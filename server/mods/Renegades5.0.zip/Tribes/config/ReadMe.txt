-|DF|- Zed 
www.Deadly-force.com
Creators of the Renegades mod  is  RenWerX   www.planetrenegades.com
Changes for renegades 5.0 are as follows 

Engineer armor gets  Vulcan,mortar,and rocket launcher also is able to deploy turrents inside of large force fields and blast walls   u can also put a platform down to cover the turrents like in Renegades classic also engineer can carry a detpack now 

Scout armor gets on extra gun  and also I added the Vulcan with a 150 rounds of ammo 

Sniper gets one extra gun  

Mec  gets 2 beacons at spawn and a hyperblaster  also it can carry a rail gun now  and it spawns with mineammo now 

Cyborg can cloak and gets 400 rounds of ammo on the Vulcan 

Spy stayed the same 

Alien can carry an extra gun  and a detpack  

Defender now can take more shots from a laser rifle and is a little faster

Spy stayed the same 

Menu options changed 

With the help of Hamster u now can change  weapons factory on the fly in the menu and u can disable the deathstar  if u have admin. Also u can vote on eather option

Weaponsfactory changes   are sniper gets energy pack and disclauncher and plasma gun Engineer gets mortar,and vulcan

Also we request that if u get this mod and edit it in anyway that u change the name of the mod Renegades is a mod Created by RenWerx and Renegades5 is a mod Authored by -|DF|- Zed with close contact to EzTarget and Dweller of RenWerx 

-|DF|- Zed is the Author of Renegades 5  if u have any probs or questions please talk to him at playemhrd2@aol.com or at brandonc@xmission.com  or go to are forum at www.Deadly-Force.com and post a message we will reply to u just give us time 

