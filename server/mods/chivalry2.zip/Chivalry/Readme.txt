Quick Install Guide:

Extract the Chivalry_v20 zipfile with sub-directories to your Tribes directory.

It should copy the following files to the following directories:

to a new Chivalry dir:
scripts.vol
readme.txt
Chivalry Admin Document.doc
versionhistory.txt

To your /temp dir:
ReturnPlayers.cs

to your /config dir:
ChivalryPrefs.cs

If these files do not appear or appear in an incorrect directory, please move them to their correct directory.

For further assistance, feel free to contact the Sojourn Development Team at sojdev@sojdev.com

For more info about how to run Chivalry, please read the Admin Document included with this zipfile.  It is highly suggested that you read and understand this document before attempting to run Chivalry as there are many technical issues associated with the Chivalry Mod.

We have left the script code open-sourced by design.  Feel free to look through our work.  If you use any of our code, please drop us an E-Mail and give us credit.  We appreciate it!

Thanks again from the Sojourn Development Team!
www.sojdev.com