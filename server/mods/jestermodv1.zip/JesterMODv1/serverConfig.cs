////////////////////////////////////////////
//$TelnetPort = 8888;
//$TelnetPassword = "ENTERYOURPASSWORDHERE";

//$Server::Address = "YOURIPADDRESSHERE";
////////////////////////////////////////////
//HIGHEST NETWORK PREF
//$pref::PacketRate = 30; 
//$pref::PacketSize = 500;
///////////////////////////////////////////
//$Server::Password = "";
//$AdminPassword = "brown";
//$pref::PacketRate = 10;
//$pref::PacketSize = 200;

//$AdminPassword = "PASSWORD";
//CHANGE YOUR PASSWORD TO SOMETHING YOU CAN REMEMBER

//***IF A LINE HAS "//" IN FRONT OF IT THEN IT IS DISABLED, REMOVE THE "//" TO ENABLE IT