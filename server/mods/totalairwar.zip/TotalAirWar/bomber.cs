ExplosionData bomberExp
{
   shapeName = "tumult_small.dts";
   soundId   = shockExplosion;

   faceCamera = true;
   randomSpin = false;
//   faceCamera = true;
//   randomSpin = true;
   hasLight   = true;
   lightRange = 8.0;

   timeScale = 1.5;

   timeZero = 0.0;
   timeOne  = 0.500;

   colors[0]  = { 0.0, 0.0, 0.0 };
   colors[1]  = { 1.0, 1.0, 1.0 };
   colors[2]  = { 1.0, 1.0, 1.0 };
   radFactors = { 0.0, 1.0, 1.0 };
};

GrenadeData BombShell
{
   bulletShapeName    = "tiebomb.dts";
   explosionTag       = bomberExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 0.0;
   maxLevelFlightDist = 1;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.0;
};

FlierData Bomber
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "tiebomber";
   shieldShapeName = "shield_medium";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 15;								   
   minSpeed = -1;
	lift = 0.35;
	maxAlt = 15;
	maxVertical = 6;
	maxDamage = 0.7;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 1.0;

	reloadDelay = 1.0;
	repairRate = 0;
	fireSound = SoundFireMortar;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Tie Bomber";
};

function Bomber::onFire(%vehicle, %slot) 
{
	if(!%vehicle.isFiring)
	{
		%count = 4;
		ToggleFire(%vehicle);
		schedule("DeployBomblets(" @ %vehicle @ " , " @ %count @ ");",0.0,%vehicle);
		schedule("ToggleFire(" @ %vehicle @ ");",6.0,%vehicle);
	}
}

function DeployBomblets(%vehicle, %count) 
{
	if(%count) {
		%trans = GameBase::getMuzzleTransform(%vehicle);
		%vel = Item::getVelocity(%vehicle);
		Projectile::spawnProjectile("BombShell",%trans,%vehicle,%vel);
		playSound(SoundFireMortar,GameBase::getPosition(%vehicle));
		%count--;
		schedule("DeployBomblets(" @ %vehicle @ " , " @ %count @ ");",0.2,%vehicle);
	}
}

function ToggleFire(%this)
{
	if(%this.isFiring)
		%this.isFiring = false;
	else 
		%this.isFiring = true;
}

//
$DamageScale[Bomber, $ImpactDamageType] = 1.2;
$DamageScale[Bomber, $BulletDamageType] = 1.0;
$DamageScale[Bomber, $PlasmaDamageType] = 1.2;
$DamageScale[Bomber, $EnergyDamageType] = 1.3;
$DamageScale[Bomber, $ExplosionDamageType] = 1.4;
$DamageScale[Bomber, $ShrapnelDamageType] = 1.5;
$DamageScale[Bomber, $DebrisDamageType] = 1.4;
$DamageScale[Bomber, $MissileDamageType] = 1.3;
$DamageScale[Bomber, $LaserDamageType] = 1.3;
$DamageScale[Bomber, $MortarDamageType] = 1.0;
$DamageScale[Bomber, $BlasterDamageType] = 1.0;
$DamageScale[Bomber, $ElectricityDamageType] = 1.5;
$DamageScale[Bomber, $MineDamageType]        = 1.0;