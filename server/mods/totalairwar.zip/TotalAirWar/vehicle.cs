//----------------------------------------------------------------------------
//

FlierData Scout
{
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 5.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.5;
   maxPitch = 5000.0;
   maxSpeed = 70;
   minSpeed = 0;
	lift = 0.9;
	maxAlt = 45;
	maxVertical = 15;
	maxDamage = 0.4;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 1.0;

	groundDamageScale = 1.0;
	repairRate = 0;
	fireSound = SoundEnergyTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 2.0;
	ramDamageType = -1;
	mapFilter = 4;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;
	range = 100;
	dopplerVelocity = 1;
   	castLOS = true;
   	supression = false;
	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Harrier VTOL";
};


FlierData LAPC
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 10.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.5;
   maxPitch = 5000.0;
   maxSpeed = 45;
   minSpeed = 0.1;
	lift = 0.2;
	maxAlt = 50;
	maxVertical = 10;
	maxDamage = 1.8;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.80;

	groundDamageScale = 0.50;
        projectileType = GrenadeShell;
	repairRate = 0;
	fireSound =  SoundMortarTurretFire;

	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	reloadDelay = 1.0;
	damageSound = SoundTankCrash;
	visibleToSensor = false;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
	description = "F-117 Stealth Fighter";
};

FlierData Strato
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.0;
   maxPitch = 5000.0;
   maxSpeed = 25;								   
   minSpeed = 0;
	lift = 0.1;
	maxAlt = 80;
	maxVertical = 6;
	maxDamage = 2.9;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.15;

	groundDamageScale = 0.125;
	projectileType = BombShell;
	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundMortarTurretFire;
	reloadDelay = 2.2;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
	description = "B-52 StratoFortress";
};

function Strato::onFire(%vehicle, %slot) 
{
	if(!%vehicle.isFiring)
	{
		%count = 10;
		ToggleFire(%vehicle);
		schedule("DeployBomblets(" @ %vehicle @ " , " @ %count @ ");",0.0,%vehicle);
		schedule("ToggleFire(" @ %vehicle @ ");",6.0,%vehicle);
	}
}

function DeployBomblets(%vehicle, %count) 
{
	if(%count) {
		%trans = GameBase::getMuzzleTransform(%vehicle);
		%vel = Item::getVelocity(%vehicle);
		Projectile::spawnProjectile("BombShell",%trans,%vehicle,%vel);
		playSound(SoundFireMortar,GameBase::getPosition(%vehicle));
		%count--;
		schedule("DeployBomblets(" @ %vehicle @ " , " @ %count @ ");",0.2,%vehicle);
	}
}

function ToggleFire(%this)
{
	if(%this.isFiring)
		%this.isFiring = false;
	else 
		%this.isFiring = true;
}


FlierData Raptor
{
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   speed = 2.0;
   speedModifier = 2.0;
   mass = 5.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.5;
   maxPitch = 5000.0;
   maxSpeed = 62;
   minSpeed = 0;
	lift = 0.1;
	maxAlt = 90;
	maxVertical = 17;
	maxDamage = 0.9;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	minGunEnergy = 60;
	maxGunEnergy = 60;
	accel = 1.25;

	groundDamageScale = 1.0;
	projectileType = MinifusionBolt;
	reloadDelay = 0.02;
	repairRate = 0;
	fireSound = SoundEnergyTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 2.0;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = false;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	shadowDetailMask = 2;
   targetableFovRatio = 0.5;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "F-22 Raptor";

};


//--------------------------------------


FlierData Warthog
{
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 5.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.5;
   maxPitch = 5000.0;
   maxSpeed = 30;
   minSpeed = 0;
	lift = 0.1;
	maxAlt = 30;
	maxVertical = 15;
	maxDamage = 2.0;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.9;

	groundDamageScale = 1.0;
	projectileType = VulcanBullet;
	reloadDelay = 0.01;
	repairRate = 0;
	sfxFire = SoundFireChaingun;
	sfxSpinUp = SoundSpinUp;
	sfxSpinDown = SoundSpinDown;
	damageSound = SoundFlierCrash;
	ramDamage = 2.0;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "A-10 Warthog";
};


FlierData Spirit
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.1;
   maxPitch = 5000.0;
   maxSpeed = 30;
   minSpeed = 0;
	lift = 0.1;
	maxAlt = 100;
	maxVertical = 10;
	maxDamage = 1.8;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.8;

	groundDamageScale = 0.50;
        projectileType = NukeRocket;
	repairRate = 0;
	fireSound =  SoundMortarTurretFire;

	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	reloadDelay = 1000.0;
	damageSound = SoundTankCrash;
	visibleToSensor = false;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
	description = "B-2 Spirit Nuclear Bomber";
};


FlierData Falcon
{
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 5.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 1.5;
   maxPitch = 5000.0;
   maxSpeed = 60;
   minSpeed = 0;
	lift = 0.1;
	maxAlt = 65;
	maxVertical = 15;
	maxDamage = 0.4;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 1.0;

	groundDamageScale = 1.0;
	reloadDelay = 1000.0;
	repairRate = 0;
	projectileType = SEADRocket;
	fireSound = SoundTurretMissleFire;
	damageSound = SoundFlierCrash;
	ramDamage = 2.0;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "F-16 Falcon";
};


FlierData Apache
{
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 3.5;
   drag = 1.3;
   density = 1.5;
   maxBank = 1.0;
   maxPitch = 1.0;
   maxSpeed = 40;
   minSpeed = -35;
	lift = 1.0;
	maxAlt = 25;
	maxVertical = 11;
	maxDamage = 0.8;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 1.0;

	groundDamageScale = 1.0;
	repairRate = 0;
	projectiletype = HellfireRocket;
	reloadDelay = 3.0;
	fireSound = SoundMissileTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 2.0;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Cobra Attack Helicopter";
};


//----------------------------------------------------------------------------

$DamageScale[Scout, $ImpactDamageType] = 1.0;
$DamageScale[Scout, $BulletDamageType] = 1.0;
$DamageScale[Scout, $PlasmaDamageType] = 1.0;
$DamageScale[Scout, $EnergyDamageType] = 1.0;
$DamageScale[Scout, $ExplosionDamageType] = 1.0;
$DamageScale[Scout, $ShrapnelDamageType] = 1.0;
$DamageScale[Scout, $DebrisDamageType] = 1.0;
$DamageScale[Scout, $MissileDamageType] = 1.0;
$DamageScale[Scout, $LaserDamageType] = 1.0;
$DamageScale[Scout, $MortarDamageType] = 1.0;
$DamageScale[Scout, $BlasterDamageType] = 0.5;
$DamageScale[Scout, $ElectricityDamageType] = 1.0;
$DamageScale[Scout, $MineDamageType]        = 1.0;

$DamageScale[LAPC, $ImpactDamageType] = 1.0;
$DamageScale[LAPC, $BulletDamageType] = 1.0;
$DamageScale[LAPC, $PlasmaDamageType] = 1.0;
$DamageScale[LAPC, $EnergyDamageType] = 1.0;
$DamageScale[LAPC, $ExplosionDamageType] = 1.0;
$DamageScale[LAPC, $ShrapnelDamageType] = 1.0;
$DamageScale[LAPC, $DebrisDamageType] = 1.0;
$DamageScale[LAPC, $MissileDamageType] = 1.0;
$DamageScale[LAPC, $LaserDamageType] = 0.5;
$DamageScale[LAPC, $MortarDamageType] = 1.0;
$DamageScale[LAPC, $BlasterDamageType] = 0.5;
$DamageScale[LAPC, $ElectricityDamageType] = 1.0;
$DamageScale[LAPC, $MineDamageType]        = 1.0;

$DamageScale[HAPC, $ImpactDamageType] = 1.0;
$DamageScale[HAPC, $BulletDamageType] = 1.0;
$DamageScale[HAPC, $PlasmaDamageType] = 1.0;
$DamageScale[HAPC, $EnergyDamageType] = 1.0;
$DamageScale[HAPC, $ExplosionDamageType] = 1.0;
$DamageScale[HAPC, $ShrapnelDamageType] = 1.0;
$DamageScale[HAPC, $DebrisDamageType] = 1.0;
$DamageScale[HAPC, $MissileDamageType] = 1.0;
$DamageScale[HAPC, $LaserDamageType] = 0.5;
$DamageScale[HAPC, $MortarDamageType] = 1.0;
$DamageScale[HAPC, $BlasterDamageType] = 0.5;
$DamageScale[HAPC, $ElectricityDamageType] = 1.0;
$DamageScale[HAPC, $MineDamageType]        = 1.0;

$DamageScale[Raptor, $ImpactDamageType] = 1.0;
$DamageScale[Raptor, $BulletDamageType] = 1.0;
$DamageScale[Raptor, $PlasmaDamageType] = 1.0;
$DamageScale[Raptor, $EnergyDamageType] = 1.5;
$DamageScale[Raptor, $ExplosionDamageType] = 1.0;
$DamageScale[Raptor, $ShrapnelDamageType] = 1.0;
$DamageScale[Raptor, $DebrisDamageType] = 1.0;
$DamageScale[Raptor, $MissileDamageType] = 1.0;
$DamageScale[Raptor, $LaserDamageType] = 1.0;
$DamageScale[Raptor, $MortarDamageType] = 1.0;
$DamageScale[Raptor, $BlasterDamageType] = 0.5;
$DamageScale[Raptor, $ElectricityDamageType] = 1.0;
$DamageScale[Raptor, $MineDamageType]        = 1.0;

$DamageScale[Warthog, $ImpactDamageType] = 1.0;
$DamageScale[Warthog, $BulletDamageType] = 1.0;
$DamageScale[Warthog, $PlasmaDamageType] = 1.0;
$DamageScale[Warthog, $EnergyDamageType] = 1.5;
$DamageScale[Warthog, $ExplosionDamageType] = 1.0;
$DamageScale[Warthog, $ShrapnelDamageType] = 1.0;
$DamageScale[Warthog, $DebrisDamageType] = 1.0;
$DamageScale[Warthog, $MissileDamageType] = 1.0;
$DamageScale[Warthog, $LaserDamageType] = 1.0;
$DamageScale[Warthog, $MortarDamageType] = 1.0;
$DamageScale[Warthog, $BlasterDamageType] = 0.5;
$DamageScale[Warthog, $ElectricityDamageType] = 1.0;
$DamageScale[Warthog, $MineDamageType]        = 1.0;

$DamageScale[Spirit, $ImpactDamageType] = 1.0;
$DamageScale[Spirit, $BulletDamageType] = 1.0;
$DamageScale[Spirit, $PlasmaDamageType] = 1.0;
$DamageScale[Spirit, $EnergyDamageType] = 1.5;
$DamageScale[Spirit, $ExplosionDamageType] = 1.0;
$DamageScale[Spirit, $ShrapnelDamageType] = 1.0;
$DamageScale[Spirit, $DebrisDamageType] = 1.0;
$DamageScale[Spirit, $MissileDamageType] = 1.0;
$DamageScale[Spirit, $LaserDamageType] = 1.0;
$DamageScale[Spirit, $MortarDamageType] = 1.0;
$DamageScale[Spirit, $BlasterDamageType] = 0.5;
$DamageScale[Spirit, $ElectricityDamageType] = 1.0;
$DamageScale[Spirit, $MineDamageType]        = 1.0;

$DamageScale[Strato, $ImpactDamageType] = 1.0;
$DamageScale[Strato, $BulletDamageType] = 1.0;
$DamageScale[Strato, $PlasmaDamageType] = 1.0;
$DamageScale[Strato, $EnergyDamageType] = 1.5;
$DamageScale[Strato, $ExplosionDamageType] = 1.0;
$DamageScale[Strato, $ShrapnelDamageType] = 1.0;
$DamageScale[Strato, $DebrisDamageType] = 1.0;
$DamageScale[Strato, $MissileDamageType] = 1.0;
$DamageScale[Strato, $LaserDamageType] = 1.0;
$DamageScale[Strato, $MortarDamageType] = 1.0;
$DamageScale[Strato, $BlasterDamageType] = 0.5;
$DamageScale[Strato, $ElectricityDamageType] = 1.0;
$DamageScale[Strato, $MineDamageType]        = 1.0;

$DamageScale[Falcon, $ImpactDamageType] = 1.0;
$DamageScale[Falcon, $BulletDamageType] = 1.0;
$DamageScale[Falcon, $PlasmaDamageType] = 1.0;
$DamageScale[Falcon, $EnergyDamageType] = 1.5;
$DamageScale[Falcon, $ExplosionDamageType] = 1.0;
$DamageScale[Falcon, $ShrapnelDamageType] = 1.0;
$DamageScale[Falcon, $DebrisDamageType] = 1.0;
$DamageScale[Falcon, $MissileDamageType] = 1.0;
$DamageScale[Falcon, $LaserDamageType] = 1.0;
$DamageScale[Falcon, $MortarDamageType] = 1.0;
$DamageScale[Falcon, $BlasterDamageType] = 0.5;
$DamageScale[Falcon, $ElectricityDamageType] = 1.0;
$DamageScale[Falcon, $MineDamageType]        = 1.0;

$DamageScale[Apache, $ImpactDamageType] = 1.0;
$DamageScale[Apache, $BulletDamageType] = 1.0;
$DamageScale[Apache, $PlasmaDamageType] = 1.0;
$DamageScale[Apache, $EnergyDamageType] = 1.5;
$DamageScale[Apache, $ExplosionDamageType] = 1.0;
$DamageScale[Apache, $ShrapnelDamageType] = 1.0;
$DamageScale[Apache, $DebrisDamageType] = 1.0;
$DamageScale[Apache, $MissileDamageType] = 1.0;
$DamageScale[Apache, $LaserDamageType] = 1.0;
$DamageScale[Apache, $MortarDamageType] = 1.0;
$DamageScale[Apache, $BlasterDamageType] = 0.5;
$DamageScale[Apache, $ElectricityDamageType] = 1.0;
$DamageScale[Apache, $MineDamageType]        = 1.0;

$DamageScale[Hover, $ImpactDamageType] = 1.0;
$DamageScale[Hover, $BulletDamageType] = 1.0;
$DamageScale[Hover, $PlasmaDamageType] = 1.0;
$DamageScale[Hover, $EnergyDamageType] = 1.0;
$DamageScale[Hover, $ExplosionDamageType] = 1.0;
$DamageScale[Hover, $ShrapnelDamageType] = 1.0;
$DamageScale[Hover, $DebrisDamageType] = 1.0;
$DamageScale[Hover, $MissileDamageType] = 1.0;
$DamageScale[Hover, $LaserDamageType] = 1.0;
$DamageScale[Hover, $MortarDamageType] = 1.0;
$DamageScale[Hover, $BlasterDamageType] = 0.5;
$DamageScale[Hover, $ElectricityDamageType] = 1.0;
$DamageScale[Hover, $MineDamageType]        = 1.0;
//----------------------------------------------------------------------------

function Vehicle::onAdd(%this)
{
	%this.shieldStrength = 0.0;
	GameBase::setRechargeRate (%this, 10);
	GameBase::setMapName (%this, "Vehicle");
}

function Vehicle::onCollision (%this, %object)
{
	if(GameBase::getDamageLevel(%this) < (GameBase::getDataName(%this)).maxDamage) {
		if (getObjectType (%object) == "Player" && %object.vehicle == "" && (getSimTime() > %object.newMountTime || %object.lastMount != %this) && %this.fading == "")
			{
            if( Player::isAiControlled(%object) )
               return;
               
				%armor = Player::getArmor(%object);
		      %client = Player::getClient(%object);
				if ((%armor == "larmor" || %armor == "lfemale") && Vehicle::canMount (%this, %object))
					{
						%weapon = Player::getMountedItem(%object,$WeaponSlot);
						if(%weapon != -1) {
							%object.lastWeapon = %weapon;
							Player::unMountItem(%object,$WeaponSlot);
						}
						Player::setMountObject(%object, %this, 1);
				      Client::setControlObject(%client, %this);
						playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
						%object.driver= 1;
		            %object.vehicle = %this;
						%this.clLastMount = %client;
					}
				else if(GameBase::getDataName(%this) != Scout) 
					{
					 	%mountSlot= Vehicle::findEmptySeat(%this,%client); 
						if(%mountSlot) 
							{
								%object.vehicleSlot = %mountSlot;
								%object.vehicle = %this;
								Player::setMountObject(%object, %this, %mountSlot);
								playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
							}
					}
				else if (GameBase::getControlClient(%this) == -1)
					Client::sendMessage(Player::getClient(%object),0,"You must be in Light Armor to pilot the vehicles.~wError_Message.wav");
			}
	}
}


function getClosestPosition(%num,%playerPos,%slotPos0,%slotPos1,%slotPos2,%slotPos3)
{
	%playerX = getWord(%playerPos,0);
	%playerY = getWord(%playerPos,1);
	for(%i = 0 ;%i<%num;%i++) {
		%x = (getWord(%slotPos[%i],0)) - %playerX;
		%y = (getWord(%slotPos[%i],1)) - %playerY;
		if(%x < 0)
			%x *= -1;
		if(%y < 0)
			%y *= -1;
		%newDistance = sqrt((%x*%x)+(%y*%y));
		if(%newDistance < %distance || %distance == "") {
	  		%distance = %newDistance;			
			%closePos = %i;	
		}
	}		
	return %closePos;
}

function Vehicle::passengerJump(%this,%passenger,%mom)
{
	%armor = Player::getArmor(%passenger);
	if(%armor == "larmor" || %armor == "lfemale") {
		%height = 2;
		%velocity = 70;
		%zVec = 70;
	}
	else if(%armor == "marmor" || %armor == "mfemale") {
		%height = 2;
		%velocity = 100;
		%zVec = 100;
	}
	else if(%armor == "harmor") {
		%height = 2;
		%velocity = 140;
		%zVec = 110;
	}

	%pos = GameBase::getPosition(%passenger);
	%posX = getWord(%pos,0);
	%posY	= getWord(%pos,1);
	%posZ	= getWord(%pos,2);

	if(GameBase::testPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height))) {	
		%client = Player::getClient(%passenger);
		%this.Seat[%passenger.vehicleSlot-2] = "";
		%passenger.vehicleSlot = "";
	   %passenger.vehicle= "";
		Player::setMountObject(%passenger, -1, 0);
		%rotZ = getWord(GameBase::getRotation(%passenger),2);
		GameBase::setRotation(%passenger, "0 0 " @ %rotZ);
		GameBase::setPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height));
		%jumpDir = Vector::getFromRot(GameBase::getRotation(%passenger),%velocity,%zVec);
		Player::applyImpulse(%passenger,%jumpDir);
	}
	else
		Client::sendMessage(Player::getClient(%passanger),0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
}

function Vehicle::jump(%this,%mom)
{
   Vehicle::dismount(%this,%mom);
}

function Vehicle::dismount(%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   if(%cl != -1)
   {
      %pl = Client::getOwnedObject(%cl);
      if(getObjectType(%pl) == "Player")
      {
		   // dismount the player	  
			if(GameBase::testPosition(%pl, Vehicle::getMountPoint(%this,0))) {
				%pl.lastMount = %this;
				%pl.newMountTime = getSimTime() + 3.0;
				Player::setMountObject(%pl, %this, 0);
        	 	Player::setMountObject(%pl, -1, 0);
				%rot = GameBase::getRotation(%this);
				%rotZ = getWord(%rot,2);
				GameBase::setRotation(%pl, "0 0 " @ %rotZ);
				Player::applyImpulse(%pl,%mom);
        	 	Client::setControlObject(%cl, %pl);
				playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
				if(%pl.lastWeapon != "") {
					Player::useItem(%pl,%pl.lastWeapon);		 	
					%pl.lastWeapon = "";
      		}
				%pl.driver = "";
				%pl.vehicle = "";
			}
			else
				Client::sendMessage(%cl,0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
		}
   }
}

function Vehicle::onDestroyed (%this,%mom)
{
//	if($testcheats || $servercheats)
	$TeamItemCount[GameBase::getTeam(%this) @ $VehicleToItem[GameBase::getDataName(%this)]]--;
   %cl = GameBase::getControlClient(%this);
	%pl = Client::getOwnedObject(%cl);
	if(%pl != -1) {
	   Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
		if(%pl.lastWeapon != "") {
			Player::useItem(%pl,%pl.lastWeapon);		 	
			%pl.lastWeapon = "";
		}
		%pl.driver = "";
	   %pl.vehicle= "";
	}
	for(%i = 0 ; %i < 4 ; %i++)
		if(%this.Seat[%i] != "") {
			%pl = Client::getOwnedObject(%this.Seat[%i]);
		   Player::setMountObject(%pl, -1, 0);
	  	 	Client::setControlObject(%this.Seat[%i], %pl);
			%pl.vehicleSlot = "";
		   %pl.vehicle= "";
		}
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.55, 
		0.1, 225, 100); 
}

function Vehicle::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
	%value *= $damageScale[GameBase::getDataName(%this), %type];
	StaticShape::onDamage(%this,%type,%value,%pos,%vec,%mom,%object);
}

function Vehicle::getHeatFactor(%this)
{
	// Not getting called right now because turrets don't track
	// vehicles.  A hack has been placed in Player::getHeatFactor.
   return 1.0;
}


