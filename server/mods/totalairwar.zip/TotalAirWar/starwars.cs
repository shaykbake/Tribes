$SW::MODInfo = "<jc>\n<f2>-=Star Wars 0.1a=-\n<f0>For more information, visit the Star Wars Mod homepage at:\n<f1>http://noodles.scriptmania.com\n";

$Server::teamName0 = "Imperial Forces";
$Server::teamName1 = "Rebel Alliance";
$Server::teamName2 = "Generic 1";
$Server::teamName3 = "Generic 2";
$Server::teamName4 = "Generic 3";
$Server::teamName5 = "Generic 4";
$Server::teamName6 = "Generic 5";
$Server::teamName7 = "Generic 6";
$Server::teamSkin0 = "beagle";
$Server::teamSkin1 = "dsword";
$Server::teamSkin2 = "base";
$Server::teamSkin3 = "base";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";