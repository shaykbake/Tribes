TOTAL AIR WAR BETA v.2 
Temple of Pants design team
|HU|Antilles
Wraith|HU|

Thanks to all the other Modders out there for ideas.

This IS a client-side mod and must be downloaded as it includes new skins and maps.
 Installation:  unzip all files to C:\Dynamix\Tribes. the rest will be taken care of.. open C:\Dynamix\Tribes\TotalAirWar and look for a link to launch the MOD.  


Description:
All armors are capable of carrying the standard issue .44 Automatic. A small, effective pistol for personal defnse in case caught in the wilderness.  Jets do not exist in armors.  They were taken out for realism.  All maps to be realeased will include this as a factor.  Packs available are repair packs, pilots and target designators are able to carry.  Sensor jammer packs for the target designators only.  And  of course the standard one-time-use mdeical kit for all armors.  NOTE:  The G-suit must be equiped to fly aircraft.  The stresses put on pilots during aerobatic manuevers wil kill someone not wearing a G-suit.  The g-suit is extrememly vulnerable, as it is not armor, but a thin spacesuit.  

Maps shipped with this Beta release:
Nellis AFB - two airfields, each facing each other.  Each team has two runways, complete with a control tower, capable of controlling the six AAA\SAM sites that surround the bases.  Rules are the same as a D&D mission, there is one objective, protected by the six AAA\SAM sites and the players themselves.  if the objective is destroyed then the team loses and the next map is cycled.  Check map for more details.

Airbase - A mission similar to Nellis.. but with more functionality.. less air defenses requiring Pilots to defend manually.

-------------------------------------------------
Weapons:
1..44 Standard Issue - High caliber pistol with capabilities of killing a pilot with one shot.  All personel carry one.  Fairly accurate witha  medium range.  
-------------------------------------------------
NOTE on vehicles:  the vehicles are extremely manueverable.  Flipping and Loops are capable, so use them, =)
Vehicles:
[Small Aircraft]
1.F-22 Raptor - Mini Fusion Cannon with rapid fire rate, fast, manueverable, stealth
2.A-10 Warthog - Chaingun, with semi-fast fire rate, fairly manueverable, slower than fighter
3.Harrier VTOL scout - No weapons, extremely fast and manueverable, used for scoping out enemy lines...capable of vertical lifting.

[Anti Equipment]
1. F-16 Attack Fighter - Carries a SEAD missile, ONE shot.  The SEAD missile is capable of taking out shielded objects with one hit, but the hit must be ientirely accurate.. no slip up in the launch.

2.Cobra Attack Helicopter - Carries Hellfire Missiles, capable of taking out lightly defended objects, with no shields.  Keep in mind this is a helicopter, and is capable of up and down and back and forth flying. Use these as you hide from SAMs.. you'll need the manueverability. 

[Large Bombers]
1.B-52 - Large bomber which pack a punch, drops a large bomb at a medium fire rate... be warned this aircraft is reasonable slow and is not stealth, fighter escort is needed for bombing runs...

2.B-2 Spirit Nuclear Bomber - As the name implies it makes an entrance, and with the cloak of invisibility also.. but be warned it is slow as crap, to be put bluntly, this is the big momma, protect at all costs.... only one shot per run, so make it good... one note about the bomb, it is launched from the front of the aircraft and it requires you to fire BEFORE you get to the target... works well in conjuction with a person target lasing the target ::cough:: HINT! ::cough::

Through extensive playtesting we've discovered the range of the blast on the nuke, 450 meters.  A beacon can be seen from 600 meters, this gives you 150 to accuire a bead and launch the nuke.  

3.F-117 Stealth Fighter : Completely invisible to SAM\AAA Sites, just as the B-2.  Reasonably fast, and carries a weak, but fast firing bomb...

-----------------------------------------------
Items:  on each map there will be resupply rooms (look for them near your airfield)
Target lasers - useful in marking targets for the nuclear bomber...

Repair pack - used when your AAA and SAM launchers are destroyed due to enemy threats

Sensor jammer pack - suited for sneaking into enemy installations and marking targets with

Targeting beacons - placed near enemy objects of importance for marking enemy positions for your bombers...

-----------------------------------------------
Turrets :

AAA (Antiaircraft Artillery) - Sprays the skies with bullets, efficently destroying low-flying aircraft.

SAM (Surface to Air Missile) Launchers - Used for high altitude attackers. (mostly Bombers)
Will accuire and fire by themselves.



Coming soon (Possibly within the next release) 
Mountable turrets. AAA only.
More maps.
Pilot\target designator skins (BETA pilot skin for males on Blood eagle team)
Models ( we need modelers, and help is welcome)
Heat seeking missiles for the F-22

e-mail us at:
Antilles56k@cs.com
wraithgw@jadepro.net
bug reports\offer services 
