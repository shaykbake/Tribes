Extract zip file to C:\Dynamix\Tribes (assuming your installation drive is C:)

This will create the following files:

README.txt (this file)
Pantheon Normal.lnk
Pantheon Dedicated.lnk
Pantheon\scripts.vol
Pantheon\Pantheon MOD Website.URL
Pantheon\CHANGELOG.txt
config\Pantheon.cs
base\missions\Boredom.cs
base\missions\Boredom.dsc
base\missions\Boredom.mis
