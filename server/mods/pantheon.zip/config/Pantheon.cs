//Ban time in seconds
$Pantheon::BanKickTime = "5000";

//Auto assign new players to teams to make it fair
$Pantheon::fairTeams = "true";

//Number of seconds the player is allow to be outside of the mission area
$Pantheon::LeaveAreaTime = "20";

// Item limits

$Pantheon::AmmoStationLimit	= 7;
$Pantheon::InvStationLimit	= 7;
$Pantheon::CommandStationLimit	= 0;

$Pantheon::CameraLimit 		= 15;
$Pantheon::ProximityAlarmLimit  = 0; //DISABLED IN 1.02 DUE TO BUG. Usually 5.
$Pantheon::SensorJammerLimit 	= 5;
$Pantheon::PulseSensorLimit	= 10;
$Pantheon::MotionSensorLimit	= 10;

$Pantheon::BeaconLimit		= 40;
$Pantheon::MineLimit		= 35;

$Pantheon::ForceFieldLimit	= 5;
$Pantheon::LargeForceFieldLimit = 3;
$Pantheon::ForceFieldDoorLimit	= 4;

$Pantheon::IndoorTurretLimit 	= 5;
$Pantheon::LaserTurretLimit	= 5;
$Pantheon::DissectionLimit	= 2;
$Pantheon::MortarTurretLimit	= 3;
$Pantheon::VulcanTurretLimit	= 2;
$Pantheon::PlasmaTurretLimit	= 3;
$Pantheon::MissileTurretLimit	= 3;
$Pantheon::RocketBatteryLimit	= 2;
$Pantheon::PlasmaTurretDecoy	= 0;
$Pantheon::ELFTurretLimit	= 4;

$Pantheon::BlastwallLimit	= 12;
$Pantheon::TeleportDecoyLimit	= 5;
$Pantheon::SolarPanelLimit	= 2;
$Pantheon::SniperPadLimit	= 4;
$Pantheon::OutpostLimit		= 2;
$Pantheon::SpringboardLimit	= 5;
$Pantheon::PlatformLimit	= 12;
$Pantheon::SeedPackLimit	= 25;
$Pantheon::InterceptorPackLimit	= 3;
$Pantheon::FGCPackLimit		= 2;

$Pantheon::ScoutVehicleLimit	= 3;
$Pantheon::MarauderVehicleLimit = 2;
$Pantheon::HAPCVehicleLimit	= 3;
$Pantheon::LAPCVehicleLimit	= 3;
$Pantheon::GunshipVehicleLimit	= 4;
$Pantheon::InterceptorLimit	= 3;


//Number of Nukes a team can use per map
$Pantheon::NumberOfNukes = "1";

//Time in seconds before nuclear detonation
$Pantheon::NukeDetTime = "20";

//Players are allowed to change teams
$Pantheon::ChangeTeams = "true";

//Number of seconds a player can be in an inventory station before being ejected
$Pantheon::StationKickTime = "20";

//Points for killing vulcan turrets
$Pantheon::KillFriendlyVulcanPoints = "true";
$Pantheon::KillEnemyVulcanPoints = "true";

//Points for killing laser turrets
$Pantheon::KillFriendlyLaserPoints = "true";
$Pantheon::KillEnemyLaserPoints = "true";

//Public Admin options
$Pantheon::PABan = "false";
$Pantheon::PAKick = "true";
$Pantheon::PAGag = "true";
$Pantheon::PAMission = "false";
$Pantheon::PAModOptions = "false";
$Pantheon::PAResetDefaults = "false";
$Pantheon::PATeamChange = "false";
$Pantheon::PATeamDamage = "false";
$Pantheon::PATeamInfo = "false";
$Pantheon::PATimelimit = "false";
$Pantheon::PATourneyMode = "false";
//Is public admin votable
$Pantheon::PAVote = "false";

//Are players permitted to use personal skins
$Pantheon::PersonalSkins = "true";

//Public voting options
$Pantheon::PVKick = "true";
$Pantheon::PVMission = "false";
$Pantheon::PVTeamDamage = "false";
$Pantheon::PVTourneyMode = "false";

//What the client can do to TK'ers (0=vote, 1=kick)
$Pantheon::tkClientLvl = "0";

//Number of TK's a player can recieve before being punished
$Pantheon::tkLimit = "3";

//Number of TK's after tkLimit to retry tkServerLvl action
$Pantheon::tkMultiple = "3";

//What the server does to TK'ers (0=log, 1=vote, 2=vote until kicked, 3=auto-kick)
$Pantheon::tkServerLvl = "3";

//Team energy
$DefaultTeamEnergy = "Infinite";

//Super Admin password
$AdminPassword = "insertpasswordhere";

//Public Admin password
$RegularAdminPassword = "adminme";

//Telnet port for things such as EZConsole
$TelnetPort = 28100;

//Telnet password for things such as EZConsole
$TelnetPassword = "insertpasswordhere";

//Force the clients to use this many packets per second (8 recommended)
$pref::PacketRate = 8;

//Force the client to use packets of this size (200 recommended)
$pref::PacketSize = 200;

//Auto-kick morons by name (maximum of 5 names)
$Pantheon::AutoKickDumbass[0] = "Tribes_sucks";
$Pantheon::AutoKickDumbass[1] = "";
$Pantheon::AutoKickDumbass[2] = "";
$Pantheon::AutoKickDumbass[3] = "";
$Pantheon::AutoKickDumbass[4] = "";

