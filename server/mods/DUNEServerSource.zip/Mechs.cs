// Mechs don't work. DOn't bother with them

//Different types


//----------------------------------------------------------------------------
// Mech Armor
//----------------------------------------------------------------------------

$DamageScale[marmor, $LandingDamageType] = 0.1;
$DamageScale[marmor, $ImpactDamageType] = 0.1;
$DamageScale[marmor, $CrushDamageType] = 1.0;
$DamageScale[marmor, $BulletDamageType] = 0.0;
$DamageScale[marmor, $PlasmaDamageType] = 0.2;
$DamageScale[marmor, $EnergyDamageType] = 1.0;
$DamageScale[marmor, $ExplosionDamageType] = 1.0;
$DamageScale[marmor, $MissileDamageType] = 1.0;	
$DamageScale[marmor, $DebrisDamageType] = 0.8;	
$DamageScale[marmor, $ShrapnelDamageType] = 0.0;
$DamageScale[marmor, $LaserDamageType] = 0.8;	
$DamageScale[marmor, $MortarDamageType] = 1.0;	
$DamageScale[marmor, $BlasterDamageType] = 1.0;	
$DamageScale[marmor, $ElectricityDamageType] = 1.0;
$DamageScale[marmor, $MineDamageType] = 1.0;	
$DamageScale[marmor, $StabDamageType] = 0.0;	
$DamageScale[marmor, $PoisonDamageType] = 0.0;	
$DamageScale[marmor, $StunnerDamageType] = 0.0;	
$DamageScale[marmor, $NukeDamageType] = 1.0;	
$DamageScale[marmor, $Poison2DamageType] = 0.0;	
$DamageScale[marmor, $WormDamageType] = 1.0;	
$DamageScale[marmor, $CutterayDamageType] = 2.0;
$DamageScale[marmor, $SmallLasDamageType] = 0.8;
$DamageScale[marmor, $RifleLasDamageType] = 0.8;
$DamageScale[marmor, $HeavyLasDamageType] = 0.8;
$DamageScale[marmor, $AsphyxiationDamageType] = 0.0;
$DamageScale[marmor, $LargeBulletDamageType] = 0.5;
$DamageScale[marmor, $ThrownWeaponDamageType] = 0.0;
$DamageScale[marmor, $ThrownPoisonWeaponDamageType] = 0.0;

//Old ones
$ItemMax[marmor, Blaster] = 0;			
$ItemMax[marmor, Chaingun] = 0;			
$ItemMax[marmor, Disclauncher] = 0;
$ItemMax[marmor, GrenadeLauncher] = 0;						
$ItemMax[marmor, Mortar] = 0;
$ItemMax[marmor, PlasmaGun] = 0;				
$ItemMax[marmor, LaserRifle] = 0;	
$ItemMax[marmor, EnergyRifle] = 0;	
$ItemMax[marmor, TargetingLaser] = 0;	
$ItemMax[marmor, MineAmmo] = 0;		
$ItemMax[marmor, Grenade] = 0;		

//Blades
$ItemMax[marmor, Knife]  = 0;	
$ItemMax[marmor, Knife2]  = 0;	
$ItemMax[marmor, SlipTip]  = 0;	
$ItemMax[marmor, Crysknife]  = 0;
$ItemMax[marmor, Kindjal]  = 0;	
$ItemMax[marmor, Saber]  = 0;	

//Projectiles
$ItemMax[marmor, Pistol]  = 0;	
$ItemMax[marmor, Maula]  = 0;	
$ItemMax[marmor, Stunner]  = 0;	
$ItemMax[marmor, Rifle]  = 0;	
$ItemMax[marmor, MGun]  = 0;	
$ItemMax[marmor, SniperRifle]  = 0;
$ItemMax[marmor, RLauncher]  = 0;
$ItemMax[marmor, Flamethrower]  = 0;
$ItemMax[marmor, Piller]  = 0;	

//Lasguns
$ItemMax[marmor, Cutteray]  = 0;
$ItemMax[marmor, SmallLas]  = 0;
$ItemMax[marmor, RifleLas]  = 0;
$ItemMax[marmor, HeavyLas]  = 0;

//Items...
$ItemMax[marmor, RepairKit] = 0;
$ItemMax[marmor, Beacon]  = 0;	

//Old ammos
$ItemMax[marmor, BulletAmmo] = 0;
$ItemMax[marmor, PlasmaAmmo] = 0;			
$ItemMax[marmor, DiscAmmo] = 0;	
$ItemMax[marmor, GrenadeAmmo] = 0;	
$ItemMax[marmor, MortarAmmo] = 0;				

//Clips
$ItemMax[marmor, PistolClip] = 0;			
$ItemMax[marmor, MaulaClip] = 0;
$ItemMax[marmor, StunnerClip] = 0;
$ItemMax[marmor, RifleClip] = 0;
$ItemMax[marmor, SniperClip] = 0;
$ItemMax[marmor, MGunClip] = 0;	
$ItemMax[marmor, CutterayCell] = 0;
$ItemMax[marmor, SmallLasCell] = 0;
$ItemMax[marmor, RifleLasCell] = 0;
$ItemMax[marmor, HeavyLasCell] = 0;

//New ammos
$ItemMax[marmor, PistolAmmo] = 0;
$ItemMax[marmor, MaulaAmmo] = 0;
$ItemMax[marmor, StunnerAmmo] = 0;
$ItemMax[marmor, RifleAmmo] = 0;
$ItemMax[marmor, MGunAmmo] = 0;	
$ItemMax[marmor, SniperAmmo] = 0;	
$ItemMax[marmor, RLauncherAmmo] = 0;	
$ItemMax[marmor, FlamethrowerAmmo] = 0;	
$ItemMax[marmor, PillerAmmo] = 0;	
$ItemMax[marmor, CutterayAmmo] = 0;	
$ItemMax[marmor, SmallLasAmmo] = 0;	
$ItemMax[marmor, RifleLasAmmo] = 0;	
$ItemMax[marmor, HeavyLasAmmo] = 0;	

//Old packs not used
$ItemMax[marmor, EnergyPack] = 0;
$ItemMax[marmor, TurretPack] = 0;

//Old packs used
$ItemMax[marmor, RepairPack] = 0;	
$ItemMax[marmor, ShieldPack] = 0;	
$ItemMax[marmor, SensorJammerPack] = 0;	
$ItemMax[marmor, AmmoPack] = 0;		

//New Packs
$ItemMax[marmor, ExplosivePack] = 0;	
$ItemMax[marmor, SuicidePack] = 0;	
$ItemMax[marmor, FuelPack] = 0;		
$ItemMax[marmor, SuspensorPack] = 0;	
$ItemMax[marmor, StoneBurnerPack] = 0;	
$ItemMax[marmor, SNukePack] = 0;	
$ItemMax[marmor, MNukePack] = 0;	
$ItemMax[marmor, LNukePack] = 0;	
$ItemMax[marmor, CamoPack] = 0;		
$ItemMax[marmor, ThumperPack] = 0;	

//Old deployable packs used
$ItemMax[marmor, MotionSensorPack] = 0;		
$ItemMax[marmor, PulseSensorPack] = 0;		
$ItemMax[marmor, DeployableSensorJammerPack] = 0;
$ItemMax[marmor, CameraPack] = 0;		
$ItemMax[marmor, DeployableInvPack] = 0;	
$ItemMax[marmor, DeployableAmmoPack] = 0;	

//New deployable packs used
$ItemMax[marmor, PlasteelPack] = 0;		
$ItemMax[marmor, LPentashieldPack] = 0;		
$ItemMax[marmor, SPentashieldPack] = 0;		
$ItemMax[marmor, DeployableGenPack] = 0;	
$ItemMax[marmor, HieregPack] = 0;		
$ItemMax[marmor, StationaryLasgunPack] = 0;	
$ItemMax[marmor, RepeaterLasgunPack] = 0;	
$ItemMax[marmor, RemoteLasgunPack] = 0;		
$ItemMax[marmor, RemoteProjectileGunPack] = 0;	
$ItemMax[marmor, HunterSeekerPlatformPack] = 0;	
$ItemMax[marmor, GholaPack] = 0;		

$ItemMax[marmor, MechPack] = 0;

$MaxWeapons[marmor] = 0;		

$ArmorType[Female, MechArmor] = marmor;
$ArmorType[Male, MechArmor] = marmor;
$ArmorName[marmor] = MechArmor;

$AutoUse[MechMachine1Gun] = True;
$AutoUse[MechMachine2Gun] = True;
$AutoUse[MechMachine3Gun] = True;
$AutoUse[MechMachine4Gun] = True;


$AutoUse[MechArtillary1Gun] = True;
$AutoUse[MechArtillary2Gun] = True;

$WeapProjectile[MechMachine1Gun] = RMachineBullet;
$WeapProjectile[MechMachine2Gun] = RMachineBullet;
$WeapProjectile[MechMachine3Gun] = RMachineBullet;
$WeapProjectile[MechMachine4Gun] = RMachineBullet;


$WeapProjectile[MechArtillary1Gun] = MortarTurretShell;
$WeapProjectile[MechArtillary2Gun] = MortarTurretShell;

$WeapProjectile[Mech1RLauncher] = StingerRocket;
$WeapProjectile[Mech2RLauncher] = StingerRocket;
$WeapProjectile[Mech3RLauncher] = MechRocket;
$WeapProjectile[Mech4RLauncher] = MechRocket;

$WeaponAmmo[MechMachine1Gun] = "";
$WeaponAmmo[MechMachine2Gun] = "";
$WeaponAmmo[MechMachine3Gun] = "";
$WeaponAmmo[MechMachine4Gun] = "";

$WeaponAmmo[MechArtillary1Gun] = "";
$WeaponAmmo[MechArtillary2Gun] = "";

$WeaponAmmo[Mech1RLauncher] = "";
$WeaponAmmo[Mech2RLauncher] = "";
$WeaponAmmo[Mech3RLauncher] = "";
$WeaponAmmo[Mech4RLauncher] = "";


// Some modified code from Annihilation
function CheckMechMachineGun(%client, %player) 
{
	//if(Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == "MechMachineGunTrigger")) 
	if(!$FiringMechMachine[%client])
	{
		
		Player::trigger(%player,4,true);
		Player::trigger(%player,5,true);
		Player::trigger(%player,6,true);
		Player::trigger(%player,7,true);
		
		//schedule("CheckMechMachineGun(" @ %client @ "," @ %player @ ");",0.1);
		$FiringMechMachine[%client] = true;
	}
	else
	{	
		Player::trigger(%player,4,false);
		Player::trigger(%player,5,false);
		Player::trigger(%player,6,false);
		Player::trigger(%player,7,false);
		$FiringMechMachine[%client] = false;
	}
}

function MechMachineGunTriggerImage::onactivate(%player, %slot) 
{
	%client = GameBase::getOwnerClient(%player);
	//weapon::onfire(%player,%slot);
	CheckMechMachineGun(%client, %player);
}

function MechMachineGunTriggerImage::ondeactivate(%player, %slot) 
{
	%client = GameBase::getOwnerClient(%player);
	//weapon::onfire(%player,%slot);
	CheckMechMachineGun(%client, %player);
		
}

function MechMachine1GunImage::onFire(%player, %slot) 
{
	if(Gamebase::getenergy(%player) >= 2) 
	{
		player::unmountitem(%player,MechNullGun);
		player::MountItem(%player,MechNullGun,4);
		player::mountItem(%player,MechMachine1Gun,0);
		weapon::onfire(%player);
		//MechMachine2GunImage::onFire(%player,%slot);
		player::mountItem(%player,MechMachine1Gun,4);
		player::mountItem(%player,MechMachine2Gun,0);
		weapon::onfire(%player);
		//MechMachine3GunImage::onFire(%player,%slot);
		player::mountItem(%player,MechMachine2Gun,5);
		player::mountItem(%player,MechMachine3Gun,0);
		weapon::onfire(%player);
		//MechMachine4GunImage::onFire(%player,%slot);
		player::mountItem(%player,MechMachine3Gun,6);
		player::mountItem(%player,MechMachine4Gun,0);
		weapon::onfire(%player);
		player::mountItem(%player,MechMachine4Gun,7);
		player::useItem(%player,MechNullGun);
		Player::mountitem(%player,MechNullGun,0);
		Gamebase::setEnergy(%player,Gamebase::GetEnergy(%player)-1.37);
	} else
	{
		MechMachineGunTriggerImage::ondeactivate(%player, 1) ;
		//%client = GameBase::getOwnerClient(%player);
		//weapon::onfire(%player,%slot);
		//CheckMechMachineGun(%client, %player);
	}
}

function MechMachine2GunImage::onFire(%player, %slot) 
{

}

function MechMachine3GunImage::onFire(%player, %slot) 
{
}

function MechMachine4GunImage::onFire(%player, %slot) 
{
}

function mechArtillary1GunImage::onFire(%player,%slot)
{
	weapon::onfire(%player);
	schedule("Weapon::onfire("@%player@");",0.3);
}


function MechNullGunImage::onFire(%player,%slot)
{
	if(%player.mechtype == 3)
	{
		if(Gamebase::getenergy(%player) >= 20) 
		{
			player::unmountitem(%player,MechNullGun);
			player::MountItem(%player,MechNullGun,4);
			player::mountItem(%player,Mech1RLauncher,0);
			weapon::onfire(%player);
			//MechMachine2GunImage::onFire(%player,%slot);
			player::mountItem(%player,Mech1RLauncher,4);
			player::mountItem(%player,Mech2RLauncher,0);
			weapon::onfire(%player);
			//MechMachine3GunImage::onFire(%player,%slot);
			weapon::onfire(%player);
			player::mountItem(%player,Mech2RLauncher,5);
			player::useItem(%player,MechNullGun);
			Player::mountitem(%player,MechNullGun,0);
			Gamebase::setEnergy(%player,Gamebase::GetEnergy(%player)-20.0);
		}	
	}
}


function MechRLauncherTriggerImage::onactivate(%player, %imageslot) 
{
	//Player::trigger(%player,$BackpackSlot,false);
	if(Gamebase::getenergy(%player) >= 50) 
	{
		player::unmountitem(%player,MechNullGun);
		player::MountItem(%player,MechNullGun,6);
		player::mountItem(%player,Mech3RLauncher,0);
		weapon::onfire(%player);
		//MechMachine2GunImage::onFire(%player,%slot);
		player::mountItem(%player,Mech3RLauncher,6);
		player::mountItem(%player,Mech4RLauncher,0);
		weapon::onfire(%player);
		//MechMachine3GunImage::onFire(%player,%slot);
		weapon::onfire(%player);
		player::mountItem(%player,Mech4RLauncher,7);
		player::useItem(%player,MechNullGun);
		Player::mountitem(%player,MechNullGun,0);

		Gamebase::setEnergy(%player,Gamebase::GetEnergy(%player)-50.0);
	}
}

function mechRLauncherTriggerImage::ondeactivate(%player,%imageslot)
{
	//Player::trigger(%player,$BackpackSlot,false);
	if(Gamebase::getenergy(%player) >= 50) 
	{
		player::unmountitem(%player,MechNullGun);
		player::MountItem(%player,MechNullGun,6);
		player::mountItem(%player,Mech3RLauncher,0);
		weapon::onfire(%player);
		//MechMachine2GunImage::onFire(%player,%slot);
		player::mountItem(%player,Mech3RLauncher,6);
		player::mountItem(%player,Mech4RLauncher,0);
		weapon::onfire(%player);
		//MechMachine3GunImage::onFire(%player,%slot);
		weapon::onfire(%player);
		player::mountItem(%player,Mech4RLauncher,7);
		player::useItem(%player,MechNullGun);
		Player::mountitem(%player,MechNullGun,0);

		Gamebase::setEnergy(%player,Gamebase::GetEnergy(%player)-50.0);
	}

}
function Mech::addMech2(%this, %type)
{
	player::trigger(0,false);
	player::trigger(1,false);
	player::trigger(2,false);
	player::trigger(3,false);
	player::trigger(4,false);
	player::trigger(5,false);
	player::trigger(6,false);
	player::trigger(7,false);
	
	player::setitemcount(%this,MechMachineGunTrigger,0);
	player::unmountItem(%this,MechNullGun);
	player::unmountItem(%this,MechMachine1Gun);
	player::unmountItem(%this,MechMachine2Gun);
	player::unmountItem(%this,MechMachine3Gun);
	player::unmountItem(%this,MechMachine4Gun);
	player::unmountItem(%this,MechMachineGunTrigger);
	Player::setItemCount(%this,MechArtillary1Gun,0);		
	Player::unmountItem(%this,MechArtillary2Gun);		
	player::setitemcount(%this,MechRLauncherTrigger,0);
	Player::unmountItem(%this,MechNullGun);
	player::unmountItem(%this,Mech1RLauncher);
	player::unmountItem(%this,Mech2RLauncher);
	player::unmountItem(%this,Mech3RLauncher);
	player::unmountItem(%this,Mech4RLauncher);
	player::unmountItem(%this,MechRLauncherTrigger);
		
	player::Setarmor(%this,marmor);
	if(%type ==1)
	{
		client::getOwnedObject(%this).mechType = 1;
		player::setitemcount(%this,MechMachineGunTrigger,1);
		player::mountItem(%this,MechNullGun,0);
		Player::mountItem(%this,MechMachine1Gun,4);		
		Player::mountItem(%this,MechMachine2Gun,5);		
		Player::mountItem(%this,MechMachine3Gun,6);		
		Player::mountItem(%this,MechMachine4Gun,7);
		player::mountItem(%this,MechMachineGunTrigger,1);
	} else if(%type == 2)
	{
		client::getOwnedObject(%this).mechType = 2;
		Player::setItemCount(%this,MechArtillary1Gun,1);		
		Player::mountItem(%this,MechArtillary2Gun,4);		
		player::useItem(%this,MechArtillary1Gun);
	} else if(%type == 3)
	{
		client::getOwnedObject(%this).mechType = 3;
		player::setitemcount(%this,MechRLauncherTrigger,1);
		Player::mountItem(%this,MechNullGun,0);
		player::mountItem(%this,Mech1RLauncher,4);
		player::mountItem(%this,Mech2RLauncher,5);
		player::mountItem(%this,Mech3RLauncher,6);
		player::mountItem(%this,Mech4RLauncher,7);
		player::mountItem(%this,MechRLauncherTrigger,1);
	}	
	
}

function Mech::addMech(%player, %item, %type)
{
        %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
        {
               if (GameBase::getLOSInfo(%player,6))
               {
                        %obj = getObjectType($los::object);

                        if (!CheckForObjects($los::position))
                        {
                                Client::sendMessage(%client,1,"Objects In The Way, Can not deploy.");
                        	return;
                        }
                        
                        if (%obj == "SimTerrain")
                        {
                                if (Vector::dot($los::normal,"0 0 1") > 0.8)
                                {
					%pos = $los::position;
					Mech::spawnMech(%pos,gamebase::getrotation(%player),client::getTeam(%client),%type,%client);
                                	return true;
                                }
                                else
                                        Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
                        }
                        else
                                Client::sendMessage(%client,0,"Can only deploy on terrain.");
                }
                else
                        Client::sendMessage(%client,0,"Deploy position out of range");
        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
                 return false;
}

function Mech::spawnMech(%pos,%rot,%team,%type,%client)
{
	$MCOUNTER++;
	if(%type == 1)
	{
		%typea = "MechGunPack";
		$TeamItemCount[%team @ %typea]++;
		%name = "Mech RAM-X44 #"@ $MCOUNTER;

	} else if(%type == 2)
	{

		%typea = "MechArtillaryPack";
		$TeamItemCount[%team @ %typea]++;
		%name = "Mech RAM-A25 #"@ $MCOUNTER;

	}else if(%type == 3)
	{
		%typea = "MechRocketPack";
		$TeamItemCount[%team @ %typea]++;
		%name = "Mech RAM-R22 #"@ $MCOUNTER;

	}else if(%type == 4)
	{
		%typea = "MechFlamePack";
		$TeamItemCount[%team @ %typea]++;
		%name = "Mech RAM-N12 #"@ $MCOUNTER;

	} else
		%name = "Standard Useless Mech"@ $MCOUNTER;


	%this = AI::GholaSpawn( %Name, marmor, %client, $los::position, %rot);
	%this = AI::getId(%this);
	GameBase::setTeam(%this,%team);
	Client::sendMessage(%client,0,%Name @" Deployed");
	playSound(SoundDoorOpen,%pos);
	$Mech::nameToType[%name] = %typea;
	for(%x = 0;%x<100;%x++)
	{	
		if($Mech::list[%x] == "")
		{
			$Mech::list[%x] = %name;
			break;	
		}
	}
  	AI::setVar( %Name,  iq,  0 );
   	AI::setVar( %Name, pathType, 1);
   	AI::SetVar(%Name, triggerPct, 1.0 );
	//Client::setSkin(%this, $Server::teamSkin[%team]);
	
	if(%type ==1)
	{
		%this.type = MechGunPack;	
		client::getOwnedObject(%this).mechType = 1;
		player::setitemcount(%this,MechMachineGunTrigger,1);
		player::mountItem(%this,MechNullGun,0);
		Player::mountItem(%this,MechMachine1Gun,4);		
		Player::mountItem(%this,MechMachine2Gun,5);		
		Player::mountItem(%this,MechMachine3Gun,6);		
		Player::mountItem(%this,MechMachine4Gun,7);
		player::mountItem(%this,MechMachineGunTrigger,1);
	} else if(%type == 2)
	{
		%this.type = MechArtillaryPack;	
		client::getOwnedObject(%this).mechType = 2;
		Player::setItemCount(%this,MechArtillary1Gun,1);		
		Player::mountItem(%this,MechArtillary2Gun,4);		
		player::useItem(%this,MechArtillary1Gun);
	} else if(%type == 3)
	{
		%this.type = MechRocketPack;	
		client::getOwnedObject(%this).mechType = 3;
		player::setitemcount(%this,MechRLauncherTrigger,1);
		Player::mountItem(%this,MechNullGun,0);
		player::mountItem(%this,Mech1RLauncher,4);
		player::mountItem(%this,Mech2RLauncher,5);
		player::mountItem(%this,Mech3RLauncher,6);
		player::mountItem(%this,Mech4RLauncher,7);
		player::mountItem(%this,MechRLauncherTrigger,1);
	} else if(%type == 4)
	{

		%this.type = MechFlamePack;	
	}
}

function Mech::TakeControl(%player,%mechname)
{
	%ai = AI::getId(%mechname);
echo(%ai);
	if(%ai && %ai != "" && %ai != -1)
	{
		Client::setControlObject(%player, %ai);
		Client::setOwnedObject(%ai, -1);
		Client::setControlObject(%ai, Client::getObserverCamera(%ai));
		%player.Mech = %ai;
		%ai.controller = %player;
	}
}

function Mech::ReturnOwner(%this)
{
	
}

function Mech::RemoveFromList(%name)
{
	for(%x = 0;%x < 100;%x++)
		if($Mech::list[%x] == %name)
		{
			$Mech::list[%x] = "";
			return;
		}
}

function Mech::isMech(%player)
{
	if(Player::getArmor(%player) == marmor)
		return true;
	else
		return false;
}



function dolock(%target, %shooterId)
{
//echo("Dolock");
	%client = Player::getClient(%shooterId);
	%player = Client::getControlObject(%client);
	%targetType = GameBase::getDataName(%target);
//echo(%item.classname);
	if (%item.className == Vehicle || %item.className == Turret) {
	   lockhit(%shooterId,%target);
	} else {
	   return false;
	}
}

function lockhit(%shooterId,%target)
{
echo("lockhit");
		%client = Player::getClient(%shooterId);
		%player = Client::getControlObject(%client);
		%targetType = GameBase::getDataName(%target);
		%dist=vector::getdistance(gamebase::getposition(%player), gamebase::getposition(%target));
		%mult=6;
		if (%targettype == Apache)
		      %mult*=0.7;
		if (%targettype == BlackHawk)		   
		     %mult*=0.4;	   
		if (%targettype == Hind)
		     %mult*=0.5;
		%addon=(100/%dist)*%mult;
		%target.heat[%client]=%target.heat[%client]+%addon;
		if(%target.heat[%client]>=100)
			%target.heat[%client]=100;
	  	bottomprint(%shooterId, "<f0><jc>Target Lock at "@%target.heat[%client]@"%", 1);
		if(%target.beinglocked[%client]==0)
		  {
		   %target.heat[%client]=%target.heat[%client]+2;
		   %target.beinglocked[%client]=1;
		   lowerlock(%target, %client);
		  }
		if(%target.heat[%client]>=100)
		  {
		bottomprint(%shooterId, "<f0><jc>Target LOCKED!", 1);
		Client::sendMessage(Player::getClient(%player), 0, "~wError_Message.wav");
		%target.heat[%client]=0;
		%target.beinglocked[%client]=0;
		%trans = GameBase::getMuzzleTransform(%player);
		%projectile = Projectile::spawnProjectile("MechMissile", %trans, %player, Item::getVelocity(%player), %target);
		//Player::decItemCount(%client, StingerAmmo);
		warningMessage(GameBase::getControlClient(%target), %projectile);
		$reloadingstinger[%shooterId]=1;
		schedule("$reloadingstinger["@%shooterId@"]=0;", 4.0 , %shooterId);
		}
}

function lowerlock(%target, %client)
{
   %mult=0.3;
   if (%targettype == Apache)
	%mult=%mult/0.7;
   if (%targettype == BlackHawk)		   
	%mult=%mult/0.4;	   
   if (%targettype == Hind)
	%mult=%mult/0.5;
   %target.heat[%client]=%target.heat[%client]-%mult;
   if(%target.heat[%client]<=0)
	{
	%target.heat[%client]=0;
	%target.beinglocked[%client]=0;
	return;
	}
   schedule("lowerlock("@%target@","@%client@");",0.1);
}
