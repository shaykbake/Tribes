DUNE Server Source


Here are some simple tips for instalation.
-Place these files in a folder named tribes/DUNE/
-If that folder already exists, then just put it in with whatever is already there. It will do just fine.
-Let it run once and shut down normally before setting up your particular server's settings.

DISCLAIMER
First off, this mod and the code contained within (that which originally from Tribes, which has its own disclaimers) is my intellectual property. Any attempt to take credit for my property is illegal. If I catch wind of it, you will be dealt with in a manner that justifies the U.S. and International Copyright Laws. If you wish to use all or parts of my code, you may do so without contacting me under two conditions: 1) You provide credit where credit is due. That means you provide credit to me the author of the DUNE code, and 2) If I ask you remove my code from your mod for any reason, or that you remove the server running DUNE or any mod that is obviously based off of it and has not been changed 40% or more for any reasons, you must comply. 
Credit to the authors of Starsiege:Tribes should also be given, but I'm pretty sure no one is going to mistake your mod or mine as being based off not the tribes engine, but instead off of one you or I wrote completely our selves that happened to be perfectly compatible with Tribes. 
I reserve the right to change this disclaimer at any time without notice, to which changes you will still be accountable. If such changes occur, and you disagree with them, you have the right to delete/remove/dispose of all files, documents, papers, and/or other recordings that contain any of the intellectual property in question. If you waver this right, you agree to uphold and agree to the changes. 
By downloading this code, you understand and agree with the above terms. 

Running DUNE
Running DUNE isn't really like running a normal tribes server. It actualy is a tad more work for you the admin. There are a few things to watch out for. 
---Team work is a must. If there is no teamwork, the game just kinda stinks, and your team is going to get their ass kicked. I would advise admin enforced teamwork. 
---Make sure players know and understand that Team Energy IS enabled in DUNE. There are very few mods where this is true, so most players won't even know what it is. 
---Do *not* change the spawn time. The script requires it be set at a base 10. From there it will dynamically changed based on if the player does something wrong. Eventually it will decay back to 10. Why so high? Disruptive behavior requires punishment. Having a base of 10 will encourage people to stay ALIVE. It encourages them to be more frugil with their player's lives, because it makes them no longer free: when they die, they have to pay in time that they are not playing. 
---As a representative of the DUNE community of Houses/Clans, I request that no one, besides those who are officially hosting servers for their House/Clan, name their server after the different team names. Doing so will just confuse and upset people, which isn't needed. 
---If you plan on making changes to the Mod, keep these things in mind. The point of the mod is to recreate SQUAD level combat based in the DUNE universe as layed out by Frank Herbert in *his* novels. Adding deployable nukes, stoneburners, or other such non-personalized combat items would be silly given the point of the mod. Trust me; I know. I originally intended to put them in! Also, if you're going to make changes.. please keep it DUNE. I.e. READ THE BOOKS before you do anything. Additionally... if you make changes, keep in mind the ballance that's currently in the mod. Things are ballanced in a paradoxial fashion. Yes, some armors are better then others. This is as it was described by Herbert for the most part. From there, there has been some nonthreatening tweeking to keep the game enjoyable. This ballance has been tested out for about two years. If you make a change that upsets this ballance, things are going to suck. But.. if you do make changes, be sure, for everyone's sake, to let people know, somewhere, somehow, as they join the server that changes have been made. If you make SIGNIFICANT changes, be sure to change the mod name. 

Installing DUNE
As I said, this is basically the source code for the mod. It is not a self extracting file, and it isn't packaged up all that nicely for you to just drop everything in your tribes folder and run up the mod. In order to run the mod, you will unfortunately have to know how to run them already. All I basically did, was pick up everything in my "DUNE" folder having to do with the server side, and drop it into a *.zip file. Its yours to deal with from there. If you really can't get it running, and really want to, feel free to email me and I will see if I can help you a bit more. 
**Note: This zip file does NOT contain any of the maps for the mod. You will have to download them and put them in yourself. 


DEDICATED SERVER OPTIONS
These are options that you can use (type them into the shell) when on a dedicated server. They should also work if your using a listen server.
-$NoTalk = <bool>; Setting notalk to true will mute all use of global chat, and global commands. Actually does increase teamwork, and shuts the annoying spammers, and flamewars off.
-$NoRepeat = <bool>; Setting this to true will give anyone trying to repeat a message on global a nice little message instead.
-$NoLoudTalk = <bool>; Setting this to true will mute all use of sound playing in global messages, giving them a message instead of everyone else.
-$STEAMTALK = <bool>; Disables the teamchat echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-$STALK = <bool>;  Disables the globalchat echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-$SKILL = <bool>;   Disables the death/kill echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-$SSPAWN = <bool>;   Disables the spawn echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-$STKILL = <bool>;  Disables the teamkill echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-$STHROW = <bool>;   Disables the "throw"(mines/grenades) echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-$SDEPLOY = <bool>;   Disables the deploy echo on the shell. Does NOT effect it in game. Makes the shell cleaner so you can concentrate on bugs ect.
-SAllOff(); Turns the 7 "S" options all off.
-SAllOn(); Turns the 7 "S" options all on.
-SDefault(); Resets the 7 "S" options to their defaults.
-listplayers();  Will display a list of all the players, their ID number, their IP, their team, their TKs, and their score.
-ban( <clientID>, "<message(optional)>" ); Should add the specified client to the normal tribes ban list (and save the list incase you dont exit normally), and kick them. If you give a message, that message will be displayed when they are booted.
-net::kick( <clientID>, "<message(optional)>" ); Should kick the specified client and display the message if given.
-chat( "<message>" ); Will display a message in the chatbox to all users.
-admintalk( "<message>" ); Will display a message at the bottom of everyone's screen, and let them know its from the admin.
-ResetTK( <clientID(optional)> ); If a client is specified, it will reset their TK count. If one isnt, then it resets everyone's TKs.
-ClearScreen(); Clears the shell screen.
-Server::loadmission(<name of mission>); Loads the specified mission.

KNOWN BUGS
-Worms still act kinda funny. Additionally there seems to be an incrementing lag problem related to them. Problem is... ever time I go to fix them, they don't happen.
-Beacons still appear to block doors under some conditions.

If you fix, or find a way to fix any of these bugs, please email me so we can set up to get that new fixed code in the mod, so i can release an update. You will be added to the contributer's list if you do so.

Make sure to put the maps in tribes/DUNE/Missions/ after you install this source.


Made by Jesus 08/10/04

Questions can be sent to Deathknight@hush.com or posted on the forum at www.jmods.bravepages.com