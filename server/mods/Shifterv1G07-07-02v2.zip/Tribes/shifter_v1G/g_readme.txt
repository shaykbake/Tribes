For Dedicated Servers
--------------------------------
Just unzip using folder names into the tribes directory
double click "StartShifter.bat"


For Un-Dedicated servers
--------------------------------
Just unzip using folder names into the tribes directory
double click "ShifterND.bat"