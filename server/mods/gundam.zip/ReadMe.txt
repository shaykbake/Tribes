((((((((((((((((((((((((GundamWvx1 by ZechsMerqise)))))))))))))))))))

[=====================================================================]
]    1: About GundamWvx1                                                [
[    2: Special thanks                                                ]
]    3: Installation                                                  [
[    4: Futur projects for the mod                                    ]
]=====================================================================[

~~~~~~~~~~~~~~~~~~~~~About GundamWB~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~                                                                    ~
~   I'm a big fan of the Gundam Wing annimes, so i desided to make   ~
~   some Gundam Wing mods for Tribes. GundamWvx1 mod is more like    ~
~   my old GundamW, but it has a lot more armors and weapons.        ~
~   GundamWvx1 may be updated later, ceep an eye on the site :)      ~
~                                                                    ~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 ___________________________________________________________________
/\                  Special thanks                                 /\
| \                 ------- ------                                / |
|  \  Thanks to Julni for giving me the idea for the new look    /  |
|  /  of the swords. Thanks to the guys who helped me test the   \  | 
| /   BETA of the mods. And thanks to all guys playing my mods :) \ |
\/_________________________________________________________________\/ 


>>>>>>>>>>>>>>>>>>>>Installation<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
>>>>>><<<<<<                                                                     <
>dedicated:< Unzip the GundamWvx1 folder in your c:\dynamix/tribes folder.       <
>>>>>><<<<<<                                                                     <    
>            Click on GundamWvx1 dedicated server.                               <
>>>>>>>><<<<<<<<-----------------------------------------------------------------<
>not dedicated:< Unzip the GundamWvx1 folder in your c:\dynamix/tribes folder.   <
>>>>>>>><<<<<<<<                                                                 <
>                Click on GundamWvx1 server.                                     <
>--------------------------------------------------------------------------------<
> I sugjest that you place the GundamWvx1 server and dedicated server on         <
> your descktop.                                                                 <
>                                                                                <
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 


**********************Future projects for the mod*******************************************************************************
*                                                                                                                              *
*  {I'm looking for good mappers and modellers. If you can do one of these. E-mail me at bloody_demon@hotmail.com and tell me.}*                                       
*                                                                                                                              *
*  +=+I'm also working on a map pack for the mods+=+                                                                           *
*                                                                                                                              *
*                                                                                                                              *
********************************************************************************************************************************

If you see any bugs in the mod. Please make a new post in the furum at:

                                http://tribesgundamw.cjb.net

Or e-mail me at:

                               bloody_demon@hotmail.com

And i'l try to fix them out.

