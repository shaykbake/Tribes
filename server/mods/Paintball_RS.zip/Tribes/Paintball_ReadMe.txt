Instructions:
1.Extract this mod to your tribes folder.
2.Go to your C:/Dynamix/Tribes/Config and open up Paintball.cs with notemap.
(this is where you change your server stuff.
3.Once your done with  the paintball.cs run the Paintball-Dedicated to start your server.
4.Have fun!

NEED HELP?
Email me. |K0RN|
rdheim99@msn.com
aim: PiSked
