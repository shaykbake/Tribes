//                              Custom Server Settings:
//===========================================================================================
// Allow Custom Skins.
$FoundationII::customSkins = true;

// Allow Voting Admin.
$FoundationII::VoteAdmin = true;

// Allow Voting To Kick.
$FoundationII::VoteKick = true;

// Kick/Ban Times:
$FoundationII::KickTime = 180;
$FoundationII::BanTime = 1800;

// Cheats:(admins only cheats)
$FoundationII::CheatsForAdmins = true;

// SuperAdmin Passwords:
$FoundationII::Super[0] = "";
$FoundationII::Super[1] = "";
$FoundationII::Super[2] = "";
$FoundationII::Super[3] = "";
$FoundationII::Super[4] = "";
$FoundationII::Super[5] = "";


// PublicAdmin Passwords:
$FoundationII::Public[0] = "";
$FoundationII::Public[1] = "";
$FoundationII::Public[2] = "";
$FoundationII::Public[3] = "";
$FoundationII::Public[4] = "";
$FoundationII::Public[5] = "";

//Number of tries a player has to attempt admin passwords -1 ie 2 = 3 tries
$StrikeLimit = 2;

// Allow Public Admins To Kick.
$FoundationII::PublicKick = true;

// Allow Public Admins To Change Mission.
$FoundationII::PublicChngMission = true;

// Allow Public Admins To View\Change Server Options.
$FoundationII::PublicSvrOpts = false;

// Allow Public Admins To Enable\Disable Weapon Modules.
$FoundationII::PublicEDWepMode = true;
//===========================================================================================

//                             General Server Settings:
//===========================================================================================
// Server Name, Shown In The Servers List.
$Server::HostName = "Foundation II Server";

// Port Of Server, Usually 28001.
$Server::Port = "28001";

// Allow People To Connect To Your Server(true = yes | false = no).
$Server::HostPublicGame = true;

// Maximum Allowed Players.
$Server::MaxPlayers = "8";

// Leave Blank Unless You Want People To Enter A Password To Join Your Server.
$Server::Password = "";

// Set This To The Mission You Would Like The Server To Start On(Check Spelling).
$pref::LastMission = "Raindance";

// When You Highlight A Server, Then Click Info..You'll See This Screen.
$Server::Info = "Foundation II server setup\nAdmin: Unknown\nEmail: Unknown";

// Message To Display When You First Join The Server(After The Loading Screen).
$Server::JoinMOTD = "<jc><f1>Email mod suggestions to TheDrunk007@yahoo.com";

// Port for telnet connections.
$TelnetPort = "";

// Password for telnet connections.
$TelnetPassword = "";

// Packet rate for client connections(recommended for cable)
$pref::PacketRate = 30;

// Packet size for client connections(recommended for cable)
$pref::PacketSize = 500;

// Minimum Allowed Votes To Succeed.
$Server::MinVotes = "2";

// ??
$Server::MinVotesPct = "0.5";

// Minimum Allowed Time To Vote.
$Server::MinVoteTime = "45";

// This Is The Delay Time After You Are Killed B4 You Can Spawn.
$Server::respawnTime = "2";

// Team Damage: (1 = on | 0 = off).
$Server::TeamDamageScale = "0";

// Mission time limit in minutes.
$Server::TimeLimit       = 30;

// Warmup Time B4 Match Starts.
$Server::WarmupTime      = 15;

// Start In Tournament Mode(true = yes | false = no).
$Server::TourneyMode = "false";

// ??
$Server::VoteAdminWinMargin = "0.66";

// ??
$Server::VoteFailTime = "30";

// ??
$Server::VoteWinMargin = "0.55";

// Overall Time For Vote.
$Server::VotingTime = "20";

// Time B4 Match Starts On Each New Mission.
$Server::warmupTime = "20";

// Auto-Set Teams When People Connect Or Let Them Pick(true = auto-assign | false = don't).
$Server::AutoAssignTeams = "true";


// Team Names & Team Skins:
$Server::teamName0 = "Blue";
$Server::teamSkin0 = "blue";

$Server::teamName1 = "Purple";
$Server::teamSkin1 = "purple";

$Server::teamName2 = "Base";
$Server::teamSkin2 = "base";

$Server::teamName3 = "Green";
$Server::teamSkin3 = "green";

$Server::teamName4 = "Blood Eagle";
$Server::teamSkin4 = "beagle";

$Server::teamName5 = "Diamond Sword";
$Server::teamSkin5 = "dsword";

$Server::teamName6 = "Starwolf";
$Server::teamSkin6 = "swolf";

$Server::teamName7 = "Children of the Phoenix";
$Server::teamSkin7 = "cphoenix";
