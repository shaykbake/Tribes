//------------------------------------------------------------------------
// Comments by Nicodemus
//------------------------------------------------------------------------
// Use this file to register your own custom prefabs/buildings.
//------------------------------------------------------------------------
// Example Code:
// MissionRegDis(NewDarkEvil, advpill);
//
// Key:
// MissionRegDis(NewHeading, PrefabName);
//
// MissionRegDis = The command to register the new prefab.building.
// NewHeading	 = The heading under which the item will appear in the editor.
// PrefabName	 = This bit MUST contain the name of the prefab/building. If it
//		   isn't correctly typed, the editor can't use it.
//------------------------------------------------------------------------
