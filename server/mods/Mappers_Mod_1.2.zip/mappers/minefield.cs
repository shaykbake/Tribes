//--- export object begin ---//
instant SimGroup "Minefield" {
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "0 0 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "2.5 4.3 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "5 0 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "2.5 -4.3 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "-2.5 4.3 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "-2.5 -4.3 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
	instant Mine "AntipersonelMine1" {
		dataBlock = "AntipersonelMine";
		name = "";
		position = "-5 0 10";
		rotation = "0 0 0";
		destroyable = "True";
		deleteOnDestroy = "True";
		rotates = "False";
		collideable = "True";
		count = "0";
	};
};
//--- export object end ---//
