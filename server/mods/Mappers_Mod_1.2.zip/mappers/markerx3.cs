//--- export object begin ---//
instant Marker "Marker1" {
	dataBlock = "PathMarker";
	name = "";
	position = "0 0 0";
	rotation = "0 0 0";
};
instant Marker "Marker1" {
	dataBlock = "PathMarker";
	name = "";
	position = "0 0 0";
	rotation = "0 0 0";
};
instant Marker "Marker1" {
	dataBlock = "PathMarker";
	name = "";
	position = "0 0 0";
	rotation = "0 0 0";
};
//--- export object end ---//
