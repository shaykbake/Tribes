//---------------------------------------
// Written By Nicodemus & Dewy (MiniMod)
//---------------------------------------

function Register::SimVol(%string)
{
	if(%string == "")
	{
		echo("Register::SimVol... You must enter the File-Mask in order for me to load it.");
	}
	if(%string != "")
	{
		deleteVariables("$mmLoad*");
		%i = 0;
		%file = File::findFirst(%string);
		while(%file != "")
		{
			%unique = true;
			for(%a = 0; (%a < %i) && %unique; %a++)
			{
				if($mmLoad[%a] == %file)
				%unique = false;
			}
			if(%unique)
			{
				$mmLoad[%i] = %file;
				%i++;
			}
			%file = File::findNext(%string);
		}
	for(%a = 0; %a < %i; %a++)
	newObject("New"@$mmLoad[%a], SimVolume, $mmLoad[%a]);
	$mmLoadSize = %i;
	}
}

function PackList::Load(%string)
{
	if(%string == "")
	{
		echo("PackList::Load... You must enter the File-Mask in order for me to load it.");
	}
	if(%string != "")
	{
		deleteVariables("$mmLoad*");
		%i = 0;
		%file = File::findFirst(%string);
		while(%file != "")
		{
			%unique = true;
			for(%a = 0; (%a < %i) && %unique; %a++)
			{
				if($mmLoad[%a] == %file)
				%unique = false;
			}
			if(%unique)
			{
				$mmLoad[%i] = %file;
				%i++;
			}
			%file = File::findNext(%string);
		}
		for(%a = 0; %a < %i; %a++)
		exec($mmLoad[%a]);
		$mmLoadSize = %i;
	}
}

//---------------------------------------
Register::SimVol("textures\\*.vol");
Register::SimVol("prefabs\\*.vol");
Register::SimVol("user\\*.vol");