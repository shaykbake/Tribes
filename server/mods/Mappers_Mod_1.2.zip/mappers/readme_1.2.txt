****** This mod designed for & tested on Tribes v1.10 ******
			16/02/2000
================================================================
Title                   : Mappers Mod Version 1.2
Author                  : Owen Epps ([TEK] Nicodemus)
Email Address           : zhandri@lineone.net
Description             : A minor modification designed to facilitate
			  easier integration of new prefabricated
			  buildings & items within the Tribes map editor.
================================================================

Editor(s) used          : Textpad v4.0, Volumer v0.20b, VisualVT v1.0,
			  Windows Notepad & Tribes (for testing).

-=- Installation -=-

	 Simply unzip all the files into your */Tribes directory (keeping
	the directory structure intact). [IMPORTANT: If upgrading from
	v1.0 remove all files (except registeruserobject.cs (assuming
	you've edited it) and any stuff in the 'user' directory) prior
	to installation]

	 Next, make a shortcut of Tribes.exe, and set its properties as 
	follows:

	*\Tribes\tribes.exe -mod mappers (* = The drive you installed
	Tribes to).

	To run the mod simply double-click on the new shortcut.

-=- Included Files -=-

	readme_1.2.txt		- Readme file (you're reading it).
	instructions_1.2.txt	- Instructions for using the mod'.
	credits_1.2.txt		- List of people that have contributed to
				  the Mappers Mod'.
	prefab_guide_1.2.txt	- A set of guidelines for prefab makers to
				  make their prefabs compatible with the
				  Mappers Mod'.
	registeruserobjects.cs	- Use this file to register your own
				  custom prefabs with the mod.
	staticshape.cs		- This file contains a lot of new
				  staticshape data. It is required that you
				  distribute this with your maps if you
				  use certain new objects in the editor.
	All the other .cs files	- The Mods' new script & macro files.


-=- Copyright / Permissions -=-

	Don't redistribute this for profit or any other financial gain.
	Don't put this on a CD-ROM without my permission. These files may
	be freely distributed provided all files remain together and
	intact. Level authors may use this mod to make their own maps.

-=- Disclaimer -=-

	There shouldn't be any bugs in this mod, but if you are at all
	concerned then don't install it. I cannot be held responsible
	for any loss of data or other damage these files cause to your
	system. In other words, use at your own risk.

-=- Other Info -=-

	Please send any comments, suggestions, bug reports, or requests
	to zhandri@lineone.net,	and I'll try and send you a reply within
	a couple of days. You can check out my clan's homepage at
	http://website.lineone.net/~tribes-eternal-knights/ .

			----------------------

    Facts are chains that bind perception and fetter truth.
    For a man can remake the world if he has no facts to cloud his mind.


