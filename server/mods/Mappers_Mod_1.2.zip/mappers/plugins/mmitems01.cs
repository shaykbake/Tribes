//----------------------
// Written By Nicodemus
//----------------------

MissionRegObject( Stations, "*Deployable Inventory", MissionCreateObject, DeployableInvPack, StaticShape, DeployableInvPack );
MissionRegObject( Stations, "*Deployable Ammo", MissionCreateObject, DeployableAmmoPack, StaticShape, DeployableAmmoPack );

MissionRegObject( Turrets, "*Camera", MissionCreateObject, CameraTurret, Turret, CameraTurret );
MissionRegObject( Turrets, "*Deployable Turret", MissionCreateObject, DeployableTurret, Turret, DeployableTurret );

MissionRegItem( Packs, "*Deployable Inventory Pack", DeployableInvPack, 1);
MissionRegItem( Packs, "*Deployable Ammo Pack", DeployableAmmoPack, 1);

MissionRegObject( Projectiles, "^Flame", MissionCreateObject, Flame, StaticShape, Flame );
MissionRegObject( Projectiles, "^Tracer Bullet", MissionCreateObject, TracerBullet, StaticShape, TracerBullet );
MissionRegObject( Projectiles, "^Disc", MissionCreateObject, Disc, StaticShape, Disc );
MissionRegObject( Projectiles, "^Missle", MissionCreateObject, Missle, StaticShape, Missle );
MissionRegObject( Projectiles, "^Grenade", MissionCreateObject, GrenadeFire, StaticShape, GrenadeFire );
MissionRegObject( Projectiles, "^Mortar", MissionCreateObject, MortarFire, StaticShape, MortarFire );

MissionRegObject( PoweredDown, "*PwrdElectricBeam", MissionCreateObject, PwrdElectrBeam, StaticShape, PoweredElectricalBeam );
MissionRegObject( PoweredDown, "^PwrdBigElectricBeam", MissionCreateObject, PwrdElectrBeamBig, StaticShape, PoweredElectricalBeamBig );
MissionRegObject( PoweredDown, "^PwrdShield", MissionCreateObject, PoweredShield1, StaticShape, PoweredShield1 );
MissionRegObject( PoweredDown, "^PwrdMediumShield", MissionCreateObject, PoweredShieldMedium1, StaticShape, PoweredShieldMedium1 );
MissionRegObject( PoweredDown, "^PwrdLargeShield", MissionCreateObject, PoweredShieldLarge1, StaticShape, PoweredShieldLarge1 );
MissionRegObject( PoweredDown, "^PwrdFlame", MissionCreateObject, PoweredFlame, StaticShape, PoweredFlame );
MissionRegObject( PoweredDown, "^PwrdTracer", MissionCreateObject, PoweredTracerBullet, StaticShape, PoweredTracerBullet );
MissionRegObject( PoweredDown, "^PwrdDisc", MissionCreateObject, PoweredDisc, StaticShape, PoweredDisc );
MissionRegObject( PoweredDown, "^PwrdMissle", MissionCreateObject, PoweredMissle, StaticShape, PoweredMissle );
MissionRegObject( PoweredDown, "^PwrdGrenade", MissionCreateObject, PoweredGrenadeFire, StaticShape, PoweredGrenadeFire );
MissionRegObject( PoweredDown, "^PwrdMortar", MissionCreateObject, PoweredMortarFire, StaticShape, PoweredMortarFire );
MissionRegObject( PoweredDown, "^PwrdFlyer", MissionCreateObject, PwrdStaticFlyer, StaticShape, PwrdStaticFlyer );
MissionRegObject( PoweredDown, "^PwrdLAPC", MissionCreateObject, PwrdStaticLAPC, StaticShape, PwrdStaticLAPC );
MissionRegObject( PoweredDown, "^PwrdHAPC", MissionCreateObject, PwrdStaticHAPC, StaticShape, PwrdStaticHAPC );

MissionRegObject( PoweredUp, "^PwrdUpElectricBeam", MissionCreateObject, PwrdUpElectrBeam, StaticShape, PoweredUpElectricalBeam );
MissionRegObject( PoweredUp, "^PwrdUpBigElectricBeam", MissionCreateObject, PwrdUpElectrBeamBig, StaticShape, PoweredUpElectricalBeamBig );
MissionRegObject( PoweredUp, "^PwrdUpShield", MissionCreateObject, PoweredUpShield1, StaticShape, PoweredUpShield1 );
MissionRegObject( PoweredUp, "^PwrdUpMediumShield", MissionCreateObject, PoweredUpShieldMedium1, StaticShape, PoweredUpShieldMedium1 );
MissionRegObject( PoweredUp, "^PwrdUpLargeShield", MissionCreateObject, PoweredUpShieldLarge1, StaticShape, PoweredUpShieldLarge1 );
MissionRegObject( PoweredUp, "^PwrdUpFlame", MissionCreateObject, PoweredUpFlame, StaticShape, PoweredUpFlame );
MissionRegObject( PoweredUp, "^PwrdUpTracer", MissionCreateObject, PoweredUpTracerBullet, StaticShape, PoweredUpTracerBullet );
MissionRegObject( PoweredUp, "^PwrdUpDisc", MissionCreateObject, PoweredUpDisc, StaticShape, PoweredUpDisc );
MissionRegObject( PoweredUp, "^PwrdUpMissle", MissionCreateObject, PoweredUpMissle, StaticShape, PoweredUpMissle );
MissionRegObject( PoweredUp, "^PwrdUpGrenade", MissionCreateObject, PoweredUpGrenadeFire, StaticShape, PoweredUpGrenadeFire );
MissionRegObject( PoweredUp, "^PwrdUpMortar", MissionCreateObject, PoweredUpMortarFire, StaticShape, PoweredUpMortarFire );
MissionRegObject( PoweredUp, "^PwrdUpFlyer", MissionCreateObject, PwrdUpStaticFlyer, StaticShape, PwrdUpStaticFlyer );
MissionRegObject( PoweredUp, "^PwrdUpLAPC", MissionCreateObject, PwrdUpStaticLAPC, StaticShape, PwrdUpStaticLAPC );
MissionRegObject( PoweredUp, "^PwrdUpHAPC", MissionCreateObject, PwrdUpStaticHAPC, StaticShape, PwrdUpStaticHAPC );

MissionRegObject( ShieldShapes, "^Shield", MissionCreateObject, Shield1, StaticShape, Shield1 );
MissionRegObject( ShieldShapes, "^Shield Medium", MissionCreateObject, ShieldMedium1, StaticShape, ShieldMedium1 );
MissionRegObject( ShieldShapes, "^Shield Large", MissionCreateObject, ShieldLarge1, StaticShape, ShieldLarge1 );

MissionRegObject( Misc, "*Mine", MissionCreateObject, AntipersonelMine, Mine, AntipersonelMine );
MissionRegObject( Misc, "*Minefield", ME::PasteFile, "minefield.cs" );

MissionRegObject( CrashedVehicles, "^CrashedScout", MissionCreateObject, StaticFlyer, StaticShape, StaticFlyer );
MissionRegObject( CrashedVehicles, "^CrashedLAPC", MissionCreateObject, StaticLAPC, StaticShape, StaticLAPC );
MissionRegObject( CrashedVehicles, "^CrashedHAPC", MissionCreateObject, StaticHAPC, StaticShape, StaticHAPC );

MissionRegObject( SpringPads, "^Light Springpad", MissionCreateObject, LightSpringPad, StaticShape, LightSpringPad );
MissionRegObject( SpringPads, "^Standard Springpad", MissionCreateObject, SpringPad, StaticShape, SpringPad );
MissionRegObject( SpringPads, "^Powerful Springpad", MissionCreateObject, MegaSpringPad, StaticShape, MegaSpringPad );

// new elevator macros
MissionRegObject(StpElevMacros, StpElev_4x4, ME::PasteFile, "StpElev_4x4.cs");
MissionRegObject(StpElevMacros, StpElev_4x5, ME::PasteFile, "StpElev_4x5.cs");
MissionRegObject(StpElevMacros, StpElev_5x5, ME::PasteFile, "StpElev_5x5.cs");
MissionRegObject(StpElevMacros, StpElev_6x4, ME::PasteFile, "StpElev_6x4.cs");
MissionRegObject(StpElevMacros, StpElev_6x4t, ME::PasteFile, "StpElev_6x4t.cs");
MissionRegObject(StpElevMacros, StpElev_6x5, ME::PasteFile, "StpElev_6x5.cs");
MissionRegObject(StpElevMacros, StpElev_6x6, ME::PasteFile, "StpElev_6x6.cs");
MissionRegObject(StpElevMacros, StpElev_6x6octa, ME::PasteFile, "StpElev_6x6octa.cs");
MissionRegObject(StpElevMacros, StpElev_6x6t, ME::PasteFile, "StpElev_6x6t.cs");
MissionRegObject(StpElevMacros, StpElev_8x4, ME::PasteFile, "StpElev_8x4.cs");
MissionRegObject(StpElevMacros, StpElev_8x6, ME::PasteFile, "StpElev_8x6.cs");
MissionRegObject(StpElevMacros, StpElev_8x8, ME::PasteFile, "StpElev_8x8.cs");
MissionRegObject(StpElevMacros, StpElev_9x9, ME::PasteFile, "StpElev_9x9.cs");
MissionRegObject(StpElevMacros, StpElev_16x16, ME::PasteFile, "StpElev_16x16.cs");
MissionRegObject(StpElevMacros, markerx3, ME::PasteFile, "markerx3");