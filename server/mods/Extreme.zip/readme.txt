                       Orion Mod
                          by
                      Jason Avina

--------------------------------------------------------------
	             INSTALLATION
--------------------------------------------------------------

Just put the extreme folder and extreme.bat into your Tribes 
directory.  Then run the extreme.bat file to start the mod. 

--------------------------------------------------------------
			CHANGES
--------------------------------------------------------------

Five New Mission Types - This includes Tribes Tag, Arena, Flag
Hunter, Team Deathmatch and Chase the Rabbit.

Spawning - You now spawn with just the disc launcher and a repair kit.

Vehicles - Heavy and Medium Armors can now pilot the APCs.

Grenade Launcher - No grenade launcher for light armors.  This
makes the medium more attractive for base assaults, so maybe we'll 
actually someone using it in the future.

Scoring - You gain one point for returning your flag, you lose 
a point for dropping the flag within 100 meters of the enemies'
flagstand and capturing a flag is worth ten points, so make sure 
you plan your attack wisely. 

Mines - Mines have built-in sensors so they won't explode for your
teammates.

Lessened Skiing - I reduced the Jump Impulse for all armors to
help reduce skiing speeds.  This was very effective for the heavy
armor, so we might see less lone wolf heavy offense.  As a side 
note to all you skiers out there...heavy offense is what the 
APCs are for.

  Forgive me if I've missed something.  Have fun, enjoy my 
patch, and please e-mail me with your thoughts and suggestions.

E-mail = avina@henry-net.com
                                  Thanx,  Jason Avina

--------------------------------------------------------------
		      SPECIAL THANX
--------------------------------------------------------------

I would like to thank all the mods which I took the ideas from,
this includes Renegades, Shifter, Ideal and Balance of Power.  
Anyone I left out, please forgive me and e-mail me if you would
like your deserved credit.