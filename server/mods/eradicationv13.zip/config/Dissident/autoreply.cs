Event::Attach (eventClientMessage, autoReply, %client, %msg);

function autoReply(%client, %msg)
{
  $myClientId = %client;
  //start repair reply code 
  if(String::findSubStr(%msg, "Being repaired by") != -1)
    {
     %teamMateNameStartPos = 18 + String::findSubStr(%msg, "Being repaired by"); 
     for(%tempCount=0; String::getSubStr(%msg, %i, 1) != ""; %i++) %totalMsgLength++; 
     %teamMateThankName = String::getSubStr(%msg, %teamMateNameStartPos, %totalMsgLength-%teamMateNameStartPos);
     say(1, "Thanks, " @ %teamMateThankName); 
     localMessage("thanks"); 
    } 
  
  //start flag reply code
  if(String::findSubStr(%msg, "flag") != -1)
    {
      if(String::findSubStr(%msg, "You took the") != -1)
      {say(1, "I've got their flag! Give me some cover fire!~whaveflg");
       schedule("messageAndAnimate(5,\"\");", 0.5); }

      if(String::findSubStr(%msg, "Your team has the") != -1)
        {
          if(getWord($previousMsg, 0) !="You")
            {
              %flagTakerName=getWord($previousMsg, 0);
              say(1, "Give " @ %flagTakerName @ " some cover fire!~wcheer1");
            }
        }

      if(String::findSubStr(%msg, "You captured the") != -1)
        {
          //gets the length of the entire message.
          for(%tempCount = 0; String::getSubStr(%msg, %tempCount,1) !=""; %tempCount++) %totalMsgLength++;
          //gets the start position of the team name
          %teamNameStartPos = 17 + String::FindSubStr(%msg, "You captured the");
          //gets the length of message after team name
          for(%tempCount = String::FindSubStr(%msg,"flag"); String::getSubStr(%msg, %tempCount, 1) !=""; %tempCount++) %endMsgLength++;
          //parse team name from message
          %oppTeamName=String::getSubStr(%msg, %teamNameStartPos, %totalMsgLength - %teamNameStartPos - %endMsgLength );
          //taunt the enemy team
          say(0, "Another "@ %oppTeamName @"flag for my collection!~wcheer2");
          schedule("messageAndAnimate(6,\"\");", 0.8);
        }

      if(String::findSubStr(%msg, "Your team's flag has been taken.") != -1) 
        { 
          %flagTakerName=getWord($previousMsg, 0);
          if(%flagTakerName != "You") 
            {say(1, "Someone kick " @ %flagTakerName @ "'s ass!~wflgtkm2"); }
        } 

      if(String::findSubStr(%msg, "Your flag was returned to base.") != -1)
        {
          %flagRetrieverName=getWord($previousMsg, 0);
          if(%flagRetrieverName !="You")
            {say(1, "Thanks " @ %flagRetrieverName @"!~wthanks");}
        }

      if(String::findSubStr(%msg, "Your team's flag was captured.") != -1) 
        { say(1, "Protect our flag at the base!~wcolor6"); } 
    }

  //start repairing announce code
  if(String::findSubStr(%msg, "Repairing") != -1)
    {localMessage("coverme");} 

  //store the current message for later parsing
  $previousMsg=%msg;
  $currentCID=%client;
}
