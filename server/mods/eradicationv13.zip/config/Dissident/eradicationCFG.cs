//-----------------------------------------------
// This file is critical for the proper use of the
// Eradication mod. This script defines the throw
// function used to throw the mine types in the mod
// and binds the appropriate keys. 
// edit the keys appropriately to your configuration.
//-----------------------------------------------
// autoreply.cs and wavkeys.cs are two custom
// client-side scripts that I have made that I 
// am throwing in free of charge (and free of 
// support). You will need to have the Presto Pack
// installed to use the autoreply script. Autoreply 
// handles some basic flag and repair replies with
// attached voices and animation. Wavkeys binds
// several messages, voices, and animations to the
// numberpad keys. Use them at your discretion.

Include("dissident\\autoreply.cs");
Include("dissident\\wavkeys.cs");

function throwMine(%desc)
{
echo("Throw Release");
	%delta = getSimTime() - $throwStartTime;
	if (%delta > 1)
		%delta = 100;
	else
		%delta = floor(%delta * 100);
	remoteEval(2048,throwItem,%desc,%delta);
}

EditActionMap("playmap.sae");

bindCommand(keyboard0, make, "g", TO, "useItem(getMountedItem(4));");
bindCommand(keyboard0, make, "e", TO, "throwStart();");
bindCommand(keyboard0, break, "e", TO, "throwMine(getMountedItem(5));");

