EditActionMap("playmap.sae");

bindCommand(keyboard0, make, "numpad0", TO, "say(1,\"On the Attack~wono\"); messageAndAnimate(1,\"\");");
bindCommand(keyboard0, make, "numpad1", TO, "say(1,\"Setting up base defense~wdefend\"); messageAndAnimate(4,\"\");");
bindCommand(keyboard0, make, "numpad2", TO, "say(1,\"A little more help would be nice~wneeddef\"); messageAndAnimate(0,\"\");");
bindCommand(keyboard0, make, "numpad3", TO, "say(1,\"Problems on the home front~wbasundr\"); messageAndAnimate(0,\"\");");
bindCommand(keyboard0, make, "numpad4", TO, "say(1,\"Everything's fine at home~wbsclr2\"); messageAndAnimate(4,\"\");");
bindCommand(keyboard0, make, "numpad5", TO, "say(1,\"My bad~wsorry\"); messageAndAnimate(9,\"\");");
bindCommand(keyboard0, make, "numpad6", TO, "say(1,\"Heads up!~whitdeck\"); messageAndAnimate(2,\"\");");
bindCommand(keyboard0, make, "numpad7", TO, "say(1,\"Try practicing with that thing first!~wwshoot3\"); messageAndAnimate(12,\"\");");
bindCommand(keyboard0, make, "numpad8", TO, "say(1,\"Lobomotomy victim on the loose!~wdsgst2\"); messageAndAnimate(8,\"\");");
bindCommand(keyboard0, make, "numpad9", TO, "say(1,\"Set up your favorites amateur~whurystn\"); messageAndAnimate(12,\"\");");
