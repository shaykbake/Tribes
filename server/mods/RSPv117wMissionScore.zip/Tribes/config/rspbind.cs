EditActionMap("playMap.sae");
//Redneck Slag Pack Binds
//Modify them to your liking
bindCommand(keyboard0, make, control, "j", TO, "throwStart();");
bindCommand(keyboard0, break, control, "j", TO, "throwRelease(\"Jump Mine\");");
bindCommand(keyboard0, make, control, "g", TO, "throwStart();");
bindCommand(keyboard0, break, control, "g", TO, "throwRelease(\"Concussion Grenade\");");
//bindCommand(keyboard0, make, control, "l", TO, "throwStart();");
//bindCommand(keyboard0, break, control, "l", TO, "throwRelease(\"Flash Grenade\");");
bindCommand(keyboard0, make, control, "u", TO, "throwStart();");
bindCommand(keyboard0, break, control, "u", TO, "throwRelease(\"Nuke Pack\");");