//Anti Flooding Options
$RSP::FloodKill = True; //Toggle dramitic flood measures
$RSP::FloodCount = 7; //Sets the chat line amount that will activate the anti flood procedures. Can't be less then 5
$Server::FloodProtectionEnabled = True; //Dynamix setting that toggles the basic anti flood measures within the server. Must be true if your using flood kill on your server.

//Hacking and Infecting Options
$RSP::AllowHacking = True; //Toggle hacking
$RSP::HackTime = 5; //Time that hacking/infecting takes (In seconds) Can't be less then 2 or greater then 10
$RSP::HackedTime = 900; //Time to wait before returning control to owners (In seconds) Can't be less then 900
$RSP::InfectedTime = 900; //Time to wait before virus expires (In seconds) Can't be less then 900

//Nuke Pack Options
$RSP::NukeDetTime = 30; //Fuse time on the nuke pack {In seconds) Can't be less then 15 or greater then 60

//Anti Out of Mission Area Options
$RSP::AntiOOB = True; //Enables anti out of mission area code
$RSP::AntiOOBTime = 20; //Sets time that you are allowed to be OOB (In seconds) Can't be less then 15 or greater then 60

//Anti Team Killing Options
$RSP::AntiTK = True; //Toggles anti team killing measures
$RSP::TKKickCount = 5; //Sets how many team kill incidents it takes to be kicked off the server. Can't be less then 5 or greater then 30

//Magnetic Pulse Capacitor Pack Options
$RSP::MPCPackChargeTime = 45; //Sets how long the MPC Pack lasts during each activation (In seconds) Can't be less then 45 or greater then 90
//$RSP::MPCPackCoolingTime = 60; //Sets how long the pack must cool before being able to use it again (In seconds) Can't be less then 15 or greater then 90
$RSP::MPCCoolAccordingToUse = True; //Allows the cooling time to vary according to how long a person uses the MPC Pack

//Menu Options
$RSP::ChangeTeams = False; //Toggles team specific changing
$RSP::AdminVote = True; //Toggles admin voting

// SAD() Passwords
$SuperAdminPassword = "sadmin"; //Password for super admins to use when using the SAD(""); command

//Console Settings
$Console::LogMode = "0"; //If = 1 then server is logging. If = 0 then server is NOT logging
$Server::FloodProtectionEnabled = True; //Dynamix settings that toggles the basic anti flood measures within the server. Must be true if your using flood kill on your server.

//Telnet Settings... Remove the //s at the beginings of the lines if you want to enable remote server administration through Telnet
//$TelnetPort = 9999;
//$TelnetPassword = telpass; //Default Password