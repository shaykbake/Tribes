        ************************
        * RRRRR	  SSSSS  PPPPP *
        * RR   R  SS	 PP  P *
        * RRRRR	  SSSSS	 PPPPP *
        * RR RR	     SS	 PP    *
        * RR  RR  SSSSS	 PP    *
        ************************

*******************************************
* Rednecek Slag Pack for Starseige Tribes *
*******************************************

Author: HightechRedneck
URL: www.planetstarsiege.com/rsp
E-Mail: HightechRedneck@planetstarsiege.com

Version: 1.17 w/ Scoring Update
MOD Type: Server Side

*******************************************
* Installation			          *
*******************************************

Ok now that you downloaded the zip you need to unzip it to the directory that your
tribes folder is in...

For example: If the tribes directory was located in C:\Tribes you would unzip the
             zip file to C:\

Ok now that you have the files in place to run the MOD you need to start tribes
with the new server code. To do this you have 2 options. 

A) Start a non dedicated tribes server. To do this you can go to your windows
   run box and type "C:\Tribes\Tribes.exe -mod RedneckSlag" without the "s
   this example assumes tribes is in your C:\ drive make changes to the
   directory structure as needed. The key thing is the "-mod RedneckSlag" this
   is what tells tribes where the new server code is. After you have tribes up
   and running simply start a server as usual and bam your playing RSP.

B) Start a dedicated tribes server. As in the proceeding set of directions up
   go to your windows run box and type 
   	"C:\Tribes\Tribes.exe -mod RedneckSlag -dedicated"
   notice the added "-dedicated" at the end. The -mod and -dedicated arguments
   must be in this order for the server to run correctly. Once you hit OK a DOS
   box will open and you now have a dedicated Tribes server running RSP.

*******************************************
* Configuration			          *
*******************************************

Well now that you have the MOD up and running you may feel like setting up the 
MOD specific settings. To do this open the RedneckSlag.cs file in your
Tribes\Config directory in any text editor. You will see a bunch of lines with
comments at the ends of them. Feel free to change these as you see fit. The 
comments describe what each option affects

*******************************************
* Helpful Sites				  *
*******************************************
www.planetstarsiege.com
www.tribesplayers.com