// "Light" Armor

$DamageScale[larmor, $LandingDamageType]	= 1.0;
$DamageScale[larmor, $ImpactDamageType]		= 1.0;
$DamageScale[larmor, $CrushDamageType]		= 1.0;
$DamageScale[larmor, $BulletDamageType]		= 1.2;
$DamageScale[larmor, $PlasmaDamageType]		= 1.0;
$DamageScale[larmor, $NuclearDamageType]	= 1.5;
$DamageScale[larmor, $EnergyDamageType]		= 1.3;
$DamageScale[larmor, $ExplosionDamageType]	= 1.0;
$DamageScale[larmor, $MissileDamageType]	= 1.0;
$DamageScale[larmor, $DebrisDamageType]		= 1.2;
$DamageScale[larmor, $ShrapnelDamageType]	= 1.2;
$DamageScale[larmor, $LaserDamageType]		= 1.0;
$DamageScale[larmor, $SniperDamageType]		= 1.4;
$DamageScale[larmor, $HeatDamageType]		= 0.3;
$DamageScale[larmor, $MortarDamageType]		= 1.3;
$DamageScale[larmor, $RocketDamageType]		= 1.0;
$DamageScale[larmor, $BlasterDamageType]	= 1.3;
$DamageScale[larmor, $ElectricityDamageType]	= 1.0;
$DamageScale[larmor, $MineDamageType]		= 1.2;

$ItemMax[larmor, Blaster]			= 1;
$ItemMax[larmor, Chaingun]			= 1;
$ItemMax[larmor, Disclauncher]			= 1;
$ItemMax[larmor, GrenadeLauncher]		= 1;
$ItemMax[larmor, Mortar]			= 0;
$ItemMax[larmor, Nuke]				= 0;
$ItemMax[larmor, RocketLauncher]		= 0;
$ItemMax[larmor, PlasmaGun]			= 1;
$ItemMax[larmor, FusionRifle]			= 0;
$ItemMax[larmor, LaserRifle]			= 1;
$ItemMax[larmor, SniperRifle]			= 0;
$ItemMax[larmor, EnergyRifle]			= 1;
$ItemMax[larmor, HeatLaser]			= 0;
$ItemMax[larmor, TargetingLaser]		= 1;
$ItemMax[larmor, MineAmmo]			= 3;
$ItemMax[larmor, Grenade]			= 5;
$ItemMax[larmor, Beacon]			= 3;
$ItemMax[larmor, BulletAmmo]			= 100;
$ItemMax[larmor, PlasmaAmmo]			= 30;
$ItemMax[larmor, FusionAmmo]			= 0;
$ItemMax[larmor, DiscAmmo]			= 15;
$ItemMax[larmor, GrenadeAmmo]			= 10;
$ItemMax[larmor, NukeAmmo]			= 0;
$ItemMax[larmor, MortarAmmo]			= 0;
$ItemMax[larmor, RocketAmmo]			= 0;
$ItemMax[larmor, EnergyPack]			= 1;
$ItemMax[larmor, RepairPack]			= 1;
$ItemMax[larmor, ShieldPack]			= 1;
$ItemMax[larmor, SensorJammerPack]		= 1;
$ItemMax[larmor, MotionSensorPack]		= 1;
$ItemMax[larmor, PulseSensorPack]		= 1;
$ItemMax[larmor, DeployableSensorJammerPack]	= 1;
$ItemMax[larmor, CameraPack]			= 1;
$ItemMax[larmor, TurretPack]			= 0;
$ItemMax[larmor, AmmoPack]			= 1;
$ItemMax[larmor, RepairKit]			= 1;
$ItemMax[larmor, DeployableInvPack]		= 0;
$ItemMax[larmor, DeployableAmmoPack]		= 0;

$MaxWeapons[larmor]				= 3;

// "Scout" Armor

$DamageScale[scarmor, $LandingDamageType]	= 1.1;
$DamageScale[scarmor, $ImpactDamageType]	= 1.1;
$DamageScale[scarmor, $CrushDamageType]		= 1.1;
$DamageScale[scarmor, $BulletDamageType]	= 1.2;
$DamageScale[scarmor, $PlasmaDamageType]	= 1.1;
$DamageScale[scarmor, $NuclearDamageType]	= 1.9;
$DamageScale[scarmor, $EnergyDamageType]	= 1.4;
$DamageScale[scarmor, $ExplosionDamageType]	= 1.1;
$DamageScale[scarmor, $MissileDamageType]	= 1.1;
$DamageScale[scarmor, $DebrisDamageType]	= 1.1;
$DamageScale[scarmor, $ShrapnelDamageType]	= 1.5;
$DamageScale[scarmor, $LaserDamageType]		= 0.1;
$DamageScale[scarmor, $SniperDamageType]	= 0.1;
$DamageScale[scarmor, $HeatDamageType]		= 0.1;
$DamageScale[scarmor, $MortarDamageType]	= 1.5;
$DamageScale[scarmor, $RocketDamageType]	= 1.3;
$DamageScale[scarmor, $BlasterDamageType]	= 1.3;
$DamageScale[scarmor, $ElectricityDamageType]	= 1.0;
$DamageScale[scarmor, $MineDamageType]		= 1.2;

$ItemMax[scarmor, Blaster]			= 1;
$ItemMax[scarmor, Chaingun]			= 1;
$ItemMax[scarmor, Disclauncher]			= 1;
$ItemMax[scarmor, GrenadeLauncher]		= 0;
$ItemMax[scarmor, Nuke]				= 0;
$ItemMax[scarmor, Mortar]			= 0;
$ItemMax[scarmor, RocketLauncher]		= 0;
$ItemMax[scarmor, PlasmaGun]			= 1;
$ItemMax[scarmor, FusionRifle]			= 1;
$ItemMax[scarmor, LaserRifle]			= 0;
$ItemMax[scarmor, SniperRifle]			= 0;
$ItemMax[scarmor, EnergyRifle]			= 1;
$ItemMax[scarmor, HeatLaser]			= 0;
$ItemMax[scarmor, TargetingLaser]		= 1;
$ItemMax[scarmor, MineAmmo]			= 3;
$ItemMax[scarmor, Grenade]			= 5;
$ItemMax[scarmor, Beacon]			= 3;
$ItemMax[scarmor, BulletAmmo]			= 100;
$ItemMax[scarmor, PlasmaAmmo]			= 30;
$ItemMax[scarmor, FusionAmmo]			= 20;
$ItemMax[scarmor, DiscAmmo]			= 15;
$ItemMax[scarmor, GrenadeAmmo]			= 10;
$ItemMax[scarmor, NukeAmmo]			= 0;
$ItemMax[scarmor, MortarAmmo]			= 0;
$ItemMax[scarmor, RocketAmmo]			= 0;
$ItemMax[scarmor, EnergyPack]			= 0;
$ItemMax[scarmor, RepairPack]			= 1;
$ItemMax[scarmor, ShieldPack]			= 0;
$ItemMax[scarmor, SensorJammerPack]		= 1;
$ItemMax[scarmor, MotionSensorPack]		= 0;
$ItemMax[scarmor, PulseSensorPack]		= 0;
$ItemMax[scarmor, DeployableSensorJammerPack]	= 0;
$ItemMax[scarmor, CameraPack]			= 0;
$ItemMax[scarmor, TurretPack]			= 0;
$ItemMax[scarmor, AmmoPack]			= 1;
$ItemMax[scarmor, RepairKit]			= 1;
$ItemMax[scarmor, DeployableInvPack]		= 0;
$ItemMax[scarmor, DeployableAmmoPack]		= 0;

$MaxWeapons[scarmor]				= 2;

// "Sniper" Armor

$DamageScale[sarmor, $LandingDamageType]	= 0.0;
$DamageScale[sarmor, $ImpactDamageType]		= 0.0;
$DamageScale[sarmor, $CrushDamageType]		= 1.2;
$DamageScale[sarmor, $BulletDamageType]		= 1.0;
$DamageScale[sarmor, $PlasmaDamageType]		= 1.1;
$DamageScale[sarmor, $NuclearDamagaeType]	= 1.6;
$DamageScale[sarmor, $EnergyDamageType] 	= 1.2;
$DamageScale[sarmor, $ExplosionDamageType]	= 1.4;
$DamageScale[sarmor, $MissileDamageType] 	= 1.3;
$DamageScale[sarmor, $DebrisDamageType] 	= 1.1;
$DamageScale[sarmor, $ShrapnelDamageType] 	= 1.1;
$DamageScale[sarmor, $LaserDamageType] 		= 0.6;
$DamageScale[sarmor, $SniperDamageType] 	= 0.8;
$DamageScale[sarmor, $HeatDamageType]		= 0.4;
$DamageScale[sarmor, $MortarDamageType] 	= 1.7;
$DamageScale[sarmor, $RocketDamageType]		= 1.4;
$DamageScale[sarmor, $BlasterDamageType]	= 1.2;
$DamageScale[sarmor, $ElectricityDamageType] 	= 1.3;
$DamageScale[sarmor, $MineDamageType] 		= 1.0;

$ItemMax[sarmor, Blaster] 			= 1;
$ItemMax[sarmor, Chaingun] 			= 1;
$ItemMax[sarmor, Disclauncher] 			= 1;
$ItemMax[sarmor, GrenadeLauncher]		= 0;
$ItemMax[sarmor, Nuke]				= 0;
$ItemMax[sarmor, Mortar] 			= 0;
$ItemMax[sarmor, RocketLauncher]		= 0;
$ItemMax[sarmor, PlasmaGun] 			= 1;
$ItemMax[sarmor, FusionRifle]			= 0;
$ItemMax[sarmor, LaserRifle] 			= 0;
$ItemMax[sarmor, SniperRifle] 			= 1;
$ItemMax[sarmor, HeatLaser]			= 1;
$ItemMax[sarmor, EnergyRifle] 			= 1;
$ItemMax[sarmor, TargetingLaser] 		= 1;
$ItemMax[sarmor, MineAmmo] 			= 2;
$ItemMax[sarmor, Grenade] 			= 5;
$ItemMax[sarmor, Beacon]  			= 0;
$ItemMax[sarmor, BulletAmmo] 			= 70;
$ItemMax[sarmor, PlasmaAmmo] 			= 25;
$ItemMax[sarmor, FusionAmmo]			= 0;
$ItemMax[sarmor, DiscAmmo] 			= 15;
$ItemMax[sarmor, GrenadeAmmo] 			= 10;
$ItemMax[sarmor, NukeAmmo]			= 0;
$ItemMax[sarmor, MortarAmmo] 			= 0;
$ItemMax[sarmor, RocketAmmo]			= 0;
$ItemMax[sarmor, EnergyPack] 			= 1;
$ItemMax[sarmor, RepairPack] 			= 1;
$ItemMax[sarmor, ShieldPack] 			= 0;
$ItemMax[sarmor, SensorJammerPack] 		= 1;
$ItemMax[sarmor, MotionSensorPack] 		= 0;
$ItemMax[sarmor, PulseSensorPack] 		= 0;
$ItemMax[sarmor, DeployableSensorJammerPack] 	= 1;
$ItemMax[sarmor, CameraPack] 			= 0;
$ItemMax[sarmor, TurretPack] 			= 0;
$ItemMax[sarmor, AmmoPack] 			= 1;
$ItemMax[sarmor, RepairKit]			= 1;
$ItemMax[sarmor, DeployableInvPack] 		= 0;
$ItemMax[sarmor, DeployableAmmoPack] 		= 0;

$MaxWeapons[sarmor] = 3;

// "Assault" Armor

$DamageScale[asarmor, $LandingDamageType] 	= 1.0;
$DamageScale[asarmor, $ImpactDamageType] 	= 1.0;
$DamageScale[asarmor, $CrushDamageType] 	= 1.2;
$DamageScale[asarmor, $BulletDamageType] 	= 1.0;
$DamageScale[asarmor, $PlasmaDamageType] 	= 1.1;
$DamageScale[asarmor, $NuclearDamageType]	= 1.3;
$DamageScale[asarmor, $EnergyDamageType] 	= 1.2;
$DamageScale[asarmor, $ExplosionDamageType] 	= 1.2;
$DamageScale[asarmor, $MissileDamageType] 	= 1.1;
$DamageScale[asarmor, $DebrisDamageType] 	= 1.1;
$DamageScale[asarmor, $ShrapnelDamageType] 	= 1.1;
$DamageScale[asarmor, $LaserDamageType] 	= 1.6;
$DamageScale[asarmor, $SniperDamageType] 	= 2.8;
$DamageScale[asarmor, $HeatDamageType]		= 1.0;
$DamageScale[asarmor, $MortarDamageType] 	= 1.2;
$DamageScale[asarmor, $RocketDamageType]	= 1.1;
$DamageScale[asarmor, $BlasterDamageType] 	= 1.0;
$DamageScale[asarmor, $ElectricityDamageType] 	= 0.9;
$DamageScale[asarmor, $MineDamageType]		= 0.4;

$ItemMax[asarmor, Blaster] 			= 1;
$ItemMax[asarmor, Chaingun] 			= 1;
$ItemMax[asarmor, Disclauncher] 		= 1;
$ItemMax[asarmor, GrenadeLauncher] 		= 1;
$ItemMax[asarmor, Nuke]				= 0;
$ItemMax[asarmor, Mortar] 			= 0;
$ItemMax[asarmor, RocketLauncher]		= 1;
$ItemMax[asarmor, PlasmaGun] 			= 1;
$ItemMax[asarmor, FusionRifle]			= 1;
$ItemMax[asarmor, LaserRifle] 			= 0;
$ItemMax[asarmor, SniperRifle] 			= 0;
$ItemMax[asarmor, HeatLaser]			= 1;
$ItemMax[asarmor, EnergyRifle] 			= 1;
$ItemMax[asarmor, TargetingLaser]		= 1;
$ItemMax[asarmor, MineAmmo] 			= 10;
$ItemMax[asarmor, Grenade] 			= 10;
$ItemMax[asarmor, Beacon]  			= 10;
$ItemMax[asarmor, BulletAmmo] 			= 100;
$ItemMax[asarmor, PlasmaAmmo] 			= 30;
$ItemMax[asarmor, FusionAmmo]			= 40;
$ItemMax[asarmor, DiscAmmo] 			= 15;
$ItemMax[asarmor, GrenadeAmmo] 			= 10;
$ItemMax[asarmor, NukeAmmo]			= 0;
$ItemMax[asarmor, MortarAmmo] 			= 0;
$ItemMax[asarmor, RocketAmmo]			= 10;
$ItemMax[asarmor, EnergyPack] 			= 1;
$ItemMax[asarmor, RepairPack] 			= 1;
$ItemMax[asarmor, ShieldPack] 			= 1;
$ItemMax[asarmor, SensorJammerPack] 		= 1;
$ItemMax[asarmor, MotionSensorPack] 		= 1;
$ItemMax[asarmor, PulseSensorPack] 		= 0;
$ItemMax[asarmor, DeployableSensorJammerPack] 	= 1;
$ItemMax[asarmor, CameraPack] 			= 0;
$ItemMax[asarmor, TurretPack] 			= 0;
$ItemMax[asarmor, AmmoPack] 			= 1;
$ItemMax[asarmor, RepairKit] 			= 1;
$ItemMax[asarmor, DeployableInvPack] 		= 0;
$ItemMax[asarmor, DeployableAmmoPack] 		= 0;

$MaxWeapons[asarmor] = 4;

// "medium" armor

$DamageScale[marmor, $LandingDamageType]	= 1.0;
$DamageScale[marmor, $ImpactDamageType]		= 1.0;
$DamageScale[marmor, $CrushDamageType]		= 1.0;
$DamageScale[marmor, $BulletDamageType]		= 1.0;
$DamageScale[marmor, $PlasmaDamageType]		= 0.6;
$DamageScale[marmor, $NuclearDamageType]	= 1.3;
$DamageScale[marmor, $EnergyDamageType]		= 1.0;
$DamageScale[marmor, $ExplosionDamageType]	= 1.0;
$DamageScale[marmor, $MissileDamageType]	= 1.0;
$DamageScale[marmor, $ShrapnelDamageType]	= 1.0;
$DamageScale[marmor, $DebrisDamageType]		= 1.0;
$DamageScale[marmor, $LaserDamageType]		= 1.0;
$DamageScale[marmor, $SniperDamageType]		= 1.2;
$DamageScale[marmor, $MortarDamageType]		= 1.0;
$DamageScale[marmor, $BlasterDamageType]	= 1.0;
$DamageScale[marmor, $ElectricityDamageType]	= 1.0;
$DamageScale[marmor, $MineDamageType]		= 1.0;

$ItemMax[marmor, Blaster]			= 1;
$ItemMax[marmor, Chaingun]			= 1;
$ItemMax[marmor, Disclauncher]			= 1;
$ItemMax[marmor, GrenadeLauncher]		= 1;
$ItemMax[marmor, RocketLauncher]		= 1;
$ItemMax[marmor, Nuke]				= 0;
$ItemMax[marmor, Mortar]			= 0;
$ItemMax[marmor, PlasmaGun]			= 1;
$ItemMax[marmor, FusionRifle]			= 1;
$ItemMax[marmor, LaserRifle]			= 0;
$ItemMax[marmor, SniperRifle]			= 0;
$ItemMax[marmor, EnergyRifle]			= 1;
$ItemMax[marmor, HeatLaser]			= 0;
$ItemMax[marmor, TargetingLaser]		= 1;
$ItemMax[marmor, MineAmmo]			= 3;
$ItemMax[marmor, Grenade]			= 6;
$ItemMax[marmor, Beacon]			= 3;
$ItemMax[marmor, BulletAmmo]			= 150;
$ItemMax[marmor, PlasmaAmmo]			= 40;
$ItemMax[marmor, FusionAmmo]			= 35;
$ItemMax[marmor, DiscAmmo]			= 15;
$ItemMax[marmor, GrenadeAmmo]			= 10;
$ItemMax[marmor, NukeAmmo]			= 0;
$ItemMax[marmor, MortarAmmo]			= 10;
$ItemMax[marmor, RocketAmmo]			= 10;
$ItemMax[marmor, EnergyPack]			= 1;
$ItemMax[marmor, RepairPack]			= 1;
$ItemMax[marmor, ShieldPack]			= 1;
$ItemMax[marmor, SensorJammerPack]		= 1;
$ItemMax[marmor, MotionSensorPack]		= 1;
$ItemMax[marmor, PulseSensorPack]		= 1;
$ItemMax[marmor, DeployableSensorJammerPack]	= 1;
$ItemMax[marmor, CameraPack]			= 1;
$ItemMax[marmor, TurretPack]			= 1;
$ItemMax[marmor, AmmoPack]			= 1;
$ItemMax[marmor, RepairKit]			= 1;
$ItemMax[marmor, DeployableInvPack]		= 1;
$ItemMax[marmor, DeployableAmmoPack]		= 1;

$MaxWeapons[marmor] = 4;

// "heavy" armor (unisex)

$DamageScale[harmor, $LandingDamageType]	= 1.0;
$DamageScale[harmor, $ImpactDamageType]		= 1.0;
$DamageScale[harmor, $CrushDamageType]		= 1.0;
$DamageScale[harmor, $BulletDamageType]		= 0.6;
$DamageScale[harmor, $PlasmaDamageType]		= 0.4;
$DamageScale[harmor, $NuclearDamageType]	= 1.0;
$DamageScale[harmor, $EnergyDamageType]		= 0.7;
$DamageScale[harmor, $ExplosionDamageType]	= 0.6;
$DamageScale[harmor, $MissileDamageType]	= 0.6;
$DamageScale[harmor, $DebrisDamageType]		= 0.8;
$DamageScale[harmor, $ShrapnelDamageType]	= 0.8;
$DamageScale[harmor, $HeatDamageType]		= 0.3;
$DamageScale[harmor, $LaserDamageType]		= 0.6;
$DamageScale[harmor, $SniperDamageType]		= 1.0;
$DamageScale[harmor, $RocketDamageType]		= 0.6;
$DamageScale[harmor, $MortarDamageType]		= 0.7;
$DamageScale[harmor, $BlasterDamageType]	= 0.7;
$DamageScale[harmor, $ElectricityDamageType]	= 1.0;
$DamageScale[harmor, $MineDamageType]		= 0.8;

$ItemMax[harmor, Blaster]			= 1;
$ItemMax[harmor, Chaingun]			= 1;
$ItemMax[harmor, Disclauncher]			= 1;
$ItemMax[harmor, GrenadeLauncher]		= 1;
$ItemMax[harmor, RocketLauncher]		= 1;
$ItemMax[harmor, Nuke]				= 1;
$ItemMax[harmor, Mortar]			= 1;
$ItemMax[harmor, PlasmaGun]			= 1;
$ItemMax[harmor, FusionRifle]			= 1;
$ItemMax[harmor, LaserRifle]			= 0;
$ItemMax[harmor, SniperRifle]			= 0;
$ItemMax[harmor, EnergyRifle]			= 1;
$ItemMax[harmor, HeatLaser]			= 0;
$ItemMax[harmor, TargetingLaser]		= 1;
$ItemMax[harmor, MineAmmo]			= 3;
$ItemMax[harmor, Grenade]			= 8;
$ItemMax[harmor, Beacon]			= 3;
$ItemMax[harmor, BulletAmmo]			= 200;
$ItemMax[harmor, PlasmaAmmo]			= 50;
$ItemMax[harmor, FusionAmmo]			= 45;
$ItemMax[harmor, DiscAmmo]			= 15;
$ItemMax[harmor, GrenadeAmmo]			= 15;
$ItemMax[harmor, NukeAmmo]			= 2;
$ItemMax[harmor, MortarAmmo]			= 10;
$ItemMax[harmor, RocketAmmo]			= 10;
$ItemMax[harmor, EnergyPack]			= 1;
$ItemMax[harmor, RepairPack]			= 1;
$ItemMax[harmor, ShieldPack]			= 1;
$ItemMax[harmor, SensorJammerPack]		= 1;
$ItemMax[harmor, MotionSensorPack]		= 1;
$ItemMax[harmor, PulseSensorPack]		= 1;
$ItemMax[harmor, DeployableSensorJammerPack]	= 1;
$ItemMax[harmor, CameraPack]			= 1;
$ItemMax[harmor, TurretPack]			= 1;
$ItemMax[harmor, AmmoPack]			= 1;
$ItemMax[harmor, RepairKit]			= 1;
$ItemMax[harmor, DeployableInvPack]		= 1;
$ItemMax[harmor, DeployableAmmoPack]		= 1;

$MaxWeapons[harmor] = 5;

// "battlestar" armor (unisex)

$DamageScale[bsarmor, $LandingDamageType]	= 1.0;
$DamageScale[bsarmor, $ImpactDamageType]	= 1.0;
$DamageScale[bsarmor, $CrushDamageType]		= 1.0;
$DamageScale[bsarmor, $BulletDamageType]	= 0.6;
$DamageScale[bsarmor, $PlasmaDamageType]	= 0.4;
$DamageScale[bsarmor, $NuclearDamageType]	= 1.0;
$DamageScale[bsarmor, $EnergyDamageType]	= 0.7;
$DamageScale[bsarmor, $ExplosionDamageType]	= 0.6;
$DamageScale[bsarmor, $MissileDamageType]	= 0.6;
$DamageScale[bsarmor, $DebrisDamageType]	= 0.8;
$DamageScale[bsarmor, $ShrapnelDamageType]	= 0.8;
$DamageScale[bsarmor, $HeatDamageType]		= 0.3;
$DamageScale[bsarmor, $LaserDamageType]		= 0.6;
$DamageScale[bsarmor, $SniperDamageType]	= 1.3;
$DamageScale[bsarmor, $RocketDamageType]	= 0.6;
$DamageScale[bsarmor, $MortarDamageType]	= 0.7;
$DamageScale[bsarmor, $BlasterDamageType]	= 0.7;
$DamageScale[bsarmor, $ElectricityDamageType]	= 1.0;
$DamageScale[bsarmor, $MineDamageType]		= 0.8;

$ItemMax[bsarmor, Blaster]			= 1;
$ItemMax[bsarmor, Chaingun]			= 1;
$ItemMax[bsarmor, Disclauncher]			= 1;
$ItemMax[bsarmor, GrenadeLauncher]		= 1;
$ItemMax[bsarmor, RocketLauncher]		= 1;
$ItemMax[bsarmor, Nuke]				= 1;
$ItemMax[bsarmor, Mortar]			= 1;
$ItemMax[bsarmor, PlasmaGun]			= 1;
$ItemMax[bsarmor, FusionRifle]			= 1;
$ItemMax[bsarmor, LaserRifle]			= 0;
$ItemMax[bsarmor, SniperRifle]			= 0;
$ItemMax[bsarmor, EnergyRifle]			= 1;
$ItemMax[bsarmor, HeatLaser]			= 1;
$ItemMax[bsarmor, TargetingLaser]		= 1;
$ItemMax[bsarmor, MineAmmo]			= 500;
$ItemMax[bsarmor, Grenade]			= 500;
$ItemMax[bsarmor, Beacon]			= 500;
$ItemMax[bsarmor, BulletAmmo]			= 500;
$ItemMax[bsarmor, PlasmaAmmo]			= 500;
$ItemMax[bsarmor, FusionAmmo]			= 500;
$ItemMax[bsarmor, DiscAmmo]			= 500;
$ItemMax[bsarmor, GrenadeAmmo]			= 500;
$ItemMax[bsarmor, NukeAmmo]			= 500;
$ItemMax[bsarmor, MortarAmmo]			= 500;
$ItemMax[bsarmor, RocketAmmo]			= 500;
$ItemMax[bsarmor, EnergyPack]			= 0;
$ItemMax[bsarmor, RepairPack]			= 0;
$ItemMax[bsarmor, ShieldPack]			= 0;
$ItemMax[bsarmor, SensorJammerPack]		= 0;
$ItemMax[bsarmor, MotionSensorPack]		= 0;
$ItemMax[bsarmor, PulseSensorPack]		= 0;
$ItemMax[bsarmor, DeployableSensorJammerPack]	= 0;
$ItemMax[bsarmor, CameraPack]			= 0;
$ItemMax[bsarmor, TurretPack]			= 0;
$ItemMax[bsarmor, AmmoPack]			= 0;
$ItemMax[bsarmor, RepairKit]			= 0;
$ItemMax[bsarmor, DeployableInvPack]		= 0;
$ItemMax[bsarmor, DeployableAmmoPack]		= 0;

$MaxWeapons[bsarmor] = 11;

// "light" armor (female)

$DamageScale[lfemale, $LandingDamageType] 	= 1.0;
$DamageScale[lfemale, $ImpactDamageType] 	= 1.0;	
$DamageScale[lfemale, $CrushDamageType] 	= 1.0;	
$DamageScale[lfemale, $BulletDamageType] 	= 1.2;
$DamageScale[lfemale, $PlasmaDamageType] 	= 1.0;
$DamageScale[lfemale, $NuclearDamageType]	= 1.5;
$DamageScale[lfemale, $EnergyDamageType] 	= 1.3;
$DamageScale[lfemale, $ExplosionDamageType] 	= 1.0;
$DamageScale[lfemale, $MissileDamageType] 	= 1.0;
$DamageScale[lfemale, $ShrapnelDamageType] 	= 1.2;
$DamageScale[lfemale, $DebrisDamageType] 	= 1.2;
$DamageScale[lfemale, $LaserDamageType] 	= 1.0;
$DamageScale[lfemale, $SniperDamageType] 	= 1.0;
$DamageScale[lfemale, $HeatDamageType]		= 0.3;
$DamageScale[lfemale, $MortarDamageType] 	= 1.3;
$DamageScale[lfemale, $RocketDamageType]	= 1.2;
$DamageScale[lfemale, $BlasterDamageType] 	= 1.3;
$DamageScale[lfemale, $ElectricityDamageType] 	= 1.0;
$DamageScale[lfemale, $MineDamageType] 		= 1.2;

$ItemMax[lfemale, Blaster] 			= 1;
$ItemMax[lfemale, Chaingun] 			= 1;
$ItemMax[lfemale, Disclauncher] 		= 1;
$ItemMax[lfemale, GrenadeLauncher] 		= 1;
$ItemMax[lfemale, Nuke]				= 0;
$ItemMax[lfemale, Mortar] 			= 0;
$ItemMax[lfemale, RocketLauncher]		= 0;
$ItemMax[lfemale, PlasmaGun]			= 1;
$ItemMax[lfemale, FusionRifle]			= 0;
$ItemMax[lfemale, LaserRifle]			= 1;
$ItemMan[lfemale, SniperRifle]	 		= 0;
$ItemMax[lfemale, HeatLaser]			= 0;
$ItemMax[lfemale, EnergyRifle] 			= 1;
$ItemMax[lfemale, TargetingLaser] 		= 1;
$ItemMax[lfemale, MineAmmo] 			= 3;
$ItemMax[lfemale, Grenade] 			= 5;
$ItemMax[lfemale, Beacon] 			= 3;
$ItemMax[lfemale, BulletAmmo] 			= 100;
$ItemMax[lfemale, PlasmaAmmo] 			= 30;
$ItemMax[lfemale, FusionAmmo]			= 0;
$ItemMax[lfemale, DiscAmmo] 			= 15;
$ItemMax[lfemale, GrenadeAmmo] 			= 10;
$ItemMax[lfemale, NukeAmmo]			= 0;
$ItemMax[lfemale, MortarAmmo] 			= 0;
$ItemMax[lfemale, RocketAmmo]			= 0;
$ItemMax[lfemale, EnergyPack] 			= 1;
$ItemMax[lfemale, RepairPack] 			= 1;
$ItemMax[lfemale, ShieldPack] 			= 1;
$ItemMax[lfemale, SensorJammerPack] 		= 1;
$ItemMax[lfemale, MotionSensorPack] 		= 1;
$ItemMax[lfemale, PulseSensorPack] 		= 1;
$ItemMax[lfemale, DeployableSensorJammerPack] 	= 1;
$ItemMax[lfemale, CameraPack] 			= 1;
$ItemMax[lfemale, TurretPack] 			= 0;
$ItemMax[lfemale, AmmoPack] 			= 1;
$ItemMax[lfemale, RepairKit] 			= 1;
$ItemMax[lfemale, DeployableInvPack] 		= 0;
$ItemMax[lfemale, DeployableAmmoPack] 		= 0;

$MaxWeapons[lfemale] = 3;

// "Scout" Armor (female)

$DamageScale[scfemale, $LandingDamageType]	= 1.1;
$DamageScale[scfemale, $ImpactDamageType]	= 1.1;
$DamageScale[scfemale, $CrushDamageType]	= 1.1;
$DamageScale[scfemale, $BulletDamageType]	= 1.2;
$DamageScale[scfemale, $PlasmaDamageType]	= 1.1;
$DamageScale[scfemale, $NuclearDamageType]	= 1.7;
$DamageScale[scfemale, $EnergyDamageType]	= 1.4;
$DamageScale[scfemale, $ExplosionDamageType]	= 1.1;
$DamageScale[scfemale, $MissileDamageType]	= 1.1;
$DamageScale[scfemale, $DebrisDamageType]	= 1.1;
$DamageScale[scfemale, $ShrapnelDamageType]	= 1.5;
$DamageScale[scfemale, $LaserDamageType]	= 0.1;
$DamageScale[scfemale, $SniperDamageType]	= 0.1;
$DamageScale[scfemale, $HeatDamageType]		= 0.1;
$DamageScale[scfemale, $MortarDamageType]	= 1.7;
$DamageScale[scfemale, $RocketDamageType]	= 1.5;
$DamageScale[scfemale, $BlasterDamageType]	= 1.3;
$DamageScale[scfemale, $ElectricityDamageType]	= 1.0;
$DamageScale[scfemale, $MineDamageType]		= 1.2;

$ItemMax[scfemale, Blaster]			= 1;
$ItemMax[scfemale, Chaingun]			= 1;
$ItemMax[scfemale, Disclauncher]		= 1;
$ItemMax[scfemale, GrenadeLauncher]		= 0;
$ItemMax[scfemale, Nuke]			= 0;
$ItemMax[scfemale, Mortar]			= 0;
$ItemMax[scfemale, RocketLauncher]		= 0;
$ItemMax[scfemale, PlasmaGun]			= 1;
$ItemMax[scfemale, FusionRifle]			= 1;
$ItemMax[scfemale, LaserRifle]			= 0;
$ItemMax[scfemale, SniperRifle]			= 0;
$ItemMax[scfemale, EnergyRifle]			= 1;
$ItemMax[scfemale, HeatLaser]			= 0;
$ItemMax[scfemale, TargetingLaser]		= 1;
$ItemMax[scfemale, MineAmmo]			= 3;
$ItemMax[scfemale, Grenade]			= 5;
$ItemMax[scfemale, Beacon]			= 3;
$ItemMax[scfemale, BulletAmmo]			= 100;
$ItemMax[scfemale, PlasmaAmmo]			= 30;
$ItemMax[scfemale, FusionAmmo]			= 20;
$ItemMax[scfemale, DiscAmmo]			= 15;
$ItemMax[scfemale, GrenadeAmmo]			= 10;
$ItemMax[scfemale, NukeAmmo]			= 0;
$ItemMax[scfemale, MortarAmmo]			= 0;
$ItemMax[scfemale, RocketAmmo]			= 0;
$ItemMax[scfemale, EnergyPack]			= 0;
$ItemMax[scfemale, RepairPack]			= 1;
$ItemMax[scfemale, ShieldPack]			= 0;
$ItemMax[scfemale, SensorJammerPack]		= 1;
$ItemMax[scfemale, MotionSensorPack]		= 0;
$ItemMax[scfemale, PulseSensorPack]		= 0;
$ItemMax[scfemale, DeployableSensorJammerPack]	= 0;
$ItemMax[scfemale, CameraPack]			= 0;
$ItemMax[scfemale, TurretPack]			= 0;
$ItemMax[scfemale, AmmoPack]			= 1;
$ItemMax[scfemale, RepairKit]			= 1;
$ItemMax[scfemale, DeployableInvPack]		= 0;
$ItemMax[scfemale, DeployableAmmoPack]		= 0;

$MaxWeapons[scfemale]				= 2;

// "Sniper" Armor (female)

$DamageScale[sfemale, $LandingDamageType] 	= 0.0;
$DamageScale[sfemale, $ImpactDamageType] 	= 0.0;
$DamageScale[sfemale, $CrushDamageType] 	= 1.2;
$DamageScale[sfemale, $BulletDamageType]	= 1.0;
$DamageScale[sfemale, $PlasmaDamageType] 	= 1.1;
$DamageScale[sfemale, $NuclearDamageType]	= 1.9;
$DamageScale[sfemale, $EnergyDamageType] 	= 1.2;
$DamageScale[sfemale, $ExplosionDamageType] 	= 1.4;
$DamageScale[sfemale, $MissileDamageType] 	= 1.3;
$DamageScale[sfemale, $DebrisDamageType] 	= 1.1;
$DamageScale[sfemale, $ShrapnelDamageType] 	= 1.1;
$DamageScale[sfemale, $LaserDamageType] 	= 0.6;
$DamageScale[sfemale, $SniperDamageType] 	= 0.8;
$DamageScale[sfemale, $HeatDamageType]		= 0.4;
$DamageScale[sfemale, $MortarDamageType] 	= 1.7;
$DamageScale[sfemale, $RocketDamageType]	= 1.5;
$DamageScale[sfemale, $BlasterDamageType] 	= 1.2;
$DamageScale[sfemale, $ElectricityDamageType] 	= 1.3;
$DamageScale[sfemale, $MineDamageType]		= 1.0;

$ItemMax[sfemale, Blaster] 			= 1;
$ItemMax[sfemale, Chaingun] 			= 1;
$ItemMax[sfemale, Disclauncher] 		= 1;
$ItemMax[sfemale, GrenadeLauncher] 		= 1;
$ItemMax[sfemale, Nuke]				= 0;
$ItemMax[sfemale, Mortar] 			= 0;
$ItemMax[sfemale, RocketLauncher]		= 0;
$ItemMax[sfemale, PlasmaGun] 			= 1;
$ItemMax[sfemale, FusionRifle]			= 0;
$ItemMax[sfemale, LaserRifle] 			= 1;
$ItemMax[sfemale, SniperRifle] 			= 1;
$ItemMax[sfemale, HeatLaser]			= 1;
$ItemMax[sfemale, EnergyRifle] 			= 1;
$ItemMax[sfemale, TargetingLaser] 		= 1;
$ItemMax[sfemale, MineAmmo] 			= 10;
$ItemMax[sfemale, Grenade] 			= 10;
$ItemMax[sfemale, Beacon]  			= 10;
$ItemMax[sfemale, BulletAmmo] 			= 100;
$ItemMax[sfemale, PlasmaAmmo] 			= 30;
$ItemMax[sfemale, FusionAmmo]			= 0;
$ItemMax[sfemale, DiscAmmo] 			= 15;
$ItemMax[sfemale, GrenadeAmmo] 			= 10;
$ItemMax[sfemale, NukeAmmo]			= 0;
$ItemMax[sfemale, MortarAmmo] 			= 0;
$ItemMax[sfemale, RocketAmmo]			= 0;
$ItemMax[sfemale, EnergyPack] 			= 1;
$ItemMax[sfemale, RepairPack] 			= 1;
$ItemMax[sfemale, ShieldPack] 			= 1;
$ItemMax[sfemale, SensorJammerPack] 		= 1;
$ItemMax[sfemale, MotionSensorPack] 		= 0;
$ItemMax[sfemale, PulseSensorPack] 		= 0;
$ItemMax[sfemale, DeployableSensorJammerPack] 	= 1;
$ItemMax[sfemale, CameraPack] 			= 0;
$ItemMax[sfemale, TurretPack] 			= 0;
$ItemMax[sfemale, AmmoPack] 			= 1;
$ItemMax[sfemale, RepairKit] 			= 1;
$ItemMax[sfemale, DeployableInvPack] 		= 0;
$ItemMax[sfemale, DeployableAmmoPack] 		= 0;

$MaxWeapons[sfemale] = 4;

// "Assault" Armor (female)

$DamageScale[asfemale, $LandingDamageType] 	= 1.0;
$DamageScale[asfemale, $ImpactDamageType] 	= 1.0;
$DamageScale[asfemale, $CrushDamageType] 	= 1.2;
$DamageScale[asfemale, $BulletDamageType] 	= 1.0;
$DamageScale[asfemale, $PlasmaDamageType] 	= 1.1;
$DamageScale[asfemale, $NuclearDamageType]	= 1.6;
$DamageScale[asfemale, $EnergyDamageType] 	= 1.2;
$DamageScale[asfemale, $ExplosionDamageType] 	= 1.2;
$DamageScale[asfemale, $MissileDamageType] 	= 1.1;
$DamageScale[asfemale, $DebrisDamageType] 	= 1.1;
$DamageScale[asfemale, $ShrapnelDamageType] 	= 1.1;
$DamageScale[asfemale, $LaserDamageType] 	= 1.6;
$DamageScale[asfemale, $SniperDamageType] 	= 2.8;
$DamageScale[asfemale, $HeatDamageType]		= 1.0;
$DamageScale[asfemale, $MortarDamageType] 	= 1.3;
$DamageScale[asfemale, $RocketDamageType]	= 1.1;
$DamageScale[asfemale, $BlasterDamageType] 	= 1.2;
$DamageScale[asfemale, $ElectricityDamageType] 	= 1.3;
$DamageScale[asfemale, $MineDamageType]		= 1.0;

$ItemMax[asfemale, Blaster] 			= 1;
$ItemMax[asfemale, Chaingun] 			= 1;
$ItemMax[asfemale, Disclauncher] 		= 1;
$ItemMax[asfemale, GrenadeLauncher] 		= 1;
$ItemMax[asfemale, Nuke]			= 0;
$ItemMax[asfemale, Mortar] 			= 0;
$ItemMax[asfemale, RocketLauncher]		= 1;
$ItemMax[asfemale, PlasmaGun] 			= 1;
$ItemMax[asfemale, FusionRifle]			= 1;
$ItemMax[asfemale, LaserRifle] 			= 0;
$ItemMax[asfemale, SniperRifle] 		= 0;
$ItemMax[asfemale, HeatLaser]			= 1;
$ItemMax[asfemale, EnergyRifle] 		= 1;
$ItemMax[asfemale, TargetingLaser]		= 1;
$ItemMax[asfemale, MineAmmo] 			= 10;
$ItemMax[asfemale, Grenade] 			= 10;
$ItemMax[asfemale, Beacon]  			= 10;
$ItemMax[asfemale, BulletAmmo] 			= 100;
$ItemMax[asfemale, PlasmaAmmo] 			= 30;
$ItemMax[asfemale, FusionAmmo]			= 40;
$ItemMax[asfemale, DiscAmmo] 			= 15;
$ItemMax[asfemale, GrenadeAmmo] 		= 10;
$ItemMax[asfemale, NukeAmmo]			= 0;
$ItemMax[asfemale, MortarAmmo] 			= 0;
$ItemMax[asfemale, RocketAmmo]			= 10;
$ItemMax[asfemale, EnergyPack] 			= 1;
$ItemMax[asfemale, RepairPack] 			= 1;
$ItemMax[asfemale, ShieldPack] 			= 1;
$ItemMax[asfemale, SensorJammerPack] 		= 1;
$ItemMax[asfemale, MotionSensorPack] 		= 1;
$ItemMax[asfemale, PulseSensorPack] 		= 0;
$ItemMax[asfemale, DeployableSensorJammerPack] 	= 1;
$ItemMax[asfemale, CameraPack] 			= 0;
$ItemMax[asfemale, TurretPack] 			= 0;
$ItemMax[asfemale, AmmoPack] 			= 1;
$ItemMax[asfemale, RepairKit] 			= 1;
$ItemMax[asfemale, DeployableInvPack] 		= 0;
$ItemMax[asfemale, DeployableAmmoPack] 		= 0;

$MaxWeapons[asfemale] = 4;

// "medium" armor (female)

$DamageScale[mfemale, $LandingDamageType]	= 1.0;
$DamageScale[mfemale, $ImpactDamageType]	= 1.0;
$DamageScale[mfemale, $CrushDamageType]		= 1.0;
$DamageScale[mfemale, $BulletDamageType]	= 1.0;
$DamageScale[mfemale, $EnergyDamageType]	= 1.0;
$DamageScale[mfemale, $PlasmaDamageType]	= 0.6;
$DamageScale[mfemale, $NuclearDamageType]	= 1.3;
$DamageScale[mfemale, $ExplosionDamageType]	= 1.0;
$DamageScale[mfemale, $MissileDamageType]	= 1.0;
$DamageScale[mfemale, $ShrapnelDamageType]	= 1.0;
$DamageScale[mfemale, $DebrisDamageType]	= 1.0;
$DamageScale[mfemale, $HeatDamageType]		= 0.5;
$DamageScale[mfemale, $LaserDamageType]		= 1.0;
$DamageScale[mfemale, $SniperDamageType]	= 1.2;
$DamageScale[mfemale, $RocketDamageType]	= 1.0;
$DamageScale[mfemale, $MortarDamageType]	= 1.0;
$DamageScale[mfemale, $BlasterDamageType]	= 1.0;
$DamageScale[mfemale, $ElectricityDamageType]	= 1.0;
$DamageScale[mfemale, $MineDamageType]		= 1.0;

$ItemMax[mfemale, Blaster]			= 1;
$ItemMax[mfemale, Chaingun]			= 1;
$ItemMax[mfemale, Disclauncher]			= 1;
$ItemMax[mfemale, GrenadeLauncher]		= 1;
$ItemMax[mfemale, RocketLauncher]		= 1;
$ItemMax[mfemale, Nuke]				= 0;
$ItemMax[mfemale, Mortar]			= 0;
$ItemMax[mfemale, PlasmaGun]			= 1;
$ItemMax[mfemale, FusionRifle]			= 1;
$ItemMax[mfemale, LaserRifle]			= 0;
$ItemMax[mfemale, EnergyRifle]			= 1;
$ItemMax[mfemale, SniperRifle]			= 0;
$ItemMax[mfemale, HeatLaser]			= 0;
$ItemMax[mfemale, TargetingLaser]		= 1;
$ItemMax[mfemale, MineAmmo]			= 3;
$ItemMax[mfemale, Grenade]			= 6;
$ItemMax[mfemale, Beacon]			= 3;
$ItemMax[mfemale, BulletAmmo]			= 150;
$ItemMax[mfemale, PlasmaAmmo]			= 40;
$ItemMax[mfemale, FusionAmmo]			= 35;
$ItemMax[mfemale, DiscAmmo]			= 15;
$ItemMax[mfemale, GrenadeAmmo]			= 10;
$ItemMax[mfemale, NukeAmmo]			= 0;
$ItemMax[mfemale, MortarAmmo]			= 10;
$ItemMax[mfemale, RocketAmmo]			= 10;
$ItemMax[mfemale, EnergyPack]			= 1;
$ItemMax[mfemale, RepairPack]			= 1;
$ItemMax[mfemale, ShieldPack]			= 1;
$ItemMax[mfemale, SensorJammerPack]		= 1;
$ItemMax[mfemale, MotionSensorPack]		= 1;
$ItemMax[mfemale, PulseSensorPack]		= 1;
$ItemMax[mfemale, DeployableSensorJammerPack]	= 1;
$ItemMax[mfemale, CameraPack]			= 1;
$ItemMax[mfemale, TurretPack]			= 1;
$ItemMax[mfemale, AmmoPack]			= 1;
$ItemMax[mfemale, RepairKit]			= 1;
$ItemMax[mfemale, DeployableInvPack]		= 1;
$ItemMax[mfemale, DeployableAmmoPack]		= 1;

$MaxWeapons[mfemale] = 4;

// light armor data (male)

DamageSkinData armorDamageSkins
{
	bmpName[0] = "dskin1_armor";
	bmpName[1] = "dskin2_armor";
	bmpName[2] = "dskin3_armor";
	bmpName[3] = "dskin4_armor";
	bmpName[4] = "dskin5_armor";
	bmpName[5] = "dskin6_armor";
	bmpName[6] = "dskin7_armor";
	bmpName[7] = "dskin8_armor";
	bmpName[8] = "dskin9_armor";
	bmpName[9] = "dskin10_armor";
};

PlayerData larmor
{
	className = "Armor";
	shapeFile = "larmor";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 22;
	minJetEnergy = 1;
	jetForce = 236;
	jetEnergyDrain = 0.8;
	maxDamage = 0.66;
	maxForwardSpeed = 11;
	maxBackwardSpeed = 10;
	maxSideSpeed = 10;
	groundForce = 40 * 9.0;
	mass = 9.0;
	groundTraction = 3.0;
	maxEnergy = 60;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	rFootSounds = 
	{
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSnow,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft
	}; 
	lFootSounds =
	{
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSnow,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft
	};

	footPrints = { 0, 1 };
	boxWidth = 0.5;
	boxDepth = 0.5;
	boxNormalHeight = 2.3;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage  = 0.6666;
	boxCrouchTorsoPercentage = 0.3333;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// scout armor data (male)

PlayerData scarmor
{
	className = "Armor";
	shapeFile = "larmor";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.9;
	maxJetForwardVelocity = 30;
	minJetEnergy = 1;
	jetForce = 250;
	jetEnergyDrain = 0.4;
	maxDamage = 0.50;
	maxForwardSpeed = 15;
	maxBackwardSpeed = 12;
	maxSideSpeed = 12;
	groundForce = 40 * 9.0;
	mass = 6.0;
	groundTraction = 3.0;
	maxEnergy = 40;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	rFootSounds = 
	{
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSnow,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft
	}; 
	lFootSounds =
	{
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSnow,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft
	};

	footPrints = { 0, 1 };
	boxWidth = 0.5;
	boxDepth = 0.5;
	boxNormalHeight = 2.3;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage  = 0.6666;
	boxCrouchTorsoPercentage = 0.3333;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// sniper armor data (male)

PlayerData sarmor
{
	className = "Armor";
	shapeFile = "larmor";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = False;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 30;
	minJetEnergy = 1;
	jetForce = 245;
	jetEnergyDrain = 0.8;
	maxDamage = 0.66;
	maxForwardSpeed = 13;
	maxBackwardSpeed = 12;
	maxSideSpeed = 10;
	groundForce = 40 * 9.0;
	mass = 9.0;
	groundTraction = 3.0;
	maxEnergy = 60;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	rFootSounds = 
	{
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSnow,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft
	};
	lFootSounds =
	{
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSnow,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft
	};

	footPrints = { 0, 1 };
	boxWidth = 0.5;
	boxDepth = 0.5;
	boxNormalHeight = 2.3;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage  = 0.6666;
	boxCrouchTorsoPercentage = 0.3333;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// assault armor data (male)

PlayerData asarmor
{
	className = "Armor";
	shapeFile = "marmor";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 17;
	minJetEnergy = 1;
	jetForce = 320;
	jetEnergyDrain = 1.0;
	maxDamage = 1.0;
	maxForwardSpeed = 8.0;
	maxBackwardSpeed = 7.0;
	maxSideSpeed = 7.0;
	groundForce = 35 * 13.0;
	mass = 13.0;
	groundTraction = 3.0;
	maxEnergy = 80;
	drag = 1.0;
	density = 1.5;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 110;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	
	rFootSounds = 
	{
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSnow,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft
	}; 
	lFootSounds =
	{
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSnow,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft
	};

	footPrints = { 2, 3 };
	boxWidth = 0.7;
	boxDepth = 0.7;
	boxNormalHeight = 2.4;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.49;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// "medium" armor data (male)

PlayerData marmor
{
	className = "Armor";
	shapeFile = "marmor";
	flameShapeName = "mflame";
	shieldShapeName = "shield";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	shadowDetailMask = 1;
	canCrouch = false;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 17;
	minJetEnergy = 1;
	jetForce = 320;
	jetEnergyDrain = 1.0;
	maxDamage = 1.0;
	maxForwardSpeed = 8.0;
	maxBackwardSpeed = 7.0;
	maxSideSpeed = 7.0;
	groundForce = 35 * 13.0;
	mass = 13.0;
	groundTraction = 3.0;
	maxEnergy = 80;
	drag = 1.0;
	density = 1.5;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 110;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	
	rFootSounds = 
	{
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSnow,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft
	}; 
	lFootSounds =
	{
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSnow,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft
	};

	footPrints = { 2, 3 };
	boxWidth = 0.7;
	boxDepth = 0.7;
	boxNormalHeight = 2.4;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.49;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// "heavy" armor data (unisex)

PlayerData harmor
{
	className = "Armor";
	shapeFile = "harmor";
	flameShapeName = "hflame";
	shieldShapeName = "shield";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 12;
	minJetEnergy = 1;
	jetForce = 385;
	jetEnergyDrain = 1.1;
	maxDamage = 1.32;
	maxForwardSpeed = 5.0;
	maxBackwardSpeed = 4.0;
	maxSideSpeed = 4.0;
	groundForce = 35 * 18.0;
	groundTraction = 4.5;
	mass = 18.0;
	maxEnergy = 110;
	drag = 1.0;
	density = 2.5;
	canCrouch = false;
	minDamageSpeed = 25;
	damageScale = 0.006;
	jumpImpulse = 150;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetHeavy;

	rFootSounds = 
	{
		SoundHFootRSoft,
		SoundHFootRHard,
		SoundHFootRSoft,
		SoundHFootRHard,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRHard,
		SoundHFootRSnow,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft
	}; 
	lFootSounds =
	{
		SoundHFootLSoft,
		SoundHFootLHard,
		SoundHFootLSoft,
		SoundHFootLHard,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLHard,
		SoundHFootLSnow,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft
	};

	footPrints = { 4, 5 };
	boxWidth = 0.8;
	boxDepth = 0.8;
	boxNormalHeight = 2.6;
	boxNormalHeadPercentage  = 0.70;
	boxNormalTorsoPercentage = 0.45;
	boxHeadLeftPercentage  = 0.48;
	boxHeadRightPercentage = 0.70;
	boxHeadBackPercentage  = 0.48;
	boxHeadFrontPercentage = 0.60;
};

// "battlestar" armor data (unisex)

PlayerData bsarmor
{
	className = "Armor";
	shapeFile = "harmor";
	flameShapeName = "hflame";
	shieldShapeName = "shield";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	maxJetSideForceFactor = 0.3;
	maxJetForwardVelocity = 5;
	minJetEnergy = 1;
	jetForce = 385;
	jetEnergyDrain = 1.5;
	maxDamage = 5.00;
	maxForwardSpeed = 1.03;
	maxBackwardSpeed = 1.01;
	maxSideSpeed = 1.0;
	groundForce = 35 * 18.0;
	groundTraction = 6.5;
	mass = 22.3;
	maxEnergy = 110;
	drag = 1.0;
	density = 2.5;
	canCrouch = false;
	minDamageSpeed = 20;
	damageScale = 0.006;
	jumpImpulse = 150;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetHeavy;

	rFootSounds = 
	{
		SoundHFootRSoft,
		SoundHFootRHard,
		SoundHFootRSoft,
		SoundHFootRHard,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRHard,
		SoundHFootRSnow,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft,
		SoundHFootRSoft
	}; 
	lFootSounds =
	{
		SoundHFootLSoft,
		SoundHFootLHard,
		SoundHFootLSoft,
		SoundHFootLHard,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLHard,
		SoundHFootLSnow,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft,
		SoundHFootLSoft
	};

	footPrints = { 4, 5 };
	boxWidth = 0.8;
	boxDepth = 0.8;
	boxNormalHeight = 2.6;
	boxNormalHeadPercentage  = 0.70;
	boxNormalTorsoPercentage = 0.45;
	boxHeadLeftPercentage  = 0.48;
	boxHeadRightPercentage = 0.70;
	boxHeadBackPercentage  = 0.48;
	boxHeadFrontPercentage = 0.60;
};

// light armor data (female)

PlayerData lfemale
{
	className = "Armor";
	shapeFile = "lfemale";
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 22;
	minJetEnergy = 1;
	jetForce = 236;
	jetEnergyDrain = 0.8;
	maxDamage = 0.66;
	maxForwardSpeed = 11;
	maxBackwardSpeed = 10;
	maxSideSpeed = 10;
	groundForce = 40 * 9.0;
	mass = 9.0;
	groundTraction = 3.0;
	maxEnergy = 60;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;

	rFootSounds = 
	{
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSnow,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft
	}; 
	lFootSounds =
	{
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSnow,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft
	};

	footPrints = { 0, 1 };
	boxWidth = 0.5;
	boxDepth = 0.5;
	boxNormalHeight = 2.3;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage  = 0.85;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage  = 0.88;
	boxCrouchTorsoPercentage = 0.35;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// scout armor data (female)

PlayerData scfemale
{
	className = "Armor";
	shapeFile = "lfemale";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.9;
	maxJetForwardVelocity = 30;
	minJetEnergy = 1;
	jetForce = 250;
	jetEnergyDrain = 0.4;
	maxDamage = 0.50;
	maxForwardSpeed = 15;
	maxBackwardSpeed = 12;
	maxSideSpeed = 12;
	groundForce = 40 * 9.0;
	mass = 6.0;
	groundTraction = 3.0;
	maxEnergy = 40;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	rFootSounds = 
	{
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSnow,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft
	}; 
	lFootSounds =
	{
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSnow,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft
	};

	footPrints = { 0, 1 };
	boxWidth = 0.5;
	boxDepth = 0.5;
	boxNormalHeight = 2.3;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage  = 0.6666;
	boxCrouchTorsoPercentage = 0.3333;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// sniper armor data (female)

PlayerData sfemale
{
	className = "Armor";
	shapeFile = "lfemale";
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	shadowDetailMask = 1;
	visibleToSensor = False;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 30;
	minJetEnergy = 1;
	jetForce = 245;
	jetEnergyDrain = 0.8;
	maxDamage = 0.66;
	maxForwardSpeed = 13;
	maxBackwardSpeed = 12;
	maxSideSpeed = 10;
	groundForce = 40 * 9.0;
	mass = 9.0;
	groundTraction = 3.0;
	maxEnergy = 60;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	
	rFootSounds = 
	{
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRHard,
		SoundLFootRSnow,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft,
		SoundLFootRSoft
	}; 
	lFootSounds =
	{
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLHard,
		SoundLFootLSnow,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft,
		SoundLFootLSoft
	};

	footPrints = { 0, 1 };
	boxWidth = 0.5;
	boxDepth = 0.5;
	boxNormalHeight = 2.3;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage  = 0.85;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage  = 0.88;
	boxCrouchTorsoPercentage = 0.35;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// assault armor data (female)

PlayerData asfemale
{
	className = "Armor";
	shapeFile = "mfemale";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 17;
	minJetEnergy = 1;
	jetForce = 320;
	jetEnergyDrain = 1.0;
	maxDamage = 1.0;
	maxForwardSpeed = 8.0;
	maxBackwardSpeed = 7.0;
	maxSideSpeed = 7.0;
	groundForce = 35 * 13.0;
	mass = 13.0;
	groundTraction = 3.0;
	maxEnergy = 80;
	drag = 1.0;
	density = 1.5;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 110;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;
	
	rFootSounds = 
	{
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSnow,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft
	}; 
	lFootSounds =
	{
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSnow,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft
	};

	footPrints = { 2, 3 };
	boxWidth = 0.7;
	boxDepth = 0.7;
	boxNormalHeight = 2.4;
	boxNormalHeadPercentage  = 0.83;
	boxNormalTorsoPercentage = 0.49;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};

// "medium" armor data (female)

PlayerData mfemale
{
	className = "Armor";
	shapeFile = "mfemale";
	flameShapeName = "mflame";
	shieldShapeName = "shield";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	shadowDetailMask = 1;
	visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 17;
	minJetEnergy = 1;
	jetForce = 320;
	jetEnergyDrain = 1.0;
	canCrouch = false;
	maxDamage = 1.0;
	maxForwardSpeed = 8.0;
	maxBackwardSpeed = 7.0;
	maxSideSpeed = 7.0;
	groundForce = 35 * 13.0;
	mass = 13.0;
	groundTraction = 3.0;
	maxEnergy = 80;
	mass = 13.0;
	drag = 1.0;
	density = 1.5;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 110;
	jumpSurfaceMinDot = 0.2;

	animData[0]  = { "root", none, 1, true, true, true, false, 0 };
	animData[1]  = { "run", none, 1, true, false, true, false, 3 };
	animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
	animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
	animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
	animData[5]  = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6]  = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7]  = { "crouch root", none, 1, true, false, true, false, 3 };
	animData[8]  = { "crouch root", none, 1, true, false, true, false, 3 };
	animData[9]  = { "crouch root", none, -1, true, false, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
	animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };

	jetSound = SoundJetLight;

	rFootSounds = 
	{
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRHard,
		SoundMFootRSnow,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft,
		SoundMFootRSoft
	}; 
	lFootSounds =
	{
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLHard,
		SoundMFootLSnow,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft,
		SoundMFootLSoft
	};

	footPrints = { 2, 3 };
	boxWidth = 0.7;
	boxDepth = 0.7;
	boxNormalHeight = 2.4;
	boxNormalHeadPercentage  = 0.84;
	boxNormalTorsoPercentage = 0.55;
	boxHeadLeftPercentage  = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage  = 0;
	boxHeadFrontPercentage = 1;
};