----------------------------------------------------------------
Name: Insomniax.net IX-Admin Mod.
Version: 0.9 (For TRIBES Version 1.7 and above)
Date: 8-31-99
Author: Kevin Savage (*IX*Savage1)
Email: Savage1@insomniax.net
URL: http://www.insomniax.net/mods
Purpose: To lessen the burden of Server Admins, and make 
	 the overall play more managable. 

Notes:  This Mod Does NOT make changes to ANYTHING in Tribes\base. 
	This can be installed without harm to standard Tribes\base 
	games or any other mods. This Mod is NOT meant to be run 
	with Insomniax TRIBES. IX-Admin is Built into the Insomniax
	Mod. IX-Admin is a by product of it.  Combining them is
	pointless, and could generate problems with the mod. 

Thanks: To the Tribes Dev Team, and All those at Dynamix/Sierra that
	make this game possible. I'd also like to thank them for
	answering my emails with questions about this or that, and 
	taking bug reports. They seem to truely care about what goes 
	into the game. I admire them for that. Thanks.
	I'd also like to thank *IX*LongBow and others that took the time
	to test this or that whenever I asked "Hey, got a minute?". 
	Without that, I wouldn't have gotten nearly as much done. 
	Thanks. 

Known Bugs: Various problems occur when this mod is combined with others.

---------------------------------------------------------------

Client Install: NONE. 

Server Install: 
	1. Unzip IXAdmin09.zip into default Tribes Dir.
	   (where tribes.exe resides - UNZIP WITH PATH INFORMATION)
	This means:

	When installed The Files Should be here: 
		Tribes\config\ixadmin.cs
	 	Tribes\config\ixUserList.cs
		Tribes\ixadmin\admin.cs
		Tribes\ixadmin\baseProjData.cs
		Tribes\ixadmin\game.cs
		Tribes\ixadmin\Gui.cs
		Tribes\ixadmin\licence.txt
		Tribes\ixadmin\objectives.cs
		Tribes\ixadmin\player.cs
		Tribes\ixadmin\Readme.txt
		Tribes\ixadmin\server.cs
		Tribes\ixadmin\staticshape.cs
		Tribes\ixadmin\satation.cs
		Tribes\ixadmin\WhatsNew.txt
		Tribes\ixadmin\WhatsOld.txt
	 
	NOTE: If these files are not in these folders ..put them there.
	      IF THIS IS NOT THE FIRST TIME INSTALLING and you have the 
	      insomniax.cs file already you dont need to unzip this
	      one. You can choose to add the new variables, or not.
	      The server will choose default values. Settings can be
	      changed during the game and are saved when the server
	      exits normally. If you want to save the config while
	      the game is active just execute the ixSave(); command
	      at the console.
	
	2. Command line to run the mod.
	   (A command line is what you use to start the game.
	    for windows its called a shortcut. It's what you 
	    double click on to run the game.)

	   Just add "-mod insomniax" to your current Server Command Line.
	   For Example:
		Running Normally. 
			tribes.exe
		Running this Mod.
			tribes.exe -mod ixadmin

	   If you have a custom Server Config then add the +exec Parameter
	   BEFORE The -mod parameter. 	
	   For Example:
		Running Normally. 
			tribes.exe +exec MyConfig.cs
		Running this Mod.
			tribes.exe +exec MyConfig.cs -mod ixadmin

	   If your runing dedicated and have a special server config. 
	   I suggest you use infinitespawn. (get it at tribesplayers.com)
	   For Example:
		Running Normally. 
			infinitespawn *tribes +exec MyConfig -dedicated
		Running this Mod.
			infinitespawn *tribes +exec MyConfig -mod ixadmin -dedicated

	   If For Some Reason insomniax.cs is not executing when the mod loads. 
	   (It should be automatic) Then just add it to the command line.
	   For Example:
		Running Normally. 
			infinitespawn *tribes +exec MyConfig -dedicated
		Running this Mod and Executing the Mod Config.
			infinitespawn *tribes +exec MyConfig +exec ixadmin -mod ixadmin -dedicated

   If you dont know what im talking about then please learn
   how to run a server before yelling at me because you dont
   know how.

Here are a few URLs
	http://www.tribesplayers.com/tribesplayers/server-basic-config.html
 
	http://www.tribesplayers.com/tribesplayers/server-advanced-admin.html
 
	http://www.tribesplayers.com/tribesplayers/server-mods.html
 
	http://www.tribesplayers.com/tribesplayers/faq.html#sec1 


Full Instructions for the Mod can be found at the Mod Site (Still under construction)
	http://www.insomniax.net/mods

All Questions will be answered on the Mod message board.
Please post any and all feedback you have here. 
	http://www.insomniax.net/IXTribes.cgi. 


Uninstalling:

	Delete the Tribes\insomniax Directory and everything in it. 
	Delete ixadmin.cs and ixUserList.cs from within the 
	Tribes\config Directoy. All files are listed above. 
	THIS MOD DOES NOT CHANGE ANYTHING IN TRIBES\BASE.

---------------------------------------------------------------
Whats IN the Mod?
---------------------------------------------------------------

  Check the Files WhatsNew.txt for what is new with this 
  version of the mod. (Bug Fixes etc.) For more News and Info on 
  this mod go to the Mod Web site mentioned above. 

----------------------------------------------------------------
Disclaimer:
	    I am not responsible for any damage this game 
	    modification may cause you or anything having to do 
	    with you. If you lose your job because you play this
	    game nite and day, it is purely your responsibility.
	    I also am not responsible for any hardware failures 
	    or software problems that may arise in TRIBES. For 
	    problems of that nature contact the game manufacturer.
	    If you believe this modification has problems please 
	    report them to me so that I may look into it. 
		I am not responsible for any bugs or problems caused
	    from copying this code into another mod. I do not claim
	    to support any other mod using my code. If they have
	    problems, bother them, not me. -*IX*Savage1
----------------------------------------------------------------