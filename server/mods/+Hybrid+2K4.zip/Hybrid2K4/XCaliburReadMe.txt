I Give Credit To The Following People.

- |*|w00|*|Grey   I Learned How To Script By Reading Through GreyBOT's 
		  Scripts Over And Over, So I Give Grey Lots Of Credit
		  As Well As Anyone Else That Helped With GreyBOT.

- VRWarper        Anytime I Had A Question He Always Answered And
		  Helped Me Out A Lot.

- [GL]JadaCyrus   I Stripped The Whereis Function Straight From CoreMAN
		  And Give Jada Full Credit For It.

Now Onto The Commands

All You Have To Do Is Type These In Where You Would Normally Type To Chat.

*The Commands*

All You Have To Do Is Type These In Where You Would Normally Type To Chat.

*****************
*Public Commands*
*****************
	Command			Function

	Typing Nothing Into The Message Box Will Clear All Center, Top, and Bottom Printed Messages

        !XCalibur          	"Gives Server Stats"
        !XCredits          	"Gives Credit As Show Above"
	!+]-[+       		"Gives Info About Your Clan Tag" Already Filled In And In Xadmin.cs.
	!listadmins		"Lists All The Admins Currently In The Server"
	!stop 			"Stops You From Moving, Like An AirBreak"
	!pmsg personsname	"Sends A Private Message To The Name Specified"
	!urgent			"Sends An Urgent Message To Server Host In A File Called Urgent.txt"
	= message               "Putting = And Then Your Message Is Another Way To Send A Private Message. You Must Click Speak To On The Tab Menu First. The Message Will Send Itself To The Person Who You Clicked Speak To On.
	
****************
*Admin Commands*
****************
Admin Type	Command			Function

(PublicAdmin)	!playerlimit            "Sets How Many People Can Connect"
(PublicAdmin)	!cleanup  		"Kicks All But Admins"
(PublicAdmin) 	!PC Message		"Sends A Message To All Other Public Admins"
(SuperAdmin)	!SC Message		"Sends A Message To All Other Super Admins"
(SuperAdmin)    !centerprintall	Message	"Allows You To Type A Message And Have It Center Printed To Everyone (you can use <F0>, <F1>, <F2>, <jl>, <jc>, and <jr> before the message you type, but after the ! command"
(SuperAdmin)    !topprintall Message	"Allows You To Type A Message And Have It Top Printed To Everyone (you can use <F0>, <F1>, <F2>, <jl>, <jc>, and <jr> before the message you type, but after the ! command"
(SuperAdmin)    !bottomprintall	Message	"Allows You To Type A Message And Have It Bottom Printed To Everyone (you can use <F0>, <F1>, <F2>, <jl>, <jc>, and <jr> before the message you type, but after the ! command"
(SuperAdmin)    !cmsg Message 		"Allows You To Talk Anonymously With Color (!cmsg type message)(type can be any number 0 - 4)
(SuperAdmin)   	!msg Message		"Allows You To Talk Through XCalibur"
(GodAdmin)	!GC Message		"Sends A Message To All Other God-Admins"
(MasterAdmin)	!DMISTRUE          	"Allows You To De-Master-Admin Other Master-Admins, The Option Is Added To Your XCalibur Options Menu"
(MasterAdmin)   !MC Message		"Sends A Message To All Other Master-Admins"

****************
* Admin Logins *
****************

XCalibur Does Not Let You Get Admin Via The Console (No More sad("") )
Now You Have To Type It In As Specified Below.

To Login As A Public Admin:

	!PublicAdmin yourpublicadminpassword

To Login As A Super Admin:

	!SuperAdmin yoursuperadminpassword

To Login As A God Admin: 

	!GodAdmin yourgodadminpassword

To Login As A Master Admin:

	!MasterAdmin yourmasteradminpassword

NOTE: YOU CANNOT Type !PublicAdmin And Type A SuperAdmin Password.  It Won't Work.
You Can Only Use The Password Corresponding To The Type Of ! Admin Login Command 
You Are Using.

There Are More Commands, Relating To Kicking And Banning, As Well As More Relating To The X-List
They Will Be Explained As You Try To Use Them.

CLAN CHAT:

If You Turn Clan Chat On, If You Are In The Clan Specified In $ClanTag, Any Message Sent By Anyone Else
In The Clan Will Be Sent To Anyone In The Clan, And No One Else. You Will Not Be Able To Respond Any Other 
Way Until ClanChat Is Turned Off. Clan Chat Can Be Turned On Only By God-Admins And Master-Admins.  It Is Turned
On Through The Tab Menu Under Admin Menu.

Recordings:

XCalibur Records And Exports Everything Said In Your Server To A File Called chat.txt
XCalibur Records And Exports All Commands Used In Your Server To A File Called commands.txt
XCalibur Records And Exports All Connections Made To Your Server To A File Called Connections.txt (Don't worry about the other connection files.  You Can Open Them, But Don't Change Them Because It Could Cause The Alias Option To Not Function)
XCalibur Records And Exports All Reasons For Kicks And Bans, As Well As Ban Messages And Kick Messages And The Person That Did The Kick/Ban.  Same With X-List Related Stuff.
XCalibur Records And Exports All X-List Related Stuff. You Can Open The Files (GPW.cs, PPW.cs, SPW.cs, MPW.cs, MNames.cs, GNames.cs, SNames.cs, PNames.cs) But Don't Touch Anything In Them Unless You Know What Your Doing
XCalibur Records And Exports All Successful Admin Logins To A File Called AdminLog.txt All Unsuccessful Logins Go To A File Called Attempts.txt
If Someone Is An Imposter, XCalibur Records And Exports Their Info To A File Called imposters.txt
If Someone Is A Tagless Member, XCalibur Records And Exports Their Info To A File Called Tagless.txt

X-List:

The XCalibur X-List Was Created Entirly By Me (  WorstAim  ) And So Were All Its Functions.  
The X-List Allows You To Modify And Access All Information Relating To Admins and Bans Through The Tab Menu.
You Can Have As Many Admins Added To It, Same Goes With Bans, But, It Only Allows Access To 7 Players Of Each 
Type Of Admin, And Of Each Type Of Ban.  The Reason For This Is It Takes A Very Long Time To Make Each Menu, And 
Its Options Since Everyone Is A Completely Different One For Each Name.  7 Names = about 70 Or So Pages Of Code.
I Just Didn't Want To Make More Menu's.  It Would Take To Long.  So Don't Complain.

Thats About It. Hope You Like It.

-   WorstAim    -

XCalibur�  Are CopyRighted Under Copyright Law 17 102(a).