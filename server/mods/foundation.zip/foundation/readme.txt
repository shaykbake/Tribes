Foundation Mod readme.

   I'll keep this short and sweet for now, at least until I can be bothered to write more. This is a quick little mod, where all the weapons, armours, packs, and all other items have been split up into seperate script files ready for editing. The files are all registered upon startup through a list in ripserver.cs. This should make it nice and easy for mod authors to add their own item types. The mod is not really intended for use as a base for your own mod (there are better mods for you to base yours on), but it should be usefull as a learning aid for new modders. But by all means use it as a base if you really like it, just make sure to include some credit for me. :)

	- Nicodemus -


NOTES:

1: The explosion and debris data hasn't been moved to the item scripts. This is mainly due to an oversite on my part, but when I got to thinking about it I decided to leave it as it is. This is due to the fact that several scripts may call on a single piece of explosion or debris data. It's just simpler to leave them in their own script file. In case you're wondering what I'm talking about, look inside baseDebrisData.cs and baseExpData.cs.

2: When adding a new weapon, you should check that you have entered the appropriate data in the scripts missionreinitdata.cs, nextprevweapons.cs, & resupplylist.cs found in *\Tribes\foundation\scripts\. These script files contain functions from item.cs and station.cs, which I have relocated to seperate scripts for ease of use.

   missionreinitdata.cs contains data which (I think) removes all team items just prior to a level change (I may be wrong about this).

   nextprevweapons.cs contains a list of weapons that can be accessed via the next and previous weapons buttons. Make sure you enter any new weapons in here or you won't be able to access them for testing.

   resupplylist.cs contains data of all the ammo that will be resupplied by an ammo station, along with when to resupply it (you don't want to resupply ammo when a player doesn't have the weapon that uses it).