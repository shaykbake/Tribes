This sound pack is for the server and client side.
If you wish to run a server with DuelMOD, use this pack.
If you wish to hear the sounds on a server running DuelMOD, use this pack as well.

Unzip this zip file into your Tribes directory.  It will put the files into your
base directory automatically.

Enjoy it.

- Drink|Kahlua