Congrats !! You have a copy of the first beta of Shifterk 2-22-03 Gameplay is not much different than that of v1g. Here are the latest options

1) Added A new option for Eyecandy. Its a little twang to shifter. It changes the grav, emp turret, repair gun, and the laser rifles colors. In serverconfig.cs you can put in : Purple, Green, Blue, Red, and Orange. Which changes these things to these colors. **READ INSTRUCTIONS IN SERVERCONFIG.CS**

2) Somone noted that you couldnt deploy out of the invo any more and there were alot of flames about why it should be brought back. If sba dosent like it I might consider changing it..but for now...yes you can deploy out of the invo. (wahhoo)

3) Although I know in shifter there are many admins that like to be childish..yes I have added 1 (one) new option to play with you and your friends. Its called bounce and for now all it does is throw you across the map. I didnt work very hard on this becuase I had other bugs to fix. 

4) More admin options - To your benifit. Have you ever herad anyone say "hey kill that turret so we can duel" Well with k's new options you can do it with a click of the mouse. You can destroy all stations, gens, and turrets (turrets include every deployable in shifter). Also if you dont want them destroyed any more you can just click repair gens, stations, or turrets. *KEEP IN MIND* deployables cannot be repaired. 

5) Yet another option is Respawning players. You can now respawn players with an admin option. 

6) You can also Turn off Player damage. Which means no one can get hurt. obviously.

7) You can strip flags from players if you dont want capping (adding no cap option as we speak next beta)

Things im adding for next beta 

No capping option. 
Adding all armors (excluding eng, arb, and jugg) to greys duel mod. Editing bugs in duel mod.
Adding more and more to eyecandy. ~ new trails and different projectiles ~ *remember* you will  -----be able to disable eyecandy if you wish. 
Gonna fix up greys Perma ban most likly. 
Gonna do major work on match options. Not sure what yet lol. 
Admins will be able to change password from menu instead of console. 

Pending/Questionable ~ need suggestions
Another mode for mortar..~ Concussion Mortar ~ which will bounce you without hurting...
Also will be making New maps to jive things up! 
If you dont want this PLZ PLZ post. 

~~~~~~~~~~~~~~~~~~~~

NEED IDEAS !!!
email dmkilla@msn.com or killa_shifter@hotmail.com 

Thanks to : }E{ Holy for all beta testing, Plentonic for advice and beta testing. ~ Special thanks to: GreyFlcn. For helping me get started in modding 2 years ago.

______________ 

2-23-03

Added no osnipe option. and fixed the respawn bug, damage bug, and flag bug.

3-11-03

Added a cool smurf option. Will be adding much more to that. Killed lots of crash bugs. Also made everything off on tourny mode.  

3-21-03

3-21-03

Added an servercofig option to turn on or off t2 models so you can use t2 models and merc works correctly. Make it to false to turn them off...and true to turn it on.
Admin option for changing password durning the game to your second built in password that you defined in serverconfig.cs
Admin option for making people SUPER admin and NORMAL. Also you can deadmin super admins if you are super admin. 
Re did the menus so they look a little cleaner. 
~~~Right now I am working on reducing FPS. 
Also adding an option to turn off cap limit.

6-01-03

Well. Its nice seeing you again. Sorry been 3 months with no updating, ive been a very busy man. I will start to update 
it regularly now. Well heres the updates

Took out spam notify ~ going to have it notify admins with one simple msg instead of alot. 
Took out my admin ability. ~ sorry didnt think n e one would care. 
Now satchels can kill turrents with one hit..but bw's,ff's,shocks,bf's, platforms...can be easier killed with a magnum!!!

Thanx for all the support again. ~ Special thanks to Finz

Make sure you drop by www.sxt.planetubh.com for Shifter Xtreme Tournys which are starting up soon. 
Also drop in on me in tribes, tribes 2, or battlefield 1942. 
                     KiLL(--) KiLL(--)      :}|3H{:Gen. Blue@ngel 

6-07-03

Fixed alot this time.

1) Super admin bug
2) Rapid plasma tweak
3) Sticky no longer works
4) Removed ip logger notify..now it just notifys admins
5) Increased Rail speed a hair
6) Spam messege if you use sticky. 
7) Increased Plasma Turret speed a tad 
8) Destroy all actullys destroys everything and fix all works too. 

Things to look for on next release:

1) 1v1 option
2) auto d disabled
3) nofog detection
4) admin screen shot command
5) in game dueling
6) more to come...

New member of ShifterK team : enV joined up. thanx for the help env. 
 