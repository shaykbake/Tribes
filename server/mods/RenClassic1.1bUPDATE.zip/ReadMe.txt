
                        RenWerX
                         (FTA)
              The original creators of Renegades
                  www.planetrenegades.com
 			brings you

               ******Renegades Classic******
                       Version 1.1b



This is an **update patch** to Renegades Classic.  You must have version 1.1a installed
to take advantage of the admin features.  

The following is a list of changes over Renegades Classic 1.1a


**********************************************************************************************

*****************************
***Fixes/bugs/enhancements
*****************************

1)  Fixed an issue whereby a player could bypass the menu commands and gain unauthorized 
    admin status on a server.  Protection added to other menus and commands to prevent
    future tampering.  Any attempts to access any menu in this fashion will result in the
    player being banned as well as the players name and IP being logged in the kicklist.
    (I wouldn't test it if I were you)

2)  Plasma, Rail, Missile, and Vulcan turrets can no longer be clipped far enough to a wall, floor,
    or ceiling that would allow it to fire through the other side.

**********************************************************************************************

NOTES:
   I did a brief test on the changes, and everything seems to work as expected.  If you find any issues
   with this patch please let me know at snypress@planetrenegades.com



Installation:

   Extract the scripts.vol into your dynamix\tribes\renegades directory overwriting your older scripts.vol.


Coding by: Snypress

