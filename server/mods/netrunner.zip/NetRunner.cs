$NetRunner::VoteAdmin = True;		// Allows users to vote an admin
$NetRunner::VoteKick = True;		// Allows users to kick players by vote
$NetRunner::KeepBalanced = True;	// Keeps the teams balanced
$NetRunner::VoteDTD = True;		// Allows players to enable Team Damage on/off by vote
$NetRunner::VoteFFA = True;		// Allows players to enable/disable Tournament mode by vote
$NetRunner::TeamDamageScale = 1.0;	// How much damage team-mates take from shots if Team Damage is enabled
$NetRunner::ScoreMulti = 3.0;		// Determines how many points players receive for kills.  Adjust to suit.
$NetRunner::CreditsMulti = 10.0;	// Credits are determined by points.  This determines how many credits per point players receive.
$NetRunner::TestMode = False;		// All Weapons and Armors Available

// Global Game Variables
$AutoRespawn = 0;				// Respawn automatically after X sec's -If 0..no respawn
$ItemPopTime = 30;			// Time it takes for items to disappear after they've been dropped.
$ItemRespawnTime = 30;			// (Rate is sec's) Spinning items respawn
$WaitThrowTime = 2;			// Time in sec player must wait before he can throw a Grenade or Mine after leaving a station.
$flagToStandTime = 180;			// Time player has to put flag in flagstand before it gets returned to its flag stand. 
$InfiniteCreds = False;			// Ignores the credits of the players if True
$InitialPlayerEnergy = 1000;		// Initial Player credits
$ServerCheats = 0;			// CHEATS
$TestCheats = 0;				// CHEATS
$RandomMissions = True;			// Random missions chosen

// Auto Lists...  An axample of each is here.
// AutoAdmins verify both from the name and the address.  You must have both for this to work. IsSuper is True or False or can be left out.
$NetRunner::AutoAdmin[0] = "{DS} Stiletto";
$NetRunner::AutoAdminAddr[0] = "IP:24.15.239.254";
$NetRunner::IsSuperAdmin[0] = TRUE;
$NetRunner::AutoAdmin[1] = "[D.LORD]Arkfire";
$NetRunner::AutoAdminAddr[1] = "IP:24.216.181.251";
$NetRunner::IsSuperAdmin[1] = TRUE;
// AutoBan and AutoMute verify from name and/or address. You only have to list one for it to work, but if both are listed both must belong to the player in question.
//$NetRunner::AutoBan[0] = "Joe Shmoe";
//$NetRunner::AutoBanAddr[0] = "IP:171.217.198.121";
//$NetRunner::AutoMute[0] = "Gheghis Marauder";
//$NetRunner::AutoMuteAddr[0] = "IP:19.63.5.2";