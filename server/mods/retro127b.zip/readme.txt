-=*=-=*=-=*=-=*=-=*=-=*=-=*=-
Retrogear
1.25b

Author: Mustang
-=*=-=*=-=*=-=*=-=*=-=*=-=*=-

Client-side Installation:
	none, technically. They might want to download the keyboard
	configuration, as it updates the 1-8 keys to use the new
	weapons
Server-side Installation:
	Make a folder called "retro" in the dynamix\tribes directory
	and copy the scripts.vol file into there. Then run by typing
	"tribes -mod retro" at the console. 	

Changes:
    Added:
	AK-47
	H&K MP5
	AKSU-74
	Dragunov SVD
	DShK Heavy Machinegun
	RPG
	Combat Shotgun
	Hellfire Artillery System
	Flame Thrower
	C4

   Removed:
	Blaster
	Plasma Gun
	Chaingun
	Disk Launcher
	Laser Rifle
	Shield Pack

Initial Player Loadout:
	- Flack Jacket
	- AK-47 (75 rounds)
	- Repair Pack
	- Repair Kit
	- Grenades (3)

Armor Factors
--------------------------
Flack Jacket - 0.35
Urban Assault - 0.60
Kevlar Body Armor - 0.75