							===============
							Shifter V1 Beta
							===============

Shifter_V1 Beta Read Me...

Firstly you will need to install the files for Shifter in the correct directorys.

1) Create a directory under your Dynamix/Tribes directory called Shifter_v1
2) Put the scripts.vol in this directory.
3) Open the Shifter_v1.cs in your favorite text editor and configure.
4) Place the Shifter_v1.cs in you /Dynamix/Tribes/Config directory.
5) Open the Spawn.bat in your favorite text editor and change the path acordingly.
6) Place the spawn.bat in your /Dynamix/Tribes directory.

	You Shifter_V1 Modded server should be up and running now.
	
	If you have any questions, comments or suggestions please send them to me,
Emo1313@dopplegangers.dynip.com, you can also log into a Shifter_v1 server at
the following addesss 209.196.97.170:28001 just bring up the console in Tribes
and type connect("209.196.97.170:28001"); and hit enter if you can not find us
in the master list.

 Thanks
 Emo1313