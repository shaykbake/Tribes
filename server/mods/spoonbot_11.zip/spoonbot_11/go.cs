$BotTree::Filename = "config\\BotTree2_" @ $missionName @ ".cs";
export("$BotTree::Treepoint*", $BotTree::Filename, false);
