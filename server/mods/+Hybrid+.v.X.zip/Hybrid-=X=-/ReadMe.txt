Ok installation is simple
Put all files in Dynamix\Tribes\Config Folder
Then

Add This to your Tribes  Application Target Line
C:\Dynamix\Tribes\Tribes.exe -mod -=:|Hybrid-X|:=-

or this if your running a dedicated server.
C:\Dynamix\Tribes\Tribes.exe -mod -=:|Hybrid-X|:=- -dedicated

This mod is hack proof & has Alias Scan running ;)