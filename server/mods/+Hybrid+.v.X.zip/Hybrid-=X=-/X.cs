//Here is all your admin contorl PW's
//There is only one type of admin to take out some confussion
//AdminPassword = "whatever" is your only Password for admin, so be careful with it ;)

$TelnetPort = "666";
$TelnetPassword = "SameChangeThis";
$AdminPassword = "PutYouPassWordHereBuddy!";

