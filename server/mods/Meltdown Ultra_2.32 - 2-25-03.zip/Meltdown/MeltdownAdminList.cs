//=========================================================================================================================================
// AutoAdmin Options
//=========================================================================================================================================

//==== Wild card IP's must just be left blank. Do NOT use the * in place of an octet. Note below for an example.
//==== NEW AutoAdmin - SAD Password Assignments

//==== NOTE : ALL OF THESE LINES MUST BE PRESENT FOR AUTO/SAD ADMIN TO WORK - PER PLAYER!!!

$MD::Admin["autoa", ")WAR(Defender"] = 1;			//== (0 or 1) 1 Turns ON AutoAdmin
$MD::Admin["noban", ")WAR(Defender"] = 1;			//== (0 or 1) 1 Adds player to NOBan list
$MD::Admin["ipadr", ")WAR(Defender"] = "IP:4.60.105";	//== Ip mask for AutoAdmining check (Left blank will NOT Autoadmin, MUST contain an IP mask to Autoadmin)
$MD::Admin["sadpw", ")WAR(Defender"] = "";	//== Optional SAD password for user - Left blank user will NOT be able to use SAD ability.
$MD::Admin["admin", ")WAR(Defender"] = 1;			//== (0 or 1) 1 Sets User to Normal Admin
$MD::Admin["super", ")WAR(Defender"] = 1;			//== (0 or 1) 1 Sets User to BOTH Normal/SuperAdmin

$MD::Admin["autoa", "YourName"] = 0;			//== (0 or 1) 1 Turns ON AutoAdmin
$MD::Admin["noban", "YourName"] = 0;			//== (0 or 1) 1 Adds player to NOBan list
$MD::Admin["ipadr", "YourName"] = "YourIP:4.60.105";	//== Ip mask for AutoAdmining check (Left blank will NOT Autoadmin, MUST contain an IP mask to Autoadmin)
$MD::Admin["sadpw", "YourName"] = "";	//== Optional SAD password for user - Left blank user will NOT be able to use SAD ability.
$MD::Admin["admin", "YourName"] = 0;			//== (0 or 1) 1 Sets User to Normal Admin
$MD::Admin["super", "YourName"] = 0;			//== (0 or 1) 1 Sets User to BOTH Normal/SuperAdmin

$MD::Admin["autoa", "YourName"] = 0;			//== (0 or 1) 1 Turns ON AutoAdmin
$MD::Admin["noban", "YourName"] = 0;			//== (0 or 1) 1 Adds player to NOBan list
$MD::Admin["ipadr", "YourName"] = "YourIP:4.60.105";	//== Ip mask for AutoAdmining check (Left blank will NOT Autoadmin, MUST contain an IP mask to Autoadmin)
$MD::Admin["sadpw", "YourName"] = "";	//== Optional SAD password for user - Left blank user will NOT be able to use SAD ability.
$MD::Admin["admin", "YourName"] = 0;			//== (0 or 1) 1 Sets User to Normal Admin
$MD::Admin["super", "YourName"] = 0;			//== (0 or 1) 1 Sets User to BOTH Normal/SuperAdmin

$MD::Admin["autoa", "YourName"] = 0;			//== (0 or 1) 1 Turns ON AutoAdmin
$MD::Admin["noban", "YourName"] = 0;			//== (0 or 1) 1 Adds player to NOBan list
$MD::Admin["ipadr", "YourName"] = "YourIP:4.60.105";	//== Ip mask for AutoAdmining check (Left blank will NOT Autoadmin, MUST contain an IP mask to Autoadmin)
$MD::Admin["sadpw", "YourName"] = "";	//== Optional SAD password for user - Left blank user will NOT be able to use SAD ability.
$MD::Admin["admin", "YourName"] = 0;			//== (0 or 1) 1 Sets User to Normal Admin
$MD::Admin["super", "YourName"] = 0;			//== (0 or 1) 1 Sets User to BOTH Normal/SuperAdmin

$MD::Admin["autoa", "YourName"] = 0;			//== (0 or 1) 1 Turns ON AutoAdmin
$MD::Admin["noban", "YourName"] = 0;			//== (0 or 1) 1 Adds player to NOBan list
$MD::Admin["ipadr", "YourName"] = "YourIP:4.60.105";	//== Ip mask for AutoAdmining check (Left blank will NOT Autoadmin, MUST contain an IP mask to Autoadmin)
$MD::Admin["sadpw", "YourName"] = "";	//== Optional SAD password for user - Left blank user will NOT be able to use SAD ability.
$MD::Admin["admin", "YourName"] = 0;			//== (0 or 1) 1 Sets User to Normal Admin
$MD::Admin["super", "YourName"] = 0;			//== (0 or 1) 1 Sets User to BOTH Normal/SuperAdmin

//== Local IP's (Assuming you have a LAN connection to the server and are not worried about band width from connecting Lan players,
// You can increase the limit when a player from this IP Mask connects.
//$Meltdown::LocalNetMask = " ";


//=========================================================================================================================================



