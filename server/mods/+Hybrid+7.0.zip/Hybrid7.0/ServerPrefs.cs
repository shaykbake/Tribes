//***************************************//
//       +Hybrid 7.0 By: Armagedon       //
//    Designed For The Great +]-[+ Clan  //
//      Server Settup For +Hybrid+       //
//***************************************//

$Server::Address = "IP:66.75.88.233:28001";
$Server::AutoAssignTeams = "true";
$Server::CurrentMaster = "0";
$Server::fairteams = "true";
$Server::FloodProtectionEnabled = "false";
$Server::HostName = "+Hybrid+ 7.0 Basic Settup";
$Server::HostPublicGame = "true";
$Server::Info = "<jc><f1>+Hybrid+ v7.0 Basic Settup\n<f3>Admin: <f2>(Names)\n<f3>Email:(Yours)\n<f3>Mod Info: <f2>ArmagedonSexGod@aol.com\n<jc><f1>www.HTribe.cjb.net";
$Server::JoinMOTD = "<jc><f1>Message of the Day:\nWelcome to +Hybrid+ v7.0\nDon't be stupid...Don't Disrespect.....Don't Be a Dick!\n\nFire For Chaos!!!";
$Server::Master1 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";
$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "Tribes Master";
$Server::MasterName1 = "UK Tribes Master";
$Server::MasterName2 = "Australian Tribes Master";
$Server::MaxPlayers = "12";
$Server::MinVotes = "1";
$Server::MinVotesPct = "0.5";
$Server::MinVoteTime = "45";
$Server::numMasters = "3";
$Server::PABan = "false";
$Server::PAFairTeams = "true";
$Server::PAKick = "true";
$Server::PAMission = "true";
$Server::PAModOptions = "false";
$Server::PAResetDefaults = "false";
$Server::PATeamChange = "true";
$Server::PATeamDamage = "true";
$Server::PATeamInfo = "true";
$Server::PATimeLimit = "true";
$Server::PATourneyMode = "true";
$Server::PAVote = "false";
$Server::Port = "28001";
$Server::PSkin = "true";
$Server::PVFairTeams = "true";
$Server::PVKick = "true";
$Server::PVMission = "true";
$Server::PVTeamDamage = "true";
$Server::PVTourneyMode = "true";
$Server::respawnTime = "2";
$Server::SafeStation = "true";
$Server::StationTime = "15";
$Server::TeamDamageScale = "1";
$Server::teamName0 = "+]-[ybrids+";
$Server::teamName1 = "Others";
$Server::teamName2 = "Generic 1";
$Server::teamName3 = "Generic 2";
$Server::teamName4 = "Generic 3";
$Server::teamName5 = "Generic 4";
$Server::teamName6 = "Generic 5";
$Server::teamName7 = "Generic 6";
$Server::teamSkin0 = "hybrid";
$Server::teamSkin1 = "dsword";
$Server::teamSkin2 = "base";
$Server::teamSkin3 = "base";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";
$Server::timeLimit = "0";
$Server::tkClientLvl = "0";
$Server::tkLimit = "3";
$Server::tkMultiple = "2";
$Server::tkServerLvl = "2";
$Server::TourneyMode = "false";
$Server::VoteAdminWinMargin = "9999";
$Server::VoteFailTime = "30";
$Server::VoteWinMargin = "9999";
$Server::VotingTime = "20";
$Server::warmupTime = "20";
$Server::XLMaster1 = "IP:64.94.105.150:28000";
$Server::XLMaster2 = "IP:Broadcast:28001";
$Server::XLMasterN0 = "IP:63.251.143.245:28000";
$Server::XLMasterN1 = "IP:64.94.105.149:28000";
$Server::XLMasterN2 = "IP:198.74.40.67:28000";
$pref::LastMission = "Rollercoaster";

//************************************//
// Questions E-Mail +]-[+Armagedon+   //
//   At: ArmagedonSexGod@Aol.com      //
//      AIM: ArmagedonSexGod          //
//          ::WebSites::              //
//       www.HTribe.cjb.net           //
//      www.Hybrid.webhop.net         //
//      www.Orion420.cjb.net          //
//************************************//
