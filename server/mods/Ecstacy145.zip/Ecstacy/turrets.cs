// ====================== ======================== ===================== turrets.cs MegaMan 1024
// ====================== Successor to turret.cs -- No confusion

