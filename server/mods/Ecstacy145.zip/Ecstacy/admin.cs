$curVoteTopic = "";
$curVoteAction = "";
$curVoteOption = "";
$curVoteCount = 0;
$tempmenu = "";

function Admin::changeMissionMenu(%clientId)
{
   Client::buildMenu(%clientId, "Pick Mission Type", "cmtype", true);
   %index = 1;
   for(%type = 1; %type < $MLIST::TypeCount; %type++)
      if($MLIST::Type[%type] != "Training")
      {
         Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type], %type @ " 0");
         %index++;
      }
}

function processMenuCMType(%clientId, %options)
{
   %curItem = 0;
   %option = getWord(%options, 0);
   %first = getWord(%options, 1);
   Client::buildMenu(%clientId, "Pick Mission", "cmission", true);
   
   for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%option], %first + %i)) != -1; %i++)
   {
      if(%i > 6)
      {
         Client::addMenuItem(%clientId, %i+1 @ "More missions...", "more " @ %first + %i @ " " @ %option);
         break;
      }
      Client::addMenuItem(%clientId, %i+1 @ $MLIST::EName[%misIndex], %misIndex @ " " @ %option);
   }
}

function processMenuCMission(%clientId, %option)
{
   if(getWord(%option, 0) == "more")
   {
      %first = getWord(%option, 1);
      %type = getWord(%option, 2);
      processMenuCMType(%clientId, %type @ " " @ %first);
      return;
   }
   %mi = getWord(%option, 0);
   %mt = getWord(%option, 1);

   %misName = $MLIST::EName[%mi];
   %misType = $MLIST::Type[%mt];

   // verify that this is a valid mission:
   if(%misType == "" || %misType == "Training")
      return;
   for(%i = 0; true; %i++)
   {
      %misIndex = getWord($MLIST::MissionList[%mt], %i);
      if(%misIndex == %mi)
         break;
      if(%misIndex == -1)
         return;
   }
   // Added Public Admin toggle - *IX*Savage1
   if(($Ecstacy::PAMission && %clientId.isAdmin) || (%clientId.isSuperAdmin))
   {
     	messageAll(0, Client::getName(%clientId) @ " changed the mission to " @ %misName @ " (" @ %misType @ ")");
	Vote::changeMission();
	Server::loadMission(%misName);
   }
   else
   {
	Admin::startVote(%clientId, "change the mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName);
	Game::menuRequest(%clientId);
   }
}

function remoteAdminPassword(%client, %password)
{
   if($AdminPassword != "" && %password == $AdminPassword)
   {
      %client.isAdmin = true;
      %client.isSuperAdmin = true;
   }
}

function remoteSetPassword(%client, %password)
{
   if(%client.isSuperAdmin)
      $Server::Password = %password;
}

function remoteSetTimeLimit(%client, %time)
{
   %time = floor(%time);
   if(%time == $Server::timeLimit || (%time != 0 && %time < 1))
      return;
   if(%client.isAdmin)
   {
      $Server::timeLimit = %time;
      if(%time)
         messageAll(0, Client::getName(%client) @ " changed the time limit to " @ %time @ " minute(s).");
      else
         messageAll(0, Client::getName(%client) @ " disabled the time limit.");
         
   }
}

function remoteSetTeamInfo(%client, %team, %teamName, %skinBase)
{
   if(%team >= 0 && %team < 8 && %client.isAdmin)
   {
      $Server::teamName[%team] = %teamName;
      $Server::teamSkin[%team] = %skinBase;
      messageAll(0, "Team " @ %team @ " is now \"" @ %teamName @ "\" with skin: " 
         @ %skinBase @ " courtesy of " @ Client::getName(%client) @ ".  Changes will take effect next mission.");
   }
}

function remoteVoteYes(%clientId)
{
   %clientId.vote = "yes";
   centerprint(%clientId, "", 0);
}

function remoteVoteNo(%clientId)
{
   %clientId.vote = "no";
   centerprint(%clientId, "", 0);
}

function Admin::startMatch(%admin)
{
   if(%admin == -1 || %admin.isAdmin)
   {
      if(!$CountdownStarted && !$matchStarted)
      {
         if(%admin == -1)
            messageAll(0, "Match start countdown forced by vote.");
         else
            messageAll(0, "Match start countdown forced by " @ Client::getName(%admin));
      
         Game::ForceTourneyMatchStart();
      }
   }
}

function Admin::setTeamDamageEnable(%admin, %enabled)
{
   if(%admin == -1 || %admin.isAdmin)
   {
      if(%enabled)
      {
         $Server::TeamDamageScale = 1;
         if(%admin == -1)
            messageAll(0, "Team damage set to ENABLED by consensus.");
         else
            messageAll(0, Client::getName(%admin) @ " ENABLED team damage.");
      }
      else
      {
         $Server::TeamDamageScale = 0;
         if(%admin == -1)
            messageAll(0, "Team damage set to DISABLED by consensus.");
         else
            messageAll(0, Client::getName(%admin) @ " DISABLED team damage.");
      }
   }
}

// Added TK Code - Different Kick Handleing - *IX*Savage1
// Admin == -2 = Team Kill Kick Handler (Server)
// Admin == -3 = Client Kick of TK.
function Admin::kick(%admin, %client, %ban)
{
   if((%admin == -1 || %admin.isAdmin) || (%admin == -2 || %admin == -3))
   {
      if(%ban)
      {
         %word = "banned";
         %cmd = "Screw: ";
      }
      else
      {
         %word = "kicked";
         %cmd = "cum sucking: ";
      }
      if(%client.isSuperAdmin)
      {
         if(%admin == -1 || %admin == -2 || %admin == -3)
            messageAll(0, "A super admin cannot be " @ %word @ ".");
         else
            Client::sendMessage(%admin, 0, "A super admin cannot be " @ %word @ ".");
         return;
      }
      %ip = Client::getTransportAddress(%client);

      echo(%cmd @ %admin @ " " @ %client @ " " @ %ip);

      if(%ip == "")
         return;
      Insomniax_leaveGame(%client);
	if(%ban)
         BanList::add(%ip, 1800);
      else
         BanList::add(%ip, $Ecstacy::BanKickTime);

      %name = Client::getName(%client);

      if(%admin == -1)
      {
         MessageAll(0, %name @ " was " @ %word @ " from vote.");
         Net::kick(%client, "You were " @ %word @ " by  consensus.");
      }
      else if(%admin == -2)
      {
         MessageAll(0, %name @ " was Auto-" @ %word @ " for Team Killing.");
         Net::kick(%client, "You were Auto-" @ %word @ " for Team Killing.");
      }
	else if(%admin == -3)
      {
         MessageAll(0, %name @ " was " @ %word @ " by a TK-Victim.");
         Net::kick(%client, "You were " @ %word @ " by a TK-Victim.");
      }
	else 
      {
         MessageAll(0, %name @ " was " @ %word @ " by " @ Client::getName(%admin) @ ".");
         Net::kick(%client, "You were " @ %word @ " by " @ Client::getName(%admin));
      }
   }
}

function Admin::setModeFFA(%clientId)
{
   if($Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
   {
      $Server::TeamDamageScale = 0;
      if(%clientId == -1)
         messageAll(0, "Server switched to Free-For-All Mode.");
      else
         messageAll(0, "Server switched to Free-For-All Mode by " @ Client::getName(%clientId) @ ".");

      $Server::TourneyMode = false;
      centerprintall(); // clear the messages
      if(!$matchStarted && !$countdownStarted)
      {
         if($Server::warmupTime)
            Server::Countdown($Server::warmupTime);
         else   
            Game::startMatch();
      }
   }
}

function Admin::setModeTourney(%clientId)
{
   if(!$Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
   {
      $Server::TeamDamageScale = 1;
      if(%clientId == -1)
         messageAll(0, "Server switched to Tournament Mode.");
      else
         messageAll(0, "Server switched to Tournament Mode by " @ Client::getName(%clientId) @ ".");

      $Server::TourneyMode = true;
      Server::nextMission();
   }
}

function Admin::voteFailed()
{
   $curVoteInitiator.numVotesFailed++;

   if($curVoteAction == "kick" || $curVoteAction == "admin" || $curVoteAction == "tkkick")
      $curVoteOption.voteTarget = "";
}

function Admin::voteSucceded()
{
   $curVoteInitiator.numVotesFailed = "";
   if($curVoteAction == "kick")
   {
      if($curVoteOption.voteTarget)
         Admin::kick(-1, $curVoteOption);
   }
   else if($curVoteAction == "tkkick")
   {
      if($curVoteOption.voteTarget)
         Admin::kick(-2, $curVoteOption);
   }
   else if($curVoteAction == "admin")
   {
      if($curVoteOption.voteTarget)
      {
         $curVoteOption.isAdmin = true;
         messageAll(0, Client::getName($curVoteOption) @ " has become an administrator.");
         if($curVoteOption.menuMode == "options")
            Game::menuRequest($curVoteOption);
      }
      $curVoteOption.voteTarget = false;
   }
   else if($curVoteAction == "cmission")
   {
      messageAll(0, "Changing to mission " @ $curVoteOption @ ".");
		Vote::changeMission();
      Server::loadMission($curVoteOption);
   }
   else if($curVoteAction == "tourney")
      Admin::setModeTourney(-1);
   else if($curVoteAction == "ffa")
      Admin::setModeFFA(-1);
   else if($curVoteAction == "etd")
      Admin::setTeamDamageEnable(-1, true);
   else if($curVoteAction == "dtd")
      Admin::setTeamDamageEnable(-1, false);
   else if($curVoteOption == "smatch")
      Admin::startMatch(-1);
}

function Admin::countVotes(%curVote)
{
   // if %end is true, cancel the vote either way
   if(%curVote != $curVoteCount)
      return;

   %votesFor = 0;
   %votesAgainst = 0;
   %totalClients = 0;
   %totalVotes = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      %totalClients++;
      if(%cl.vote == "yes")
      {
         %votesFor++;
         %totalVotes++;
      }
      else if(%cl.vote == "no")
      {
         %votesAgainst++;
         %totalVotes++;
      }
   }
   %minVotes = floor($Server::MinVotesPct * %totalClients);
   if(%minVotes < $Server::MinVotes)
      %minVotes = $Server::MinVotes;

   if(%totalVotes < %minVotes)
   {
      %votesAgainst += %minVotes - %totalVotes;
      %totalVotes = %minVotes;
   }
   if(%votesFor / %totalVotes >= $Server::VoteWinMargin)
   {
      messageAll(0, "Vote to " @ $curVoteTopic @ " passed: " @ %votesFor @ " to " @ %votesAgainst @ " with " @ %totalClients - (%votesFor + %votesAgainst) @ " abstentions.");
      Admin::voteSucceded();
   }
   else  // special team kick option:
   {
      if($curVoteAction == "kick") // check if the team did a majority number on him:
      {
         %votesFor = 0;
         %totalVotes = 0;
         for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         {
            if(GameBase::getTeam(%cl) == $curVoteOption.kickTeam)
            {
               %totalVotes++;
               if(%cl.vote == "yes")
                  %votesFor++;
            }
         }
         if(%totalVotes >= $Server::MinVotes && %votesFor / %totalVotes >= $Server::VoteWinMargin)
         {
            messageAll(0, "Vote to " @ $curVoteTopic @ " passed: " @ %votesFor @ " to " @ %totalVotes - %votesFor @ ".");
            Admin::voteSucceded();
            $curVoteTopic = "";
            return;
         }
      }
      messageAll(0, "Vote to " @ $curVoteTopic @ " did not pass: " @ %votesFor @ " to " @ %votesAgainst @ " with " @ %totalClients - (%votesFor + %votesAgainst) @ " abstentions.");
      Admin::voteFailed();
   }
   $curVoteTopic = "";
}

function Admin::startVote(%clientId, %topic, %action, %option)
{
   if(%clientId.lastVoteTime == "")
      %clientId.lastVoteTime = -$Server::MinVoteTime;

   // we want an absolute time here.
   %time = getIntegerTime(true) >> 5;
   %diff = %clientId.lastVoteTime + $Server::MinVoteTime - %time;

   if(%diff > 0)
   {
      Client::sendMessage(%clientId, 0, "You can't start another vote for " @ floor(%diff) @ " seconds.");
      return;
   }
   if($curVoteTopic == "")
   {
      if(%clientId.numFailedVotes)
         %time += %clientId.numFailedVotes * $Server::VoteFailTime;

      %clientId.lastVoteTime = %time;
      $curVoteInitiator = %clientId;
      $curVoteTopic = %topic;
      $curVoteAction = %action;
      $curVoteOption = %option;
      if(%action == "kick" || %action == "tkkick")
         $curVoteOption.kickTeam = GameBase::getTeam($curVoteOption);
	$curVoteCount++;
	if(%action == "tkkick")
      {
      	%IXtker = getWord(%topic, 3);
		%IXtkKills = $tkKills[getClientByName(%IXtker)];
		bottomprintall("<jc><f1>" @ Client::getName(%clientId) @ " <f0>initiated a vote to <f1>" @ $curVoteTopic @ "\n " @ %IXtker @ " <f0> has a Confirmed <f1>" @ %IXtkKills @ " TEAM KILLS", 10);  
      }
	else
      	bottomprintall("<jc><f1>" @ Client::getName(%clientId) @ " <f0>initiated a vote to <f1>" @ $curVoteTopic, 10);

      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         %cl.vote = "";
      %clientId.vote = "yes";
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         if(%cl.menuMode == "options")
            Game::menuRequest(%clientId);
      schedule("Admin::countVotes(" @ $curVoteCount @ ", true);", $Server::VotingTime, 35);
   }
   else
   {
      Client::sendMessage(%clientId, 0, "Voting already in progress.");
   }
}

// Remade Menu to Include Various Options - *IX*Savage1
function Game::menuRequest(%clientId)
{
   %curItem = 0;
   Client::buildMenu(%clientId, "Options", "options", true);
   if(!$matchStarted || !$Server::TourneyMode)
   {
      Client::addMenuItem(%clientId, %curItem++ @ "Change Teams/Observe", "changeteams");
	Client::addMenuItem(%clientId, %curItem++ @ "Weapon Options", "weaponoptions");
//      Client::addMenuItem(%clientId, %curItem++ @ "Spoonbot controls", "botmenu");
   }
   if(%clientId.selClient)
   {
      %sel = %clientId.selClient;
      %name = Client::getName(%sel);

      if($curVoteTopic == "" && !%clientId.isSuperAdmin)
      {
         if($Ecstacy::PAVote && !%clientId.isAdmin)
		Client::addMenuItem(%clientId, %curItem++ @ "Vote to admin " @ %name, "vadmin " @ %sel);
         if($Ecstacy::PAKick && %clientId.isAdmin)
		Client::addMenuItem(%clientId, %curItem++ @ "Kick " @ %name, "kick " @ %sel);
	   else
		Client::addMenuItem(%clientId, %curItem++ @ "Vote to kick " @ %name, "vkick " @ %sel);
         if($Ecstacy::PABan && %clientId.isAdmin)
		Client::addMenuItem(%clientId, %curItem++ @ "Ban " @ %name, "ban " @ %sel);
         if($Ecstacy::PATeamChange && %clientId.isAdmin)
		Client::addMenuItem(%clientId, %curItem++ @ "Change " @ %name @ "'s team", "fteamchange " @ %sel);
      }
	else if(%clientId.isSuperAdmin)
	{
         if(!%sel.isAdmin) 
		Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
         Client::addMenuItem(%clientId, %curItem++ @ "Kick " @ %name, "kick " @ %sel);
         Client::addMenuItem(%clientId, %curItem++ @ "Ban " @ %name, "ban " @ %sel);
         Client::addMenuItem(%clientId, %curItem++ @ "Change " @ %name @ "'s team", "fteamchange " @ %sel);
	}
      if(%clientId.muted[%sel])
         Client::addMenuItem(%clientId, %curItem++ @ "Unmute " @ %name, "unmute " @ %sel);
      else
         Client::addMenuItem(%clientId, %curItem++ @ "Mute " @ %name, "mute " @ %sel);
   }
   if($curVoteTopic != "" && %clientId.vote == "")
   {
      Client::addMenuItem(%clientId, %curItem++ @ "Vote YES to " @ $curVoteTopic, "voteYes " @ $curVoteCount);
      Client::addMenuItem(%clientId, %curItem++ @ "Vote NO to " @ $curVoteTopic, "voteNo " @ $curVoteCount);
   }
   else if($curVoteTopic == "" && !%clientId.isSuperAdmin)
   {
      if($Ecstacy::PAMission && %clientId.isAdmin)
        Client::addMenuItem(%clientId, %curItem++ @ "Change mission", "cmission");
	else
	  Client::addMenuItem(%clientId, %curItem++ @ "Vote to change mission", "vcmission");
	if($Ecstacy::PATeamDamage && %clientId.isAdmin)
      	if($Server::TeamDamageScale == 1.0)
	      	Client::addMenuItem(%clientId, %curItem++ @ "Disable team damage", "dtd");
	      else
	      	Client::addMenuItem(%clientId, %curItem++ @ "Enable team damage", "etd");
      else
		if($Server::TeamDamageScale == 1.0)
      		Client::addMenuItem(%clientId, %curItem++ @ "Vote to disable team damage", "vdtd");
		else
      		Client::addMenuItem(%clientId, %curItem++ @ "Vote to enable team damage", "vetd");
	if($Ecstacy::PATourneyMode && %clientId.isAdmin)
	      if($Server::TourneyMode)
      	{
	      	Client::addMenuItem(%clientId, %curItem++ @ "Change to FFA mode", "cffa");
			if(!$CountdownStarted && !$matchStarted)
      	      	Client::addMenuItem(%clientId, %curItem++ @ "Start the match", "smatch");
	      }
      	else
			Client::addMenuItem(%clientId, %curItem++ @ "Change to Tournament mode", "ctourney");
	else
		if($Server::TourneyMode)
     		{
			Client::addMenuItem(%clientId, %curItem++ @ "Vote to enter FFA mode", "vcffa");
      		if(!$CountdownStarted && !$matchStarted)
	            	Client::addMenuItem(%clientId, %curItem++ @ "Vote to start the match", "vsmatch");
     		}
	      else
			Client::addMenuItem(%clientId, %curItem++ @ "Vote to enter Tournament mode", "vctourney");
		if($Ecstacy::PATimeLimit && %clientId.isAdmin) Client::addMenuItem(%clientId, %curItem++ @ "Set Time Limit", "ctimelimit");
	      if($Ecstacy::PAResetDefaults && %clientId.isAdmin) Client::addMenuItem(%clientId, %curItem++ @ "Reset Server Defaults", "reset");
      	if($Ecstacy::PAModOptions && %clientId.isAdmin) Client::addMenuItem(%clientId, %curItem++ @ "Ecstacy Mod Settings", "ecstacy");
   }
   else if(%clientId.isSuperAdmin)
   {
      Client::addMenuItem(%clientId, %curItem++ @ "Change mission", "cmission");
      if($Server::TeamDamageScale == 1.0)
         Client::addMenuItem(%clientId, %curItem++ @ "Disable team damage", "dtd");
      else
         Client::addMenuItem(%clientId, %curItem++ @ "Enable team damage", "etd");

      if($Server::TourneyMode)
      {
         Client::addMenuItem(%clientId, %curItem++ @ "Change to FFA mode", "cffa");
         if(!$CountdownStarted && !$matchStarted)
            Client::addMenuItem(%clientId, %curItem++ @ "Start the match", "smatch");
      }
      else
         Client::addMenuItem(%clientId, %curItem++ @ "Change to Tournament mode", "ctourney");
      Client::addMenuItem(%clientId, %curItem++ @ "Set Time Limit", "ctimelimit");
      Client::addMenuItem(%clientId, %curItem++ @ "Reset Server Defaults", "reset");
//      Client::addMenuItem(%clientId, %curItem++ @ "Ecstacy Admin Options", "ecstacyAdmin");
   }
// Ecstacy Mod Client TK Options Added - *IX*Savage1
   %IXKiller = Insomniax_getKiller(%clientId);
   if((%IXKiller != %clientId) && ($tkKills[%IXKiller] >= $Ecstacy::tkLimit))
   {
	Client::addMenuItem(%clientId, %curItem++ @ "Kick Team Killer " @ Client::getName(Insomniax_getKiller(%clientId)), "tkopt " @ getClientByName(Client::getName(%IXKiller)));    
	}
   }

function remoteSelectClient(%clientId, %selId)
{
   if(%clientId.selClient != %selId)
   {
	%selKills = $tkKills[%selId];
      %clientId.selClient = %selId;
      if(%clientId.menuMode == "options")
         Game::menuRequest(%clientId);
      remoteEval(%clientId, "setInfoLine", 1, "Player Info for " @ Client::getName(%selId) @ ":");
      remoteEval(%clientId, "setInfoLine", 2, "Name: " @ $Client::info[%selId, 1]);
     remoteEval(%clientId, "setInfoLine", 3, "Email: " @ $Client::info[%selId, 2]);
      remoteEval(%clientId, "setInfoLine", 4, "Tribe: " @ $Client::info[%selId, 3]);
    remoteEval(%clientId, "setInfoLine", 5, "Number of TKs: " @ %selKills);
      remoteEval(%clientId, "setInfoLine", 6, "Other: " @ $Client::info[%selId, 5]);

//    remoteEval(%clientId, "setInfoLine", 1, "Team Kill Info for " @ Client::getName(%selId) @ ":");
//    remoteEval(%clientId, "setInfoLine", 2, "Last TK Victim: " @ %selLastTK);
//    remoteEval(%clientId, "setInfoLine", 3, "Last TK'd By: " @ %selTKdBy);
//    remoteEval(%clientId, "setInfoLine", 4, "Number of TKs: " @ %selKills);
//    remoteEval(%clientId, "setInfoLine", 5, "Server: " @ Insomniax_ServerLvlTxt());
//    remoteEval(%clientId, "setInfoLine", 6, "Client: " @ Insomniax_ClientLvlTxt());
//    remoteEval(%clientId, "setInfoLine", 5, "URL: " @ $Client::info[%selId, 4]);
   }
}

function processMenuFPickTeam(%clientId, %team)
{
   if(%clientId.isAdmin)
      processMenuPickTeam(%clientId.ptc, %team, %clientId);
   %clientId.ptc = "";
}


function processMenuPickTeam(%clientId, %team, %adminClient)
{
	checkPlayerCash(%clientId);
   if(%team != -1 && %team == Client::getTeam(%clientId))
      return;

   if(%clientId.observerMode == "justJoined")
   {
      %clientId.observerMode = "";
      centerprint(%clientId, "");
   }

   if((!$matchStarted || !$Server::TourneyMode || %adminClient) && %team == -2)
   {
      if(Observer::enterObserverMode(%clientId))
      {
         %clientId.notready = "";
         if(%adminClient == "") 
            messageAll(0, Client::getName(%clientId) @ " became an observer.");
         else
            messageAll(0, Client::getName(%clientId) @ " was forced into observer mode by " @ Client::getName(%adminClient) @ ".");
			Game::resetScores(%clientId);	
		   Game::refreshClientScore(%clientId);
		}
      return;
   }

   %player = Client::getOwnedObject(%clientId);
   if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player)) {
		playNextAnim(%clientId);
	   Player::kill(%clientId);
	}
   %clientId.observerMode = "";
   if(%adminClient == "")
      messageAll(0, Client::getName(%clientId) @ " changed teams.");
   else
      messageAll(0, Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient) @ ".");

   if(%team == -1)
   {
      Game::assignClientTeam(%clientId);
      %team = Client::getTeam(%clientId);
   }
   GameBase::setTeam(%clientId, %team);
   %clientId.teamEnergy = 0;
	Client::clearItemShopping(%clientId);
	if(Client::getGuiMode(%clientId) != 1)
		Client::setGuiMode(%clientId,1);		
	Client::setControlObject(%clientId, -1);

   Game::playerSpawn(%clientId, false);
	%team = Client::getTeam(%clientId);
	if($TeamEnergy[%team] != "Infinite")
		$TeamEnergy[%team] += $InitialPlayerEnergy;
   if($Server::TourneyMode && !$CountdownStarted)
   {
      bottomprint(%clientId, "<f1><jc>Press FIRE when ready.", 0);
      %clientId.notready = true;
   }
}

function processMenuOptions(%clientId, %option)
{
   %opt = getWord(%option, 0);
   %cl = getWord(%option, 1);

   if(%opt == "fteamchange")
   {
      %clientId.ptc = %cl;
      Client::buildMenu(%clientId, "Pick a team:", "FPickTeam", true);
      Client::addMenuItem(%clientId, "0Observer", -2);
      Client::addMenuItem(%clientId, "1Automatic", -1);
      for(%i = 0; %i < getNumTeams(); %i = %i + 1)
         Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
      return;
   }      
   else if(%opt == "changeteams")
   {
      if(!$matchStarted || !$Server::TourneyMode)
      {
         Client::buildMenu(%clientId, "Pick a team:", "PickTeam", true);
         Client::addMenuItem(%clientId, "0Observer", -2);
         Client::addMenuItem(%clientId, "1Automatic", -1);
         for(%i = 0; %i < getNumTeams(); %i = %i + 1)
            Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
         return;
      }
   }
   else if(%opt == "mute")
      %clientId.muted[%cl] = true;
   else if(%opt == "unmute")
      %clientId.muted[%cl] = "";
   else if(%opt == "vkick")
   {
      %cl.voteTarget = true;
      Admin::startVote(%clientId, "kick " @ Client::getName(%cl), "kick", %cl);
   }
   else if(%opt == "vadmin")
   {
      %cl.voteTarget = true;
      Admin::startVote(%clientId, "admin " @ Client::getName(%cl), "admin", %cl);
   }
   else if(%opt == "vsmatch")
      Admin::startVote(%clientId, "start the match", "smatch", 0);
   else if(%opt == "vetd")
      Admin::startVote(%clientId, "enable team damage", "etd", 0);
   else if(%opt == "vdtd")
      Admin::startVote(%clientId, "disable team damage", "dtd", 0);
   else if(%opt == "etd")
      Admin::setTeamDamageEnable(%clientId, true);
   else if(%opt == "dtd")
      Admin::setTeamDamageEnable(%clientId, false);
   else if(%opt == "vcffa")
      Admin::startVote(%clientId, "change to Free For All mode", "ffa", 0);
   else if(%opt == "vctourney")
      Admin::startVote(%clientId, "change to Tournament mode", "tourney", 0);
   else if(%opt == "cffa")
      Admin::setModeFFA(%clientId);
   else if(%opt == "ctourney")
      Admin::setModeTourney(%clientId);
   else if(%opt == "voteYes" && %cl == $curVoteCount)
   {
      %clientId.vote = "yes";
      centerprint(%clientId, "", 0);
   }
   else if(%opt == "voteNo" && %cl == $curVoteCount)
   {
      %clientId.vote = "no";
      centerprint(%clientId, "", 0);
   }
   else if(%opt == "kick")
   {
      Client::buildMenu(%clientId, "Confirm kick:", "kaffirm", true);
      Client::addMenuItem(%clientId, "1Kick " @ Client::getName(%cl), "yes " @ %cl);
      Client::addMenuItem(%clientId, "2Don't kick " @ Client::getName(%cl), "no " @ %cl);
      return;
   } 
   else if(%opt == "admin")
   {
      Client::buildMenu(%clientId, "Confirm Admin:", "aaffirm", true);
      Client::addMenuItem(%clientId, "1Make " @ Client::getName(%cl) @ " Admin", "yes " @ %cl);
      Client::addMenuItem(%clientId, "2Don't Make " @ Client::getName(%cl) @ " Admin", "no " @ %cl);
      return;
   }
  
   else if(%opt == "ban")
   {
      Client::buildMenu(%clientId, "Confirm Ban:", "baffirm", true);
      Client::addMenuItem(%clientId, "1Ban " @ Client::getName(%cl), "yes " @ %cl);
      Client::addMenuItem(%clientId, "2Don't ban " @ Client::getName(%cl), "no " @ %cl);
      return;
   }
   else if(%opt == "smatch")
      Admin::startMatch(%clientId);
   else if(%opt == "vcmission" || %opt == "cmission")
   {
      Admin::changeMissionMenu(%clientId, %opt == "cmission");
      return;
   }
   else if(%opt == "ctimelimit")
   {
      Client::buildMenu(%clientId, "Change Time Limit:", "ctlimit", true);
      Client::addMenuItem(%clientId, "110 Minutes", 10);
      Client::addMenuItem(%clientId, "215 Minutes", 15);
      Client::addMenuItem(%clientId, "320 Minutes", 20);
      Client::addMenuItem(%clientId, "425 Minutes", 25);
      Client::addMenuItem(%clientId, "530 Minutes", 30);
      Client::addMenuItem(%clientId, "645 Minutes", 45);
      Client::addMenuItem(%clientId, "71 Hour", 60);
      Client::addMenuItem(%clientId, "8No Time Limit", 0);
      return;
   }
   else if(%opt == "reset")
   {
      Client::buildMenu(%clientId, "Confirm Reset:", "raffirm", true);
      Client::addMenuItem(%clientId, "1Reset", "yes");
      Client::addMenuItem(%clientId, "2Don't Reset", "no");
      return;
   }
   else if(%opt == "botmenu")
   {
      Client::buildMenu(%clientId, "Select bot action:", "selbotaction", true);
      Client::addMenuItem(%clientId, "1Spawn bot", "spawnbot");
      Client::addMenuItem(%clientId, "2Remove bot", "removebot");
     return;
   }
   else if (%opt == "weaponoptions") 
   { 	
   		%curItem = 0;
   
   		Client::buildMenu(%clientId, "Weapon Options", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "MB Cannon", "weapon_MB");
 		Client::addMenuItem(%clientId, %curItem++ @ "Litmus Cannon", "weapon_MDRL");
//   		Client::addMenuItem(%clientId, %curItem++ @ "RPM", "weapon_RPM");
//   		Client::addMenuItem(%clientId, %curItem++ @ "RPEMP", "weapon_RPEMP");
//     	Client::addMenuItem(%clientId, %curItem++ @ "", "weapon_MDG");
// 		if (Player::getMountedItem(%clientId,$BackpackSlot) == HyperPack)
//	   		Client::addMenuItem(%clientId, %curItem++ @ "Lock Hyperdrive to Flag", "locktelepoint");

 		return;
   	}
	else if (%opt == "weapon_MB")
	{
   		%curItem = 0;
   		Client::buildMenu(%clientId, "Mitzi Blast Cannon", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "Normal", "weapon_MB_reg");
   		Client::addMenuItem(%clientId, %curItem++ @ "EMP", "weapon_MB_haywire");
   		return;
	}
	else if (%opt == "weapon_MDRL")
	{
   		%curItem = 0;
   		Client::buildMenu(%clientId, "Multiple Demiforce", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "Reaver Missile", "weapon_MD_red");
   		Client::addMenuItem(%clientId, %curItem++ @ "Electron Missile", "weapon_MD_blue");
	      Client::addMenuItem(%clientId, %curItem++ @ "Gundam Heavy Plasma", "weapon_MD_sparky");
	      Client::addMenuItem(%clientId, %curItem++ @ "Devistator Beam", "weapon_MD_crazy");
  		return;
	}
	else if (%opt == "weapon_RPM")
	{
   		%curItem = 0;
   		Client::buildMenu(%clientId, "Rocket Propelled Mortar", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "Normal", "weapon_RPM_reg");
   		Client::addMenuItem(%clientId, %curItem++ @ "Electro-Optical", "weapon_RPM_EO");
   		return;
	}
	else if (%opt == "weapon_RPEMP")
	{
   		%curItem = 0;
   		Client::buildMenu(%clientId, "Rocket Powered EMP", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "Normal", "weapon_RPEMP_reg");
   		Client::addMenuItem(%clientId, %curItem++ @ "Electro-Optical", "weapon_RPEMP_EO");
  		return;
	}
	else if (%opt == "weapon_MDG")
	{
   		%curItem = 0;
   		Client::buildMenu(%clientId, "Spy Gun Options", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "Pistol Bullet", "weapon_MDG_rb");
   		Client::addMenuItem(%clientId, %curItem++ @ "Sniper Bullet", "weapon_MDG_gb");
   		Client::addMenuItem(%clientId, %curItem++ @ "Spy Grenade", "weapon_MDG_hb");
    		Client::addMenuItem(%clientId, %curItem++ @ "Spy Disc", "weapon_MDG_lb");
   		Client::addMenuItem(%clientId, %curItem++ @ "Spy Rocket", "weapon_MDG_zb");
  		return;
	}
	else if (%opt == "weapon_MD_red")
	{
		%clientId.multi = "0";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Litmus Cannon set to Reaver.\", 5);", 0);
   		return;
	}

	else if (%opt == "weapon_MD_blue")
	{
		%clientId.multi = "1";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Litmus Cannon set to Electron.\", 5);", 0);
   		return;
	}

	else if (%opt == "weapon_MD_sparky")
	{
		%clientId.multi = "2";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Litmus Cannon set to Gundam Heavy Plasma.\", 5);", 0);
   		return;
	}
	else if (%opt == "weapon_MD_crazy")
	{
		%clientId.multi = "3";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Litmus Cannon set to Devistator.\", 5);", 0);
   		return;
	}

	else if (%opt == "weapon_MDG_zb")
	{
		%clientId.fixOpt = "4";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Spy Gun is set to Rocket mode.\", 3);", 0);
   		return;
	}
	else if (%opt == "weapon_MB_reg")
	{
		%clientId.Cannon = "0";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Mitzi Blast Cannon set to Standard.\", 5);", 0);
   		return;
	}

	else if (%opt == "weapon_MB_haywire")
	{
		%clientId.Cannon = "1";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Mitzi Blast Cannon set to EMP.\", 5);", 0);
   		return;
	}

	else if (%opt == "weapon_rpg_REG")
	{
		%clientId.rpg = "0";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Rocket Propelled Grenade set to Standard.\", 3);", 0);
   		return;
	}
	else if (%opt == "weapon_rpg_EO")
	{
		%clientId.RPG = "1";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Rocket Propelled Grenade set to Electro-Optical.\", 3);", 0);
   		return;
	}
	else if (%opt == "weapon_rpm_reg")
	{
		%clientId.RPM = "0";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Rocket Propelled Mortar set to Standard.\", 3);", 0);
   		return;
	}
	else if (%opt == "weapon_rpm_eo")
	{
		%clientId.RPM = "1";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Rocket Propelled Mortar set to Electro-Optical.\", 3);", 0);
   		return;
	}
	else if (%opt == "weapon_gl_reg")
	{
		%clientId.MorOpt = "0";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Nuclear Warhead Laucnehr switched to Mortar mode.\", 3);", 0);
   		return;
	}

	else if (%opt == "weapon_gl_haywire")
	{
		%clientId.MorOpt = "1";
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Nuclear Warhead Launcher switched to Missile mode.\", 3);", 0);
   		return;
	}
 	
	else if (%opt == "locktelepoint")
	{
		%playerteam = Client::getTeam(%clientId);		//== Player Team
		%playerpos = GameBase::getPosition(%clientId);		//== Player Position

		if ($debug) echo ("" @ %flagdist @ "");

		for(%i = -1; %i < 8 ; %i++)
		{
			%homepos = ($teamFlag[%i]).originalPosition;
			%flagdist = Vector::getDistance(%playerpos,%homepos);  	//== Player To Flag Distance		
			%tname = getTeamName(%i);
			if (%flagdist < 49)
			{
			        bottomprint(%clientId, "<jc><f2>You must be atleast 50m from any Flag to lock on.", 2);
				schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Too close to " @ %tname @ " flag...\", 3);", 3);
				return;
			}
		}
		%clientId.telepoint = GameBase::getPosition(%clientId);
	        topprint(%clientId, "<jc><f2>Hyperdrive locked onto " @ %clientId.telepoint @ ".", 2);
		return;
	}
	
	else if (%opt == "weapon_Cannon")
	{
   		%curItem = 0;
   		Client::buildMenu(%clientId, "MBC Bolt", "options", true);
   		Client::addMenuItem(%clientId, %curItem++ @ "Mitzi Blast", "weapon_Cannon_shell");
   		Client::addMenuItem(%clientId, %curItem++ @ "Missile", "weapon_Cannon_Missile");
   		Client::addMenuItem(%clientId, %curItem++ @ "Shell", "weapon_Cannon_Plasma");
   		return;
	}
	else if (%opt == "weapon_Cannon_Shell")
	{
		%clientId.Cannon = 0;
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Standard Mitzi Blast\", 5);", 0);
   		return;
	}
	else if (%opt == "weapon_cannon_missile")
	{
		%clientId.Cannon = 1;
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Wide-Proximity Missile.\", 5);", 0);
   		return;
	}
	else if (%opt == "weapon_cannon_plasma")
	{
		%clientId.cannon = 2;
		schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Cannon Shell.\", 5);", 0);
   		return;
	}

   else if(%opt == "ecstacyAdmin")
   {
      Client::buildMenu(%clientId, "Ecstacy Admin Settings:", "settings", true);
	Client::addMenuItem(%clientId, "Kick Team Killer", "tkopt" @ %clientId);
      return;
   }
   // Ecstacy MOD Client TK Actions. - *IX*Savage1
   else if(%opt == "tkopt")
   {
      if($Ecstacy::tkClientLvl == 1)
        Admin::Kick(-3, Insomniax_getKiller(%clientId));
   }
   Game::menuRequest(%clientId);
}

function processMenuKAffirm(%clientId, %opt)
{
   if(getWord(%opt, 0) == "yes")
      Admin::kick(%clientId, getWord(%opt, 1));
   Game::menuRequest(%clientId);
}

function processMenuAAffirm(%clientId, %opt)
{
    if(getWord(%opt, 0) == "yes")
    {
	%cl = getWord(%opt, 1);
	%cl.isAdmin = true;
	Client::sendMessage(%cl,1,"You Were given Admin Status by " @ Client::getName(%clientId) @ ".");
	Client::sendMessage(%clientId,1,"You gave Admin Status to " @ Client::getName(%cl) @ ".");
    }
    Game::menuRequest(%clientId);
}

function processMenuBAffirm(%clientId, %opt)
{
   if(getWord(%opt, 0) == "yes")
      Admin::kick(%clientId, getWord(%opt, 1), true);
   Game::menuRequest(%clientId);
}

function processMenuRAffirm(%clientId, %opt)
{
   if(%opt == "yes" && %clientId.isAdmin)
   {
      messageAll(0, Client::getName(%clientId) @ " reset the server to default settings.");
      Server::refreshData();
   }
   Game::menuRequest(%clientId);
}

function processMenuCTLimit(%clientId, %opt)
{
   remoteSetTimeLimit(%clientId, %opt);
}

function processMenuSelBotAction(%clientId, %opt)
{
if (%opt == "spawnbot") 
    {
      Client::buildMenu(%clientId, "Select bot type:", "selbotgender", true);
      Client::addMenuItem(%clientId, "1Guard", "Guard");
      Client::addMenuItem(%clientId, "2Demo", "Demo");
      Client::addMenuItem(%clientId, "3Painter", "Painter");
      Client::addMenuItem(%clientId, "4Sniper", "Sniper");
      Client::addMenuItem(%clientId, "5Medic", "Medic");
      Client::addMenuItem(%clientId, "6Miner", "Miner");
      Client::addMenuItem(%clientId, "7Mortar", "Mortar");
      return;
    }
    else if (%opt == "removebot")
    {
      %opt = 0;
      processMenuRemoveBot(%clientId, %opt);
      return;
    }

}



function processMenuSelBotGender(%clientId, %opt)
{
      Client::buildMenu(%clientId, "Bot gender and type:", "botalldone", true);
      Client::addMenuItem(%clientId, "1Male Roaming " @ %opt, %opt @ "_Male");
      Client::addMenuItem(%clientId, "2Female Roaming " @ %opt, %opt @ "_Female");
      Client::addMenuItem(%clientId, "3Male CMD " @ %opt, %opt @ "_Male_CMD");
      Client::addMenuItem(%clientId, "4Female CMD " @ %opt, %opt @ "_Female_CMD");
      return;
}






function processMenuRemoveBot(%clientId, %options)
{
   %curItem = 0;
   %first = getWord(%options, 0);
   Client::buildMenu(%clientId, "Pick bot to remove", "rbot", true);
   %i = 0;
   %menunum = 0;
   %startCl = 2049;                  //by EMO1313
//   %startCl = Client::getFirst();
   %endCl = %startCl + 90;
   for(%cl = %startCl; %cl < %endCl; %cl = %cl + 1)
       if (Player::isAIControlled(%cl)) //Is this a bot?
       {
         %aiName = Client::getName(%cl);
         %i = %i + 1;

         if (%i > %first)  // Skip some bots if we selected "more bots" previously
           {
            %menunum = %menunum + 1;

            if(%menunum > 6)
             {

               Client::addMenuItem(%clientId, %menunum @ "More bots...", "more " @ %first + %menunum - 1);
               break;
              }


             Client::addMenuItem(%clientId, %menunum @ %aiName, %aiName);
           }

       }
return;
}


function processMenuRBot(%clientId, %option)
{
   if(getWord(%option, 0) == "more")
   {
      %first = getWord(%option, 1);
      processMenuRemoveBot(%clientId, %first);
      return;
   }

   AI::RemoveBot(%option, %clientId);
   return;
}



function processMenuBotAllDone(%clientId, %opt)
{
//   dbecho(1, "processMenuBotAllDone calls AI::SpawnAdditionalBot with these parameters:");
//   dbecho(1, "opt: " @ %opt);
//   dbecho(1, "clientId: " @ %clientId);
   %teamnum = GameBase::getTeam(%clientId);
   AI::SpawnAdditionalBot(%opt, %teamNum, 1);
   return;
}




//-------------------------------------------------------------------
// Various Menus and Data Processing - *IX*Savage1
//-------------------------------------------------------------------

function processMenuIXSettings(%clientId, %option)
{
   %opt = getWord(%option, 0);
   %cl = getWord(%option, 1);

   if(%opt == "patoggle")
   {
	Client::sendMessage(%clientId, 3, "Public Admin Vote is now " @ isonoff(%cl) @ ".");
	$Ecstacy::PAVote = %cl;
   }
   else if(%opt == "tkserv")
   {
      Client::buildMenu(%clientId, "Current Server Anti-TK: " @ %cl, "ServerLvl", true);
      Client::addMenuItem(%clientId, "0Log TK's only", 0);
      Client::addMenuItem(%clientId, "1Auto Vote TKer", 1);
      Client::addMenuItem(%clientId, "2Auto Vote Until Kicked", 2);
      Client::addMenuItem(%clientId, "3Auto Kick TKer", 3);
      return;
   }
   else if(%opt == "tkclient")
   {
      Client::buildMenu(%clientId, "Current Client Anti-TK: " @ %cl, "ClientLvl", true);
      Client::addMenuItem(%clientId, "0Client Vote Option", 0);
      Client::addMenuItem(%clientId, "1Client Kick Option", 1);
      return;
   }
   else if(%opt == "areakill")
   {
      Client::buildMenu(%clientId, "Out of Bounds Kill Time: " @ %cl @ " Seconds", "AKill", true);
      Client::addMenuItem(%clientId, "0Set to Off", 0);
      Client::addMenuItem(%clientId, "1Set to 10 Seconds", 10);
      Client::addMenuItem(%clientId, "2Set to 15 Seconds", 15);
      Client::addMenuItem(%clientId, "3Set to 20 Seconds", 20);
      Client::addMenuItem(%clientId, "4Set to 25 Seconds", 25);
      Client::addMenuItem(%clientId, "5Set to 30 Seconds", 30);
      Client::addMenuItem(%clientId, "6Set to 40 Seconds", 40);
      Client::addMenuItem(%clientId, "7Set to 60 Seconds", 60);
      return;
   }
   else if(%opt == "palockout")
   {
      Client::buildMenu(%clientId, "Current Public Admin Lockouts:","PALockouts", true);
      Client::addMenuItem(%clientId, "1Team Changing " @ isonoff($Ecstacy::PATeamChange), "teamchange " @ $Insomniax::PATeamChange);
      Client::addMenuItem(%clientId, "2Kicking " @ isonoff($Ecstacy::PAKick), "kick " @ $Insomniax::PAKick);
      Client::addMenuItem(%clientId, "3Banning " @ isonoff($Ecstacy::PABan), "ban " @ $Insomniax::PABan);
      Client::addMenuItem(%clientId, "4Change Mission " @ isonoff($Ecstacy::PAMission), "mission " @ $Insomniax::PAMission);
      Client::addMenuItem(%clientId, "5Team Damage " @ isonoff($Ecstacy::PATeamDamage), "teamdamage " @ $Insomniax::PATeamDamage);
      Client::addMenuItem(%clientId, "6Tourney Mode " @ isonoff($Ecstacy::PATourneyMode), "tourney " @ $Insomniax::PATourneyMode);
      Client::addMenuItem(%clientId, "7Time Limit " @ isonoff($Ecstacy::PATimeLimit), "timelimit " @ $Insomniax::PATimeLimit);
      Client::addMenuItem(%clientId, "8Additional Lockouts ...", "additional");
      return;
   }
   else if(%opt == "adminvote")
   {
      Client::buildMenu(%clientId, "Public Admin Vote is " @ isonoff(%cl), "ixsettings", true);
      Client::addMenuItem(%clientId, "0Turn OFF Public Admin", "patoggle false");
      Client::addMenuItem(%clientId, "1Turn ON Public Admin", "patoggle true");
      return;
   }
   else if(%opt == "purge")
   {
	Client::sendMessage(%cl,3,"Purging All Public Admins of Admin Status.");
	Insomniax_clearPA(%cl);
	Client::sendMessage(%cl,3,"Purging Complete.");
      return;
   }

}

function processMenuPALockouts(%clientId, %option) 
{
	%opt = getWord(%option, 0);
	%toggle = getWord(%option, 1);
	if(%opt == "additional")
	{
		Client::buildMenu(%clientId, "Current Public Admin Lockouts:","PALockouts", true);
		Client::addMenuItem(%clientId, "1Server Defaults " @ isonoff($Ecstacy::PAResetDefaults), "reset " @ $Insomniax::PAResetDefaults);
      	Client::addMenuItem(%clientId, "2Insomniax Mod Options " @ isonoff($Ecstacy::PAModOptions), "modopt " @ $Insomniax::PAModOptions);
      	Client::addMenuItem(%clientId, "3Turn all Options ON", "allon");
		return;
	}
	else if(%opt == "allon") 
	{
		%access = "All Options";
		%toggle = "false";
		$Insomniax::PATeamChange = "true";
		$Insomniax::PAKick = "true";
		$Insomniax::PABan = "true";
		$Insomniax::PAMission = "true";
		$Insomniax::PATeamDamage = "true";
		$Insomniax::PATourneyMode = "true";
		$Insomniax::PATimeLimit = "true";
		$Insomniax::PAResetDefaults = "true";
		$Insomniax::PAModOptions = "true";
	}
	else if(%opt == "teamchange") 
	{
		%access = "Team Changing";
		if(%toggle) $Ecstacy::PATeamChange = "false";
		else $Ecstacy::PATeamChange = "true";
	}
	else if(%opt == "kick") 
	{
		%access = "Kicking";
		if(%toggle) $Ecstacy::PAKick = "false";
		else $Ecstacy::PAKick = "true";
	}
	else if(%opt == "ban") 
	{
		%access = "Banning";
		if(%toggle) $Ecstacy::PABan = "false";
		else $Ecstacy::PABan = "true";
	}
	else if(%opt == "mission") 
	{
		%access = "Changing Mission";
		if(%toggle) $Ecstacy::PAMission = "false";
		else $Ecstacy::PAMission = "true";
	}
	else if(%opt == "teamdamage") 
	{
		%access = "Team Damage";
		if(%toggle) $Ecstacy::PATeamDamage = "false";
		else $Ecstacy::PATeamDamage = "true";
	}
	else if(%opt == "tourney") 
	{
		%access = "Tourney Mode";
		if(%toggle) $Ecstacy::PATourneyMode = "false";
		else $Ecstacy::PATourneyMode = "true";
	}
	else if(%opt == "timelimit") 
	{
		%access = "Mission Time Limit";
		if(%toggle) $Ecstacy::PATimeLimit = "false";
		else $Ecstacy::PATimeLimit = "true";
	}
	else if(%opt == "reset") 
	{
		%access = "Reseting Sever to Defaults";
		if(%toggle) $Ecstacy::PAResetDefaults = "false";
		else $Ecstacy::PAResetDefaults = "true";
	}
	else if(%opt == "modopt") 
	{
		%access = "Ecstacy Mod Options";
		if(%toggle) $Ecstacy::PAModOptions = "false";
		else $Ecstacy::PAModOptions = "true";
	}
	if(%toggle) %toggle = "false";
	else %toggle = "true";
	Client::sendMessage(%clientId, 3, "Public Admin Access to " @ %access @ " is now " @ isonoff(%toggle) @ ".");
}

function isonoff(%toggle)
{
	if(%toggle) return "On";
	else return "Off";
}

function processMenuServerLvl(%clientId, %option) 
{
   $Ecstacy::tkServerLvl = %option;
   if(%option == 0)
     messageAll(0, "SERVER:TK Protection Level Set to Zero. (Logging TK's only).");
   if(%option == 1)
     messageAll(0, "SERVER:TK Protection Level Set to One. (Auto Vote).");
   if(%option == 2)
     messageAll(0, "SERVER:TK Protection Level Set to Two. (Auto Vote Until Kicked).");
   if(%option == 3)
     messageAll(0, "SERVER:TK Protection Level Set to Three. (Auto Kick).");
}

function processMenuClientLvl(%clientId, %option) 
{
   $Ecstacy::tkClientLvl = %option;
   if(%option == 0)
     messageAll(0, "SERVER: Client TK Vote Option Engaged. (From Options Menu).");
   if(%option == 1)
     messageAll(0, "SERVER: Client TK Kick Option Engaged. (From Options Menu).");
}

function processMenuAKill(%clientId, %option) 
{
   $Ecstacy::LeaveAreaTime = %option;
   if(%option == 0)
     messageAll(0, "SERVER: Leaving Mission Area Does not Kill you.");
   else
     messageAll(0, "SERVER: Leaving Mission Area Kills you in " @ %option @ " Seconds.");

}

function Insomniax_ServerLvlTxt()
{
    if($Ecstacy::tkServerLvl == 0)
    	%tkText = "Only Logging TK's"; 
    else if($Ecstacy::tkServerLvl == 1)
	%tkText = "Votes at " @ $Ecstacy::tkLimit @ " TK's";
    else if($Ecstacy::tkServerLvl == 2)
	%tkText = "Votes at " @ $Ecstacy::tkLimit @ " TKs and Kicks at " @ $Ecstacy::tkLimit * $Ecstacy::tkMultiple @ " TK's";
    else if($Ecstacy::tkServerLvl == 3)
	%tkText = "Kicks at " @ $Ecstacy::tkLimit @ " TK's";
    else %tkText = "ERROR: Server Level set to Unkown Level";
    return %tkText;
}

function Insomniax_ClientLvlTxt()
{
    if($Ecstacy::tkClientLvl == 0)
    	%tkText = "Vote Option at " @ $Ecstacy::tkLimit @ " TK's"; 
    else if($Ecstacy::tkClientLvl == 1)
	%tkText = "Kick Option at " @ $Ecstacy::tkLimit @ "TK's";
    else %tkText = "ERROR: Client Level set to Unkown Level";
    return %tkText;
}

// Insomnaix Mod TK Handling - *IX*Savage1
function Insomniax_setTeamKill(%victimId, %killerId) 
{
	$tkVictim[%killerId] = %victimId;
	$tkKiller[%victimId] = %killerId;
	$tkKills[%killerId] += 1;
	%trigger = $tkKills[%killerId] % $Ecstacy::tkLimit;
	%tkTopKills = $Ecstacy::tkLimit * $Ecstacy::tkMultiple;
	if(($tkKills[%killerId] >= $Ecstacy::tkLimit) && (!%trigger)) 
	  {
	  if($Ecstacy::tkServerLvl) 
	    {
	    if($Ecstacy::tkServerLvl != 3)
	      {
		if(($tkKills[%killerId] >= %tkTopKills) && ($Ecstacy::tkServerLvl != 1))
		{
		messageAll(0, Client::getName(%killerId) @ " has been kicked for Team Killing. Confirmed " @ $tkKills[%killerId] @ " Team Kills.~waaodsfx62.wav");
		Admin::Kick(-2, %killerId);
		return;
		}
		%killerId.voteTarget = true;
     		%victimId.selClient = Insomniax_getKiller(%victimId);
		Admin::startVote(%victimId, "Kick Team Killer " @ Client::getName(%killerId), "tkkick", %killerId);
	      }
	    else
	      {
		messageAll(0, Client::getName(%killerId) @ " has been kicked for Team Killing. Confirmed " @ $tkKills[%killerId] @ " Team Kills.~waaodsfx62.wav");
		Admin::Kick(-2, %killerId);
	      }		
	    }
	  }
	return;
}

function Insomniax_getKiller(%clientId) 
{
  return $tkKiller[%clientId];
}

function Insomniax_getVictim(%clientId) 
{
  return $tkVictim[%clientId];
}

function Insomniax_leaveGame(%clientId) 
{
	if (($tkKiller[$tkVictim[%clientId]] == %clientId) && ($tkVictim != %clientId))
	  $tkKiller[$tkVictim[%clientId]] = $tkVictim[%clientId];
	if (($tkVictim[$tkKiller[%clientId]] == %clientId) && ($tkVictim != %clientId))
	  $tkVictim[$tkKiller[%clientId]] = $tkKiller[%clientId];
      $tkKiller[%clientId] = %clientId;
	$tkVictim[%clientId] = %clientId;
	$tkKills[%clientId] = 0;
	$empTime[%clientId] = 0;
	return;
}

function Insomniax_joinGame(%clientId) 
{
	if (($tkKiller[$tkVictim[%clientId]] == %clientId) && ($tkVictim != %clientId))
	  $tkKiller[$tkVictim[%clientId]] = $tkVictim[%clientId];
	if (($tkVictim[$tkKiller[%clientId]] == %clientId) && ($tkVictim != %clientId))
	  $tkVictim[$tkKiller[%clientId]] = $tkKiller[%clientId];
	$tkVictim[%clientId] = %clientId;
	$tkKiller[%clientId] = %clientId;
      $tkKills[%clientId] = 0;
	$empTime[%clientId] = 0;
}

function Insomniax_clearPA(%admin) 
{
	if(%admin.isSuperAdmin)
	{
	      %numPlayers = getNumClients();
      	for(%i = 0; %i < %numPlayers; %i++)
	      {
			%pl = getClientByIndex(%i);
			if(!%pl.isSuperAdmin && %pl.isAdmin)
			{
				%pl.isAdmin = false;
				Client::sendMessage(%pl,1,"Your Admin Status has been revoked by the Super Admin.");
				Client::sendMessage(%admin,3,"Public Admin Status Stripped from: " @ Client::getName(%pl) @ ".");
			}
		}
	}
}

function AutoAdminMsg(%clientId)
{
	Client::sendMessage(%cl,1,"Welcome to Ecstacy. You are now an Admin");
}
