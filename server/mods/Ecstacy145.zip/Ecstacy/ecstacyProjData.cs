// ====================== ======================== ===================== ecstacyProjData.cs MegaMan 1024
// ====================== Successor to baseProjData.cs -- mod projectile reference

