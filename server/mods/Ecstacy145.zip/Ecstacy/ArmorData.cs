//----------------------------------------------------------------------------
// Light Armor
//----------------------------------------------------------------------------

$DamageScale[larmor, $LandingDamageType] = 1.0;
$DamageScale[larmor, $ImpactDamageType] = 1.0;
$DamageScale[larmor, $CrushDamageType] = 1.0;
$DamageScale[larmor, $BulletDamageType] = 1.2;
$DamageScale[larmor, $PlasmaDamageType] = 1.0;
$DamageScale[larmor, $EnergyDamageType] = 1.3;
$DamageScale[larmor, $ExplosionDamageType] = 1.0;
$DamageScale[larmor, $MissileDamageType] = 1.0;
$DamageScale[larmor, $DebrisDamageType] = 1.2;
$DamageScale[larmor, $ShrapnelDamageType] = 1.2;
$DamageScale[larmor, $LaserDamageType] = 1.0;
$DamageScale[larmor, $MortarDamageType] = 1.3;
$DamageScale[larmor, $BlasterDamageType] = 1.3;
$DamageScale[larmor, $ElectricityDamageType] = 1.0;
$DamageScale[larmor, $MineDamageType] = 1.2;
$DamageScale[larmor, $MagneticDamageType] = 0.5;
$DamageScale[larmor, $RocketDamageType] = 1.0;
$DamageScale[larmor, $FusionDamageType] = 1.5;
$DamageScale[larmor, $DisruptorDamageType] = 1.0;
$DamageScale[larmor, $SonicDamageType] = 5.0;
$DamageScale[larmor, $IonDamageType] = 2.2;
$DamageScale[larmor, $DistortionDamageType] = 7.2;
$DamageScale[larmor, $EMPDamageType] = 1.0;
$DamageScale[larmor, $PulseDamageType] = 1.0;
$DamageScale[larmor, $SniperDamageType] = 1.0;
$DamageScale[larmor, $VulcanDamageType] = 1.0;
$DamageScale[larmor, $ShotgunDamageType] = 1.0;
$DamageScale[larmor, $NukeDamageType] = 10.0;
$DamageScale[larmor, $ZapDamageType] = 2.0;
$DamageScale[larmor, $RepairDamageType] = 1.0;
$DamageScale[larmor, $HeatDamageType] = 1.0;
$DamageScale[larmor, $PhotonDamageType] = 1.0;
$DamageScale[larmor, $PistolDamageType] = 1.0;
$DamageScale[larmor, $ATCDamageType] = 1.0;
$DamageScale[larmor, $StarDamageType] = 1.0;
$DamageScale[larmor, $ZapMortarDamageType] = 1.0;
$DamageScale[larmor, $ShockwaveDamageType] = 1.0;
$DamageScale[larmor, $QuantumDamageType] = 1.0;
$DamageScale[larmor, $BusterDamageType] = 1.0;
$DamageScale[larmor, $FluxDamageType] = 1.0;
$DamageScale[larmor, $FlierBombDamageType] = 1.0;
$DamageScale[larmor, $BustedDamageType] = 1.0;
$DamageScale[larmor, $PBWDamageType] = 1.0;
$DamageScale[larmor, $FlameDamageType] = 1.0;
$DamageScale[larmor, $IceDamageType] = 1.0;
$DamageScale[larmor, $RPGDamageType] = 1.0;
$DamageScale[larmor, $RPMDamageType] = 1.0;
$DamageScale[larmor, $EMPDamageType] = 0.5;
$DamageScale[larmor, $MethaneDamageType] = 1.0;
$DamageScale[larmor, $BurstDamageType] = 1.0;
$DamageScale[larmor, $ReaverDamageType] = 1.0;
$DamageScale[larmor, $RifleDamageType] = 1.0;
$DamageScale[larmor, $MassShotgunDamageType] = 1.0;
$DamageScale[larmor, $AutogunDamageType] = 1.0;
$DamageScale[larmor, $PistolDamageType] = 1.0;
$DamageScale[larmor, $AutogunDamageType] = 1.0;
$DamageScale[larmor, $GaussDamageType] = 1.0;
$DamageScale[larmor, $MBDamageType] = 1.0;
$DamageScale[larmor, $CutterDamageType] = 1.0;
$DamageScale[larmor, $NullDamageType] = 1.0;

$ItemMax[larmor, Blaster] = 1;
$ItemMax[larmor, Chaingun] = 1;
$ItemMax[larmor, DiscLauncher] = 1;
$ItemMax[larmor, Mortar] = 0;
$ItemMax[larmor, PlasmaGun] = 1;
$ItemMax[larmor, LaserRifle] = 1;
$ItemMax[larmor, EnergyRifle] = 1;
$ItemMax[larmor, TargetingLaser] = 1;
$ItemMax[larmor, MineAmmo] = 3;
$ItemMax[larmor, Grenade] = 5;
$ItemMax[larmor, Beacon]  = 3;
$ItemMax[larmor, RepairKit] = 2;
//-----------------------------
$ItemMax[larmor, GatlingBlaster] = 1;
$ItemMax[larmor, GatlingDisruptor] = 1;
$ItemMax[larmor, LaserGatling] = 1;
$ItemMax[larmor, DisruptorGun] = 1;
$ItemMax[larmor, GaussCannon] = 1;
$ItemMax[larmor, VulcanCannon] = 1;
$ItemMax[larmor, SDiscLauncher] = 1;
$ItemMax[larmor, GrenadeLauncher] = 1;
$ItemMax[larmor, RPGLauncher] = 1;
$ItemMax[larmor, RPEMPLauncher] = 1;
$ItemMax[larmor, MBCannon] = 1;
$ItemMax[larmor, Cutter] = 1;
$ItemMax[larmor, ReaverLauncher] = 1;
$ItemMax[larmor, Pistol] = 1;
$ItemMax[larmor, IceBlower] = 1;
$ItemMax[larmor, DartGun] = 1;
$ItemMax[larmor, Autogun] = 1;
$ItemMax[larmor, ElectroCannon] = 1;
$ItemMax[larmor, Reassembler] = 1;

$ItemMax[larmor, BulletAmmo] = 100;
$ItemMax[larmor, PlasmaAmmo] = 30;
$ItemMax[larmor, DiscAmmo] = 25;
$ItemMax[larmor, SDiscAmmo] = 25;
$ItemMax[larmor, GrenadeAmmo] = 10;
$ItemMax[larmor, RPGAmmo] = 10;
$ItemMax[larmor, RPEMPAmmo] = 15;
$ItemMax[larmor, MortarAmmo] = 10;
//-------------------------------
$ItemMax[larmor, ReaverAmmo] = 25;
$ItemMax[larmor, VulcanAmmo] = 100;
$ItemMax[larmor, GaussAmmo] = 100;
$ItemMax[larmor, Shells] = 50;
$ItemMax[larmor, Darts] = 25;

$ItemMax[larmor, EnergyPack] = 1;
$ItemMax[larmor, RepairPack] = 1;
$ItemMax[larmor, ShieldPack] = 1;
$ItemMax[larmor, SensorJammerPack] = 1;
$ItemMax[larmor, MotionSensorPack] = 1;
$ItemMax[larmor, PulseSensorPack] = 1;
$ItemMax[larmor, DeployableSensorJammerPack] = 1;
$ItemMax[larmor, CameraPack] = 1;
$ItemMax[larmor, TurretPack] = 1;
$ItemMax[larmor, AmmoPack] = 1;
$ItemMax[larmor, DeployableInvPack] = 0;
$ItemMax[larmor, DeployableAmmoPack] = 0;
$ItemMax[larmor, ReaverPack] = 1;
$ItemMax[larmor, FakeFlag] = 1;
$ItemMax[larmor, ForceFieldPack] = 1;
$ItemMax[larmor, SteaLTHsHIELDpACK] = 1;
$ItemMax[larmor, HyperPack] = 1;
$ItemMax[larmor, Slipstream] = 1;
$ItemMax[larmor, CloakingDevice] = 1;
$ItemMax[larmor, LaserPack] = 1;
$ItemMax[larmor, RegenerationPack] = 1;
$ItemMax[larmor, EPodPack] = 1;
$ItemMax[larmor, SKYPack] = 1;
$ItemMax[larmor, EXPack] = 1;
$ItemMax[larmor, AAAPack] = 1;
$ItemMax[larmor, IScoutPack] = 1;
$ItemMax[larmor, BTScoutPack] = 1;
$ItemMax[larmor, PyroGXPack] = 1;
$ItemMax[larmor, PyroPack] = 1;
$ItemMax[larmor, PyroGxLPack] = 1;
$ItemMax[larmor, DoorFieldPack] = 1;
$ItemMax[larmor, TNTpack] = 1;
$ItemMax[larmor, TreePack] = 1;
$ItemMax[larmor, Holopack] = 1;
$ItemMax[larmor, Blasterpack] = 1;
$ItemMax[larmor, Flamerpack] = 1;
$ItemMax[larmor, Reactorpack] = 1;

$MaxWeapons[larmor] = 4;

//----------------------------------------------------------------------------
// Disruptor Armor 
//----------------------------------------------------------------------------

$DamageScale[disruptor, $LandingDamageType] = 1.0;
$DamageScale[disruptor, $ImpactDamageType] = 1.0;
$DamageScale[disruptor, $CrushDamageType] = 1.0;
$DamageScale[disruptor, $BulletDamageType] = 1.2;
$DamageScale[disruptor, $PlasmaDamageType] = 1.0;
$DamageScale[disruptor, $EnergyDamageType] = 0.3;
$DamageScale[disruptor, $ExplosionDamageType] = 1.0;
$DamageScale[disruptor, $MissileDamageType] = 1.0;
$DamageScale[disruptor, $DebrisDamageType] = 1.2;
$DamageScale[disruptor, $ShrapnelDamageType] = 1.2;
$DamageScale[disruptor, $LaserDamageType] = 0.5;
$DamageScale[disruptor, $MortarDamageType] = 1.3;
$DamageScale[disruptor, $BlasterDamageType] = 0.3;
$DamageScale[disruptor, $ElectricityDamageType] = 1.0;
$DamageScale[disruptor, $MineDamageType] = 1.2;
$DamageScale[disruptor, $MagneticDamageType] = 0.5;
$DamageScale[disruptor, $RocketDamageType] = 1.0;
$DamageScale[disruptor, $FusionDamageType] = -1.5;
$DamageScale[disruptor, $DisruptorDamageType] = -1.0;
$DamageScale[disruptor, $SonicDamageType] = 5.0;
$DamageScale[disruptor, $IonDamageType] = 2.2;
$DamageScale[disruptor, $DistortionDamageType] = 7.2;
$DamageScale[disruptor, $EMPDamageType] = 1.0;
$DamageScale[disruptor, $PulseDamageType] = 1.0;
$DamageScale[disruptor, $SniperDamageType] = 1.0;
$DamageScale[disruptor, $VulcanDamageType] = 1.0;
$DamageScale[disruptor, $ShotgunDamageType] = 1.0;
$DamageScale[disruptor, $NukeDamageType] = 10.0;
$DamageScale[disruptor, $ZapDamageType] = 2.0;
$DamageScale[disruptor, $RepairDamageType] = 1.0;
$DamageScale[disruptor, $HeatDamageType] = 1.0;
$DamageScale[disruptor, $PhotonDamageType] = 1.0;
$DamageScale[disruptor, $PistolDamageType] = 1.0;
$DamageScale[disruptor, $ATCDamageType] = 1.0;
$DamageScale[disruptor, $StarDamageType] = 1.0;
$DamageScale[disruptor, $ZapMortarDamageType] = 1.0;
$DamageScale[disruptor, $ShockwaveDamageType] = 1.0;
$DamageScale[disruptor, $QuantumDamageType] = 1.0;
$DamageScale[disruptor, $BusterDamageType] = 1.0;
$DamageScale[disruptor, $FluxDamageType] = 1.0;
$DamageScale[disruptor, $FlierBombDamageType] = 1.0;
$DamageScale[disruptor, $BustedDamageType] = 1.0;
$DamageScale[disruptor, $PBWDamageType] = 1.0;
$DamageScale[disruptor, $FlameDamageType] = 1.0;
$DamageScale[disruptor, $IceDamageType] = 1.0;
$DamageScale[disruptor, $RPGDamageType] = 1.0;
$DamageScale[disruptor, $RPMDamageType] = 1.0;
$DamageScale[disruptor, $EMPDamageType] = 0.5;
$DamageScale[disruptor, $MethaneDamageType] = 1.0;
$DamageScale[disruptor, $BurstDamageType] = 1.0;
$DamageScale[disruptor, $ReaverDamageType] = 1.0;
$DamageScale[disruptor, $RifleDamageType] = 1.0;
$DamageScale[disruptor, $MassShotgunDamageType] = 1.0;
$DamageScale[disruptor, $AutogunDamageType] = 1.0;
$DamageScale[disruptor, $PistolDamageType] = 1.0;
$DamageScale[disruptor, $AutogunDamageType] = 1.0;
$DamageScale[disruptor, $GaussDamageType] = 1.0;
$DamageScale[disruptor, $MBDamageType] = 1.0;
$DamageScale[disruptor, $CutterDamageType] = 1.0;
$DamageScale[disruptor, $NullDamageType] = 1.0;

$ItemMax[disruptor, Blaster] = 1;
$ItemMax[disruptor, TargetingLaser] = 1;
$ItemMax[disruptor, MineAmmo] = 10;
$ItemMax[disruptor, Grenade] = 15;
$ItemMax[disruptor, Beacon]  = 10;
$ItemMax[disruptor, RepairKit] = 2;
//-----------------------------
$ItemMax[disruptor, DisruptorGun] = 1;
$ItemMax[disruptor, RocketLauncher] = 1;
$ItemMax[disruptor, LPistol] = 1;
$ItemMax[disruptor, Reassembler] = 1;

$ItemMax[disruptor, EnergyPack] = 1;
$ItemMax[disruptor, RepairPack] = 1;
$ItemMax[disruptor, ShieldPack] = 1;
$ItemMax[disruptor, AmmoPack] = 1;
$ItemMax[disruptor, CloakingDevice] = 1;
$ItemMax[disruptor, CrystalPack] = 1;

$MaxWeapons[disruptor] = 2;

//----------------------------------------------------------------------------
// Vulcan Armor
//----------------------------------------------------------------------------

$DamageScale[vulcan, $LandingDamageType] = 1.0;
$DamageScale[vulcan, $ImpactDamageType] = 1.0;
$DamageScale[vulcan, $CrushDamageType] = 1.0;
$DamageScale[vulcan, $BulletDamageType] = -0.2;
$DamageScale[vulcan, $PlasmaDamageType] = 1.0;
$DamageScale[vulcan, $EnergyDamageType] = 1.3;
$DamageScale[vulcan, $ExplosionDamageType] = 1.0;
$DamageScale[vulcan, $MissileDamageType] = 1.0;
$DamageScale[vulcan, $DebrisDamageType] = 1.2;
$DamageScale[vulcan, $ShrapnelDamageType] = 1.2;
$DamageScale[vulcan, $LaserDamageType] = 1.0;
$DamageScale[vulcan, $MortarDamageType] = 1.3;
$DamageScale[vulcan, $BlasterDamageType] = 1.3;
$DamageScale[vulcan, $ElectricityDamageType] = 1.0;
$DamageScale[vulcan, $MineDamageType] = 1.2;
$DamageScale[vulcan, $MagneticDamageType] = 0.5;
$DamageScale[vulcan, $RocketDamageType] = 1.0;
$DamageScale[vulcan, $FusionDamageType] = 1.5;
$DamageScale[vulcan, $DisruptorDamageType] = 1.0;
$DamageScale[vulcan, $SonicDamageType] = 5.0;
$DamageScale[vulcan, $IonDamageType] = 2.2;
$DamageScale[vulcan, $DistortionDamageType] = 7.2;
$DamageScale[vulcan, $EMPDamageType] = 1.0;
$DamageScale[vulcan, $PulseDamageType] = 1.0;
$DamageScale[vulcan, $SniperDamageType] = 1.0;
$DamageScale[vulcan, $VulcanDamageType] = -0.1;
$DamageScale[vulcan, $ShotgunDamageType] = 0.05;
$DamageScale[vulcan, $NukeDamageType] = 10.0;
$DamageScale[vulcan, $ZapDamageType] = 2.0;
$DamageScale[vulcan, $RepairDamageType] = 1.0;
$DamageScale[vulcan, $HeatDamageType] = 1.0;
$DamageScale[vulcan, $PhotonDamageType] = 1.0;
$DamageScale[vulcan, $PistolDamageType] = 1.0;
$DamageScale[vulcan, $ATCDamageType] = 1.0;
$DamageScale[vulcan, $StarDamageType] = 1.0;
$DamageScale[vulcan, $ZapMortarDamageType] = 1.0;
$DamageScale[vulcan, $ShockwaveDamageType] = 1.0;
$DamageScale[vulcan, $QuantumDamageType] = 1.0;
$DamageScale[vulcan, $BusterDamageType] = 1.0;
$DamageScale[vulcan, $FluxDamageType] = 1.0;
$DamageScale[vulcan, $FlierBombDamageType] = 1.0;
$DamageScale[vulcan, $BustedDamageType] = 1.0;
$DamageScale[vulcan, $PBWDamageType] = 1.0;
$DamageScale[vulcan, $FlameDamageType] = 1.0;
$DamageScale[vulcan, $IceDamageType] = 1.0;
$DamageScale[vulcan, $RPGDamageType] = 1.0;
$DamageScale[vulcan, $RPMDamageType] = 1.0;
$DamageScale[vulcan, $EMPDamageType] = 0.5;
$DamageScale[vulcan, $MethaneDamageType] = 1.0;
$DamageScale[vulcan, $BurstDamageType] = 1.0;
$DamageScale[vulcan, $ReaverDamageType] = 1.0;
$DamageScale[vulcan, $RifleDamageType] = -0.5;
$DamageScale[vulcan, $MassShotgunDamageType] = 1.0;
$DamageScale[vulcan, $AutogunDamageType] = 0;
$DamageScale[vulcan, $PistolDamageType] = 0;
$DamageScale[vulcan, $GaussDamageType] = 1.0;
$DamageScale[vulcan, $MBDamageType] = 1.0;
$DamageScale[vulcan, $CutterDamageType] = 0.5;
$DamageScale[vulcan, $NullDamageType] = 1.0;

$ItemMax[vulcan, Chaingun] = 1;
$ItemMax[vulcan, TargetingLaser] = 1;
$ItemMax[vulcan, MineAmmo] = 3;
$ItemMax[vulcan, Grenade] = 5;
$ItemMax[vulcan, Beacon]  = 3;
$ItemMax[vulcan, RepairKit] = 2;
//-----------------------------
$ItemMax[vulcan, GatlingBlaster] = 1;
$ItemMax[vulcan, GatlingDisruptor] = 1;
$ItemMax[vulcan, ATC] = 1;
$ItemMax[vulcan, LaserGatling] = 1;
$ItemMax[vulcan, GaussCannon] = 1;
$ItemMax[vulcan, VulcanCannon] = 1;
$ItemMax[vulcan, Cutter] = 1;
$ItemMax[vulcan, ReaverLauncher] = 1;
$ItemMax[vulcan, LPistol] = 1;
$ItemMax[vulcan, Autogun] = 1;
$ItemMax[vulcan, Reassembler] = 1;

$ItemMax[vulcan, BulletAmmo] = 100;
$ItemMax[vulcan, ATCAmmo] = 50;
//-------------------------------
$ItemMax[vulcan, ReaverAmmo] = 25;
$ItemMax[vulcan, VulcanAmmo] = 500;
$ItemMax[vulcan, GaussAmmo] = 100;
$ItemMax[vulcan, Shells] = 50;

$ItemMax[vulcan, EnergyPack] = 1;
$ItemMax[vulcan, RepairPack] = 1;
$ItemMax[vulcan, ShieldPack] = 1;
$ItemMax[vulcan, SensorJammerPack] = 1;
$ItemMax[vulcan, MotionSensorPack] = 1;
$ItemMax[vulcan, PulseSensorPack] = 1;
$ItemMax[vulcan, DeployableSensorJammerPack] = 1;
$ItemMax[vulcan, AmmoPack] = 1;
$ItemMax[vulcan, ReaverPack] = 1;
$ItemMax[vulcan, FakeFlag] = 1;
$ItemMax[vulcan, SteaLTHsHIELDpACK] = 1;
$ItemMax[vulcan, HyperPack] = 1;
$ItemMax[vulcan, CloakingDevice] = 1;
$ItemMax[vulcan, Reactorpack] = 1;

$MaxWeapons[vulcan] = 4;

//----------------------------------------------------------------------------
// Medium Armor
//----------------------------------------------------------------------------
$DamageScale[marmor, $LandingDamageType] = 1.0;
$DamageScale[marmor, $ImpactDamageType] = 1.0;
$DamageScale[marmor, $CrushDamageType] = 1.0;
$DamageScale[marmor, $BulletDamageType] = 1.0;
$DamageScale[marmor, $PlasmaDamageType] = 0.6;
$DamageScale[marmor, $EnergyDamageType] = 1.0;
$DamageScale[marmor, $ExplosionDamageType] = 1.0;
$DamageScale[marmor, $MissileDamageType] = 1.0;
$DamageScale[marmor, $ShrapnelDamageType] = 1.0;
$DamageScale[marmor, $DebrisDamageType] = 1.0;
$DamageScale[marmor, $LaserDamageType] = 1.0;
$DamageScale[marmor, $MortarDamageType] = 1.0;
$DamageScale[marmor, $BlasterDamageType] = 1.0;
$DamageScale[marmor, $ElectricityDamageType] = 1.0;
$DamageScale[marmor, $MineDamageType] = 1.0;
$DamageScale[marmor, $MagneticDamageType] = 0.5;
$DamageScale[marmor, $RocketDamageType] = 1.0;
$DamageScale[marmor, $FusionDamageType] = 1.5;
$DamageScale[marmor, $DisruptorDamageType] = 1.0;
$DamageScale[marmor, $SonicDamageType] = 5.0;
$DamageScale[marmor, $IonDamageType] = 2.2;
$DamageScale[marmor, $DistortionDamageType] = 7.2;
$DamageScale[marmor, $EMPDamageType] = 1.0;
$DamageScale[marmor, $PulseDamageType] = 1.0;
$DamageScale[marmor, $SniperDamageType] = 1.0;
$DamageScale[marmor, $VulcanDamageType] = 1.0;
$DamageScale[marmor, $ShotgunDamageType] = 1.0;
$DamageScale[marmor, $NukeDamageType] = 10.0;
$DamageScale[marmor, $ZapDamageType] = 2.0;
$DamageScale[marmor, $RepairDamageType] = 1.0;
$DamageScale[marmor, $HeatDamageType] = 1.0;
$DamageScale[marmor, $PhotonDamageType] = 1.0;
$DamageScale[marmor, $PistolDamageType] = 1.0;
$DamageScale[marmor, $ATCDamageType] = 1.0;
$DamageScale[marmor, $StarDamageType] = 1.0;
$DamageScale[marmor, $ZapMortarDamageType] = 1.0;
$DamageScale[marmor, $ShockwaveDamageType] = 1.0;
$DamageScale[marmor, $QuantumDamageType] = 1.0;
$DamageScale[marmor, $BusterDamageType] = 1.0;
$DamageScale[marmor, $FluxDamageType] = 1.0;
$DamageScale[marmor, $FlierBombDamageType] = 1.0;
$DamageScale[marmor, $BustedDamageType] = 1.0;
$DamageScale[marmor, $PBWDamageType] = 1.0;
$DamageScale[marmor, $FlameDamageType] = 1.0;
$DamageScale[marmor, $IceDamageType] = 1.0;
$DamageScale[marmor, $RPGDamageType] = 1.0;
$DamageScale[marmor, $RPMDamageType] = 1.0;
$DamageScale[marmor, $EMPDamageType] = 0.5;
$DamageScale[marmor, $MethaneDamageType] = 1.0;
$DamageScale[marmor, $BurstDamageType] = 1.0;
$DamageScale[marmor, $ReaverDamageType] = 1.0;
$DamageScale[marmor, $RifleDamageType] = 1.0;
$DamageScale[marmor, $MassShotgunDamageType] = 1.0;
$DamageScale[marmor, $AutogunDamageType] = 1.0;
$DamageScale[marmor, $PistolDamageType] = 1.0;
$DamageScale[marmor, $AutogunDamageType] = 1.0;
$DamageScale[marmor, $GaussDamageType] = 1.0;
$DamageScale[marmor, $MBDamageType] = 1.0;
$DamageScale[marmor, $CutterDamageType] = 1.0;
$DamageScale[marmor, $NullDamageType] = 1.0;

$ItemMax[marmor, Blaster] = 1;
$ItemMax[marmor, Chaingun] = 1;
$ItemMax[marmor, GaussCannon] = 1;
$ItemMax[marmor, VulcanCannon] = 1;
$ItemMax[marmor, DiscLauncher] = 1;
$ItemMax[marmor, SDiscLauncher] = 1;
$ItemMax[marmor, GrenadeLauncher] = 1;
$ItemMax[marmor, GrandGrenadeLauncher] = 1;
$ItemMax[marmor, RPGLauncher] = 1;
$ItemMax[marmor, RPMLauncher] = 1;
$ItemMax[marmor, RPEMPLauncher] = 1;
$ItemMax[marmor, Mortar] = 1;
$ItemMax[marmor, ImpactMortar] = 1;
$ItemMax[marmor, RubberMortar] = 1;
$ItemMax[marmor, ElectroMortar] = 1;
$ItemMax[marmor, MineLauncher] = 1;
$ItemMax[marmor, HyperB] = 1;
$ItemMax[marmor, IonGun] = 1;
$ItemMax[marmor, SPlas] = 1;
$ItemMax[marmor, GatlingBlaster] = 1;
$ItemMax[marmor, MBCannon] = 1;
$ItemMax[marmor, Cutter] = 1;
$ItemMax[marmor, PTCannon] = 1;
$ItemMax[marmor, IONCannon] = 1;
$ItemMax[marmor, ShockCannon] = 1;
$ItemMax[marmor, BabyNukeMortar] = 1;
$ItemMax[marmor, ReaverLauncher] = 1;
$ItemMax[marmor, PlasmaGun] = 1;
$ItemMax[marmor, LaserRifle] = 1;
$ItemMax[marmor, EnergyRifle] = 1;
$ItemMax[marmor, RocketLauncher] = 1;
$ItemMax[marmor, EMPGrenadeLauncher] = 1;
$ItemMax[marmor, MagGun] = 1;
$ItemMax[marmor, TargetingLaser] = 1;
$ItemMax[marmor, MineAmmo] = 3;
$ItemMax[marmor, Grenade] = 6;
$ItemMax[marmor, Beacon] = 3;
$ItemMax[marmor, RepairKit] = 3;
$ItemMax[marmor, LPistol] = 1;
$ItemMax[marmor, Autogun] = 1;
$ItemMax[marmor, Rifle] = 1;
$ItemMax[marmor, MassDriver] = 1;
$ItemMax[marmor, Shotgun] = 1;
$ItemMax[marmor, FlameBlower] = 1;
$ItemMax[marmor, MassShotgun] = 1;
$ItemMax[marmor, RFL] = 1;
$ItemMax[marmor, PBW] = 1;
$ItemMax[marmor, FusionGun] = 1;
$ItemMax[marmor, FlareGun] = 1;

$ItemMax[marmor, BulletAmmo] = 150;
$ItemMax[marmor, ReaverAmmo] = 50;
$ItemMax[marmor, GaussAmmo] = 150;
$ItemMax[marmor, VulcanAmmo] = 150;
$ItemMax[marmor, PlasmaAmmo] = 40;
$ItemMax[marmor, DiscAmmo] = 15;
$ItemMax[marmor, SDiscAmmo] = 15;
$ItemMax[marmor, RDiscAmmo] = 15;
$ItemMax[marmor, GrenadeAmmo] = 25;
$ItemMax[marmor, GrandGrenadeAmmo] = 15;
$ItemMax[marmor, MortarAmmo] = 15;
$ItemMax[marmor, ImpactAmmo] = 15;
$ItemMax[marmor, RubberAmmo] = 15;
$ItemMax[marmor, ElectroAmmo] = 15;
$ItemMax[marmor, BabyNukeAmmo] = 15;
$ItemMax[marmor, MultiMineAmmo] = 15;
$ItemMax[marmor, RPGAmmo] = 25;
$ItemMax[marmor, RPMAmmo] = 15;
$ItemMax[marmor, RPEMPAmmo] = 15;
$ItemMax[marmor, RocketAmmo] = 30;
$ItemMax[marmor, EMPGrenadeAmmo] = 30;
$ItemMax[marmor, Bolts] = 25;
$ItemMax[marmor, Shells] = 100;
$ItemMax[marmor, Flares] = 100;
$ItemMax[marmor, Balls] = 15;

$ItemMax[marmor, EnergyPack] = 1;
$ItemMax[marmor, RepairPack] = 1;
$ItemMax[marmor, ShieldPack] = 1;
$ItemMax[marmor, ReaverPack] = 1;
$ItemMax[marmor, SensorJammerPack] = 1;
$ItemMax[marmor, MotionSensorPack] = 1;
$ItemMax[marmor, PulseSensorPack] = 1;
$ItemMax[marmor, DeployableSensorJammerPack] = 1;
$ItemMax[marmor, CameraPack] = 1;
$ItemMax[marmor, TurretPack] = 1;
$ItemMax[marmor, AmmoPack] = 1;
$ItemMax[marmor, DeployableInvPack] = 1;
$ItemMax[marmor, DeployableAmmoPack] = 1;
$ItemMax[marmor, FakeFlag] = 1;
$ItemMax[marmor, SentryPack] = 1;
$ItemMax[marmor, RocketPack] = 1;
$ItemMax[marmor, Slipstream] = 1;
$ItemMax[marmor, TeleportPack] = 1;
$ItemMax[marmor, RocketPack] = 1;
$ItemMax[marmor, ContainmentFieldPack] = 1;
$ItemMax[marmor, DeployableElf] = 1;
$ItemMax[marmor, CloakingDevice] = 1;
$ItemMax[marmor, LaserPack] = 1;
$ItemMax[marmor, RegenerationPack] = 1;
$ItemMax[marmor, BlasterPack] = 1;
$ItemMax[marmor, FlamerPack] = 1;
$ItemMax[marmor, ReactorPack] = 1;
$ItemMax[marmor, WildfirePack] = 1;
$ItemMax[marmor, SniperPack] = 1;
$ItemMax[marmor, GunboyPack] = 1;
$ItemMax[marmor, AirbasePack] = 1;
$ItemMax[marmor, GroundbasePack] = 1;
$ItemMax[marmor, DoorfieldPack] = 1;
$ItemMax[marmor, HoloPack] = 1;
$ItemMax[marmor, HolowallPack] = 1;
$ItemMax[marmor, HologenPack] = 1;
$ItemMax[marmor, TreePack] = 1;
$ItemMax[marmor, TNTPack] = 1;
$ItemMax[marmor, DetPack] = 1;
$ItemMax[marmor, accelPPack] = 1;
$ItemMax[marmor, JailPack] = 1;
$ItemMax[marmor, JailcapPack] = 1;
$ItemMax[marmor, ObeliskPack] = 1;
$ItemMax[marmor, ObeliskPowerPack] = 1;

$MaxWeapons[marmor] = 5;

//----------------------------------------------------------------------------
// BlasTech Armor
//----------------------------------------------------------------------------
$DamageScale[blastech, $LandingDamageType] = 1.0;
$DamageScale[blastech, $ImpactDamageType] = 1.0;
$DamageScale[blastech, $CrushDamageType] = 1.0;
$DamageScale[blastech, $BulletDamageType] = 1.0;
$DamageScale[blastech, $PlasmaDamageType] = 0;
$DamageScale[blastech, $EnergyDamageType] = 1.0;
$DamageScale[blastech, $ExplosionDamageType] = -0.2;
$DamageScale[blastech, $MissileDamageType] = -0.2;
$DamageScale[blastech, $ShrapnelDamageType] = -0.4;
$DamageScale[blastech, $DebrisDamageType] = -0.2;
$DamageScale[blastech, $LaserDamageType] = 1.0;
$DamageScale[blastech, $MortarDamageType] = -0.5;
$DamageScale[blastech, $BlasterDamageType] = 1.0;
$DamageScale[blastech, $ElectricityDamageType] = 1.0;
$DamageScale[blastech, $MineDamageType] = 1.0;
$DamageScale[blastech, $MagneticDamageType] = 0.5;
$DamageScale[blastech, $RocketDamageType] = 1.0;
$DamageScale[blastech, $FusionDamageType] = 1.5;
$DamageScale[blastech, $DisruptorDamageType] = 1.0;
$DamageScale[blastech, $SonicDamageType] = 5.0;
$DamageScale[blastech, $IonDamageType] = 2.2;
$DamageScale[blastech, $DistortionDamageType] = 7.2;
$DamageScale[blastech, $EMPDamageType] = 0.0;
$DamageScale[blastech, $PulseDamageType] = 1.0;
$DamageScale[blastech, $SniperDamageType] = 1.0;
$DamageScale[blastech, $VulcanDamageType] = 1.0;
$DamageScale[blastech, $ShotgunDamageType] = 1.0;
$DamageScale[blastech, $NukeDamageType] = -1.0;
$DamageScale[blastech, $ZapDamageType] = 2.0;
$DamageScale[blastech, $RepairDamageType] = 1.0;
$DamageScale[blastech, $HeatDamageType] = 1.0;
$DamageScale[blastech, $PhotonDamageType] = -1.0;
$DamageScale[blastech, $PistolDamageType] = 1.0;
$DamageScale[blastech, $ATCDamageType] = -0.01;
$DamageScale[blastech, $StarDamageType] = -1.0;
$DamageScale[blastech, $ZapMortarDamageType] = 1.0;
$DamageScale[blastech, $ShockwaveDamageType] = -1.0;
$DamageScale[blastech, $QuantumDamageType] = -1.0;
$DamageScale[blastech, $BusterDamageType] = -1.0;
$DamageScale[blastech, $FluxDamageType] = 1.0;
$DamageScale[blastech, $FlierBombDamageType] = -0.5;
$DamageScale[blastech, $BustedDamageType] = -1.0;
$DamageScale[blastech, $PBWDamageType] = 1.0;
$DamageScale[blastech, $FlameDamageType] = 1.0;
$DamageScale[blastech, $IceDamageType] = 1.0;
$DamageScale[blastech, $RPGDamageType] = -0.2;
$DamageScale[blastech, $RPMDamageType] = -0.5;
$DamageScale[blastech, $EMPDamageType] = -0.01;
$DamageScale[blastech, $MethaneDamageType] = 1.0;
$DamageScale[blastech, $BurstDamageType] = -0.1;
$DamageScale[blastech, $ReaverDamageType] = -0.01;
$DamageScale[blastech, $RifleDamageType] = 1.0;
$DamageScale[blastech, $MassShotgunDamageType] = -1.0;
$DamageScale[blastech, $AutogunDamageType] = 1.0;
$DamageScale[blastech, $PistolDamageType] = 1.0;
$DamageScale[blastech, $AutogunDamageType] = 1.0;
$DamageScale[blastech, $GaussDamageType] = -0.2;
$DamageScale[blastech, $MBDamageType] = 1.0;
$DamageScale[blastech, $CutterDamageType] = 1.0;
$DamageScale[blastech, $NullDamageType] = 1.0;

$ItemMax[blastech, Blaster] = 1;
$ItemMax[blastech, Chaingun] = 1;
$ItemMax[blastech, GaussCannon] = 1;
$ItemMax[blastech, VulcanCannon] = 1;
$ItemMax[blastech, DiscLauncher] = 1;
$ItemMax[blastech, SDiscLauncher] = 1;
$ItemMax[blastech, GrenadeLauncher] = 1;
$ItemMax[blastech, GrandGrenadeLauncher] = 1;
$ItemMax[blastech, RPGLauncher] = 1;
$ItemMax[blastech, RPMLauncher] = 1;
$ItemMax[blastech, ShockCannon] = 1;
$ItemMax[blastech, RPEMPLauncher] = 1;
$ItemMax[blastech, Mortar] = 1;
$ItemMax[blastech, ImpactMortar] = 1;
$ItemMax[blastech, RubberMortar] = 1;
$ItemMax[blastech, ElectroMortar] = 1;
$ItemMax[blastech, MineLauncher] = 1;
$ItemMax[blastech, HyperB] = 1;
$ItemMax[blastech, IonGun] = 1;
$ItemMax[blastech, MBCannon] = 1;
$ItemMax[blastech, Cutter] = 1;
$ItemMax[blastech, PTCannon] = 1;
$ItemMax[blastech, BabyNukeMortar] = 1;
$ItemMax[blastech, ReaverLauncher] = 1;
$ItemMax[blastech, PlasmaGun] = 1;
$ItemMax[blastech, EnergyRifle] = 1;
$ItemMax[blastech, RocketLauncher] = 1;
$ItemMax[blastech, EMPGrenadeLauncher] = 1;
$ItemMax[blastech, TargetingLaser] = 1;
$ItemMax[blastech, MineAmmo] = 3;
$ItemMax[blastech, Grenade] = 6;
$ItemMax[blastech, Beacon] = 3;
$ItemMax[blastech, RepairKit] = 3;
$ItemMax[blastech, LPistol] = 1;
$ItemMax[blastech, Rifle] = 1;
$ItemMax[blastech, MassDriver] = 1;
$ItemMax[blastech, PBW] = 1;
$ItemMax[blastech, FusionGun] = 1;
$ItemMax[blastech, FlareGun] = 1;

$ItemMax[blastech, BulletAmmo] = 150;
$ItemMax[blastech, ReaverAmmo] = 50;
$ItemMax[blastech, GaussAmmo] = 150;
$ItemMax[blastech, VulcanAmmo] = 150;
$ItemMax[blastech, PlasmaAmmo] = 40;
$ItemMax[blastech, DiscAmmo] = 15;
$ItemMax[blastech, SDiscAmmo] = 15;
$ItemMax[blastech, GrenadeAmmo] = 25;
$ItemMax[blastech, GrandGrenadeAmmo] = 15;
$ItemMax[blastech, MortarAmmo] = 15;
$ItemMax[blastech, ImpactAmmo] = 15;
$ItemMax[blastech, RubberAmmo] = 15;
$ItemMax[blastech, ElectroAmmo] = 15;
$ItemMax[blastech, BabyNukeAmmo] = 15;
$ItemMax[blastech, MultiMineAmmo] = 15;
$ItemMax[blastech, RPGAmmo] = 25;
$ItemMax[blastech, RPMAmmo] = 15;
$ItemMax[blastech, RPEMPAmmo] = 15;
$ItemMax[blastech, RocketAmmo] = 30;
$ItemMax[blastech, EMPGrenadeAmmo] = 30;
$ItemMax[blastech, Bolts] = 25;
$ItemMax[blastech, Shells] = 100;
$ItemMax[blastech, Flares] = 100;
$ItemMax[blastech, Balls] = 15;

$ItemMax[blastech, EnergyPack] = 1;
$ItemMax[blastech, RepairPack] = 1;
$ItemMax[blastech, ShieldPack] = 1;
$ItemMax[blastech, ReaverPack] = 1;
$ItemMax[blastech, SensorJammerPack] = 1;
$ItemMax[blastech, MotionSensorPack] = 1;
$ItemMax[blastech, PulseSensorPack] = 1;
$ItemMax[blastech, DeployableSensorJammerPack] = 1;
$ItemMax[blastech, CameraPack] = 1;
$ItemMax[blastech, TurretPack] = 1;
$ItemMax[blastech, AmmoPack] = 1;
$ItemMax[blastech, DeployableInvPack] = 1;
$ItemMax[blastech, DeployableAmmoPack] = 1;
$ItemMax[blastech, FakeFlag] = 1;
$ItemMax[blastech, TeleportPack] = 1;
$ItemMax[blastech, BlasterPack] = 1;
$ItemMax[blastech, FlamerPack] = 1;
$ItemMax[blastech, ReactorPack] = 1;
$ItemMax[blastech, WildfirePack] = 1;
$ItemMax[blastech, AirbasePack] = 1;
$ItemMax[blastech, GroundbasePack] = 1;
$ItemMax[blastech, DoorfieldPack] = 1;
$ItemMax[blastech, HoloPack] = 1;
$ItemMax[blastech, HolowallPack] = 1;
$ItemMax[blastech, HologenPack] = 1;
$ItemMax[blastech, TreePack] = 1;
$ItemMax[blastech, TNTPack] = 1;
$ItemMax[blastech, DetPack] = 1;
$ItemMax[blastech, accelPPack] = 1;
$ItemMax[blastech, JailPack] = 1;
$ItemMax[blastech, JailcapPack] = 1;
$ItemMax[blastech, ObeliskPack] = 1;
$ItemMax[blastech, ObeliskPowerPack] = 1;
$ItemMax[blastech, CrystalPack] = 1;
$ItemMax[blastech, HyperPack] = 1;
$ItemMax[blastech, Slipstream] = 1;

$MaxWeapons[blastech] = 5;

//----------------------------------------------------------------------------
// Heavy Armor
//----------------------------------------------------------------------------
$DamageScale[harmor, $LandingDamageType] = 1.0;
$DamageScale[harmor, $ImpactDamageType] = 1.0;
$DamageScale[harmor, $CrushDamageType] = 1.0;
$DamageScale[harmor, $BulletDamageType] = 0.6;
$DamageScale[harmor, $PlasmaDamageType] = 0.4;
$DamageScale[harmor, $EnergyDamageType] = 0.7;
$DamageScale[harmor, $ExplosionDamageType] = 0.6;
$DamageScale[harmor, $MissileDamageType] = 0.6;
$DamageScale[harmor, $DebrisDamageType] = 0.8;
$DamageScale[harmor, $ShrapnelDamageType] = 0.8;
$DamageScale[harmor, $LaserDamageType] = 0.6;
$DamageScale[harmor, $MortarDamageType] = 0.7;
$DamageScale[harmor, $BlasterDamageType] = 0.7;
$DamageScale[harmor, $ElectricityDamageType] = 1.0;
$DamageScale[harmor, $MineDamageType] = 0.8;
$DamageScale[harmor, $MagneticDamageType] = 0.5;
$DamageScale[harmor, $RocketDamageType] = 1.0;
$DamageScale[harmor, $FusionDamageType] = 1.5;
$DamageScale[harmor, $DisruptorDamageType] = 1.0;
$DamageScale[harmor, $SonicDamageType] = 5.0;
$DamageScale[harmor, $IonDamageType] = 2.2;
$DamageScale[harmor, $DistortionDamageType] = 7.2;
$DamageScale[harmor, $EMPDamageType] = 1.0;
$DamageScale[harmor, $PulseDamageType] = 1.0;
$DamageScale[harmor, $SniperDamageType] = 1.0;
$DamageScale[harmor, $VulcanDamageType] = 1.0;
$DamageScale[harmor, $ShotgunDamageType] = 1.0;
$DamageScale[harmor, $NukeDamageType] = 10.0;
$DamageScale[harmor, $ZapDamageType] = 2.0;
$DamageScale[harmor, $RepairDamageType] = 1.0;
$DamageScale[harmor, $HeatDamageType] = 1.0;
$DamageScale[harmor, $PhotonDamageType] = 1.0;
$DamageScale[harmor, $PistolDamageType] = 1.0;
$DamageScale[harmor, $ATCDamageType] = 1.0;
$DamageScale[harmor, $StarDamageType] = 1.0;
$DamageScale[harmor, $ZapMortarDamageType] = 1.0;
$DamageScale[harmor, $ShockwaveDamageType] = 1.0;
$DamageScale[harmor, $QuantumDamageType] = 1.0;
$DamageScale[harmor, $BusterDamageType] = 1.0;
$DamageScale[harmor, $FluxDamageType] = 1.0;
$DamageScale[harmor, $FlierBombDamageType] = 1.0;
$DamageScale[harmor, $BustedDamageType] = 1.0;
$DamageScale[harmor, $PBWDamageType] = 1.0;
$DamageScale[harmor, $FlameDamageType] = 1.0;
$DamageScale[harmor, $IceDamageType] = 1.0;
$DamageScale[harmor, $RPGDamageType] = 1.0;
$DamageScale[harmor, $RPMDamageType] = 1.0;
$DamageScale[harmor, $EMPDamageType] = 0.5;
$DamageScale[harmor, $MethaneDamageType] = 1.0;
$DamageScale[harmor, $BurstDamageType] = 1.0;
$DamageScale[harmor, $ReaverDamageType] = 1.0;
$DamageScale[harmor, $RifleDamageType] = 1.0;
$DamageScale[harmor, $MassShotgunDamageType] = 1.0;
$DamageScale[harmor, $AutogunDamageType] = 1.0;
$DamageScale[harmor, $PistolDamageType] = 1.0;
$DamageScale[harmor, $AutogunDamageType] = 1.0;
$DamageScale[harmor, $GaussDamageType] = 1.0;
$DamageScale[harmor, $MBDamageType] = 1.0;
$DamageScale[harmor, $CutterDamageType] = 1.0;
$DamageScale[harmor, $NullDamageType] = 1.0;

$ItemMax[harmor, Blaster] = 1;
$ItemMax[harmor, Chaingun] = 1;
$ItemMax[harmor, Disclauncher] = 1;
$ItemMax[harmor, ATC] = 1;
$ItemMax[harmor, TacheonLauncher] = 1;
$ItemMax[harmor, MBCannon] = 1;
$ItemMax[harmor, Cutter] = 1;
$ItemMax[harmor, ReaverLauncher] = 1;
$ItemMax[harmor, GrenadeLauncher] = 1;
$ItemMax[harmor, Mortar] = 1;
$ItemMax[harmor, PlasmaGun] = 1;
$ItemMax[harmor, LaserRifle] = 0;
$ItemMax[harmor, EnergyRifle] = 1;
$ItemMax[harmor, TargetingLaser] = 1;
$ItemMax[harmor, RocketLauncher] = 1;
$ItemMax[harmor, EMPGrenadeLauncher] = 1;
$ItemMax[harmor, MagGun] = 1;
$ItemMax[harmor, MineAmmo] = 3;
$ItemMax[harmor, Grenade] = 8;
$ItemMax[harmor, Beacon] = 3;
$ItemMax[harmor, RepairKit] = 6;
$ItemMax[harmor, LCannon] = 1;
$ItemMax[harmor, BCannon] = 1;
$ItemMax[harmor, LPistol] = 1;
$ItemMax[harmor, Rifle] = 1;
$ItemMax[harmor, Shotgun] = 1;
$ItemMax[harmor, Autogun] = 1;
$ItemMax[harmor, FlameBlower] = 1;
$ItemMax[harmor, IceBlower] = 1;
$ItemMax[harmor, ElectroCannon] = 1;
$ItemMax[harmor, LaserGatling] = 1;
$ItemMax[harmor, PBW] = 1;
$ItemMax[harmor, DisruptorGatling] = 1;
$ItemMax[harmor, ShockCannon] = 1;
$ItemMax[harmor, Starburst] = 1;
$ItemMax[harmor, FusionGun] = 1;
$ItemMax[harmor, FlareGun] = 1;
$ItemMax[harmor, ConcunPistol] = 1;
$ItemMax[harmor, LaserCannon] = 1;
$ItemMax[gharmor, Starburst] = 1;

$ItemMax[harmor, BulletAmmo] = 200;
$ItemMax[harmor, ATCAmmo] = 100;
$ItemMax[harmor, PlasmaAmmo] = 50;
$ItemMax[harmor, DiscAmmo] = 15;
$ItemMax[harmor, GrenadeAmmo] = 15;
$ItemMax[harmor, ReaverAmmo] = 75;
$ItemMax[harmor, MortarAmmo] = 10;
$ItemMax[harmor, EMPGrenadeAmmo] = 30;
$ItemMax[harmor, Shells] = 250;
$ItemMax[harmor, Bolts] = 50;
$ItemMax[harmor, Flares] = 200;
$ItemMax[harmor, Balls] = 100;
$ItemMax[harmor, StarburstShells] = 10;

$ItemMax[harmor, EnergyPack] = 1;
$ItemMax[harmor, RepairPack] = 1;
$ItemMax[harmor, ShieldPack] = 1;
$ItemMax[harmor, ReaverPack] = 1;
$ItemMax[harmor, TacheonPack] = 1;
$ItemMax[harmor, SensorJammerPack] = 1;
$ItemMax[harmor, MotionSensorPack] = 1;
$ItemMax[harmor, PulseSensorPack] = 1;
$ItemMax[harmor, DeployableSensorJammerPack] = 1;
$ItemMax[harmor, CameraPack] = 1;
$ItemMax[harmor, TurretPack] = 1;
$ItemMax[harmor, AmmoPack] = 1;
$ItemMax[harmor, DeployableInvPack] = 1;
$ItemMax[harmor, DeployableAmmoPack] = 1;
$ItemMax[harmor, FakeFlag] = 1;
$ItemMax[harmor, SentryPack] = 1;
$ItemMax[harmor, RocketPack] = 1;
$ItemMax[harmor, ForceFieldPack] = 1;
$ItemMax[harmor, HyperPack] = 1;
$ItemMax[harmor, Slipstream] = 1;
$ItemMax[harmor, TeleportPack] = 1;
$ItemMax[harmor, RocketPack] = 1;
$ItemMax[harmor, ContainmentFieldPack] = 1;
$ItemMax[harmor, DeployableElf] = 1;
$ItemMax[harmor, LaserPack] = 1;
$ItemMax[harmor, RegenerationPack] = 1;
$ItemMax[harmor, JetfirePack] = 1;
$ItemMax[harmor, SMCPack] = 1;
$ItemMax[harmor, SPTPack] = 1;
$ItemMax[harmor, SPCPack] = 1;
$ItemMax[harmor, CrystalPack] = 1;
$ItemMax[harmor, DetPack] = 1;
$ItemMax[harmor, Groundbase] = 1;
$ItemMax[harmor, airbase] = 1;
$ItemMax[harmor, FlamerCannonPack] = 1;

$MaxWeapons[harmor] = 6;

//----------------------------------------------------------------------------
// Transformer Armor
//----------------------------------------------------------------------------
$DamageScale[transformer, $LandingDamageType] = 1.0;
$DamageScale[transformer, $ImpactDamageType] = 1.0;
$DamageScale[transformer, $CrushDamageType] = 1.0;
$DamageScale[transformer, $BulletDamageType] = 0.6;
$DamageScale[transformer, $PlasmaDamageType] = 0.4;
$DamageScale[transformer, $EnergyDamageType] = 0.7;
$DamageScale[transformer, $ExplosionDamageType] = 0.6;
$DamageScale[transformer, $MissileDamageType] = 0.6;
$DamageScale[transformer, $DebrisDamageType] = 0.8;
$DamageScale[transformer, $ShrapnelDamageType] = 0.8;
$DamageScale[transformer, $LaserDamageType] = 0.6;
$DamageScale[transformer, $MortarDamageType] = 0.7;
$DamageScale[transformer, $BlasterDamageType] = 0.7;
$DamageScale[transformer, $ElectricityDamageType] = 1.0;
$DamageScale[transformer, $MineDamageType] = 0.8;
$DamageScale[transformer, $MagneticDamageType] = 0.5;
$DamageScale[transformer, $RocketDamageType] = 1.0;
$DamageScale[transformer, $FusionDamageType] = 1.5;
$DamageScale[transformer, $DisruptorDamageType] = 1.0;
$DamageScale[transformer, $SonicDamageType] = 5.0;
$DamageScale[transformer, $IonDamageType] = 2.2;
$DamageScale[transformer, $DistortionDamageType] = 7.2;
$DamageScale[transformer, $EMPDamageType] = 1.0;
$DamageScale[transformer, $PulseDamageType] = 1.0;
$DamageScale[transformer, $SniperDamageType] = 1.0;
$DamageScale[transformer, $VulcanDamageType] = 1.0;
$DamageScale[transformer, $ShotgunDamageType] = 1.0;
$DamageScale[transformer, $NukeDamageType] = 10.0;
$DamageScale[transformer, $ZapDamageType] = 2.0;
$DamageScale[transformer, $RepairDamageType] = 1.0;
$DamageScale[transformer, $HeatDamageType] = 1.0;
$DamageScale[transformer, $PhotonDamageType] = 1.0;
$DamageScale[transformer, $PistolDamageType] = 1.0;
$DamageScale[transformer, $ATCDamageType] = 1.0;
$DamageScale[transformer, $StarDamageType] = 1.0;
$DamageScale[transformer, $ZapMortarDamageType] = 1.0;
$DamageScale[transformer, $ShockwaveDamageType] = 1.0;
$DamageScale[transformer, $QuantumDamageType] = 1.0;
$DamageScale[transformer, $BusterDamageType] = 1.0;
$DamageScale[transformer, $FluxDamageType] = 1.0;
$DamageScale[transformer, $FlierBombDamageType] = 1.0;
$DamageScale[transformer, $BustedDamageType] = 1.0;
$DamageScale[transformer, $PBWDamageType] = 1.0;
$DamageScale[transformer, $FlameDamageType] = 1.0;
$DamageScale[transformer, $IceDamageType] = 1.0;
$DamageScale[transformer, $RPGDamageType] = 1.0;
$DamageScale[transformer, $RPMDamageType] = 1.0;
$DamageScale[transformer, $EMPDamageType] = 0.5;
$DamageScale[transformer, $MethaneDamageType] = 1.0;
$DamageScale[transformer, $BurstDamageType] = 1.0;
$DamageScale[transformer, $ReaverDamageType] = 1.0;
$DamageScale[transformer, $RifleDamageType] = 1.0;
$DamageScale[transformer, $MassShotgunDamageType] = 1.0;
$DamageScale[transformer, $AutogunDamageType] = 1.0;
$DamageScale[transformer, $PistolDamageType] = 1.0;
$DamageScale[transformer, $AutogunDamageType] = 1.0;
$DamageScale[transformer, $GaussDamageType] = 1.0;
$DamageScale[transformer, $MBDamageType] = 1.0;
$DamageScale[transformer, $CutterDamageType] = 1.0;
$DamageScale[transformer, $NullDamageType] = 1.0;

$ItemMax[transformer, Blaster] = 1;
$ItemMax[transformer, Chaingun] = 1;
$ItemMax[transformer, Disclauncher] = 1;
$ItemMax[transformer, MBCannon] = 1;
$ItemMax[transformer, ReaverLauncher] = 1;
$ItemMax[transformer, PlasmaGun] = 1;
$ItemMax[transformer, LaserRifle] = 1;
$ItemMax[transformer, EnergyRifle] = 1;
$ItemMax[transformer, TargetingLaser] = 1;
$ItemMax[transformer, RocketLauncher] = 1;
$ItemMax[transformer, MineAmmo] = 3;
$ItemMax[transformer, Grenade] = 8;
$ItemMax[transformer, Beacon] = 3;
$ItemMax[transformer, RepairKit] = 6;
$ItemMax[transformer, FlameBlower] = 1;
$ItemMax[transformer, IceBlower] = 1;
$ItemMax[transformer, ElectroCannon] = 1;
$ItemMax[transformer, Starburst] = 1;
$ItemMax[transformer, FusionGun] = 1;
$ItemMax[transformer, LaserCannon] = 1;

$ItemMax[transformer, BulletAmmo] = 200;
$ItemMax[transformer, PlasmaAmmo] = 50;
$ItemMax[transformer, DiscAmmo] = 15;
$ItemMax[transformer, ReaverAmmo] = 75;
$ItemMax[transformer, Shells] = 250;
$ItemMax[transformer, Bolts] = 50;
$ItemMax[transformer, Flares] = 200;
$ItemMax[transformer, Balls] = 100;
$ItemMax[transformer, StarburstShells] = 15;
$ItemMax[gharmor, StarburstShells] = 25;

$ItemMax[transformer, JetfirePack] = 1;

$MaxWeapons[transformer] = 3;

//----------------------------------------------------------------------------
// light Female Armor
//----------------------------------------------------------------------------
$DamageScale[lfemale, $LandingDamageType] = 1.0;
$DamageScale[lfemale, $ImpactDamageType] = 1.0;	
$DamageScale[lfemale, $CrushDamageType] = 1.0;	
$DamageScale[lfemale, $BulletDamageType] = 1.2;
$DamageScale[lfemale, $PlasmaDamageType] = 1.0;
$DamageScale[lfemale, $EnergyDamageType] = 1.3;
$DamageScale[lfemale, $ExplosionDamageType] = 1.0;
$DamageScale[lfemale, $MissileDamageType] = 1.0;
$DamageScale[lfemale, $ShrapnelDamageType] = 1.2;
$DamageScale[lfemale, $DebrisDamageType] = 1.2;
$DamageScale[lfemale, $LaserDamageType] = 1.0;
$DamageScale[lfemale, $MortarDamageType] = 1.3;
$DamageScale[lfemale, $BlasterDamageType] = 1.3;
$DamageScale[lfemale, $ElectricityDamageType] = 1.0;
$DamageScale[lfemale, $MineDamageType] = 1.2;
$DamageScale[lfemale, $FusionDamageType] = 1.5;
$DamageScale[lfemale, $DisruptorDamageType] = 1.0;
$DamageScale[lfemale, $SonicDamageType] = 5.0;
$DamageScale[lfemale, $IonDamageType] = 2.2;
$DamageScale[lfemale, $DistortionDamageType] = 7.2;
$DamageScale[lfemale, $EMPDamageType] = 1.0;
$DamageScale[lfemale, $PulseDamageType] = 1.0;
$DamageScale[lfemale, $SniperDamageType] = 1.0;
$DamageScale[lfemale, $VulcanDamageType] = 1.0;
$DamageScale[lfemale, $ShotgunDamageType] = 1.0;
$DamageScale[lfemale, $NukeDamageType] = 10.0;
$DamageScale[lfemale, $ZapDamageType] = 2.0;
$DamageScale[lfemale, $RepairDamageType] = 1.0;
$DamageScale[lfemale, $HeatDamageType] = 1.0;
$DamageScale[lfemale, $PhotonDamageType] = 1.0;
$DamageScale[lfemale, $PistolDamageType] = 1.0;
$DamageScale[lfemale, $ATCDamageType] = 1.0;
$DamageScale[lfemale, $StarDamageType] = 1.0;
$DamageScale[lfemale, $ZapMortarDamageType] = 1.0;
$DamageScale[lfemale, $ShockwaveDamageType] = 1.0;
$DamageScale[lfemale, $QuantumDamageType] = 1.0;
$DamageScale[lfemale, $BusterDamageType] = 1.0;
$DamageScale[lfemale, $FluxDamageType] = 1.0;
$DamageScale[lfemale, $FlierBombDamageType] = 1.0;
$DamageScale[lfemale, $BustedDamageType] = 1.0;
$DamageScale[lfemale, $PBWDamageType] = 1.0;
$DamageScale[lfemale, $FlameDamageType] = 1.0;
$DamageScale[lfemale, $IceDamageType] = 1.0;
$DamageScale[lfemale, $RPGDamageType] = 1.0;
$DamageScale[lfemale, $RPMDamageType] = 1.0;
$DamageScale[lfemale, $EMPDamageType] = 0.5;
$DamageScale[lfemale, $MethaneDamageType] = 1.0;
$DamageScale[lfemale, $BurstDamageType] = 1.0;
$DamageScale[lfemale, $ReaverDamageType] = 1.0;
$DamageScale[lfemale, $RifleDamageType] = 1.0;
$DamageScale[lfemale, $MassShotgunDamageType] = 1.0;
$DamageScale[lfemale, $AutogunDamageType] = 1.0;
$DamageScale[lfemale, $PistolDamageType] = 1.0;
$DamageScale[lfemale, $AutogunDamageType] = 1.0;
$DamageScale[lfemale, $GaussDamageType] = 1.0;
$DamageScale[lfemale, $MBDamageType] = 1.0;
$DamageScale[lfemale, $CutterDamageType] = 1.0;
$DamageScale[lfemale, $NullDamageType] = 1.0;

$ItemMax[lfemale, Blaster] = 1;
$ItemMax[lfemale, Chaingun] = 1;
$ItemMax[lfemale, DiscLauncher] = 1;
$ItemMax[lfemale, Mortar] = 0;
$ItemMax[lfemale, PlasmaGun] = 1;
$ItemMax[lfemale, LaserRifle] = 1;
$ItemMax[lfemale, EnergyRifle] = 1;
$ItemMax[lfemale, TargetingLaser] = 1;
$ItemMax[lfemale, MineAmmo] = 3;
$ItemMax[lfemale, Grenade] = 5;
$ItemMax[lfemale, Beacon]  = 3;
$ItemMax[lfemale, RepairKit] = 2;
//-----------------------------
$ItemMax[lfemale, GatlingBlaster] = 1;
$ItemMax[lfemale, GatlingDisruptor] = 1;
$ItemMax[lfemale, LaserGatling] = 1;
$ItemMax[lfemale, DisruptorGun] = 1;
$ItemMax[lfemale, GaussCannon] = 1;
$ItemMax[lfemale, VulcanCannon] = 1;
$ItemMax[lfemale, SDiscLauncher] = 1;
$ItemMax[lfemale, GrenadeLauncher] = 1;
$ItemMax[lfemale, RPGLauncher] = 1;
$ItemMax[lfemale, RPEMPLauncher] = 1;
$ItemMax[lfemale, MBCannon] = 1;
$ItemMax[lfemale, Cutter] = 1;
$ItemMax[lfemale, ReaverLauncher] = 1;
$ItemMax[lfemale, Pistol] = 1;
$ItemMax[lfemale, IceBlower] = 1;
$ItemMax[lfemale, DartGun] = 1;
$ItemMax[lfemale, Autogun] = 1;
$ItemMax[lfemale, ElectroCannon] = 1;
$ItemMax[lfemale, Reassembler] = 1;

$ItemMax[lfemale, BulletAmmo] = 100;
$ItemMax[lfemale, PlasmaAmmo] = 30;
$ItemMax[lfemale, DiscAmmo] = 25;
$ItemMax[lfemale, SDiscAmmo] = 25;
$ItemMax[lfemale, GrenadeAmmo] = 10;
$ItemMax[lfemale, RPGAmmo] = 10;
$ItemMax[lfemale, RPEMPAmmo] = 15;
$ItemMax[lfemale, MortarAmmo] = 10;
//-------------------------------
$ItemMax[lfemale, ReaverAmmo] = 25;
$ItemMax[lfemale, VulcanAmmo] = 100;
$ItemMax[lfemale, GaussAmmo] = 100;
$ItemMax[lfemale, Shells] = 50;
$ItemMax[lfemale, Darts] = 25;

$ItemMax[lfemale, EnergyPack] = 1;
$ItemMax[lfemale, RepairPack] = 1;
$ItemMax[lfemale, ShieldPack] = 1;
$ItemMax[lfemale, SensorJammerPack] = 1;
$ItemMax[lfemale, MotionSensorPack] = 1;
$ItemMax[lfemale, PulseSensorPack] = 1;
$ItemMax[lfemale, DeployableSensorJammerPack] = 1;
$ItemMax[lfemale, CameraPack] = 1;
$ItemMax[lfemale, TurretPack] = 1;
$ItemMax[lfemale, AmmoPack] = 1;
$ItemMax[lfemale, DeployableInvPack] = 0;
$ItemMax[lfemale, DeployableAmmoPack] = 0;
$ItemMax[lfemale, ReaverPack] = 1;
$ItemMax[lfemale, FakeFlag] = 1;
$ItemMax[lfemale, ForceFieldPack] = 1;
$ItemMax[lfemale, CloakingDevice] = 1;
$ItemMax[lfemale, ForceFieldPack] = 1;
$ItemMax[lfemale, SteaLTHsHIELDpACK] = 1;
$ItemMax[lfemale, HyperPack] = 1;
$ItemMax[lfemale, Slipstream] = 1;
$ItemMax[lfemale, LaserPack] = 1;
$ItemMax[lfemale, RegenerationPack] = 1;
$ItemMax[lfemale, EPodPack] = 1;
$ItemMax[lfemale, SKYPack] = 1;
$ItemMax[lfemale, EXPack] = 1;
$ItemMax[lfemale, AAAPack] = 1;
$ItemMax[lfemale, IScoutPack] = 1;
$ItemMax[lfemale, BTScoutPack] = 1;
$ItemMax[lfemale, PyroGXPack] = 1;
$ItemMax[lfemale, PyroPack] = 1;
$ItemMax[lfemale, PyroGxLPack] = 1;
$ItemMax[lfemale, DoorFieldPack] = 1;
$ItemMax[lfemale, TNTpack] = 1;
$ItemMax[lfemale, TreePack] = 1;
$ItemMax[lfemale, Holopack] = 1;
$ItemMax[lfemale, Blasterpack] = 1;
$ItemMax[lfemale, Flamerpack] = 1;
$ItemMax[lfemale, Reactorpack] = 1;

$MaxWeapons[lfemale] = 4;

//----------------------------------------------------------------------------
// Disrupter Armor 
//----------------------------------------------------------------------------

$DamageScale[disrupter, $LandingDamageType] = 1.0;
$DamageScale[disrupter, $ImpactDamageType] = 1.0;
$DamageScale[disrupter, $CrushDamageType] = 1.0;
$DamageScale[disrupter, $BulletDamageType] = 1.2;
$DamageScale[disrupter, $PlasmaDamageType] = 1.0;
$DamageScale[disrupter, $EnergyDamageType] = 0.3;
$DamageScale[disrupter, $ExplosionDamageType] = 1.0;
$DamageScale[disrupter, $MissileDamageType] = 1.0;
$DamageScale[disrupter, $DebrisDamageType] = 1.2;
$DamageScale[disrupter, $ShrapnelDamageType] = 1.2;
$DamageScale[disrupter, $LaserDamageType] = 0.5;
$DamageScale[disrupter, $MortarDamageType] = 1.3;
$DamageScale[disrupter, $BlasterDamageType] = 0.3;
$DamageScale[disrupter, $ElectricityDamageType] = 1.0;
$DamageScale[disrupter, $MineDamageType] = 1.2;
$DamageScale[disrupter, $MagneticDamageType] = 0.5;
$DamageScale[disrupter, $RocketDamageType] = 1.0;
$DamageScale[disrupter, $FusionDamageType] = -1.5;
$DamageScale[disrupter, $DisruptorDamageType] = -1.0;
$DamageScale[disrupter, $SonicDamageType] = 5.0;
$DamageScale[disrupter, $IonDamageType] = 2.2;
$DamageScale[disrupter, $DistortionDamageType] = 7.2;
$DamageScale[disrupter, $EMPDamageType] = 1.0;
$DamageScale[disrupter, $PulseDamageType] = 1.0;
$DamageScale[disrupter, $SniperDamageType] = 1.0;
$DamageScale[disrupter, $VulcanDamageType] = 1.0;
$DamageScale[disrupter, $ShotgunDamageType] = 1.0;
$DamageScale[disrupter, $NukeDamageType] = 10.0;
$DamageScale[disrupter, $ZapDamageType] = 2.0;
$DamageScale[disrupter, $RepairDamageType] = 1.0;
$DamageScale[disrupter, $HeatDamageType] = 1.0;
$DamageScale[disrupter, $PhotonDamageType] = 1.0;
$DamageScale[disrupter, $PistolDamageType] = 1.0;
$DamageScale[disrupter, $ATCDamageType] = 1.0;
$DamageScale[disrupter, $StarDamageType] = 1.0;
$DamageScale[disrupter, $ZapMortarDamageType] = 1.0;
$DamageScale[disrupter, $ShockwaveDamageType] = 1.0;
$DamageScale[disrupter, $QuantumDamageType] = 1.0;
$DamageScale[disrupter, $BusterDamageType] = 1.0;
$DamageScale[disrupter, $FluxDamageType] = 1.0;
$DamageScale[disrupter, $FlierBombDamageType] = 1.0;
$DamageScale[disrupter, $BustedDamageType] = 1.0;
$DamageScale[disrupter, $PBWDamageType] = 1.0;
$DamageScale[disrupter, $FlameDamageType] = 1.0;
$DamageScale[disrupter, $IceDamageType] = 1.0;
$DamageScale[disrupter, $RPGDamageType] = 1.0;
$DamageScale[disrupter, $RPMDamageType] = 1.0;
$DamageScale[disrupter, $EMPDamageType] = 0.5;
$DamageScale[disrupter, $MethaneDamageType] = 1.0;
$DamageScale[disrupter, $BurstDamageType] = 1.0;
$DamageScale[disrupter, $ReaverDamageType] = 1.0;
$DamageScale[disrupter, $RifleDamageType] = 1.0;
$DamageScale[disrupter, $MassShotgunDamageType] = 1.0;
$DamageScale[disrupter, $AutogunDamageType] = 1.0;
$DamageScale[disrupter, $PistolDamageType] = 1.0;
$DamageScale[disrupter, $AutogunDamageType] = 1.0;
$DamageScale[disrupter, $GaussDamageType] = 1.0;
$DamageScale[disrupter, $MBDamageType] = 1.0;
$DamageScale[disrupter, $CutterDamageType] = 1.0;
$DamageScale[disrupter, $NullDamageType] = 1.0;

$ItemMax[disrupter, Blaster] = 1;
$ItemMax[disrupter, TargetingLaser] = 1;
$ItemMax[disrupter, MineAmmo] = 3;
$ItemMax[disrupter, Grenade] = 5;
$ItemMax[disrupter, Beacon]  = 3;
$ItemMax[disrupter, RepairKit] = 2;
//-----------------------------
$ItemMax[disrupter, Disruptor] = 1;
$ItemMax[disrupter, LPistol] = 1;
$ItemMax[disrupter, Pistol] = 1;
$ItemMax[disrupter, Reassembler] = 1;

$ItemMax[disrupter, Shells] = 512;

$ItemMax[disrupter, EnergyPack] = 1;
$ItemMax[disrupter, RepairPack] = 1;
$ItemMax[disrupter, ShieldPack] = 1;
$ItemMax[disrupter, AmmoPack] = 1;
$ItemMax[disrupter, CloakingDevice] = 1;
$ItemMax[disrupter, CrystalPack] = 1;

$MaxWeapons[disrupter] = 2;

//----------------------------------------------------------------------------
// Vulcan Female Armor
//----------------------------------------------------------------------------

$DamageScale[vulcanf, $LandingDamageType] = 1.0;
$DamageScale[vulcanf, $ImpactDamageType] = 1.0;
$DamageScale[vulcanf, $CrushDamageType] = 1.0;
$DamageScale[vulcanf, $BulletDamageType] = -0.2;
$DamageScale[vulcanf, $PlasmaDamageType] = 1.0;
$DamageScale[vulcanf, $EnergyDamageType] = 1.3;
$DamageScale[vulcanf, $ExplosionDamageType] = 1.0;
$DamageScale[vulcanf, $MissileDamageType] = 1.0;
$DamageScale[vulcanf, $DebrisDamageType] = 1.2;
$DamageScale[vulcanf, $ShrapnelDamageType] = 1.2;
$DamageScale[vulcanf, $LaserDamageType] = 1.0;
$DamageScale[vulcanf, $MortarDamageType] = 1.3;
$DamageScale[vulcanf, $BlasterDamageType] = 1.3;
$DamageScale[vulcanf, $ElectricityDamageType] = 1.0;
$DamageScale[vulcanf, $MineDamageType] = 1.2;
$DamageScale[vulcanf, $MagneticDamageType] = 0.5;
$DamageScale[vulcanf, $RocketDamageType] = 1.0;
$DamageScale[vulcanf, $FusionDamageType] = 1.5;
$DamageScale[vulcanf, $DisruptorDamageType] = 1.0;
$DamageScale[vulcanf, $SonicDamageType] = 5.0;
$DamageScale[vulcanf, $IonDamageType] = 2.2;
$DamageScale[vulcanf, $DistortionDamageType] = 7.2;
$DamageScale[vulcanf, $EMPDamageType] = 1.0;
$DamageScale[vulcanf, $PulseDamageType] = 1.0;
$DamageScale[vulcanf, $SniperDamageType] = 1.0;
$DamageScale[vulcanf, $VulcanDamageType] = -0.1;
$DamageScale[vulcanf, $ShotgunDamageType] = 0.05;
$DamageScale[vulcanf, $NukeDamageType] = 10.0;
$DamageScale[vulcanf, $ZapDamageType] = 2.0;
$DamageScale[vulcanf, $RepairDamageType] = 1.0;
$DamageScale[vulcanf, $HeatDamageType] = 1.0;
$DamageScale[vulcanf, $PhotonDamageType] = 1.0;
$DamageScale[vulcanf, $PistolDamageType] = 1.0;
$DamageScale[vulcanf, $ATCDamageType] = 1.0;
$DamageScale[vulcanf, $StarDamageType] = 1.0;
$DamageScale[vulcanf, $ZapMortarDamageType] = 1.0;
$DamageScale[vulcanf, $ShockwaveDamageType] = 1.0;
$DamageScale[vulcanf, $QuantumDamageType] = 1.0;
$DamageScale[vulcanf, $BusterDamageType] = 1.0;
$DamageScale[vulcanf, $FluxDamageType] = 1.0;
$DamageScale[vulcanf, $FlierBombDamageType] = 1.0;
$DamageScale[vulcanf, $BustedDamageType] = 1.0;
$DamageScale[vulcanf, $PBWDamageType] = 1.0;
$DamageScale[vulcanf, $FlameDamageType] = 1.0;
$DamageScale[vulcanf, $IceDamageType] = 1.0;
$DamageScale[vulcanf, $RPGDamageType] = 1.0;
$DamageScale[vulcanf, $RPMDamageType] = 1.0;
$DamageScale[vulcanf, $EMPDamageType] = 0.5;
$DamageScale[vulcanf, $MethaneDamageType] = 1.0;
$DamageScale[vulcanf, $BurstDamageType] = 1.0;
$DamageScale[vulcanf, $ReaverDamageType] = 1.0;
$DamageScale[vulcanf, $RifleDamageType] = -0.5;
$DamageScale[vulcanf, $MassShotgunDamageType] = 1.0;
$DamageScale[vulcanf, $AutogunDamageType] = 0;
$DamageScale[vulcanf, $PistolDamageType] = 0;
$DamageScale[vulcanf, $GaussDamageType] = 1.0;
$DamageScale[vulcanf, $MBDamageType] = 1.0;
$DamageScale[vulcanf, $CutterDamageType] = 0.5;
$DamageScale[vulcanf, $NullDamageType] = 1.0;

$ItemMax[vulcanf, Chaingun] = 1;
$ItemMax[vulcanf, TargetingLaser] = 1;
$ItemMax[vulcanf, MineAmmo] = 3;
$ItemMax[vulcanf, Grenade] = 5;
$ItemMax[vulcanf, Beacon]  = 3;
$ItemMax[vulcanf, RepairKit] = 2;
//-----------------------------
$ItemMax[vulcanf, GatlingBlaster] = 1;
$ItemMax[vulcanf, GatlingDisruptor] = 1;
$ItemMax[vulcanf, ATC] = 1;
$ItemMax[vulcanf, LaserGatling] = 1;
$ItemMax[vulcanf, GaussCannon] = 1;
$ItemMax[vulcanf, VulcanCannon] = 1;
$ItemMax[vulcanf, Cutter] = 1;
$ItemMax[vulcanf, ReaverLauncher] = 1;
$ItemMax[vulcanf, LPistol] = 1;
$ItemMax[vulcanf, Autogun] = 1;
$ItemMax[vulcanf, Reassembler] = 1;

$ItemMax[vulcanf, BulletAmmo] = 100;
$ItemMax[vulcanf, ATCAmmo] = 50;
//-------------------------------
$ItemMax[vulcanf, ReaverAmmo] = 25;
$ItemMax[vulcanf, VulcanAmmo] = 500;
$ItemMax[vulcanf, GaussAmmo] = 100;
$ItemMax[vulcanf, Shells] = 50;

$ItemMax[vulcanf, EnergyPack] = 1;
$ItemMax[vulcanf, RepairPack] = 1;
$ItemMax[vulcanf, ShieldPack] = 1;
$ItemMax[vulcanf, SensorJammerPack] = 1;
$ItemMax[vulcanf, MotionSensorPack] = 1;
$ItemMax[vulcanf, PulseSensorPack] = 1;
$ItemMax[vulcanf, DeployableSensorJammerPack] = 1;
$ItemMax[vulcanf, AmmoPack] = 1;
$ItemMax[vulcanf, ReaverPack] = 1;
$ItemMax[vulcanf, FakeFlag] = 1;
$ItemMax[vulcanf, SteaLTHsHIELDpACK] = 1;
$ItemMax[vulcanf, HyperPack] = 1;
$ItemMax[vulcanf, CloakingDevice] = 1;
$ItemMax[vulcanf, Reactorpack] = 1;

$MaxWeapons[vulcanf] = 4;

//----------------------------------------------------------------------------
// Medium Female Armor
//----------------------------------------------------------------------------
$DamageScale[mfemale, $LandingDamageType] = 1.0;
$DamageScale[mfemale, $ImpactDamageType] = 1.0;
$DamageScale[mfemale, $CrushDamageType] = 1.0;
$DamageScale[mfemale, $BulletDamageType] = 1.0;
$DamageScale[mfemale, $EnergyDamageType] = 1.0;
$DamageScale[mfemale, $PlasmaDamageType] = 0.6;
$DamageScale[mfemale, $ExplosionDamageType] = 1.0;
$DamageScale[mfemale, $MissileDamageType] = 1.0;
$DamageScale[mfemale, $ShrapnelDamageType] = 1.0;
$DamageScale[mfemale, $DebrisDamageType] = 1.0;
$DamageScale[mfemale, $LaserDamageType] = 1.0;
$DamageScale[mfemale, $MortarDamageType] = 1.0;
$DamageScale[mfemale, $BlasterDamageType] = 1.0;
$DamageScale[mfemale, $ElectricityDamageType] = 1.0;
$DamageScale[mfemale, $MineDamageType] = 1.0;
$DamageScale[mfemale, $FusionDamageType] = 1.5;
$DamageScale[mfemale, $DisruptorDamageType] = 1.0;
$DamageScale[mfemale, $SonicDamageType] = 5.0;
$DamageScale[mfemale, $IonDamageType] = 2.2;
$DamageScale[mfemale, $DistortionDamageType] = 7.2;
$DamageScale[mfemale, $EMPDamageType] = 1.0;
$DamageScale[mfemale, $PulseDamageType] = 1.0;
$DamageScale[mfemale, $SniperDamageType] = 1.0;
$DamageScale[mfemale, $VulcanDamageType] = 1.0;
$DamageScale[mfemale, $ShotgunDamageType] = 1.0;
$DamageScale[mfemale, $NukeDamageType] = 10.0;
$DamageScale[mfemale, $ZapDamageType] = 2.0;
$DamageScale[mfemale, $RepairDamageType] = 1.0;
$DamageScale[mfemale, $HeatDamageType] = 1.0;
$DamageScale[mfemale, $PhotonDamageType] = 1.0;
$DamageScale[mfemale, $PistolDamageType] = 1.0;
$DamageScale[mfemale, $ATCDamageType] = 1.0;
$DamageScale[mfemale, $StarDamageType] = 1.0;
$DamageScale[mfemale, $ZapMortarDamageType] = 1.0;
$DamageScale[mfemale, $ShockwaveDamageType] = 1.0;
$DamageScale[mfemale, $QuantumDamageType] = 1.0;
$DamageScale[mfemale, $BusterDamageType] = 1.0;
$DamageScale[mfemale, $FluxDamageType] = 1.0;
$DamageScale[mfemale, $FlierBombDamageType] = 1.0;
$DamageScale[mfemale, $BustedDamageType] = 1.0;
$DamageScale[mfemale, $PBWDamageType] = 1.0;
$DamageScale[mfemale, $FlameDamageType] = 1.0;
$DamageScale[mfemale, $IceDamageType] = 1.0;
$DamageScale[mfemale, $RPGDamageType] = 1.0;
$DamageScale[mfemale, $RPMDamageType] = 1.0;
$DamageScale[mfemale, $EMPDamageType] = 0.5;
$DamageScale[mfemale, $MethaneDamageType] = 1.0;
$DamageScale[mfemale, $BurstDamageType] = 1.0;
$DamageScale[mfemale, $ReaverDamageType] = 1.0;
$DamageScale[mfemale, $RifleDamageType] = 1.0;
$DamageScale[mfemale, $MassShotgunDamageType] = 1.0;
$DamageScale[mfemale, $AutogunDamageType] = 1.0;
$DamageScale[mfemale, $PistolDamageType] = 1.0;
$DamageScale[mfemale, $AutogunDamageType] = 1.0;
$DamageScale[mfemale, $GaussDamageType] = 1.0;
$DamageScale[mfemale, $MBDamageType] = 1.0;
$DamageScale[mfemale, $CutterDamageType] = 1.0;
$DamageScale[mfemale, $NullDamageType] = 1.0;

$ItemMax[mfemale, Blaster] = 1;
$ItemMax[mfemale, Chaingun] = 1;
$ItemMax[mfemale, GaussCannon] = 1;
$ItemMax[mfemale, VulcanCannon] = 1;
$ItemMax[mfemale, DiscLauncher] = 1;
$ItemMax[mfemale, SDiscLauncher] = 1;
$ItemMax[mfemale, GrenadeLauncher] = 1;
$ItemMax[mfemale, GrandGrenadeLauncher] = 1;
$ItemMax[mfemale, RPGLauncher] = 1;
$ItemMax[mfemale, RPMLauncher] = 1;
$ItemMax[mfemale, RPEMPLauncher] = 1;
$ItemMax[mfemale, Mortar] = 1;
$ItemMax[mfemale, ImpactMortar] = 1;
$ItemMax[mfemale, RubberMortar] = 1;
$ItemMax[mfemale, ElectroMortar] = 1;
$ItemMax[mfemale, MineLauncher] = 1;
$ItemMax[mfemale, HyperB] = 1;
$ItemMax[mfemale, SPlas] = 1;
$ItemMax[mfemale, IonGun] = 1;
$ItemMax[mfemale, GatlingBlaster] = 1;
$ItemMax[mfemale, MBCannon] = 1;
$ItemMax[mfemale, Cutter] = 1;
$ItemMax[mfemale, PTCannon] = 1;
$ItemMax[mfemale, IONCannon] = 1;
$ItemMax[mfemale, ShockCannon] = 1;
$ItemMax[mfemale, BabyNukeMortar] = 1;
$ItemMax[mfemale, ReaverLauncher] = 1;
$ItemMax[mfemale, PlasmaGun] = 1;
$ItemMax[mfemale, LaserRifle] = 1;
$ItemMax[mfemale, EnergyRifle] = 1;
$ItemMax[mfemale, RocketLauncher] = 1;
$ItemMax[mfemale, EMPGrenadeLauncher] = 1;
$ItemMax[mfemale, MagGun] = 1;
$ItemMax[mfemale, TargetingLaser] = 1;
$ItemMax[mfemale, MineAmmo] = 3;
$ItemMax[mfemale, Grenade] = 6;
$ItemMax[mfemale, Beacon] = 3;
$ItemMax[mfemale, RepairKit] = 3;
$ItemMax[mfemale, LPistol] = 1;
$ItemMax[mfemale, Autogun] = 1;
$ItemMax[mfemale, Rifle] = 1;
$ItemMax[mfemale, MassDriver] = 1;
$ItemMax[mfemale, Shotgun] = 1;
$ItemMax[mfemale, FlameBlower] = 1;
$ItemMax[mfemale, RFL] = 1;
$ItemMax[mfemale, PBW] = 1;
$ItemMax[mfemale, FusionGun] = 1;
$ItemMax[mfemale, FlareGun] = 1;

$ItemMax[mfemale, BulletAmmo] = 150;
$ItemMax[mfemale, ReaverAmmo] = 50;
$ItemMax[mfemale, GaussAmmo] = 150;
$ItemMax[mfemale, VulcanAmmo] = 150;
$ItemMax[mfemale, PlasmaAmmo] = 40;
$ItemMax[mfemale, DiscAmmo] = 15;
$ItemMax[mfemale, SDiscAmmo] = 15;
$ItemMax[mfemale, RDiscAmmo] = 15;
$ItemMax[mfemale, GrenadeAmmo] = 25;
$ItemMax[mfemale, GrandGrenadeAmmo] = 15;
$ItemMax[mfemale, MortarAmmo] = 15;
$ItemMax[mfemale, ImpactAmmo] = 15;
$ItemMax[mfemale, RubberAmmo] = 15;
$ItemMax[mfemale, ElectroAmmo] = 15;
$ItemMax[mfemale, BabyNukeAmmo] = 15;
$ItemMax[mfemale, MultiMineAmmo] = 15;
$ItemMax[mfemale, RPGAmmo] = 25;
$ItemMax[mfemale, RPMAmmo] = 15;
$ItemMax[mfemale, RPEMPAmmo] = 15;
$ItemMax[mfemale, RocketAmmo] = 30;
$ItemMax[mfemale, EMPGrenadeAmmo] = 30;
$ItemMax[mfemale, Bolts] = 50;
$ItemMax[mfemale, Shells] = 100;
$ItemMax[mfemale, Flares] = 100;
$ItemMax[mfemale, Balls] = 15;

$ItemMax[mfemale, EnergyPack] = 1;
$ItemMax[mfemale, RepairPack] = 1;
$ItemMax[mfemale, ShieldPack] = 1;
$ItemMax[mfemale, ReaverPack] = 1;
$ItemMax[mfemale, SensorJammerPack] = 1;
$ItemMax[mfemale, MotionSensorPack] = 1;
$ItemMax[mfemale, PulseSensorPack] = 1;
$ItemMax[mfemale, DeployableSensorJammerPack] = 1;
$ItemMax[mfemale, CameraPack] = 1;
$ItemMax[mfemale, TurretPack] = 1;
$ItemMax[mfemale, AmmoPack] = 1;
$ItemMax[mfemale, DeployableInvPack] = 1;
$ItemMax[mfemale, DeployableAmmoPack] = 1;
$ItemMax[mfemale, FakeFlag] = 1;
$ItemMax[mfemale, SentryPack] = 1;
$ItemMax[mfemale, RocketPack] = 1;
$ItemMax[mfemale, Slipstream] = 1;
$ItemMax[mfemale, TeleportPack] = 1;
$ItemMax[mfemale, RocketPack] = 1;
$ItemMax[mfemale, ContainmentFieldPack] = 1;
$ItemMax[mfemale, DeployableElf] = 1;
$ItemMax[mfemale, CloakingDevice] = 1;
$ItemMax[mfemale, LaserPack] = 1;
$ItemMax[mfemale, RegenerationPack] = 1;
$ItemMax[mfemale, BlasterPack] = 1;
$ItemMax[mfemale, FlamerPack] = 1;
$ItemMax[mfemale, ReactorPack] = 1;
$ItemMax[mfemale, WildfirePack] = 1;
$ItemMax[mfemale, SniperPack] = 1;
$ItemMax[mfemale, GunboyPack] = 1;
$ItemMax[mfemale, AirbasePack] = 1;
$ItemMax[mfemale, GroundbasePack] = 1;
$ItemMax[mfemale, DoorfieldPack] = 1;
$ItemMax[mfemale, HoloPack] = 1;
$ItemMax[mfemale, HolowallPack] = 1;
$ItemMax[mfemale, HologenPack] = 1;
$ItemMax[mfemale, TreePack] = 1;
$ItemMax[mfemale, TNTPack] = 1;
$ItemMax[mfemale, DetPack] = 1;
$ItemMax[mfemale, accelPPack] = 1;
$ItemMax[mfemale, JailPack] = 1;
$ItemMax[mfemale, JailcapPack] = 1;
$ItemMax[mfemale, ObeliskPack] = 1;
$ItemMax[mfemale, ObeliskPowerPack] = 1;

$MaxWeapons[mfemale] = 5;

//----------------------------------------------------------------------------
// BlasTech Female Armor
//----------------------------------------------------------------------------
$DamageScale[blastechf, $LandingDamageType] = 1.0;
$DamageScale[blastechf, $ImpactDamageType] = 1.0;
$DamageScale[blastechf, $CrushDamageType] = 1.0;
$DamageScale[blastechf, $BulletDamageType] = 1.0;
$DamageScale[blastechf, $PlasmaDamageType] = 0;
$DamageScale[blastechf, $EnergyDamageType] = 1.0;
$DamageScale[blastechf, $ExplosionDamageType] = -0.2;
$DamageScale[blastechf, $MissileDamageType] = -0.2;
$DamageScale[blastechf, $ShrapnelDamageType] = -0.4;
$DamageScale[blastechf, $DebrisDamageType] = -0.2;
$DamageScale[blastechf, $LaserDamageType] = 1.0;
$DamageScale[blastechf, $MortarDamageType] = -0.5;
$DamageScale[blastechf, $BlasterDamageType] = 1.0;
$DamageScale[blastechf, $ElectricityDamageType] = 1.0;
$DamageScale[blastechf, $MineDamageType] = -0.5;
$DamageScale[blastechf, $MagneticDamageType] = 0.5;
$DamageScale[blastechf, $RocketDamageType] = -0.5;
$DamageScale[blastechf, $FusionDamageType] = 1.5;
$DamageScale[blastechf, $DisruptorDamageType] = 1.0;
$DamageScale[blastechf, $SonicDamageType] = 5.0;
$DamageScale[blastechf, $IonDamageType] = 2.2;
$DamageScale[blastechf, $DistortionDamageType] = 7.2;
$DamageScale[blastechf, $EMPDamageType] = -0.1;
$DamageScale[blastechf, $PulseDamageType] = 1.0;
$DamageScale[blastechf, $SniperDamageType] = 1.0;
$DamageScale[blastechf, $VulcanDamageType] = 1.0;
$DamageScale[blastechf, $ShotgunDamageType] = 1.0;
$DamageScale[blastechf, $NukeDamageType] = -1.0;
$DamageScale[blastechf, $ZapDamageType] = 2.0;
$DamageScale[blastechf, $RepairDamageType] = 1.0;
$DamageScale[blastechf, $HeatDamageType] = 1.0;
$DamageScale[blastechf, $PhotonDamageType] = -1.0;
$DamageScale[blastechf, $PistolDamageType] = 1.0;
$DamageScale[blastechf, $ATCDamageType] = -0.01;
$DamageScale[blastechf, $StarDamageType] = -1.0;
$DamageScale[blastechf, $ZapMortarDamageType] = 1.0;
$DamageScale[blastechf, $ShockwaveDamageType] = -1.0;
$DamageScale[blastechf, $QuantumDamageType] = -1.0;
$DamageScale[blastechf, $BusterDamageType] = 1.0;
$DamageScale[blastechf, $FluxDamageType] = 1.0;
$DamageScale[blastechf, $FlierBombDamageType] = -0.5;
$DamageScale[blastechf, $BustedDamageType] = -1.0;
$DamageScale[blastechf, $PBWDamageType] = 1.0;
$DamageScale[blastechf, $FlameDamageType] = 1.0;
$DamageScale[blastechf, $IceDamageType] = 1.0;
$DamageScale[blastechf, $RPGDamageType] = -0.2;
$DamageScale[blastechf, $RPMDamageType] = -0.5;
$DamageScale[blastechf, $EMPDamageType] = -0.1;
$DamageScale[blastechf, $MethaneDamageType] = 1.0;
$DamageScale[blastechf, $BurstDamageType] = -1.0;
$DamageScale[blastechf, $ReaverDamageType] = -0.01;
$DamageScale[blastechf, $RifleDamageType] = 1.0;
$DamageScale[blastechf, $MassShotgunDamageType] = -1.0;
$DamageScale[blastechf, $AutogunDamageType] = 1.0;
$DamageScale[blastechf, $PistolDamageType] = 1.0;
$DamageScale[blastechf, $AutogunDamageType] = 1.0;
$DamageScale[blastechf, $GaussDamageType] = -0.2;
$DamageScale[blastechf, $MBDamageType] = 1.0;
$DamageScale[blastechf, $CutterDamageType] = 1.0;
$DamageScale[blastechf, $NullDamageType] = 1.0;

$ItemMax[blastechf, Blaster] = 1;
$ItemMax[blastechf, Chaingun] = 1;
$ItemMax[blastechf, GaussCannon] = 1;
$ItemMax[blastechf, VulcanCannon] = 1;
$ItemMax[blastechf, DiscLauncher] = 1;
$ItemMax[blastechf, SDiscLauncher] = 1;
$ItemMax[blastechf, ShockCannon] = 1;
$ItemMax[blastechf, GrenadeLauncher] = 1;
$ItemMax[blastechf, GrandGrenadeLauncher] = 1;
$ItemMax[blastechf, RPGLauncher] = 1;
$ItemMax[blastechf, RPMLauncher] = 1;
$ItemMax[blastechf, RPEMPLauncher] = 1;
$ItemMax[blastechf, Mortar] = 1;
$ItemMax[blastechf, ImpactMortar] = 1;
$ItemMax[blastechf, RubberMortar] = 1;
$ItemMax[blastechf, ElectroMortar] = 1;
$ItemMax[blastechf, MineLauncher] = 1;
$ItemMax[blastechf, HyperB] = 1;
$ItemMax[blastechf, MBCannon] = 1;
$ItemMax[blastechf, Cutter] = 1;
$ItemMax[blastechf, PTCannon] = 1;
$ItemMax[blastechf, IonGun] = 1;
$ItemMax[blastechf, BabyNukeMortar] = 1;
$ItemMax[blastechf, ReaverLauncher] = 1;
$ItemMax[blastechf, PlasmaGun] = 1;
$ItemMax[blastechf, EnergyRifle] = 1;
$ItemMax[blastechf, RocketLauncher] = 1;
$ItemMax[blastechf, EMPGrenadeLauncher] = 1;
$ItemMax[blastechf, TargetingLaser] = 1;
$ItemMax[blastechf, MineAmmo] = 3;
$ItemMax[blastechf, Grenade] = 6;
$ItemMax[blastechf, Beacon] = 3;
$ItemMax[blastechf, RepairKit] = 3;
$ItemMax[blastechf, LPistol] = 1;
$ItemMax[blastechf, Rifle] = 1;
$ItemMax[blastechf, MassDriver] = 1;
$ItemMax[blastechf, PBW] = 1;
$ItemMax[blastechf, FusionGun] = 1;
$ItemMax[blastechf, FlareGun] = 1;

$ItemMax[blastechf, BulletAmmo] = 150;
$ItemMax[blastechf, ReaverAmmo] = 50;
$ItemMax[blastechf, GaussAmmo] = 150;
$ItemMax[blastechf, VulcanAmmo] = 150;
$ItemMax[blastechf, PlasmaAmmo] = 40;
$ItemMax[blastechf, DiscAmmo] = 15;
$ItemMax[blastechf, SDiscAmmo] = 15;
$ItemMax[blastechf, GrenadeAmmo] = 25;
$ItemMax[blastechf, GrandGrenadeAmmo] = 15;
$ItemMax[blastechf, MortarAmmo] = 15;
$ItemMax[blastechf, ImpactAmmo] = 15;
$ItemMax[blastechf, RubberAmmo] = 15;
$ItemMax[blastechf, ElectroAmmo] = 15;
$ItemMax[blastechf, BabyNukeAmmo] = 15;
$ItemMax[blastechf, MultiMineAmmo] = 15;
$ItemMax[blastechf, RPGAmmo] = 25;
$ItemMax[blastechf, RPMAmmo] = 15;
$ItemMax[blastechf, RPEMPAmmo] = 15;
$ItemMax[blastechf, RocketAmmo] = 30;
$ItemMax[blastechf, EMPGrenadeAmmo] = 30;
$ItemMax[blastechf, Bolts] = 25;
$ItemMax[blastechf, Shells] = 100;
$ItemMax[blastechf, Flares] = 100;
$ItemMax[blastechf, Balls] = 15;

$ItemMax[blastechf, EnergyPack] = 1;
$ItemMax[blastechf, RepairPack] = 1;
$ItemMax[blastechf, ShieldPack] = 1;
$ItemMax[blastechf, ReaverPack] = 1;
$ItemMax[blastechf, SensorJammerPack] = 1;
$ItemMax[blastechf, MotionSensorPack] = 1;
$ItemMax[blastechf, PulseSensorPack] = 1;
$ItemMax[blastechf, DeployableSensorJammerPack] = 1;
$ItemMax[blastechf, CameraPack] = 1;
$ItemMax[blastechf, TurretPack] = 1;
$ItemMax[blastechf, AmmoPack] = 1;
$ItemMax[blastechf, DeployableInvPack] = 1;
$ItemMax[blastechf, DeployableAmmoPack] = 1;
$ItemMax[blastechf, FakeFlag] = 1;
$ItemMax[blastechf, TeleportPack] = 1;
$ItemMax[blastechf, BlasterPack] = 1;
$ItemMax[blastechf, FlamerPack] = 1;
$ItemMax[blastechf, ReactorPack] = 1;
$ItemMax[blastechf, WildfirePack] = 1;
$ItemMax[blastechf, AirbasePack] = 1;
$ItemMax[blastechf, GroundbasePack] = 1;
$ItemMax[blastechf, DoorfieldPack] = 1;
$ItemMax[blastechf, HoloPack] = 1;
$ItemMax[blastechf, HolowallPack] = 1;
$ItemMax[blastechf, HologenPack] = 1;
$ItemMax[blastechf, TreePack] = 1;
$ItemMax[blastechf, TNTPack] = 1;
$ItemMax[blastechf, DetPack] = 1;
$ItemMax[blastechf, accelPPack] = 1;
$ItemMax[blastechf, JailPack] = 1;
$ItemMax[blastechf, JailcapPack] = 1;
$ItemMax[blastechf, ObeliskPack] = 1;
$ItemMax[blastechf, ObeliskPowerPack] = 1;
$ItemMax[blastechf, CrystalPack] = 1;
$ItemMax[blastechf, HyperPack] = 1;
$ItemMax[blastechf, Slipstream] = 1;

$MaxWeapons[blastechf] = 5;

//==================================================================
DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};
//==================================================================

//------------------------------------------------------------------
// Disruptor armor data:
//------------------------------------------------------------------

PlayerData disruptor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 255;
   jetEnergyDrain = 0.7;

	maxDamage = 1;
   maxForwardSpeed = 16.384;
   maxBackwardSpeed = 16;
   maxSideSpeed = 15.7;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 512;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 255;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Vulcan armor data:
//------------------------------------------------------------------

PlayerData vulcan
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.4;

	maxDamage = 0.75;
   maxForwardSpeed = 12.5;
   maxBackwardSpeed = 12;
   maxSideSpeed = 15;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 90;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// light armor data:
//------------------------------------------------------------------

PlayerData larmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium Armor data:
//------------------------------------------------------------------

PlayerData marmor
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
	maxEnergy = 80;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// BlasTech Armor data:
//------------------------------------------------------------------

PlayerData blastech
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.2;
   maxForwardSpeed = 10.0;
   maxBackwardSpeed = 9.0;
   maxSideSpeed = 8.5;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
	maxEnergy = 100;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 128;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Transformer Armor data:
//------------------------------------------------------------------

PlayerData transformer
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 32;
   minJetEnergy = 1;
   jetForce = 385;
   jetEnergyDrain = 0.1;

	maxDamage = 1.32;
   maxForwardSpeed = 7.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 6.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 255;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// Transformer Armor data:
//------------------------------------------------------------------

PlayerData harmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 24;
   minJetEnergy = 1;
   jetForce = 385;
   jetEnergyDrain = 0.1;

	maxDamage = 1;
   maxForwardSpeed = 7.0;
   maxBackwardSpeed = 6.0;
   maxSideSpeed = 5.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 150;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// Disrupter armor data:
//------------------------------------------------------------------

PlayerData disrupter
{
   className = "Armor";
   shapeFile = "lfemale";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 255;
   jetEnergyDrain = 0.7;

	maxDamage = 1;
   maxForwardSpeed = 16.384;
   maxBackwardSpeed = 16;
   maxSideSpeed = 15.7;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 512;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 255;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Vulcan armor data:
//------------------------------------------------------------------

PlayerData vulcanf
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.4;

	maxDamage = 0.75;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 90;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Light female data:
//------------------------------------------------------------------

PlayerData lfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;
   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };


   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.85;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.88;
   boxCrouchTorsoPercentage = 0.35;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium female data:
//------------------------------------------------------------------

PlayerData mfemale
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

   canCrouch = false;
	maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	maxEnergy = 80;
   mass = 13.0;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// BlasTech Armor data:
//------------------------------------------------------------------

PlayerData blastechf
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.2;
   maxForwardSpeed = 10.0;
   maxBackwardSpeed = 9.0;
   maxSideSpeed = 8.5;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
	maxEnergy = 100;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 128;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//----------------------------------------------------------------------------
// Engineer
//----------------------------------------------------------------------------
$DamageScale[engineer, $LandingDamageType] = 1.0;
$DamageScale[engineer, $ImpactDamageType] = 1.0;
$DamageScale[engineer, $CrushDamageType] = 1.0;
$DamageScale[engineer, $BulletDamageType] = 1.0;
$DamageScale[engineer, $PlasmaDamageType] = 0.6;
$DamageScale[engineer, $EnergyDamageType] = 1.0;
$DamageScale[engineer, $ExplosionDamageType] = 1.0;
$DamageScale[engineer, $MissileDamageType] = 1.0;
$DamageScale[engineer, $ShrapnelDamageType] = 1.0;
$DamageScale[engineer, $DebrisDamageType] = 1.0;
$DamageScale[engineer, $LaserDamageType] = 1.0;
$DamageScale[engineer, $MortarDamageType] = 1.0;
$DamageScale[engineer, $BlasterDamageType] = 1.0;
$DamageScale[engineer, $ElectricityDamageType] = 1.0;
$DamageScale[engineer, $MineDamageType] = 1.0;
$DamageScale[engineer, $MagneticDamageType] = 0.5;
$DamageScale[engineer, $RocketDamageType] = 1.0;
$DamageScale[engineer, $FusionDamageType] = 1.5;
$DamageScale[engineer, $DisruptorDamageType] = 1.0;
$DamageScale[engineer, $SonicDamageType] = 5.0;
$DamageScale[engineer, $IonDamageType] = 2.2;
$DamageScale[engineer, $DistortionDamageType] = 7.2;
$DamageScale[engineer, $EMPDamageType] = 1.0;
$DamageScale[engineer, $PulseDamageType] = 1.0;
$DamageScale[engineer, $SniperDamageType] = 1.0;
$DamageScale[engineer, $VulcanDamageType] = 1.0;
$DamageScale[engineer, $ShotgunDamageType] = 1.0;
$DamageScale[engineer, $NukeDamageType] = 10.0;
$DamageScale[engineer, $ZapDamageType] = 2.0;
$DamageScale[engineer, $RepairDamageType] = 1.0;
$DamageScale[engineer, $HeatDamageType] = 1.0;
$DamageScale[engineer, $PhotonDamageType] = 1.0;
$DamageScale[engineer, $PistolDamageType] = 1.0;
$DamageScale[engineer, $ATCDamageType] = 1.0;
$DamageScale[engineer, $StarDamageType] = 1.0;
$DamageScale[engineer, $ZapMortarDamageType] = 1.0;
$DamageScale[engineer, $ShockwaveDamageType] = 1.0;
$DamageScale[engineer, $QuantumDamageType] = 1.0;
$DamageScale[engineer, $BusterDamageType] = 1.0;
$DamageScale[engineer, $FluxDamageType] = 1.0;
$DamageScale[engineer, $FlierBombDamageType] = 1.0;
$DamageScale[engineer, $BustedDamageType] = 1.0;
$DamageScale[engineer, $PBWDamageType] = 1.0;
$DamageScale[engineer, $FlameDamageType] = 1.0;
$DamageScale[engineer, $IceDamageType] = 1.0;
$DamageScale[engineer, $RPGDamageType] = 1.0;
$DamageScale[engineer, $RPMDamageType] = 1.0;
$DamageScale[engineer, $EMPDamageType] = 0.5;
$DamageScale[engineer, $MethaneDamageType] = 1.0;
$DamageScale[engineer, $BurstDamageType] = 1.0;
$DamageScale[engineer, $ReaverDamageType] = 1.0;
$DamageScale[engineer, $RifleDamageType] = 1.0;
$DamageScale[engineer, $MassShotgunDamageType] = 1.0;
$DamageScale[engineer, $AutogunDamageType] = 1.0;
$DamageScale[engineer, $PistolDamageType] = 1.0;
$DamageScale[engineer, $AutogunDamageType] = 1.0;
$DamageScale[engineer, $GaussDamageType] = 1.0;
$DamageScale[engineer, $MBDamageType] = 1.0;
$DamageScale[engineer, $CutterDamageType] = 1.0;
$DamageScale[engineer, $NullDamageType] = 1.0;

$ItemMax[engineer, Blaster] = 1;
$ItemMax[engineer, Chaingun] = 1;
$ItemMax[engineer, DiscLauncher] = 1;
$ItemMax[engineer, SDiscLauncher] = 1;
$ItemMax[engineer, GrenadeLauncher] = 1;
$ItemMax[engineer, RPMLauncher] = 1;
$ItemMax[engineer, RPEMPLauncher] = 1;
$ItemMax[engineer, Mortar] = 1;
$ItemMax[engineer, ElectroMortar] = 1;
$ItemMax[engineer, ElectroAmmo] = 10;
$ItemMax[engineer, MineLauncher] = 1;
$ItemMax[engineer, HyperB] = 1;
$ItemMax[engineer, IonGun] = 1;
$ItemMax[engineer, PTCannon] = 1;
$ItemMax[engineer, PlasmaGun] = 1;
$ItemMax[engineer, LaserRifle] = 1;
$ItemMax[engineer, EnergyRifle] = 1;
$ItemMax[engineer, RocketLauncher] = 1;
$ItemMax[engineer, EMPGrenadeLauncher] = 1;
$ItemMax[engineer, TargetingLaser] = 1;
$ItemMax[engineer, MineAmmo] = 3;
$ItemMax[engineer, Grenade] = 6;
$ItemMax[engineer, Beacon] = 3;
$ItemMax[engineer, RepairKit] = 3;
$ItemMax[engineer, Rifle] = 1;
$ItemMax[engineer, MassDriver] = 1;
$ItemMax[engineer, Shotgun] = 1;
$ItemMax[engineer, RFL] = 1;
$ItemMax[engineer, PBW] = 1;
$ItemMax[engineer, FusionGun] = 1;
$ItemMax[engineer, EngineerGun] = 1;

$ItemMax[engineer, BulletAmmo] = 150;
$ItemMax[engineer, PlasmaAmmo] = 40;
$ItemMax[engineer, DiscAmmo] = 15;
$ItemMax[engineer, SDiscAmmo] = 15;
$ItemMax[engineer, GrenadeAmmo] = 25;
$ItemMax[engineer, MortarAmmo] = 15;
$ItemMax[engineer, MultiMineAmmo] = 15;
$ItemMax[engineer, RPMAmmo] = 15;
$ItemMax[engineer, RPEMPAmmo] = 15;
$ItemMax[engineer, EMPGrenadeAmmo] = 30;
$ItemMax[engineer, Bolts] = 25;
$ItemMax[engineer, Shells] = 100;
$ItemMax[engineer, Balls] = 15;

$ItemMax[engineer, EnergyPack] = 1;
$ItemMax[engineer, RepairPack] = 1;
$ItemMax[engineer, ShieldPack] = 1;
$ItemMax[engineer, SensorJammerPack] = 1;
$ItemMax[engineer, MotionSensorPack] = 1;
$ItemMax[engineer, PulseSensorPack] = 1;
$ItemMax[engineer, DeployableSensorJammerPack] = 1;
$ItemMax[engineer, CameraPack] = 1;
$ItemMax[engineer, TurretPack] = 1;
$ItemMax[engineer, AmmoPack] = 1;
$ItemMax[engineer, DeployableInvPack] = 1;
$ItemMax[engineer, DeployableAmmoPack] = 1;
$ItemMax[engineer, FakeFlag] = 1;
$ItemMax[engineer, SentryPack] = 1;
$ItemMax[engineer, RocketPack] = 1;
$ItemMax[engineer, TeleportPack] = 1;
$ItemMax[engineer, RocketPack] = 1;
$ItemMax[engineer, DeployableElf] = 1;
$ItemMax[engineer, LaserPack] = 1;
$ItemMax[engineer, SniperPack] = 1;
$ItemMax[engineer, GunboyPack] = 1;
$ItemMax[engineer, AirbasePack] = 1;
$ItemMax[engineer, GroundbasePack] = 1;
$ItemMax[engineer, HoloPack] = 1;
$ItemMax[engineer, HolowallPack] = 1;
$ItemMax[engineer, HologenPack] = 1;
$ItemMax[engineer, TreePack] = 1;
$ItemMax[engineer, TNTPack] = 1;
$ItemMax[engineer, DetPack] = 1;
$ItemMax[engineer, accelPPack] = 1;
$ItemMax[engineer, JailPack] = 1;
$ItemMax[engineer, JailcapPack] = 1;
$ItemMax[engineer, ObeliskPack] = 1;
$ItemMax[engineer, ObeliskPowerPack] = 1;
$ItemMax[engineer, HPCpack] = 1;
$ItemMax[engineer, groundbase] = 1;

$MaxWeapons[engineer] = 4;

//------------------------------------------------------------------
// Engineer Armor data:
//------------------------------------------------------------------

PlayerData engineer
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.0;
   maxForwardSpeed = 10.0;
   maxBackwardSpeed = 9.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
	maxEnergy = 128;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//----------------------------------------------------------------------------
// Engineer Female Armor
//----------------------------------------------------------------------------
$DamageScale[engineers, $LandingDamageType] = 1.0;
$DamageScale[engineers, $ImpactDamageType] = 1.0;
$DamageScale[engineers, $CrushDamageType] = 1.0;
$DamageScale[engineers, $BulletDamageType] = 1.0;
$DamageScale[engineers, $PlasmaDamageType] = 0.6;
$DamageScale[engineers, $EnergyDamageType] = 1.0;
$DamageScale[engineers, $ExplosionDamageType] = 1.0;
$DamageScale[engineers, $MissileDamageType] = 1.0;
$DamageScale[engineers, $ShrapnelDamageType] = 1.0;
$DamageScale[engineers, $DebrisDamageType] = 1.0;
$DamageScale[engineers, $LaserDamageType] = 1.0;
$DamageScale[engineers, $MortarDamageType] = 1.0;
$DamageScale[engineers, $BlasterDamageType] = 1.0;
$DamageScale[engineers, $ElectricityDamageType] = 1.0;
$DamageScale[engineers, $MineDamageType] = 1.0;
$DamageScale[engineers, $MagneticDamageType] = 0.5;
$DamageScale[engineers, $RocketDamageType] = 1.0;
$DamageScale[engineers, $FusionDamageType] = 1.5;
$DamageScale[engineers, $DisruptorDamageType] = 1.0;
$DamageScale[engineers, $SonicDamageType] = 5.0;
$DamageScale[engineers, $IonDamageType] = 2.2;
$DamageScale[engineers, $DistortionDamageType] = 7.2;
$DamageScale[engineers, $EMPDamageType] = 1.0;
$DamageScale[engineers, $PulseDamageType] = 1.0;
$DamageScale[engineers, $SniperDamageType] = 1.0;
$DamageScale[engineers, $VulcanDamageType] = 1.0;
$DamageScale[engineers, $ShotgunDamageType] = 1.0;
$DamageScale[engineers, $NukeDamageType] = 10.0;
$DamageScale[engineers, $ZapDamageType] = 2.0;
$DamageScale[engineers, $RepairDamageType] = 1.0;
$DamageScale[engineers, $HeatDamageType] = 1.0;
$DamageScale[engineers, $PhotonDamageType] = 1.0;
$DamageScale[engineers, $PistolDamageType] = 1.0;
$DamageScale[engineers, $ATCDamageType] = 1.0;
$DamageScale[engineers, $StarDamageType] = 1.0;
$DamageScale[engineers, $ZapMortarDamageType] = 1.0;
$DamageScale[engineers, $ShockwaveDamageType] = 1.0;
$DamageScale[engineers, $QuantumDamageType] = 1.0;
$DamageScale[engineers, $BusterDamageType] = 1.0;
$DamageScale[engineers, $FluxDamageType] = 1.0;
$DamageScale[engineers, $FlierBombDamageType] = 1.0;
$DamageScale[engineers, $BustedDamageType] = 1.0;
$DamageScale[engineers, $PBWDamageType] = 1.0;
$DamageScale[engineers, $FlameDamageType] = 1.0;
$DamageScale[engineers, $IceDamageType] = 1.0;
$DamageScale[engineers, $RPGDamageType] = 1.0;
$DamageScale[engineers, $RPMDamageType] = 1.0;
$DamageScale[engineers, $EMPDamageType] = 0.5;
$DamageScale[engineers, $MethaneDamageType] = 1.0;
$DamageScale[engineers, $BurstDamageType] = 1.0;
$DamageScale[engineers, $ReaverDamageType] = 1.0;
$DamageScale[engineers, $RifleDamageType] = 1.0;
$DamageScale[engineers, $MassShotgunDamageType] = 1.0;
$DamageScale[engineers, $AutogunDamageType] = 1.0;
$DamageScale[engineers, $PistolDamageType] = 1.0;
$DamageScale[engineers, $AutogunDamageType] = 1.0;
$DamageScale[engineers, $GaussDamageType] = 1.0;
$DamageScale[engineers, $MBDamageType] = 1.0;
$DamageScale[engineers, $CutterDamageType] = 1.0;
$DamageScale[engineers, $NullDamageType] = 1.0;

$ItemMax[engineers, Blaster] = 1;
$ItemMax[engineers, Chaingun] = 1;
$ItemMax[engineers, DiscLauncher] = 1;
$ItemMax[engineers, SDiscLauncher] = 1;
$ItemMax[engineers, GrenadeLauncher] = 1;
$ItemMax[engineers, RPMLauncher] = 1;
$ItemMax[engineers, RPEMPLauncher] = 1;
$ItemMax[engineers, Mortar] = 1;
$ItemMax[engineers, ElectroMortar] = 1;
$ItemMax[engineers, ElectroAmmo] = 10;
$ItemMax[engineers, MineLauncher] = 1;
$ItemMax[engineers, HyperB] = 1;
$ItemMax[engineers, IonGun] = 1;
$ItemMax[engineers, PTCannon] = 1;
$ItemMax[engineers, PlasmaGun] = 1;
$ItemMax[engineers, LaserRifle] = 1;
$ItemMax[engineers, EnergyRifle] = 1;
$ItemMax[engineers, RocketLauncher] = 1;
$ItemMax[engineers, EMPGrenadeLauncher] = 1;
$ItemMax[engineers, TargetingLaser] = 1;
$ItemMax[engineers, MineAmmo] = 3;
$ItemMax[engineers, Grenade] = 6;
$ItemMax[engineers, Beacon] = 3;
$ItemMax[engineers, RepairKit] = 3;
$ItemMax[engineers, Rifle] = 1;
$ItemMax[engineers, MassDriver] = 1;
$ItemMax[engineers, Shotgun] = 1;
$ItemMax[engineers, RFL] = 1;
$ItemMax[engineers, PBW] = 1;
$ItemMax[engineers, FusionGun] = 1;
$ItemMax[engineers, engineergun] = 1;

$ItemMax[engineers, BulletAmmo] = 150;
$ItemMax[engineers, PlasmaAmmo] = 40;
$ItemMax[engineers, DiscAmmo] = 15;
$ItemMax[engineers, SDiscAmmo] = 15;
$ItemMax[engineers, GrenadeAmmo] = 25;
$ItemMax[engineers, MortarAmmo] = 15;
$ItemMax[engineers, MultiMineAmmo] = 15;
$ItemMax[engineers, RPMAmmo] = 15;
$ItemMax[engineers, RPEMPAmmo] = 15;
$ItemMax[engineers, EMPGrenadeAmmo] = 30;
$ItemMax[engineers, Bolts] = 25;
$ItemMax[engineers, Shells] = 100;
$ItemMax[engineers, Balls] = 15;

$ItemMax[engineers, EnergyPack] = 1;
$ItemMax[engineers, RepairPack] = 1;
$ItemMax[engineers, ShieldPack] = 1;
$ItemMax[engineers, SensorJammerPack] = 1;
$ItemMax[engineers, MotionSensorPack] = 1;
$ItemMax[engineers, PulseSensorPack] = 1;
$ItemMax[engineers, DeployableSensorJammerPack] = 1;
$ItemMax[engineers, CameraPack] = 1;
$ItemMax[engineers, TurretPack] = 1;
$ItemMax[engineers, AmmoPack] = 1;
$ItemMax[engineers, DeployableInvPack] = 1;
$ItemMax[engineers, DeployableAmmoPack] = 1;
$ItemMax[engineers, FakeFlag] = 1;
$ItemMax[engineers, SentryPack] = 1;
$ItemMax[engineers, RocketPack] = 1;
$ItemMax[engineers, TeleportPack] = 1;
$ItemMax[engineers, RocketPack] = 1;
$ItemMax[engineers, DeployableElf] = 1;
$ItemMax[engineers, LaserPack] = 1;
$ItemMax[engineers, SniperPack] = 1;
$ItemMax[engineers, GunboyPack] = 1;
$ItemMax[engineers, AirbasePack] = 1;
$ItemMax[engineers, GroundbasePack] = 1;
$ItemMax[engineers, HoloPack] = 1;
$ItemMax[engineers, HolowallPack] = 1;
$ItemMax[engineers, HologenPack] = 1;
$ItemMax[engineers, TreePack] = 1;
$ItemMax[engineers, TNTPack] = 1;
$ItemMax[engineers, DetPack] = 1;
$ItemMax[engineers, accelPPack] = 1;
$ItemMax[engineers, JailPack] = 1;
$ItemMax[engineers, JailcapPack] = 1;
$ItemMax[engineers, ObeliskPack] = 1;
$ItemMax[engineers, ObeliskPowerPack] = 1;
$ItemMax[HPCpack, airbase] = 1;
$ItemMax[engineers, groundbase] = 1;

$MaxWeapons[engineers] = 4;

//------------------------------------------------------------------
// Engineer female data:
//------------------------------------------------------------------

PlayerData engineers
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

   canCrouch = false;
	maxDamage = 1.0;
   maxForwardSpeed = 10.0;
   maxBackwardSpeed = 9.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	maxEnergy = 128;
   mass = 13.0;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

$ArmorType[Male, EngineerArmor] = engineer;
$ArmorType[Female, EngineerArmor] = engineers;
$ArmorName[engineer] = EngineerArmor;
$ArmorName[engineers] = EngineerArmor;

//----------------------------------------------------------------------------
// Gundam Armor
//----------------------------------------------------------------------------

$DamageScale[gharmor, $LandingDamageType] = 1.0;
$DamageScale[gharmor, $ImpactDamageType] = 1.0;
$DamageScale[gharmor, $CrushDamageType] = 1.0;
$DamageScale[gharmor, $BulletDamageType] = 0.6;
$DamageScale[gharmor, $PlasmaDamageType] = 0.4;
$DamageScale[gharmor, $EnergyDamageType] = -0.1;
$DamageScale[gharmor, $ExplosionDamageType] = 0.6;
$DamageScale[gharmor, $MissileDamageType] = 0.6;
$DamageScale[gharmor, $DebrisDamageType] = 0.8;
$DamageScale[gharmor, $ShrapnelDamageType] = 0.8;
$DamageScale[gharmor, $LaserDamageType] = 0.1;
$DamageScale[gharmor, $MortarDamageType] = 0.7;
$DamageScale[gharmor, $BlasterDamageType] = -0.05;
$DamageScale[gharmor, $ElectricityDamageType] = -0.1;
$DamageScale[gharmor, $MineDamageType] = 0.8;
$DamageScale[gharmor, $MagneticDamageType] = 0.5;
$DamageScale[gharmor, $RocketDamageType] = 1.0;
$DamageScale[gharmor, $FusionDamageType] = -0.05;
$DamageScale[gharmor, $DisruptorDamageType] = 1.0;
$DamageScale[gharmor, $SonicDamageType] = 5.0;
$DamageScale[gharmor, $IonDamageType] = -0.2;
$DamageScale[gharmor, $DistortionDamageType] = 7.2;
$DamageScale[gharmor, $EMPDamageType] = 0.5;
$DamageScale[gharmor, $PulseDamageType] = -0.1;
$DamageScale[gharmor, $SniperDamageType] = 1.0;
$DamageScale[gharmor, $VulcanDamageType] = 1.0;
$DamageScale[gharmor, $ShotgunDamageType] = 1.0;
$DamageScale[gharmor, $NukeDamageType] = 10.0;
$DamageScale[gharmor, $ZapDamageType] = -0.2;
$DamageScale[gharmor, $RepairDamageType] = 1.0;
$DamageScale[gharmor, $HeatDamageType] = 1.0;
$DamageScale[gharmor, $PhotonDamageType] = 1.0;
$DamageScale[gharmor, $PistolDamageType] = 1.0;
$DamageScale[gharmor, $ATCDamageType] = 1.0;
$DamageScale[gharmor, $StarDamageType] = 1.0;
$DamageScale[gharmor, $ZapMortarDamageType] = 1.0;
$DamageScale[gharmor, $ShockwaveDamageType] = 1.0;
$DamageScale[gharmor, $QuantumDamageType] = 1.0;
$DamageScale[gharmor, $BusterDamageType] = -0.1;
$DamageScale[gharmor, $FluxDamageType] = 1.0;
$DamageScale[gharmor, $FlierBombDamageType] = 1.0;
$DamageScale[gharmor, $BustedDamageType] = 1.0;
$DamageScale[gharmor, $PBWDamageType] = 1.0;
$DamageScale[gharmor, $FlameDamageType] = 1.0;
$DamageScale[gharmor, $IceDamageType] = 1.0;
$DamageScale[gharmor, $RPGDamageType] = 1.0;
$DamageScale[gharmor, $RPMDamageType] = 1.0;
$DamageScale[gharmor, $EMPDamageType] = 0.5;
$DamageScale[gharmor, $MethaneDamageType] = 1.0;
$DamageScale[gharmor, $BurstDamageType] = 1.0;
$DamageScale[gharmor, $ReaverDamageType] = 1.0;
$DamageScale[gharmor, $RifleDamageType] = 1.0;
$DamageScale[gharmor, $MassShotgunDamageType] = 1.0;
$DamageScale[gharmor, $AutogunDamageType] = 1.0;
$DamageScale[gharmor, $PistolDamageType] = 1.0;
$DamageScale[gharmor, $AutogunDamageType] = 1.0;
$DamageScale[gharmor, $GaussDamageType] = 1.0;
$DamageScale[gharmor, $MBDamageType] = -0.2;
$DamageScale[gharmor, $CutterDamageType] = 1.0;
$DamageScale[gharmor, $NullDamageType] = 1.0;

$ItemMax[gharmor, HyperB] = 1;
$ItemMax[gharmor, VulcanCannon] = 1;
$ItemMax[gharmor, SDisclauncher] = 1;
$ItemMax[gharmor, ATC] = 1;
$ItemMax[gharmor, TacheonLauncher] = 1;
$ItemMax[gharmor, MBCannon] = 1;
$ItemMax[gharmor, ReaverLauncher] = 1;
$ItemMax[gharmor, PlasmaGun] = 1;
$ItemMax[gharmor, LaserRifle] = 1;
$ItemMax[gharmor, ShockCannon] = 1;
$ItemMax[gharmor, RocketLauncher] = 1;
$ItemMax[gharmor, RepairKit] = 1;
$ItemMax[gharmor, Beacon] = 10;
$ItemMax[gharmor, LCannon] = 1;
$ItemMax[gharmor, BCannon] = 1;
$ItemMax[gharmor, Rifle] = 1;
$ItemMax[gharmor, ElectroCannon] = 1;
$ItemMax[gharmor, LaserGatling] = 1;
$ItemMax[gharmor, PBW] = 1;
$ItemMax[gharmor, FusionGun] = 1;
$ItemMax[gharmor, ConcunPistol] = 1;
$ItemMax[gharmor, LaserCannon] = 1;

$ItemMax[gharmor, BulletAmmo] = 250;
$ItemMax[gharmor, VulcanAmmo] = 500;
$ItemMax[gharmor, ATCAmmo] = 250;
$ItemMax[gharmor, PlasmaAmmo] = 100;
$ItemMax[gharmor, SDiscAmmo] = 150;
$ItemMax[gharmor, ReaverAmmo] = 200;
$ItemMax[gharmor, Shells] = 250;
$ItemMax[gharmor, Bolts] = 150;
$ItemMax[gharmor, Balls] = 200;

$ItemMax[gharmor, EnergyPack] = 1;
$ItemMax[gharmor, RepairPack] = 1;
$ItemMax[gharmor, ShieldPack] = 1;
$ItemMax[gharmor, ReaverPack] = 1;
$ItemMax[gharmor, SensorJammerPack] = 1;
$ItemMax[gharmor, AmmoPack] = 1;
$ItemMax[gharmor, FakeFlag] = 1;
$ItemMax[gharmor, HyperPack] = 1;
$ItemMax[gharmor, Slipstream] = 1;
$ItemMax[gharmor, JetfirePack] = 1;
$ItemMax[gharmor, SMCPack] = 1;
$ItemMax[gharmor, SPTPack] = 1;
$ItemMax[gharmor, SPCPack] = 1;
$ItemMax[gharmor, FlamerCannonPack] = 1;
$ItemMax[gharmor, BlasterPack] = 1;
$ItemMax[gharmor, WildFirePack] = 1;

$MaxWeapons[gharmor] = 8;

//------------------------------------------------------------------
// Gundam Armor data:
//------------------------------------------------------------------

PlayerData gharmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 32;
   minJetEnergy = 1;
   jetForce = 385;
   jetEnergyDrain = 0.1;

	maxDamage = 2;
   maxForwardSpeed = 7.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 6.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 255;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};


$ArmorType[Male, GundamArmor] = gharmor;
$ArmorType[Female, GundamArmor] = gharmor;
$ArmorName[gharmor] = GundamArmor;


