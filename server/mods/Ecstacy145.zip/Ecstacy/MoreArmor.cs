// ====================== ======================== ===================== morearmor.cs MegaMan 1024
// ====================== Successor to armordata.cs -- No confusion

