# Damage Types
#
$ImpactDamageType		  = -1;
$LandingDamageType	  =  0;
$BulletDamageType      =  1;
$EnergyDamageType      =  2;
$PlasmaDamageType      =  3;
$ExplosionDamageType   =  4;
$ShrapnelDamageType    =  5;
$LaserDamageType       =  6;
$MortarDamageType      =  7;
$BlasterDamageType     =  8;
$ElectricityDamageType =  9;
$CrushDamageType       = 10;
$DebrisDamageType      = 11;
$MissileDamageType     = 12;
$MineDamageType        = 13;
$FusionDamageType        = 14;
$DisruptorDamageType        = 15;
$SonicDamageType        = 16;
$IonDamageType        = 17;
$DistortionDamageType        = 18;
$EMPDamageType        = 19;
$PulseDamageType        = 20;
$SniperDamageType        = 21;
$VulcanDamageType        = 22;
$ShotgunDamageType        = 23;
$NukeDamageType        = 24;
$ZapDamageType        = 25;
$RepairDamageType        = 26;
$HeatDamageType        = 27;
$PhotonDamageType        = 28;
$PistolDamageType        = 29;
$ATCDamageType        = 30;
$StarDamageType        = 31;
$ZapMortarDamageType        = 32;
$ShockwaveDamageType        = 33;
$QuantumDamageType        = 34;
$BusterDamageType        = 35;
$FluxDamageType        = 36;
$FlierBombDamageType        = 37;
$BustedDamageType        = 38;
$PBWDamageType        = 39;
$MagneticDamageType    = 40;
$EMPDamageType         = 41;
$RocketDamageType	     = 42;
$FlameDamageType	     = 43;
$IceDamageType	     = 44;
$MethaneDamageType	     = 45;
$BurstDamageType	     = 46;
$RPGDamageType	     = 47;
$RPMDamageType	     = 48;
$ReaverDamageType	     = 49;
$RifleDamageType	     = 50;
$ShotgunDamageType	     = 51;
$AutogunDamageType	     = 52;
$PistolDamageType	     = 53;
$VulcanDamageType	     = 54;
$GaussDamageType	     = 55;
$MBDamageType	     = 56;
$CutterDamageType	     = 57;
$MassDamageType	     = 58;
$MassShotgunDamageType	     = 58;
$NullDamageType	     = 127;

// Added Additional Damage Types Here - *IX*Savage1, MegaMan 1024

//--------------------------------------
BulletData ChaingunBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.11;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.005;
   muzzleVelocity     = 425.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

BulletData HCBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.10;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.005;
   muzzleVelocity     = 625.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData GaussBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp3;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.55;
   damageType         = $MortarDamageType;

   explosionRadius    = 7.5;
   aimDeflection      = 0.005;
   muzzleVelocity     = 725.0;
   totalTime          = 10.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData MassBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp3;
   expRandCycle       = 7;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.9;
   damageType         = $MortarDamageType;

   explosionRadius    = 7.5;
   muzzleVelocity     = 725.0;
   totalTime          = 10.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData VulcanBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.15;
   damageType         = $VulcanDamageType;

   aimDeflection      = 0.00375;
   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData ShotgunBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.45;
   damageType         = $ShotgunDamageType;

   aimDeflection      = 0.025;
   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData ShotgunBullet2
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.25;
   damageType         = $AutoDamageType;

   aimDeflection      = 0.025;
   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData ShotgunBullet3
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp3;
   expRandCycle       = 7;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.5;
   damageType         = $MassShotgunDamageType;

   explosionRadius    = 7.5;
   aimDeflection      = 0.025;
   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData RifleBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.75;
   damageType         = $SniperDamageType;

   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData PistolBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.375;
   damageType         = $PistolDamageType;

   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData MethaneBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.25;
   damageType         = $MethaneDamageType;

   muzzleVelocity     = 900.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData FusionBolt
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.25;
   damageType         = $EnergyDamageType;

   explosionRadius    = 5;
   muzzleVelocity     = 50.0;
   totalTime          = 6.0;
   liveTime           = 4.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

BulletData FusionBolt2
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.35;
   damageType         = $EnergyDamageType;

   explosionRadius    = 5;
   muzzleVelocity     = 150.0;
   totalTime          = 16.0;
   liveTime           = 14.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

//--------------------------------------
BulletData Concussion
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.5;
   damageType         = $ConcussionDamageType;

   explosionRadius    = 25;
   muzzleVelocity     = 100.0;
   totalTime          = 12.0;
   liveTime           = 8.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

//--------------------------------------
BulletData MiniFusionBolt
{
   bulletShapeName    = "enbolt.dts";
   explosionTag       = energyExp;

   damageClass        = 1;
   damageValue        = 0.1;
   damageType         = $EnergyDamageType;

   muzzleVelocity     = 80.0;
   totalTime          = 4.0;
   liveTime           = 2.0;

   explosionRadius    = 2.5;
   lightRange         = 3.0;
   lightColor         = { 0.25, 0.25, 1.0 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

BulletData PulseBolt
{
   bulletShapeName    = "enex.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.3;
   damageType         = $PulseDamageType;

   explosionRadius    = 2.5;
   muzzleVelocity     = 375.0;
   totalTime          = 10.0;
   liveTime           = 9.9;
   isVisible          = True;

   rotationPeriod = 15;
};

//--------------------------------------
BulletData BlasterBolt
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = blasterExp;

   damageClass        = 1;
   damageValue        = 0.125;
   damageType         = $BlasterDamageType;
   explosionRadius    = 1.5;

   muzzleVelocity     = 200.0;
   totalTime          = 2.0;
   liveTime           = 1.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

BulletData ElectroBolt
{
   bulletShapeName    = "rsmoke.dts";
   explosionTag       = EMExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   explosionRadius    = 100;
   damageValue        = 2.5;
   damageType         = $ZapDamageType;

   muzzleVelocity     = 1024.0;
   totalTime          = 7.5;
   inheritedVelocityScale = 1.0;
   isVisible          = True;

};

BulletData VaussPod
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = Boltexp1;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.768;
   damageType         = $MortarDamageType;

   explosionRadius    = 15.0;
   aimDeflection      = 0.007;
   muzzleVelocity     = 1400.0;
   totalTime          = 10;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};


//--------------------------------------
RocketData SuperBlasterBolt
{
   collisionRadius  = 0.0;
   mass             = 2.0;

   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = blasterExp;

   damageClass        = 1;
   damageValue        = 0.7;
   damageType         = $BlasterDamageType;

   explosionRadius    = 5.0;
   muzzleVelocity     = 250.0;

   kickBackStrength = 250.0;
   terminalVelocity = 2500.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "shotgunex.dts";
   smokeDist   = 1.6;

   soundId = SoundJetHeavy;
};

BulletData Flare
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = FlareSmoke;

   damageClass        = 1;
   damageValue        = 7.25;
   damageType         = $HeatDamageType;
   explosionRadius    = 25.0;

   muzzleVelocity     = 10.0;
   totalTime          = 5;
   liveTime           = 4.9;

   lightRange         = 3.0;
   lightColor         = { 0.25, 0.25, 1.0 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

};

//--------------------------------------
BulletData Flame
{
   bulletShapeName    = "tumult_small.dts";
   explosionTag       = flameExp;

   damageClass        = 1;
   damageValue        = 0.1;
   damageType         = $FlameDamageType;
   explosionRadius    = 7;
   aimDeflection      = 0.01;

   muzzleVelocity     = 100.0;
   totalTime          = 5.0;
   liveTime           = 4.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

//   rotationPeriod = 1;
};

//--------------------------------------
BulletData StraightFlame
{
   bulletShapeName    = "tumult_small.dts";
   explosionTag       = flameExp;

   damageClass        = 1;
   damageValue        = 0.1;
   damageType         = $FlameDamageType;
   explosionRadius    = 7;
   aimDeflection      = 0.01;

   muzzleVelocity     = 100.0;
   totalTime          = 5.0;
   liveTime           = 4.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

//   rotationPeriod = 1;
};

//--------------------------------------
BulletData CannonFlame
{
   bulletShapeName    = "tumult_small.dts";
   explosionTag       = boltexp5;

   damageClass        = 1;
   damageValue        = 0.2;
   damageType         = $FlameDamageType;
   explosionRadius    = 15;

   muzzleVelocity     = 100.0;
   totalTime          = 5.0;
   liveTime           = 4.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

};

//--------------------------------------
BulletData Ice
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = fliceExp;

   damageClass        = 1;
   damageValue        = 0.2;
   damageType         = $IceDamageType;
   explosionRadius    = 5;
   aimDeflection      = 0.01;

   muzzleVelocity     = 75.0;
   totalTime          = 5.0;
   liveTime           = 4.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

};

//--------------------------------------
BulletData Tacheon
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = tachyonExp;

   damageClass        = 1;
   damageValue        = 2;
   damageType         = $EMPDamageType;
   explosionRadius    = 10;

   muzzleVelocity     = 400.0;
   totalTime          = 10;
   liveTime           = 5;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

BulletData RFB
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = blasterExp;

   damageClass        = 1;
   damageValue        = 0.1;
   damageType         = $BlasterDamageType;

   muzzleVelocity     = 1000.0;
   explosionRadius    = 1;
   totalTime          = 10.0;
   liveTime           = 6.255;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

BulletData GatlingBlasterBolt
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = blasterExp;

   damageClass        = 1;
   damageValue        = 0.35;
   damageType         = $BlasterDamageType;

   muzzleVelocity     = 700.0;
   explosionRadius    = 2.5;
   totalTime          = 10.0;
   liveTime           = 8.255;
   aimDeflection      = 0.0075;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

BulletData GatlingDisruptorBolt
{
   bulletShapeName    = "paint.dts";
   explosionTag       = disexp;

   damageClass        = 1;
   damageValue        = 0.35;
   damageType         = $DisruptorDamageType;

   muzzleVelocity     = 175.0;
   explosionRadius    = 3.5;
   totalTime          = 10.0;
   liveTime           = 8.255;
   aimDeflection      = 0.0075;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

BulletData PTCBolt
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $EnergyDamageType;

   explosionRadius    = 5;
   muzzleVelocity     = 300.0;
   totalTime          = 21.0;
   liveTime           = 8.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

BulletData PTBolt
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.9;
   damageType         = $EnergyDamageType;

   explosionRadius    = 5;
   muzzleVelocity     = 300.0;
   totalTime          = 21.0;
   liveTime           = 8.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};


RocketData IonShock
{
   bulletShapeName  = "fusionbolt.dts";
   explosionTag     = ionExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.99;
   damageType       = $ElectricityDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "fusionbolt.dts";
   smokeDist   = 3.14;

   soundId = SoundELFIdle;
};

RocketData Devistator
{
   bulletShapeName  = "paint.dts";
   explosionTag     = ionExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.99;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "paint.dts";
   smokeDist   = 3.14;

   soundId = SoundELFIdle;
};

RocketData MicrowaveBolt
{
   bulletShapeName  = "plasmatrail.dts";
   explosionTag     = boltexp4;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.59;
   damageType       = $HeatDamageType;

   explosionRadius  = 16;
   kickBackStrength = 12.0;
   muzzleVelocity   = 165.0;
   terminalVelocity = 1115.0;
   acceleration     = 15.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "plasmatrail.dts";
   smokeDist   = 3.14;

   soundId = SoundELFIdle;
};

RocketData IonShock2
{
   bulletShapeName  = "mortar.dts";
   explosionTag     = PlasmaExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.5;
   damageType       = $MineDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "fusionbolt.dts";
   smokeDist   = 3.1415926;

   soundId = SoundELFIdle;
};

RocketData IonShock3
{
   bulletShapeName  = "shield_large.dts";
   explosionTag     = ionExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1;
   damageType       = $MBDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "fusionbolt.dts";
   smokeDist   = 3.1415926;

   soundId = SoundELFIdle;
};

RocketData IonShock4
{
   bulletShapeName  = "shield_large.dts";
   explosionTag     = ionExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1;
   damageType       = $EMPDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "fusionbolt.dts";
   smokeDist   = 3.1415926;

   soundId = SoundELFIdle;
};

//--------------------------------------
BulletData PlasmaBolt
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.45;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 55.0;
   totalTime          = 3.0;
   liveTime           = 2.0;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

BulletData PlasmaBolt2
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.45;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 75.0;
   aimDeflection      = 0.0075;
   totalTime          = 3.0;
   liveTime           = 2.0;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

BulletData FlierPlasmaBolt
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.75;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 85.0;
   totalTime          = 5.0;
   liveTime           = 4.0;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

RocketData SPlasBeam
{
   bulletShapeName  = "plasmabolt.dts";
   explosionTag     = SPlasmaExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.35;
   damageType       = $PlasmaDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "plastrail.dts";
   smokeDist   = 3.14;

   soundId = SoundELFIdle;
};

//--------------------------------------
RocketData DiscShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 15;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

//--------------------------------------
RocketData CutterShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = bulletExp0;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.41;
   damageType       = $CutterDamageType;

   kickBackStrength = 1.0;

   muzzleVelocity   = 300.0;
   terminalVelocity = 500.0;
   acceleration     = 5.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 10.5;

   // rocket specific
   trailType   = 1;
   trailLength = 15;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

RocketData ChainDiscShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 375.0;
   terminalVelocity = 500.0;
   acceleration     = 50.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 100;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

RocketData FlierDiscShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.25;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 128.0;
   terminalVelocity = 256.0;
   acceleration     = 16.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 150;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

//--------------------------------------
GrenadeData GrenadeShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 150;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 1.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "smoke.dts";
};

//--------------------------------------
GrenadeData MortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

GrenadeData RepairMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = -1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = -250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//--------------------------------------
GrenadeData MortarTurretShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 400;
   collisionRadius    = 1.0;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.32;
   damageType         = $MortarDamageType;

   explosionRadius    = 30.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 400;
   totalTime          = 1000.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//=========================================================================

GrenadeData ImpactMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 0.1;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

GrenadeData ElectroMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = EMExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.15;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 2.5;
   damageType         = $ElectricityDamageType;

   explosionRadius    = 100.0;
   kickBackStrength   = 0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "paint.dts";
};

GrenadeData RubberMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.75;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 3.5;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

BulletData Starblast
{
   bulletShapeName    = "rocket.dts";
   explosionTag       = pbwExp;
   expRandCycle       = 4;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.8;
   damageType         = $StarDamageType;

   aimDeflection      = 0.010;
   explosionRadius    = 20.5;
   muzzleVelocity     = 100;
   totalTime          = 40;
   inheritedVelocityScale = 1.0;
   isVisible          = True;

   tracerPercentage   = 2.0;
   tracerLength       = 30;
   soundId = SoundJetLight;
   
};

//====================================

BulletData MiniMissile
{
   bulletShapeName    = "rocket.dts";
   explosionTag       = Exp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.512;
   damageType         = $ATCDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 50.0;

   aimDeflection      = 0.003;
   muzzleVelocity     = 1000.0;
   totalTime          = 17.5;
   inheritedVelocityScale = 1.0;
   isVisible          = True;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

RocketData RPG
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = grenadeExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $GrenadeDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 150.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "smoke.dts";
   smokeDist   = 15;

   soundId = SoundJetHeavy;
};

RocketData flierLaser
{
   bulletShapeName  = "fusionbolt.dts";
   explosionTag     = shockwave;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.85;
   damageType       = $ElectricityDamageType;

   explosionRadius  = 12.5;
   kickBackStrength = 150.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "hflame.dts";
   smokeDist   = 3.141592654;

   soundId = SoundJetHeavy;
};

RocketData TachyBolt
{
   bulletShapeName  = "fusionbolt.dts";
   explosionTag     = boltexp6;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.85;
   damageType       = $ElectricityDamageType;

   explosionRadius  = 12.5;
   kickBackStrength = 150.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "hflame.dts";
   smokeDist   = 3.141592654;

   soundId = SoundJetHeavy;
};

RocketData RPEMP
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = EMPPulseExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.51;
   damageType       = $EMPDamageType;

   explosionRadius  = 40;
   kickBackStrength = -50.0;
   muzzleVelocity   = 100.0;
   terminalVelocity = 200.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "smoke.dts";
   smokeDist   = 15;

   soundId = SoundJetHeavy;
};

RocketData RPM
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = mortarExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.5;
   damageType       = $MortarDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 250.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "smoke.dts";
   smokeDist   = 15;



   soundId = SoundJetHeavy;
};

RocketData StingerMissile
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 10;
   kickBackStrength = 300.0;

   muzzleVelocity   = 900.0;
   terminalVelocity = 2000.0;
   acceleration     = 200.0;

   totalTime        = 18.5;
   liveTime         = 20.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };


   inheritedVelocityScale = 0.5;

    // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "smoke.dts";
   smokeDist   = 15;

   soundId = SoundJetHeavy;
};

RocketData reaver
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 15;
   kickBackStrength = 300.0;

   muzzleVelocity   = 100.0;
   terminalVelocity = 900.0;
   acceleration     = 50.0;

   totalTime        = 18.5;
   liveTime         = 20.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };


   inheritedVelocityScale = 1.5; // how fast (really) it speeds up

    // rocket specific
   trailType   = 2; // smoke trail
   trailString = "shotgunex.dts"; // shape name
   smokeDist   = 3.141592654; // controls distance apart from each smoke puff

   soundId = SoundJetHeavy; // sound it makes 
};

RocketData Electron
{
   bulletShapeName = "rocket.dts";
   explosionTag    = plasmaExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $PlasmaDamageType;

   explosionRadius  = 15;
   kickBackStrength = 300.0;

   muzzleVelocity   = 100.0;
   terminalVelocity = 900.0;
   acceleration     = 50.0;

   totalTime        = 18.5;
   liveTime         = 20.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };


   inheritedVelocityScale = 1.5; 

   trailType   = 2; 
   trailString = "fusionbolt.dts"; 
   smokeDist   = 3.141592654; 

   soundId = SoundJetHeavy; 
};

RocketData Minion
{
   bulletShapeName = "rocket.dts";
   explosionTag    = mortarExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $MortarDamageType;

   explosionRadius  = 75;
   kickBackStrength = 300.0;

   muzzleVelocity   = 100.0;
   terminalVelocity = 900.0;
   acceleration     = 50.0;

   totalTime        = 18.5;
   liveTime         = 20.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };


   inheritedVelocityScale = 1.5; 

   trailType   = 2; 
   trailString = "paint.dts"; 
   smokeDist   = 3.141592654; 

   soundId = SoundJetHeavy; 
};

RocketData Mitzi
{
   bulletShapeName = "plasma.dts";
   explosionTag    = EnergyExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $MBDamageType;

   explosionRadius  = 30;
   kickBackStrength = 300.0;

   muzzleVelocity   = 100.0;
   terminalVelocity = 900.0;
   acceleration     = 50.0;

   totalTime        = 18.5;
   liveTime         = 20.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };


   inheritedVelocityScale = 1.5; 

   trailType   = 2; 
   trailString = "plasma.dts"; 
   smokeDist   = 5.12; 

   soundId = SoundJetHeavy; 
};

//--------------------------------------
RocketData FlierRocket
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 250.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;

   soundId = SoundJetHeavy;
};

SeekingMissileData MinionMissileSeeking
{
bulletShapeName = "rocket.dts";
explosionTag = MinionGoBoom;
collisionRadius = 0.0;
mass = 2.0;
damageClass = 1;
damageValue = 10;
damageType = $MissileDamageType;
explosionRadius = 50;
kickBackStrength = 200.0;
muzzleVelocity = 50.0;
terminalVelocity = 2000.0;
acceleration = 200.0;
totalTime = 7.0;
liveTime = 8.0;
lightRange = 5.0;
lightColor = { 1.0, 0.7, 0.5 };
inheritedVelocityScale = 0.5;
seekingTurningRadius = 0.0;
nonSeekingTurningRadius = 5.0;
proximityDist = 1.5;
lightRange = 5.0;
lightColor = { 0.4, 0.4, 1.0 };
smokeDist         = 15;
inheritedVelocityScale = 0.5;
soundId = SoundJetHeavy;
};

//--------------------------------------
SeekingMissileData TurretMissile
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;
   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;
   explosionRadius  = 9.5;
   kickBackStrength = 175.0;

   muzzleVelocity    = 72.0;
   totalTime         = 10;
   liveTime          = 10;
   seekingTurningRadius    = 9;
   nonSeekingTurningRadius = 75.0;
   proximityDist     = 1.5;
   smokeDist         = 1.75;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   soundId = SoundJetHeavy;
};


SeekingMissileData RPMTracker 
{
bulletShapeName = "rocket.dts";
explosionTag = mortarExp;
collisionRadius = 0.0;
mass = 2.0;
damageClass = 1;
damageValue = 1.5;
damageType = $MissileDamageType;
explosionRadius = 7.5;
kickBackStrength = 200.0;
muzzleVelocity = 40.0;
terminalVelocity = 500.0;
acceleration = 10.0;
totalTime = 20.0;
liveTime = 21.0;
lightRange = 5.0;
lightColor = { 1.0, 0.7, 0.5 };
inheritedVelocityScale = 0.5;
seekingTurningRadius = 0.0;
nonSeekingTurningRadius = 5.0;
proximityDist = 1.5;
lightRange = 5.0;
lightColor = { 0.4, 0.4, 1.0 };
smokeDist         = 15;
inheritedVelocityScale = 0.5;
soundId = SoundJetHeavy;
};


SeekingMissileData RPGTracker 
{
bulletShapeName = "rocket.dts";
explosionTag = grenadeExp;
collisionRadius = 0.0;
mass = 2.0;
damageClass = 1;
damageValue = 0.75;
damageType = $MissileDamageType;
explosionRadius = 5;
kickBackStrength = 200.0;
muzzleVelocity = 40.0;
terminalVelocity = 500.0;
acceleration = 10.0;
totalTime = 20.0;
liveTime = 21.0;
lightRange = 5.0;
lightColor = { 1.0, 0.7, 0.5 };
inheritedVelocityScale = 0.5;
seekingTurningRadius = 0.0;
nonSeekingTurningRadius = 5.0;
proximityDist = 1.5;
lightRange = 5.0;
lightColor = { 0.4, 0.4, 1.0 };
smokeDist         = 15;
inheritedVelocityScale = 0.5;
soundId = SoundJetHeavy;
};

SeekingMissileData RPEMPTracker 
{
bulletShapeName = "rocket.dts";
explosionTag = EMPPulseExp;
collisionRadius = 0.0;
mass = 2.0;
damageClass = 1;
damageValue = 0.01;
damageType = $EMPDamageType;
explosionRadius = 40;
kickBackStrength = -500.0;
muzzleVelocity = 200.0;
terminalVelocity = 500.0;
acceleration = 10.0;
totalTime = 20.0;
liveTime = 21.0;
lightRange = 5.0;
lightColor = { 1.0, 0.7, 0.5 };
inheritedVelocityScale = 0.5;
seekingTurningRadius = 0.0;
nonSeekingTurningRadius = 5.0;
proximityDist = 1.5;
lightRange = 5.0;
lightColor = { 0.4, 0.4, 1.0 };
smokeDist         = 15;
inheritedVelocityScale = 0.5;
soundId = SoundJetHeavy;
};

SeekingMissileData DiscShellTracker 
{
bulletShapeName = "discb.dts";
explosionTag = rocketExp;
collisionRadius = 0.0;
mass = 2.0;
damageClass = 1;
damageValue = 0.6;
damageType = $ExplosionDamageType;
explosionRadius = 7.5;
kickBackStrength = 200.0;
muzzleVelocity = 40.0;
terminalVelocity = 500.0;
acceleration = 10.0;
totalTime = 20.0;
liveTime = 21.0;
lightRange = 5.0;
lightColor = { 1.0, 0.7, 0.5 };
inheritedVelocityScale = 0.5;
seekingTurningRadius = 0.0;
nonSeekingTurningRadius = 5.0;
smokeDist         = 15;
proximityDist = 1.5;
lightRange = 5.0;
lightColor = { 0.4, 0.4, 1.0 };
inheritedVelocityScale = 0.5;
soundId = SoundDiscSpin;
};

function SeekingMissile::updateTargetPercentage(%target)
{
   return GameBase::virtual(%target, "getHeatFactor");
}

//-------------------------------------- 
// These are kinda oddball dat's
// the lasers really don't fit into
// the typical projectile catagories...
//--------------------------------------
LaserData sniperLaser
{
   laserBitmapName   = "laserPulse.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.007;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData pistolLaser
{
   laserBitmapName   = "laserPulse.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.03;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData protoLaser
{
   laserBitmapName   = "repairadd.bmp";
   hitName           = "shotgunex.dts";

   damageConversion  = 0.006;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

TargetLaserData targetLaser
{
   laserBitmapName   = "paintPulse.bmp";

   damageConversion  = 0.0;
   baseDamageType    = 0;

   lightRange        = 2.0;
   lightColor        = { 0.25, 1.0, 0.25 };

   detachFromShooter = false;
};
LaserData LaserPhaser
{
   laserBitmapName   = "laserPulse.bmp";
//   hitName           = "laserhit.dts";

   damageConversion  = 0.04;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
//   hitSoundId        = SoundLaserHit;
};

LaserData superLaser
{
   laserBitmapName   = "lightningnew.bmp";
   hitName           = "shield_medium.dts";

   damageConversion  = 0.035;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundBuzz2;
};


LaserData EmpireLaser
{
   laserBitmapName   = "paintPulse.bmp";
   hitName           = "smoke.dts";

   damageConversion  = 0.007;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData OddBallLaser
{
   laserBitmapName   = "LightningNew.bmp";
   hitName           = "enexp.dts";

   damageConversion  = 0.007;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};


LaserData TurretLaser
{
   laserBitmapName   = "laserPulse.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.01;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData PBWLaser
{
   laserBitmapName   = "lightningNew.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.05;
   baseDamageType    = $PBWDamageType;

   beamTime          = 0.75;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = ShockExplosion;
};

LaserData RFLaser
{
   laserBitmapName   = "paintPulse.bmp";
   hitName           = "breath.dts";

   damageConversion  = 0.064;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData GatlingLaser
{
   laserBitmapName   = "paintpulse.bmp";
   hitName           = "paint.dts";

   damageConversion  = 0.128;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData PyroLaser
{
   laserBitmapName   = "paintPulse.bmp";
   hitName           = "smoke.dts";

   damageConversion  = 0.1;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.35;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LightningData lightningCharge
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageType;
   boltLength       = 100.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.666;
   energyDrainPerSec = 64.0;
   segmentDivisions = 10;
   numSegments      = 10;
   beamWidth        = 0.125;//075;

   updateTime   = 240;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

LightningData turretCharge
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageType;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.06;
   energyDrainPerSec = 60.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

function Lightning::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
   %damVal = %timeSlice * %damPerSec;
   %enVal  = %timeSlice * %enDrainPerSec;

// Added Hack to Make Magnetic Damage Engage - *IX*Savage1 
   if(%damPerSec > 0.06) 
   	GameBase::applyDamage(%target, $MagneticDamageType, %damVal, %pos, %vec, %mom, %shooterId);
   else
   	GameBase::applyDamage(%target, $ElectricityDamageType, %damVal, %pos, %vec, %mom, %shooterId);

   %energy = GameBase::getEnergy(%target);
   %energy = %energy - %enVal;
   if (%energy < 0) {
      %energy = 0;
   }
   GameBase::setEnergy(%target, %energy);
}

RepairEffectData RepairBolt
{
   bitmapName       = "repairadd.bmp";
   boltLength       = 50.0;
   segmentDivisions = 4;
   beamWidth        = 0.125;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.85, 0.25, 0.25 };
};

function RepairBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (%target == %player) {
	   %player.repairTarget = -1;
		if (GameBase::getDamageLevel(%player) != 0) {
			%player.repairRate = 0.2;
			%player.repairTarget = %player;
			Client::sendMessage(%client, 0, "AutoRepair On");
		}
		else {
			Client::sendMessage(%client,0,"Nothing in range");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}
	}
	else {
      %player.repairTarget = %target;
		%player.repairRate   = 0.15;
		if (getObjectType(%player.repairTarget) == "Player") {
			%rclient = Player::getClient(%player.repairTarget);
			%name = Client::getName(%rclient);
		}
		else { 
			%name = GameBase::getMapName(%target);
			if(%name == "") {
				%name = (GameBase::getDataName(%player.repairTarget)).description;
			}
		}
		if (GameBase::getDamageLevel(%player.repairTarget) == 0) {
			Client::sendMessage(%client,0,%name @ " is not damaged");
			Player::trigger(%player,$WeaponSlot,false);
			%player.repairTarget = -1;
			return;
		}
		if (getObjectType(%player.repairTarget) == "Player") {
			Client::sendMessage(%rclient,0,"Being repaired by " @ Client::getName(%client));
		}
		Client::sendMessage(%client,0,"Repairing " @ %name);
	}
	%rate = GameBase::getAutoRepairRate(%player.repairTarget) + %player.repairRate;
	GameBase::setAutoRepairRate(%player.repairTarget,%rate);
}

function RepairBolt::onRelease(%this, %player)
{
	%object = %player.repairTarget;
	if (%object != -1) {
		%client = Player::getClient(%player);
		if (%object == %player) {
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Client::sendMessage(%client,0,"Repair Done");
			}
			else {
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
      if (%rate < 0)
         %rate = 0;
      
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

function RepairBolt::checkDone(%this, %player)
{
	if (Player::isTriggered(%player,$WeaponSlot) && 
       Player::getMountedItem(%player,$WeaponSlot) == RepairGun &&
		 %player.repairTarget != -1) {
		%object = %player.repairTarget;
		if (%object == %player) {
			if (GameBase::getDamageLevel(%player) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
	}
}

RepairEffectData reassemblerBolt
{
   bitmapName       = "repairadd.bmp";
   boltLength       = 50.0;
   segmentDivisions = 4;
   beamWidth        = 0.125;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.85, 0.25, 0.25 };
};

function reassemblerBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (%target == %player) {
	   %player.repairTarget = -1;
		if (GameBase::getDamageLevel(%player) != 0) {
			%player.repairRate = 0.2;
			%player.repairTarget = %player;
			Client::sendMessage(%client, 0, "AutoRepair On");
		}
		else {
			Client::sendMessage(%client,0,"Nothing in range");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}
	}
	else {
      %player.repairTarget = %target;
		%player.repairRate   = 0.15;
		if (getObjectType(%player.repairTarget) == "Player") {
			%rclient = Player::getClient(%player.repairTarget);
			%name = Client::getName(%rclient);
		}
		else { 
			%name = GameBase::getMapName(%target);
			if(%name == "") {
				%name = (GameBase::getDataName(%player.repairTarget)).description;
			}
		}
		if (GameBase::getDamageLevel(%player.repairTarget) == 0) {
			Client::sendMessage(%client,0,%name @ " isn't damaged");
			Player::trigger(%player,$WeaponSlot,false);
			%player.repairTarget = -1;
			return;
		}
		if (getObjectType(%player.repairTarget) == "Player") {
			Client::sendMessage(%rclient,0,"Being repaired by " @ Client::getName(%client));
		}
		Client::sendMessage(%client,0,"Repairing " @ %name);
	}
	%rate = GameBase::getAutoRepairRate(%player.repairTarget) + %player.repairRate;
	GameBase::setAutoRepairRate(%player.repairTarget,%rate);
}

function reassemblerBolt::onRelease(%this, %player)
{
	%object = %player.repairTarget;
	if (%object != -1) {
		%client = Player::getClient(%player);
		if (%object == %player) {
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Client::sendMessage(%client,0,"Repair Done");
			}
			else {
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
      if (%rate < 0)
         %rate = 0;
      
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

function reassemblerBolt::checkDone(%this, %player)
{
	if (Player::isTriggered(%player,$WeaponSlot) && 
       Player::getMountedItem(%player,$WeaponSlot) == reassembler &&
		 %player.repairTarget != -1) {
		%object = %player.repairTarget;
		if (%object == %player) {
			if (GameBase::getDamageLevel(%player) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
	}
}

function SuperRBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (%target == %player) {
	   %player.repairTarget = -1;
		if (GameBase::getDamageLevel(%player) != 0) {
			%player.repairRate = 0.8;
			%player.repairTarget = %player;
			Client::sendMessage(%client, 0, "AutoRepair On");
		}
		else {
			Client::sendMessage(%client,0,"Nothing in range");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}
	}
	else {
      %player.repairTarget = %target;
		%player.repairRate   = 0.6;
		if (getObjectType(%player.repairTarget) == "Player") {
			%rclient = Player::getClient(%player.repairTarget);
			%name = Client::getName(%rclient);
		}
		else { 
			%name = GameBase::getMapName(%target);
			if(%name == "") {
				%name = (GameBase::getDataName(%player.repairTarget)).description;
			}
		}
		if (GameBase::getDamageLevel(%player.repairTarget) == 0) {
			Client::sendMessage(%client,0,%name @ " isn't damaged");
			Player::trigger(%player,$WeaponSlot,false);
			%player.repairTarget = -1;
			return;
		}
		if (getObjectType(%player.repairTarget) == "Player") {
			Client::sendMessage(%rclient,0,"Being repaired by " @ Client::getName(%client));
		}
		Client::sendMessage(%client,0,"Repairing " @ %name);
	}
	%rate = GameBase::getAutoRepairRate(%player.repairTarget) + %player.repairRate;
	GameBase::setAutoRepairRate(%player.repairTarget,%rate);
}

function SuperRBolt::onRelease(%this, %player)
{
	%object = %player.repairTarget;
	if (%object != -1) {
		%client = Player::getClient(%player);
		if (%object == %player) {
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Client::sendMessage(%client,0,"Repair Done");
			}
			else {
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
      if (%rate < 0)
         %rate = 0;
      
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

function SuperRBolt::checkDone(%this, %player)
{
	if (Player::isTriggered(%player,$WeaponSlot) && 
       Player::getMountedItem(%player,$WeaponSlot) == AODSuperRGun &&
		 %player.repairTarget != -1) {
		%object = %player.repairTarget;
		if (%object == %player) {
			if (GameBase::getDamageLevel(%player) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
	}
}

//--------------------------------------
// HandRocket - *IX*Savage1
//--------------------------------------

RocketData HandRocket
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = mineExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $RocketDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 200.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;

   soundId = SoundJetHeavy;
};

//--------------------------------------
// Bomber Shell - *IX*Savage1
//--------------------------------------

GrenadeData BomberShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 150;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 1.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "smoke.dts";
};

//--------------------------------------
// EMP Grenade  - *IX*Savage1
//--------------------------------------

GrenadeData EMPGrenadeShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = EMPPulseExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.51;
   damageType         = $EMPDamageType;

   explosionRadius    = 40;
   kickBackStrength   = -50.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 0.25;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
   smokeName              = "fusionbolt.dts";
   soundId = SoundELFFire;
};

//--------------------------------------
// MagnetCharge - *IX*Savage1
//--------------------------------------

LightningData MagnetCharge
{
   bitmapName       = "repairadd.bmp";

   damageType       = $MagneticDamageType;
   boltLength       = 30.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.4;
   energyDrainPerSec = 0.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.14;//0.125;//075;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 4.0;
   lightColor = { 0.85, 0.25, 0.25 };

   soundId = SoundELFFire;
};

//====================================================================Gunboy

GrenadeData Deploybox
{
   bulletShapeName    = "mine.dts";
   explosionTag       = BExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 25.0;
   elasticity         = 0.001;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0;
   damageType         = $NullDamageType;

   explosionRadius    = 1;
   kickBackStrength   = 1.0;
   maxLevelFlightDist = 128;
   totalTime          = 5.0;    // special meaning for grenades...
   liveTime           = 4.1;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

	smokeName              = "smoke.dts";
};

function Deploybox::onAdd(%this)
{
	schedule("DeployGunboy(" @ %this @ ");",4.0,%this);
}

function DeployGunboy(%this)
{
		%obj = newObject("","Mine","AntipersonelMine");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","AntipersonelMine");
		addToSet("MissionCleanup", %obj);
		%padd = "5 0 0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","AntipersonelMine");
		addToSet("MissionCleanup", %obj);
		%padd = "-5 0 0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","AntipersonelMine");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -5 0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","AntipersonelMine");
		addToSet("MissionCleanup", %obj);
		%padd = "0 5 0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

}

GrenadeData ClusterBomb         //Modified by: MegaMan
{
   bulletShapeName    = "Shockwave_Large.dts";
   explosionTag       = LargeShockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 500;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.4;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1;
   damageType         = $FlierBombDamageType;

   explosionRadius    = 40.0;
   kickBackStrength   = 100.0;
   maxLevelFlightDist = 350;
   totalTime          = 50.0;
   liveTime           = 6.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "paint.dts";
};

function ClusterBomb::onAdd(%this)
{
	schedule("BombSpread(" @ %this @ ");",5.1,%this);
}

function bombspread(%this)
{
		%obj = newObject("","Mine","bomba");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombb");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 15.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombc");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 25";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombd");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 25";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombe");
		addToSet("MissionCleanup", %obj);
		%padd = "10.0 0 25";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombe");
		addToSet("MissionCleanup", %obj);
		%padd = "-10.0 0 25";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombe");
		addToSet("MissionCleanup", %obj);
		%padd = "0 10. 25";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombe");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -10.0 25";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombe");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 35";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","bombf");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 15";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

}

//----------------------------------------------------------
GrenadeData AtomicBomb         //added by Werewolf   Modified by: Bhall
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = LargeShockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 5000;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 10;
   damageType         = $FlierBombDamageType;

   explosionRadius    = 40.0;
   kickBackStrength   = 1000.0;
   maxLevelFlightDist = 350;
   totalTime          = 50.0;
   liveTime           = 8.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
//   smokeName              = "rsmoke.dts";
};

function AtomicBomb::onAdd(%this)
{
	schedule("NuclearExplosion(" @ %this @ ");",4.9,%this);
}

function NuclearExplosion(%this)
{
		%obj = newObject("","Mine","NBase");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing1");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing2");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 10.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 15.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 20.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 25.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud1");
		addToSet("MissionCleanup", %obj);
		%padd = "15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud2");
		addToSet("MissionCleanup", %obj);
		%padd = "-15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 60.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);
}

//----------------------------------------------------------

GrenadeData SpiritBomb         //Mega Man 1024
{
   bulletShapeName    = "shockwave_large.dts";
   explosionTag       = LargeShockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 5000;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 10;
   damageType         = $NukeDamageType;

   explosionRadius    = 100.0;
   kickBackStrength   = 1000.0;
   maxLevelFlightDist = 350;
   totalTime          = 50.0;
   liveTime           = 6.5;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "shockwave_large.dts";
};

function AtomicBomb::onAdd(%this)
{
	schedule("NuclearExplosion(" @ %this @ ");",4.9,%this);
}

function NuclearExplosion(%this)
{
		%obj = newObject("","Mine","NBase");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing1");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing2");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 10.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 15.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 20.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 25.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud1");
		addToSet("MissionCleanup", %obj);
		%padd = "15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud2");
		addToSet("MissionCleanup", %obj);
		%padd = "-15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud1");
		addToSet("MissionCleanup", %obj);
		%padd = "15.0 0 55.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud2");
		addToSet("MissionCleanup", %obj);
		%padd = "-15.0 0 55.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 15.0 55.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -15.0 55.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 70.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud6");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 75.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

}

GrenadeData Det1         //Modified by: Bhall
{
   bulletShapeName    = "ammo2.dts";
   explosionTag       = LargeShockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 14;
   collisionRadius    = 0.3;
   mass               = 15.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 10;
   damageType         = $BustedDamageType;

   explosionRadius    = 50.0;
   kickBackStrength   = 1000.0;
   maxLevelFlightDist = 0;
   totalTime          = 1.1;
   liveTime           = 0.95;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//----------------------------------------------------------
GrenadeData AtomicShock         
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = LargeShockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 5000;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 10;
   damageType         = $ShockwaveDamageType;

   explosionRadius    = 300.0;
   kickBackStrength   = 1000.0;
   maxLevelFlightDist = 350;
   totalTime          = 50.0;
   liveTime           = 8.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

function AtomicShock::onAdd(%this)
{
	schedule("NuclearExplosion2(" @ %this @ ");",4.9,%this);
}

function NuclearExplosion2(%this)
{
		%obj = newObject("","Mine","NBase");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing1");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing2");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 10.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 15.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 20.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 25.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud1");
		addToSet("MissionCleanup", %obj);
		%padd = "15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud2");
		addToSet("MissionCleanup", %obj);
		%padd = "-15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 60.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);
}

//----------------------------------------------------------
GrenadeData AtomicShockTorp         
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = LargeShockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 5000;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 10;
   damageType         = $ShockwaveDamageType;

   explosionRadius    = 300.0;
   kickBackStrength   = 1000.0;
   maxLevelFlightDist = 3000;
   totalTime          = 50.0;
   liveTime           = 8.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

function AtomicShockTorp::onAdd(%this)
{
	schedule("shocktorp(" @ %this @ ");",4.9,%this);
}

function shocktorp(%this)
{
		%obj = newObject("","Mine","NBase");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing1");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 5.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing2");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 10.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 15.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 20.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NRing5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 25.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud1");
		addToSet("MissionCleanup", %obj);
		%padd = "15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud2");
		addToSet("MissionCleanup", %obj);
		%padd = "-15.0 0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud3");
		addToSet("MissionCleanup", %obj);
		%padd = "0 15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud4");
		addToSet("MissionCleanup", %obj);
		%padd = "0 -15.0 40.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);

		%obj = newObject("","Mine","NCloud5");
		addToSet("MissionCleanup", %obj);
		%padd = "0 0 60.0";
		%pos = Vector::add(GameBase::getPosition(%this), %padd);
		GameBase::setPosition(%obj, %pos);
}

GrenadeData GrandGrenadeShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.01;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.75;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 350;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 5.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "smoke.dts";
};

function GrandGrenadeShell::onAdd(%this)
{
	schedule("DeployBomblets(" @ %this @ " , 5);",3.0,%this);
}

function DeployBomblets(%this, %count) 
{
	if(%count && %this)
	{
		%obj = newObject("","Mine","Cluster1");
 		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-2,false);

		%obj = newObject("","Mine","Cluster2");
 		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-2,false);

		%obj = newObject("","Mine","Cluster3");
 		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-2,false);

		%obj = newObject("","Mine","Cluster4");
 		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-2,false);

		%obj = newObject("","Mine","Cluster5");
 		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-2,false);

		%count -= 1;
		schedule("DeployBomblets(" @ %this @ " , " @ %count @ ");",0.5,%this);
	}
}

LaserData ObeliskBeam
{
   laserBitmapName   = "laserPulse.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.0125;
   damageType    = $LaserDamageType;

   beamTime          = 0.5;
   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

RocketData FusionBall
{
   bulletShapeName  = "plasmaex.dts";
   explosionTag     = LargeShockwave;
   collisionRadius  = 0.0;
   mass             = 0.5;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $MineDamageType;

   explosionRadius  = 12.8;
   kickBackStrength = 475.0;
   muzzleVelocity   = 768.0;
   terminalVelocity = 1024.0;
   acceleration     = 32.0;
   totalTime        = 10.0;
   liveTime         = 11.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   soundId = SoundJetHeavy;
};

RocketData IonBolt
{ 
	bulletShapeName = "enbolt.dts"; 
	explosionTag = turretExp; 
	collisionRadius = 0.0;
	 mass = 2.0; 
	damageClass = 1; // 0 impact, 1, radius 
    damageValue = 0.64; 
	damageType = $ElectricityDamageType; 
	explosionRadius = 6; 
	kickBackStrength = 0.0; 
	muzzleVelocity = 150.0; 
	terminalVelocity = 500.0;
	 acceleration = 10.0; 
	totalTime = 10.0; 
	liveTime = 7.0; 
	lightRange = 5.0; 
	lightColor = { 1.0, 0.7, 0.5 }; 
	inheritedVelocityScale = 0.5; 
	// rocket specific 
	trailType = 1;
	trailLength = 255; 
	trailWidth = 0.9; 
	soundId = SoundJetHeavy;
};

//--------------------------------------
RocketData ProxyMissile
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = Shockwave;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1;
   damageType       = $MissileDamageType;

   explosionRadius  = 50;
   kickBackStrength = 250.0;
   muzzleVelocity   = 255.0;
   terminalVelocity = 512.0;
   acceleration     = 8.0;
   totalTime        = 16.0;
   liveTime         = 16.384;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "shotgunex.dts";
   smokeDist   = 5.12;

   soundId = SoundJetHeavy;
};

//--------------------------------------
RocketData CannonShell
{
   bulletShapeName  = "mortar.dts";
   explosionTag     = mortarExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $MissileDamageType;

   explosionRadius  = 16;
   kickBackStrength = 250.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "mortartrail.dts";
   smokeDist   = 5.12;

   soundId = SoundJetHeavy;
};

GrenadeData TeleportShock 
{ 
	bulletShapeName = "breath.dts";
 	explosionTag = TeleportExp;
 	collideWithOwner = false;
 	ownerGraceMS = 500;
 	collisionRadius = 0.0;
 	mass = 0.0;
 	elasticity = 0.1;
 	damageClass = 0;
 	damageValue = 0.01;
 	damageType = $NullDamageType;
 	explosionRadius = 10;
 	kickBackStrength = 0.0;
 	maxLevelFlightDist = 1;
 	totalTime = 0.05;
 	liveTime = 0.05;
 	projSpecialTime = 0.05;
 	inheritedVelocityScale = 1.0;
 	smokeName = "breath.dts";
 };

//--------------------------------------
BulletData UziBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.1;
   damageType         = $BulletDamageType;

   muzzleVelocity     = 500.0;
   totalTime          = 5.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData SwarmerRocket
{
   bulletShapeName    = "rocket.dts";
   explosionTag       = flashExpLarge;

   damageClass        = 1;
   damageValue        = 0.25;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 6.0;
   aimDeflection      = 0.015;

   muzzleVelocity     = 155.0;
   totalTime          = 3.0;
   liveTime           = 2.0;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

RocketData TurretDiscShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.75;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 75.0;
   terminalVelocity = 100.0;
   acceleration     = 15.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 100;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

//--------------------------------------
SeekingMissileData SwarmRocketSeeking
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;
   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.33;
   damageType       = $PMissileDamageType;
   explosionRadius  = 9.5;
   kickBackStrength = 25.0;

   muzzleVelocity    = 85.0;
   totalTime         = 10;
   liveTime          = 10;
   seekingTurningRadius    = 9;
   nonSeekingTurningRadius = 75.0;
   proximityDist     = 1.5;
   smokeDist         = 1.75;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };

   inheritedVelocityScale = 0.5;

   soundId = SoundJetHeavy;
};

BulletData SwarmRocketMiss
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;
   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.2;
   damageType       = $PMissileDamageType;
   explosionRadius  = 9.5;
   kickBackStrength = 15.0;

   aimDeflection    = 0.006;
   muzzleVelocity   = 65.0;
   totalTime        = 6.0;
   liveTime         = 6.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;

   soundId = SoundJetHeavy;
};

RocketData ChargedFusionBolt
{
   bulletShapeName  = "fusionbolt.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.85;
   damageType       = $DisruptorDamageType;

   explosionRadius  = 12.5;
   kickBackStrength = 150.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 200.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "hflame.dts";
   smokeDist   = 3.141592654;

   soundId = SoundJetHeavy;
};

RocketData fluxbolt
{
   bulletShapeName  = "plasma.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 75;
   damageType       = $ElectricityDamageType;

   explosionRadius  = 16;
   kickBackStrength = 512.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 115.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "plasma.dts";
   smokeDist   = 3.14;

   soundId = SoundELFIdle;
};

LaserData MiniPBWBeam
{
   laserBitmapName   = "paintpulse.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.025;
   baseDamageType    = $PBWDamageType;

   beamTime          = 0.75;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = rocketExplosion;
};

LaserData SuperPBWBeam
{
   laserBitmapName   = "laserPulse.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.08;
   baseDamageType    = $PBWDamageType;

   beamTime          = 0.75;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = BigExplosion3;
};

//--------------------------------------
BulletData DisruptorBolt
{
   bulletShapeName    = "paint.dts";
   explosionTag       = disexp;

   damageClass        = 1;
   damageValue        = 0.5;
   damageType         = $DisruptorDamageType;
   explosionRadius    = 10;

   muzzleVelocity     = 300.0;
   totalTime          = 10.0;
   liveTime           = 7;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

//--------------------------------------
BulletData BusterBolt
{
   bulletShapeName    = "paint.dts";
   explosionTag       = disexp;

   damageClass        = 1;
   damageValue        = 0.5;
   damageType         = $DisruptorDamageType;
   explosionRadius    = 5;

   muzzleVelocity     = 300.0;
   totalTime          = 10.0;
   liveTime           = 7;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

LaserData aaLaser
{
   laserBitmapName   = "lightningNew.bmp";
   hitName           = "tumult_small.dts";

   damageConversion  = 0.03;
   baseDamageType    = $SniperDamageType;

   beamTime          = 0.75;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundFlierCrash;
};

RocketData AntiMatterBolt
{
   bulletShapeName  = "shockwave_large.dts";
   explosionTag     = LargeShockwave;
   collisionRadius  = 0.0;
   mass             = 0.5;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 3.14;
   damageType       = $ImpactDamageType;

   explosionRadius  = 64;
   kickBackStrength = 512.0;
   muzzleVelocity   = 32.0;
   terminalVelocity = 128.0;
   acceleration     = 32.0;
   totalTime        = 10.0;
   liveTime         = 9.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   trailType   = 2;                // smoke trail
   trailString = "smoke.dts";
   smokeDist   = 3.1415926; // Pi

   soundId = SoundJetHeavy;
};

SeekingMissileData CruiseMissile 
{
bulletShapeName = "rocket.dts";
explosionTag = mortarExp;
collisionRadius = 0.0;
mass = 2.0;
damageClass = 1;
damageValue = 3;
damageType = $MissileDamageType;
explosionRadius = 32;
kickBackStrength = 200.0;
muzzleVelocity = 20.0;
terminalVelocity = 500.0;
acceleration = 10.0;
totalTime = 20.0;
liveTime = 21.0;
lightRange = 5.0;
lightColor = { 1.0, 0.7, 0.5 };
inheritedVelocityScale = 0.5;
seekingTurningRadius = 0.0;
nonSeekingTurningRadius = 5.0;
proximityDist = 1.5;
lightRange = 5.0;
lightColor = { 0.4, 0.4, 1.0 };
smokeDist         = 15;
inheritedVelocityScale = 0.5;
soundId = SoundJetHeavy;
};

BulletData sniperXBullet
{	bulletShapeName = "smoke.dts";
	explosionTag	= SniperXExp;
	mass			= 2.0;
	collisionRadius = 0.0;
	bulletHoleIndex = 0;
	ExplosionRadius = 7.5;
	damageClass		= 1;
	damageValue		= 0.45;
	damageType		= $MineDamageType;
	aimDeflection	= 0.0;
	muzzleVelocity	= 1500.0;
	totalTime		= 1.5;
	liveTime		= 1.6;
	inheritedVelocityScale = 0.5;
	isVisible		= true;
	tracerPercentage = 1;
	tracerLength	= 10;
	detachFromShooter = false;
	soundId			= soundjetHeavy;
	rotationPeriod	= 0;
	lightRange		= 1.0;
	lightColor		= {1.0, 0.25,0.25};
};

BulletData flier2bullet
{	bulletShapeName = "Bullet.DTS";
	explosionTag = bulletExp0;
	expRandCycle	= 3;
	mass = 1.75;
	bulletHoleIndex = 0;
	ExplosionRadius = 3;
	damageClass = 0;
	damageValue = 0.10;
	damageType = $BulletDamageType;
	aimDeflection = 0.006;
	muzzleVelocity = 550.0;
	totalTime = 0.30;
	inheritedVelocityScale = 0.75;
	isVisible = False;
	tracerPercentage = 0.5;
	tracerLength = 10;
	detachFromShooter = false;
	rotationPeriod = 0;
	lightRange = 0.0;
	lightColor = {1.0, 0.25,0.25};
};

GrenadeData ImplosionShell
{
   bulletShapeName    = "armorkit.dts";

  explosionTag       = mineExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 0.1;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.6;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 450;
   totalTime          = 37.0;    // special meaning for grenades...
   liveTime           = 5.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "plasmatrail.dts";
};
function ImplosionShell::onAdd(%this)
{
	schedule("DeployISHandgrenades(" @ %this @ " , 5);",1.0,%this);
}

function DeployISHandgrenades(%this, %count) 
{
	if(%count && %this)
	{
		%obj = newObject("","Mine","MDHandgrenade1");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-5,true);
		%obj = newObject("","Mine","MDHandgrenade2");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-7.5,false);
		%obj = newObject("","Mine","MDHandgrenade3");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,5,false);
		%obj = newObject("","Mine","MDHandgrenade4");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,7.5,true);
		%obj = newObject("","Mine","MDHandgrenade5");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-1,false);
		%count = 2;
//		schedule("DeployISHandgrenades(" @ %this @ ", " @ %count @ ");",0.5,%this);
//		schedule("DeployISHandgrenades(" @ %this @ ");",0.1,%this);
	}
}

GrenadeData ImplosionShell2
{
   bulletShapeName    = "shockwave_large.dts";

  explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 0.1;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 450;
   totalTime          = 37.0;    // special meaning for grenades...
   liveTime           = 5.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "plasmatrail.dts";
};

function ImplosionShell2::onAdd(%this)
{
	schedule("DeployGBHandgrenades(" @ %this @ " , 5);",1.0,%this);
}

function DeployGBHandgrenades(%this, %count) 
{
	if(%count && %this)
	{
		%obj = newObject("","Mine","MHandgrenade1");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-5,true);
		%obj = newObject("","Mine","MHandgrenade2");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-7.5,false);
		%obj = newObject("","Mine","MHandgrenade3");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,5,false);
		%obj = newObject("","Mine","MHandgrenade4");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,7.5,true);
		%obj = newObject("","Mine","MHandgrenade5");
		addToSet("MissionCleanup", %obj);
		GameBase::throw(%obj,%this,-1,false);
		%count = 2;
//		schedule("DeployGBHandgrenades(" @ %this @ ", " @ %count @ ");",1.0,%this);
	}
}

