// ====================== ======================== ===================== Items.cs Mega Man 1024
// ====================== Successor to Item.cs -- No confusion

//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
//
//	Weapons From Original Tribes and Meltdown Arbitor...
//
//    Any weapons, ammo, packs and deployables below this line are made by 
//    Mega Man 1024 or {J} MEGA-Man unless specifically noted or otherwise
//
//    Taken items from: 
//    Arbitor
//	Meltdown
//
//	Helping People:
//	[MR] Tribe
//	[AAOD] Tribe
//	Flame
//
//	This mod will blow Renegades and any other mod out of the water!
//    Ecstacy to take over.....
//    Exceptions: Killer & AAOD
//
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------

$ExtraWeaponSlotA=4;
$ExtraWeaponSlotB=5;
$ExtraWeaponSlotC=6;
$ArmorDetailSlot=7;

%boom = "BOOM";

//--------------------------------------------------------------------------------------------------------
// Ghetto Blaster
//--------------------------------------------------------------------------------------------------------


ItemImageData GBlasterImage
{
   shapeFile  = "energygun";
	mountPoint = 0;
	mountRotation = { 0, -1.57, 0 };

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.15;
	minEnergy = 5;
	maxEnergy = 6;

	projectileType = BlasterBolt;
	accuFire = true;

	sfxFire = SoundFireBlaster;
	sfxActivate = SoundPickUpWeapon;
};

ItemData GhettoBlaster
{
   heading = "bWeapons";
	description = "Ghetto Blaster";
	className = "Weapon";
   shapeFile  = "energygun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = GBlasterImage;
	price = 100;
	showWeaponBar = true;
};

function GhettoBlaster::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>" @ %item.description @ "\n<f0>Damage: <f5>|||||||||<f2>|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||", 10);
}

$InvList[GhettoBlaster] = 1;
$RemoteInvList[GhettoBlaster] = 1;

$ItemMax[larmor, GhettoBlaster] = 1;
$ItemMax[lfemale, GhettoBlaster] = 1;
$ItemMax[engineer, GhettoBlaster] = 1;
$ItemMax[enginers, GhettoBlaster] = 1;
$ItemMax[gharmor, GhettoBlaster] = 1;

//--------------------------------------------------------------------------------------------------------
// MegaMan Buster pod
//--------------------------------------------------------------------------------------------------------

ItemImageData BusterImage
{
	shapeFile = "mortar";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	minEnergy = 5;
	maxEnergy = 5;
	projectileType = MicrowaveBolt;
	accuFire = true;
	reloadTime = 0;
	fireTime = 0.75;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 1, 1, 0.2 };

	sfxFire = SoundFireFlierRocket;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Buster
{
	description = "Buster Pod";
	className = "Weapon";
	shapeFile = "mortar";
	hudIcon = "chain";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = BusterImage;
	price = 100;
	showWeaponBar = true;
};

function Buster::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f2>Buster", 5);
}

$InvList[Buster] = 1;
$RemoteInvList[Buster] = 1;

$ItemMax[transformer, Buster] = 1;

//--------------------------------------------------------------------------------------------------------
// AAOD SniperX
//--------------------------------------------------------------------------------------------------------

ItemImageData SXImage 
{
	shapeFile = "sniper";
	mountPoint = 0;
	mountRotation = { 0,-1.57, 0 };

	weaponType = 0; 
      projectileType = sniperXBullet;
	accuFire = true;
	fireTime = 1.5;
	reloadTime = 0;
	sfxFire = SoundFireSniperX;
	sfxActivate = SoundPickUpWeapon;
};

ItemData AAODSniperX
{
	description = "AAOD SniperX";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "chain";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = SXImage;
	price = 4500;
	showWeaponBar = true;
};

function AAODSniperX::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>" @ %item.description @ "\n<f0>Damage: <F5>||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<f2>", 10);
}

$InvList[AAODSniperX] = 1;
$RemoteInvList[AAODSniperX] = 1;

$ItemMax[larmor, AAODSniperX] = 1;
$ItemMax[lfemale, AAODSniperX] = 1;
$ItemMax[blastech, AAODSniperX] = 1;
$ItemMax[blastechf, AAODSniperX] = 1;
$ItemMax[gharmor, AAODSniperX] = 1;

//--------------------------------------------------------------------------------------------------------
// Fusion Cannon
//--------------------------------------------------------------------------------------------------------

ItemImageData FCBS
{
	shapeFile = "mortargun";
	mountPoint = 0;

	weaponType = 1; // Spinning
	reloadTime = 0;
	spinUpTime = 0.5;
	spinDownTime = 3;
	fireTime = 1.5;

	projectileType = ChargedFusionBolt;
	accuFire = false;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundMortarTurretFire;
	sfxActivate = SoundPickUpWeapon;
	sfxSpinUp = ForceFieldOpen;
	sfxSpinDown = ForceFieldClose;
};

ItemData FusionCannon
{
	description = "Fusion Cannon";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "chain";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = FCBS;
	price = 12500;
	showWeaponBar = true;
};

function FusionCannon::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>" @ %item.description @ "\n<f0>Damage: <F5>|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<f2>|||||||||||||||||||||||||||||||||||||||||||||||||||", 10);
}

$InvList[FusionCannon] = 1;
$RemoteInvList[FusionCannon] = 1;

$ItemMax[harmor, FusionCannon] = 1;
$ItemMax[gharmor, FusionCannon] = 1;
$ItemMax[disruptor, FusionCannon] = 1;
$ItemMax[disrupter, FusionCannon] = 1;
$ItemMax[transformer, FusionCannon] = 1;

//--------------------------------------------------------------------------------------------------------
// Juggalo Electro-Optical Missile Launcher
//--------------------------------------------------------------------------------------------------------

ItemImageData JugLauncherImage
{
	shapeFile = "mortargun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	minEnergy = 64;
	maxEnergy = 64;
	accuFire = true;
	reloadTime = 0.5;
	fireTime = 5.0;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundMissileTurretFire;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
};

ItemData JugLauncher // god I love energy weapons!!!
{
	description = "Juggalo EO-Missile Laucher";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "fear";
    heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = JugLauncherImage;
	price = 15200;
	showWeaponBar = true;
};

function JugLauncher::onMount(%player,%item,$WeaponSlot)
{
	%client = Player::getclient(%player);
      bottomprint(%client, "<f0>Juggalo Electro-Optical Missile Launcher: <f2>When you fire it, be sure to control it immediately.\n<f1>*WARNING*<f2> Do not fire while in the air or inside a small or enclosed building.");
}

function JugLauncherImage::onFire(%this,%slot)
{
    %client = Player::getClient(%this);
    %weapon = Player::getMountedItem(%client,$WeaponSlot);
    %trans = GameBase::getMuzzleTransform(%client);
    %vel = Item::getVelocity(%client);
    %obj = getObjectType($los::object);

	 if(!%player.vehicle)
	 {
	  %rot = GameBase::getRotation(%client);
	  %posX = getWord(%trans,9);
	  %posY = getWord(%trans,10);
	  %posZ = getWord(%trans,11) + 3.0;
	  %position = %posX@" "@%posY@" "@%posZ;
	   
      %obj = newObject("Juggalo Electro-Optical Missile",flier,EOMissile,true);
      addToSet("MissionCleanup",%obj);
      GameBase::setTeam(%obj,GameBase::getTeam(%this));
	  GameBase::setPosition(%obj,%position);
      GameBase::setRotation(%obj,%rot);
      Gamebase::setMapName(%obj,"Juggalo Electro-Optical Missile");
      GameBase::startFadeIn(%obj);
      Client::setControlObject(%client,%obj);
      %this.vehicle = %obj;
      %this.lastWeapon = %weapon;
	  Player::unMountItem(%this,$WeaponSlot);
	 }
}

$InvList[JugLauncher] = 1;
$RemoteInvList[JugLauncher] = 1;

$ItemMax[gharmor, JugLauncher] = 1;
$ItemMax[harmor, JugLauncher] = 1;

//--------------------------------------------------------------------------------------------------------
// Swarmer
//--------------------------------------------------------------------------------------------------------

ItemData SwarmerAmmo
{
	description = "Swarmer Rack";
	className = "Ammo";
	shapeFile = "mortarammo";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 4;
};

ItemImageData SwarmerImage
{
	shapeFile = "mortargun";
	mountPoint = 0;
	mountOffset = { 0, -0.1, 0 };

	weaponType = 0; // Single Shot
	ammoType = SwarmerAmmo;
	accuFire = false;
	reloadTime = 2.5;
	fireTime = 1.5;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireSeeking;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
};

ItemData Swarmer
{
	description = "Swarmer";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "grenade";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = SwarmerImage;
	price = 16384;
	showWeaponBar = true;
};

function Swarmer::onMount(%player,%item,$WeaponSlot)
{
	%client = Player::getclient(%player);
	Player::mountItem(%player,ExtraSwarmerA,$ExtraWeaponSlotA);
	Player::mountItem(%player,ExtraSwarmerB,$ExtraWeaponSlotB);
	Player::mountItem(%player,ExtraSwarmerC,$ExtraWeaponSlotC);
}

function Swarmer::onUnmount(%player,%item,$WeaponSlot)
{
	Player::unmountItem(%player,$ExtraWeaponSlotA);
	Player::unmountItem(%player,$ExtraWeaponSlotB);
	Player::unmountItem(%player,$ExtraWeaponSlotC);
}

function SwarmerImage::onFire(%player,%slot)
{
	%rawCharge = Player::getItemCount(%player,SwarmerAmmo);
	%charge = %rawCharge *= 0.2;
	if(%charge > 0)
	{
		for(%i=1; %i<%charge; %i++)
		{
			%trans = GameBase::getMuzzleTransform(%player);
			%vel = Item::getVelocity(%player);
			Projectile::spawnProjectile("SwarmerRocket",%trans,%player,%vel);
		}
		Player::setItemCount(%player,SwarmerAmmo,0);
		if($SwarmerRecharging[%player] != True)
		{
			$SwarmerRecharging[%player] = True;
			%guntype = Swarmer;
			schedule("RechargeAmmo(" @ %player @ ", " @ %guntype @ ");",0.25,%player);
		}
	}
		else Client::sendMessage(Player::getClient(%player),0,"Swarmer is out of energy.");
}


ItemImageData SwarmerImageA
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = { 0, 0, 0.25 };

	weaponType = 0; // Single Shot
	ammoType = SwarmerAmmo;
	accuFire = false;
	reloadTime = 2.5;
	fireTime = 1.5;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
};

ItemData ExtraSwarmerA
{
	description = "Swarmer Extra Barrel";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = "cSpecialWeapons";
	shadowDetailMask = 4;
	imageType = SwarmerImageA;
	price = 0;
	showWeaponBar = true;
	showInventory = false;
};


ItemImageData SwarmerImageB
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = { 0.15, 0, 0 };

	weaponType = 0; // Single Shot
	ammoType = SwarmerAmmo;
	accuFire = false;
	reloadTime = 2.5;
	fireTime = 1.5;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
};

ItemData ExtraSwarmerB
{
	description = "Swarmer Extra Barrel";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = "cSpecialWeapons";
	shadowDetailMask = 4;
	imageType = SwarmerImageB;
	price = 0;
	showWeaponBar = true;
	showInventory = false;
};


ItemImageData SwarmerImageC
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = { -0.15, 0, 0 };

	weaponType = 0; // Single Shot
	ammoType = SwarmerAmmo;
	accuFire = false;
	reloadTime = 2.5;
	fireTime = 1.5;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
};

ItemData ExtraSwarmerC
{
	description = "Swarmer Extra Barrel";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = "cSpecialWeapons";
	shadowDetailMask = 4;
	imageType = SwarmerImageC;
	price = 0;
	showWeaponBar = true;
	showInventory = false;
};


function RechargeAmmo(%player,%gunType)
{
	%armor = Player::GetArmor(%player);
	if(%gunType == Swarmer && (Player::getItemCount(%player,Swarmer) > 0))
	{
		if(Player::getItemCount(%player,SwarmerAmmo) < $ItemMax[%armor,SwarmerAmmo])
		{
			Player::incItemCount(%player,SwarmerAmmo,1);
			schedule("RechargeAmmo(" @ %player @ ", " @ %gunType @ ");",0.125,%player);
		}
		else
			$SwarmerRecharging[%player] = False;
	}
	else if(%gunType == PlasmaGun (Player::getItemCount(%player,PlasmaGun) > 0))
{
	if(Player::getItemCount(%player,PlasmaAmmo) < $ItemMax[%armor,PlasmaAmmo])
	{
		Player::incItemCount(%player,PlasmaAmmo,1);
		schedule("RechargeAmmo(" @ %player @ ", " @ %gunType @ ");",1,%player);
	}
	else
		$PlasmaGunRecharging[%player] = False;
}
}

function THResuply(%player)
{
	Station::itemsToResupply(%player);
	schedule("THResuply(" @ %player @ ");",0.25,%this);
}

$SellAmmo[SwarmerAmmo] = 50;
$AmmoPackMax[SwarmerAmmo] = 75;
$AmmoPackItems[16] = SwarmerAmmo;
$WeaponAmmo[Swarmer] = SwarmerAmmo;

$InvList[Swarmer] = 1;
$RemoteInvList[Swarmer] = 1;
$InvList[SwarmerAmmo] = 1;
$RemoteInvList[SwarmerAmmo] = 1;

$ItemMax[transformer, Swarmer] = 1;
$ItemMax[gharmor, Swarmer] = 1;
$ItemMax[harmor, Swarmer] = 1;
$ItemMax[larmor, Swarmer] = 1;
$ItemMax[marmor, Swarmer] = 1;
$ItemMax[blastech, Swarmer] = 1;
$ItemMax[disruptor, Swarmer] = 1;
$ItemMax[vulcan, Swarmer] = 1;
$ItemMax[lfemale, Swarmer] = 1;
$ItemMax[mfemale, Swarmer] = 1;
$ItemMax[blastechf, Swarmer] = 1;
$ItemMax[disrupter, Swarmer] = 1;
$ItemMax[vulcanf, Swarmer] = 1;
$ItemMax[engineers, Swarmer] = 1;
$ItemMax[engineer, Swarmer] = 1;

$ItemMax[transformer, SwarmerAmmo] = 350;
$ItemMax[gharmor, SwarmerAmmo] = 500;
$ItemMax[harmor, SwarmerAmmo] = 250;
$ItemMax[larmor, SwarmerAmmo] = 25;
$ItemMax[marmor, SwarmerAmmo] = 50;
$ItemMax[blastech, SwarmerAmmo] = 150;
$ItemMax[disruptor, SwarmerAmmo] = 15;
$ItemMax[vulcan, SwarmerAmmo] = 10;
$ItemMax[lfemale, SwarmerAmmo] = 25;
$ItemMax[mfemale, SwarmerAmmo] = 50;
$ItemMax[blastechf, SwarmerAmmo] = 150;
$ItemMax[disrupter, SwarmerAmmo] = 15;
$ItemMax[vulcanf, SwarmerAmmo] = 10;
$ItemMax[engineers, SwarmerAmmo] = 100;
$ItemMax[engineer, SwarmerAmmo] = 100;

//--------------------------------------------------------------------------------------------------------
// Scouter Electro-Optical Rocket Launcher
//--------------------------------------------------------------------------------------------------------

ItemImageData ScoLauncherImage
{
	shapeFile = "grenadel";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	minEnergy = 32;
	maxEnergy = 32;
	accuFire = true;
	reloadTime = 0.5;
	fireTime = 2.5;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireFlierRocket;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundDryFire;
};

ItemData ScoLauncher 
{
	description = "Scouter Rocket Laucher";
	className = "Tool";
	shapeFile = "grenadel";
	hudIcon = "fear";
    heading = "cTools";
	shadowDetailMask = 4;
	imageType = ScoLauncherImage;
	price = 5000;
	showWeaponBar = true;
};

function ScoLauncher::onMount(%player,%item,$WeaponSlot)
{
	%client = Player::getclient(%player);
      bottomprint(%client, "<f0>Scouter Electro-Optical Rocket Launcher: <f2>When you fire it, be sure to control it immediately.\n<f1>*WARNING*<f2> Do not fire while in the air or inside a small or enclosed area.");
}

function ScoLauncherImage::onFire(%this,%slot)
{
    %client = Player::getClient(%this);
    %weapon = Player::getMountedItem(%client,$WeaponSlot);
    %trans = GameBase::getMuzzleTransform(%client);
    %vel = Item::getVelocity(%client);
    %obj = getObjectType($los::object);

	 if(!%player.vehicle)
	 {
	  %rot = GameBase::getRotation(%client);
	  %posX = getWord(%trans,9);
	  %posY = getWord(%trans,10);
	  %posZ = getWord(%trans,11) + 3.0;
	  %position = %posX@" "@%posY@" "@%posZ;
	   
      %obj = newObject("Scouter Electro-Optical Missile",flier,ScouterMissile,true);
      addToSet("MissionCleanup",%obj);
      GameBase::setTeam(%obj,GameBase::getTeam(%this));
	  GameBase::setPosition(%obj,%position);
      GameBase::setRotation(%obj,%rot);
      Gamebase::setMapName(%obj,"Scouter Electro-Optical Missile");
      GameBase::startFadeIn(%obj);
      Client::setControlObject(%client,%obj);
      %this.vehicle = %obj;
      %this.lastWeapon = %weapon;
	  Player::unMountItem(%this,$WeaponSlot);
	 }
}

$InvList[ScoLauncher] = 1;
$RemoteInvList[ScoLauncher] = 1;

$ItemMax[transformer, ScoLauncher] = 1;
$ItemMax[gharmor, ScoLauncher] = 1;
$ItemMax[harmor, ScoLauncher] = 1;
$ItemMax[larmor, ScoLauncher] = 1;
$ItemMax[marmor, ScoLauncher] = 1;
$ItemMax[blastech, ScoLauncher] = 1;
$ItemMax[disruptor, ScoLauncher] = 1;
$ItemMax[vulcan, ScoLauncher] = 1;
$ItemMax[lfemale, ScoLauncher] = 1;
$ItemMax[mfemale, ScoLauncher] = 1;
$ItemMax[blastechf, ScoLauncher] = 1;
$ItemMax[disrupter, ScoLauncher] = 1;
$ItemMax[vulcanf, ScoLauncher] = 1;
$ItemMax[engineers, ScoLauncher] = 1;
$ItemMax[engineer, ScoLauncher] = 1;

function DeployDrone(%player,%item,%shape,%data,%name)
{
 %client = Player::getClient(%player);
 if(GameBase::getLOSInfo(%player,3))
  {
   if(Vector::dot($los::normal,"0 0 1") > 0.7)
   {
   %rot = GameBase::getRotation(%player);
   %obj = newObject(%name,%data,%shape,true);
   if($TeamItemCount[GameBase::getTeam(%player) @ %name@"Pack"] >= $TeamItemMax[%item])
    {
		centerprint(%client,"<jc>Maximum number of "@%name@"s deployed.");
		deleteObject(%obj);
		return;
	}
   addToSet("MissionCleanup",%obj);
   GameBase::setTeam(%obj,GameBase::getTeam(%player));
   GameBase::setPosition(%obj,$los::position);
   GameBase::setRotation(%obj,%rot);
   Gamebase::setMapName(%obj,%name);
   Client::sendMessage(%client,0,%name@" Deployed ");
   GameBase::startFadeIn(%obj);
   playSound(SoundPickupBackpack,$los::position);
   Client::setControlObject(%client,%obj);
   %player.vehicle = %obj;
   $TeamItemCount[GameBase::getTeam(%player) @ %name@"Pack"]++;
   return true;
   }
   else Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
   }
  else Client::sendMessage(%client,0,"Deploy position out of range");
 return false;
}

ItemImageData DronePackImage
{
	shapeFile = "ammopack";
	weaponType = 2;
	mountPoint = 2;
	mountOffset = { 0, -0.1, 0 };

	minEnergy = 4;
 	maxEnergy = 4.5;
	firstPerson = false;
};

ItemData DronePack
{
	description = "Survey Drone";
	shapeFile = "ammopack";
	className = "Backpack";
    heading = "dDeployables";
	shadowDetailMask = 4;
	imageType = DronePackImage;
	mass = 0.5;
	price = 200;
	hudIcon = "energypack";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function DronePack::onUse(%player,%item)
{
if(Player::getMountedItem(%player,$BackpackSlot) != %item) Player::mountItem(%player,%item,$BackpackSlot);
else Player::deployItem(%player,%item);
}

function DronePack::onDeploy(%player,%item,%pos)
{

if(DeployDrone(%player,%item,SurveyDrone,flier,SurveyDrone)) if(!Player::isDead(%player)) Player::decItemCount(%player,%item);
}

$TeamItemMax[DronePack] = 70000;

$InvList[DronePack] = 1;
$RemoteInvList[DronePack] = 1;

$ItemMax[transformer, DronePack] = 1;
$ItemMax[gharmor, DronePack] = 1;
$ItemMax[harmor, DronePack] = 1;
$ItemMax[larmor, DronePack] = 1;
$ItemMax[marmor, DronePack] = 1;
$ItemMax[blastech, DronePack] = 1;
$ItemMax[disruptor, DronePack] = 1;
$ItemMax[vulcan, DronePack] = 1;
$ItemMax[lfemale, DronePack] = 1;
$ItemMax[mfemale, DronePack] = 1;
$ItemMax[blastechf, DronePack] = 1;
$ItemMax[disrupter, DronePack] = 1;
$ItemMax[vulcanf, DronePack] = 1;
$ItemMax[engineers, DronePack] = 1;
$ItemMax[engineer, DronePack] = 1;

$ItemMax[engineer, reassembler] = 1;
$ItemMax[engineers, reassembler] = 1;

ItemImageData ProbePackImage
{
	shapeFile = "ammopack";
	weaponType = 2;
	mountPoint = 2;
	mountOffset = { 0, -0.1, 0 };

	minEnergy = 4;
 	maxEnergy = 4.5;
	firstPerson = false;
};

ItemData ProbeDroidPack
{
	description = "Probe Droid";
	shapeFile = "ammopack";
	className = "Backpack";
    heading = "dDeployables";
	shadowDetailMask = 4;
	imageType = ProbePackImage;
	mass = 0.5;
	price = 400;
	hudIcon = "energypack";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function ProbeDroidPack::onUse(%player,%item)
{
if(Player::getMountedItem(%player,$BackpackSlot) != %item) Player::mountItem(%player,%item,$BackpackSlot);
else Player::deployItem(%player,%item);
}

function ProbeDroidPack::onDeploy(%player,%item,%pos)
{

if(DeployDrone(%player,%item,ProbeDroid,flier,ProbeDroid)) if(!Player::isDead(%player)) Player::decItemCount(%player,%item);
}

$TeamItemMax[ProbeDroidPack] = 900000;

$InvList[ProbeDroidPack] = 1;
$RemoteInvList[ProbeDroidPack] = 1;

$ItemMax[transformer, ProbeDroidPack] = 1;
$ItemMax[gharmor, ProbeDroidPack] = 1;
$ItemMax[harmor, ProbeDroidPack] = 1;
$ItemMax[larmor, ProbeDroidPack] = 1;
$ItemMax[marmor, ProbeDroidPack] = 1;
$ItemMax[blastech, ProbeDroidPack] = 1;
$ItemMax[disruptor, ProbeDroidPack] = 1;
$ItemMax[vulcan, ProbeDroidPack] = 1;
$ItemMax[lfemale, ProbeDroidPack] = 1;
$ItemMax[mfemale, ProbeDroidPack] = 1;
$ItemMax[blastechf, ProbeDroidPack] = 1;
$ItemMax[disrupter, ProbeDroidPack] = 1;
$ItemMax[vulcanf, ProbeDroidPack] = 1;
$ItemMax[engineers, ProbeDroidPack] = 1;
$ItemMax[engineer, ProbeDroidPack] = 1;

//----------------------------------------------------------------------------
// Flux Turret
//----------------------------------------------------------------------------
																			
ItemImageData FluxPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData FluxPack
{
	description = "Disruptor Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = FluxPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 1000;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function FluxPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function FluxPack::onDeploy(%player,%item,%pos)
{
	if (FluxPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function FluxPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"DeployableSentry",%num) + CountObjects(%set,"DeployableTurret",%num) + CountObjects(%set,"DeployableRocket",%num);

				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"DeployableSentry",%num) + CountObjects(%set,"DeployableTurret",%num) + CountObjects(%set,"DeployableRocket",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("remoteTurret","Turret",Fluxturret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"Disruptor Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Disruptor Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "FluxPack"]++;
								echo("MSG: ",%client," deployed a Turret");
						      Client::setOwnedObject(%client, %turret);
						      Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData Fluxturret
{
	className = "Turret";
	shapeFile = "remoteturret";
	projectileType = disruptorbolt;
	maxDamage = 1;
	maxEnergy = 60;
	minGunEnergy = 10;
	maxGunEnergy = 5;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	reloadDelay = 0.3;
	speed = 4.0;
	speedModifier = 1.5;
	range = 100;
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	fireSound = SoundLaserHit;
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
	description = "Flux Turret";
	damageSkinData = "objectDamageSkins";
};

function Fluxturret::onAdd(%this)
{
	schedule("Fluxturret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,5);
	%this.shieldStrength = 0.01;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Disruptor Turret");
	}
}

function Fluxturret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function Fluxturret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function Fluxturret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "FluxPack"]--;
}

// Override base class just in case.
function Fluxturret::onPower(%this,%power,%generator) {}
function Fluxturret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,5);
	GameBase::setActive(%this,true);
}	

$InvList[FluxPack] = 1;
$RemoteInvList[FluxPack] = 1;

$TeamItemMax[FluxPack] = 900000;

$ItemMax[engineer, FluxPack] = 1;
$ItemMax[engineers, FluxPack] = 1;
$ItemMax[larmor, FluxPack] = 1;
$ItemMax[lfemale, FluxPack] = 1;

//----------------------------------------------------------------------------
// Fusion Turret
//----------------------------------------------------------------------------

ItemImageData Turret4PackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData Turret4Pack
{
	description = "Fusion Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = Turret4PackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 3500;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function Turret4Pack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function Turret4Pack::onDeploy(%player,%item,%pos)
{
	if (Turret4Pack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function Turret4Pack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"Turret4",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"FusionTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("","Turret",FusionTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"Fusion Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Fusion Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "Turret4Pack"]++;
								echo("MSG: ",%client," deployed a Remote Turret");
								//	Remote turrets - kill points to player that deploy them
								Client::setOwnedObject(%client, %turret); 
								Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData FusionTurret
{
	maxDamage = 1.0;
	maxEnergy = 100;
	minGunEnergy = 75;
	maxGunEnergy = 15;
	reloadDelay = 1;
	fireSound = SoundPlasmaTurretFire;
	activationSound = SoundPlasmaTurretOn;
	deactivateSound = SoundPlasmaTurretOff;
	whirSound = SoundPlasmaTurretTurn;
	range = 150;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "hellfiregun";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = ChargedFusionBolt;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Fusion Turret";
};

function FusionTurret::onAdd(%this)
{
	schedule("FusionTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,25);
	%this.shieldStrength = 0.006;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Fusion Turret");
	}
}

function FusionTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function FusionTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function FusionTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "Turret4Pack"]--;
}

// Override base class just in case.
function FusionTurret::onPower(%this,%power,%generator) {}
function FusionTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,25);
	GameBase::setActive(%this,true);
}	

$InvList[Turret4Pack] = 1;
$RemoteInvList[Turret4Pack] = 1;

$TeamItemMax[Turret4Pack] = 900000;

$ItemMax[engineer, Turret4Pack] = 1;
$ItemMax[engineers, Turret4Pack] = 1;

//----------------------------------------------------------------------------
// Ion Turret
//----------------------------------------------------------------------------

ItemImageData DisruptorTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 0.5;
	firstPerson = false;
};

ItemData DisruptorTurretPack
{
	description = "Ion Shockwave Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = DisruptorTurretPackImage;
	shadowDetailMask = 4;
	mass = 0.5;
	elasticity = 0.2;
	price = 2000;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function DisruptorTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function DisruptorTurretPack::onDeploy(%player,%item,%pos)
{
	if (DisruptorTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function DisruptorTurretPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"DisruptorTurret",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"DisruptorTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("","Turret",DisruptorTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"Ion Shock Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Ion Shockwave Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "DisruptorTurretPack"]++;
								echo("MSG: ",%client," deployed a Remote Turret");
								//	Remote turrets - kill points to player that deploy them
								Client::setOwnedObject(%client, %turret); 
								Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData DisruptorTurret
{
	maxDamage = 1.0;
	maxEnergy = 200;
	minGunEnergy = 25;
	maxGunEnergy = 25;
	reloadDelay = 1;
	fireSound = SoundPlasmaTurretFire;
	activationSound = SoundMortarTurretOn;
	deactivateSound = SoundMortarTurretOff;
	whirSound = SoundMortarTurretTurn;
	range = 150;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "mortar_turret";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = IonShock;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Ion Shockwave Turret";
};

function DisruptorTurret::onAdd(%this)
{
	schedule("DisruptorTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,15);
	%this.shieldStrength = 0.006;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Ion Turret");
	}
}

function DisruptorTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function DisruptorTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function DisruptorTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "DisruptorTurretPack"]--;
}

// Override base class just in case.
function DisruptorTurret::onPower(%this,%power,%generator) {}
function DisruptorTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,15);
	GameBase::setActive(%this,true);
}	

$InvList[DisruptorTurretPack] = 1;
$RemoteInvList[DisruptorTurretPack] = 1;

$TeamItemMax[DisruptorTurretPack] = 900000;

$ItemMax[engineer, DisruptorTurretPack] = 1;
$ItemMax[engineers, DisruptorTurretPack] = 1;

//----------------------------------------------------------------------------
// Mitzi Blast Turret
//----------------------------------------------------------------------------

ItemImageData IonTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData IonTurretPack
{
	description = "Mitzi Blast Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = IonTurretPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 3000;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function IonTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function IonTurretPack::onDeploy(%player,%item,%pos)
{
	if (IonTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function IonTurretPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"IonTurret",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"IonTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("","Turret",IonTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"MB Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Mitzi Blast Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "IonTurretPack"]++;
								echo("MSG: ",%client," deployed a Remote Turret");
								//	Remote turrets - kill points to player that deploy them
								Client::setOwnedObject(%client, %turret); 
								Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData IonTurret
{
	maxDamage = 1.0;
	maxEnergy = 300;
	minGunEnergy = 25;
	maxGunEnergy = 25;
	reloadDelay = 2;
	fireSound = capturedTower;
	activationSound = SoundMortarTurretOn;
	deactivateSound = SoundMortarTurretOff;
	whirSound = SoundMortarTurretTurn;
	range = 150;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "mortar_turret";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = IonShock3;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Mitzi Blast Turret";
};

function IonTurret::onAdd(%this)
{
	schedule("IonTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,15);
	%this.shieldStrength = 0.006;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Mitzi Blast Turret");
	}
}

function IonTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function IonTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function IonTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "IonTurretPack"]--;
}

// Override base class just in case.
function IonTurret::onPower(%this,%power,%generator) {}
function IonTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,15);
	GameBase::setActive(%this,true);
}	

$InvList[IonTurretPack] = 1;
$RemoteInvList[IonTurretPack] = 1;

$TeamItemMax[IonTurretPack] = 900000;

$ItemMax[engineer, IonTurretPack] = 1;
$ItemMax[engineers, IonTurretPack] = 1;

//----------------------------------------------------------------------------
// Pulse Turret
//----------------------------------------------------------------------------

ItemImageData PulseTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 0.5;
	firstPerson = false;
};

ItemData PulseTurretPack
{
	description = "Pulse Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = PulseTurretPackImage;
	shadowDetailMask = 4;
	mass = 0.5;
	elasticity = 0.2;
	price = 950;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function PulseTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function PulseTurretPack::onDeploy(%player,%item,%pos)
{
	if (PulseTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function PulseTurretPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"PulseTurret",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"PulseTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("","Turret",PulseTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"PulseTurret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Pulse Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "PulseTurretPack"]++;
								echo("MSG: ",%client," deployed a Remote Turret");
								//	Remote turrets - kill points to player that deploy them
								Client::setOwnedObject(%client, %turret); 
								Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData PulseTurret
{
	maxDamage = 1.0;
	maxEnergy = 150;
	minGunEnergy = 45;
	maxGunEnergy = 5;
	reloadDelay = 0.5;
	fireSound = SoundFireBlaster;
	activationSound = SoundPlasmaTurretOn;
	deactivateSound = SoundPlasmaTurretOff;
	whirSound = SoundPlasmaTurretTurn;
	range = 200;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "hellfiregun";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = pulseBolt;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Pulse Turret";
};

function PulseTurret::onAdd(%this)
{
	schedule("PulseTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,15);
	%this.shieldStrength = 0.006;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Pulse Turret");
	}
}

function PulseTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function PulseTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function PulseTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "PulseTurretPack"]--;
}

// Override base class just in case.
function PulseTurret::onPower(%this,%power,%generator) {}
function PulseTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,15);
	GameBase::setActive(%this,true);
}

$InvList[PulseTurretPack] = 1;
$RemoteInvList[PulseTurretPack] = 1;

$TeamItemMax[PulseTurretPack] = 900000;

$ItemMax[engineer, PulseTurretPack] = 1;
$ItemMax[engineers, PulseTurretPack] = 1;

//----------------------------------------------------------------------------
// Disc Turret
//----------------------------------------------------------------------------

ItemImageData DiscPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData DiscTurretPack
{
	description = "Disc Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = DiscPackImage;
	shadowDetailMask = 4;
	mass = 0.5;
	elasticity = 0.2;
	price = 700;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function DiscTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function DiscTurretPack::onDeploy(%player,%item,%pos)
{
	if (DiscTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function DiscTurretPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"DiscTurret",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"DiscTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("","Turret",DiscTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"Disc Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Disc Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "DiscTurretPack"]++;
								echo("MSG: ",%client," deployed a Remote Turret");
								//	Remote turrets - kill points to player that deploy them
								Client::setOwnedObject(%client, %turret); 
								Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData DiscTurret
{
	maxDamage = 1.0;
	maxEnergy = 100;
	minGunEnergy = 45;
	maxGunEnergy = 5;
	reloadDelay = 0.5;
	fireSound = SoundFireDisc;
	activationSound = SoundPlasmaTurretOn;
	deactivateSound = SoundPlasmaTurretOff;
	whirSound = SoundPlasmaTurretTurn;
	range = 100;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "chainturret";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = TurretDiscShell;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Disc Turret";
};

function DiscTurret::onAdd(%this)
{
	schedule("DiscTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,8);
	%this.shieldStrength = 0.006;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Disc Turret");
	}
}

function DiscTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function DiscTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function DiscTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "DiscTurretPack"]--;
}

// Override base class just in case.
function DiscTurret::onPower(%this,%power,%generator) {}
function DiscTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,8);
	GameBase::setActive(%this,true);
}

$InvList[DiscTurretPack] = 1;
$RemoteInvList[DiscTurretPack] = 1;

$TeamItemMax[DiscTurretPack] = 900000;

$ItemMax[engineer, DiscTurretPack] = 1;
$ItemMax[engineers, DiscTurretPack] = 1;

//----------------------------------------------------------------------------
// PBW Turret
//----------------------------------------------------------------------------

ItemImageData ElectroTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 0.5;
	firstPerson = false;
};

ItemData ElectroTurretPack
{
	description = "PBW Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "lTurrets";
	imageType = ElectroTurretPackImage;
	shadowDetailMask = 4;
	mass = 0.5;
	elasticity = 0.2;
	price = 10000;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function ElectroTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function ElectroTurretPack::onDeploy(%player,%item,%pos)
{
	if (ElectroTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function ElectroTurretPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"AntiTurret",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"ElectroTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("","Turret",AntiTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"PBW Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"PBW Turret (manual control) deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "ElectroTurretPack"]++;
								echo("MSG: ",%client," deployed a Remote Turret");
								//	Remote turrets - kill points to player that deploy them
								Client::setOwnedObject(%client, %turret); 
								Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

TurretData AntiTurret
{
	maxDamage = 1.0;
	maxEnergy = 320;
	minGunEnergy = 80;
	maxGunEnergy = 80;
	reloadDelay = 2.5;
	fireSound = SoundPBWBreakSoundBarrier;
	activationSound = SoundPlasmaTurretOn;
	deactivateSound = SoundPlasmaTurretOff;
	whirSound = SoundPlasmaTurretTurn;
	range = 200;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "hellfiregun";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = SuperPBWBeam;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "PBW Turret";
};

function AntiTurret::onAdd(%this)
{
	schedule("AntiTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,15);
	%this.shieldStrength = 0;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "PBW Turret");
	}
}

function AntiTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function AntiTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function AntiTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "ElectroTurretPack"]--;
}

// Override base class just in case.
function AntiTurret::onPower(%this,%power,%generator) {}
function AntiTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,15);
	GameBase::setActive(%this,true);
}

$InvList[ElectroTurretPack] = 1;
$RemoteInvList[ElectroTurretPack] = 1;

$TeamItemMax[ElectroTurretPack] = 900000;

$ItemMax[engineer, ElectroTurretPack] = 1;
$ItemMax[engineers, ElectroTurretPack] = 1;

//===============================================================================================
//Force field doors
//===============================================================================================

$TeamItemMax[doorthreebyfourForceFieldPack] = 1000000;

ItemImageData doorthreebyfourForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData doorthreebyfourForceFieldPack
{
        description = "3x4 Forcefield";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "iBarriers";
        imageType = doorthreebyfourForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 250;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function doorthreebyfourForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function doorthreebyfourForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (doorthreebyfourForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function doorthreebyfourForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("doorthreebyfourForceFieldPack","StaticShape",doorthreebyfourForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"3x4 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"3x4 Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "doorthreebyfourForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a 3x4 Force Field Door ");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}

StaticShapeData doorthreebyfourForceFieldShape
{
className = "LargeForceField";
damageSkinData = "objectDamageSkins";
shapeFile = "forcefield_3x4";
maxDamage = 25.0;
maxEnergy = 200;
mapFilter = 2;
visibleToSensor = true;
explosionId = mortarExp;
debrisId = flashDebrisLarge;
lightRadius = 12.0;
lightType=2;
lightColor = {1.0,0.2,0.2};
side = "single";
isTranslucent = true;
description = "3x4 Field Door";
};
function doorthreebyfourForceFieldShape::Destruct(%this)
{
doorthreebyfourForceFieldShape::doDamage(%this);
}
function doorthreebyfourForceFieldShape::doDamage(%this) {
calcRadiusDamage(%this, $DebrisDamageType, 5, 0.5, 25, 15, 4, 0.4, 0.1, 250, 100);
}
function doorthreebyfourForceFieldShape::onDestroyed(%this)
{
doorthreebyfourForceFieldShape::doDamage(%this);
$TeamItemCount[GameBase::getTeam(%this) @ "LargeForceField"]--;
}
function doorthreebyfourForceFieldShape::onCollision(%this,%obj)
{
if(getObjectType(%obj)!="Player" || Player::isDead(%obj)) {
return;
}
%c = Player::getClient(%obj);
%playerTeam = GameBase::getTeam(%obj);
%fieldTeam = GameBase::getTeam(%this);
if(%fieldTeam != %playerTeam)
{
return;
}
doorthreebyfourForceFieldShape::openDoor(%this);
return;
}
function doorthreebyfourForceFieldShape::openDoor(%this) {

GameBase::startfadeout(%this);

%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 6");
GameBase::setPosition(%this,%pos);
schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
schedule("doorthreebyfourForceFieldShape::closeDoor("@%this@");",4);
}
function doorthreebyfourForceFieldShape::closeDoor(%this) {
%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 -6");
GameBase::setPosition(%this,%pos);
GameBase::startfadein(%this);
schedule("GameBase::playSound("@%this@",ForceFieldClose,0);",0.15);

}

function doorthreebyfourForceFieldShape::openDoor(%this) {

GameBase::startfadeout(%this);

%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 6");
GameBase::setPosition(%this,%pos);
schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
schedule("doorthreebyfourForceFieldShape::closeDoor("@%this@");",4);
}

$InvList[doorthreebyfourForceFieldPack] = 1;
$RemoteInvList[doorthreebyfourForceFieldPack] = 1;

$ItemMax[engineer, doorthreebyfourForceFieldPack] = 1;
$ItemMax[engineers, doorthreebyfourForceFieldPack] = 1;
$ItemMax[marmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[mfemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[larmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[lfemale, doorthreebyfourForceFieldPack] = 1;

$TeamItemMax[doorfivebyfiveForceFieldPack] = 1000000;

ItemImageData doorfivebyfiveForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData doorfivebyfiveForceFieldPack
{
        description = "5x5 Forcefield";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "iBarriers";
        imageType = doorfivebyfiveForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function doorfivebyfiveForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function doorfivebyfiveForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (doorfivebyfiveForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function doorfivebyfiveForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("doorfivebyfiveForceFieldPack","StaticShape",doorfivebyfiveForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"5x5 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"5x5 Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "doorfivebyfiveForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a 5x5 Force Field Door ");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}

StaticShapeData doorfivebyfiveForceFieldShape
{
className = "LargeForceField";
damageSkinData = "objectDamageSkins";
shapeFile = "forcefield_5x5";
maxDamage = 25.0;
maxEnergy = 200;
mapFilter = 2;
visibleToSensor = true;
explosionId = mortarExp;
debrisId = flashDebrisLarge;
lightRadius = 12.0;
lightType=2;
lightColor = {1.0,0.2,0.2};
side = "single";
isTranslucent = true;
description = "5x5 Field Door";
};
function doorfivebyfiveForceFieldShape::Destruct(%this)
{
doorfivebyfiveForceFieldShape::doDamage(%this);
}
function doorfivebyfiveForceFieldShape::doDamage(%this) {
calcRadiusDamage(%this, $DebrisDamageType, 5, 0.5, 25, 15, 4, 0.4, 0.1, 250, 100);
}
function doorfivebyfiveForceFieldShape::onDestroyed(%this)
{
doorfivebyfiveForceFieldShape::doDamage(%this);
$TeamItemCount[GameBase::getTeam(%this) @ "LargeForceField"]--;
}
function doorfivebyfiveForceFieldShape::onCollision(%this,%obj)
{
if(getObjectType(%obj)!="Player" || Player::isDead(%obj)) {
return;
}
%c = Player::getClient(%obj);
%playerTeam = GameBase::getTeam(%obj);
%fieldTeam = GameBase::getTeam(%this);
if(%fieldTeam != %playerTeam)
{
return;
}
doorfivebyfiveForceFieldShape::openDoor(%this);
return;
}
function doorfivebyfiveForceFieldShape::openDoor(%this) {

GameBase::startfadeout(%this);

%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 6");
GameBase::setPosition(%this,%pos);
schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
schedule("doorfivebyfiveForceFieldShape::closeDoor("@%this@");",4);
}
function doorfivebyfiveForceFieldShape::closeDoor(%this) {
%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 -6");
GameBase::setPosition(%this,%pos);
GameBase::startfadein(%this);
schedule("GameBase::playSound("@%this@",ForceFieldClose,0);",0.15);

}

function doorfivebyfiveForceFieldShape::openDoor(%this) {

GameBase::startfadeout(%this);

%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 6");
GameBase::setPosition(%this,%pos);
schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
schedule("doorfivebyfiveForceFieldShape::closeDoor("@%this@");",4);
}

$InvList[doorfivebyfiveForceFieldPack] = 1;
$RemoteInvList[doorfivebyfiveForceFieldPack] = 1;

$ItemMax[engineer, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[engineers, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[marmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[mfemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[larmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[lfemale, doorfivebyfiveForceFieldPack] = 1;

$TeamItemMax[doorfourbyeightForceFieldPack] = 1000000;

ItemImageData doorfourbyeightForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData doorfourbyeightForceFieldPack
{
        description = "4x8 Forcefield";
        shapeFile = "AmmoPack";
        className = "Backpack";
          heading = "iBarriers";
        imageType = doorfourbyeightForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 1000;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function doorfourbyeightForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function doorfourbyeightForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (doorfourbyeightForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function doorfourbyeightForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("doorfourbyeightForceFieldPack","StaticShape",doorfourbyeightForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"4x8 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"4x8 Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "doorfourbyeightForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a 4x8 Force Field Door ");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}

StaticShapeData doorfourbyeightForceFieldShape
{
className = "LargeForceField";
damageSkinData = "objectDamageSkins";
shapeFile = "forcefield_4x8";
maxDamage = 25.0;
maxEnergy = 200;
mapFilter = 2;
visibleToSensor = true;
explosionId = mortarExp;
debrisId = flashDebrisLarge;
lightRadius = 12.0;
lightType=2;
lightColor = {1.0,0.2,0.2};
side = "single";
isTranslucent = true;
description = "4x8 Field Door";
};
function doorfourbyeightForceFieldShape::Destruct(%this)
{
doorfourbyeightForceFieldShape::doDamage(%this);
}
function doorfourbyeightForceFieldShape::doDamage(%this) {
calcRadiusDamage(%this, $DebrisDamageType, 5, 0.5, 25, 15, 4, 0.4, 0.1, 250, 100);
}
function doorfourbyeightForceFieldShape::onDestroyed(%this)
{
doorfourbyeightForceFieldShape::doDamage(%this);
$TeamItemCount[GameBase::getTeam(%this) @ "LargeForceField"]--;
}
function doorfourbyeightForceFieldShape::onCollision(%this,%obj)
{
if(getObjectType(%obj)!="Player" || Player::isDead(%obj)) {
return;
}
%c = Player::getClient(%obj);
%playerTeam = GameBase::getTeam(%obj);
%fieldTeam = GameBase::getTeam(%this);
if(%fieldTeam != %playerTeam)
{
return;
}
doorfourbyeightForceFieldShape::openDoor(%this);
return;
}
function doorfourbyeightForceFieldShape::openDoor(%this) {

GameBase::startfadeout(%this);

%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 6");
GameBase::setPosition(%this,%pos);
schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
schedule("doorfourbyeightForceFieldShape::closeDoor("@%this@");",4);
}
function doorfourbyeightForceFieldShape::closeDoor(%this) {
%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 -6");
GameBase::setPosition(%this,%pos);
GameBase::startfadein(%this);
schedule("GameBase::playSound("@%this@",ForceFieldClose,0);",0.15);

}

function doorfourbyeightForceFieldShape::openDoor(%this) {

GameBase::startfadeout(%this);

%pos=GameBase::getPosition(%this);
%pos=Vector::add(%pos,"0 0 6");
GameBase::setPosition(%this,%pos);
schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
schedule("doorfourbyeightForceFieldShape::closeDoor("@%this@");",4);
}

$InvList[doorfourbyeightForceFieldPack] = 1;
$RemoteInvList[doorfourbyeightForceFieldPack] = 1;

$ItemMax[engineer, doorfourbyeightForceFieldPack] = 1;
$ItemMax[engineers, doorfourbyeightForceFieldPack] = 1;
$ItemMax[marmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[mfemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[larmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[lfemale, doorfourbyeightForceFieldPack] = 1;

//--------------------------------------------------------------------------------------------------------
// Multi Cannon
//--------------------------------------------------------------------------------------------------------

ItemImageData MultiCImage

{
	shapeFile = "mortargun";
	mountPoint = 0;
	mountOffset = { 0.0, 0.0, -0.2 };
	mountRotation = { 0, 0, 0 };	
	weaponType = 0;
	minEnergy = 25;
	maxEnergy = 25;

	accuFire = false;
	reloadTime = 0.001;
	fireTime = 0.5;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
	sfxFire = SoundFireGrenade;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
	sfxReady = SoundConIdle;
};

function MultiCImage::onFire(%player, %slot) 
{
	 %playerId = Player::getClient(%player);
			 %client = GameBase::getOwnerClient(%player);
			 %trans = GameBase::getMuzzleTransform(%player);
		     %vel = Item::getVelocity(%player);

			if (%playerId.Multi == 0)
			{
				Projectile::spawnProjectile("Reaver",%trans,%player,%vel);
			}
			else if (%playerId.Multi == 1)
			{
				Projectile::spawnProjectile("Electron",%trans,%player,%vel);
			}
			else if (%playerId.Multi == 2)
			{
				Projectile::spawnProjectile("gPlasmaCannonShock2",%trans,%player,%vel);
			}
			else if (%playerId.Multi == 3)
			{
				Projectile::spawnProjectile("Devistator",%trans,%player,%vel);
			}

}

ItemData MultiCannon
{
	description = "Litmus Cannon";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "mortar";
    heading = "bWeapons";
	shadowDetailMask = 4;
        imageType = MultiCImage;
	price = 2500;
	showWeaponBar = true;
};

function MultiCannon::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>" @ %item.description @ "\n<f0>Damage: <F5>|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<f2>|||||||||||||||", 10);
}

$InvList[MultiCannon] = 1;
$RemoteInvList[MultiCannon] = 1;

$ItemMax[transformer, MultiCannon] = 1;
$ItemMax[gharmor, MultiCannon] = 1;
$ItemMax[harmor, MultiCannon] = 1;
$ItemMax[larmor, MultiCannon] = 1;
$ItemMax[marmor, MultiCannon] = 1;
$ItemMax[blastech, MultiCannon] = 1;
$ItemMax[disruptor, MultiCannon] = 1;
$ItemMax[vulcan, MultiCannon] = 1;
$ItemMax[lfemale, MultiCannon] = 1;
$ItemMax[mfemale, MultiCannon] = 1;
$ItemMax[blastechf, MultiCannon] = 1;
$ItemMax[disrupter, MultiCannon] = 1;
$ItemMax[vulcanf, MultiCannon] = 1;
$ItemMax[engineers, MultiCannon] = 1;
$ItemMax[engineer, MultiCannon] = 1;

exec("modnetwork.cs");

//--------------------------------------------------------------------------------------------------------
// Plasma Chaingun
//--------------------------------------------------------------------------------------------------------

ItemImageData ChainsmaGunImage
{
	shapeFile = "chaingun";
	mountPoint = 0;

	weaponType = 1; // Spinning
	minEnergy = 20;
	maxEnergy = 10;
	reloadTime = 0;
	spinUpTime = 0.75;
	spinDownTime = 4;
	fireTime = 0.2;

	projectileType = Plasmabolt2;
	accuFire = false;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFirePlasma2;
	sfxActivate = SoundPickUpWeapon;
	sfxSpinUp = SoundSpinUp;
	sfxSpinDown = SoundSpinDown;
};

ItemData ChainsmaGun
{
	description = "Plasma Chaingun";
	className = "Weapon";
	shapeFile = "chaingun";
	hudIcon = "chain";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = ChainsmaGunImage;
	price = 2500;
	showWeaponBar = true;
};

function ChainsmaGun::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>" @ %item.description @ "\n<f0>Damage: <f5>||||||||||||||||||||||||||||||||||||||||||||||||<f2>||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||", 10);}

$InvList[ChainsmaGun] = 1;
$RemoteInvList[ChainsmaGun] = 1;

$ItemMax[harmor, ChainsmaGun] = 1;
$ItemMax[larmor, ChainsmaGun] = 1;
$ItemMax[marmor, ChainsmaGun] = 1;
$ItemMax[engineer, ChainsmaGun] = 1;
$ItemMax[engineers, ChainsmaGun] = 1;
$ItemMax[gharmor, ChainsmaGun] = 1;
$ItemMax[transformer, ChainsmaGun] = 1;
$ItemMax[vulcan, ChainsmaGun] = 1;
$ItemMax[lfemale, ChainsmaGun] = 1;
$ItemMax[mfemale, ChainsmaGun] = 1;
$ItemMax[vulcanf, ChainsmaGun] = 1;

//--------------------------------------------------------------------------------------------------------
// Implosion Grenade
//--------------------------------------------------------------------------------------------------------

ItemImageData ImpImage

{
	shapeFile = "mortargun";
	mountPoint = 0;
	mountOffset = { 0.0, 0.0, -0.2 };
	mountRotation = { 0, 0, 0 };	
	weaponType = 0;
	minEnergy = 25;
	maxEnergy = 25;
	projectileType = ImplosionShell;
	accuFire = false;
	reloadTime = 0.75;
	fireTime = 1.5;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
	sfxFire = SoundFireMortar;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
};

ItemData ImpGun
{
	description = "Implosion Grenade Lchr.";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "mortar";
    heading = "bWeapons";
	shadowDetailMask = 4;
        imageType = ImpImage;
	price = 7500;
	showWeaponBar = true;
};

function ImpGun::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>Implosion Grenade Launcher\n<f0>Damage: <F5>|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<f2>|||||||||||||||", 10);
}

$InvList[ImpGun] = 1;
$RemoteInvList[ImpGun] = 1;

$ItemMax[transformer, ImpGun] = 1;
$ItemMax[harmor, ImpGun] = 1;
$ItemMax[marmor, ImpGun] = 1;
$ItemMax[blastech, ImpGun] = 1;
$ItemMax[mfemale, ImpGun] = 1;
$ItemMax[blastechf, ImpGun] = 1;
$ItemMax[engineers, ImpGun] = 1;
$ItemMax[engineer, ImpGun] = 1;
$ItemMax[larmor, ImpGun] = 1;
$ItemMax[lfemale, ImpGun] = 1;

//--------------------------------------------------------------------------------------------------------
// Implosion Mortar
//--------------------------------------------------------------------------------------------------------

ItemImageData Imp2Image

{
	shapeFile = "mortargun";
	mountPoint = 0;
	mountOffset = { 0.0, 0.0, -0.2 };
	mountRotation = { 0, 0, 0 };	
	weaponType = 0;
	minEnergy = 50;
	maxEnergy = 50;
	projectileType = ImplosionShell2;
	accuFire = false;
	reloadTime = 0.75;
	fireTime = 1.5;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
	sfxFire = SoundFireMortar;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
};

ItemData ImpGun2
{
	description = "Implosion Mortar Lchr.";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "mortar";
    heading = "bWeapons";
	shadowDetailMask = 4;
        imageType = Imp2Image;
	price = 15200;
	showWeaponBar = true;
};

function ImpGun2::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f1>Implosion Mortar Launcher\n<f0>Damage: <F5>|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<f2>|||||||||||||||", 10);
}

$InvList[ImpGun2] = 1;
$RemoteInvList[ImpGun2] = 1;

$ItemMax[transformer, ImpGun2] = 1;
$ItemMax[harmor, ImpGun2] = 1;
$ItemMax[engineers, ImpGun2] = 1;
$ItemMax[engineer, ImpGun2] = 1;

//----------------------------------------------------------------------------

ItemData DualDiscs
{
	description = "Dual Discs";
	className = "Ammo";
	shapeFile = "discammo";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 1;
};

ItemImageData HDisc1Image 
{ 
	shapeFile = "disc"; 
	mountPoint = 0; 
	mountRotation = { 0,-1.57, 0 }; 
	mountOffset = { 0.05, 0, 0 };
	ammoType = DualDiscs; 
	weaponType = 3; 
	accuFire = true; 
	reloadTime = 0.1; 
	fireTime = 0.1; 
	spinUpTime = 0.2; 
	projectileType = DiscShell;
}; 

ItemData HDisc1 
{ 
	description = "Disclauncher turned Sideways";
	 className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
	heading = "bWeapons"; 
	shadowDetailMask = 4; 
	imageType = HDisc1Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
}; 

ItemImageData HDisc2Image 
{
	 shapeFile = "disc"; 
	mountPoint = 0; 
	mountRotation = { 0,1.57, 0 };
	mountOffset = { 0.03, 0, 0 };
	 ammoType = DualDiscs; 
	weaponType = 3; 
	accuFire = true; 

	reloadTime = 0.1; 
	fireTime = 0.1; 
	spinUpTime = 0.2; 
	projectileType = DiscShell; 
}; 

ItemData HDisc2 
{ 
	description = "Disclauncher turned Sideways";
	 className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
	heading = "bWeapons"; 
	shadowDetailMask = 4; 
	imageType = HDisc2Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
};

ItemImageData HDiscLauncherImage 
{ 
	shapeFile = "breath"; 
	mountPoint = 3; 
	weaponType = 3; 
	ammoType = DualDiscs; 
	accuFire = true; 
	reloadTime = 0.1; 
	fireTime = 0.1; 
	spinUpTime = 0.2; 
	sfxFire = SoundFireDisc; 
	sfxActivate = SoundPickUpWeapon; 
	sfxReload = SoundDiscReload; 
	sfxReady = SoundSpinIdle; 
}; 

ItemData HDiscLauncher 
{ 
	description = "Dual Disc Launcher"; 
	className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
     heading = "bWeapons"; 
	shadowDetailMask = 4; 
	imageType = HDiscLauncherImage; 
	price = 2500; 
	showWeaponBar = true; 
}; 

function HDiscLauncherImage::onFire(%player, %slot) 
{  
	%state1 = Player::getItemState(%player,6);  
	%state2 = Player::getItemState(%player,7);  
	if (%state1 != "Fire" && %state1 != "Reload" && %state2 != "Fire" && %state2 != "Reload") 
	{   
		%client = GameBase::getOwnerClient(%player);   
		Player::decItemCount(%player, "DualDiscs", 1);   
		%num = Player::getItemCount(%player, "DualDiscs");   
		if(%client.hd == 0) 
		{    
			%client.hd = 1;    
			if(%num == 1)     
			Player::setItemCount(%player, "DualDiscs", 0);    
			else     
			Player::setItemCount(%player, "DualDiscs", %num);    
			Player::trigger(%player,6,true);    
			Player::trigger(%player,6,false);   
		} 
		else 
		{    
			%client.hd = 0;    
			if(%num == 1)     
			Player::setItemCount(%player, "DualDiscs", 0);    
			else     
			Player::setItemCount(%player, "DualDiscs", %num);    
			Player::trigger(%player,7,true);    
			Player::trigger(%player,7,false);   
		}  
	} 
} 

function HDiscLauncher::onMount(%player,%imageSlot) 
{  
	%num = Player::getItemCount(%player, "DualDiscs");  
	Player::setItemCount(%player, "DualDiscs", %num);  
	Player::mountItem(%player,HDisc1,6);  
	Player::mountItem(%player,HDisc2,7); 
} 

function HDiscLauncher::onUnmount(%player,%imageSlot) 
{  
	Player::unmountItem(%player,6);  
	Player::unmountItem(%player,7); 
}

$InvList[HDiscLauncher] = 1;
$RemoteInvList[HDiscLauncher] = 1;

$InvList[DualDiscs] = 1;
$RemoteInvList[DualDiscs] = 1;

$ItemMax[transformer, HDiscLauncher] = 1;
$ItemMax[gharmor, HDiscLauncher] = 1;
$ItemMax[harmor, HDiscLauncher] = 1;
$ItemMax[marmor, HDiscLauncher] = 1;
$ItemMax[blastech, HDiscLauncher] = 1;
$ItemMax[mfemale, HDiscLauncher] = 1;
$ItemMax[blastechf, HDiscLauncher] = 1;
$ItemMax[engineers, HDiscLauncher] = 1;
$ItemMax[engineer, HDiscLauncher] = 1;

$ItemMax[transformer, DualDiscs] = 250;
$ItemMax[gharmor, DualDiscs] = 500;
$ItemMax[harmor, DualDiscs] = 125;
$ItemMax[marmor, DualDiscs] = 100;
$ItemMax[blastech, DualDiscs] = 50;
$ItemMax[mfemale, DualDiscs] = 100;
$ItemMax[blastechf, DualDiscs] = 50;
$ItemMax[engineers, DualDiscs] = 50;
$ItemMax[engineer, DualDiscs] = 50;

//----------------------------------------------------------------------------

ItemData gatlingammo
{
	description = "Dual Chaingun Bullets";
	className = "Ammo";
	shapeFile = "discammo";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 1;
};

ItemImageData HChain1Image 
{ 
	shapeFile = "chaingun"; 
	mountPoint = 0; 
	mountRotation = { 0,1.57, 0 }; 
	mountOffset = { 0.2, 0, 0 };
	ammoType = gatlingammo; 
	weaponType = 1; 
	reloadTime = 0;
	spinUpTime = 0.5;
	spinDownTime = 3;
	fireTime = 0.2;
	projectileType = ChaingunBullet;
}; 

ItemData HChain1 
{ 
	description = "Chaingun turned Sideways";
	 className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
	heading = "bWeapons"; 
	shadowDetailMask = 4; 
	imageType = HChain1Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
}; 

ItemImageData HChain2Image 
{
	 shapeFile = "chaingun"; 
	mountPoint = 0; 
	mountRotation = { 0,-1.57, 0 };
	mountOffset = { 0, 0, 0 };
	 ammoType = gatlingammo; 
	weaponType = 1; 
	accuFire = true; 
	reloadTime = 0;
	spinUpTime = 0.5;
	spinDownTime = 3;
	fireTime = 0.2;
	projectileType = ChaingunBullet; 
}; 

ItemData HChain2 
{ 
	description = "Chaingun turned Sideways";
	 className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
	heading = "bWeapons"; 
	shadowDetailMask = 4; 
	imageType = HChain2Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
};

ItemImageData HChaingunImage 
{ 
	shapeFile = "breath"; 
	mountPoint = 3; 
	weaponType = 1; 
	ammoType = gatlingammo; 
	reloadTime = 0;
	spinUpTime = 0.5;
	spinDownTime = 3;
	fireTime = 0.2;
	sfxFire = SoundFireChaingun; 
	sfxActivate = SoundPickUpWeapon; 
}; 

ItemData HChaingun
{ 
	description = "Dual Chaingun"; 
	className = "Weapon"; 
	shapeFile = "chaingun"; 
	hudIcon = "chain"; 
     heading = "bWeapons"; 
	shadowDetailMask = 4; 
	imageType = HChaingunImage; 
	price = 5000; 
	showWeaponBar = true;
	showInventory = false; 
}; 

function HChaingunImage::onFire(%player, %slot) 
{  
	%state1 = Player::getItemState(%player,4);  
	%state2 = Player::getItemState(%player,5);  
	if (%state1 != "Fire" && %state1 != "Reload" && %state2 != "Fire" && %state2 != "Reload") 
	{   
		%client = GameBase::getOwnerClient(%player);   
		Player::decItemCount(%player, "gatlingammo", 1);   
		%num = Player::getItemCount(%player, "gatlingammo");   
		if(%client.hd == 0) 
		{    
			%client.hd = 1;    
			if(%num == 1)     
			Player::setItemCount(%player, "gatlingammo", 0);    
			else     
			Player::setItemCount(%player, "gatlingammo", %num);    
			Player::trigger(%player,4,true);    
			Player::trigger(%player,4,false);   
		} 
		else 
		{    
			%client.hd = 0;    
			if(%num == 1)     
			Player::setItemCount(%player, "gatlingammo", 0);    
			else     
			Player::setItemCount(%player, "gatlingammo", %num);    
			Player::trigger(%player,5,true);    
			Player::trigger(%player,5,false);   
		}  
	} 
} 

function HChaingun::onMount(%player,%imageSlot) 
{  
	%num = Player::getItemCount(%player, "gatlingammo");  
	Player::setItemCount(%player, "gatlingammo", %num);  
	Player::mountItem(%player,HChain1,4);  
	Player::mountItem(%player,HChain2,5); 
} 

function HChaingun::onUnmount(%player,%imageSlot) 
{  
	Player::unmountItem(%player,4);  
	Player::unmountItem(%player,5); 
}

$InvList[HChaingun] = 1;
$RemoteInvList[HChaingun] = 1;

$InvList[gatlingammo] = 1;
$RemoteInvList[gatlingammo] = 1;

$ItemMax[transformer, HChaingun] = 1;
$ItemMax[gharmor, HChaingun] = 1;
$ItemMax[harmor, HChaingun] = 1;
$ItemMax[marmor, HChaingun] = 1;
$ItemMax[blastech, HChaingun] = 1;
$ItemMax[mfemale, HChaingun] = 1;
$ItemMax[blastechf, HChaingun] = 1;
$ItemMax[engineers, HChaingun] = 1;
$ItemMax[engineer, HChaingun] = 1;

$ItemMax[transformer, gatlingammo] = 450;
$ItemMax[gharmor, gatlingammo] = 500;
$ItemMax[harmor, gatlingammo] = 400;
$ItemMax[marmor, gatlingammo] = 350;
$ItemMax[blastech, gatlingammo] = 150;
$ItemMax[mfemale, gatlingammo] = 350;
$ItemMax[blastechf, gatlingammo] = 150;
$ItemMax[engineers, gatlingammo] = 200;
$ItemMax[engineer, gatlingammo] = 200;

//=============================================================
RocketData gPlasmaCannonShock2
{
	bulletShapeName  = "plasmaex.dts";
	explosionTag     = grenadeExp;
	collisionRadius  = 0.0;
	mass             = 0.0;
	damageClass      = 1;
	damageValue      = 1.0;
	damageType       = $PlasmaDamageType;
	explosionRadius  = 15.0;
	kickBackStrength = 0;
	muzzleVelocity   = 35.0;
	terminalVelocity = 65.0;
	acceleration     = 25.0;
	totalTime        = 5.0;
	liveTime         = 5.0;
	lightRange       = 5.0;
	lightColor       = { 1.0, 0.0, 0.0 };
	inheritedVelocityScale = 0.0;

	trailType   = 2;
	trailString = "plasmatrail.dts";
	smokeDist   = 160.0;
	soundId = SoundJetHeavy;
};


function gPlasmaCannonShock2Fire(%trans, %player, %vel, %client, %num)
{
	%fired = (Projectile::spawnProjectile(gPlasmaCannonShock2, %trans,%player,%vel));
	%fired.deployer = %client;

	if (%num == 0)
	{
		$Plasma[0] = %fired;
	}
	if (%num == 1)
	{
		%boom = $Plasma[0];
		$Plasma[%boom] = %fired;
	}
	
}

function gPlasmaCannonShock2::OnRemove(%this)
{
	//DeployFrags(%this, 10);
	schedule("NuclearExplosion(" @ %this @ ");",%this);
}

function gPlasmaCannonShock2::Blast(%this)
{
	DeployFrags(%this, 10);
}

MineData HavocBlast
{
	className = "Mine";
	description = "HavocBlast";
	shapeFile = "breath";
	shadowDetailMask = 4;
	explosionId = ShockwaveThree;
	explosionRadius = 20.0;
	damageValue = 2.0;
	damageType = $MortarDamageType;
	kickBackStrength = 0.1;
	triggerRadius = 2.5;
	maxDamage = 0.5;
	shadowDetailMask = 0;
	destroyDamage = 1.0;
	damageLevel = {1.0, 1.0};
};

function HavocBlast::onAdd(%this)
{
    	schedule("Mine::Detonate(" @ %this @ ");",0.1,%this);	
}

//==================================================================================================== Napalm Frags

MineData Frag1
{
   	mass = 5.0;
   	drag = 0.5;
   	density = 2.0;
	elasticity = 0.15;
	friction = 0.5;
	className = "Handgrenade";
	description = "Bomblet";
	shapeFile = "plasmabolt";
	shadowDetailMask = 4;
	explosionId = plasmaExp;
	explosionRadius = 20.0;
	damageValue = 0.4;
	damageType = $PlasmaDamageType;
	kickBackStrength = 300;
	triggerRadius = 0.5;
	maxDamage = 1.5;
};

function Frag1::onAdd(%this)
{
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

MineData Frag2
{
   	mass = 5.0;
   	drag = 0.5;
   	density = 2.0;
	elasticity = 0.35;
	friction = 1.0;
	className = "Handgrenade";
	description = "Bomblet";
	shapeFile = "plasmabolt";
	shadowDetailMask = 4;
	explosionId = plasmaExp;
	explosionRadius = 20.0;
	damageValue = 0.4;
	damageType = $PlasmaDamageType;
	kickBackStrength = 300;
	triggerRadius = 0.5;
	maxDamage = 1.5;
};

function Frag2::onAdd(%this)
{
	schedule("Mine::Detonate(" @ %this @ ");",2.25,%this);
}

MineData Frag3
{
   	mass = 5.0;
   	drag = 0.1;
   	density = 2.0;
	elasticity = 0.25;
	friction = 1.5;
	className = "Handgrenade";
	description = "Bomblet";
	shapeFile = "plasmabolt";
	shadowDetailMask = 4;
	explosionId = plasmaExp;
	explosionRadius = 20.0;
	damageValue = 0.4;
	damageType = $PlasmaDamageType;
	kickBackStrength = 300;
	triggerRadius = 0.5;
	maxDamage = 1.5;
};

function Frag3::onAdd(%this)
{
	schedule("Mine::Detonate(" @ %this @ ");",2.5,%this);
}

function DeployFrags(%this, %count) 
{
	%pos = gamebase::getposition(%this);
	
	%team = GameBase::getTeam(%player);

	for (%i = 0; %i < %count; %i++)
	{
		%frag = "Frag" @ (floor(getRandom()*3)+1);
		%obj = newObject("","Mine", %frag);
		%obj.deployer = %cl;

		if ((floor(getRandom()*4)+1) > 2)
		{
			%dir = 120;			
			GameBase::throw(%obj,%cl,%dir,true);
		}
		else
		{
			%dir = 60;
			GameBase::throw(%obj,%cl,%dir,true);
		}

		addToSet("MissionCleanup", %obj);
		
		GameBase::setPosition(%obj, %pos);
	}

}