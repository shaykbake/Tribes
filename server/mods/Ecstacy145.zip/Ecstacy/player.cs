$PlayerAnim::Crouching = 25;
$PlayerAnim::DieChest = 26;
$PlayerAnim::DieHead = 27;
$PlayerAnim::DieGrabBack = 28;
$PlayerAnim::DieRightSide = 29;
$PlayerAnim::DieLeftSide = 30;
$PlayerAnim::DieLegLeft = 31;
$PlayerAnim::DieLegRight = 32;
$PlayerAnim::DieBlownBack = 33;
$PlayerAnim::DieSpin = 34;
$PlayerAnim::DieForward = 35;
$PlayerAnim::DieForwardKneel = 36;
$PlayerAnim::DieBack = 37;

//----------------------------------------------------------------------------
$CorpseTimeoutValue = 22;
//----------------------------------------------------------------------------

// Player & Armor data block callbacks

function Player::onAdd(%this)
{
	GameBase::setRechargeRate(%this,8);
}

function Player::onRemove(%this)
{
	// Drop anything left at the players pos
	for (%i = 0; %i < 8; %i = %i + 1) {
		%type = Player::getMountedItem(%this,%i);
		if (%type != -1) {
			// Note: Player::dropItem ius not called here.
			%item = newObject("","Item",%type,1,false);
         schedule("Item::Pop(" @ %item @ ");", $ItemPopTime, %item);

         addToSet("MissionCleanup", %item);
			GameBase::setPosition(%item,GameBase::getPosition(%this));
		}
	}
}

function Player::onNoAmmo(%player,%imageSlot,%itemType)
{
	//echo("No ammo for weapon ",%itemType.description," slot(",%imageSlot,")");
}

function Player::onKilled(%this)
{
	%cl = GameBase::getOwnerClient(%this);
	$TeleUsed[%this] = false;
   	$empTime[%cl] = 0;
	%cl.dead = 1;
	if($AutoRespawn > 0)
		schedule("Game::autoRespawn(" @ %cl @ ");",$AutoRespawn,%cl);
	if(%this.outArea==1)	
		leaveMissionAreaDamage(%cl);
	Player::setDamageFlash(%this,0.75);
	for (%i = 0; %i < 8; %i = %i + 1) {
		%type = Player::getMountedItem(%this,%i);
		if (%type != -1) {
			if (%i != $WeaponSlot || !Player::isTriggered(%this,%i) || getRandom() > "0.5") 
				Player::dropItem(%this,%type);
		}
	}

   if(%cl != -1)
   {
		if(%this.vehicle != "")
		{
			if(%this.driver != "")
			{
				%this.driver = "";
        	 		Client::setControlObject(Player::getClient(%this), %this);
	        	 	Player::setMountObject(%this, -1, 0);
			}
			else
			{
				%this.vehicle.Seat[%this.vehicleSlot-2] = "";
				%this.vehicleSlot = "";
			}
			if(GameBase::getDataName(%this.vehicle) == JetfireVehicle || GameBase::getDataName(%this.vehicle) == Jetfire)
				GameBase::setDamageLevel(%this.vehicle, GameBase::getDataName(%this.vehicle).maxDamage);
			%this.vehicle = "";		
		}
      schedule("GameBase::startFadeOut(" @ %this @ ");", $CorpseTimeoutValue, %this);
      Client::setOwnedObject(%cl, -1);
      Client::setControlObject(%cl, Client::getObserverCamera(%cl));
      Observer::setOrbitObject(%cl, %this, 5, 5, 5);
      schedule("deleteObject(" @ %this @ ");", $CorpseTimeoutValue + 2.5, %this);
      %cl.observerMode = "dead";
      %cl.dieTime = getSimTime();
   }
}

function Player::onDamage(%this,%type,%value,%pos,%vec,%mom,%vertPos,%quadrant,%object)
{
	if (Player::isExposed(%this)) {
      %damagedClient = Player::getClient(%this);
      %shooterClient = %object;

		Player::applyImpulse(%this,%mom);
		if($teamplay && %damagedClient != %shooterClient && Client::getTeam(%damagedClient) == Client::getTeam(%shooterClient) ) {
			if (%shooterClient != -1) {
				%curTime = getSimTime();
			   if ((%curTime - %this.DamageTime > 3.5 || %this.LastHarm != %shooterClient) && %damagedClient != %shooterClient && $Server::TeamDamageScale > 0) {
					if(%type != $MineDamageType) {
						Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ "!");
						Client::sendMessage(%damagedClient,0,"You took Friendly Fire from " @ Client::getName(%shooterClient) @ "!");
					}
					else {
						Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ " with your mine!");
						Client::sendMessage(%damagedClient,0,"You just stepped on Teamate " @ Client::getName(%shooterClient) @ "'s mine!");
					}
					%this.LastHarm = %shooterClient;
					%this.DamageStamp = %curTime;
				}
			}
			%friendFire = $Server::TeamDamageScale;
		}
		else if(%type == $ImpactDamageType && Client::getTeam(%object.clLastMount) == Client::getTeam(%damagedClient)) 
			%friendFire = $Server::TeamDamageScale;
		else  
			%friendFire = 1.0;	

		if (!Player::isDead(%this)) {
			%armor = Player::getArmor(%this);
			//More damage applyed to head shots
			if(%vertPos == "head" && %type == $LaserDamageType) {
				if(%armor == "harmor") { 
					if(%quadrant == "middle_back" || %quadrant == "middle_front" || %quadrant == "middle_middle") {
						%value += (%value * 0.3);
					}
				}
				else {
					%value += (%value * 0.3);
				}
			}
			//If Shield Pack is on
			if (%type != -1 && %this.shieldStrength) {
				%energy = GameBase::getEnergy(%this);
				%strength = %this.shieldStrength;
				if (%type == $ShrapnelDamageType || %type == $MortarDamageType)
					%strength *= 0.75;
				// Added Code to Modify Damage From Magnetic Damage - *IX*Savage1
				if (%type == $MagneticDamageType)
					%value = 0.005;
				%absorb = %energy * %strength;
				if (%value < %absorb) {
					GameBase::setEnergy(%this,%energy - ((%value / %strength)*%friendFire));
					%thisPos = getBoxCenter(%this);
					%offsetZ =((getWord(%pos,2))-(getWord(%thisPos,2)));
					GameBase::activateShield(%this,%vec,%offsetZ);
					%value = 0;
				}
				else {
					GameBase::setEnergy(%this,0);
					%value = %value - %absorb;
				}
			}
			// Added EMP Effect Damage. - *IX*Savage1
			%armor = Player::getArmor(%this);
			if ((%armor == "gharmor") && (!%this.shieldStrength))
			Gundam_emergencyshield(%damagedClient, %this);

			else if (%type == $EMPDamageType) 
				Insomniax_startEMP(%damagedClient, %this);
			else if ((%type == $MethaneDamageType) && (Client::getTeam(%damagedClient) != Client::getTeam(%shooterClient) ) )
			{
				%armor = Player::getArmor(%this);
				if ((%armor != "aarmor") && (%armor != "afemale"))
					Poisoned(%damagedClient, %this);
			else if ((%type == $ImpactDamageType) && (Client::getTeam(%damagedClient) != Client::getTeam(%shooterClient) ) )
			{
				%armor = Player::getArmor(%this);
				if ((%armor != "aarmor") && (%armor != "afemale"))
					startSmall(%damagedClient, %this);
			}
			else if (((%type == $MortarDamageType) || (%type == $NukeDamageType)) && (Client::getTeam(%damagedClient) != Client::getTeam(%shooterClient)))
			{
				%rnd = floor(getRandom() * 10);
				if(%rnd > 7)
				{
					%armor = Player::getArmor(%this);
					if ( (%armor != "barmor") && (%armor != "bfemale"))
						startBig(%damagedClient, %this);
				}
			}

			}

			else if (((%type == $PlasmaDamageType) || (%type == $ReaverDamageType) || (%type == $FlamerDamageType) || (%type == $HeatDamageType)) && (Client::getTeam(%damagedClient) != Client::getTeam(%shooterClient)))
			{
				%rnd = floor(getRandom() * 10);
				if(%rnd > 7)
				{
					%armor = Player::getArmor(%this);
					if ( (%armor != "barmor") && (%armor != "bfemale"))
						BurnTheFlesh(%damagedClient, %this);
				}
			}

  			if (%value) {
				// Added Sniper Shooting Weapon out of Hand - *IX*Savage1
				%armor = Player::getArmor(%this);
				%hitdamageval = 0.05;
				if(%armor == "harmor")
					%hittolerance = 0.25;
				else
					%hittolerance = 0.41;

				%weaponType = Player::getMountedItem(%this,$WeaponSlot);
				if ((%vertPos == "torso") && (%quadrant == "front_right") && (%type == $LaserDamageType) && (%value > %hittolerance) && (%weaponType != -1 && %weaponType != "RepairGun"))
				{
					Player::dropItem(%this,%weaponType);
	       		   	%dlevel = GameBase::getDamageLevel(%this) + %hitdamageval;
					messageall(0, Client::getName(%shooterClient) @ " sniped the " @ %weaponType @ " out of " @ Client::getName(%damagedClient) @ "'s Hand!");
				}
				else
				{
					%value = $DamageScale[%armor, %type] * %value * %friendFire;
		        	   	%dlevel = GameBase::getDamageLevel(%this) + %value;
				}
            		%spillOver = %dlevel - %armor.maxDamage;
            			if (%spillOver >= 0)
            			{
            				//$died[%damagedclient]=1;
            				%player = Client::getOwnedObject(%damagedclient);
            				if (%armor = "hlarmor" || %armor ="hlfemale") GameBase::setAutoRepairRate(%player, 0);
            				%pack = Player::getMountedItem(%damagedclient,$BackpackSlot);
            				if (%pack == "Slipstream")
            				{
            					$TeleUsed[%player] = false;
            				}
            			}

				GameBase::setDamageLevel(%this,%dlevel);
				%flash = Player::getDamageFlash(%this) + %value * 2;
				if (%flash > 0.75) 
					%flash = 0.75;
				Player::setDamageFlash(%this,%flash);
				//If player not dead then play a random hurt sound
				if(!Player::isDead(%this)) { 
					if(%damagedClient.lastDamage < getSimTime()) {
						%sound = radnomItems(3,injure1,injure2,injure3);
						playVoice(%damagedClient,%sound);
						%damagedClient.lastdamage = getSimTime() + 1.5;
					}
				}
				else 
				{
           	if((%spillOver > 0.5 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType || %type == $BurstDamageType || %type == $LaserDamageType || %type == $RPGDamageType || %type == $RPMDamageType || %type == $ReaverDamageType || %type == $EMPDamageType || %type == $SonicDamageType || %type == $MineDamageType || %type == $IonDamageType || %type == $NukeDamageType || %type == $ATCDamageType || %type == $StarDamageType || %type == $ShockwaveDamageType || %type == $PBWDamageType || %type == $FusionDamageType || %type == $DisruptorDamageType || %type == $MissileDamageType || %type == $DistortionDamageType)) || %type == $MagneticDamageType)
					{
						Player::trigger(%this, $WeaponSlot, false);
						%weaponType = Player::getMountedItem(%this,$WeaponSlot);
						if(%weaponType != -1)
							Player::dropItem(%this,%weaponType);
						if (%type == $MagneticDamageType) 
							playSound(ShockExplosion,GameBase::getPosition(%this));
					   	Player::blowUp(%this);
					}
					else
					{
						if ((%value > 0.40 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType || %type == $BurstDamageType || %type == $LaserDamageType || %type == $RPGDamageType || %type == $RPMDamageType || %type == $ReaverDamageType || %type == $EMPDamageType || %type == $SonicDamageType || %type == $MineDamageType || %type == $IonDamageType || %type == $NukeDamageType || %type == $ATCDamageType || %type == $StarDamageType || %type == $ShockwaveDamageType || %type == $PBWDamageType || %type == $FusionDamageType || %type == $DisruptorDamageType || %type == $MissileDamageType || %type == $DistortionDamageType)) || (Player::getLastContactCount(%this) > 6) ) {
					  		if(%quadrant == "front_left" || %quadrant == "front_right") 
								%curDie = $PlayerAnim::DieBlownBack;
							else
								%curDie = $PlayerAnim::DieForward;
						}
						else if( Player::isCrouching(%this) ) 
							%curDie = $PlayerAnim::Crouching;							
						else if(%vertPos=="head") {
							if(%quadrant == "front_left" ||	%quadrant == "front_right"	) 
								%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieBack);
						  	else 
								%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieForward);
						}
						else if (%vertPos == "torso") {
							if(%quadrant == "front_left" ) 
								%curDie = radnomItems(3, $PlayerAnim::DieLeftSide, $PlayerAnim::DieChest, $PlayerAnim::DieForwardKneel);
							else if(%quadrant == "front_right") 
								%curDie = radnomItems(3, $PlayerAnim::DieChest, $PlayerAnim::DieRightSide, $PlayerAnim::DieSpin);
							else if(%quadrant == "back_left" ) 
								%curDie = radnomItems(4, $PlayerAnim::DieLeftSide, $PlayerAnim::DieGrabBack, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
							else if(%quadrant == "back_right") 
								%curDie = radnomItems(4, $PlayerAnim::DieGrabBack, $PlayerAnim::DieRightSide, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
						}
						else if (%vertPos == "legs") {
							if(%quadrant == "front_left" ||	%quadrant == "back_left") 
								%curDie = $PlayerAnim::DieLegLeft;
							if(%quadrant == "front_right" ||	%quadrant == "back_right") 
								%curDie = $PlayerAnim::DieLegRight;
						}
						Player::setAnimation(%this, %curDie);
					}
					if(%type == $ImpactDamageType && %object.clLastMount != "")  
						%shooterClient = %object.clLastMount;
					Client::onKilled(%damagedClient,%shooterClient, %type);
				}
			}
		}
	}
}

function radnomItems(%num, %an0, %an1, %an2, %an3, %an4, %an5, %an6)
{
	return %an[floor(getRandom() * (%num - 0.01))];
}

function Player::onCollision(%this,%object)
{
	if (Player::isDead(%this)) {
		if (getObjectType(%object) == "Player") {
			// Transfer all our items to the player
			%sound = false;
			%max = getNumItems();
			for (%i = 0; %i < %max; %i = %i + 1) {
				%count = Player::getItemCount(%this,%i);
				if (%count) {
					%delta = Item::giveItem(%object,getItemData(%i),%count);
					if (%delta > 0) {
						Player::decItemCount(%this,%i,%delta);
						%sound = true;
					}
				}
			}
			if (%sound) {
				// Play pickup if we gave him anything
				playSound(SoundPickupItem,GameBase::getPosition(%this));
			}
		}
	}
}

function Player::getHeatFactor(%this)
{
	// Hack to avoid turret turret not tracking vehicles.
	// Assumes that if we are not in the player we are
	// controlling a vechicle, which is not always correct
	// but should be OK for now.
	%client = Player::getClient(%this);
	if (Client::getControlObject(%client) != %this)
		return 1.0;

   %time = getIntegerTime(true) >> 5;
   %lastTime = Player::lastJetTime(%this) >> 10;

   if ((%lastTime + 1.5) < %time) {
      return 0.0;
   } else {
      %diff = %time - %lastTime;
      %heat = 1.0 - (%diff / 1.5);
      return %heat;
   }
}

function Player::jump(%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   if(%cl != -1)
   {
      %vehicle = Player::getMountObject (%this);
		%this.lastMount = %vehicle;
		%this.newMountTime = getSimTime() + 3.0;
		Player::setMountObject(%this, %vehicle, 0);
		Player::setMountObject(%this, -1, 0);
		Player::applyImpulse(%pl,%mom);
		playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
   }
}


//----------------------------------------------------------------------------

function remoteKill(%client)
{
   if(!$matchStarted)
      return;

   %player = Client::getOwnedObject(%client);
   $TeleUsed[%player] = false;
   $empTime[%client] = 0;

   if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
   {
		playNextAnim(%client);
	   Player::kill(%client);
	   Client::onKilled(%client,%client);
   }
}

$animNumber = 25;	 
function playNextAnim(%client)
{
	if($animNumber > 36) 
		$animNumber = 25;		
	Player::setAnimation(%client,$animNumber++);
}

function Client::takeControl(%clientId, %objectId)
{
   // remote control
   if(%objectId == -1)
   {
      //echo("objectId = " @ %objectId);
      return;
   }
   if(GameBase::getTeam(%objectId) != Client::getTeam(%clientId))
   {
      //echo(GameBase::getTeam(%objectId) @ " " @ Client::getTeam(%clientId));
      return;
   }
   if(GameBase::getControlClient(%objectId) != -1)
   {
      echo("Ctrl Client = " @ GameBase::getControlClient(%objectId));
      return;
   }
	%name = GameBase::getDataName(%objectId);
	// Add Controllable Deployables - *IX*Savage1
	if(
	%name != CameraTurret &&
	%name != Gunboy && 
	%name != SniperTurret &&  
	%name != DeployableTurret && 
	%name != AntiTurret && 
	%name != Scout &&
	%name != ScoutVehicle &&  
	%name != Android && 
	%name != DeployableLaser && 
	%name != FusionTurret && 
	%name != IonTurret && 
	%name != Turret2 && 
	%name != Turret3 && 
	%name != DisruptorTurret && 
	%name != ELFTurret && 
	%name != SPlasTurret && 
	%name != ElectroTurret && 
	%name != PulseTurret && 
	%name != CannonTurret &&
	%name != DiscTurret &&  
      %name != FlamerTurret &&
      %name != RealObeliskOfLight &&
      %name != LaserTurret &&
      %name != DeployableELF &&
      %name != DeployableRocket &&
      %name != DeployableSentry &&
      %name != MortarTurret &&
      %name != AATurret &&
      %name != FluxTurret &&
      %name != DeployableCoolMortar &&
      %name != Sentry 
){
	   if(!GameBase::isPowered(%objectId)) 
		{
	      echo(%objectId @ " is not powered.");
	      return;
		}
   }
   // Added PDA Controllable Turrets - Mega Man 1024
        if (!(Client::getOwnedObject(%clientId)).CommandTag && 
	GameBase::getDataName(%objectId) != CameraTurret && 
	GameBase::getDataName(%objectId) != Gunboy && 
	GameBase::getDataName(%objectId) != SniperTurret && 
	GameBase::getDataName(%objectId) != Android && 
	GameBase::getDataName(%objectId) != AntiTurret &&
	GameBase::getDataName(%objectId) != EPodVehicle &&
	GameBase::getDataName(%objectId) != Scout && 
	GameBase::getDataName(%objectId) != ScoutVehicle && 
	GameBase::getDataName(%objectId) != DeployableTurret && 
	GameBase::getDataName(%objectId) != DeployableLaser &&
	GameBase::getDataName(%objectId) != FusionTurret && 
	GameBase::getDataName(%objectId) != IonTurret &&
	GameBase::getDataName(%objectId) != Turret2 &&
	GameBase::getDataName(%objectId) != DiscTurret &&
	GameBase::getDataName(%objectId) != Turret3 &&
	GameBase::getDataName(%objectId) != DisruptorTurret &&
	GameBase::getDataName(%objectId) != FlamerTurret &&
	GameBase::getDataName(%objectId) != SPlasTurret &&
	GameBase::getDataName(%objectId) != PulseTurret &&
	GameBase::getDataName(%objectId) != ElectroTurret &&
	GameBase::getDataName(%objectId) != ELFTurret &&
	GameBase::getDataName(%objectId) != CannonTurret &&
	GameBase::getDataName(%objectId) != RealObeliskOfLight &&
	GameBase::getDataName(%objectId) != LaserTurret &&
	GameBase::getDataName(%objectId) != DeployableRocket &&
	GameBase::getDataName(%objectId) != Sentry &&
	GameBase::getDataName(%objectId) != DeployableSentry &&
	GameBase::getDataName(%objectId) != MortarTurret &&
	GameBase::getDataName(%objectId) != DeployableELF &&
	GameBase::getDataName(%objectId) != FluxTurret &&
	GameBase::getDataName(%objectId) != AATurret &&
	GameBase::getDataName(%objectId) != DeployabelCoolMortar &&
	!$TestCheats) {
		Client::SendMessage(%clientId,0,"You cannot control base turrets from your PDA!");
   		return;
   }
   if(GameBase::getDamageState(%objectId) == "Enabled") {
   	Client::setControlObject(%clientId, %objectId);
   	Client::setGuiMode(%clientId, $GuiModePlay);
	}
}

function remoteCmdrMountObject(%clientId, %objectIdx)
{
   Client::takeControl(%clientId, getObjectByTargetIndex(%objectIdx));
}

function checkControlUnmount(%clientId)
{
   %ownedObject = Client::getOwnedObject(%clientId);
   %ctrlObject = Client::getControlObject(%clientId);
   if(%ownedObject != %ctrlObject)
   {
      if(%ownedObject == -1 || %ctrlObject == -1)
         return;
      if(getObjectType(%ownedObject) == "Player" && Player::getMountObject(%ownedObject) == %ctrlObject)
         return;
      Client::setControlObject(%clientId, %ownedObject);
   }
}

  			%armor = Player::getArmor(%this);
			if ((%armor == "gharmor") && (!%this.shieldStrength))
			Gundam_emergencyshield(%damagedClient, %this);

//========================================================================================================================================
//==================================================== Collisions With Players ===========================================================
//========================================================================================================================================

function Player::onCollision(%this,%object)
{
	if (Player::isDead(%this))
	{
		if (getObjectType(%object) == "Player")
		{
			%sound = false;
			%max = getNumItems();
			
			for (%i = 0; %i < %max; %i = %i + 1)
			{
				%count = Player::getItemCount(%this,%i);
				if (%count)
				{
					%delta = Item::giveItem(%object,getItemData(%i),%count);
					if (%delta > 0)
					{
						Player::decItemCount(%this,%i,%delta);
						%sound = true;
					}
				}
			}
			if (%sound)
			{
				playSound(SoundPickupItem,GameBase::getPosition(%this));
			}
		}
	}
	if (getObjectType(%object) == "Player") 
		{
			if (Player::isDead(%object))
			{
				return;
			}
				if (Player::isDead(%this))
				{
					return;
				}

				if(GameBase::getTeam(%object) == GameBase::getTeam(%this))
				{
					%armor = Player::getArmor(%object);
					if (%armor == "engineer" || %armor == "engineers")
			      	{
						if(GameBase::getDamageLevel(%this)) 
						{
							GameBase::repairDamage(%this,1.10);
				      	}
					}		
				}	
			}
}

function Poisoned(%clientId, %player)
{
	Client::sendMessage(%clientId,1, "You've been hit by a poison dart!");
	if($poisonTime[%clientId] == 0)
	{
		
		Player::setDamageFlash(%player,0.95);
		$poisonTime[%clientId] = 15;
		checkPlayerBlind(%clientId, %player);
	}
	else
		$poisonTime[%clientId] = 15;
}


function checkPlayerBlind(%clientId, %player)
{
	
	if($poisonTime[%clientId] > 0)
	{
		$poisonTime[%clientId] -= 2;  
		%drrate = GameBase::getDamageLevel(%player) + 0.5;
			if  (!Player::isDead(%player)) 
			{
				GameBase::setDamageLevel(%player, %drrate);  
				Player::setDamageFlash(%player,0.75);  
				if  (Player::isDead(%player))
				{
					messageall(0, Client::getName(%clientId) @ " died from a poison injection.");
					%clientId.scoreDeaths++;
		      		%clientId.score--;
					Game::refreshClientScore(%clientId);
					$poisonTime[%clientId] = 0;
				}

		}
		else
		{
		
		$poisonTime[%clientId] = 0;
		}
		

		schedule("checkPlayerBlind(" @ %clientId @ ", " @ %player @ ");",5,%player);
      }
	else
	{
		Client::sendMessage(%clientId,1,"The poison subsides.");		
	}			

		
}

function Gundam_emergencyshield(%clientId, %player)
{
	GameBase::playSound(%player,ForceFieldOpen,0);
	%armor = Player::getArmor(%player);

	if (%armor == "gharmor")
		%player.shieldStrength = 0.006;
	else
		%player.shieldStrength = 0.003;

	if($shieldTime[%clientId] == 0)
	{
		$shieldTime[%clientId] = 2.5;
		checkPlayerShield(%clientId, %player);
	}
	else
		$shieldTime[%clientId] = 2.5;
}


function checkPlayerShield(%clientId, %player)
{
	%armor = Player::getArmor(%player);
	if($shieldTime[%clientId] > 0)
	{
		$shieldTime[%clientId] -= 2;  

		if  ((!Player::isDead(%player)) && (%armor == "harmor" || %armor == "transformer" || %armor == "gharmor"))
		{
			if  (Player::isDead(%player))
			{
			}
		}
		else
		{
			$shieldTime[%clientId] = 0;
		}
		

		schedule("checkPlayerShield(" @ %clientId @ ", " @ %player @ ");",2,%player);
    	}
	else
	{
		%player.shieldStrength = 0;
		GameBase::playSound(%player,ForceFieldClose,0);	
	}			

		
}

//============================================================================= Flamer Burn

function BurnTheFlesh(%clientId, %player)
{
	Client::sendMessage(%clientId,1,"You're on fire!");
	if($burnTime[%clientId] == 0)
	{
		
		Player::setDamageFlash(%player,0.50);
		$burnTime[%clientId] = 5;
		checkPlayerBurn(%clientId, %player);
	}
	else
		$burnTime[%clientId] = 5;
}


function checkPlayerBurn(%clientId, %player)
{
	
if($burnTime[%clientId] > 0)
	{
		$burnTime[%clientId] -= 5;  
		%drrate = GameBase::getDamageLevel(%player) + 0.1;
		if  (!Player::isDead(%player)) 
		{
		GameBase::setDamageLevel(%player, %drrate);  
		Player::setDamageFlash(%player,0.50);  
			if  (Player::isDead(%player))
			{
				messageall(0, Client::getName(%clientId) @ " was burned to death.");
				%clientId.scoreDeaths++;
      			%clientId.score--;
				Game::refreshClientScore(%clientId);
				$burnTime[%clientId] = 0;
			}

		}
		else
		{
			$burnTime[%clientId] = 0;
		}
		

		schedule("checkPlayerBurn(" @ %clientId @ ", " @ %player @ ");",1,%player);
      }
	else
	{
		Client::sendMessage(%clientId,1,"Your internal extinguishers put out the fire.");
		
	}			

		
}

//============================================================================= Radio Active Material

function startSmall(%clientId, %player) { Client::sendMessage(%clientId,1,"You have been hit with radio active material.. and you feel ill!"); if($RATime[%clientId] == 0) { Player::setDamageFlash(%player,5.75); $RATime[%clientId] = 30; checkPlayerSmall(%clientId, %player); } else $RATime[%clientId] = 30; } 

function checkPlayerSmall(%clientId, %player) { if($RATime[%clientId] > 5) { $RATime[%clientId] -= 2; %drrate = GameBase::getDamageLevel(%player) + 0.07; if (!Player::isDead(%player)) { GameBase::setDamageLevel(%player, %drrate); Player::setDamageFlash(%player,5.75); if (Player::isDead(%player)) { messageall(0, Client::getName(%clientId) @ " body did not overcome the radio active material."); %clientId.scoreDeaths++; %clientId.score--; Game::refreshClientScore(%clientId); $RATime[%clientId] = 0; } } else { $RATime[%clientId] = 0; } schedule("checkPlayerSmall(" @ %clientId @ ", " @ %player @ ");",5,%player); } else { Client::sendMessage(%clientId,1,"You have overcome the radio active material."); } } 

//============================================================================= Y2K Virus

function startBig(%clientId, %player) { Client::sendMessage(%clientId,3,"Uh-Oh!!!! You have caught the Y2K virus!"); if($y2kTime[%clientId] == 0) { Player::setDamageFlash(%player,0.75); $y2kTime[%clientId] = 30; checkPlayerBig(%clientId, %player); } else $y2kTime[%clientId] = 30; } 

function checkPlayerBig(%clientId, %player) { if($y2kTime[%clientId] > 5) { $y2kTime[%clientId] -= 2; %drrate = GameBase::getDamageLevel(%player) + 0.12; if (!Player::isDead(%player)) { GameBase::setDamageLevel(%player, %drrate); Player::setDamageFlash(%player,0.75); if (Player::isDead(%player)) { messageall(0, Client::getName(%clientId) @ " was not Y2K complient."); %clientId.scoreDeaths++; %clientId.score--; Game::refreshClientScore(%clientId); $y2kTime[%clientId] = 0; } } else { $y2kTime[%clientId] = 0; } schedule("checkPlayerBig(" @ %clientId @ ", " @ %player @ ");",5,%player); } else { Client::sendMessage(%clientId,3,"You have Y2K virus out of your system....for now at least."); } } 

//============================================================================= Flag Shot Off

function DoTheFlagDrop(%player, %shooterId) 
{
   %playerTeam = GameBase::getTeam(%player);
   %flag = %player.carryFlag;
   %flagTeam = GameBase::getTeam(%flag);
   %playerClient = Player::getClient(%player);
   %dropClientName = Client::getName(%playerClient);
   %shooterName = Client::getName(%shooterId);

   if(%flagTeam == -1)
   {
      MessageAllExcept(%playerClient, 1, %shooterName @ " sniped " @ %flag.objectiveName @ " off of " @ %dropClientName @ "'s back!");
      Client::sendMessage(%playerClient, 1, %shooterName @ " sniped " @ %flag.objectiveName @ " off of your back!");
   }
   else
   {
		MessageAllExcept(%playerClient, 0, %shooterName @ " sniped the " @ getTeamName(%flagTeam) @ " flag off of " @ %dropClientName @ "'s back!");
        Client::sendMessage(%playerClient, 0, %shooterName @ " sniped the " @ getTeamName(%flagTeam) @ " flag off of your back!");
        TeamMessages(1, %flagTeam, "Your flag was dropped in the field.", -2, "", "The " @ getTeamName(%flagTeam) @ " flag was dropped in the field.");
   }
   GameBase::throw(%flag, %player, -15, false);
   Item::hide(%flag, false);
   Player::setItemCount(%player, "Flag", 0);
   %flag.carrier = -1;
   %player.carryFlag = "";
   Flag::clearWaypoint(%playerClient, false);

	schedule("Flag::checkReturn(" @ %flag @ ", " @ %flag.pickupSequence @ ");", $flagReturnTime);
	%flag.dropFade = 1;
	ObjectiveMission::ObjectiveChanged(%flag);
}
