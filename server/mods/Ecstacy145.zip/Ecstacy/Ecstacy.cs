//Makes you wonder doesn't it..........
//THIS IS NOT A SHIFTER, RENEGADES, INSOMNIAX OR ANY OTHER MOD COPY 
//This mod is based off of the Insomniax Anti-TK patch. It also uses parts from AAOD
//
// Base Programming by Mega Man 1024

#Thanks, Valya[AAOD]!
$Server::HostName = "Mega Man 1024's Ecstacy " @ EcstacyBaseVersionShort @ "!";
$Server::Info = "Ecstacy Server Setup\nBetter Than ANY other mod out there\nAdmin: Mega Man 1024\nEmail: megaman1024@hotmail.com";
$Server::teamName0 = "N64";
$Server::teamName1 = "PS2";
$Server::teamName2 = "Dreamcast";
$Server::teamName3 = "Neo-Geo Pocket";
$Server::teamName4 = "Nintendo";
$Server::teamName5 = "Sony";
$Server::teamName6 = "Sega";
$Server::teamName7 = "SNK";

#Server startup variables
$EcstacyComment1 = "<Place Server Info here>";  //server in4
$Ecstacy::JoinMOTD = "Fire spawn and do something more....";

#Server Anti-TK settings
$Ecstacy::BanKickTime = "120";
$Ecstacy::LeaveAreaTime = "10";
$Ecstacy::PABan = "true";
$Ecstacy::PAKick = "true";
$Ecstacy::PAMission = "true";
$Ecstacy::PAModOptions = "true";
$Ecstacy::PAResetDefaults = "true";
$Ecstacy::PATeamChange = "true";
$Ecstacy::PATeamDamage = "true";
$Ecstacy::PATimelimit = "true";
$Ecstacy::PATourneyMode = "true";
$Ecstacy::tkClientLvl = "0";
$Ecstacy::tkLimit = "5";
$Ecstacy::tkMultiple = "3";
$Ecstacy::tkServerLvl = "3";

#Obsolete (Old Anti-TK)
$SHAntiTeamKillWarnKills = 2;
$SHAntiTeamKillBanTime = 600;
$SHAntiTeamKillMaxKills = 3;
$SHAntiTeamKillProximity = 50;

if($SHAntiTeamKillWarnKills == "")
	$SHAntiTeamKillWarnKills = 2;
if($SHAntiTeamKillBanTime == "")
	$SHAntiTeamKillBanTime = 600;
if($SHAntiTeamKillMaxKills == "")
	$SHAntiTeamKillMaxKills = 3;
if($SHAntiTeamKillProximity == "")
    $SHAntiTeamKillProximity = 50;
#End Obsolete 

// Team Energy settings

$DefaultTeamEnergy = "Infinite";
$MaxTeamEnergy = "Infinite";
$TeamEnergyCheat = 0;
$incTeamEnergy = 768;
$secTeamEnergy = 32;
$TeammateSpending = -4096;  //Set = to 0 if don't want the warning message
$WarnEnergyLow = 4096;	    //Set = to 0 if don't want the warning message
$InitialPlayerEnergy = 8192;

$TeamEnergy[-1] = $DefaultTeamEnergy; 
$TeamEnergy[0]  = $DefaultTeamEnergy; 
$TeamEnergy[1]  = $DefaultTeamEnergy; 
$TeamEnergy[2]  = $DefaultTeamEnergy; 
$TeamEnergy[3]  = $DefaultTeamEnergy; 
$TeamEnergy[4]  = $DefaultTeamEnergy; 
$TeamEnergy[5]  = $DefaultTeamEnergy; 
$TeamEnergy[6]  = $DefaultTeamEnergy; 				
$TeamEnergy[7]  = $DefaultTeamEnergy; 

#Spoonbots not included in this mod right now; maybe later.

//==========================================================================================================================================
// The following bot configurations should be used ONLY by admins who know what they are doing... This can seriously mess up the way the
// bots in Ecstacy work... Please make very sure of what you are doing before you alter any of these settings!!!
//==========================================================================================================================================

$EcstacyHasBots = "false"; // to disable bots type false. to enable type true. No Spoonobot functionality yet.

$Spoonbot::DebugMode = False;
$Spoonbot::AutoSpawn = True;			//== Automatic bot-spawning on
$Spoonbot::BotTree_Design = False;		//== Enables Bot tree design mode
$SpoonBot::BotTree_MaxAutoCalc = 10;		//== Threshhold after which auto route generation is disabled.
$Spoonbot::UserMenu = True;			//== Users may add/remove bots via menu
$Spoonbot::BotChat = True;			//== If the bot's chat messages annoy you, you can turn them off here.
$BotTree::DebugMode = False;
$Spoonbot::RespawnDelay = 10;		//== How many seconds until bots respawn after being killed?
$Spoonbot::IQ = 100;				//== The IQ controls the bot's overall skill, like targeting precision, speed, etc.
$Spoonbot::ThinkingInterval = 5;	//== Interval in sec between which bots will "reconsider" their situation
								 //== NOTE: RespawnDelay MUST be higher than ThinkingInterval
$Spoonbot::RetreatDamageLevel = 1.0;		//== Bots will retreat if damage exceeds this value. 0.0 means no damage, 1.0 means dead.
						//== To disable retreating, set to 1.0
$BotHUD::ToggleKey = "b";			//== CTRL + this key will open the BotHUD.
						
if($EcstacyHasBots == "true")
{
	$Spoonbot::Bot1Name = "Killer_Demo_Roam_Male";
	$Spoonbot::Bot1Team = 0;

	$Spoonbot::Bot2Name = "Mitzi_Demo_Roam_Female";
	$Spoonbot::Bot2Team = 1;

//	$Spoonbot::Bot3Name = "Sonic_Demo_Roam_Male";
//	$Spoonbot::Bot3Team = 1;

//	$Spoonbot::Bot4Name = "Tails_Sniper_Roam_Female";
//	$Spoonbot::Bot4Team = 1;

//	$Spoonbot::Bot5Name = "Samus_Guard_Female";
//	$Spoonbot::Bot5Team = 1;
}

$Spoonbot::SPOONBOTCSLOADED = True;   
//================================= The following weapons are for what the bot will use when the enemy is...
//================================= The Pack is the pack that the bot will have mounted.
//================================= All items listed here **MUST** be listed in the particular bots inventory below...

//=========================== Mortar Gear
$Spoonbot::MortarMArmor  = "harmor";
$Spoonbot::MortarFArmor  = "harmor";
$Spoonbot::MortarGear[0] = "mortar";		$Spoonbot::MortarAmmo[0] = "1";
$Spoonbot::MortarGear[1] = "mortarammo";		$Spoonbot::MortarAmmo[1] = "500";
$Spoonbot::MortarGear[2] = "RPMLauncher";		$Spoonbot::MortarAmmo[2] = "1";
$Spoonbot::MortarGear[3] = "RPMAmmo";		$Spoonbot::MortarAmmo[3] = "500";
$SpoonBot::MortarGear[4] = "PlasmaGun";		$Spoonbot::MortarAmmo[4] = "1";
$SpoonBot::MortarGear[5] = "plasmaammo";		$Spoonbot::MortarAmmo[5] = "500";
$Spoonbot::MortarGear[6] = "energypack";		$Spoonbot::MortarAmmo[6] = "1";
$Spoonbot::MortarGear[7] = "";

$Spoonbot::MortarClose = "PlasmaGun"; 
$Spoonbot::MortarLong  = "RPMLauncher";
$SpoonBot::MortarJet   = "mortar";
$Spoonbot::MortarPack  = "energypack";

//=========================== Guard Gear
$Spoonbot::GuardMArmor  = "gharmor";
$Spoonbot::GuardFArmor  = "gharmor";
$Spoonbot::GuardGear[0] = "RPMLauncher";		$Spoonbot::GuardAmmo[0] = "1";
$Spoonbot::GuardGear[1] = "RPMammo";		$Spoonbot::GuardAmmo[1] = "500";
$Spoonbot::GuardGear[2] = "VulcanCannon";		$Spoonbot::GuardAmmo[2] = "1";
$Spoonbot::GuardGear[3] = "vulcanammo";		$Spoonbot::GuardAmmo[3] = "50000";
$SpoonBot::GuardGear[4] = "DiscLauncher";		$Spoonbot::GuardAmmo[4] = "1";
$SpoonBot::GuardGear[5] = "discammo";		$Spoonbot::GuardAmmo[5] = "500";
$Spoonbot::GuardGear[6] = "energypack";		$Spoonbot::GuardAmmo[6] = "1";
$Spoonbot::GuardGear[7] = "";

$Spoonbot::GuardClose = "DiscLauncher"; 
$Spoonbot::GuardLong  = "RPMLauncher";
$SpoonBot::GuardJet   = "VulcanCannon";
$Spoonbot::GuardPack  = "energypack";

//=========================== Demo Gear
$SpoonBot::DemoMArmor  = "marmor";
$SpoonBot::DemoFArmor  = "mfemale";
$SpoonBot::DemoGear[0] = "PlasmaGun";		$Spoonbot::DemoAmmo[0] = "1";
$SpoonBot::DemoGear[1] = "plasmaammo";		$Spoonbot::DemoAmmo[1] = "500";
$SpoonBot::DemoGear[2] = "disclauncher";	$Spoonbot::DemoAmmo[2] = "1";
$SpoonBot::DemoGear[3] = "discammo";		$Spoonbot::DemoAmmo[3] = "500";
$SpoonBot::DemoGear[4] = "chaingun";		$Spoonbot::DemoAmmo[4] = "1";
$SpoonBot::DemoGear[5] = "bulletammo";		$Spoonbot::DemoAmmo[5] = "50000";
$SpoonBot::DemoGear[6] = "";

$Spoonbot::DemoClose = "Plasmagun";
$Spoonbot::DemoLong  = "disclauncher";
$SpoonBot::DemoJet   = "chaingun";
$Spoonbot::DemoPack  = "energypack";

//=========================== Medic Gear
$SpoonBot::MedicMArmor  = "marmor";
$SpoonBot::MedicFArmor  = "mfemale";
$SpoonBot::MedicGear[0] = "blaster";		$Spoonbot::MedicAmmo[0] = "1";
$SpoonBot::MedicGear[1] = "PlasmaGun";		$Spoonbot::MedicAmmo[1] = "1";
$SpoonBot::MedicGear[2] = "plasmaammo";		$Spoonbot::MedicAmmo[2] = "500";
$SpoonBot::MedicGear[3] = "disclauncher";	$Spoonbot::MedicAmmo[3] = "1";
$SpoonBot::MedicGear[4] = "discammo";		$Spoonbot::MedicAmmo[4] = "500";
$SpoonBot::MedicGear[5] = "repairkit";		$Spoonbot::MedicAmmo[5] = "1";
$SpoonBot::MedicGear[6] = "repairpack";		$Spoonbot::MedicAmmo[6] = "1";
$SpoonBot::MedicGear[7] = "";

$Spoonbot::MedicClose = "PlasmaGun";
$Spoonbot::MedicLong  = "disclauncher";
$SpoonBot::MedicJet   = "blaster";
$Spoonbot::MedicPack  = "repairpack";

//=========================== Miner Gear
$SpoonBot::MinerMArmor  = "larmor";
$SpoonBot::MinerFArmor  = "lfemale";
$SpoonBot::MinerGear[0] = "chaingun";		$Spoonbot::MinerAmmo[0] = "1";
$SpoonBot::MinerGear[1] = "PlasmaGun";		$Spoonbot::MinerAmmo[1] = "1";
$SpoonBot::MinerGear[2] = "plasmaammo";		$Spoonbot::MinerAmmo[2] = "500";
$SpoonBot::MinerGear[3] = "energypack";		$Spoonbot::MinerAmmo[3] = "1";
$SpoonBot::MinerGear[4] = "repairkit";		$Spoonbot::MinerAmmo[4] = "1";
$SpoonBot::MinerGear[5] = "bulletammo";		$Spoonbot::MinerAmmo[5] = "50000";
$SpoonBot::MinerGear[6] = "grenadelauncher";	$Spoonbot::MinerAmmo[6] = "1";
$SpoonBot::MinerGear[7] = "grenadeammo";	$Spoonbot::MinerAmmo[7] = "5000";
$SpoonBot::MinerGear[9] = "";

$Spoonbot::MinerClose = "PlasmaGun";
$Spoonbot::MinerLong  = "grenadelauncher";
$SpoonBot::MinerJet   = "chaingun";
$Spoonbot::MinerPack  = "energypack";

//=========================== Sniper Gear
$SpoonBot::SniperMArmor  = "larmor";
$SpoonBot::SniperFArmor  = "lfemale";
$SpoonBot::SniperGear[0] = "AAODSniperX";		$Spoonbot::SniperAmmo[0] = "1";
$SpoonBot::SniperGear[1] = "Rifle";	          $Spoonbot::SniperAmmo[1] = "1";
$SpoonBot::SniperGear[2] = "LaserRifle";	$Spoonbot::SniperAmmo[2] = "1";
$SpoonBot::SniperGear[3] = "energypack";	$Spoonbot::SniperAmmo[3] = "1";
$SpoonBot::SniperGear[4] = "shells";      $Spoonbot::SniperAmmo[4] = "500";

$Spoonbot::SniperClose = "Rifle";
$Spoonbot::SniperLong  = "AAODSniperX";
$SpoonBot::SniperJet   = "LaserRifle";
$Spoonbot::SniperPack  = "energypack";

//=========================== Painter Gear
$SpoonBot::PainterMArmor  = "larmor";
$SpoonBot::PainterFArmor  = "lfemale";
$SpoonBot::PainterGear[0] = "TargetingLaser";	$Spoonbot::PainterAmmo[0] = "1";
$SpoonBot::PainterGear[1] = "PlasmaGun";	$Spoonbot::PainterAmmo[1] = "1";
$SpoonBot::PainterGear[2] = "plasmaammo";	$Spoonbot::PainterAmmo[2] = "500";
$SpoonBot::PainterGear[3] = "disclauncher"; 	$Spoonbot::PainterAmmo[3] = "1";
$SpoonBot::PainterGear[4] = "discammo";		$Spoonbot::PainterAmmo[4] = "500";
$SpoonBot::PainterGear[5] = "";

$Spoonbot::PainterClose = "PlasmaGun";
$Spoonbot::PainterLong  = "TargetingLaser";
$SpoonBot::PainterJet   = "DiscLauncher";
$Spoonbot::PainterPack  = "energypack";

//=========================== Standard Gear -- Used if Bot has no preset name...
$SpoonBot::StandardMArmor  = "marmor";
$SpoonBot::StandardFArmor  = "mfemale";
$SpoonBot::StandardGear[0] = "energypack";		$Spoonbot::StandardAmmo[0] = "1";
$SpoonBot::StandardGear[1] = "PlasmaGun";		$Spoonbot::StandardAmmo[1] = "1";
$SpoonBot::StandardGear[2] = "plasmaammo";		$Spoonbot::StandardAmmo[2] = "500";
$SpoonBot::StandardGear[3] = "disclauncher";		$Spoonbot::StandardAmmo[3] = "1";
$SpoonBot::StandardGear[4] = "discammo";		$Spoonbot::StandardAmmo[4] = "500";
$SpoonBot::StandardGear[5] = "chaingun";		$Spoonbot::StandardAmmo[5] = "1";
$SpoonBot::StandardGear[6] = "bulletammo";		$Spoonbot::StandardAmmo[6] = "5000";
$SpoonBot::StandardGear[7] = "";

$Spoonbot::StandardClose = "PlasmaGun";
$Spoonbot::StandardLong  = "disclauncher";
$SpoonBot::StandardJet   = "chaingun";
$Spoonbot::StandardPack  = "energypack";
