exec("include.cs"); // Made it near copy-proof
$SensorNetworkEnabled = true;

$GuiModePlay = 1;
$GuiModeCommand = 2;
$GuiModeVictory = 3;
$GuiModeInventory = 4;
$GuiModeObjectives = 5;
$GuiModeLobby = 6;


//  Global Variables
//

//==================================================== Built Arbitor Tough
//==================================================== From Scratch
//==================================================== By Mega Man 1024

$EcstacyModName = "Tribes Ecstacy";
$EcstacyLogo = "Testing the limits of Tribal Theory";
$EcstacyJoke = "Hark! What mail from yonder Modem breaks?";
$EcstacyAdmin = "Mega Man 1024";
$EcstacyMainLicensed = "Mega Man 1024";
$EcstacyMadeFor = "Me";
$EcstacyAntiTK = true;
$Ecstacy::onUseEcstacyEngine = true;
$EcstacyBaseVersionLong = "Version 1.45";
$EcstacyBaseVersionShort = "v1.45";

//---------------------------------------------------------------------------------
// (Rate is sec's) Items respwan
//---------------------------------------------------------------------------------
$ItemRespawnTime = 30;

//---------------------------------------------------------------------------------
//Amount of Energy remote stations start out with
//---------------------------------------------------------------------------------
$RemoteAmmoEnergy = 15200; 
$RemoteInvEnergy = 9000;

//---------------------------------------------------------------------------------
// REMOTE TURRET
//---------------------------------------------------------------------------------
$MaxNumTurretsInBox = 5;     //Number of remote turrets allowed in the area
$TurretBoxMaxLength = 25;    //Define Max Length of the area
$TurretBoxMaxWidth =  25;    //Define Max Width of the area
$TurretBoxMaxHeight = 5;    //Define Max Height of the area

$TurretBoxMinLength = 5;	  //Define Min Length from another turret
$TurretBoxMinWidth =  5;	  //Define Min Width from another turret
$TurretBoxMinHeight = 5;    //Define Min Height from another turret

//---------------------------------------------------------------------------------
//	Object Types	
//---------------------------------------------------------------------------------
$SimTerrainObjectType    = 1 << 1;
$SimInteriorObjectType   = 1 << 2;
$SimPlayerObjectType     = 1 << 7;

$MineObjectType		    = 1 << 26;	
$MoveableObjectType	    = 1 << 22;
$VehicleObjectType	 	 = 1 << 29;  
$StaticObjectType			 = 1 << 23;	   
$ItemObjectType			 = 1 << 21;	  

//---------------------------------------------------------------------------------
// CHEATS
//---------------------------------------------------------------------------------
$ServerCheats = 0;
$TestCheats = 0;

//---------------------------------------------------------------------------------
//Respawn automatically after X sec's -  If 0..no respawn
//---------------------------------------------------------------------------------
$AutoRespawn = 0;

//---------------------------------------------------------------------------------
// Player death messages - %1 = killer's name, %2 = victim's name
//       %3 = killer's gender pronoun (his/her), %4 = victim's gender pronoun
//---------------------------------------------------------------------------------
// Added Damage Type Death Messages - *IX*Savage1
// Added more kill yourself messages - Mega Man 1024

$deathMsg[$LandingDamageType, 0]      = "%2 falls to %3 death.";
$deathMsg[$LandingDamageType, 1]      = "%2 forgot to tie %3 bungie cord.";
$deathMsg[$LandingDamageType, 2]      = "%2 bites the dust in a forceful manner.";
$deathMsg[$LandingDamageType, 3]      = "%2 fall down go boom.";
$deathMsg[$LandingDamageType, 4] = "%2 left a small crater.";
$deathMsg[$LandingDamageType, 5] = "%2's corpse made a good throne rug.";
$deathMsg[$LandingDamageType, 6] = "%2 went from human to pancake in 0.2 seconds.";
$deathMsg[$LandingDamageType, 7] = "%2 died a painful death.";
$deathMsg[$LandingDamageType, 8] = "%2 will never walk again";
$deathMsg[$ImpactDamageType, 0]      = "%1 makes quite an impact on %2.";
$deathMsg[$ImpactDamageType, 1]      = "%2 becomes the victim of a fly-by from %1.";
$deathMsg[$ImpactDamageType, 2]      = "%2 leaves a nasty dent in %1's fender.";
$deathMsg[$ImpactDamageType, 3]      = "%1 says, 'Hey %2, you scratched my paint job!'";
$deathMsg[$ImpactDamageType, 4] = "%1 rammed into %2.";
$deathMsg[$ImpactDamageType, 5] = "%2 got run over by %1.";
$deathMsg[$ImpactDamageType, 6] = "%2 left his pair of teeth on %1's fender.";
$deathMsg[$ImpactDamageType, 7] = "%1 shows %2 his new ride";
$deathMsg[$ImpactDamageType, 8] = "%1 shoves %2 into his jet thrust.";
$deathMsg[$BulletDamageType, 0]      = "%1 ventilates %2 with %3 chaingun.";
$deathMsg[$BulletDamageType, 1]      = "%1 gives %2 an overdose of lead.";
$deathMsg[$BulletDamageType, 2]      = "%1 fills %2 full of holes.";
$deathMsg[$BulletDamageType, 3]      = "%1 guns down %2.";
$deathMsg[$BulletDamageType, 4]      = "%1 ventilates %2 with %3 chaingun.";
$deathMsg[$BulletDamageType, 5]      = "%1 gives %2 an overdose of lead.";
$deathMsg[$BulletDamageType, 6]      = "%1 turns %2 into swiss cheese.";
$deathMsg[$BulletDamageType, 7]      = "%2 felt like being Holy.";
$deathMsg[$BulletDamageType, 8] = "%2 was perforated by %1.";
$deathMsg[$BulletDamageType, 9] = "%1 completely decimated %2.";
$deathMsg[$BulletDamageType, 10] = "%1 gave %2 a shot right between the eyes- as well as everywhere else.";
$deathMsg[$BulletDamageType, 11] = "%1 guns down %2.";
$deathMsg[$BulletDamageType, 12] = "%1 bucked out on %2.";
$deathMsg[$EnergyDamageType, 0]      = "%2 dies of turret trauma.";
$deathMsg[$EnergyDamageType, 1]      = "%2 is chewed to pieces by a turret.";
$deathMsg[$EnergyDamageType, 2]      = "%2 walks into a stream of turret fire.";
$deathMsg[$EnergyDamageType, 3]      = "%2 ends up on the wrong side of a turret.";
$deathMsg[$EnergyDamageType, 4]      = "%2 loses a game of chicken with a turret.";
$deathMsg[$EnergyDamageType, 5]      = "%2 wonders 'hey, what's this thing do?'";
$deathMsg[$EnergyDamageType, 6]      = "%2 managed to find the enemy turrets.";
$deathMsg[$EnergyDamageType, 7]      = "%2 figures out what all those pretty lights are.";
$deathMsg[$PlasmaDamageType, 0]      = "%2 feels the warm glow of %1's plasma.";
$deathMsg[$PlasmaDamageType, 1]      = "%1 gives %2 a white-hot plasma injection.";
$deathMsg[$PlasmaDamageType, 2]      = "%1 asks %2, 'Got plasma?'";
$deathMsg[$PlasmaDamageType, 3]      = "%1 gives %2 a plasma transfusion.";
$deathMsg[$PlasmaDamageType, 0] = "%2 combusted.";
$deathMsg[$PlasmaDamageType, 1] = "%1 says: '%2, fire=BAD.'";
$deathMsg[$PlasmaDamageType, 2] = "%1 asks %2, 'Need a light?'";
$deathMsg[$PlasmaDamageType, 3] = "%1 lights %2 on fire.";
$deathMsg[$PlasmaDamageType, 4] = "%2 saw %3 life before his eyes, or at least %1's glowing fire.";
$deathMsg[$ExplosionDamageType, 0]   = "%2 catches a Frisbee of Death thrown by %1.";
$deathMsg[$ExplosionDamageType, 1]   = "%1 blasts %2 with a well-placed disc.";
$deathMsg[$ExplosionDamageType, 2]   = "%1's spinfusor caught %2 by surprise.";
$deathMsg[$ExplosionDamageType, 3]   = "%2 falls victim to %1's Stormhammer.";
$deathMsg[$ExplosionDamageType, 4]   = "%2 catches a highly explosive Frisbee thrown by %1.";
$deathMsg[$ExplosionDamageType, 5]   = "%1 blasts %2 with a well-placed disc.";
$deathMsg[$ExplosionDamageType, 6]   = "%1's spinfusor caught %2 by surprise.";
$deathMsg[$ExplosionDamageType, 7]   = "%2 never saw %1's disc coming.";
$deathMsg[$ExplosionDamageType, 8] = "%2 gets blown apart by %1.";
$deathMsg[$ExplosionDamageType, 9] = "%2 was shown %3 inside flesh.";
$deathMsg[$ExplosionDamageType, 10] = "%2 got %3 ribcage opened by %1.";
$deathMsg[$ExplosionDamageType, 11] = "%1 shows off %3 mad skills of body dismemberment on %2.";
$deathMsg[$ExplosionDamageType, 12] = "%2 goes Kablooie!";
$deathMsg[$ShrapnelDamageType, 0]    = "%1 blows %2 up real good.";
$deathMsg[$ShrapnelDamageType, 1]    = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$ShrapnelDamageType, 2]    = "%1 gives %2 a fatal concussion.";
$deathMsg[$ShrapnelDamageType, 3]    = "%2 never saw it coming from %1.";
$deathMsg[$ShrapnelDamageType, 4] = "%2 was canned by %1.";
$deathMsg[$ShrapnelDamageType, 5] = "%1 brutally shafted %2.";
$deathMsg[$LaserDamageType, 0]       = "%1 adds %2 to %3 list of sniper victims.";
$deathMsg[$LaserDamageType, 1]       = "%1 fells %2 with a sniper shot.";
$deathMsg[$LaserDamageType, 2]       = "%2 becomes a victim of %1's laser rifle.";
$deathMsg[$LaserDamageType, 3]       = "%2 stayed in %1's crosshairs for too long.";
$deathMsg[$LaserDamageType, 4]       = "%1 fried %2's brain.";
$deathMsg[$LaserDamageType, 5]       = "%2 has a hole fried through %4 by %1's laser.";
$deathMsg[$LaserDamageType, 6]       = "%1 Lightly Amplified %2's Stimulated Emission of Radiation.";
$deathMsg[$LaserDamageType, 7]       = "%1 felt like using his flashlight on %2.";
$deathMsg[$LaserDamageType, 8]       = "%1 adds a few scorches to %2's hide.";
$deathMsg[$LaserDamageType, 9]       = "%1 gives %2 a much needed hole in the head.";
$deathMsg[$LaserDamageType, 10]       = "%2 becomes a victim of %1's Laser.";
$deathMsg[$LaserDamageType, 11]       = "%2 was cut in half by %1's Laser.";
$deathMsg[$LaserDamageType, 12]       = "%2 finally realised what that red dot was.";
$deathMsg[$LaserDamageType, 13] = "%1 adds %2 to %3 list of hapless victims.";
$deathMsg[$LaserDamageType, 14] = "%1 fells %2 with a beam of pain.";
$deathMsg[$LaserDamageType, 15] = "%2 was executed by %1.";
$deathMsg[$LaserDamageType, 16] = "%2 stayed in %1's way, for too long.";
$deathMsg[$LaserDamageType, 17] = "%2 gets a hole burned in %3 head.";
$deathMsg[$MortarDamageType, 0]      = "%1 mortars %2 into oblivion.";
$deathMsg[$MortarDamageType, 1]      = "%2 didn't see that last mortar from %1.";
$deathMsg[$MortarDamageType, 2]      = "%1 inflicts a mortal mortar wound on %2.";
$deathMsg[$MortarDamageType, 3]      = "%1's mortar takes out %2.";
$deathMsg[$MortarDamageType, 4]      = "%1 caught %2 in %3 blast radius.";
$deathMsg[$MortarDamageType, 5]      = "%1 gave %2 a lesson in body dismemberment.";
$deathMsg[$MortarDamageType, 6]      = "%1 blew %2 all to pieces.";
$deathMsg[$MortarDamageType, 7]      = "%1's mortar takes out %2.";
$deathMsg[$MortarDamageType, 8]      = "%1 reached out and touched %2.";
$deathMsg[$MortarDamageType, 9]      = "%2 should have seen that one coming from %1.";
$deathMsg[$MortarDamageType, 10]      = "%1 teaches %2 the meaning of BOOM!.";
$deathMsg[$MortarDamageType, 11]      = "%2 last memory was of a green thing at %4 feet.";
$deathMsg[$MortarDamageType, 12] = "%1 explodes %2 into oblivion.";
$deathMsg[$MortarDamageType, 13] = "%2 found %1's bomb.";
$deathMsg[$MortarDamageType, 14] = "%1 placed the explosives right below %2's feet.";
$deathMsg[$MortarDamageType, 15] = "%1's bomb takes out %2.";
$deathMsg[$MortarDamageType, 16] = "%2 makes a mental note- bombs=bad.";
$deathMsg[$BlasterDamageType, 0]     = "%2 gets a blast out of %1.";
$deathMsg[$BlasterDamageType, 1]     = "%2 succumbs to %1's rain of blaster fire.";
$deathMsg[$BlasterDamageType, 2]     = "%1's puny blaster shows %2 a new world of pain.";
$deathMsg[$BlasterDamageType, 3]     = "%2 meets %1's master blaster.";
$deathMsg[$BlasterDamageType, 4] = "%2 gets blasted with %1's Blaster.";
$deathMsg[$BlasterDamageType, 5] = "%1 fries %2.";
$deathMsg[$BlasterDamageType, 6] = "%2 meets %1's Bolt O' inceniration.";
$deathMsg[$BlasterDamageType, 7] = "%2 couldn't steer clear of %1's Blaster.";
$deathMsg[$ElectricityDamageType, 0] = "%2 gets zapped with %1's ELF gun.";
$deathMsg[$ElectricityDamageType, 1] = "%1 gives %2 a nasty jolt.";
$deathMsg[$ElectricityDamageType, 2] = "%2 gets a real shock out of meeting %1.";
$deathMsg[$ElectricityDamageType, 3] = "%1 short-circuits %2's systems.";
$deathMsg[$ElectricityDamageType, 4] = "%2 gets zapped with %1's bug zapper.";
$deathMsg[$ElectricityDamageType, 5] = "%1 gives %2 a nasty jolt.";
$deathMsg[$ElectricityDamageType, 6] = "%2 gets a real shock out of meeting %1.";
$deathMsg[$ElectricityDamageType, 7] = "%2 caught a few volts.";
$deathMsg[$CrushDamageType, 0]		 = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 1]		 = "%2 is crushed.";
$deathMsg[$CrushDamageType, 2]		 = "%2 gets smushed flat.";
$deathMsg[$CrushDamageType, 3]		 = "%2 gets caught in the machinery.";
$deathMsg[$CrushDamageType, 4]		 = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 5]		 = "%2 got a great deal for pizza.";
$deathMsg[$CrushDamageType, 6]		 = "%2 became 1 dimensional.";
$deathMsg[$CrushDamageType, 7]		 = "%2 gets caught in the machinery.";
$deathMsg[$DebrisDamageType, 0]		 = "%2 is a victim among the wreckage.";
$deathMsg[$DebrisDamageType, 1]		 = "%2 is killed by debris.";
$deathMsg[$DebrisDamageType, 2]		 = "%2 becomes a victim of collateral damage.";
$deathMsg[$DebrisDamageType, 3]		 = "%2 got too close to the exploding stuff.";
$deathMsg[$MissileDamageType, 0]	    = "%2 takes a missile up the keister.";
$deathMsg[$MissileDamageType, 1]	    = "%2 gets shot down.";
$deathMsg[$MissileDamageType, 2]	    = "%2 gets real friendly with a rocket.";
$deathMsg[$MissileDamageType, 3]	    = "%2 feels the burn from a warhead.";
$deathMsg[$MissileDamageType, 4] = "%2 gets buttraped by a warhead.";
$deathMsg[$MissileDamageType, 5] = "%2 offered to suck %1's warhead.";
$deathMsg[$MissileDamageType, 6] = "%2 played dodgeball with a rocket...And lost.";
$deathMsg[$MissileDamageType, 7] = "%2 feels the burn from a warhead.";
$deathMsg[$MissileDamageType, 8] = "%2 rides the rocket.";
$deathMsg[$MineDamageType, 0]	       = "%1 blows %2 up real good.";
$deathMsg[$MineDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$MineDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$MineDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$MineDamageType, 4] = "%2 stepped in %1's cow pie.";
$deathMsg[$MagneticDamageType, 0] = "%1 ripps %2 apart.";
$deathMsg[$MagneticDamageType, 1] = "%2 felt %1's magnetic personality.";
$deathMsg[$MagneticDamageType, 2] = "%2 took the pain from %1's MAG gun.";
$deathMsg[$MagneticDamageType, 3] = "%1 zapped %2 into oblivion.";
$deathMsg[$EMPDamageType, 0] = "%2 was killed by %1's EMP blast.";
$deathMsg[$EMPDamageType, 1] = "%2 was killed by %1's EMP blast.";
$deathMsg[$EMPDamageType, 2] = "%2 was killed by %1's EMP blast.";
$deathMsg[$EMPDamageType, 3] = "%2 was killed by %1's EMP blast.";
$deathMsg[$RocketDamageType, 0] = "%1 shoots %2 down.";
$deathMsg[$RocketDamageType, 1] = "%2 was scorched by %1's Rocket.";
$deathMsg[$RocketDamageType, 2] = "%1 shoots %2 down.";
$deathMsg[$RocketDamageType, 3] = "%2 was scorched by %1's Rocket.";
$deathMsg[$FusionDamageType, 0]	       = "%2 was torn to shreads by a Frag.";
$deathMsg[$FusionDamageType, 1]	       = "%2 gets a taste of %1's Fragmenting Missile.";
$deathMsg[$FusionDamageType, 2]	       = "%1 gives %2 a fatal blast.";
$deathMsg[$FusionDamageType, 3]	       = "%2 was blown to pieces by a Frag.";
$deathMsg[$DisruptorDamageType, 0]	       = "%1 blows %2 clear through into another dimension.";
$deathMsg[$DisruptorDamageType, 1]	       = "%2 is a victim of %1's disruptor beams.";
$deathMsg[$DisruptorDamageType, 2]	       = "%1 blew antimatter into %2's face.";
$deathMsg[$DisruptorDamageType, 3]	       = "%2 is filled with disruptor by %1.";
$deathMsg[$SonicDamageType, 0]	       = "%2 took a 5000 decibel soundwave.";
$deathMsg[$SonicDamageType, 1]	       = "%1 left a nasty dent in %2's armor.";
$deathMsg[$SonicDamageType, 2]	       = "%1 gives %2 up for spare parts.";
$deathMsg[$SonicDamageType, 3]	       = "%2 never heard it coming from %1.";
$deathMsg[$IonDamageType, 0]	       = "%1 electrified %2 with an Ion Cannon.";
$deathMsg[$IonDamageType, 1]	       = "%2 gets a taste of %1's fission energy.";
$deathMsg[$IonDamageType, 2]	       = "%2 gets a fusion reactor overload.";
$deathMsg[$IonDamageType, 3]	       = "%2 took in too much energy.";
$deathMsg[$DistortionDamageType, 0]	       = "%2 was distorted by %1.";
$deathMsg[$DistortionDamageType, 1]	       = "%2 fell all to pieces.";
$deathMsg[$DistortionDamageType, 2]	       = "%1 distorted %2 with %3 distortion gun.";
$deathMsg[$DistortionDamageType, 3]	       = "%2 was dissasembled.";
$deathMsg[$EMPDamageType, 0]	       = "%1 zaps %2 of %3 energy.";
$deathMsg[$EMPDamageType, 1]	       = "%2 gets a taste of %1's energy sucker.";
$deathMsg[$EMPDamageType, 2]	       = "%1 gives %2 a fatal power drain.";
$deathMsg[$EMPDamageType, 3]	       = "%2 ran out of energy.";
$deathMsg[$PulseDamageType, 0]	       = "%1 lit %2 up.";
$deathMsg[$PulseDamageType, 1]	       = "%2's light got turned on by %1.";
$deathMsg[$PulseDamageType, 2]	       = "%1 used the Force on %2.";
$deathMsg[$PulseDamageType, 3]	       = "%1 electrified %2.";
$deathMsg[$SniperDamageType, 0]	       = "%1 assassinated %2 with %3 MD-2000.";
$deathMsg[$SniperDamageType, 1]	       = "%2 stayed still for too long.";
$deathMsg[$SniperDamageType, 2]	       = "%2 ends up on the wrong side of a MD-2000.";
$deathMsg[$SniperDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$SniperDamageType, 4]   		 = "%1 chews %2 to bits with %3 MD-2000.";
$deathMsg[$SniperDamageType, 5]   		 = "%2 suddenly has way too much air conditioning from %1's MD-2000.";
$deathMsg[$SniperDamageType, 6]   		 = "%1's MD-2000 does in %2 up close and personal.";
$deathMsg[$SniperDamageType, 7]   		 = "%2 now knows what the barrel of %1's MD-2000 looks like.";
$deathMsg[$SniperDamageType, 8]            = "%1 snipes %2.";
$deathMsg[$SniperDamageType, 9]            = "%2 claimed to be immortal. %1 proved him wrong.";
$deathMsg[$SniperDamageType, 10]           = "%1 tells %2 you zigged when you should have zagged.";
$deathMsg[$SniperDamageType, 11]           = "%1 shaves a little too much off %2.";
$deathMsg[$SniperDamageType, 12]           = "%2 is clueless after %1's MD-2000 shot."; 
$deathMsg[$SniperDamageType, 13]           = "%1 punches a hole through %2's armor."; 
$deathMsg[$SniperDamageType, 14]           = "%2 becomes a victim of %1's MD-2000."; 
$deathMsg[$SniperDamageType, 15]           = "%2 REALLY never saw it coming from %1.";
$deathMsg[$SniperDamageType, 16] = "%1 says- 'professional assassination, the highest form of gov. service.'";
$deathMsg[$SniperDamageType, 17] = "%1 takes %2 on a snipe hunt.";
$deathMsg[$SniperDamageType, 18] = "%2 was assassinated by %1.";
$deathMsg[$SniperDamageType, 19] = "%2 walked in a straight line again.";
$deathMsg[$SniperDamageType, 20] = "%2 gets picked off from afar by %1.";
$deathMsg[$SniperDamageType, 21] = "%2 feels the bullets from %1 lodge into his chest.";
$deathMsg[$SniperDamageType, 22] = "%1 gave %2 a shot right between the eyes.";
$deathMsg[$SniperDamageType, 23] = "%2 fell victim to a chopper city from %1.";
$deathMsg[$SniperDamageType, 25] = "%2 was perforated by %1.";
$deathMsg[$SniperDamageType, 26]	       = "%2 had no idea how %4 was assassinated.";
$deathMsg[$SniperDamageType, 27]	       = "%2 was killed.";
$deathMsg[$SniperDamageType, 28]	       = "%1 takes a pot shot at %2.";
$deathMsg[$SniperDamageType, 29]	       = "%2 died.";
$deathMsg[$VulcanDamageType, 0]	       = "%2 says: Live long and prosper.";
$deathMsg[$VulcanDamageType, 1]	       = "%2 became holy from %1.";
$deathMsg[$VulcanDamageType, 2]	       = "%2 is now well ventilated by %1's Vulcan.";
$deathMsg[$VulcanDamageType, 3]	       = "%1 vulcanized %2.";
$deathMsg[$ShotgunDamageType, 0]	       = "%1 turns %2 into swiss cheese.";
$deathMsg[$ShotgunDamageType, 1]	       = "%2 gets a taste of %1's explosive shotgun.";
$deathMsg[$ShotgunDamageType, 2]	       = "%1 gives %2 an overdose of tungsten.";
$deathMsg[$ShotgunDamageType, 3]	       = "%2 blasts %1.";
$deathMsg[$ShotgunDamageType, 4] 		 = "%2 caught a chest full of %1's shotgun blast."; 
$deathMsg[$ShotgunDamageType, 5] 		 = "%1 filled %2 full of shotgun pellets."; 
$deathMsg[$ShotgunDamageType, 6] 		 = "%2 went down after %1's vicious shotgun assault."; 
$deathMsg[$ShotgunDamageType, 7] 		 = "%2 lets freedom ring with a shotgun blast from %1."; 
$deathMsg[$NukeDamageType, 0]	       = "%1 nukes %2.";
$deathMsg[$NukeDamageType, 1]	       = "%2 was caught in the nuke radius.";
$deathMsg[$NukeDamageType, 2]	       = "%1 sent %2 back to %4's maker.";
$deathMsg[$NukeDamageType, 3]	       = "%2 was incenirated.";
$deathMsg[$NukeDamageType, 4]        = "%2 takes a brutal flying lesson from %1.";
$deathMsg[$NukeDamageType, 5]   	 = "%1 tells %2 to 'back off!'";
$deathMsg[$NukeDamageType, 6]   	 = "%1 shows %2 the force of %3 wrath.";
$deathMsg[$NukeDamageType, 7]   	 = "%1 makes a real impression on %2.";
$deathMsg[$ZapDamageType, 0]	       = "%1 gives %2 a nasty jolt.";
$deathMsg[$ZapDamageType, 1]	       = "%2 gets a taste of %1's electric temper.";
$deathMsg[$ZapDamageType, 2]	       = "%1 zaps %2.";
$deathMsg[$ZapDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$RepairDamageType, 0]	       = "%1 omegas %2 up real good.";
$deathMsg[$RepairDamageType, 1]	       = "%2 gets a taste of %1's interdimensional temper.";
$deathMsg[$RepairDamageType, 2]	       = "%2 couldn't take any more omega rays.";
$deathMsg[$RepairDamageType, 3]	       = "%2 never felt it omeging from %1.";
$deathMsg[$HeatDamageType, 0]	       = "%2 couldn't take the heat.";
$deathMsg[$HeatDamageType, 1]	       = "%2 overheated.";
$deathMsg[$HeatDamageType, 2]	       = "%1 gives %2 a fatal heatstroke.";
$deathMsg[$HeatDamageType, 3]	       = "%2 was a victim of a heatwave from %1.";
$deathMsg[$HeatDamageType, 4]        = "%1 says to %2, 'Only I can prevent forest fires.'";
$deathMsg[$HeatDamageType, 5]        = "%2 needed a light. %1 gave it to him.";
$deathMsg[$HeatDamageType, 6]        = "%2 dies of %1's second-hand smoke.";
$deathMsg[$HeatDamageType, 7]        = "%1 says to %2, 'Toasty!'";
$deathMsg[$HeatDamageType, 8]        = "%1 roasted %2 to a nice golden brown."; 
$deathMsg[$HeatDamageType, 9]        = "%2 was left with a burning sensation after %4 encounter with %1."; 
$deathMsg[$HeatDamageType, 10]       = "%1 overcooked %2."; 
$deathMsg[$HeatDamageType, 11]       = "%1 incinerated %2 with %3 Flamer."; 
$deathMsg[$HeatDamageType, 12]       = "%1 overheated %2 with his Flamer."; 
$deathMsg[$HeatDamageType, 13]       = "%2 should have ran from %1's hot advances."; 
$deathMsg[$HeatDamageType, 14]       = "%2 couldn't handle %1's Flamer."; 
$deathMsg[$HeatDamageType, 15]       = "%2 exploded from the heat of %1's Flamer.";
$deathMsg[$HeatDamageType, 16] = "%2 got microwaved by %1.";
$deathMsg[$HeatDamageType, 17] = "%2 was cooked by %1.";
$deathMsg[$HeatDamageType, 18] = "%2 was taught about home cookin, by %1.";
$deathMsg[$HeatDamageType, 19] = "%2 was bubbled and melted by %1.";
$deathMsg[$HeatDamageType, 20] = "%2 got pressure cooked by %1.";
$deathMsg[$PhotonDamageType, 0]	       = "%1 throws %2 a volley of photons.";
$deathMsg[$PhotonDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$PhotonDamageType, 2]	       = "%1 gives %2 a fatal photon blast.";
$deathMsg[$PhotonDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$PistolDamageType, 0]	       = "%1 shoots %2 for target practice.";
$deathMsg[$PistolDamageType, 1]	       = "%2 gets a taste of %1's lead.";
$deathMsg[$PistolDamageType, 2]	       = "%1 gives %2 a fatal overdose of lead.";
$deathMsg[$PistolDamageType, 3]	       = "%2 never knew how good %4 had it.";
$deathMsg[$ATCDamageType, 0]	       = "%1 is the victim of a vulcanized missile launcher.";
$deathMsg[$ATCDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$ATCDamageType, 2]	       = "%1 gives %2 a vulcan ATC blast.";
$deathMsg[$ATCDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$StarDamageType, 0]	       = "%1 gives %2 some Starburst.";
$deathMsg[$StarDamageType, 1]	       = "%2 samples some of %1's Starburst hard candy.";
$deathMsg[$StarDamageType, 2]	       = "%1 gives %2 a 75-missile concussion.";
$deathMsg[$StarDamageType, 3]	       = "%2 saw his life flash before %4 eyes.";
$deathMsg[$ZapMortarDamageType, 0]	       = "%1 blasts %2 with a big blue glob of antimatter.";
$deathMsg[$ZapMortarDamageType, 1]	       = "%2 gets a taste of %1's interdimensional technology.";
$deathMsg[$ZapMortarDamageType, 2]	       = "%2 was impacted by a fusion charge.";
$DeathMsg[$ZapMortarDamageType, 3]	       = "%2 was killed by %1.";
$deathMsg[$ShockwaveDamageType, 0]	       = "%2 is turned to rubble.";
$deathMsg[$ShockwaveDamageType, 1]	       = "%2 gets a shockwave.";
$deathMsg[$ShockwaveDamageType, 2]	       = "%1 blew %2 all to pieces.";
$deathMsg[$ShockwaveDamageType, 3]	       = "%1 kills %2 with an overdose of radiation.";
$deathMsg[$QuantumDamageType, 0]	       = "%1 blows %2 up real good.";
$deathMsg[$QuantumDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$QuantumDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$QuantumDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$BusterDamageType, 0]	       = "%2 has a close encounter of %1's Fhazer type.";
$deathMsg[$BusterDamageType, 1]	       = "%1 gave a much needed hole through %2.";
$deathMsg[$BusterDamageType, 2]	       = "%1 Fhazes %2.";
$deathMsg[$BusterDamageType, 3]	       = "%2 died from the electric hole.";
$deathMsg[$FluxDamageType, 0]	       = "%1 blows %2 up real good.";
$deathMsg[$FluxDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$FluxDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$FluxDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$FlierBombDamageType, 0]	       = "%2 is the victim of a fly-by.";
$deathMsg[$FlierBombDamageType, 1]	       = "%2 got bombed by %1.";
$deathMsg[$FlierBombDamageType, 2]	       = "%1 let his bombs loose on %2.";
$deathMsg[$FlierBombDamageType, 3]	       = "%2 was killed by %1.";
$deathMsg[$FlierBombDamageType, 4] 		 = "%1 rain of bombs obliterated %2."; 
$deathMsg[$FlierBombDamageType, 5] 		 = "%1 bombed the crap outa %2."; 
$deathMsg[$FlierBombDamageType, 6] 		 = "%2 couldn't escape %1's bombing run."; 
$deathMsg[$FlierBombDamageType, 7] 		 = "%1 over ran %2 with a string of bombs."; 
$deathMsg[$BustedDamageType, 0]	       = "%1 takes %2 with %3.";
$deathMsg[$BustedDamageType, 1]	       = "%2 is the victim of %1's explosive DetPack.";
$deathMsg[$BustedDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$BustedDamageType, 3]	       = "%2 never suspected a blast from %1.";
$deathMsg[$PBWDamageType, 0]	       = "%1 punched a hole through %2.";
$deathMsg[$PBWDamageType, 1]	       = "%2 gets a taste of %1's PBW.";
$deathMsg[$PBWDamageType, 2]	       = "%1 gives %2 a fatal PBW concussion.";
$deathMsg[$PBWDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$IceDamageType, 0]	       = "%2 froze to death.";
$deathMsg[$IceDamageType, 1]	       = "%2 was feeling kinda cold.";
$deathMsg[$IceDamageType, 2]	       = "%2 was bombarded by freezing cold crystals.";
$deathMsg[$IceDamageType, 3]	       = "%2 was freezerburned.";
$deathMsg[$RPGDamageType, 0]	       = "%1 fiored ma RPG at %2.";
$deathMsg[$RPGDamageType, 1]	       = "%2 takes a RPG head-on.";
$deathMsg[$RPGDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$RPGDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$RPMDamageType, 0]	       = "%2 had no idea mortars could fly.";
$deathMsg[$RPMDamageType, 1]	       = "%2 was blown all to pieces.";
$deathMsg[$RPMDamageType, 2]	       = "%1 gives %2 a mortar rocket.";
$deathMsg[$RPMDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$MethaneDamageType, 0]	       = "%2 was poisioned with a methane-oxide dart.";
$deathMsg[$MethaneDamageType, 1]	       = "%2 felt the effects of methane-oxide poisoning and took 65536 HP!";
$deathMsg[$MethaneDamageType, 2]	       = "%1 gives %2 a lethal injection.";
$deathMsg[$MethaneDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$MethaneDamageType, 4] = "%2 dies with green flesh open.";
$deathMsg[$MethaneDamageType, 5] = "%2 gets a lethal injection from %1.";
$deathMsg[$MethaneDamageType, 6] = "%2 falls victim to a deadly virus.";
$deathMsg[$MethaneDamageType, 7] = "%2 heard 'USE THE REPAIR KIT' from far off.";
$deathMsg[$MethaneDamageType, 8] = "%2 gasps %3 last breath.";
$deathMsg[$BurstDamageType, 0]	       = "%2 had no idea lasers could blow you to pieces.";
$deathMsg[$BurstDamageType, 1]	       = "%2 was blown all to pieces.";
$deathMsg[$BurstDamageType, 2]	       = "%1 gives %2 a hi-powered laser.";
$deathMsg[$BurstDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$ReaverDamageType, 0]	       = "%2 had no idea what a reaver was.";
$deathMsg[$ReaverDamageType, 1]	       = "%2 was killed by the rapid-fire rhapsody of the Reaver.";
$deathMsg[$ReaverDamageType, 2]	       = "%1 gives %2 a reaver rocket.";
$deathMsg[$ReaverDamageType, 3]	       = "%2 never saw it coming from %1.";
$deathMsg[$RifleDamageType, 0]	       = "%2 had no idea how %4 was assassinated.";
$deathMsg[$RifleDamageType, 1]	       = "%2 was killed.";
$deathMsg[$RifleDamageType, 2]	       = "%1 takes a pot shot at %2.";
$deathMsg[$RifleDamageType, 3]	       = "%2 died.";
$deathMsg[$FlameDamageType, 0]	       = "%2 couldn't take the heat.";
$deathMsg[$FlameDamageType, 1]	       = "%2 overheated.";
$deathMsg[$FlameDamageType, 2]	       = "%1 gives %2 a fatal heatstroke.";
$deathMsg[$FlameDamageType, 3]	       = "%2 was a victim of a heatwave from %1.";
$deathMsg[$FlameDamageType, 4]        = "%1 says to %2, 'Only I can prevent forest fires.'";
$deathMsg[$FlameDamageType, 5]        = "%2 needed a light. %1 gave it to him.";
$deathMsg[$FlameDamageType, 6]        = "%2 dies of %1's second-hand smoke.";
$deathMsg[$FlameDamageType, 7]        = "%1 says to %2, 'Toasty!'";
$deathMsg[$FlameDamageType, 8]        = "%1 roasted %2 to a nice golden brown."; 
$deathMsg[$FlameDamageType, 9]        = "%2 was left with a burning sensation after %4 encounter with %1."; 
$deathMsg[$FlameDamageType, 10]       = "%1 overcooked %2."; 
$deathMsg[$FlameDamageType, 11]       = "%1 incinerated %2 with %3 Flamer."; 
$deathMsg[$FlameDamageType, 12]       = "%1 overheated %2 with his Flamer."; 
$deathMsg[$FlameDamageType, 13]       = "%2 should have ran from %1's hot advances."; 
$deathMsg[$FlameDamageType, 14]       = "%2 couldn't handle %1's Flamer."; 
$deathMsg[$FlameDamageType, 15]       = "%2 exploded from the heat of %1's Flamer.";
$deathMsg[$FlameDamageType, 16]	       = "%2 was feeling kinda toasty.";
$deathMsg[$FlameDamageType, 17]	       = "%2 melted.";
$deathMsg[$FlameDamageType, 18]	       = "%1 gives %2 a hot time.";
$deathMsg[$FlameDamageType, 19]	       = "%2 couldn't take the heat.";
$deathMsg[$FlameDamageType, 20] = "%2 got microwaved by %1.";
$deathMsg[$FlameDamageType, 21] = "%2 was cooked by %1.";
$deathMsg[$FlameDamageType, 22] = "%2 was taught about home cookin, by %1.";
$deathMsg[$FlameDamageType, 23] = "%2 was bubbled and melted by %1.";
$deathMsg[$FlameDamageType, 24] = "%2 got pressure cooked by %1.";
$deathMsg[$FlameDamageType, 25] = "%2 is cooked medium rare by %1.";
$deathMsg[$FlameDamageType, 26] = "%1 bakes %2 at 3000 degrees centigrade.";
$deathMsg[$FlameDamageType, 27] = "%2 feels a little hot under the hood.";
$deathMsg[$FlameDamageType, 28] = "%2 fries extra crispy from %1's flamer.";
$deathMsg[$FlameDamageType, 29] = "%1 ignites %2.";
$deathMsg[$VulcanDamageType, 0]      = "%1 ventilates %2 with %3 Vulcan Cannon.";
$deathMsg[$VulcanDamageType, 1]      = "%1 gives %2 an overdose of tungsten-tipped bullets.";
$deathMsg[$VulcanDamageType, 2]      = "%1 fills %2 full of holes.";
$deathMsg[$VulcanDamageType, 3]      = "%1 guns down %2.";
$deathMsg[$VulcanDamageType, 4]      = "%1 ventilates %2 with %3 Vulcan.";
$deathMsg[$VulcanDamageType, 5]      = "%1 gives %2 an overdose of bullets.";
$deathMsg[$VulcanDamageType, 6]      = "%1 turns %2 into swiss cheese.";
$deathMsg[$VulcanDamageType, 7]      = "%2 felt like being Holy.";
$deathMsg[$GaussDamageType, 0]      = "%1 chunks apart %2 with %3 Gauss Cannon.";
$deathMsg[$GaussDamageType, 1]      = "%1 gives %2 an overdose of highly explosive bullets.";
$deathMsg[$GaussDamageType, 2]      = "%1 fills %2 with explosive bullets.";
$deathMsg[$GaussDamageType, 3]      = "%1 decintegrates %2.";
$deathMsg[$GaussDamageType, 4]      = "%1 pillages %2 with %3 Gauss.";
$deathMsg[$GaussDamageType, 5]      = "%1 blows %2 to smithereens.";
$deathMsg[$GaussDamageType, 6]      = "%1 turns %2 into swiss cheese.";
$deathMsg[$GaussDamageType, 7]      = "%2 says: Blasted Gauss Cannon.";
$deathMsg[$MBDamageType, 0]      = "%2 is blown away.";
$deathMsg[$MBDamageType, 1]      = "%1 gives %2 an overdose of Mitzi.";
$deathMsg[$MBDamageType, 2]      = "%1 fills %2 with a hyperactiuve blast.";
$deathMsg[$MBDamageType, 3]      = "%1 bowls over %2.";
$deathMsg[$CutterDamageType, 0]      = "%2 is cut in half.";
$deathMsg[$CutterDamageType, 1]      = "%1 gives %2 a fatal haircut.";
$deathMsg[$CutterDamageType, 2]      = "%1 slices %2 to pieces.";
$deathMsg[$CutterDamageType, 3]      = "%1 kills %2.";
$deathMsg[$PistolDamageType, 0]      = "%2 was shot a point-blank";
$deathMsg[$PistolDamageType, 1]      = "%1 shot %2 with a pistol";
$deathMsg[$PistolDamageType, 2]      = "%1 kills %2";
$deathMsg[$PistolDamageType, 3]      = "%2 was pistollized";
$deathMsg[$MassDamageType, 0]      = "%2 took in an excessive amount of explosion";
$deathMsg[$MassDamageType, 1]      = "%2 smoked too much";
$deathMsg[$MassDamageType, 2]      = "%1 gives %2 a Mass Driver blast";
$deathMsg[$MassDamageType, 3]      = "%2 says: Ouchies!";
$deathMsg[$NullDamageType, 0]      = "";
$deathMsg[$NullDamageType, 1]      = "";
$deathMsg[$NullDamageType, 2]      = "";
$deathMsg[$NullDamageType, 3]      = "";

// "you just killed yourself" messages
//   %1 = player name,  %2 = player gender pronoun

$deathMsg[-2,0]						 = "%1 ends it all.";
$deathMsg[-2,1]						 = "%1 takes %2 own life.";
$deathMsg[-2,2]						 = "%1 kills %2 own dumb self.";
$deathMsg[-2,3]						 = "%1 decides to see what the afterlife is like.";
$deathMsg[-2,4]						 = "%1 heard the fat lady sing.";
$deathMsg[-2,5]						 = "%1 wanted to make sure %2 gun was loaded.";
$deathMsg[-2,6]						 = "%1 goes postal.";
$deathMsg[-2,7]						 = "%1 says: Today is a good day to die.";
$deathMsg[-2,8]						 = "%1 goes to see Dr. Kevorkian.";
$deathMsg[-2,9]						 = "%1 just killed %2self for no good reason."; 
$deathMsg[-2,10]						 = "%1 decides to eat %2 Fusion Generator for lunch.";
$deathMsg[-2,11]						 = "%1 tripped over %2 shoelaces.";
$deathMsg[-2,12]						 = "%1 was last heard yelling 'death before dishonor!'";
$deathMsg[-2,13]						 = "%1 had %2 weapon facing the wrong way.";
$deathMsg[-2,14]						 = "%1 was bored with %2 life.";
$deathMsg[-2,15]						 = "%1 decided to test the reincarnation theory.";
$deathMsg[-2,16]						 = "%1 shows off %2 mad dying skills.";
$deathMsg[-2,17]						 = "%1 engaged %2 self-destruct sequence.";
$deathMsg[-2,18]						 = "%1 had sone really urgent buisiness to take care of.";
$deathMsg[-2,19]						 = "%1 made himself holy.";
$deathMsg[-2,20]						 = "%1 says: Clap on! (clap, clap) Clap off! (clap@#&$NO CARRIER";
$deathMsg[-2,21]						 = "%1 decided to end it all.";
$deathMsg[-2,22]						 = "%1 says: The Borg assimilated me & all I got was this stupid T-Shirt!";
$deathMsg[-2,23]						 = "%1 wasn't sure how much ammo was left in his gun.";  
$deathMsg[-2,24]						 = "%1 should have paid attention to the ground.";  
$deathMsg[-2,25]						 = "%1 went to Heaven";  
$deathMsg[-2,26]						 = "%1 became a glitch in the matrix";

$numDeathMsgs = 27;

//---------------------------------------------------------------------------------

$spawnBuyList[0] = LightArmor;
$spawnBuyList[1] = RPGLauncher;
$spawnBuyList[2] = GaussCannon;
$spawnBuyList[3] = GatlingBlaster;
$spawnBuyList[4] = DiscLauncher;
$SpawnBuyList[5] = Reassembler;
$SpawnBuyList[6] = ScoLauncher;
$SpawnBuyList[7] = EPodPack;
$SpawnBuyList[8] = repairkit;
$SpawnBuyList[9] = repairkit;

function remotePlayMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModePlay);
   }
}

function remoteCommandMode(%clientId)
{
   // can't switch to command mode while a server menu is up
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);  // force the bandwidth to be full command
		if(%clientId.observerMode != "pregame")
		   checkControlUnmount(%clientId);
		Client::setGuiMode(%clientId, $GuiModeCommand);
   }
}

function remoteInventoryMode(%clientId)
{
   if(!%clientId.guiLock && !Observer::isObserver(%clientId))
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeInventory);
   }
}

function remoteObjectivesMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeObjectives);
   }
}

function remoteScoresOn(%clientId)
{
   if(!%clientId.menuMode)
      Game::menuRequest(%clientId);
}

function remoteScoresOff(%clientId)
{
   Client::cancelMenu(%clientId);
}

function remoteToggleCommandMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeCommand)
		remoteCommandMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleInventoryMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeInventory)
		remoteInventoryMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleObjectivesMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeObjectives)
		remoteObjectivesMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function Time::getMinutes(%simTime)
{
   return floor(%simTime / 60);
}

function Time::getSeconds(%simTime)
{
   return %simTime % 60;
}

function Game::pickRandomSpawn(%team)
{
   %group = nameToID("MissionGroup/Teams/team" @ %team @ "/DropPoints/Random");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;
  	%spawnIdx = floor(getRandom() * (%count - 0.1));
  	%value = %count;
	for(%i = %spawnIdx; %i < %value; %i++) {
		%set = newObject("set",SimSet);
		%obj = Group::getObject(%group, %i);
		if(containerBoxFillSet(%set,$SimPlayerObjectType|$VehicleObjectType,GameBase::getPosition(%obj),2,2,4,0) == 0) {
			deleteObject(%set);
			return %obj;		
		}
		if(%i == %count - 1) {
			%i = -1;
			%value = %spawnIdx;
		}
		deleteObject(%set);
	}
   return false;
}

function Game::pickStartSpawn(%team)
{
   %group = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\DropPoints\\Start");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;

   %spawnIdx = $lastTeamSpawn[%team] + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   $lastTeamSpawn[%team] = %spawnIdx;
   return Group::getObject(%group, %spawnIdx);
}

function Game::pickTeamSpawn(%team, %respawn)
{
   if(%respawn)
      return Game::pickRandomSpawn(%team);
   else
   {
      %spawn = Game::pickStartSpawn(%team);
      if(%spawn == -1)
         return Game::pickRandomSpawn(%team);
      return %spawn;
   }
}

function Game::pickObserverSpawn(%client)
{
   %group = nameToID("MissionGroup\\ObserverDropPoints");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team" @ Client::getTeam(%client) @ "\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team0\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      return -1;
   %spawnIdx = %client.lastObserverSpawn + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   %client.lastObserverSpawn = %spawnIdx;
	return Group::getObject(%group, %spawnIdx);
}

function UpdateClientTimes(%time)
{
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      remoteEval(%cl, "setTime", -%time);
}

function Game::notifyMatchStart(%time)
{
   messageAll(0, "Match starts in " @ %time @ " seconds.");
   UpdateClientTimes(%time);
}

function Game::startMatch()
{
   $matchStarted = true;
   $missionStartTime = getSimTime();
   messageAll(0, "Match started.");
	Game::resetScores();	

   %numTeams = getNumTeams();
   for(%i = 0; %i < %numTeams; %i = %i + 1) {
		if($TeamEnergy[%i] != "Infinite")
			schedule("replenishTeamEnergy(" @ %i @ ");", $secTeamEnergy);
	}

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
		if(%cl.observerMode == "pregame")
      {
         %cl.observerMode = "";
         Client::setControlObject(%cl, Client::getOwnedObject(%cl));
      }
   	Game::refreshClientScore(%cl);
	}
   Game::checkTimeLimit();
}

function Game::pickPlayerSpawn(%clientId, %respawn)
{
   return Game::pickTeamSpawn(Client::getTeam(%clientId), %respawn);
}

function Game::playerSpawn(%clientId, %respawn)
{
	Client::setSkin(%clientId, $Client::info[%clientId, 0]);
   if(!$ghosting)
      return false;

	Client::clearItemShopping(%clientId);
   %spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);
   if(!%respawn)
   {
      // initial drop
      // Added Server Version ID At Map Start - *IX*Savage1
      bottomprint(%clientId, "<jc><f1>Ecstacy <f2>" @ $HyperVersion @ " \n\nAnother great mod by: <f2>Mega Man 1024", 5); // Does not work (intentional)
   }
	if(%spawnMarker) {   
		%clientId.guiLock = "";
	 	%clientId.dead = "";
	   if(%spawnMarker == -1)
	   {
	      %spawnPos = "0 0 300";
	      %spawnRot = "0 0 0";
	   }
	   else
	   {
	      %spawnPos = GameBase::getPosition(%spawnMarker);
	      %spawnRot = GameBase::getRotation(%spawnMarker);
	   }
		$TeleSpot[Client::getTeam(%clientId)] = %spawnPos;

		if(!String::ICompare(Client::getGender(%clientId), "Male"))
	      %armor = "larmor";
	   else
	      %armor = "lfemale";

	   %pl = spawnPlayer(%armor, %spawnPos, %spawnRot);
	   echo("SPAWN: cl:" @ %clientId @ " pl:" @ %pl @ " marker:" @ %spawnMarker @ " armor:" @ %armor);
	   if(%pl != -1)
	   {
	      GameBase::setTeam(%pl, Client::getTeam(%clientId));
	      Client::setOwnedObject(%clientId, %pl);
	      Game::playerSpawned(%pl, %clientId, %armor, %respawn);
	      
	      if($matchStarted)
	         Client::setControlObject(%clientId, %pl);
	      else
	      {
	         %clientId.observerMode = "pregame";
	         Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
	         Observer::setOrbitObject(%clientId, %pl, 3, 3, 3);
	      }
	   }
      return true;
	}
	else {
		Client::sendMessage(%clientId,0,"Sorry No Respawn Positions Are Empty - Try again later ");
      return false;
	}
}

function Game::playerSpawned(%pl, %clientId, %armor)
{
	Client::setSkin(%clientId, $Client::info[%clientId, 0]);
						  
	%clientId.spawn= 1;
	%max = getNumItems();
   for(%i = 0; (%item = $spawnBuyList[%i]) != ""; %i++)
   {
		buyItem(%clientId,%item);	
		if(%item.className == Weapon) 
			%clientId.spawnWeapon = %item;
	}
	%clientId.spawn= "";
	if(%clientId.spawnWeapon != "") {
		Player::useItem(%pl,%clientId.spawnWeapon);	
   	%clientId.spawnWeapon="";
	}
} 

function Game::autoRespawn(%client)
{
	if(%client.dead == 1)
		Game::playerSpawn(%client, "true");
}

function onServerGhostAlwaysDone()
{
}

function Game::initialMissionDrop(%clientId)
{
	Client::setGuiMode(%clientId, $GuiModePlay);

   if($Server::TourneyMode)
      GameBase::setTeam(%clientId, -1);
   else
   {
      if(%clientId.observerMode == "observerFly" || %clientId.observerMode == "observerOrbit")
      {
	      %clientId.observerMode = "observerOrbit";
	      %clientId.guiLock = "";
         Observer::jump(%clientId);
         return;
      }
      %numTeams = getNumTeams();
      %curTeam = Client::getTeam(%clientId);

      if(%curTeam >= %numTeams || (%curTeam == -1 && (%numTeams < 2 || $Server::AutoAssignTeams)) )
         Game::assignClientTeam(%clientId);
   }    
	Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
   %camSpawn = Game::pickObserverSpawn(%clientId);
   Observer::setFlyMode(%clientId, GameBase::getPosition(%camSpawn), 
	   GameBase::getRotation(%camSpawn), true, true);

   if(Client::getTeam(%clientId) == -1)
   {
      %clientId.observerMode = "pickingTeam";

      if($Server::TourneyMode && ($matchStarted || $matchStarting))
      {
         %clientId.observerMode = "observerFly";
         return;
      }
      else if($Server::TourneyMode)
      {
         if($Server::TeamDamageScale)
            %td = "ENABLED";
         else
            %td = "DISABLED";
         bottomprint(%clientId, "<jc><f1>Server is running in Competition Mode\nPick a team.\nTeam damage is " @ %td, 0);
      }
      Client::buildMenu(%clientId, "Pick a team:", "InitialPickTeam");
      Client::addMenuItem(%clientId, "0Observe", -2);
      Client::addMenuItem(%clientId, "1Automatic", -1);
      for(%i = 0; %i < getNumTeams(); %i = %i + 1)
         Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
      %clientId.justConnected = "";
   }
   else 
   {
      Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
      if(%clientId.justConnected)
      {
	 // Added Internal Version Number - *IX*Savage1 -  base version number - Mega Man 1024
         centerprint(%clientId, "<jc><f2>Ecstacy " @ $EcstacyBaseVersionShort @ "\nMade by Mega Man 1024 & Tested by {J} MEGA-Man\n\n" @ $EcstacyComment1 @ "\n" @ $EcstacyComment2 @ "\n\n<f1>" @ $Ecstacy::JoinMOTD, 0);
         %clientId.observerMode = "justJoined";
         %clientId.justConnected = "";
 	// TK Tracking. - *IX*Savage1
         Insomniax_joinGame(%clientId);
      }
      else if(%clientId.observerMode == "justJoined")
      {
         centerprint(%clientId, "");
         %clientId.observerMode = "";
         Game::playerSpawn(%clientId, false);
      }
      else
         Game::playerSpawn(%clientId, false);
	}
	if($TeamEnergy[Client::getTeam(%clientId)] != "Infinite")
		$TeamEnergy[Client::getTeam(%clientId)] += $InitialPlayerEnergy;
	%clientId.teamEnergy = 0;
}

function processMenuInitialPickTeam(%clientId, %team)
{
   if($Server::TourneyMode && $matchStarted)
      %team = -2;

   if(%team == -2)
   {
      Observer::enterObserverMode(%clientId);
   }
   if(%team == -1)
   {
      Game::assignClientTeam(%clientId);
      %team = Client::getTeam(%clientId);
   }
   if(%team != -2)
   {
      GameBase::setTeam(%clientId, %team);
		if($TeamEnergy[%team] != "Infinite")
			$TeamEnergy[%team] += $InitialPlayerEnergy;
      %clientId.teamEnergy = 0;
      Client::setControlObject(%clientId, -1);
      Game::playerSpawn(%clientId, false);
   }
   if($Server::TourneyMode && !$CountdownStarted)
   {
      if(%team != -2)
      {
         bottomprint(%clientId, "<f1><jc>Press FIRE when ready.", 0);
         %clientId.notready = true;
         %clientId.notreadyCount = "";
      }
      else
      {
         bottomprint(%clientId, "", 0);
         %clientId.notready = "";
         %clientId.notreadyCount = "";
      }
   }
}

function Game::ForceTourneyMatchStart()
{
   %playerCount = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pregame")
         %playerCount++;
   }
   if(%playerCount == 0)
      return;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")   
         processMenuInitialPickTeam(%cl, -2); // throw these guys into observer
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
   }
   Server::Countdown(30);
}

function Game::CheckTourneyMatchStart()
{
   if($CountdownStarted || $matchStarted)
      return;
   
   // loop through all the clients and see if any are still notready
   %playerCount = 0;
   %notReadyCount = 0;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")
      {
         %notReady[%notReadyCount] = %cl;
         %notReadyCount++;
      }   
      else if(%cl.observerMode == "pregame")
      {
         if(%cl.notready)
         {
            %notReady[%notReadyCount] = %cl;
            %notReadyCount++;
         }
         else
            %playerCount++;
      }
   }
   if(%notReadyCount)
   {
      if(%notReadyCount == 1)
         MessageAll(0, Client::getName(%notReady[0]) @ " is holding things up!");
      else if(%notReadyCount < 4)
      {
         for(%i = 0; %i < %notReadyCount - 2; %i++)
            %str = Client::getName(%notReady[%i]) @ ", " @ %str;

         %str = %str @ Client::getName(%notReady[%i]) @ " and " @ Client::getName(%notReady[%i+1]) 
                     @ " are holding things up!";
         MessageAll(0, %str);
      }
      return;
   }

   if(%playerCount != 0)
   {
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
      Server::Countdown(30);
   }
}


function Game::checkTimeLimit()
{
   // if no timeLimit set or timeLimit set to 0,
   // just reschedule the check for a minute hence
   $timeLimitReached = false;

   if(!$Server::timeLimit)
   {
      schedule("Game::checkTimeLimit();", 60);
      return;
   }
   %curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
   if(%curTimeLeft <= 0 && $matchStarted)
   {
      echo("GAME: Timelimit reached.");
      $timeLimitReached = true;
      Server::nextMission();
   }
   else
   {
      schedule("Game::checkTimeLimit();", 20);
      UpdateClientTimes(%curTimeLeft);
   }
}

function Game::resetScores(%client)
{
	if(%client == "") {
	   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
	      %cl.scoreKills = 0;
   	   %cl.scoreDeaths = 0;
			%cl.ratio = 0;
      	%cl.score = 0;
		}
	}
	else {
      %client.scoreKills = 0;
  	   %client.scoreDeaths = 0;
		%client.ratio = 0;
     	%client.score = 0;
	}
}

function remoteSetArmor(%player, %armorType)
{
	if ($ServerCheats) {
		checkMax(Player::getClient(%player),%armorType);
	   Player::setArmor(%player, %armorType);
	}
	else if($TestCheats) {
	   Player::setArmor(%player, %armorType);
	}
}


function Game::onPlayerConnected(%playerId)
{
   %playerId.scoreKills = 0;
   %playerId.scoreDeaths = 0;
	%playerId.score = 0;
   %playerId.justConnected = true;
   $menuMode[%playerId] = "None";
   Game::refreshClientScore(%playerId);
}

function Game::assignClientTeam(%playerId)
{
   if($teamplay)
   {
      %name = Client::getName(%playerId);
      %numTeams = getNumTeams();
      if($teamPreset[%name] != "")
      {
         if($teamPreset[%name] < %numTeams)
         {
            GameBase::setTeam(%playerId, $teamPreset[%name]);
            echo(Client::getName(%playerId), " was preset to team ", $teamPreset[%name]);
            return;
         }            
      }
      %numPlayers = getNumClients();
      for(%i = 0; %i < %numTeams; %i = %i + 1)
         %numTeamPlayers[%i] = 0;

      for(%i = 0; %i < %numPlayers; %i = %i + 1)
      {
         %pl = getClientByIndex(%i);
         if(%pl != %playerId)
         {
            %team = Client::getTeam(%pl);
            %numTeamPlayers[%team] = %numTeamPlayers[%team] + 1;
         }
      }
      %leastPlayers = %numTeamPlayers[0];
      %leastTeam = 0;
      for(%i = 1; %i < %numTeams; %i = %i + 1)
      {
         if( (%numTeamPlayers[%i] < %leastPlayers) || 
            ( (%numTeamPlayers[%i] == %leastPlayers) && 
            ($teamScore[%i] < $teamScore[%leastTeam] ) ))
         {
            %leastTeam = %i;
            %leastPlayers = %numTeamPlayers;
         }
      }
      GameBase::setTeam(%playerId, %leastTeam);
      echo(Client::getName(%playerId), " was automatically assigned to team ", %leastTeam);
   }
   else
   {
      GameBase::setTeam(%playerId, 0);
   }
}

function Client::onKilled(%playerId, %killerId, %damageType)
{
   echo("GAME: kill " @ %killerId @ " " @ %playerId @ " " @ %damageType);
   %playerId.guiLock = true;
   Client::setGuiMode(%playerId, $GuiModePlay);
	if(!String::ICompare(Client::getGender(%playerId), "Male"))
   {
      %playerGender = "his";
   }
	else
	{
		%playerGender = "her";
	}
	%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
	%victimName = Client::getName(%playerId);


   if(!%killerId)
   {
      messageAll(0, strcat(%victimName, " dies."), $DeathMessageMask);
      %playerId.scoreDeaths++;
   }
   else if(%killerId == %playerId)
   {
	  %oopsMsg = sprintf($deathMsg[-2, %ridx], %victimName, %playerGender);
      messageAll(0, %oopsMsg, $DeathMessageMask);
      %playerId.scoreDeaths++;
      %playerId.score--;
      Game::refreshClientScore(%playerId);
   }
   else
   {
		if(!String::ICompare(Client::getGender(%killerId), "Male"))
		{
			%killerGender = "his";
		}
		else
		{
			%killerGender = "her";
		}
      if($teamplay && (Client::getTeam(%killerId) == Client::getTeam(%playerId)))
      {
	// Added Team Kill notification (more outstanding) - *IX*Savage1 
	bottomprint(%playerId, "<jc><f1>You have just been\n<f2>TEAM KILLED <f1>by<f2> " @ Client::getName(%killerId), 10);
	bottomprint(%killerId, "<jc><f2>YOU<f1> have just <f2>TEAM KILLED\n " @ Client::getName(%playerId), 10);
	Insomniax_setTeamKill(%playerId, %killerId); 
      messageAll(0, strcat(Client::getName(%killerId), " mows down ", %killerGender, " teammate, ", %victimName), $DeathMessageMask);
	   %killerId.scoreDeaths++;
         %playerId.score--;
         Game::refreshClientScore(%killerId);
      }
      else
      {
	     %obitMsg = sprintf($deathMsg[%damageType, %ridx], Client::getName(%killerId),
	       %victimName, %killerGender, %playerGender);
         messageAll(0, %obitMsg, $DeathMessageMask);
         %killerId.scoreKills++;
         %playerId.scoreDeaths++;  // test play mode
         %killerId.score++;
         Game::refreshClientScore(%killerId);
         Game::refreshClientScore(%playerId);
      }
   }
   Game::clientKilled(%playerId, %killerId);
}

function Game::clientKilled(%playerId, %killerId)
{
   // do nothing
}

function Client::leaveGame(%clientId)
{
   // do nothing
}

function Player::enterMissionArea(%player)
{
   echo("Player " @ %player @ " entered the mission area.");
}

function Player::leaveMissionArea(%player)
{
   echo("Player " @ %player @ " left the mission area.");
}

function GameBase::getHeatFactor(%this)
{
   return 0.0;
}

