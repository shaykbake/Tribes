// ====================== ======================== ===================== barrier.cs MegaMan 1024
// ====================== The first ever .cs file for blastwalls & forcefields!

