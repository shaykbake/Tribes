//========================================================== Wheeeeeeeeeeee
//					Vehicles
//========================================================== Mega Man 1024

FlierData EscapePod
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 3.14;
   maxPitch = 3.14;
   maxSpeed = 100;
   minSpeed = -1.5;
	maxSideSpeed = 10;
	lift = 1;
	maxAlt = 2500;
	maxVertical = 10;
	maxDamage = 0.1;
	damageLevel = {1.0, 1.0};
	accel = 0.25;

	groundDamageScale = 10.01;

	projectileType = BlasterBolt;
	reloadDelay = 0.3;
	maxEnergy = 15;
	repairRate = 0;
	fireSound = SoundFireBlaster;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Escape Pod";
};

FlierData Jetfire
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 40;
   minSpeed = -10;
	maxSideSpeed = 10;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1.32;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.7;

	groundDamageScale = 0.01;

	projectileType = MicrowaveBolt;
	reloadDelay = 0.75; //  2.5 normal fire rate
	repairRate = 0;
	fireSound = SoundFireFlierRocket;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 22;
	description = "JetFire";
};

function Jetfire::Dismount(%this, %cl)
{
//dismount...

	Player::useItem(%cl, "JetfirePack");

      %pl = Client::getOwnedObject(%cl);
	%pl.lastMount = %this;
	%pl.newMountTime = getSimTime() + 3.0;
	Player::setMountObject(%pl, -1, 0);
	%rot = GameBase::getRotation(%this);
	%rotZ = getWord(%rot,2);
	GameBase::setRotation(%pl, "0 0 " @ %rotZ);
      Client::setControlObject(%cl, %pl);

	%newPos = Vector::add(GameBase::getPosition(%cl), "0 0 -2");
	GameBase::setPosition(%pl, %newPos); //to compensate for being too high on dismount

	playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
	bottomprint(Player::getClient(%player), "<jc><f2>Bipedal <f0>mode", 5);
	if(%pl.lastWeapon != "")
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle = "";


//make sure you have the same health as in Plane mode:
	%damage = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%pl, %damage);

//then get rid of the vehicle

	$TeamItemCount[GameBase::getTeam(%this) @ $VehicleToItem[GameBase::getDataName(%this)]]--;
	GameBase::setPosition(%this, "-1000 -1000 -1000");
	GameBase::applyRadiusDamage($MineDamageType, "-1000 -1000 -1000", 500, 10000, 1000, %this);
}

FlierData EOMissile
{
	explosionId = MortarExp;
	debrisId = EODebris;
	className = "Vehicle";
    shapeFile = "rocket";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 10.5;
    maxPitch = 11.15;
    maxSpeed = 65;
    minSpeed = 40;
	maxSideSpeed = 10;
	lift = 0.85;
	maxAlt = 200;
	maxVertical = 200;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 30; // time in seconds until explodes
	accel = 2.0;

	groundDamageScale = 20.0;

	repairRate = 0;
	damageSound = ShockExplosion;
	ramDamage = 1.28;
	ramDamageType = $MissileDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Electro-Optical Missile";
};

function EOMissile::onAdd(%this)
{
 GameBase::setRechargeRate (%this,0);
 schedule("EOMissile::exhaustFuel("@%this@");",1,%this);
}

function EOMissile::onCollision(%this,%object)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

function EOMissile::jump(%this,%mom)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function EOMissile::onDestroyed (%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   %pl = Client::getOwnedObject(%cl);
   if(%pl != -1) 
   {
    Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	if(%pl.lastWeapon != "") 
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle= "";
   }
   calcRadiusDamage(%this,$MissileDamageType, 30, 0.5, 20, 10, 8, 1.2, 0.7, 300, 200); 
}

function EOMissile::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 1);
   schedule("EOMissile::exhaustFuel("@%this@");",1,%this);
  }
}

FlierData ScouterMissile
{
	explosionId = rocketExp;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
    shapeFile = "rocket";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 10.5;
    maxPitch = 11.15;
    maxSpeed = 80;
    minSpeed = 40;
	lift = 0.85;
	maxAlt = 200;
	maxVertical = 200;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 60; // time in seconds until explodes
	accel = 1.0;

	groundDamageScale = 20.0;

	repairRate = 0;

	damageSound = shockExplosion;
	ramDamage = 0.5;
	ramDamageType = $ImpactDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Electro-Optical Missile";
};

function ScouterMissile::onAdd(%this)
{
 GameBase::setRechargeRate (%this,0);
 schedule("ScouterMissile::exhaustFuel("@%this@");",1,%this);
}

function ScouterMissile::onCollision(%this,%object)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

function ScouterMissile::jump(%this,%mom)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function ScouterMissile::onDestroyed (%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   %pl = Client::getOwnedObject(%cl);
   if(%pl != -1) 
   {
    Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	if(%pl.lastWeapon != "") 
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle= "";
   }
   calcRadiusDamage(%this,$MissileDamageType, 30, 0.5, 20, 10, 8, 1.2, 0.7, 300, 200); 
}

function ScouterMissile::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 1);
   schedule("ScouterMissile::exhaustFuel("@%this@");",1,%this);
  }
}

FlierData EODisc
{
	explosionId = rocketExp;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
    shapeFile = "discb";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 10.5;
    maxPitch = 11.15;
    maxSpeed = 80;
    minSpeed = 40;
	lift = 0.85;
	maxAlt = 200;
	maxVertical = 200;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 45; // time in seconds until explodes
	accel = 1.0;

	groundDamageScale = 20.0;

	repairRate = 0;

	damageSound = rocketExplosion;
	ramDamage = 0.5;
	ramDamageType = $ExplosionDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Electro-Optical Disc";
};

function EODisc::onAdd(%this)
{
 GameBase::setRechargeRate (%this,0);
 schedule("EODisc::exhaustFuel("@%this@");",1,%this);
}

function EODisc::onCollision(%this,%object)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

function EODisc::jump(%this,%mom)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function EODisc::onDestroyed (%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   %pl = Client::getOwnedObject(%cl);
   if(%pl != -1) 
   {
    Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	if(%pl.lastWeapon != "") 
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle= "";
   }
   calcRadiusDamage(%this,$ExplosionDamageType, 30, 0.5, 20, 10, 8, 1.2, 0.7, 300, 200); 
}

function EODisc::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 1);
   schedule("EODisc::exhaustFuel("@%this@");",1,%this);
  }
}

FlierData GuidedBomb
{
	explosionId = smokeExp;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
    shapeFile = "rocket";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 0.60;
    maxPitch = 1.15;
    maxSpeed = 80;
    minSpeed = -1;
	lift = 0.85;
	maxAlt = 20;
	maxVertical = 20;
	maxDamage = 0.1;
	damageLevel = {0.15, 0.15};
	maxEnergy = 60;
	accel = 1.0;

	groundDamageScale = 1000.0;

	repairRate = 0;
	damageSound = rocketExplosion;
	ramDamage = 4.0;
	ramDamageType = $MissileDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Guiding Bomb";
};

function GuidedBomb::onAdd(%this)
{
	GameBase::setRechargeRate (%this,0);
    schedule("GuidedBomb::exhaustFuel("@%this@");",1,%this);
}

function GuidedBomb::onCollision(%this,%object)
{
}

function GuidedBomb::jump(%this,%mom)
{
	GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function GuidedBomb::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 4);
   schedule("GuidedBomb::exhaustFuel("@%this@");",5,%this);
  }
}

FlierData SurveyDrone
{
	explosionId = flashExpSmall;
	debrisId = flashDebrisSmall;
	className = "Vehicle";
    shapeFile = "camera";
    shieldShapeName = "shield_medium";
    mass = 0.001;
    drag = 1.0;
    density = 1.2;
    maxBank = 10;
    maxPitch = 10;
    maxSpeed = 12.5;
	maxSideSpeed = 10;
    minSpeed = -15;
	lift = 1.0;
	maxAlt = 50;
	maxVertical = 1;
	maxDamage = 0.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 50;
	accel = 1.0;

	groundDamageScale = 0.001;

	projectileType = BlasterBolt;
	reloadDelay = 0.2;
	repairRate = 0;
	fireSound = SoundFireBlaster;
	damageSound = SoundFlierCrash;
	ramDamage = 0.0001;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundDiscSpin;

	visibleDriver = false;
	driverPose = 22;
	description = "Survey Drone";
};

function SurveyDrone::onCollision(%this,%object)
{
}

function SurveyDrone::jump(%this,%mom)
{
	GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function SurveyDrone::onFire(%this,%slot)
{
 %client = GameBase::getControlClient(%this);
 if($TeamItemCount[GameBase::getTeam(%this) @ CameraPack] < $TeamItemMax[CameraPack] && !%this.deployed)
  {
	if(GameBase::getLOSInfo(%this,3))
	 {
		%obj = getObjectType($los::object);
		if(%obj == "SimTerrain" || %obj == "InteriorShape")
		 {
		    %this.deployed = true;
			%prot = GameBase::getRotation(%this);
			%zRot = getWord(%prot,2);
			if(Vector::dot($los::normal,"0 0 1") > 0.6) %rot = "0 0 " @ %zRot;
			else
			{
				if(Vector::dot($los::normal,"0 0 -1") > 0.6) %rot = "3.14159 0 " @ %zRot;
				else %rot = Vector::getRotation($los::normal);
			}
			%beacon = newObject("Target Beacon", "StaticShape", "DefaultBeacon", true);
            addToSet("MissionCleanup", %beacon);
			GameBase::setTeam(%beacon,GameBase::getTeam(%this));
			GameBase::setRotation(%beacon,%rot);
			GameBase::setPosition(%beacon,$los::position);
			Gamebase::setMapName(%beacon,"Target Beacon");
		    Beacon::onEnabled(%beacon);
			Client::sendMessage(%client,0,"Beacon deployed");
			playSound(SoundPickupBackpack,$los::position);
			$TeamItemCount[GameBase::getTeam(%beacon) @ "Beacon"]++;
			echo("MSG: Survey Drone deployed a Beacon");
			SurveyDrone::removeDrone(%this);
		}
	 }
  }
}

function SurveyDrone::removeDrone(%this)
{
 %client = GameBase::getControlClient(%this);
 %player = Client::getOwnedObject(%client);

  Player::setMountObject(%player, -1, 0);
  Client::setControlObject(%client,%player);
  %player.vehicle = "";

  Client::sendMessage(%client,0,"Drone beacon deployed successfully");
 
  $TeamItemCount[GameBase::getTeam(%this) @ "SurveyDronePack"]--;
  GameBase::startFadeOut(%this);
  GameBase::applyDamage(%this,$ImpactDamageType,1,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

FlierData ProbeDroid
{
	explosionId = flashExpSmall;
	debrisId = flashDebrisSmall;
	className = "Vehicle";
    shapeFile = "camera";
    shieldShapeName = "shield_medium";
    mass = 0.001;
    drag = 1.0;
    density = 1.2;
    maxBank = 10;
    maxPitch = 10;
    maxSpeed = 25;
	maxSideSpeed = 10;
    minSpeed = -15;
	lift = 1.0;
	maxAlt = 50;
	maxVertical = 1;
	maxDamage = 0.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 50;
	accel = 1.0;

	groundDamageScale = 0.001;

	projectileType = DisruptorBolt;
	reloadDelay = 0.5;
	repairRate = 0;
	fireSound = SoundLaserHit;
	damageSound = SoundFlierCrash;
	ramDamage = 0.0001;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundDiscSpin;

	visibleDriver = false;
	driverPose = 22;
	description = "Probe Droid";
};

function ProbeDroid::onCollision(%this,%object)
{
}

function ProbeDroid::jump(%this,%mom)
{
	GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function ProbeDroid::onFire(%this,%slot)
{
 %client = GameBase::getControlClient(%this);
 if($TeamItemCount[GameBase::getTeam(%this) @ CameraPack] < $TeamItemMax[CameraPack] && !%this.deployed)
  {
	if(GameBase::getLOSInfo(%this,3))
	 {
		%obj = getObjectType($los::object);
		if(%obj == "SimTerrain" || %obj == "InteriorShape")
		 {
		    %this.deployed = true;
			%prot = GameBase::getRotation(%this);
			%zRot = getWord(%prot,2);
			if(Vector::dot($los::normal,"0 0 1") > 0.6) %rot = "0 0 " @ %zRot;
			else
			{
				if(Vector::dot($los::normal,"0 0 -1") > 0.6) %rot = "3.14159 0 " @ %zRot;
				else %rot = Vector::getRotation($los::normal);
			}
			%beacon = newObject("Target Beacon", "StaticShape", "DefaultBeacon", true);
            addToSet("MissionCleanup", %beacon);
			GameBase::setTeam(%beacon,GameBase::getTeam(%this));
			GameBase::setRotation(%beacon,%rot);
			GameBase::setPosition(%beacon,$los::position);
			Gamebase::setMapName(%beacon,"Target Beacon");
		    Beacon::onEnabled(%beacon);
			Client::sendMessage(%client,0,"Beacon deployed");
			playSound(SoundPickupBackpack,$los::position);
			$TeamItemCount[GameBase::getTeam(%beacon) @ "Beacon"]++;
			echo("MSG: Survey Drone deployed a Beacon");
			ProbeDroid::removeDrone(%this);
		}
	 }
  }
}

function ProbeDroid::removeDrone(%this)
{
 %client = GameBase::getControlClient(%this);
 %player = Client::getOwnedObject(%client);

  Player::setMountObject(%player, -1, 0);
  Client::setControlObject(%client,%player);
  %player.vehicle = "";

  Client::sendMessage(%client,0,"Drone beacon deployed successfully");
 
  $TeamItemCount[GameBase::getTeam(%this) @ "ProbeDroidPack"]--;
  GameBase::startFadeOut(%this);
  GameBase::applyDamage(%this,$ImpactDamageType,1,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

FlierData Drone
{
//	explosionId = flashExpLarge;
//	debrisId = flashDebrisLarge;
	className = "Vehicle";
    shapeFile = "camera";
    shieldShapeName = "shield_medium";
    mass = 0.01;
    drag = 0.6;
    density = 0.3;
    maxBank = 1.5;
    maxPitch = 1.0;
    maxSpeed = 12;
	maxSideSpeed = 10;
    minSpeed = -10;
	lift = 0.75;
	maxAlt = 30;
	maxVertical = 10;
	maxDamage = 0.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 50;
	accel = 0.6;

	groundDamageScale = 0.001;

	repairRate = 0;
	damageSound = SoundFlierCrash;
	ramDamage = 0.0001;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundDiscSpin;

	visibleDriver = false;
	driverPose = 22;
	description = "Drone";

	deployed = false;
};

function Drone::onCollision (%this, %object)
{
}

function Drone::jump(%this,%mom)
{
	GameBase::applyDamage(%this,$ImpactDamageType,1,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function Drone::onFire(%this,%slot)
{
 %client = GameBase::getControlClient(%this);
 if($TeamItemCount[GameBase::getTeam(%this) @ CameraPack] < $TeamItemMax[CameraPack] && !%this.deployed)
  {
	if(GameBase::getLOSInfo(%this,3))
	 {
		%obj = getObjectType($los::object);
		if(%obj == "SimTerrain" || %obj == "InteriorShape")
		 {
		    %this.deployed = true;
			%prot = GameBase::getRotation(%this);
			%zRot = getWord(%prot,2);
			if(Vector::dot($los::normal,"0 0 1") > 0.6) %rot = "0 0 " @ %zRot;
			else
			{
				if(Vector::dot($los::normal,"0 0 -1") > 0.6) %rot = "3.14159 0 " @ %zRot;
				else %rot = Vector::getRotation($los::normal);
			}
			%camera = newObject("Camera","Turret",CameraTurret,true);
            addToSet("MissionCleanup", %camera);
			GameBase::setTeam(%camera,GameBase::getTeam(%this));
			GameBase::setRotation(%camera,%rot);
			GameBase::setPosition(%camera,$los::position);
			Gamebase::setMapName(%camera,"Camera#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
			Client::sendMessage(%client,0,"Camera deployed");
			playSound(SoundPickupBackpack,$los::position);
			$TeamItemCount[GameBase::getTeam(%camera) @ "CameraPack"]++;
			echo("MSG: Drone deployed a Camera");
			Drone::removeDrone(%this);
		}
	 }
  }
}

function Drone::removeDrone(%this)
{
 %client = GameBase::getControlClient(%this);
 %player = Client::getOwnedObject(%client);

  Player::setMountObject(%player, -1, 0);
  Client::setControlObject(%client,%player);
  %player.vehicle = "";

  Client::sendMessage(%client,0,"Drone camera deployed successfully");
 
  $TeamItemCount[GameBase::getTeam(%this) @ "DronePack"]--;
  GameBase::startFadeOut(%this);
  GameBase::applyDamage(%this,$ImpactDamageType,1,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

FlierData Scout
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 60;
	maxSideSpeed = 10;
   minSpeed = -5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = IonShock3;
	reloadDelay = 1;
	maxEnergy = 37.5;
	repairRate = 0;
	fireSound = CapturedTower;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Scout";
};

FlierData Arwing
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 40;
	maxSideSpeed = 10;
   minSpeed = -5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	accel = 0.4;

	groundDamageScale = 1.7;

	projectileType = Disruptorbolt;
	reloadDelay = 0.45;
	maxEnergy = 50;
	repairRate = 0;
	fireSound = SoundLaserHit;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Arwing";
};

FlierData SkyCutter
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 128;
	maxSideSpeed = 32;
   minSpeed = -8;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = pulseBolt;
	reloadDelay = 0.15;
	maxEnergy = 37.5;
	repairRate = 0;
	fireSound = SoundFireBlaster;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Sky Cutter";
};

FlierData StarHammer
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 35;
	maxSideSpeed = 10;
   minSpeed = -5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	accel = 0.6;

	groundDamageScale = 0.01;

	projectileType = Implosionshell;
	reloadDelay = 1.5;
	maxEnergy = 37.5;
	repairRate = 0;
	fireSound = SoundFireMortar;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Star Hammer";
};

FlierData Explorer 
{	
	explosionId = flashExpsmall;
	debrisId = flashDebrissmall;
	classname = "Vehicle";
	shapeFile = "flyer";
	shieldShapeName = "shield_medium";
	mass = 1.0;
	drag = 0.1;
	density = 1.0;
	maxBank = 12.5;
	maxPitch = 12.0;
	maxSpeed = 65;
	minSpeed = -15;
	maxSideSpeed = 10;

	lift = 1.0;
	maxAlt = 100000;
	maxVertical = 0.000000000000000001;
	maxDamage = 0.55;
	
	damageLevel = {1.0, 1.0};
	maxEnergy = 80;
	accel = 1.5;
	groundDamageScale = 0.5;
	projectileType = flier2Bullet;
	reloadDelay = 0.02;
	repairRate = 0;
	fireSound = SoundFireChain;
	damageSound = SoundFlierCrash;
	ramDamage = 0.65;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;
	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;
	visibleDriver = true;
	driverPose = 22;
	description = "Explorer";
};

FlierData Skyranger
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 45;
	maxSideSpeed = 10;
   minSpeed = -10;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = DiscShell;
	reloadDelay = 0.45;
	repairRate = 0;
	fireSound = SoundFireDisc;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Skyranger";
};

FlierData Icarus
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 32;
	maxSideSpeed = 10;
   minSpeed = -2;
	lift = 1;
	maxAlt = 25000;
	maxVertical = 5;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.4;

	groundDamageScale = 0.1;

	projectileType = tachyBolt;
	reloadDelay = 0.53;
	repairRate = 0;
	fireSound = SoundMortarTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Icarus";
};

FlierData Avenger
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 50;
	maxSideSpeed = 10;
   minSpeed = -7.5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.4;

	groundDamageScale = 0.1;

	projectileType = Reaver;
	reloadDelay = 1;
	repairRate = 0;
	fireSound = SoundMissileTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Avenger";
};

FlierData StarFighter
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 50;
	maxSideSpeed = 10;
   minSpeed = -7.5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 1;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = plasmabolt;
	reloadDelay = 0.45;
	repairRate = 0;
	fireSound = SoundFirePlasma;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "StarFighter";
};

FlierData LAPC
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 25;
   minSpeed = -1;
	lift = 0.5;
	maxAlt = 15;
	maxVertical = 9;
	maxDamage = 1.5;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	
	projectileType = Reaver;
	fireSound = SoundMissileTurretFire;
	reloadDelay = 1.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

FlierData HAPC
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 25;								   
   minSpeed = -1;
	lift = 0.35;
	maxAlt = 15;
	maxVertical = 6;
	maxDamage = 2.0;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.125;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	projectileType = AtomicBomb; //WereWolf
	fireSound = SoundFireMortar;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = false;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

FlierData HoverTank
{
	explosionId = LargeShockwave;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.9;
   maxPitch = 1;
   maxSpeed = 25;								   
   minSpeed = -1;
	lift = 0.75;
	maxAlt = 15;
	maxVertical = 0.001;
	maxDamage = 3.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.125;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	projectileType = Fusionbolt2; 
	fireSound = SoundPlasmaTurretFire;
	reloadDelay = 0.5;
	damageSound = SoundTankCrash;
	visibleToSensor = false;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

FlierData Bomber
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 10.5;
   maxPitch = 10.5;
   maxSpeed = 50;
	maxSideSpeed = 10;
   minSpeed = -2;
	lift = 0.75;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 0.6;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.4;

	groundDamageScale = 1.0;

	projectileType = Implosionshell2;
	reloadDelay = 1.5;
	repairRate = 0;
	fireSound = SoundFireMortar;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Bomber";
};

// StealthLevel = Radius around Driver for Jamming - *IX*Savage1
$StealthLevel = 10;

FlierData SLAPC
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 25;
   minSpeed = -1;
	lift = 0.5;
	maxAlt = 15;
	maxVertical = 6;
	maxDamage = 1.5;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	projectileType = IonShock2;
	fireSound = CapturedTower;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
	description = "Stealth LPC";
};
//----------------------------------------------------------------------------

//Escape pod damage counters
$DamageScale[EscapePod, $ImpactDamageType] = 1.0;
$DamageScale[EscapePod, $BulletDamageType] = 1.0;
$DamageScale[EscapePod, $PlasmaDamageType] = 1.0;
$DamageScale[EscapePod, $EnergyDamageType] = 1.0;
$DamageScale[EscapePod, $ExplosionDamageType] = 1.0;
$DamageScale[EscapePod, $ShrapnelDamageType] = 1.0;
$DamageScale[EscapePod, $DebrisDamageType] = 1.0;
$DamageScale[EscapePod, $MissileDamageType] = 1.0;
$DamageScale[EscapePod, $LaserDamageType] = 1.0;
$DamageScale[EscapePod, $MortarDamageType] = 1.0;
$DamageScale[EscapePod, $BlasterDamageType] = 0.5;
$DamageScale[EscapePod, $ElectricityDamageType] = 1.0;
$DamageScale[EscapePod, $MineDamageType]        = 1.0;
$DamageScale[EscapePod, $FusionDamageType] = 1.5;
$DamageScale[EscapePod, $DisruptorDamageType] = 1.0;
$DamageScale[EscapePod, $IonDamageType] = 2.2;
$DamageScale[EscapePod, $VulcanDamageType] = 1.0;
$DamageScale[EscapePod, $ShotgunDamageType] = 1.0;
$DamageScale[EscapePod, $NukeDamageType] = 10.0;
$DamageScale[EscapePod, $ZapDamageType] = 2.0;
$DamageScale[EscapePod, $HeatDamageType] = 1.0;
$DamageScale[EscapePod, $ATCDamageType] = 1.0;
$DamageScale[EscapePod, $StarDamageType] = 1.0;
$DamageScale[EscapePod, $ShockwaveDamageType] = 1.0;
$DamageScale[EscapePod, $PBWDamageType] = 1.0;
$DamageScale[EscapePod, $FlameDamageType] = 1.0;
$DamageScale[EscapePod, $IceDamageType] = 1.0;
$DamageScale[EscapePod, $BurstDamageType] = 1.0;
$DamageScale[EscapePod, $ReaverDamageType] = 1.0;
$DamageScale[EscapePod, $RifleDamageType] = 1.0;
$DamageScale[EscapePod, $MassShotgunDamageType] = 1.0;
$DamageScale[EscapePod, $GaussDamageType] = 1.0;
$DamageScale[EscapePod, $MBDamageType] = 1.0;
$DamageScale[EscapePod, $NullDamageType] = 1.0;

$DamageScale[EOMissile, $ImpactDamageType] = 1.0;
$DamageScale[EOMissile, $BulletDamageType] = 1.0;
$DamageScale[EOMissile, $PlasmaDamageType] = 1.0;
$DamageScale[EOMissile, $EnergyDamageType] = 1.0;
$DamageScale[EOMissile, $ExplosionDamageType] = 1.0;
$DamageScale[EOMissile, $ShrapnelDamageType] = 1.0;
$DamageScale[EOMissile, $DebrisDamageType] = 1.0;
$DamageScale[EOMissile, $MissileDamageType] = 1.0;
$DamageScale[EOMissile, $LaserDamageType] = 0.5;
$DamageScale[EOMissile, $MortarDamageType] = 1.0;
$DamageScale[EOMissile, $BlasterDamageType] = 0.5;
$DamageScale[EOMissile, $ElectricityDamageType] = 1.0;
$DamageScale[EOMissile, $MineDamageType]        = 1.0;

$DamageScale[EODisc, $ImpactDamageType] = 1.0;
$DamageScale[EODisc, $BulletDamageType] = 1.0;
$DamageScale[EODisc, $PlasmaDamageType] = 1.0;
$DamageScale[EODisc, $EnergyDamageType] = 1.0;
$DamageScale[EODisc, $ExplosionDamageType] = 1.0;
$DamageScale[EODisc, $ShrapnelDamageType] = 1.0;
$DamageScale[EODisc, $DebrisDamageType] = 1.0;
$DamageScale[EODisc, $MissileDamageType] = 1.0;
$DamageScale[EODisc, $LaserDamageType] = 0.5;
$DamageScale[EODisc, $MortarDamageType] = 1.0;
$DamageScale[EODisc, $BlasterDamageType] = 0.5;
$DamageScale[EODisc, $ElectricityDamageType] = 1.0;
$DamageScale[EODisc, $MineDamageType]        = 1.0;

$DamageScale[ScouterMissile, $ImpactDamageType] = 1.0;
$DamageScale[ScouterMissile, $BulletDamageType] = 1.0;
$DamageScale[ScouterMissile, $PlasmaDamageType] = 1.0;
$DamageScale[ScouterMissile, $EnergyDamageType] = 1.0;
$DamageScale[ScouterMissile, $ExplosionDamageType] = 1.0;
$DamageScale[ScouterMissile, $ShrapnelDamageType] = 1.0;
$DamageScale[ScouterMissile, $DebrisDamageType] = 1.0;
$DamageScale[ScouterMissile, $MissileDamageType] = 1.0;
$DamageScale[ScouterMissile, $LaserDamageType] = 0.5;
$DamageScale[ScouterMissile, $MortarDamageType] = 1.0;
$DamageScale[ScouterMissile, $BlasterDamageType] = 0.5;
$DamageScale[ScouterMissile, $ElectricityDamageType] = 1.0;
$DamageScale[ScouterMissile, $MineDamageType]        = 1.0;

$DamageScale[SurveyDrone, $ImpactDamageType] = 1.0;
$DamageScale[SurveyDrone, $BulletDamageType] = 1.0;
$DamageScale[SurveyDrone, $PlasmaDamageType] = 1.0;
$DamageScale[SurveyDrone, $EnergyDamageType] = 1.0;
$DamageScale[SurveyDrone, $ExplosionDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShrapnelDamageType] = 1.0;
$DamageScale[SurveyDrone, $DebrisDamageType] = 1.0;
$DamageScale[SurveyDrone, $MissileDamageType] = 1.0;
$DamageScale[SurveyDrone, $LaserDamageType] = 1.0;
$DamageScale[SurveyDrone, $MortarDamageType] = 1.0;
$DamageScale[SurveyDrone, $BlasterDamageType] = 0.5;
$DamageScale[SurveyDrone, $ElectricityDamageType] = 1.0;
$DamageScale[SurveyDrone, $MineDamageType]        = 1.0;
$DamageScale[SurveyDrone, $FusionDamageType] = 1.5;
$DamageScale[SurveyDrone, $DisruptorDamageType] = 1.0;
$DamageScale[SurveyDrone, $IonDamageType] = 2.2;
$DamageScale[SurveyDrone, $VulcanDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShotgunDamageType] = 1.0;
$DamageScale[SurveyDrone, $NukeDamageType] = 10.0;
$DamageScale[SurveyDrone, $ZapDamageType] = 2.0;
$DamageScale[SurveyDrone, $HeatDamageType] = 1.0;
$DamageScale[SurveyDrone, $ATCDamageType] = 1.0;
$DamageScale[SurveyDrone, $StarDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShockwaveDamageType] = 1.0;
$DamageScale[SurveyDrone, $PBWDamageType] = 1.0;
$DamageScale[SurveyDrone, $FlameDamageType] = 1.0;
$DamageScale[SurveyDrone, $IceDamageType] = 1.0;
$DamageScale[SurveyDrone, $BurstDamageType] = 1.0;
$DamageScale[SurveyDrone, $ReaverDamageType] = 1.0;
$DamageScale[SurveyDrone, $RifleDamageType] = 1.0;
$DamageScale[SurveyDrone, $MassShotgunDamageType] = 1.0;
$DamageScale[SurveyDrone, $GaussDamageType] = 1.0;
$DamageScale[SurveyDrone, $MBDamageType] = 1.0;
$DamageScale[SurveyDrone, $NullDamageType] = 1.0;

$DamageScale[ProbeDroid, $ImpactDamageType] = 1.0;
$DamageScale[ProbeDroid, $BulletDamageType] = 1.0;
$DamageScale[ProbeDroid, $PlasmaDamageType] = 1.0;
$DamageScale[ProbeDroid, $EnergyDamageType] = 1.0;
$DamageScale[ProbeDroid, $ExplosionDamageType] = 1.0;
$DamageScale[ProbeDroid, $ShrapnelDamageType] = 1.0;
$DamageScale[ProbeDroid, $DebrisDamageType] = 1.0;
$DamageScale[ProbeDroid, $MissileDamageType] = 1.0;
$DamageScale[ProbeDroid, $LaserDamageType] = 1.0;
$DamageScale[ProbeDroid, $MortarDamageType] = 1.0;
$DamageScale[ProbeDroid, $BlasterDamageType] = 0.5;
$DamageScale[ProbeDroid, $ElectricityDamageType] = 1.0;
$DamageScale[ProbeDroid, $MineDamageType]        = 1.0;
$DamageScale[ProbeDroid, $FusionDamageType] = 1.5;
$DamageScale[ProbeDroid, $DisruptorDamageType] = 1.0;
$DamageScale[ProbeDroid, $IonDamageType] = 2.2;
$DamageScale[ProbeDroid, $VulcanDamageType] = 1.0;
$DamageScale[ProbeDroid, $ShotgunDamageType] = 1.0;
$DamageScale[ProbeDroid, $NukeDamageType] = 10.0;
$DamageScale[ProbeDroid, $ZapDamageType] = 2.0;
$DamageScale[ProbeDroid, $HeatDamageType] = 1.0;
$DamageScale[ProbeDroid, $ATCDamageType] = 1.0;
$DamageScale[ProbeDroid, $StarDamageType] = 1.0;
$DamageScale[ProbeDroid, $ShockwaveDamageType] = 1.0;
$DamageScale[ProbeDroid, $PBWDamageType] = 1.0;
$DamageScale[ProbeDroid, $FlameDamageType] = 1.0;
$DamageScale[ProbeDroid, $IceDamageType] = 1.0;
$DamageScale[ProbeDroid, $BurstDamageType] = 1.0;
$DamageScale[ProbeDroid, $ReaverDamageType] = 1.0;
$DamageScale[ProbeDroid, $RifleDamageType] = 1.0;
$DamageScale[ProbeDroid, $MassShotgunDamageType] = 1.0;
$DamageScale[ProbeDroid, $GaussDamageType] = 1.0;
$DamageScale[ProbeDroid, $MBDamageType] = 1.0;
$DamageScale[ProbeDroid, $NullDamageType] = 1.0;

$DamageScale[Bomber, $ImpactDamageType] = 1.0;
$DamageScale[Bomber, $BulletDamageType] = 1.0;
$DamageScale[Bomber, $PlasmaDamageType] = 1.0;
$DamageScale[Bomber, $EnergyDamageType] = 1.0;
$DamageScale[Bomber, $ExplosionDamageType] = 1.0;
$DamageScale[Bomber, $ShrapnelDamageType] = 1.0;
$DamageScale[Bomber, $DebrisDamageType] = 1.0;
$DamageScale[Bomber, $MissileDamageType] = 1.0;
$DamageScale[Bomber, $LaserDamageType] = 1.0;
$DamageScale[Bomber, $MortarDamageType] = 1.0;
$DamageScale[Bomber, $BlasterDamageType] = 0.5;
$DamageScale[Bomber, $ElectricityDamageType] = 1.0;
$DamageScale[Bomber, $MineDamageType]        = 1.0;
$DamageScale[Bomber, $FusionDamageType] = 1.5;
$DamageScale[Bomber, $DisruptorDamageType] = 1.0;
$DamageScale[Bomber, $IonDamageType] = 1.0;
$DamageScale[Bomber, $VulcanDamageType] = 1.0;
$DamageScale[Bomber, $ShotgunDamageType] = 1.0;
$DamageScale[Bomber, $NukeDamageType] = 10.0;
$DamageScale[Bomber, $ZapDamageType] = 1.0;
$DamageScale[Bomber, $HeatDamageType] = 1.0;
$DamageScale[Bomber, $ATCDamageType] = 1.0;
$DamageScale[Bomber, $StarDamageType] = 1.0;
$DamageScale[Bomber, $ShockwaveDamageType] = 1.0;
$DamageScale[Bomber, $PBWDamageType] = 2.55;
$DamageScale[Bomber, $FlameDamageType] = 1.0;
$DamageScale[Bomber, $IceDamageType] = 1.0;
$DamageScale[Bomber, $BurstDamageType] = 1.0;
$DamageScale[Bomber, $ReaverDamageType] = 1.0;
$DamageScale[Bomber, $RifleDamageType] = 1.0;
$DamageScale[Bomber, $MassShotgunDamageType] = 1.0;
$DamageScale[Bomber, $GaussDamageType] = 1.0;
$DamageScale[Bomber, $MBDamageType] = 1.0;
$DamageScale[Bomber, $NullDamageType] = 1.0;

$DamageScale[Scout, $ImpactDamageType] = 1.0;
$DamageScale[Scout, $BulletDamageType] = 1.0;
$DamageScale[Scout, $PlasmaDamageType] = 1.0;
$DamageScale[Scout, $EnergyDamageType] = 1.0;
$DamageScale[Scout, $ExplosionDamageType] = 1.0;
$DamageScale[Scout, $ShrapnelDamageType] = 1.0;
$DamageScale[Scout, $DebrisDamageType] = 1.0;
$DamageScale[Scout, $MissileDamageType] = 1.0;
$DamageScale[Scout, $LaserDamageType] = 1.0;
$DamageScale[Scout, $MortarDamageType] = 1.0;
$DamageScale[Scout, $BlasterDamageType] = 0.5;
$DamageScale[Scout, $ElectricityDamageType] = 1.0;
$DamageScale[Scout, $MineDamageType]        = 1.0;
$DamageScale[Scout, $FusionDamageType] = 1.5;
$DamageScale[Scout, $DisruptorDamageType] = 1.0;
$DamageScale[Scout, $SonicDamageType] = 5.0;
$DamageScale[Scout, $IonDamageType] = 2.2;
$DamageScale[Scout, $DistortionDamageType] = 7.2;
$DamageScale[Scout, $EMPDamageType] = 0.0;
$DamageScale[Scout, $PulseDamageType] = 1.0;
$DamageScale[Scout, $SniperDamageType] = 1.0;
$DamageScale[Scout, $VulcanDamageType] = 1.0;
$DamageScale[Scout, $ShotgunDamageType] = 1.0;
$DamageScale[Scout, $NukeDamageType] = 10.0;
$DamageScale[Scout, $ZapDamageType] = 2.0;
$DamageScale[Scout, $RepairDamageType] = 1.0;
$DamageScale[Scout, $HeatDamageType] = 1.0;
$DamageScale[Scout, $PhotonDamageType] = 1.0;
$DamageScale[Scout, $PistolDamageType] = 1.0;
$DamageScale[Scout, $ATCDamageType] = 1.0;
$DamageScale[Scout, $StarDamageType] = 1.0;
$DamageScale[Scout, $ZapMortarDamageType] = 1.0;
$DamageScale[Scout, $ShockwaveDamageType] = 1.0;
$DamageScale[Scout, $QuantumDamageType] = 1.0;
$DamageScale[Scout, $BusterDamageType] = 1.0;
$DamageScale[Scout, $FluxDamageType] = 1.0;
$DamageScale[Scout, $FlierBombDamageType] = 1.0;
$DamageScale[Scout, $BustedDamageType] = 1.0;
$DamageScale[Scout, $PBWDamageType] = 1.0;
$DamageScale[Scout, $FlameDamageType] = 1.0;
$DamageScale[Scout, $IceDamageType] = 1.0;
$DamageScale[Scout, $RPGDamageType] = 1.0;
$DamageScale[Scout, $RPMDamageType] = 1.0;
$DamageScale[Scout, $EMPDamageType] = 0.5;
$DamageScale[Scout, $MethaneDamageType] = 1.0;
$DamageScale[Scout, $BurstDamageType] = 1.0;
$DamageScale[Scout, $ReaverDamageType] = 1.0;
$DamageScale[Scout, $RifleDamageType] = 1.0;
$DamageScale[Scout, $MassShotgunDamageType] = 1.0;
$DamageScale[Scout, $AutogunDamageType] = 1.0;
$DamageScale[Scout, $PistolDamageType] = 1.0;
$DamageScale[Scout, $AutogunDamageType] = 1.0;
$DamageScale[Scout, $GaussDamageType] = 1.0;
$DamageScale[Scout, $MBDamageType] = 1.0;
$DamageScale[Scout, $CutterDamageType] = 1.0;
$DamageScale[Scout, $NullDamageType] = 1.0;

$DamageScale[Explorer, $ImpactDamageType] = 1.0;
$DamageScale[Explorer, $BulletDamageType] = 1.0;
$DamageScale[Explorer, $PlasmaDamageType] = 1.0;
$DamageScale[Explorer, $EnergyDamageType] = 1.0;
$DamageScale[Explorer, $ExplosionDamageType] = 1.0;
$DamageScale[Explorer, $ShrapnelDamageType] = 1.0;
$DamageScale[Explorer, $DebrisDamageType] = 1.0;
$DamageScale[Explorer, $MissileDamageType] = 1.0;
$DamageScale[Explorer, $LaserDamageType] = 1.0;
$DamageScale[Explorer, $MortarDamageType] = 1.0;
$DamageScale[Explorer, $BlasterDamageType] = 0.5;
$DamageScale[Explorer, $ElectricityDamageType] = 1.0;
$DamageScale[Explorer, $MineDamageType]        = 1.0;
$DamageScale[Explorer, $FusionDamageType] = 1.5;
$DamageScale[Explorer, $DisruptorDamageType] = 1.0;
$DamageScale[Explorer, $IonDamageType] = 1.0;
$DamageScale[Explorer, $VulcanDamageType] = 1.0;
$DamageScale[Explorer, $ShotgunDamageType] = 1.0;
$DamageScale[Explorer, $NukeDamageType] = 10.0;
$DamageScale[Explorer, $ZapDamageType] = 1.0;
$DamageScale[Explorer, $HeatDamageType] = 1.0;
$DamageScale[Explorer, $ATCDamageType] = 1.0;
$DamageScale[Explorer, $StarDamageType] = 1.0;
$DamageScale[Explorer, $ShockwaveDamageType] = 1.0;
$DamageScale[Explorer, $PBWDamageType] = 2.55;
$DamageScale[Explorer, $FlameDamageType] = 1.0;
$DamageScale[Explorer, $IceDamageType] = 1.0;
$DamageScale[Explorer, $BurstDamageType] = 1.0;
$DamageScale[Explorer, $ReaverDamageType] = 1.0;
$DamageScale[Explorer, $RifleDamageType] = 1.0;
$DamageScale[Explorer, $MassShotgunDamageType] = 1.0;
$DamageScale[Explorer, $GaussDamageType] = 1.0;
$DamageScale[Explorer, $MBDamageType] = 1.0;
$DamageScale[Explorer, $NullDamageType] = 1.0;

$DamageScale[StarFighter, $ImpactDamageType] = 1.0;
$DamageScale[StarFighter, $BulletDamageType] = 1.0;
$DamageScale[StarFighter, $PlasmaDamageType] = 1.0;
$DamageScale[StarFighter, $EnergyDamageType] = 1.0;
$DamageScale[StarFighter, $ExplosionDamageType] = 1.0;
$DamageScale[StarFighter, $ShrapnelDamageType] = 1.0;
$DamageScale[StarFighter, $DebrisDamageType] = 1.0;
$DamageScale[StarFighter, $MissileDamageType] = 1.0;
$DamageScale[StarFighter, $LaserDamageType] = 1.0;
$DamageScale[StarFighter, $MortarDamageType] = 1.0;
$DamageScale[StarFighter, $BlasterDamageType] = 0.5;
$DamageScale[StarFighter, $ElectricityDamageType] = 1.0;
$DamageScale[StarFighter, $MineDamageType]        = 1.0;
$DamageScale[StarFighter, $FusionDamageType] = 1.5;
$DamageScale[StarFighter, $DisruptorDamageType] = 1.0;
$DamageScale[StarFighter, $IonDamageType] = 1.0;
$DamageScale[StarFighter, $VulcanDamageType] = 1.0;
$DamageScale[StarFighter, $ShotgunDamageType] = 1.0;
$DamageScale[StarFighter, $NukeDamageType] = 10.0;
$DamageScale[StarFighter, $ZapDamageType] = 1.0;
$DamageScale[StarFighter, $HeatDamageType] = 1.0;
$DamageScale[StarFighter, $ATCDamageType] = 1.0;
$DamageScale[StarFighter, $StarDamageType] = 1.0;
$DamageScale[StarFighter, $ShockwaveDamageType] = 1.0;
$DamageScale[StarFighter, $PBWDamageType] = 2.55;
$DamageScale[StarFighter, $FlameDamageType] = 1.0;
$DamageScale[StarFighter, $IceDamageType] = 1.0;
$DamageScale[StarFighter, $BurstDamageType] = 1.0;
$DamageScale[StarFighter, $ReaverDamageType] = 1.0;
$DamageScale[StarFighter, $RifleDamageType] = 1.0;
$DamageScale[StarFighter, $MassShotgunDamageType] = 1.0;
$DamageScale[StarFighter, $GaussDamageType] = 1.0;
$DamageScale[StarFighter, $MBDamageType] = 1.0;
$DamageScale[StarFighter, $NullDamageType] = 1.0;

$DamageScale[Icarus, $ImpactDamageType] = 1.0;
$DamageScale[Icarus, $BulletDamageType] = 1.0;
$DamageScale[Icarus, $PlasmaDamageType] = 1.0;
$DamageScale[Icarus, $EnergyDamageType] = 1.0;
$DamageScale[Icarus, $ExplosionDamageType] = 1.0;
$DamageScale[Icarus, $ShrapnelDamageType] = 1.0;
$DamageScale[Icarus, $DebrisDamageType] = 1.0;
$DamageScale[Icarus, $MissileDamageType] = 1.0;
$DamageScale[Icarus, $LaserDamageType] = 1.0;
$DamageScale[Icarus, $MortarDamageType] = 1.0;
$DamageScale[Icarus, $BlasterDamageType] = 0.5;
$DamageScale[Icarus, $ElectricityDamageType] = 1.0;
$DamageScale[Icarus, $MineDamageType]        = 1.0;
$DamageScale[Icarus, $FusionDamageType] = 1.5;
$DamageScale[Icarus, $DisruptorDamageType] = 1.0;
$DamageScale[Icarus, $IonDamageType] = 1.0;
$DamageScale[Icarus, $VulcanDamageType] = 1.0;
$DamageScale[Icarus, $ShotgunDamageType] = 1.0;
$DamageScale[Icarus, $NukeDamageType] = 10.0;
$DamageScale[Icarus, $ZapDamageType] = 1.0;
$DamageScale[Icarus, $HeatDamageType] = 1.0;
$DamageScale[Icarus, $ATCDamageType] = 1.0;
$DamageScale[Icarus, $StarDamageType] = 1.0;
$DamageScale[Icarus, $ShockwaveDamageType] = 1.0;
$DamageScale[Icarus, $PBWDamageType] = 2.55;
$DamageScale[Icarus, $FlameDamageType] = 1.0;
$DamageScale[Icarus, $IceDamageType] = 1.0;
$DamageScale[Icarus, $BurstDamageType] = 1.0;
$DamageScale[Icarus, $ReaverDamageType] = 1.0;
$DamageScale[Icarus, $RifleDamageType] = 1.0;
$DamageScale[Icarus, $MassShotgunDamageType] = 1.0;
$DamageScale[Icarus, $GaussDamageType] = 1.0;
$DamageScale[Icarus, $MBDamageType] = 1.0;
$DamageScale[Icarus, $NullDamageType] = 1.0;

$DamageScale[Skyranger, $ImpactDamageType] = 1.0;
$DamageScale[Skyranger, $BulletDamageType] = 1.0;
$DamageScale[Skyranger, $PlasmaDamageType] = 1.0;
$DamageScale[Skyranger, $EnergyDamageType] = 1.0;
$DamageScale[Skyranger, $ExplosionDamageType] = 1.0;
$DamageScale[Skyranger, $ShrapnelDamageType] = 1.0;
$DamageScale[Skyranger, $DebrisDamageType] = 1.0;
$DamageScale[Skyranger, $MissileDamageType] = 1.0;
$DamageScale[Skyranger, $LaserDamageType] = 1.0;
$DamageScale[Skyranger, $MortarDamageType] = 1.0;
$DamageScale[Skyranger, $BlasterDamageType] = 0.5;
$DamageScale[Skyranger, $ElectricityDamageType] = 1.0;
$DamageScale[Skyranger, $MineDamageType]        = 1.0;
$DamageScale[Skyranger, $FusionDamageType] = 1.5;
$DamageScale[Skyranger, $DisruptorDamageType] = 1.0;
$DamageScale[Skyranger, $IonDamageType] = 1.0;
$DamageScale[Skyranger, $VulcanDamageType] = 1.0;
$DamageScale[Skyranger, $ShotgunDamageType] = 1.0;
$DamageScale[Skyranger, $NukeDamageType] = 10.0;
$DamageScale[Skyranger, $ZapDamageType] = 1.0;
$DamageScale[Skyranger, $HeatDamageType] = 1.0;
$DamageScale[Skyranger, $ATCDamageType] = 1.0;
$DamageScale[Skyranger, $StarDamageType] = 1.0;
$DamageScale[Skyranger, $ShockwaveDamageType] = 1.0;
$DamageScale[Skyranger, $PBWDamageType] = 2.55;
$DamageScale[Skyranger, $FlameDamageType] = 1.0;
$DamageScale[Skyranger, $IceDamageType] = 1.0;
$DamageScale[Skyranger, $BurstDamageType] = 1.0;
$DamageScale[Skyranger, $ReaverDamageType] = 1.0;
$DamageScale[Skyranger, $RifleDamageType] = 1.0;
$DamageScale[Skyranger, $MassShotgunDamageType] = 1.0;
$DamageScale[Skyranger, $GaussDamageType] = 1.0;
$DamageScale[Skyranger, $MBDamageType] = 1.0;
$DamageScale[Skyranger, $NullDamageType] = 1.0;

$DamageScale[LAPC, $ImpactDamageType] = 1.0;
$DamageScale[LAPC, $BulletDamageType] = 1.0;
$DamageScale[LAPC, $PlasmaDamageType] = 1.0;
$DamageScale[LAPC, $EnergyDamageType] = 1.0;
$DamageScale[LAPC, $ExplosionDamageType] = 1.0;
$DamageScale[LAPC, $ShrapnelDamageType] = 1.0;
$DamageScale[LAPC, $DebrisDamageType] = 1.0;
$DamageScale[LAPC, $MissileDamageType] = 1.0;
$DamageScale[LAPC, $LaserDamageType] = 0.5;
$DamageScale[LAPC, $MortarDamageType] = 0.7;
$DamageScale[LAPC, $BlasterDamageType] = 0.5;
$DamageScale[LAPC, $ElectricityDamageType] = 1.0;
$DamageScale[LAPC, $MineDamageType]        = 1.0;
$DamageScale[LAPC, $FusionDamageType] = 1.5;
$DamageScale[LAPC, $DisruptorDamageType] = 1.0;
$DamageScale[LAPC, $IonDamageType] = 1.0;
$DamageScale[LAPC, $VulcanDamageType] = 1.0;
$DamageScale[LAPC, $ShotgunDamageType] = 1.0;
$DamageScale[LAPC, $NukeDamageType] = 10.0;
$DamageScale[LAPC, $ZapDamageType] = 1.0;
$DamageScale[LAPC, $HeatDamageType] = 1.0;
$DamageScale[LAPC, $ATCDamageType] = 1.0;
$DamageScale[LAPC, $StarDamageType] = 1.0;
$DamageScale[LAPC, $ShockwaveDamageType] = 1.0;
$DamageScale[LAPC, $PBWDamageType] = 2.55;
$DamageScale[LAPC, $FlameDamageType] = 1.0;
$DamageScale[LAPC, $IceDamageType] = 1.0;
$DamageScale[LAPC, $BurstDamageType] = 1.0;
$DamageScale[LAPC, $ReaverDamageType] = 1.0;
$DamageScale[LAPC, $RifleDamageType] = 1.0;
$DamageScale[LAPC, $MassShotgunDamageType] = 1.0;
$DamageScale[LAPC, $GaussDamageType] = 1.0;
$DamageScale[LAPC, $MBDamageType] = 1.0;
$DamageScale[LAPC, $NullDamageType] = 1.0;

$DamageScale[HAPC, $ImpactDamageType] = 1.0;
$DamageScale[HAPC, $BulletDamageType] = 1.0;
$DamageScale[HAPC, $PlasmaDamageType] = 1.0;
$DamageScale[HAPC, $EnergyDamageType] = 1.0;
$DamageScale[HAPC, $ExplosionDamageType] = 1.0;
$DamageScale[HAPC, $ShrapnelDamageType] = 1.0;
$DamageScale[HAPC, $DebrisDamageType] = 1.0;
$DamageScale[HAPC, $MissileDamageType] = 1.0;
$DamageScale[HAPC, $LaserDamageType] = 0.5;
$DamageScale[HAPC, $MortarDamageType] = 1.0;
$DamageScale[HAPC, $BlasterDamageType] = 0.5;
$DamageScale[HAPC, $ElectricityDamageType] = 1.0;
$DamageScale[HAPC, $MineDamageType]        = 1.0;
$DamageScale[HAPC, $FusionDamageType] = 1.5;
$DamageScale[HAPC, $DisruptorDamageType] = 1.0;
$DamageScale[HAPC, $IonDamageType] = 1.0;
$DamageScale[HAPC, $VulcanDamageType] = 1.0;
$DamageScale[HAPC, $ShotgunDamageType] = 1.0;
$DamageScale[HAPC, $NukeDamageType] = 10.0;
$DamageScale[HAPC, $ZapDamageType] = 1.0;
$DamageScale[HAPC, $HeatDamageType] = 1.0;
$DamageScale[HAPC, $ATCDamageType] = 1.0;
$DamageScale[HAPC, $StarDamageType] = 1.0;
$DamageScale[HAPC, $ShockwaveDamageType] = 1.0;
$DamageScale[HAPC, $PBWDamageType] = 2.55;
$DamageScale[HAPC, $FlameDamageType] = 1.0;
$DamageScale[HAPC, $IceDamageType] = 1.0;
$DamageScale[HAPC, $BurstDamageType] = 1.0;
$DamageScale[HAPC, $ReaverDamageType] = 1.0;
$DamageScale[HAPC, $RifleDamageType] = 1.0;
$DamageScale[HAPC, $MassShotgunDamageType] = 1.0;
$DamageScale[HAPC, $GaussDamageType] = 1.0;
$DamageScale[HAPC, $MBDamageType] = 1.0;
$DamageScale[HAPC, $NullDamageType] = 1.0;

$DamageScale[HoverTank, $ImpactDamageType] = 1.0;
$DamageScale[HoverTank, $BulletDamageType] = 1.0;
$DamageScale[HoverTank, $PlasmaDamageType] = 1.0;
$DamageScale[HoverTank, $EnergyDamageType] = 1.0;
$DamageScale[HoverTank, $ExplosionDamageType] = 1.0;
$DamageScale[HoverTank, $ShrapnelDamageType] = 1.0;
$DamageScale[HoverTank, $DebrisDamageType] = 1.0;
$DamageScale[HoverTank, $MissileDamageType] = 1.0;
$DamageScale[HoverTank, $LaserDamageType] = 0.5;
$DamageScale[HoverTank, $MortarDamageType] = 1.0;
$DamageScale[HoverTank, $BlasterDamageType] = 0.5;
$DamageScale[HoverTank, $ElectricityDamageType] = 1.0;
$DamageScale[HoverTank, $MineDamageType]        = 1.0;
$DamageScale[HoverTank, $FusionDamageType] = 1.5;
$DamageScale[HoverTank, $DisruptorDamageType] = 1.0;
$DamageScale[HoverTank, $IonDamageType] = 1.0;
$DamageScale[HoverTank, $VulcanDamageType] = 1.0;
$DamageScale[HoverTank, $ShotgunDamageType] = 1.0;
$DamageScale[HoverTank, $NukeDamageType] = 10.0;
$DamageScale[HoverTank, $ZapDamageType] = 1.0;
$DamageScale[HoverTank, $HeatDamageType] = 1.0;
$DamageScale[HoverTank, $ATCDamageType] = 1.0;
$DamageScale[HoverTank, $StarDamageType] = 1.0;
$DamageScale[HoverTank, $ShockwaveDamageType] = 1.0;
$DamageScale[HoverTank, $PBWDamageType] = 2.55;
$DamageScale[HoverTank, $FlameDamageType] = 1.0;
$DamageScale[HoverTank, $IceDamageType] = 1.0;
$DamageScale[HoverTank, $BurstDamageType] = 1.0;
$DamageScale[HoverTank, $ReaverDamageType] = 1.0;
$DamageScale[HoverTank, $RifleDamageType] = 1.0;
$DamageScale[HoverTank, $MassShotgunDamageType] = 1.0;
$DamageScale[HoverTank, $GaussDamageType] = 1.0;
$DamageScale[HoverTank, $MBDamageType] = 1.0;
$DamageScale[HoverTank, $NullDamageType] = 1.0;

$DamageScale[StarHammer, $ImpactDamageType] = 1.0;
$DamageScale[StarHammer, $BulletDamageType] = 1.0;
$DamageScale[StarHammer, $PlasmaDamageType] = 1.0;
$DamageScale[StarHammer, $EnergyDamageType] = 1.0;
$DamageScale[StarHammer, $ExplosionDamageType] = 1.0;
$DamageScale[StarHammer, $ShrapnelDamageType] = 1.0;
$DamageScale[StarHammer, $DebrisDamageType] = 1.0;
$DamageScale[StarHammer, $MissileDamageType] = 1.0;
$DamageScale[StarHammer, $LaserDamageType] = 1.0;
$DamageScale[StarHammer, $MortarDamageType] = 1.0;
$DamageScale[StarHammer, $BlasterDamageType] = 0.5;
$DamageScale[StarHammer, $ElectricityDamageType] = 1.0;
$DamageScale[StarHammer, $MineDamageType]        = 1.0;
$DamageScale[StarHammer, $FusionDamageType] = 1.5;
$DamageScale[StarHammer, $DisruptorDamageType] = 1.0;
$DamageScale[StarHammer, $IonDamageType] = 1.0;
$DamageScale[StarHammer, $VulcanDamageType] = 1.0;
$DamageScale[StarHammer, $ShotgunDamageType] = 1.0;
$DamageScale[StarHammer, $NukeDamageType] = 10.0;
$DamageScale[StarHammer, $ZapDamageType] = 1.0;
$DamageScale[StarHammer, $HeatDamageType] = 1.0;
$DamageScale[StarHammer, $ATCDamageType] = 1.0;
$DamageScale[StarHammer, $StarDamageType] = 1.0;
$DamageScale[StarHammer, $ShockwaveDamageType] = 1.0;
$DamageScale[StarHammer, $PBWDamageType] = 2.55;
$DamageScale[StarHammer, $FlameDamageType] = 1.0;
$DamageScale[StarHammer, $IceDamageType] = 1.0;
$DamageScale[StarHammer, $BurstDamageType] = 1.0;
$DamageScale[StarHammer, $ReaverDamageType] = 1.0;
$DamageScale[StarHammer, $RifleDamageType] = 1.0;
$DamageScale[StarHammer, $MassShotgunDamageType] = 1.0;
$DamageScale[StarHammer, $GaussDamageType] = 1.0;
$DamageScale[StarHammer, $MBDamageType] = 1.0;
$DamageScale[StarHammer, $NullDamageType] = 1.0;

$DamageScale[SkyCutter, $ImpactDamageType] = 1.0;
$DamageScale[SkyCutter, $BulletDamageType] = 1.0;
$DamageScale[SkyCutter, $PlasmaDamageType] = 1.0;
$DamageScale[SkyCutter, $EnergyDamageType] = 1.0;
$DamageScale[SkyCutter, $ExplosionDamageType] = 1.0;
$DamageScale[SkyCutter, $ShrapnelDamageType] = 1.0;
$DamageScale[SkyCutter, $DebrisDamageType] = 1.0;
$DamageScale[SkyCutter, $MissileDamageType] = 1.0;
$DamageScale[SkyCutter, $LaserDamageType] = 1.0;
$DamageScale[SkyCutter, $MortarDamageType] = 1.0;
$DamageScale[SkyCutter, $BlasterDamageType] = 0.5;
$DamageScale[SkyCutter, $ElectricityDamageType] = 1.0;
$DamageScale[SkyCutter, $MineDamageType]        = 1.0;
$DamageScale[SkyCutter, $FusionDamageType] = 1.5;
$DamageScale[SkyCutter, $DisruptorDamageType] = 1.0;
$DamageScale[SkyCutter, $IonDamageType] = 1.0;
$DamageScale[SkyCutter, $VulcanDamageType] = 1.0;
$DamageScale[SkyCutter, $ShotgunDamageType] = 1.0;
$DamageScale[SkyCutter, $NukeDamageType] = 10.0;
$DamageScale[SkyCutter, $ZapDamageType] = 1.0;
$DamageScale[SkyCutter, $HeatDamageType] = 1.0;
$DamageScale[SkyCutter, $ATCDamageType] = 1.0;
$DamageScale[SkyCutter, $StarDamageType] = 1.0;
$DamageScale[SkyCutter, $ShockwaveDamageType] = 1.0;
$DamageScale[SkyCutter, $PBWDamageType] = 2.55;
$DamageScale[SkyCutter, $FlameDamageType] = 1.0;
$DamageScale[SkyCutter, $IceDamageType] = 1.0;
$DamageScale[SkyCutter, $BurstDamageType] = 1.0;
$DamageScale[SkyCutter, $ReaverDamageType] = 1.0;
$DamageScale[SkyCutter, $RifleDamageType] = 1.0;
$DamageScale[SkyCutter, $MassShotgunDamageType] = 1.0;
$DamageScale[SkyCutter, $GaussDamageType] = 1.0;
$DamageScale[SkyCutter, $MBDamageType] = 1.0;
$DamageScale[SkyCutter, $NullDamageType] = 1.0;

$DamageScale[Arwing, $ImpactDamageType] = 1.0;
$DamageScale[Arwing, $BulletDamageType] = 1.0;
$DamageScale[Arwing, $PlasmaDamageType] = 1.0;
$DamageScale[Arwing, $EnergyDamageType] = 1.0;
$DamageScale[Arwing, $ExplosionDamageType] = 1.0;
$DamageScale[Arwing, $ShrapnelDamageType] = 1.0;
$DamageScale[Arwing, $DebrisDamageType] = 1.0;
$DamageScale[Arwing, $MissileDamageType] = 1.0;
$DamageScale[Arwing, $LaserDamageType] = 1.0;
$DamageScale[Arwing, $MortarDamageType] = 1.0;
$DamageScale[Arwing, $BlasterDamageType] = 0.5;
$DamageScale[Arwing, $ElectricityDamageType] = 1.0;
$DamageScale[Arwing, $MineDamageType]        = 1.0;
$DamageScale[Arwing, $FusionDamageType] = 1.5;
$DamageScale[Arwing, $DisruptorDamageType] = 1.0;
$DamageScale[Arwing, $IonDamageType] = 1.0;
$DamageScale[Arwing, $VulcanDamageType] = 1.0;
$DamageScale[Arwing, $ShotgunDamageType] = 1.0;
$DamageScale[Arwing, $NukeDamageType] = 10.0;
$DamageScale[Arwing, $ZapDamageType] = 1.0;
$DamageScale[Arwing, $HeatDamageType] = 1.0;
$DamageScale[Arwing, $ATCDamageType] = 1.0;
$DamageScale[Arwing, $StarDamageType] = 1.0;
$DamageScale[Arwing, $ShockwaveDamageType] = 1.0;
$DamageScale[Arwing, $PBWDamageType] = 2.55;
$DamageScale[Arwing, $FlameDamageType] = 1.0;
$DamageScale[Arwing, $IceDamageType] = 1.0;
$DamageScale[Arwing, $BurstDamageType] = 1.0;
$DamageScale[Arwing, $ReaverDamageType] = 1.0;
$DamageScale[Arwing, $RifleDamageType] = 1.0;
$DamageScale[Arwing, $MassShotgunDamageType] = 1.0;
$DamageScale[Arwing, $GaussDamageType] = 1.0;
$DamageScale[Arwing, $MBDamageType] = 1.0;
$DamageScale[Arwing, $NullDamageType] = 1.0;

//--------------------------------------------------------
function Vehicle::onAdd(%this)
{	
	%this.isMarked=false;
	GameBase::setRechargeRate (%this, 4);
	GameBase::setMapName (%this, "Vehicle");

 	if(GameBase::getDataName(%this) == Scout) 
	{	GameBase::setMapName (%this, "Scout");
		%this.shieldStrength = 0;
		GameBase::setRechargeRate (%this, 4);
	}
	else if(GameBase::getDataName(%this) == LAPC)
	{	GameBase::setMapName (%this, "LPC");
		%this.shieldStrength = 0.001;
		GameBase::setRechargeRate (%this, 8);
	}
	else if(GameBase::getDataName(%this) == HAPC) 
	{	GameBase::setMapName (%this, "HPC");
		%this.shieldStrength = 0.002;
		GameBase::setRechargeRate (%this, 8);
	}
	else if(GameBase::getDataName(%this) == HoverTank) 
	{	GameBase::setMapName (%this, "Hover Tank");
		%this.shieldStrength = 0.01;
		GameBase::setRechargeRate (%this, 2);
	}
	else if(GameBase::getDataName(%this) == StarHammer) 
	{	GameBase::setMapName (%this, "Star Hammer");
		%this.shieldStrength = 0.0001;
		GameBase::setRechargeRate (%this, 16);
	}
	else if(GameBase::getDataName(%this) == Arwing) 
	{	GameBase::setMapName (%this, "Arwing");
		%this.shieldStrength = 0.00375;
		GameBase::setRechargeRate (%this, 4);
	}
	else if(GameBase::getDataName(%this) == SkyCutter) 
	{	GameBase::setMapName (%this, "Sky Cutter");
		%this.shieldStrength = 0;
		GameBase::setRechargeRate (%this, 0);
	}
 	if(GameBase::getDataName(%this) == EscapePod) 
	{	GameBase::setMapName (%this, "Escape Pod");
		%this.shieldStrength = 0;
		GameBase::setRechargeRate (%this, 0);
	}
	else if(GameBase::getDataName(%this) == Icarus)
	{	GameBase::setMapName (%this, "Icarus");
		%this.shieldStrength = 0.005;
		GameBase::setRechargeRate (%this, 2);
	}
	else if(GameBase::getDataName(%this) == Skyranger) 
	{	GameBase::setMapName (%this, "Skyranger");
		%this.shieldStrength = 0.0025;
		GameBase::setRechargeRate (%this, 5);
	}
	else if(GameBase::getDataName(%this) == StarFighter) 
	{	GameBase::setMapName (%this, "StarFighter");
		%this.shieldStrength = 0.1;
		GameBase::setRechargeRate (%this, 0);
	}
	else if(GameBase::getDataName(%this) == Avenger) 
	{	GameBase::setMapName (%this, "Avenger");
		%this.shieldStrength = 0.003;
		GameBase::setRechargeRate (%this, 5);
	}
	else if(GameBase::getDataName(%this) == Explorer) 
	{	GameBase::setMapName (%this, "Explorer");
		%this.shieldStrength = 0.001;
		GameBase::setRechargeRate (%this, 12);
	}
	else if(GameBase::getDataName(%this) == Jetfire) 
	{	GameBase::setMapName (%this, "Human Flier");
		%this.shieldStrength = 0.0012;
		GameBase::setRechargeRate (%this, 8);
	}
}

function Vehicle::onCollision (%this, %object)
{
	if(GameBase::getDamageLevel(%this) < (GameBase::getDataName(%this)).maxDamage) {
		if (getObjectType (%object) == "Player" && (getSimTime() > %object.newMountTime || %object.lastMount != %this) && %this.fading == "")
			{
				%armor = Player::getArmor(%object);
		      %client = Player::getClient(%object);
				if ((%armor == "larmor" || %armor == "lfemale" || %armor == "marmor" || %armor == "mfemale" || %armor == "gharmor" || %armor == "harmor" || %armor == "engineer" || %armor == "engineers" || %armor == "disruptor" || %armor == "disrupter" || %armor == "blastech" || %armor == "blastechf" || %armor == "vulcan" || %armor == "vulcanf") && Vehicle::canMount (%this, %object))
					{
						%weapon = Player::getMountedItem(%object,$WeaponSlot);
						if(%weapon != -1) {
							%object.lastWeapon = %weapon;
							Player::unMountItem(%object,$WeaponSlot);
						}
						Player::setMountObject(%object, %this, 1);
				      Client::setControlObject(%client, %this);
						playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
						%object.driver= 1;
		            %object.vehicle = %this;
						%this.clLastMount = %client;
					}
				else if((GameBase::getDataName(%this) != Scout || (%this) != Explorer || (%this) != StarFighter || (%this) != Icarus || (%this) != EscapePod || (%this) != Avenger || (%this) != Bomber || (%this) != Arwing || (%this) != Starhammer || (%this) != Skycutter (%this) || (%this) != Skyranger) && (GameBase::getDataName(%this) != Wraith)) 
					{
					 	%mountSlot= Vehicle::findEmptySeat(%this,%client); 
						if(%mountSlot) 
							{
								%object.vehicleSlot = %mountSlot;
								%object.vehicle = %this;
								Player::setMountObject(%object, %this, %mountSlot);
								playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
							}
					}
				else if (GameBase::getControlClient(%this) == -1)
					Client::sendMessage(Player::getClient(%object),0,"You're screwed...~wError_Message.wav");
			}
	}
}

function Vehicle::findEmptySeat(%this,%client)
{
	if(GameBase::getDataName(%this) == HAPC || (%this) == HoverTank || (%this) == Annihalator)
		%numSlots = 4;
	else
		%numSlots = 2;
	%count=0;
	for(%i=0;%i<%numSlots;%i++)  
		if(%this.Seat[%i] == "") {
			%slotPos[%count] = Vehicle::getMountPoint(%this,%i+2);
			%slotVal[%count] = %i+2;
			%lastEmpty = %i+2;
			%count++;
		}
	if(%count == 1) {
		%this.Seat[%lastEmpty-2] = %client;
		return %lastEmpty;
	}
	else if (%count > 1)	{
		%freeSlot = %slotVal[getClosestPosition(%count,GameBase::getPosition(%client),%slotPos[0],%slotPos[1],%slotPos[2],%slotPos[3])];
		%this.Seat[%freeSlot-2] = %client;
		return %freeSlot;
	}
	else
		return "False";
}

function getClosestPosition(%num,%playerPos,%slotPos0,%slotPos1,%slotPos2,%slotPos3)
{
	%playerX = getWord(%playerPos,0);
	%playerY = getWord(%playerPos,1);
	for(%i = 0 ;%i<%num;%i++) {
		%x = (getWord(%slotPos[%i],0)) - %playerX;
		%y = (getWord(%slotPos[%i],1)) - %playerY;
		if(%x < 0)
			%x *= -1;
		if(%y < 0)
			%y *= -1;
		%newDistance = sqrt((%x*%x)+(%y*%y));
		if(%newDistance < %distance || %distance == "") {
	  		%distance = %newDistance;			
			%closePos = %i;	
		}
	}		
	return %closePos;
}

function Vehicle::passengerJump(%this,%passenger,%mom)
{
	%armor = Player::getArmor(%passenger);
	if(%armor == "larmor" || %armor == "lfemale") {
		%height = 2;
		%velocity = 70;
		%zVec = 70;
	}
	else if(%armor == "marmor" || %armor == "mfemale") {
		%height = 2;
		%velocity = 100;
		%zVec = 100;
	}
	else if(%armor == "harmor") {
		%height = 2;
		%velocity = 140;
		%zVec = 110;
	}
	else
	 {	
		%height = 2;
		%velocity = 70;
		%zVec = 70;
	}




	%pos = GameBase::getPosition(%passenger);
	%posX = getWord(%pos,0);
	%posY	= getWord(%pos,1);
	%posZ	= getWord(%pos,2);

	if(GameBase::testPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height))) {	
		%client = Player::getClient(%passenger);
		%this.Seat[%passenger.vehicleSlot-2] = "";
		%passenger.vehicleSlot = "";
	   %passenger.vehicle= "";
		Player::setMountObject(%passenger, -1, 0);
		%rotZ = getWord(GameBase::getRotation(%passenger),2);
		GameBase::setRotation(%passenger, "0 0 " @ %rotZ);
		GameBase::setPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height));
		%jumpDir = Vector::getFromRot(GameBase::getRotation(%passenger),%velocity,%zVec);
		Player::applyImpulse(%passenger,%jumpDir);
	}
	else
		Client::sendMessage(Player::getClient(%passanger),0,"Can not dismount - Object in the way.~wError_Message.wav");
}

function Vehicle::jump(%this,%mom)
{
   Vehicle::dismount(%this,%mom);
}

function Vehicle::dismount(%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   if(%cl != -1)
   {
	if(GameBase::getDataName(%this) == "Jetfire")
	{
		Jetfire::Dismount(%this, %cl);
		return;
	}
      %pl = Client::getOwnedObject(%cl);
      if(getObjectType(%pl) == "Player")
      {
		   // dismount the player	  
			if(GameBase::testPosition(%pl, Vehicle::getMountPoint(%this,0))) {
				%pl.lastMount = %this;
				%pl.newMountTime = getSimTime() + 3.0;
				Player::setMountObject(%pl, %this, 0);
        	 	Player::setMountObject(%pl, -1, 0);
				%rot = GameBase::getRotation(%this);
				%rotZ = getWord(%rot,2);
				GameBase::setRotation(%pl, "0 0 " @ %rotZ);
				Player::applyImpulse(%pl,%mom);
        	 	Client::setControlObject(%cl, %pl);
				playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
				if(%pl.lastWeapon != "") {
					Player::useItem(%pl,%pl.lastWeapon);		 	
					%pl.lastWeapon = "";
      		}
				%pl.driver = "";
				%pl.vehicle = "";
			}
			else
				Client::sendMessage(%cl,0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
		}
   }
}

function Vehicle::onDestroyed (%this,%mom)
{
//	if($testcheats || $servercheats)
	$TeamItemCount[GameBase::getTeam(%this) @ $VehicleToItem[GameBase::getDataName(%this)]]--;
   %cl = GameBase::getControlClient(%this);
	%pl = Client::getOwnedObject(%cl);
	if(%pl != -1) {
	   Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
		if(%pl.lastWeapon != "") {
			Player::useItem(%pl,%pl.lastWeapon);		 	
			%pl.lastWeapon = "";
		}
		%pl.driver = "";
				// ADDED JAMMING OFF When SLAPC Destroyed - *IX*Savage1
				if(GameBase::getDataName(%this) == SLAPC) {
					%rate = Player::getSensorSupression(%pl) - $StealthLevel;
					Player::setSensorSupression(%pl,%rate);
				}
				// ------------------------------------------------
	}
	for(%i = 0 ; %i < 4 ; %i++)
		if(%this.Seat[%i] != "") {
			%pl = Client::getOwnedObject(%this.Seat[%i]);
		   Player::setMountObject(%pl, -1, 0);
	  	 	Client::setControlObject(%this.Seat[%i], %pl);
		}
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.55, 
		0.1, 225, 100); 
}

function Vehicle::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
	%value *= $damageScale[GameBase::getDataName(%this), %type];
	StaticShape::onDamage(%this,%type,%value,%pos,%vec,%mom,%object);
}

function Vehicle::getHeatFactor(%this)
{
	// Not getting called right now because turrets don't track
	// vehicles.  A hack has been placed in Player::getHeatFactor.
   return 1.0;
}