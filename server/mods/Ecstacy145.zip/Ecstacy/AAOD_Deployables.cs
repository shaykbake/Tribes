//Warning!! This has been copied from the AAOD with their permission! 
//DO NOT COPY THIS unless you, too have permission.
//They will know if you did.....
//Mega Man 1024

function PackUpStuff(%this,%client, %player,%armor,%desc,%nopack,%pName)
{	if(%this.isbusy)
	{	Client::sendMessage(%client,0,"Unable to Pack up - Unit is Busy performing some function!~wError_message.wav");
		return(false);
	}

	if(%this.ShieldNode)
	{	Client::sendMessage(%client,0,"Unable to Pack up - Unit has an Attached Shield Node.| Pack Shield Node up First!~wError_message.wav");
		return(false);
	}

	%name = Client::getName(%client);
	%team = Client::getTeam(%client);
	%pack=Player::getMountedItem(%player,$BackpackSlot);
	if (%nopack==true)	// If Client must not have a pack on to pack up
		if(%pack!=-1)	// then check to see if he has a pack
		{	Client::sendMessage(%client,0,"Unable to Pack up - You are wearing a Pack!~wError_message.wav");
			return(false);		// if he does return without packing up
		}

	if(%armor!="")
	{	%parmor = Player::getArmor(%client);
		%parm=String::getSubStr(%parmor, 0, 1);
		%num=String::findSubStr(%armor, %parm);	//	Is the Armor Type the player is wearing in the list of acceptable armor types
		if (%num==-1)
		{	Client::sendMessage(%client,0,"Unable to Pack up - You are not wearing the compatable armor!~wError_message.wav");
			return(false);		// if he is not wearing right armor return without packing up
		}
			
	}
			
	if(GameBase::getDamageLevel(%this)!=0)				// Item is Damaged so dont Pack it up
	{	Client::sendMessage(%client,0,"Unable to Pack up "@%desc@". It Requires Repair!~wError_message.wav");	
		return(false);
	}
	else
	{	GameBase::stopSequence(%this,0);
		GameBase::setSequenceDirection(%this,1,0);
		GameBase::playSequence(%this,1,"deploy");
		if(%this.pset)	//	Is This a power generator???
		{	GameBase::virtual(%this,"Disabled");
			%player.isDeploying = true;
			%pos=vector::add(Gamebase::getPosition(%this),"0 0 0.5");
			%td=DisconnectGenerator(%this)+1;	// Dis-connect it from the grid
			removeFromSet($GenSet[%team],%this);
			schedule("GameBase::startFadeOut("@%this@");",%td,%this);
			schedule("deleteObject(" @ %this @ ");",(%td+1),%this);
			schedule("PlaceItemPack(" @ %player @ "," @ %pName @ ",\"" @ %pos @ "\");",(%td+1.15),%player);		
			return(true);
		}
		else
		{	%player.isDeploying = true;
			%pos=vector::add(Gamebase::getPosition(%this),"0 0 0.5");
			GameBase::startFadeOut(%this);
			schedule("deleteObject(" @ %this @ ");",1.0,%this);
			schedule("PlaceItemPack(" @ %player @ "," @ %pName @ ",\"" @ %pos @ "\");",1.15,%player);		
			return(true);
		}
		echo(">INF: ",$User[%client]," Packed up a "@%desc);
	}
}


function CheckObjectType(%object,%type)
{	//if($traceDep) Echo("Checking: Is deployable placement on ",%object," valid for type: ",%type);

	if (%type==0)		// **** Can be PLaced on Terrain Only
	{	if (%object=="SimTerrain")
			return(true);
	}
	else if (%type==1)	// **** Can Be Placed on Terrain & Buildings
	{	if (%object=="SimTerrain" || %object=="InteriorShape")
			return(true);
	}	
	else if (%type==2)	// **** Can Be Placed on Terrain, Buildings & Some objects
	{	if ((%object=="SimTerrain" || %object=="InteriorShape" ) || (%object=="Turret" || %object=="sensor"))
			return(true);
	}
	else if(%type==3)	// **** Can Be Placed on Buildings & Terrain but Must be Outside
	{	if (%object=="SimTerrain" || %object=="InteriorShape")
		{	%num=0;
			%setx = newObject("set",SimSet);
			%pos1=$los::position;
			%pos=Vector::Add(%pos1,"0 0 30");
			%num = containerBoxFillSet(%setx,$SimInteriorObjectType,%pos,1,1,50,0);
			deleteObject(%setx);
			if(!%num)			
				return(true);
		}
	}
	return(false);
}

function DeployStuff(%player,%item,%shape,%pType,%dist,%cType,%dtype,%DonD,%Power,%pRange)
{	
	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	// %ptype = 0 for SimTerrain only
	// %ptype = 1 for SimTerrain or Interior Shapes
	// %ptype = 2 for SimTerrain or Interior Shapes or Objects
	// %ptype = 3 Outside clear sky above....(is this possible - The answer being yes!!!)
	// %dist is the max deploy distance
	// %ctype = 0	Use Defaults for Interference Checking
	// %ctype = 1	Turret Use Turret Box Values for checking interference
	// %ctype = 2	Forcefield Use Forcefield Values for Interference checking
	// %dtype = true or false	(True means it can be placed on any surface)
	// %shape = Shape Name (String) The Name of the DATA Block for this shape
	// %shape = Shape
	// %DonD  = Delete on Destroy True or False
	// %tname = Name of Type items
	// %power = 0= Item has No special Power Needs|1=Item Requires Power|2=Item generates Power 
	//			   (Item which requires Power will have an %item.prange var for how far it can look for power)
	
	%descr=%item.description;
		
	if(%ptype==0)
		%pDesc="Terrain";
	else if(%ptype==1)
		%pDesc="Terrain & Buildings";
	else if(%ptype==2)
		%pDesc="Terrain, Buildings & Objects";
	else if(%ptype==3)
		%pDesc="Terrain & Buildings but MUST be Outside";
	else if(%ptype==4)
		%pDesc="Terrain";

			
	if (%ctype==1)
	{	%BxMxL=$TurretBoxMaxLength;
		%BxMnL=$TurretBoxMinLength;
		%BxMxW=$TurretBoxMaxWidth;
		%BxMnW=$TurretBoxMinWidth;
		%BxMxH=$TurretBoxMaxHeight;
		%BxMnH=$TurretBoxMinHeight;
		%MaxNum=$MaxNumTurretsInBox;
		%class="Turret";
		%tname="deployable Turrets";
	}
	else if (%ctype==2)
	{	%BxMxL=$FFBxMxLength;
		%BxMnL=$FFBxMnLength;
		%BxMxW=$FFBxMxWidth;
		%BxMnW=$FFBxMnWidth;
		%BxMxH=$FFBxMxHeight;
		%BxMnH=$FFBxMnHeight;
		%MaxNum=$MaxNumFieldsInBox;
		%class="StaticShape";
		%tname="Deployable Forcefields";
	}
	else if (%ctype==4)	// Nodes
	{	%BxMxL=10;
		%BxMnL=1;
		%BxMxW=10;
		%BxMnW=1;
		%BxMxH=10;
		%BxMnH=1;
		%MaxNum=20;
		%class="StaticShape";
	}
	else
	{	%BxMxL=2;
		%BxMnL=1;
		%BxMxW=2;
		%BxMnW=1;
		%BxMxH=2;
		%BxMnH=1;
		%MaxNum=10;
		%class="StaticShape";
	}
	
	%team=GameBase::getTeam(%player);
	%client = Player::getClient(%player);
	if($TeamItemCount[ %team @ %item] < $TeamItemMax[%item])	// Check to see if Item Count has been Reached
	{	%thisnum=$TeamItemCount[%team @ %item]+1;
		if (GameBase::getLOSInfo(%player,%dist)) 
		{	%obj = getObjectType($los::object);
			if(CheckObjectType(%obj,%ptype))
			{	%set = newObject("set",SimSet);
				%tnum = containerBoxFillSet(%set,$StaticObjectType,$los::position,%BxMxL,%BxMxW,%BxMxH,0);
				%num = GetNumObjects(%set,%ctype,%tnum);
				deleteObject(%set);
				if(%MaxNum > %num) 
				{	%set = newObject("set",SimSet);
					%tnum = containerBoxFillSet(%set,$StaticObjectType,$los::position,%BxMnL,%BxMnW,%BxMnH,0);
					%num = GetNumObjects(%set,%ctype,%tnum);
					if(0 == %num)	// No Objects within the Minimum Box
					{	if(%dtype==1)	//	If Deployable on Any Surface
						{	// Try to stick it straight up or down, otherwise
							// just use the surface normal
							%prot = GameBase::getRotation(%player);
							//if($trace) echo("Player Rotation ",%prot);
							//%zRot = (3.141592654-getWord(%prot,2));
							//if($trace) echo("Player Rotation ",%zrot);
							%zRot = (getWord(%prot,2));

							if (Vector::dot($los::normal,"0 0 1") > 0.6) 
							{	%rot = "0 0 " @ %zRot;}
							else
							{	if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
								{	%rot = "3.14159 0 " @ %zRot;}
								else
								{	%rot = Vector::getRotation($los::normal);}
							}
						}
						else if(%dtype==2)	//	Matches Any Surface
						{	%rot = Vector::getRotation($los::normal);
							
						}
						else
						{	if (Vector::dot($los::normal,"0 0 1") <= 0.7)
							{	Client::sendMessage(%client,0,%desc@" Can only deploy on flat surfaces~werror_message.wav");
								return (false);
							}
							%rot = GameBase::getRotation(%player);
						}	
							
						if(checkDeployArea(%client,$los::position)) 
						{	%newitem = newObject(%shape,%class,%shape,%DonD);
							if($traceObj) Echo($Ver,"|Created New Object :",%newitem," ",%descr);
							GameBase::playSequence(%newitem,1,"deploy");
							GameBase::SetActive(%newItem,false);
							%newitem.faded=1;
							addToSet("MissionCleanup", %newitem);
							GameBase::setTeam(%newitem,%team);
							GameBase::setPosition(%newitem,$los::position);
							GameBase::setRotation(%newitem,%rot);
							Gamebase::setMapName(%newitem,%descr @" #" @ %thisnum @ " " @ Client::getName(%client));
							Client::sendMessage(%client,0,%descr @" deployed");
							playSound(SoundCreateItem,$los::position);
							$TeamItemCount[%team @ %item]++;
							
							%newitem.deployedBy	= %client;
							%newitem.powerReq	= %power;
							%newitem.pRange		= %pRange;

							if(%power==1)	// Item Requires Power
							{	if($TracePwr) echo(%newitem," requires Power!");
								Client::sendMessage(%client,1,"Attempting to connect to Main Power Grid~AAODSFX13.WAV");
								schedule("PowerItem("@%newitem@","@%pRange@","@%client@");",2,%newitem);
							}
							else if(%power==2)	// Item generates Power
							{	if($TracePwr) echo(%newitem,"	Power Generator!");
								GameBase::SetActive(%newItem,true);
								Client::sendMessage(%client,1,"Attempting to connect Generator to Main Grid~AAODSFX13.WAV");
								schedule("ConnectGenerator("@%newitem@","@%client@");",2,%newitem);
								if($GenSet[%team])
								{	addToSet($GenSet[%team],%newItem);
								}
								else
								{	$GenSet[%team]=newObject("set",SimSet);
									addToSet("MissionCleanup",$GenSet[%team]);
									addToSet($GenSet[%team],%newItem);
								}
							}
							else
								GameBase::SetActive(%newItem,true);

							echo(">INF: ",$User[%client]," deployed a "@ %descr);
							return (%newitem);
						}
					}
					else Client::sendMessage(%client,0,"Frequency Overload - Too close to other "@%tname);
				}
				else Client::sendMessage(%client,0,"Too Many Other "@%tname@" in the area");
			}
			else Client::sendMessage(%client,0,%descr@" can only be deployed "@%pDesc@"~wAAODSFX09.WAV");
		}
		else Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %descr);
	return (false);
}

//************************************
// 	AODDefender Backpack Script
// 	(Defender Defense Turret)
//************************************

$InvList[AODDefender]			= 1;
$RemoteInvList[AODDefender]		= 1;
$TeamItemMax[AODDefender]		= 20;

$ItemMax[larmor, AODDefender]	= 1;
$ItemMax[lfemale, AODDefender]	= 1;
$ItemMax[marmor, AODDefender]	= 1;
$ItemMax[mfemale, AODDefender]	= 1;
$ItemMax[harmor, AODDefender]	= 1;
$ItemMax[engineer, AODDefender]	= 1;
$ItemMax[engineers, AODDefender]	= 1;

ExplosionData DesignatorExp
{	shapeName = "plasmaEx.DTS";		
	soundId=  SoundDefenderScan;	
	faceCamera=true;				
	randomSpin = true;		
	hasLight=true;			
	lightRange=2.0;			
	timeZero=0.100;				
	timeOne=0.900;				
	colors[0]={0.0,0.0,0.0};	
	colors[1]={1.0,1.0,0.5};	
	colors[2]={0.0,1.0,0.0};	
	radFactors={0.0,1.0,0.0};	
	shiftPosition=False;		
};

BulletData TargetScan
{	bulletShapeName		= "plasmaex.DTS";
	explosionTag		= plasmaExp;		
	expRandCycle		= 0;				
	accufire			= true;
	mass				= 0.75;					
	collisionRadius		= 0.0;		
	bulletHoleIndex		= 0;			
	ExplosionRadius		= 1;			
	damageClass			= 0;			
	damageValue			= 0.06;						// Means something Diff for Designators
	damageType			= $EnergyDamageType;
	muzzleVelocity		= 1000;	
	totalTime			= 1.5;			
	inheritedVelocityScale = 0.0;		
	isVisible			= True;			
	tracerPercentage	= 1.00;
	tracerLength		= 25;		
	detachFromShooter	= false;		
	rotationPeriod		= 0.25;			
	lightRange			= 4.0;			
	lightColor			= {0.75, 0.25,0.35};		
	hitSoundId			= SoundDefenderScan;
};


ItemImageData AODDefenderImage 
{	shapeFile	= "CAMERA";
	mountPoint	= 2;
	mass		= 2.0;
	firstPerson = false;
};

ItemData AODDefender 
{	description			= "Defender Designator";
	shapeFile			= "CAMERA";
	classname			= "Backpack";
	heading				= "dDeployables";
	imageType			= AODDefenderImage;
	shadowDetailMask	= 4;
	mass				= 3.0;
	elasticity			= 0.2;
	price				= 325;
	hudIcon				= "deployable";
	showWeaponBar		= true;
	hiliteOnActive		= true;
};

TurretData DefenderTurret 
{	classname			= "SensorNet";
	shapeFile			= "CAMERA";
	projectileType		= targetscan;
	maxDamage			= 0.75;
	maxEnergy			= 100;
	minGunEnergy		= 5;
	maxGunEnergy		= 15;
	sequenceSound[0]	= {"deploy", SoundActivateMotionSensor};
	reloadDelay			= 1;
	speed				= 4.5;
	speedModifier		= 1.5;
	range				= 400;
	visibleToSensor		= true;
	shadowDetailMask	= 4;
	dopplerVelocity		= 0;
	castLOS				= true;
	supression			= false;
	mapFilter			= 2;
	mapIcon				= "M_turret";
	debrisId			= flashDebrisSmall;
	shieldShapeName		= "shield";
	fireSound			= SoundFireDefender;
	activationSound		= SoundRemoteTurretOn;
	deactivateSound		= SoundRemoteTurretOff;
	explosionId			= flashExpMedium;
	description			= "Defender Turret";
	damageSkinData		= "objectDamageSkins";
	pinger				= false;
	lightColor			= { 0.75, 0.75, 0.85 };
};


function AODDefender::onUse(%player,%item)
{	%client = Player::getClient(%player);
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
	{	Player::mountItem(%player,%item,$BackpackSlot);}
	else 
	{	Player::deployItem(%player,%item); }
}

function AODDefender::onDeploy(%player,%item,%pos)
{	if (AODDefender::deployShape(%player,%item)) 
	{	Player::decItemCount(%player,%item);}
}

function AODDefender::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	DeployStuff(%player,%item,DefenderTurret,1,4,1,1,true,false,0);
}

function DefenderTurret::packUp(%this, %pos, %client, %player)
{	%armor		= "";
	%desc		= "Defender Designator";
	%nopack		= false;			// does not have to have no pack on
	%pName	= AODDefender;

	PackUpStuff(%this,%client, %player,%armor,%desc,%nopack,%pName);
}

function DefenderTurret::onAdd(%this)
{	schedule("DefenderTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,10);
	%this.shieldStrength = 0.025;
	if (GameBase::getMapName(%this) == "") 
	{	GameBase::setMapName (%this, "Defender Turret");}
}

function DefenderTurret::deploy(%this)
{	GameBase::playSequence(%this,1,"deploy");
}

function DefenderTurret::onEndSequence(%this,%thread)
{	GameBase::setActive(%this,true);
}

function DefenderTurret::onDestroyed(%this)
{	Turret::onDestroyed(%this);
	$TeamItemCount[GameBase::getTeam(%this) @ "AODDefender"]--;
}

function DefenderTurret::onPower(%this,%power,%generator)
{}

function DefenderTurret::onEnabled(%this)
{	GameBase::setRechargeRate(%this,10);
	GameBase::setActive(%this,true);
}

//***********************************
// AAOD Mobile Inventory Pack
//***********************************

$InvList[AODMobileInv]	= 1;
$RemoteInvList[AODMobileInv] = 1;
$TeamItemMax[AODMobileInv]	= 5;

$ItemMax[larmor, AODMobileInv]	= 0;
$ItemMax[lfemale, AODMobileInv]	= 0;
$ItemMax[marmor, AODMobileInv]	= 0;
$ItemMax[mfemale, AODMobileInv]	= 0;
$ItemMax[harmor, AODMobileInv]	= 1;
$ItemMax[engineer, AODMobileInv]	= 1;
$ItemMax[engineers, AODMobileInv]	= 1;

ItemImageData AODMobileInvImage 
{	shapeFile	= "MagCargo";
	mountPoint	= 2;
	mountOffset = { 0, -0.65, -0.4 };
	mass			= 5.0;
	firstPerson = false;
};


ItemData AODMobileInv
{	description		= "Mobile Inventory Stn";
	shapeFile		= "inventory_sta";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= AODMobileInvImage;
	shadowDetailMask = 4;
	elasticity		= 0.2;
	price			= 5000;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

StaticShapeData MobileInvent
{  description		= "Mobile Supply Unit";
	shapeFile		= "inventory_sta";
	classname		= "station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateInventoryStation };
	sequenceSound[1] = { "power", SoundInventoryStationPower };
	sequenceSound[2] = { "use", SoundUseInventoryStation };
	maxDamage		= 1.5;
	debrisId		= flashDebrisLarge;
	mapFilter		= 4;
	mapIcon			= "M_station";
	damageSkinData	= "objectDamageSkins";
	shadowDetailMask = 16;
	triggerRadius	= 1.5;
	explosionId		= flashExpLarge;
	shieldShapeName = "shield";
		
};

function AODMobileInv::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function AODMobileInv::onDeploy(%player,%item,%pos)
{	if (AODMobileInv::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);
		
	}
}

function AODMobileInv::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	DeployStuff(%player,%item,MobileInvent,1,5,0,0,false,1,250);
}


function MobileInvent::onEndSequence(%this,%thread)
{
	if (Station::onEndSequence(%this,%thread)) 
		InventoryStation::onResupply(%this,"InvList");
}

function MobileInvent::packUp(%this, %pos, %client, %player)
{	PackUpStuff(%this,%client, %player,"h","Mobile Inventory Station",true,AODMobileInv);
}

//***********************************
// Health Station based off AAOD Mobile inv
//***********************************

$InvList[HealthStation1024]  = 1;
$RemoteInvList[HealthStation1024] = 1;
$TeamItemMax[HealthStation1024]	= 10;

$ItemMax[larmor, HealthStation1024]	= 0;
$ItemMax[lfemale, HealthStation1024]	= 0;
$ItemMax[marmor, HealthStation1024]	= 0;
$ItemMax[mfemale, HealthStation1024]	= 0;
$ItemMax[harmor, HealthStation1024]	= 1;
$ItemMax[engineer, HealthStation1024]	= 1;
$ItemMax[engineers, HealthStation1024]	= 1;

ItemImageData HealthStation1024Image 
{	shapeFile	= "MagCargo";
	mountPoint	= 2;
	mountOffset = { 0, -0.65, -0.4 };
	mass			= 5.0;
	firstPerson = false;
};

ItemData HealthStation1024
{	description		= "Health Station";
	shapeFile		= "mainpad";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= HealthStation1024Image;
	shadowDetailMask = 4;
	elasticity		= 0.2;
	price			= 7500;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

function HealthStation1024::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function HealthStation1024::onDeploy(%player,%item,%pos)
{	if (HealthStation1024::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);
		
	}
}

function HealthStation1024::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	DeployStuff(%player,%item,HealthStation,1,5,0,0,false,1,250);
}


function HealthStation1024::packUp(%this, %pos, %client, %player)
{	PackUpStuff(%this,%client, %player,"h","Health Station",true,HealthStation);
}

StaticShapeData HealthStation
{
   description = "Health Station";
	shapeFile = "ammounit";
	className = "Station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateAmmoStation };
	sequenceSound[1] = { "power", SoundAmmoStationPower };
	sequenceSound[2] = { "use", SoundUseAmmoStation };
	maxDamage = 1.0;
	debrisId = flashDebrisLarge;
	mapFilter = 4;
	mapIcon = "M_station";
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 16;
   explosionId = flashExpLarge;
	shieldShapeName = "shield";
};

function HealthStation::onEndSequence(%this,%thread)
{
	//echo("End Seq ",%thread);
	if(%this.clTeamEnergy == "")
		%this.clTeamEnergy = (Player::getClient(Station::getTarget(%this))).TeamEnergy;
	if (Station::onEndSequence(%this,%thread)) 
		HealthStation::onResupply(%this);
}									
											
function HealthStation::onResupply(%this)
{
	if (GameBase::isActive(%this)) {
		%player = Station::getTarget(%this);
		if (%player != -1) {GameBase::repairDamage(%player,3);
			if(getSimTime() - %this.enterTime > 11)
				%cnt = 0;
			if (%cnt != 0) {
				schedule("HealthStation::onResupply(" @ %this @ ");",0.1,%this);
				return;
			}
			%client = Player::getClient(%player);
			Client::sendMessage(%client,0,"Repair Complete");
			Client::setInventoryText(%client, "<f1><jc>TEAM ENERGY: " @ $TeamEnergy[Client::getTeam(%client)]);
		}
		GameBase::setActive(%this,false);
		%this.enterTime="";
	}
}
		 											
function HealthStation::resupply(%player,%weapon,%item,%delta)
{
	%delta = checkResources(%player,%item,%delta,1);		
	if(%delta > 0) {						
		if(%item == RepairPatch) {
			teamEnergyBuySell(%player,%item.price * %delta * -1);
			GameBase::repairDamage(%player,0.06);
		 	return %delta;
		}
	}
	return 0;
}

//-------------------------------
// ******* Mobile Generator *****
//-------------------------------
$TeamItemMax[AODMobileGen]		= 5;
$InvList[AODMobileGen]		= 1;
$RemoteInvList[AODMobileGen]	= 1;

$ItemMax[larmor, AODMobileGen]		= 0;
$ItemMax[lfemale, AODMobileGen]	= 0;
$ItemMax[marmor, AODMobileGen]		= 0;
$ItemMax[mfemale, AODMobileGen]	= 0;
$ItemMax[harmor, AODMobileGen]		= 1;
$ItemMax[engineer, AODMobileGen]	= 1;
$ItemMax[engineers, AODMobileGen]	= 1;

ItemImageData AODMobileGenImage 
{	shapeFile	= "generator_p";
	mountPoint	= 2;
	mountOffset = { 0, -0.65, -0.4 };
	mas			= 5.0;
	firstPerson = false;
};


ItemData AODMobileGen
{	description		= "Portable Generator";
	shapeFile		= "generator_p";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= AODMobileGenImage;
	shadowDetailMask = 4;
	mass			= 4.5;
	elasticity		= 0.2;
	price			= 2500;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

StaticShapeData MobileGen 
{	description		= "Portable Generator";
	shapeFile		= "generator_p";
	classname		= "pGen";
	debrisId		= flashDebrisSmall;
	sfxAmbient		= SoundGeneratorPower;
	maxDamage		= 1.8;
	mapIcon			= "M_generator";
	damageSkinData	= "objectDamageSkins";
	shadowDetailMask = 16;
	explosionId		= flashExpMedium;
	visibleToSensor = true;
	mapFilter		= 4;
	shieldShapeName = "shield";
		
};


function AODMobileGen::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function AODMobileGen::onDeploy(%player,%item,%pos)
{	if (AODMobileGen::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);
		
	}
}

function AODMobileGen::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	DeployStuff(%player,%item,MobileGen,1,5,0,0,false,2,200);
	
}

function MobileGen::onAdd(%this)
{}

function MobileGen::onDestroyed(%this)
{	if($trace) echo($ver,"| MobileGen::onDestroyed");
	MobileGen::onDisabled(%this);
	StaticShape::objectiveDestroyed(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 3, 0.55, 0.30, 250, 170); 
}

function MobileGen::onEnabled(%this)
{	if($trace) echo($ver,"| MobileGen::onEnabled ",%this);
	GameBase::setActive(%this,true);
	GameBase::playSequence(%this,0,"power");
	GameBase::generatePower(%this, true);
	GameBase::isPowerGenerator(%this);
}

function MobileGen::onDisabled(%this)
{	if($trace) echo($ver,"| MobileGen::onDisabled ",%this);
	GameBase::stopSequence(%this,0);
 	GameBase::generatePower(%this, false);
}

function MobileGen::packUp(%this, %pos, %client, %player)
{	if($trace) echo( $ver@"|MobileGen::Packup");
	if(%this.isBusy)
	{	Client::SendMessage(%client,"Generator is Busy... try packing up later");
		return;
	}
	MobileGen::onDisabled(%this);
	%time=DisconnectGenerator(%this)+1;
	schedule("PackGen("@%this@","@%client@","@%player@");",%time);

}

function PackGen(%this,%client,%player)
{	if(PackUpStuff(%this,%client,%player,"h","Portable Generator",true,AODMobileGen)==false)
	{	MobileGen::onEnabled(%this);
		ConnectGenerator(%this);
	}
}

//------------------------------------
// ******* Portable solar Panel *******
// -----------------------------------
$InvList[AODPortaSolar]		= 1;
$RemoteInvList[AODPortaSolar]	= 1;

$ItemMax[larmor, AODPortaSolar]	= 1;
$ItemMax[marmor, AODPortaSolar]	= 1;
$ItemMax[harmor, AODPortaSolar]	= 1;
$ItemMax[lfemale, AODPortaSolar]	= 1;
$ItemMax[mfemale, AODPortaSolar]	= 1;
$ItemMax[engineer, AODPortaSolar]	= 1;
$ItemMax[engineers, AODPortaSolar]	= 1;

$TeamItemMax[AODPortaSolar] = 5;

ItemImageData AODPortaSolarImage 
{	shapeFile		= "magCargo";
	mountPoint		= 2;
	mountOffset		= { 0, -0.65, -0.4 };
	mountRotation	= { 0, 0, 0 };
	mass			= 2.5;
	firstPerson		= false;
};


ItemData AODPortaSolar
{	description		= "Portable Solar Panel";
	shapeFile		= "solar_med";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= AODPortaSolarImage;
	shadowDetailMask = 4;
	mass			= 1;
	elasticity		= 0.2;
	price			= 500;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

StaticShapeData PortaSolar 
{	description		= "Portable Solar Panel";
	shapeFile		= "solar_med";
	classname		= "pGen";
	debrisId		= flashDebrisSmall;
	maxDamage		= 2;
	mapIcon			= "M_station";
	damageSkinData	= "objectDamageSkins";
	shadowDetailMask = 16;
	explosionId		= flashExpMedium;
	visibleToSensor = true;
	mapFilter		= 4;
};

function AODPortaSolar::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function AODPortaSolar::onDeploy(%player,%item,%pos)
{	if (AODPortaSolar::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);}
}

function AODPortaSolar::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	DeployStuff(%player,%item,PortaSolar,3,4,0,0,false,2,150);
}

function PortaSolar::onDestroyed(%this)
{	if($trace) echo($ver,"|PortaSolar::onDestroyed");
	PortaSolar::onDisabled(%this);
	StaticShape::objectiveDestroyed(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 3, 0.55, 0.30, 250, 170); 
	
}

function PortaSolar::onEnabled(%this)
{	if($trace) echo($ver,"|PortaSolar::onEnabled");
	GameBase::setActive(%this,true);
	GameBase::playSequence(%this,0,"power");
	GameBase::generatePower(%this, true);
	GameBase::isPowerGenerator(%this);
}

function PortaSolar::onDisabled(%this)
{	if($trace) echo($ver,"|PortaSolar::onDisabled");
	GameBase::stopSequence(%this,0);
 	GameBase::generatePower(%this, false);
}

function PortaSolar::packUp(%this, %pos, %client, %player)
{	if($trace) echo( $ver@"|Portable Solar Panel::Packup");
	if(%this.isBusy)
		return;
	PortaSolar::onDisabled(%this);
	%time=DisconnectGenerator(%this)+1;
	schedule("PackSolar("@%this@","@%client@","@%player@");",%time);
}

function PackSolar(%this,%client,%player)
{	if(PackUpStuff(%this,%client,%player,"m h","Portable Solar Panel",true,AODPortaSolar)==false)
	{	PortaSolar::onEnabled(%this);
		ConnectGenerator(%this);
	}
}

//------------------------------------
// ******* Power Node   *******
// -----------------------------------
$InvList[AODPowerNode]			= 1;
$RemoteInvList[AODPowerNode]	= 1;

$ItemMax[larmor, AODPowerNode]	= 1;
$ItemMax[marmor, AODPowerNode]	= 1;
$ItemMax[harmor, AODPowerNode]	= 1;
$ItemMax[lfemale, AODPowerNode]	= 1;
$ItemMax[mfemale, AODPowerNode]	= 1;
$ItemMax[engineer, AODPowerNode]	= 1;
$ItemMax[engineers, AODPowerNode]	= 1;

$TeamItemMax[AODPowerNode] = 50;

ItemImageData AODPowerNodeImage 
{	shapeFile		= "sensor_small";
	mountPoint		= 2;
	mountOffset		= { 0, -0.15, 0 };
	mountRotation	= {-1.570796327, 0 , 0};
	mass			= 2.5;
	firstPerson		= false;
};


ItemData AODPowerNode
{	description		= "Remote Power Node";
	shapeFile		= "sensor_small";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= AODPowerNodeImage;
	shadowDetailMask = 4;
	elasticity		= 0.2;
	price			= 750;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

StaticShapeData PowerNode 
{	description		= "Remote Power Node";
	shapeFile		= "sensor_small";
	classname		= "pGen";
	debrisId		= flashDebrisSmall;
	maxDamage		= 8;
	mapIcon			= "M_generator";
	damageSkinData	= "objectDamageSkins";
	shadowDetailMask = 16;
	explosionId		= flashExpMedium;
	visibleToSensor = true;
	mapFilter		= 4;
	sequenceSound[0] = { "power", SoundSatNode };
};

function AODPowerNode::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function AODPowerNode::onDeploy(%player,%item,%pos)
{	if (AODPowerNode::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);}
}

function AODPowerNode::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	%pNode=(DeployStuff(%player,%item,PowerNode,2,4,4,2,true,2,15));
	if(%pNode)
	{	%team=GameBase::getTeam(%pNode);
		if(!$PowerSatSet[%team])
		{	$PowerSatSet[%team]=newobject("set",SimSet);
			addtoSet("missionCleanup",$PowerSatSet[%team]);
		}
		addtoSet($PowerSatSet[%team],%pNode);
		PowerNode::onEnabled(%pNode);
		return (true);
	}
		
}

function PowerNode::onDestroyed(%this)
{	if($tracePwr) echo($ver,"|PowerNode::onDestroyed");
	%team=GameBase::GetTeam(%this);
	PowerNode::onDisabled(%this);
	DisconnectGenerator(%this);
	StaticShape::objectiveDestroyed(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 3, 0.55, 0.30, 250, 170); 
	removeFromSet($PowerSatSet[%team],%this);
	$TeamItemCount[%team @ AODPowerNode]--;

}

function PowerNode::onEnabled(%this)
{	if($tracePwr) echo($ver,"|PowerNode::onEnabled");
	%team=GameBase::getTeam(%this);
	if(GameBase::getDamageState($PowerSat[%team])=="Enabled")
	{	if(GameBase::isPowered($PowerSat[%team]))
		{	GameBase::setActive(%this,true);
			GameBase::playSequence(%this,0,"power");
			GameBase::generatePower(%this, true);
			GameBase::isPowerGenerator(%this);
		}
	}
}

function PowerNode::onDisabled(%this)
{	if($tracePwr) echo($ver,"|PowerNode::onDisabled");
	GameBase::stopSequence(%this,0);
 	GameBase::generatePower(%this, false);
}


function PowerNode::packUp(%this, %pos, %client, %player)
{	if($trace) echo( $ver@"|PowerNode::Packup");
	if(%this.isBusy)
		return;
	PowerNode::onDisabled(%this);
	%time=DisconnectGenerator(%this)+1;
	schedule("PackNode("@%this@","@%client@","@%player@");",%time);
}

function PackNode(%this,%client,%player)
{	if(PackUpStuff(%this,%client,%player,"","Power Node",true,AODPowerNode)==false)
	{	PowerNode::onEnabled(%this);
		ConnectGenerator(%this);
	}
}
	

//------------------------------------
// ******* Satellite Power System  *******
// -----------------------------------
$InvList[AODSatPwrSys]		= 1;
$RemoteInvList[AODSatPwrSys]	= 1;

$ItemMax[larmor, AODSatPwrSys]		= 0;
$ItemMax[marmor, AODSatPwrSys]		= 0;
$ItemMax[harmor, AODSatPwrSys]		= 1;
$ItemMax[lfemale, AODSatPwrSys]	= 0;
$ItemMax[mfemale, AODSatPwrSys]	= 0;
$ItemMax[engineer, AODSatPwrSys]	= 1;
$ItemMax[engineers, AODSatPwrSys]	= 1;

$TeamItemMax[AODSatPwrSys] = 1;

ItemImageData AODSatPwrSysImage 
{	shapeFile		= "magCargo";
	mountPoint		= 2;
	mountOffset		= { 0, -0.65, -0.4 };
	mountRotation	= { 0, 0, 0 };
	mass			= 8.0;
	firstPerson		= false;
};


ItemData AODSatPwrSys
{	description		= "Satelite Power System";
	shapeFile		= "sat_big";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= AODSatPwrSysImage;
	shadowDetailMask = 4;
	elasticity		= 0.2;
	price			= 4500;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

StaticShapeData SatSystem 
{	description		= "Satelite Power System";
	shapeFile		= "sat_big";
	classname		= "pGen";
	debrisId		= flashDebrisLarge;
	maxDamage		= 15;
	mapIcon			= "M_station";
	damageSkinData	= "objectDamageSkins";
	shadowDetailMask = 16;
	explosionId		= flashExpLarge;
	visibleToSensor = true;
	mapFilter		= 4;
	sfxAmbient		= SoundSatSystem;
};

function AODSatPwrSys::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function AODSatPwrSys::onDeploy(%player,%item,%pos)
{	if (AODSatPwrSys::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);}
}

function AODSatPwrSys::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	%pSat=(DeployStuff(%player,%item,SatSystem,3,6,0,0,true,1,150));
	if(%pSat)
	{	%team=GameBase::getTeam(%pSat);
		if(!$PowerSatSet[%team])
		{	$PowerSatSet[%team]=newobject("set",SimSet);
			addtoSet("missionCleanup",$PowerSatSet[%team]);
		}
		$PowerSat[%team]=%pSat;
		return (true);
	}
}

function SatSystem::packUp(%this, %pos, %client, %player)
{	if($trace) echo( $ver@"|SatSystem::Packup");
	if(PackUpStuff(%this,%client, %player,"h","Satelite Power Transmitter",false,AODSatPwrSys))
	{ DeleteObject($PowerSat[%team]);
	}
}

function SatSystem::onAdd(%this)
{}

function SatSystem::onEnabled(%this)
{	%team=GameBase::getTeam(%this);
	if(GameBase::isPowered(%this))
	{	if(%team != -1)
		{	%tnum = Group::objectCount($PowerSatSet[%team]);
			if($tracePwr) echo( $ver@"|SatSystem::OnEnabled Activating Nodes ",%tnum," for Team ",%team);
			if (%tnum>0)
			{	for (%i=0;%i<%tnum;%i++)
				{	%tgt=Group::getObject($PowerSatSet[%team],%i);
					PowerNode::OnEnabled(%tgt);
				}
			}
			GameBase::setActive(%this,true);
			GameBase::playSequence(%this,0,"power");
		}
	}
}

function SatSystem::onDestroyed(%this)
{	if($trace) echo( $ver@"|SatSystem::onDestroyed");
	%team=GameBase::getTeam(%this);
	SatSystem::onDisabled(%this);
	$PowerSat[%team]=false;
}

function SatSystem::onDisabled(%this)
{	%team=GameBase::getTeam(%this);
	%tnum = Group::objectCount($PowerSatSet[%team]);
	if($tracePwr) echo( $ver@"|SatSystem::OnDisAbled DE-Activating Nodes ",%tnum," for Team ",%team);
	if (%tnum>0)
	{	for (%i=0;%i<%tnum;%i++)
		{	%tgt=Group::getObject($PowerSatSet[%team],%i);
			PowerNode::OnDisabled(%tgt);
		}
	}
}


function SatSystem::onPower(%this, %state, %generator)
{	if($trace) echo($ver,"|SatSystem::onPower this|state|generator ",%this,%state,%generator);
	if (%state)
		SatSystem::onEnabled(%this);
	else
		SatSystem::onDisabled(%this);
}


function ConnectGenerator (%this,%client)
{	if($TracePwr) echo("Connect this ",%this," Generator to Power Grid (Client = ",%client,")");
	if(%this.isBusy)
		return;
	%name=GameBase::GetMapName(%this);
	if(!%name)
		%name=GameBase::GetDataName(%this);

	if(GameBase::getDamageState(%this)!="Enabled")
	{	echo("Backup Generator ",%this," is disabled!!");
		TeamMessages(0,%team,%name@" DISABLED Unable to come ON Line...~wAAODSFX50.wav");
		return;
	}

	%range = %this.pRange;
	ItemBusy(%this);
	%team = GameBase::getTeam(%this);
	echo("Connecting Generator for Team ",%team);
	echo("Connecting Generator for Client ",$User[%client]);

	
	if(%this.pset)
	{	// Generator has a powerset....refresh it
		%pset=%this.pset;
		if($tracePwr) echo("Generator ",%this," has a power set (",%pset,") ....Refreshing");
	}
	else	// Generator does not have a powerset Create one & refresh it
	{	%pset=MakePowerSet(%this);
		%this.powerset=getGroup(%this);
		removeFromSet(%this.powerset,%this);
		addtoSet(%pset,%this);
		%this.pset=%pset;
	}
	// Scan for Items to Power
	%set = newObject("set",SimSet);
	%pos =	GameBase::getPosition(%this);
	%tnum = containerBoxFillSet(%set,$StaticObjectType | $StaticShapeType ,%pos,%range,%range,%range,0);
	%td=0;
	if (%tnum>0)
	{	// There are Items within scan range
		if($tracePwr) echo($Ver,"| Generator Checking ",%tnum," items");
		for (%i=0;%i<%tnum;%i++)
		{	%tgt=Group::getObject(%set,%i);
			%tgtTeam=GameBase::getTeam(%tgt);
			if(PowerReq(%tgt))									// Does Item Require Power then check otherwise don't Bother
			{	if(%team==%tgtTeam)								// Is it of the Same Team
				{	if (!GameBase::isPowered(%tgt))				// Has NO Power so Connect to it!
					{	%td+=3;									// Time to hookup = 3 Sec
						if(%tgt.powerSet=="")					// This Item has Not Been previously Connected to a Portable Generator
						{	%tgt.powerSet=getGroup(%tgt);			// If it Had Power Remeber where it Was from
						}
						if($tracePwr) echo($Ver,"|Item Has No Power - Removing from Old group ",%tgt.powerSet," adding to ",%pset);
						schedule("PowerSet("@%this@","@%tgt@");",%td);
					}
				}
			}			
		}
	}
	deleteObject(%set);
	schedule("ItemNotBusy("@%this@");",%td);
	if (%td==0)
	{	if(%client)
			Client::SendMessage(%client,1,"Connected to grid... Backup power Initialised");
		return (false);
	}
	else
		TeamMessages(0,%team,%name@" connecting to power grid...~wAAODSFX50.wav");
	return (true);
}

function DisconnectGenerator(%this)	
{	if($TracePwr) echo("Disconnecting this ",%this," Generator from Power Grid");
	//	Use when Packing up a Power Generator
	//	& End of Mission 
	//	Unhooks everything
	ItemBusy(%this);
	%pset=%this.pset;
	%name=GameBase::GetMapName(%this);
	if(!%name)
		%name=GameBase::GetDataName(%this);
	%team = GameBase::getTeam(%this);
	%tnum = Group::objectCount(%pset);
	TeamMessages(1,%team,%name@" Going OFF Line...~wAAODSFX50.wav");
	%td=0;
	if (%tnum>0)
	{	for (%i=0;%i<%tnum;%i++)
		{	%tgt=Group::getObject(%pset,0);
			%td+=2;
			schedule("PowerReset("@%this@","@%tgt@");",%td);
		}
	}
	%td+=1;
	schedule("deleteObject("@%pset@");",%td);
	schedule("ItemNotBusy("@%this@");",%td,%this);
	return (%td);
}


function PowerReq(%this)
{	
	%name=GameBase::GetDataName(%this);
	if(%this.powerReq==1) 
		return true;
	else if(%this.powerReq==false) 
		return false;
	else if(%name.classname == "Turret" || %name.classname == "Station" || %name=="PulseSensor" )
		return (true);
	else
		return (false);
}

function RecheckGrid(%this)
{	if($TracePwr) echo("RE-Connect this ",%this," Generator to Power Grid ");
	// Call When Main Power Source has come back online after a failure
	%mset=getGroup(%this);
	%team=GameBase::getTeam(%this);
	%tnum = Group::objectCount($GenSet[%team]);
	if ($tracePwr) echo($ver,"| Main Gen ",%this," Back on line .. re-routing power from ",%tnum," alternate Generators for Team ",%team);
	if (%tnum>0)
	{	for (%i=0;%i<%tnum;%i++)
		{	%tgt=Group::getObject($GenSet[%team],%i);
			%num = Group::objectCount(%tgt.pset);
			if(%num>1)	// If it has more than one object the unit is powering something
			{	for (%j=0;%j<%num;%j++)
				{	%tgt2=Group::getObject(%tgt.pset,%j);
					if(%tgt2.powerset==%mset)	// Object belong in the Power Set for %this which was just restored
					{	removeFromSet(%tgt.pset,%tgt2);
						addToSet(%mset,%tgt2);
						%j--;
						%num--;
					}
				}
			}
		}
	}
}

function EngageBackupPower(%this)
{	if($tracePwr) echo("Engage Backup Power for this ",%this," Generator (It has Been Destroyed or Disabled)");
	%NumFF=0;
	// Call When Main Power has Experienced a failure
	// Check Main Generator Group... If Multiple generators Then Dont Engage Backup
	%Mainset=getGroup(%this);
	%MainNum = Group::objectCount(%MainSet);
	if($tracePwr) echo("Generator Group = ",%MainSet," Number of Items in Group ",%MainNum);
	for (%i=0;%i<%MainNum;%i++)
	{	%tgt=Group::getObject(%MainSet,%i);
		%name = GameBase::getDataName(%tgt);
		%type = GetObjectType(%tgt);
		// if(%name=="" && %type == SimGroup) %name="DoorGroup";
		if($tracePwr) echo("Checking Item ",%tgt," Item is: ",%Name," Class = ",%name.className," type ",%type);
		if(%name == "Generator" || %name == "SolarPanel" || %name == "PortGenerator")
		{	%result=GameBase::getDamageState(%tgt);	
			if(%result==Enabled) %NotReq=True;
		}
		else if(%name=="DoorGroup" || %name.classname == "ForceDoor" || %name.classname == "Door" || %name.classname == "ForceField")
		{	if($TracePwr) echo("Re-Routing ForceField Power for ",%name," Id# ",%tgt);
			%ForceField[%NumFF]=%tgt;
			%NumFF++;
		}
		if(%NotReq==true) %i=%MainNum;
	}

	if(%NotReq) return;
	%team=GameBase::getTeam(%this);
	%tnum = Group::objectCount($GenSet[%team]);
	if ($tracePwr) echo($ver,"| Main Gen ",%this," FAILURE .. ",%tnum," alternate Generators re-checking Grid ",%team);
	%td=0;
	if (%tnum>0)
	{	for (%i=0;%i<%tnum;%i++)
		{	%td+=2;
			%tgt=Group::getObject($GenSet[%team],%i);
			// ForceField Reconnect Routine
			// First Active Generator Gets the ForceFields
			%result=GameBase::getDamageState(%tgt);	
			if(GameBase::getDamageState(%tgt) == "Enabled")
			{	for (%j=0;%j<%NumFF;%j++)
				{	%ff=%ForceField[%j];
					%ff.powerSet=getGroup(%ff);			// Remember where it Was from
					PowerSet(%tgt,%ff);
					//schedule("PowerSet("@%tgt@","@%ff@");",5,%ff);
					if ($tracePwr) echo($ver,"| Routing Power for ",%ff," Forcefield to ",GetGroup(%tgt));
					
				}
			}
			schedule("ConnectGenerator("@%tgt@", false);",%td);
		}
	}
}

function MakePowerSet(%this)
{	%SetName ="PG"@%this;
	%pset= newObject(%SetName,SimGroup);
	addToSet("MissionCleanup", %pset);
	if($tracePwr) echo("Created NEW power set (",%pset,") for Generator ",%this);
	return(%pset);
}

//---------------------------------
// ******* Shield Generator *******
//---------------------------------
//  	Shield Power Functions
// --------------------------------
$InvList[AODShieldGen]		= 1;
$RemoteInvList[AODShieldGen]	= 1;
$TeamItemMax[AODShieldGen]		= 5;

$ItemMax[larmor, AODShieldGen]		= 0;
$ItemMax[lfemale, AODShieldGen]	= 0;
$ItemMax[marmor, AODShieldGen]		= 0;
$ItemMax[mfemale, AODShieldGen]	= 0;
$ItemMax[harmor, AODShieldGen]		= 1;
$ItemMax[engineer, AODShieldGen]	= 1;
$ItemMax[engineers, AODShieldGen]	= 1;

ItemImageData AODShieldGenImage 
{	shapeFile		= "bridge";
	mountPoint		= 2;
	mountOffset		= { 0, -0.65, -0.4 };
	mountRotation	= { 0, 0, 0 };
	mass			= 5.0;
	firstPerson		= false;
};


ItemData AODShieldGen
{	description		= "Shield Generator";
	shapeFile		= "bridge";
	classname		= "Backpack";
	heading			= "dDeployables";
	imageType		= AODShieldGenImage;
	shadowDetailMask = 4;
	elasticity		= 0.2;
	price			= 1500;
	hudIcon			= "deployable";
	showWeaponBar	= true;
	hiliteOnActive	= true;
};

StaticShapeData ShieldGen 
{	description			= "Shield Generator";
	shapeFile			= "bridge";
	classname			= "ShieldGen";
	debrisId			= flashDebrisLarge;
	maxDamage			= 1.8;
	mapIcon				= "M_generator";
	damageSkinData		= "objectDamageSkins";
	shadowDetailMask	= 16;
	explosionId			= LargeShockWave;
	visibleToSensor		= true;
	mapFilter			= 4;
	shieldShapeName		= "shield";
	sequenceSound[0] = { "activate", SoundFabGenStart };
	sequenceSound[1] = { "power", SoundShieldGenerator };
};


function AODShieldGen::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
    {	Player::mountItem(%player,%item,$BackpackSlot);}
    else
	{	Player::deployItem(%player,%item);}
}

function AODShieldGen::onDeploy(%player,%item,%pos)
{	if (AODShieldGen::deployShape(%player,%item))
	{	Player::decItemCount(%player,%item);
		
	}
}

function AODShieldGen::deployShape(%player,%item)
{	//	Deploy ( Player, item, shape, placement, Max Dist, Categorys, Surfaces, Delete, PowerReq,PRange)
	%gen=DeployStuff(%player,%item,ShieldGen,1,5,0,0,false,1,100);
	if(%gen)
	{	%team=GameBase::getTeam(%player);
		$ShieldGen[%team]=%gen;
		$ShieldGenOn[%team]=true;
		if($trace) echo( $ver@"|NodeSet for this team is ",$NodeSet[%team]);
		if(!$NodeSet[%team])
		{	if($trace) echo( $ver@"|Creating a Node Set for Team ",%team);
			$NodeSet[%team] = newObject("ShieldNodes",SimSet);
			addToSet("MissionCleanup", $NodeSet[%team]);
		}
	}
}

function ShieldGen::onAdd(%this)
{}

function ShieldGen::onEnabled(%this)
{	if($trace) echo( $ver@"|Shield Gen OnEnabled");
	%team=GameBase::getTeam(%this);
	if(%this.destroyed==true)
	{	// Was destroyed but is no longer - Has been repaired
		%this.destroyed=false;
	}
	if(GameBase::isPowered(%this))
	{	GameBase::playSequence(%this,0,"power");
		if (%team!=-1)
		{	$ShieldGenOn[%team]=true;
			ActivateNodes(true,%team);
		}
	}
}

function ShieldGen::onDestroyed(%this)
{	if($trace) echo( $ver@"|ShieldGen::onDestroyed");
	%team=GameBase::getTeam(%this);
	if($ShieldGenOn[%team])
		ShieldGen::onDisabled(%this);

	$ShieldGen[%team]=false;
	StaticShape::objectiveDestroyed(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 8.5, 0.10, 55, 23, 3, 1.5, 1.0, 250, 170); 
}

function ShieldGen::onDisabled(%this)
{	if($trace) echo( $ver@"|ShieldGen::onDisabled");
	%team=GameBase::getTeam(%this);
	GameBase::stopSequence(%this,0);
 	$ShieldGenOn[%team]=false;
	ActivateNodes(false,%team);
}

function ShieldGen::packUp(%this, %pos, %client, %player)
{	%armor		= "h";
	%desc		= "Shield Generator";
	%nopack		= true;			// does not have to have no pack on
	%pName	= AODShieldGen;

	%result=PackUpStuff(%this,%client, %player,%armor,%desc,%nopack,%pName);
	if(%result==true)
	{	%team = Client::getTeam(%client);
		$ShieldGenOn[%team]=false;
		ActivateNodes(false,%team);
	}
}

function ShieldGen::onPower(%this, %state, %generator)
{	if($trace) echo($ver,"|ShieldGen::onPower this|state|generator ",%this,%state,%generator);
	if(%state)
		ShieldGen::OnEnabled(%this);
	else
		ShieldGen::OnDisabled(%this);
}



function ActivateNodes(%status,%team)
{	if($trace) echo( $ver@"|Activate Shield Nodes for Team ",%team);
	%num=$TeamItemCount[%team @ AODShieldNode];
	if (%num>0)
	{	for(%i=0;%i<%num;%i++)
		{	%node=Group::GetObject($NodeSet[%team],%i);
			if($trace) echo( $ver@"|Node ID is:",%node);
			if (%status==true)
			{	if($trace) echo( $ver@"|Activating Node :",%i);
				if($trace) echo( $ver@"|Node ID = ",%node);
				RemoteShieldNode::onActivate(%node);}
			else
			{	if($trace) echo( $ver@"|DeActivating Node :",%i);
				if($trace) echo( $ver@"|Node ID = ",%node);
				RemoteShieldNode::onDeActivate(%node);}
		}
	}
	else
		if($trace) echo( $ver@"|No Nodes to Activate");
}

//************************************
// 	AODShieldNode Backpack Script
//************************************
$InvList[AODShieldNode]	= 1;
$RemoteInvList[AODShieldNode]	= 1;
$TeamItemMax[AODShieldNode]	= 60;

$ItemMax[larmor, AODShieldNode]	= 1;
$ItemMax[lfemale, AODShieldNode]	= 1;
$ItemMax[marmor, AODShieldNode]	= 1;
$ItemMax[mfemale, AODShieldNode]	= 1;
$ItemMax[harmor, AODShieldNode]	= 1;
$ItemMax[engineer, AODShieldNode]	= 1;
$ItemMax[engineers, AODShieldNode]	= 1;

ItemImageData AODShieldNodeImage 
{	shapeFile = "sensor_jammer";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 3.0;
	firstPerson = false;
};

ItemData AODShieldNode 
{	description = "Remote Shield Node";
	shapeFile = "sensor_jammer";
	classname = "Backpack";
	heading = "dDeployables";
	imageType = AODShieldNodeImage;
	shadowDetailMask = 4;
	mass = 3.0;
	elasticity = 0.2;
	price = 750;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

StaticShapeData RemoteShieldNode 
{	description		= "Shield Node";
	shapeFile		= "sensor_jammer";
	classname		= "ShieldNode";
	debrisId		= flashDebrisSmall;
	sfxAmbient		= SoundGeneratorPower;
	maxDamage		= 2.5;
	mapIcon			= "M_generator";
	damageSkinData	= "objectDamageSkins";
	shadowDetailMask = 16;
	explosionId		= flashExpMedium;
	visibleToSensor = true;
	mapFilter		= 4;
	maxEnergy		= 50;
};

function AODShieldNode::onUse(%player,%item)
{	if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
	{	Player::mountItem(%player,%item,$BackpackSlot);	}
	else 
	{	Player::deployItem(%player,%item);}
}

function AODShieldNode::onDeploy(%player,%item,%pos)
{	if (AODShieldNode::deployShape(%player,%item)) 
	{	Player::decItemCount(%player,%item);}
}

function AODShieldNode::deployShape(%player,%item)
{	if($trace) echo( $ver@"|Deploying Remote Shield Node");
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
	{	if (GameBase::getLOSInfo(%player,5)) 
		{	%obj = getObjectType($los::object);
			if($trace) echo( $ver@"|Object Type = ",%obj);
			if ((%obj == "SimTerrain" || %obj == "InteriorShape") || (%obj == "Turret" || %obj =="sensor") || (%obj == "Obstruction" || %obj =="Statue") || (%obj == "Hologram" || %obj =="LargeForceField") || ( %obj == "StaticShape"))
			{	%set = newObject("set",SimSet);
				%tnum = containerBoxFillSet(%set,$StaticObjectType,$los::position,2,2,2,0);
				%num = GetNumObjects(%set,0,%tnum);
				if(%num==1) 
				{		%boostObj=Group::getObject(%set,0);
						if (%boostObj.shieldNode)
						{	Client::sendMessage(%client,0,"DANGER!!! Shield Node Feedback!!~wError_message.wav");
							%pos1=GameBase::getPosition(%BoostObj.shieldNode);
							%pos2=GameBase::getPosition(%client);
							%vec=vector::sub(%pos1,%pos2);
							Player::onDamage(%client,$EnergyDamageType,1.5,%pos,%vec,"","head","front_left",%node);
							return false;
						}
						else
						{	deleteObject(%set);
							%prot = GameBase::getRotation(%player);
							%zRot = getWord(%prot,2);
							if (Vector::dot($los::normal,"0 0 1") > 0.6) 
							{	%rot = "0 0 " @ %zRot;}
							else
							{	if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
								{	%rot = "3.14159 0 " @ %zRot;}
								else
								{	%rot = Vector::getRotation($los::normal);}
							}
							%node = newObject("RemoteShieldNode","StaticShape",RemoteShieldNode,true);
							if($traceObj) Echo($Ver,"|Created New Object :",%newitem," | Remote Shield Node");
							echo("Shield Node Created (Node #",%node,") ");
							%team=GameBase::getTeam(%player);
							GameBase::setTeam(%node,%team);
							GameBase::setPosition(%node,$los::position);
							GameBase::setRotation(%node,%rot);
							Gamebase::setMapName(%node,"ShieldNode#" @ $totalNumNodes++ @ " " @ Client::getName(%client));
							Gamebase::StartFadein(%node);
							addToSet("MissionCleanup", %node);
							Client::setOwnedObject(%client, %node); 
							Client::setOwnedObject(%client, %player);
							GameBase::setActive(%node,true);
							playSound(SoundCreateItem,$los::position);
							%boostObj.shieldNode=%node;
							%node.isGuarding=%boostObj;
							// Add Node to Node Set
							if(!$NodeSet[%team])
							{	if($trace) echo( $ver@"|Creating a Node Set for Team ",%team);
								$NodeSet[%team] = newObject("ShieldNodes",SimSet);
								addToSet("MissionCleanup", $NodeSet[%team]);
							}
								
							addToSet($NodeSet[%team],%node);
							%name=GameBase::GetDataName(%boostObj);
							//	Get the shield strength of the Item
							if (!$ShieldGenOn[%team])
								Client::sendMessage(%client,0,"Shield Generator is destroyed or not deployed!!");
							Client::sendMessage(%client,0,"Remote Shield Node deployed - Shield activated on: "@%name);
							$TeamItemCount[GameBase::getTeam(%player) @ "AODShieldNode"]++;
							echo("MSG: ",$User[%client]," deployed a Remote Shield Node on ",%name);
							return true;						
						}
				}
				else 
				{	deleteObject(%set);
					if (%num>1)
					{	Client::sendMessage(%client,0,"Too Many Items in area - unable to obtain single interface");}
					else if (%num==0)
					{	Client::sendMessage(%client,0,"Nothing to interface to.\n Node Must be placed close to an object which will have its shield boosted.~Werror_message.wav");}
				}
				
			}
			else Client::sendMessage(%client,0,"Can only deploy on terrain/buildings or objects");
		}
		else Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	return false;
}


function RemoteShieldNode::onEndSequence(%this)
{	echo("Node on End sequence");
	if(%this.position==1)	
		GameBase::playSequence(%this,0,"power");
}

function RemoteShieldNode::onDestroyed(%this)
{	if($trace) echo( $ver@"|Remote Shield Node::On destroyed");
	%team=GameBase::getTeam(%this);
	$TeamItemCount[%team @ "AODShieldNode"]--;
	$totalNumNodes--;
	for(%i=0;%i<=Group::objectCount($NodeSet[%team]);%i++)
	{	%node=Group::GetObject($NodeSet[%team],%i);
		if(%node==%this)
		{	removeFromSet($NodeSet[%team], %i);
		}
	}
	%boostObj				= %this.isGuarding;
	%this.isGuarding		="";
	%boostObj.shieldNode	="";
						
	if ($ShieldGen[%team])
	{	if($trace) echo( $ver@"|Shield Gen Exists applying Node Feedback Damage");
		%pos1=GameBase::getPosition(%this);
		%pos2=GameBase::getPosition($ShieldGen[%team]);
		%vec=vector::sub(%pos1,%pos2);
		%damageLevel = GameBase::getDamageLevel($ShieldGen[%team]);
		NewStaticShapeDamage($ShieldGen[%team],%this,%damageLevel,0.35);
	}
}

function RemoteShieldNode::onDisabled(%this)
{	if($trace) echo( $ver@"|Remote Shield Node on Disabled");
	GameBase::setRechargeRate(%this,0);
	Gamebase::setEnergy(%this,0);
	%this.Position=0;
	GameBase::stopSequence(%this,0);
	GameBase::setSequenceDirection(%this,1,0);
	GameBase::playSequence(%this,1,"deploy");
	%this.shieldStrength = 0;
	
}

function RemoteShieldNode::onActivate(%this)
{	%team=GameBase::getTeam(%this);
	%this.shieldStrength = 0.03; //had 2
	if($ShieldGen[%team])
	{	if($ShieldGenOn[%team])
		{	GameBase::setActive(%this,true);
			%this.Position=1;
			GameBase::setSequenceDirection(%this,1,1);
			GameBase::playSequence(%this,1,"deploy");
			GameBase::setRechargeRate(%this,15);
			GameBase::playSequence(%this,1); 
		}
		else
			if($trace) echo($Ver,"| Shield Generator is Off!");

	}
	else
		if($trace) echo( $ver@"|Shield Generator Does Not Exist for This Team");
	
}

function RemoteShieldNode::onEnabled(%this)
{	RemoteShieldNode::onActivate(%this);
}

function RemoteShieldNode::onDeActivate(%this)
{	RemoteShieldNode::onDisabled(%this);
}

function RemoteShieldNode::packUp(%this, %pos, %client, %player)
{	if($trace) echo( $ver@"|Pack up Remote shield node");
	%name = Client::getName(%client);
	%team = Client::getTeam(%client);
	%pack=Player::getMountedItem(%player,$BackpackSlot);
	if($trace) echo( $ver@"|Player is wearing Pack Item :",%pack);
	if(%pack== -1)	// Must Have No Pack on....
	{	if($trace) echo( $ver@"|Shield Node Pickup Routine");
		if(!GameBase::getDamageLevel(%this))				// Node is Damaged
		{	if (!$ShieldGenOn[%team])
			{	Client::sendMessage(%client,0,"Shield Generator is destroyed or not deployed!!/nUnable to self-repair node..");
				return;
			}
			else
				Client::sendMessage(%client,0,"Shield Generator active/nRunning node self-repair.");
		}
		for(%i=0;%i<=Group::objectCount($NodeSet[%team]);%i++)
		{	%node=Group::GetObject($NodeSet[%team],%i);
			if(%node==%this)
			{	removeFromSet($NodeSet[%team], %i);
			}
		}
		%boostObj				=%this.isGuarding;
		%BoostObj.shieldNode	="";
		%this.isGuarding		="";
		%pos=vector::add(Gamebase::getPosition(%this),"0 0 0.5");
		%player.isDeploying = true;
		%player.deployPosition = %pos;
		GameBase::startFadeOut(%this);
		schedule("deleteObject(" @ %this @ ");",1.75,%this);			
		schedule("PlaceItemPack(" @ %player @ ",AODShieldNode,\"" @ %pos @ "\");",2,%player);
		RemoteShieldNode::onDisabled(%this);
		echo("MSG: ",%client," Packed up a remote Shield Node");
	}
	else
		Client::sendMessage(%client,0,"Unable to Pack up Node.. You are wearing a Pack!~wError_message.wav");
}

//DaEndz 
function ItemBusy(%this)
{	%this.isbusy=true;
}

function ItemNotBusy(%this)
{	%this.isbusy=false;
}


$ObjType[0]="DeployableTurret";
$ObjType[1]="VELCROTurret";
$ObjType[2]="GROGTurret";
$ObjType[3]="SAMTurret";
$ObjType[4]="RocketTurret";
$ObjType[5]="PlasmaTurret";
$ObjType[6]="MORTTurret";
$ObjType[7]="AATurret";
$ObjType[8]="ELFTurret";
$ObjType[9]="IndoorTurret";
$ObjType[10]="ArtilleryTurret";
$ObjType[11]="AmbusherAP";
$ObjType[12]="AmbusherAA";

// ForceFields 
$ObjType[13]="DeployableField1";
$ObjType[14]="DeployableField2";
$ObjType[15]="SmallForceDoor";
$ObjType[16]="LargeForceDoor";

// Other Static Objects
$ObjType[17]="PulseSensor";
$ObjType[18]="Generator";
$ObjType[19]="SolarPanel";
$ObjType[20]="MobileBunker";
$ObjType[21]="MobileBlastShield";
$ObjType[22]="VehiclePad";
$ObjType[23]="ShieldGen";
$ObjType[24]="TeamEngGen";
$ObjType[25]="MobileGen";
$ObjType[26]="MobileInvent";
$ObjType[27]="InventoryStation";
$ObjType[28]="JumpPad";
$ObjType[29]="PortaSolar";
$ObjType[30]="Teleporter";
$ObjType[31]="TeleporterNode";
$ObjType[32]="SolarFGen";
$ObjType[33]="CounterBattery";
$ObjType[34]="SatSystem";
$ObjType[35]="Alarm";
$ObjType[36]="PortGenerator";
$ObjType[37]="AmmoStation";
$ObjType[38]="DeployableAmmoStation";
$ObjType[39]="DeployableInvStation";
$ObjType[40]="CommandStation";
$ObjType[41]="VehicleStation";



	
function GetNumObjects(%set,%type,%tnum)
{	if(%tnum==0)
		return (0);
	if(%type==4)
		return(0);

	if(%type==1)	//	Turrets only
	{	%num=0;
		%num+=CountObjects(%set,$ObjType[0],%tnum);
		%num+=CountObjects(%set,$ObjType[1],%tnum);
		%num+=CountObjects(%set,$ObjType[2],%tnum);
		%num+=CountObjects(%set,$ObjType[3],%tnum);
		%num+=CountObjects(%set,$ObjType[4],%tnum);
		%num+=CountObjects(%set,$ObjType[5],%tnum);
		%num+=CountObjects(%set,$ObjType[6],%tnum);
		%num+=CountObjects(%set,$ObjType[7],%tnum);
		%num+=CountObjects(%set,$ObjType[8],%tnum);
		%num+=CountObjects(%set,$ObjType[9],%tnum);
		%num+=CountObjects(%set,$ObjType[10],%tnum);
		%num+=CountObjects(%set,$ObjType[11],%tnum);
		%num+=CountObjects(%set,$ObjType[12],%tnum);
		return (%num);
	}
	else if(%type==2)	// Forcefields Only
	{	%num=0;
		%num+=CountObjects(%set,$ObjType[13],%tnum);
		%num+=CountObjects(%set,$ObjType[14],%tnum);
		%num+=CountObjects(%set,$ObjType[15],%tnum);
		%num+=CountObjects(%set,$ObjType[16],%tnum);
		return (%num);
	}
	else if(%type==3)	// Forcefields & Static Objects
	{	%num=0;
		%num+=CountObjects(%set,$ObjType[13],%tnum);
		%num+=CountObjects(%set,$ObjType[14],%tnum);
		%num+=CountObjects(%set,$ObjType[15],%tnum);
		%num+=CountObjects(%set,$ObjType[16],%tnum);
		%num+=CountObjects(%set,$ObjType[17],%tnum);
		%num+=CountObjects(%set,$ObjType[18],%tnum);
		%num+=CountObjects(%set,$ObjType[19],%tnum);
		%num+=CountObjects(%set,$ObjType[20],%tnum);
		%num+=CountObjects(%set,$ObjType[21],%tnum);
		%num+=CountObjects(%set,$ObjType[22],%tnum);
		%num+=CountObjects(%set,$ObjType[23],%tnum);
		%num+=CountObjects(%set,$ObjType[24],%tnum);
		%num+=CountObjects(%set,$ObjType[25],%tnum);
		%num+=CountObjects(%set,$ObjType[26],%tnum);
		%num+=CountObjects(%set,$ObjType[27],%tnum);

		%num+=CountObjects(%set,$ObjType[28],%tnum);
		%num+=CountObjects(%set,$ObjType[29],%tnum);
		%num+=CountObjects(%set,$ObjType[30],%tnum);
		%num+=CountObjects(%set,$ObjType[31],%tnum);
		%num+=CountObjects(%set,$ObjType[32],%tnum);
		%num+=CountObjects(%set,$ObjType[33],%tnum);
		%num+=CountObjects(%set,$ObjType[34],%tnum);
		%num+=CountObjects(%set,$ObjType[35],%tnum);
		%num+=CountObjects(%set,$ObjType[36],%tnum);
		%num+=CountObjects(%set,$ObjType[37],%tnum);
		%num+=CountObjects(%set,$ObjType[38],%tnum);
		%num+=CountObjects(%set,$ObjType[39],%tnum);
		%num+=CountObjects(%set,$ObjType[40],%tnum);
		%num+=CountObjects(%set,$ObjType[41],%tnum);
				
		return(%num);
	}
	else if(%type==0)
	{	%num=0;
		%num+=CountObjects(%set,$ObjType[0],%tnum);
		%num+=CountObjects(%set,$ObjType[1],%tnum);
		%num+=CountObjects(%set,$ObjType[2],%tnum);
		%num+=CountObjects(%set,$ObjType[3],%tnum);
		%num+=CountObjects(%set,$ObjType[4],%tnum);
		%num+=CountObjects(%set,$ObjType[5],%tnum);
		%num+=CountObjects(%set,$ObjType[6],%tnum);
		%num+=CountObjects(%set,$ObjType[7],%tnum);
		%num+=CountObjects(%set,$ObjType[8],%tnum);
		%num+=CountObjects(%set,$ObjType[9],%tnum);
		%num+=CountObjects(%set,$ObjType[10],%tnum);
		%num+=CountObjects(%set,$ObjType[11],%tnum);
		%num+=CountObjects(%set,$ObjType[12],%tnum);
		%num+=CountObjects(%set,$ObjType[13],%tnum);
		%num+=CountObjects(%set,$ObjType[14],%tnum);
		%num+=CountObjects(%set,$ObjType[15],%tnum);
		%num+=CountObjects(%set,$ObjType[16],%tnum);
		%num+=CountObjects(%set,$ObjType[17],%tnum);
		%num+=CountObjects(%set,$ObjType[18],%tnum);
		%num+=CountObjects(%set,$ObjType[19],%tnum);
		%num+=CountObjects(%set,$ObjType[20],%tnum);
		%num+=CountObjects(%set,$ObjType[21],%tnum);
		%num+=CountObjects(%set,$ObjType[22],%tnum);
		%num+=CountObjects(%set,$ObjType[23],%tnum);
		%num+=CountObjects(%set,$ObjType[24],%tnum);
		%num+=CountObjects(%set,$ObjType[25],%tnum);
		%num+=CountObjects(%set,$ObjType[26],%tnum);
		%num+=CountObjects(%set,$ObjType[27],%tnum);
		%num+=CountObjects(%set,$ObjType[28],%tnum);
		%num+=CountObjects(%set,$ObjType[29],%tnum);
		%num+=CountObjects(%set,$ObjType[30],%tnum);
		%num+=CountObjects(%set,$ObjType[31],%tnum);
		%num+=CountObjects(%set,$ObjType[32],%tnum);
		%num+=CountObjects(%set,$ObjType[33],%tnum);
		%num+=CountObjects(%set,$ObjType[34],%tnum);
		%num+=CountObjects(%set,$ObjType[35],%tnum);
		%num+=CountObjects(%set,$ObjType[36],%tnum);
		%num+=CountObjects(%set,$ObjType[37],%tnum);
		%num+=CountObjects(%set,$ObjType[38],%tnum);
		%num+=CountObjects(%set,$ObjType[39],%tnum);
		%num+=CountObjects(%set,$ObjType[40],%tnum);
		%num+=CountObjects(%set,$ObjType[41],%tnum);
		
		return(%num);
	}
}

function CheckItemPickup(%player)
{	if($traceDep) echo( $ver@"|Check Item Pickup (player) (",%player,") Is Deploying: ",%client.isDeploying);
	%client = Player::getClient(%player);
	if(!%player.isDeploying) 
	{	if(GameBase::getLOSinfo(%player,3)) 
		{	%this = $los::object;
			%name = GameBase::getDataName(%this);
			if($trace) echo( $ver@"|Packing Up a ",%name);
			if((%name.classname != Armor) && (%name.classname != Vehicle) && (%name.classname != Generator)) 
			{	%thisTeam = GameBase::getTeam(%this);
				%team = Client::getTeam(%client);
				if(%team == %thisTeam) GameBase::virtual(%this,"packUp",$los::position,%client,%player);
			}
		}
	}
}

function PlaceItemPack(%player, %pack, %pos)
{	%team=GameBase::getTeam(%player);
	%obj = newObject("","Item",%pack,1,false);
	schedule("Item::Pop(" @ %obj @ ");", 30, %obj);
	addToSet("MissionCleanup", %obj);
	GameBase::setPosition(%obj,%pos);
	$TeamItemCount[%team @ %pack]--;
	playSound(SoundPackupItem,%pos);
	%player.isDeploying = false;
}


function Mission::reinitData()
{	
	%numPlayers = getNumClients();
	
	for(%i = 0; %i < %numPlayers; %i++)
	{	%pl = getClientByIndex(%i);
		if($trace) echo($ver,"| Resetting Team Kill counts for - ",$User[%pl]);
		%pl.teamkills=0;
		%pl.tkobjects=0;
	}

	for(%i = -1; %i < 2 ; %i++)		// AAOD Mod Only Supports 2 Teams at this time
	{	$NodeSet[%i]		= false;
		$AAPCSet[%i]		= false;
		$PowerSet[%i]		= false;
		$PowerSat[%i]		= false;				// Satelite Power System
		$PowerSatSet[%i]	= "";				// Satelite Power System Node Set
		$TeamEnergy[%i]		= $DefaultTeamEnergy;
		$LastEnergy[%i]		= 0;
		$IncTeamEnergy[%i]	= $DefTeamEnergyInc; 
		$ShieldGenOn[%i]	= false;
		$ShieldGen[%i]		= false;
		$NodeSet[%i]		= "";
		$AAPCSet[%i]		= false;
		$LastFlagHolder[%i]	= false;
		$Teleporter[%i]		= false;
		$TeleportNode[%i]	= false;
		$ClassBGen[%i]		= "";
		$ClassAGen[%i]		= "";
		$Alarm[%i]			= false;
		$GenSet[%i]			= "";
				
		$TeamItemCount[%i @ DeployableAmmoPack]			= 0;
		$TeamItemCount[%i @ DeployableInvPack]			= 0;
		$TeamItemCount[%i @ TurretPack]					= 0;
		$TeamItemCount[%i @ CameraPack]					= 0;
		$TeamItemCount[%i @ DeployableSensorJammerPack] = 0;
		$TeamItemCount[%i @ PulseSensorPack]			= 0;
		$TeamItemCount[%i @ MotionSensorPack]			= 0;
		$TeamItemCount[%i @ ScoutVehicle]				= 0;
		$TeamItemCount[%i @ LAPCVehicle]				= 0;
		$TeamItemCount[%i @ HAPCVehicle]				= 0;
		$TeamItemCount[%i @ Beacon]						= 0;
		$TeamItemCount[%i @ mineammo]					= 0;
		$TeamItemCount[%i @ deployableTeleport]					= 0;
		$TeamItemCount[%i @ teleportpack]				= 0;
		$TeamItemCount[%i @ AODVelcroPack]				= 0;
		$TeamItemCount[%i @ AODInfernoPack]				= 0;
		$TeamItemCount[%i @ AODForce1Pack]				= 0;
		$TeamItemCount[%i @ AODForce2Pack]				= 0;
		$TeamItemCount[%i @ AODForceDoorS]				= 0;
		$TeamItemCount[%i @ AODForceDoorL]				= 0;
		$TeamItemCount[%i @ AODVehicle1]				= 0;
		$TeamItemCount[%i @ AODVehicle2]				= 0;
		$TeamItemCount[%i @ AODAAPack]					= 0;
		$TeamItemCount[%i @ AODDefender]				= 0;
		$TeamItemCount[%i @ AODArtilleryPack]			= 0;
		$TeamItemCount[%i @ AODMORTPack]				= 0;
		$TeamItemCount[%i @ AODBunker]					= 0;
		$TeamItemCount[%i @ AODBlastShield]				= 0;
		$TeamItemCount[%i @ AODMobileInv]				= 0;
		$TeamItemCount[%i @ AODMobileGen]				= 0;
		$TeamItemCount[%i @ AODShieldGen]				= 0;
		$TeamItemCount[%i @ AODShieldNode]				= 0;
		$TeamItemCount[%i @ AODTeamEGen]				= 0;
		$TeamItemCount[%i @ AODAmbushApPack]			= 0;
		$TeamItemCount[%i @ AODAmbushAAPack]			= 0;
		$TeamItemCount[%i @ AODJumpPad]					= 0;
		$TeamItemCount[%i @ AODTeleporter]				= 0;
		$TeamItemCount[%i @ AODCounterBattery]			= 0;
		$TeamItemCount[%i @ AODSolarTEGen]				= 0;
		$TeamItemCount[%i @ AODPortaSolar]				= 0;
		$TeamItemCount[%i @ AODSatPwrSys]				= 0;
		$TeamItemCount[%i @ AODPowerNode]				= 0;
		$TeamItemCount[%i @ AODAlarm]					= 0;
	}
	$totalNumCameras = 0;
	$totalNumTurrets = 0;
	
}

function Powerset(%gen,%object)
{	%gname=GameBase::GetMapName(%gen);
	if(!%gname)
		%gname=GameBase::GetDataName(%gen);
	%pset=%gen.pset;
	%mname = GameBase::getMapName(%object);
	if(%mname=="")							
		%mname = GameBase::getDataName(%object);
	%team=GameBase::getTeam(%gen);
	TeamMessages(0,%team,"Power for "@%mname@" routed to :"@%gname@"~wAAODSFX52.wav");
	%OldSet=getGroup(%object);
	RemoveFromSet(%OldSet,%object);
	%res=AddToSet(%pset,%object);
	if ($tracePwr) echo("Power for "@%object@" routed to power group "@%pset@" generator "@%gen@" for Team ",%team);
}

function Powerreset(%gen,%object)
{	%gname=GameBase::GetMapName(%gen);
	if(!%gname)
		%gname=GameBase::GetDataName(%gen);
	%pset=%gen.pset;
	%mname = GameBase::getMapName(%object);
	if(%mname=="")							
		%mname = GameBase::getDataName(%object);
	%team=GameBase::getTeam(%gen);
	if(%object.powerReq!=2)
		TeamMessages(0,%team,"Power for "@%mname@" disconnected from "@%gname@"~wAAODSFX52.wav");
	removeFromSet(%pset,%object);
	%res=addToSet(%object.powerSet,%object);
	if ($tracePwr) echo("Power for ",%object," set to orignal group ",%object.powerSet," from  generator ",%gen," for Team ",%team);
}


function PowerItem (%this,%range,%client)
{	if($TracePwr) echo($ver,"|Looking for POWER for ",%this," in a ",%range," meter area");
	//** Search Area within specified range
	//** If a Main Generator exists Draw power from that
	//** If a portable generator exists Place %this into the power set for it..
	%numGen=0;
	%team = GameBase::getTeam(%this);
	%set = newObject("set",SimSet);
	%pos =	GameBase::getPosition(%this);
	%tnum = containerBoxFillSet(%set, $StaticObjectType ,%pos,%range,%range,%range,0);
	echo(" Number of Objects Found = ",%tnum);
	if (%tnum>0)
	{	// There are Items within scan range
		if($trace) echo($Ver,"|Scanning ",%tnum," items");
		for (%i=0;%i<%tnum;%i++)
		{	%tgt=Group::getObject(%set,%i);
			%tgtTeam=GameBase::getTeam(%tgt);
			%name = GameBase::getDataName(%tgt);
			if(%team==%tgtTeam)	
			{	if(%name == "Generator" || %name == "SolarPanel" || %name == "PortGenerator")
				{	%nset=getGroup(%tgt);
					if(GameBase::getDamageState(%tgt) == "Enabled")
					{	Client::sendMessage(%client,1,"Main Power connection found..connecting~wAAODSFX16.wav");
						if($tracePwr) echo($Ver,"| Found MAIN Generator : Group ",%nset," Placing Unit in Group");	
						// %power=true;
						if(%nset)
						{	addToSet(%nset,%this);
							%this.powerset=%nset;
							%i=%tnum;
						}
						%numGen++;
					}
					else if(%nset) %this.powerset=%nset;	// Route Main Connection to Main Power Group...

				}
				else if(%name == "MobileGen" || %name == "PortaSolar" || %name == "PowerNode")
				{	if($tracePwr) echo($Ver,"|Found an alternate Power Source.. if needed ",%tgt);
					%Pgen=%tgt;	
				}
					
			}
			
		}
	}
	deleteObject(%set);
	if (%numGen==0)										// If there are No Main Generators to connect to... then
	{	if(%Pgen)										// If there is a portable Power Source connect to it
		{	if($trace) echo($Ver,"|Found a Secondary power Generator ",%PGen," Connecting to it");
			Client::sendMessage(%client,1,"Secondary Power connection found..connecting");
			%result=GameBase::getDamageState(%Pgen);	// Check state of Generator
			%nset=getGroup(%Pgen);
			if(%nset)
				addToSet(%nset,%this);
			//if(%result==Enabled)
				// %power=true;
			//else
				// %power=false;
			// GameBase::virtual(%this,"onPower",%power,%Pgen);
			return (true);
		}
		else
		{	Client::sendMessage(%client,1,"Unable to obtain Power!! Too far from any power generators!!~Werror_message.wav");
			return (false);
		}

	}
	return (true);
}
