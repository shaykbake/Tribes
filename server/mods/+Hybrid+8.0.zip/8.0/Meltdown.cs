
######################################
# Server startup variables           #
# Color Tags:                        #
# White Text = <f2>                  #
# Light Text = <f1>                  #
# Normal Text = <f0>                 # 
# \n = New Line                      #
# Leaving the messages without color #
# tags will result in the usage of   #
# the last used color                #
# In this case, White.               #
# You can also use these commands    #
# for setting up your server         #
# information (serverprefs.cs)       #
######################################
#############################################
# Server Switches (set to false to disable) #
#############################################

$Meltdown::PublicAdminVote = False; 		// Can vote to admin
$Meltdown::ChangeMissionVote = True; 		// Can vote to change missions
$Meltdown::ChangeTeams = True; 			// Must be true for Fair teams to work
$Meltdown::KickVote = True; 				// Can vote to Kick
$Meltdown::TeamDamageSwitch = True; 		// Can vote to Enable/disable team damage
$Meltdown::FlagReturnTime = 30; 			// Time in seconds before flag will return to it's flagstand
$Meltdown::StationTime = 50; 				// Cannot be less than 10 or higher than 60 or else it will use default. Set to false to disable
$Meltdown::VoteIncTime = 15; 				// # of mins to vote to increase time
$Meltdown::KickMessage = "You Must Have Pissed +]-[+Armagedon+ Off";  // The message that displays when you kick/ban someone  
$mallcomment = "LoL you die too fast";	      // What displays in the bottom mission window when they respawn
$trace = false;						// Extra in-game messages exported to console

###########################
# Server Anti-TK settings #
###########################

$TeamKillMin = 2;             			// Before he can qualify for being kicked for TKs
$Meltdown::TKLimit = 3; 				// How many TKs before he is kicked 


