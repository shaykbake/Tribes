//////////////////////////////////////////////////////
//||     || \\     // |||||) |||||) |||||||| ||||||)//
//||     ||  \\   //  || ||) || ||)    ||    ||   |)//
//||-----||   \\ //   |||||  |||||)    ||    ||   |)//
//||     ||    | |    || ||) |||\\     ||    ||   |)//
//||     ||    | |    |||||) ||  \\ |||||||| ||||||)//
//////////////////////////////////////////////////////
//Mod By: +]-[+Armagedon 2000-2002�                 //
//Made For The +]-[ybrid+ Clan                      //
//WebSite: www.HTribe.cjb.net                       //
////////////////////////////////////////////////////////////////
//CopyRight Agreement.                                        //
//By Downloading or By Obtaining my mod by any means          //
//You Have Argreed To My CopyRight.Which is As Follows        //
//You Have No Premission From Me The Creator Of This Mod      //
//To Edit Or use ANY Code.If You Do use My Code I Will pursue //
//You To The Extent Of The CopyRight Laws Of PA.              //
//Which Can Get Very Bad For The Deffendant.                  //
////////////////////////////////////////////////////////////////
//More Info About CopyRight Laws Go Here                      //
//http://www.whatiscopyright.org/copyright.html               //
////////////////////////////////////////////////////////////////
