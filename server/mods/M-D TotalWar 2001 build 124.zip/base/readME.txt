Meltdown War 2001 clientpack.


just unzip this to your base folder.
there will be a new folder created called meltdown all the files will be located there.
just delete that folder to uninstall.