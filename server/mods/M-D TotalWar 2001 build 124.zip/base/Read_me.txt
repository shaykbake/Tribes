models copyright tenabrae 1999. These models are freely distributable for non-commercial use only as long as credit is given to me. permission is granted to change the skin bitmap.

to use these models in a mod simply change the name of the shapefile of the gun to the name of the .dts file. eg. to change the plasma gun - shapefile = "plasma" would become shapefile = "<model name>", note item.cs refers to shapefile twice so change both.

clientside put the models in your base directory, any mod that calls for them will find them there, you will not need to download the models for each mod wishing to use them.