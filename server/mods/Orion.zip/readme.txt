                       Orion Mod
                          by
                      Jason Avina


****WARNING****WARNING****WARNING***WARNING***WARNING***
      This patch is filled with a lot of cool stuff. 
I think I did a good job equaling everything out by
taking in account all of their abilities.  However, some
things you may not like.  If you find an addition to be 
too powerful let me know.  I really hope you enjoy my mod.
****ENJOY****ENJOY****ENJOY****ENJOY****ENJOY***ENJOY***

--------------------------------------------------------------
	             INSTALLATION
--------------------------------------------------------------

Just put the orionmod folder and orion.bat into your Tribes 
directory.  Then run the orion.bat file to start the mod. 

--------------------------------------------------------------
			CHANGES
--------------------------------------------------------------

Five New Mission Types - This includes Tribes Tag, Arena, Flag
Hunter, Team Deathmatch and Chase the Rabbit.  Now you can enjoy 
all these new styles of play with the new additions in my mod.

Rocket Launcher - Can only be carried by Heavy Armors.  This will 
fire a rocket which does the same damage as a disk launcher, but 
if you get your target in your sights it will track them like a 
rocket turret does.  The tracking missile also does more damage.

Laser Rifle - No energy Pack required to use it, but your energy
recharges slower without one.

Cloaking Device - New pack which turns the wearer invisible.  
It still shows the enemy icon over your head if you are put on
the enemies' sensor network, so try not to get too close to players 
or sensors.

Kamikaze Pack - When used you will drop a bomb which will
kill anything in it's radius, sadly, this also includes you.
Only heavies can carry this item.

Command Laptop - This pack lets you control your turrets without 
being at a command station.

Heatsink - This pack masks your heat signature so rocket turrets
won't fire at you.  If the driver of a vehicle has this pack on
it will tap into the vehicles systems and mask it's heat too. 
Rocket Turrets will still fire at you if controlled by a player, 
but the missile doesn't seek you as well if you have this pack. 

Teleport Pack - Let's you teleport from your current location
back to one of your team's spawn points.  However, the sheer 
power of the teleportation flux will not allow you to take a 
flag with you, and it needs to recharge for 10 seconds after 
each use.

Force Fields - This deployable is a forcefield that works like
a Forcefield Doorway.  It will disappear for all your teammates
to pass through, but not for enemies.  You may have four
Forcefields per team and they can be placed on walls and 
ceilings also. They take a moderate amount of damage to destroy, 
and if damaged it will slowly heal itself if not destroyed.

Sentry Turrets - Replace the old turrets.  Pretty much just
turrets with a blast radius and shields, but they can also be 
placed on walls and ceilings.  Ten Sentries per team.

Missile Turrets - Deployable Rocket Turrets which are great for
stopping opponents from jetting and flying vehicles.  Only heavy armor
may deploy these turrets.  Two Missile Turrets per team.

Sentinel (Motion) Turrets - Decreased the damage a sentinel (motion) 
turret can take.  They also have splash damage like the Sentries do.

Beacons - Made them harder to destroy, so they are actually useful.

Spawning - You now spawn with just the disc launcher and a repair kit.

Chaingun - Increased amount of ammo and rate of fire, but decreased 
it's damage.

Skins - Added personal skins option, but other players must have 
your skin to see you wearing it.

Vehicles - Increased speed and handling of all the vehicles.  Also,
Heavy and Medium Armors can now pilot the APCs.

Scout - Slowed it down a bit and made it easier to kill.  To keep 
it attractive, I replaced the rockets with a dual chaingun, which 
gives you better accuracy while flying with a bad ping.

Deployables - Made all the deployables (motion sensors, cameras,
turrets, etc.) a little harder to destroy.

Grenade Launcher - No grenade launcher for light armors.  This
makes the medium more attractive for base assaults, so maybe we'll 
actually see one or two people wearing it in the future.

Scoring - You gain one point for returning your flag, you lose 
a point for dropping the flag within 100 meters of the enemies'
flagstand and capturing a flag is worth ten points, so make sure 
you plan your attack wisely. 

Mines/Grenades - Mines won't explode for your teammates. I also 
changed their ammo limits......

Armor	      Mines	Grenades
------------------------------------
Light           1          3
Medium          3          5
Heavy           5          7

Ammo - Changed the weapon ammo limits for the armors to balance 
them out.

Ammo Pack - It can now hold two Repair Kits.

Scores - Now shows the person with the most kills, most points and 
most deaths at the end of a mission.

Lessened Skiing - I reduced the Jump Impulse for all armors to
help reduce skiing speeds.  This was very effective for the heavy
armor, so we might see less lone wolf heavy offense.  As a side 
note to all you skiers out there...heavy offense is what the 
APCs are for.

Remote Inv. Stations - You can now buy armor from them.

Blaster Speed - Blaster still has same rate of fire, but the 
speed of it's round moves a little faster.  I did this so it's
a better anti-sniping weapon for medium and heavy armors.

No Out of Bounds - You will now take damage for going out of the
mission area in all mission types.

Autoadmin Feature - This will automatically admin you when you 
join the server, as long as your name is in the serverprefs.cs
file for the server.  Servers please keep me as an autoadmin 
and add any additional players after my name.  I spent my time 
making this mod and I feel I deserve this small priveledge.
NOTE - this only gives basic admin features, not superadmin.

  Forgive me if I've missed something.  Have fun, enjoy my 
patch, and please e-mail me with your thoughts and suggestions.

E-mail = avina@henry-net.com
                                  Thanx,  Jason Avina

--------------------------------------------------------------
		      SPECIAL THANX
--------------------------------------------------------------

I would like to thank all the mods which I took the ideas from,
this includes Renegades, Shifter, Ideal and Balance of Power.  
Anyone I left out, please forgive me and e-mail me if you would
like your deserved credit.

