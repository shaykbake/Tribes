///-----------------------------------------------
/// description = "Door 5x5 Force Field Door";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[sarmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[barmor, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[harmor, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[darmor, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[marmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[mfemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[earmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[efemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[lfemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[sfemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[bfemale, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[spyarmor, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[spyfemale, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[adarmor, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[sadarmor, doorfivebyfiveForceFieldPack] = 0;
$ItemMax[parmor, doorfivebyfiveForceFieldPack] = 0;