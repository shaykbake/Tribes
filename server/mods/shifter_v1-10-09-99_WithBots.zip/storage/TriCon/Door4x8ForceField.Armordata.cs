///-----------------------------------------------
/// description = "Door 3x4 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[sarmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[barmor, doorfourbyeightForceFieldPack] = 0;
$ItemMax[harmor, doorfourbyeightForceFieldPack] = 0;
$ItemMax[darmor, doorfourbyeightForceFieldPack] = 0;
$ItemMax[marmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[mfemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[earmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[efemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[lfemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[sfemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[bfemale, doorfourbyeightForceFieldPack] = 0;
$ItemMax[spyarmor, doorfourbyeightForceFieldPack] = 0;
$ItemMax[spyfemale, doorfourbyeightForceFieldPack] = 0;
$ItemMax[adarmor, doorfourbyeightForceFieldPack] = 0;
$ItemMax[sadarmor, doorfourbyeightForceFieldPack] = 0;
$ItemMax[parmor, doorfourbyeightForceFieldPack] = 0;