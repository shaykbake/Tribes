///-----------------------------------------------
/// description = "4x17 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, fourbyseventeenForceFieldPack] = 1;
$ItemMax[sarmor, fourbyseventeenForceFieldPack] = 1;
$ItemMax[barmor, fourbyseventeenForceFieldPack] = 0;
$ItemMax[harmor, fourbyseventeenForceFieldPack] = 0;
$ItemMax[darmor, fourbyseventeenForceFieldPack] = 0;
$ItemMax[marmor, fourbyseventeenForceFieldPack] = 1;
$ItemMax[mfemale, fourbyseventeenForceFieldPack] = 1;
$ItemMax[earmor, fourbyseventeenForceFieldPack] = 1;
$ItemMax[efemale, fourbyseventeenForceFieldPack] = 1;
$ItemMax[lfemale, fourbyseventeenForceFieldPack] = 1;
$ItemMax[sfemale, fourbyseventeenForceFieldPack] = 1;
$ItemMax[bfemale, fourbyseventeenForceFieldPack] = 0;
$ItemMax[spyarmor, fourbyseventeenForceFieldPack] = 0;
$ItemMax[spyfemale, fourbyseventeenForceFieldPack] = 0;
$ItemMax[adarmor, fourbyseventeenForceFieldPack] = 0;
$ItemMax[sadarmor, fourbyseventeenForceFieldPack] = 0;
$ItemMax[parmor, fourbyseventeenForceFieldPack] = 0;