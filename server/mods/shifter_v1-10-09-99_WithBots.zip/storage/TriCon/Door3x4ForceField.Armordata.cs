///-----------------------------------------------
/// description = "Door 3x4 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[sarmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[barmor, doorthreebyfourForceFieldPack] = 0;
$ItemMax[harmor, doorthreebyfourForceFieldPack] = 0;
$ItemMax[darmor, doorthreebyfourForceFieldPack] = 0;
$ItemMax[marmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[mfemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[earmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[efemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[lfemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[sfemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[bfemale, doorthreebyfourForceFieldPack] = 0;
$ItemMax[spyarmor, doorthreebyfourForceFieldPack] = 0;
$ItemMax[spyfemale, doorthreebyfourForceFieldPack] = 0;
$ItemMax[adarmor, doorthreebyfourForceFieldPack] = 0;
$ItemMax[sadarmor, doorthreebyfourForceFieldPack] = 0;
$ItemMax[parmor, doorthreebyfourForceFieldPack] = 0;