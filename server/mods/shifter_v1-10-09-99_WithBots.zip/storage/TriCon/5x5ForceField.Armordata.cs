///-----------------------------------------------
/// description = "5x5 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, fivebyfiveForceFieldPack] = 1;
$ItemMax[sarmor, fivebyfiveForceFieldPack] = 1;
$ItemMax[barmor, fivebyfiveForceFieldPack] = 0;
$ItemMax[harmor, fivebyfiveForceFieldPack] = 0;
$ItemMax[darmor, fivebyfiveForceFieldPack] = 0;
$ItemMax[marmor, fivebyfiveForceFieldPack] = 1;
$ItemMax[mfemale, fivebyfiveForceFieldPack] = 1;
$ItemMax[earmor, fivebyfiveForceFieldPack] = 1;
$ItemMax[efemale, fivebyfiveForceFieldPack] = 1;
$ItemMax[lfemale, fivebyfiveForceFieldPack] = 1;
$ItemMax[sfemale, fivebyfiveForceFieldPack] = 1;
$ItemMax[bfemale, fivebyfiveForceFieldPack] = 0;
$ItemMax[spyarmor, fivebyfiveForceFieldPack] = 0;
$ItemMax[spyfemale, fivebyfiveForceFieldPack] = 0;
$ItemMax[adarmor, fivebyfiveForceFieldPack] = 0;
$ItemMax[sadarmor, fivebyfiveForceFieldPack] = 0;
$ItemMax[parmor, fivebyfiveForceFieldPack] = 0;