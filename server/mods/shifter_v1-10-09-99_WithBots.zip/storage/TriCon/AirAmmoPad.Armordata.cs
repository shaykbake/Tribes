///-----------------------------------------------
/// description = "Air Ammo Pad";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, AirAmmoPad] = 1;
$ItemMax[sarmor, AirAmmoPad] = 1;
$ItemMax[barmor, AirAmmoPad] = 0;
$ItemMax[harmor, AirAmmoPad] = 0;
$ItemMax[darmor, AirAmmoPad] = 0;
$ItemMax[marmor, AirAmmoPad] = 1;
$ItemMax[mfemale, AirAmmoPad] = 1;
$ItemMax[earmor, AirAmmoPad] = 1;
$ItemMax[efemale, AirAmmoPad] = 1;
$ItemMax[lfemale, AirAmmoPad] = 1;
$ItemMax[sfemale, AirAmmoPad] = 1;
$ItemMax[bfemale, AirAmmoPad] = 0;
$ItemMax[spyarmor, AirAmmoPad] = 0;
$ItemMax[spyfemale, AirAmmoPad] = 0;
$ItemMax[adarmor, AirAmmoPad] = 0;
$ItemMax[sadarmor, AirAmmoPad] = 0;
$ItemMax[parmor, AirAmmoPad] = 0;