///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[newdoorfour] = 1;
$RemoteInvList[newdoorfour] = 1;