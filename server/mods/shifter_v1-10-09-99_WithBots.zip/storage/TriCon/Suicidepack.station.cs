///-----------------------------------------------
/// description = "Suicide DetPack";
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[SuicidePack] = 1;
$RemoteInvList[SuicidePack] = 1;