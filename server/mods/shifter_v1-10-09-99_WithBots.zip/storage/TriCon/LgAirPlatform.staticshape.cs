///-----------------------------------------------
/// description = "Air Large Platform";
/// MiniMod Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------
StaticShapeData LargeAirPlatform
{
        shapeFile = "elevator16x16_octo"; //elevator16x16_octo elevator_9x9
        debrisId = defaultDebrisLarge;
        maxDamage = 15.0;
        damageSkinData = "objectDamageSkins";
        shadowDetailMask = 16;
        explosionId = debrisExpLarge;
        visibleToSensor = true;
        mapFilter = 4;
      description = "Large Air Platform";
};