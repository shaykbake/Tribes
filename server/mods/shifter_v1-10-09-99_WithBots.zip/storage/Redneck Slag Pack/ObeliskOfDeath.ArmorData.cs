// This is a MiniMod Plugin.
// This plugin is the "Obelisk Of Death" (Anti-matter Turret) from
// the Redneck Slag Pack mod. Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    ObeliskOfDeath.ArmorData.cs
//    ObeliskOfDeath.baseProjData.cs
//    ObeliskOfDeath.item.cs
//    ObeliskOfDeath.reinitData.cs
//    Obelisk Of Light.staticshape.cs
//    ObeliskOfDeath.station.cs
//    ObeliskOfDeath.turret.cs
//
// to your MiniMod/plugins directory.

$DamageScale[larmor, $AntiMatterDamageType] = 1.0;
$DamageScale[lfemale, $AntiMatterDamageType] = 1.0;
$DamageScale[marmor, $AntiMatterDamageType] = 1.0;
$DamageScale[mfemale, $AntiMatterDamageType] = 1.0;
$DamageScale[harmor, $AntiMatterDamageType] = 1.0;
$DamageScale[sarmor, $AntiMatterDamageType] = 1.0;
$DamageScale[sfemale, $AntiMatterDamageType] = 1.0;
$DamageScale[spyarmor, $AntiMatterDamageType] = 1.0;
$DamageScale[spyfemale, $AntiMatterDamageType] = 1.0;
$DamageScale[barmor, $AntiMatterDamageType] = 1.0;
$DamageScale[bfemale, $AntiMatterDamageType] = 1.0;
$DamageScale[earmor, $AntiMatterDamageType] = 1.0;
$DamageScale[efemale, $AntiMatterDamageType] = 1.0;
$DamageScale[aarmor, $AntiMatterDamageType] = 1.0;
$DamageScale[afemale, $AntiMatterDamageType] = 1.0;
$DamageScale[barmor, $AntiMatterDamageType] = 1.0;
$DamageScale[bfemale, $AntiMatterDamageType] = 1.0;
$DamageScale[darmor, $AntiMatterDamageType] = 1.0;
$DamageScale[tarmor, $AntiMatterDamageType] = 1.0;
$DamageScale[scvarmor, $AntiMatterDamageType] = 1.0;

$ItemMax[larmor, AntiMatterTurretPack] = 0;
$ItemMax[lfemale, AntiMatterTurretPack] = 0;
$ItemMax[marmor, AntiMatterTurretPack] = 0;
$ItemMax[mfemale, AntiMatterTurretPack] = 0;
$ItemMax[harmor, AntiMatterTurretPack] = 1;
$ItemMax[sarmor, AntiMatterTurretPack] = 0;
$ItemMax[sfemale, AntiMatterTurretPack] = 0;
$ItemMax[spyfemale, AntiMatterTurretPack] = 0;
$ItemMax[spyarmor, AntiMatterTurretPack] = 0;
$ItemMax[barmor, AntiMatterTurretPack] = 0;
$ItemMax[bfemale, AntiMatterTurretPack] = 0;
$ItemMax[earmor, AntiMatterTurretPack] = 1;
$ItemMax[efemale, AntiMatterTurretPack] = 1;
$ItemMax[darmor, AntiMatterTurretPack] = 0;
$ItemMax[tarmor, AntiMatterTurretPack] = 0;
$ItemMax[scvarmor, AntiMatterTurretPack] = 0;

