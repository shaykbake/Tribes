// MiniMod plugin
// Fusion Blaster created/ported By, Dewy.

$InvList[FusionGun] = 1;
$RemoteInvList[FusionGun] = 1;
