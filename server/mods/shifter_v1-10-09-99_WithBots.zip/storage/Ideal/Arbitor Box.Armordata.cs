// This is a MiniMod Plugin.
// This is the Arbitor Box from the Ideal mod. Ported by Dewy.
//
// To install this plugin just...
// Add:
//
//    Arbitor Box.ArmorData.cs
//    Arbitor Box.item.cs
//    Arbitor Box.reinitData.cs
//    Arbitor Box.station.cs
//    Arbitor Box.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, ArbitorBoxPack] = 0;
$ItemMax[lfemale, ArbitorBoxPack] = 0;
$ItemMax[marmor, ArbitorBoxPack] = 0;
$ItemMax[mfemale, ArbitorBoxPack] = 0;
$ItemMax[harmor, ArbitorBoxPack] = 1;
$ItemMax[sarmor, ArbitorBoxPack] = 0;
$ItemMax[sfemale, ArbitorBoxPack] = 0;
$ItemMax[spyarmor, ArbitorBoxPack] = 0;
$ItemMax[spyfemale, ArbitorBoxPack] = 0;
$ItemMax[barmor, ArbitorBoxPack] = 0;
$ItemMax[bfemale, ArbitorBoxPack] = 0;
$ItemMax[earmor, ArbitorBoxPack] = 1;
$ItemMax[efemale, ArbitorBoxPack] = 1;
$ItemMax[aarmor, ArbitorBoxPack] = 1;
$ItemMax[afemale, ArbitorBoxPack] = 1;
$ItemMax[darmor, ArbitorBoxPack] = 0;
$ItemMax[tarmor, ArbitorBoxPack] = 0;
$ItemMax[scvarmor, ArbitorBoxPack] = 0;
