// This is a MiniMod Plugin.
// This plugin is the Particle Accelerator from the hvTactical mod.
// Ported by PeterT.

$Item = ClusterBomb;
$ItemClass = 7;
$qty = 1;

MiniMod::Get::ArmorClasses($ItemClass, $Item, $qty);
