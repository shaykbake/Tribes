// This is a MiniMod plugin
// This is the Shotgun From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.


$DamageScale[Scout, $ShotgunDamageType] = 1.0; 
$DamageScale[LAPC, $ShotgunDamageType] = 1.0; 
$DamageScale[HAPC, $ShotgunDamageType] = 1.0; 
