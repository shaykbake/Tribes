// This is a MiniMod plugin
// This is the Rail Turret From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

$InvList[RailTurret] = 1; 
$RemoteInvList[RailTurret] = 1;
