// This is a MiniMod plugin
// This is the Rail Turret From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

LaserData railLaser
{
laserBitmapName = "paintPulse.bmp";
hitName = "laserhit.dts";
damageConversion = 0.008;
baseDamageType = $SniperDamageType;
beamTime = 1.5;
lightRange = 5.0;
lightColor = { 0.25, 1.0, 0.25 };
detachFromShooter = true;
hitSoundId = SoundLaserHit;
};
