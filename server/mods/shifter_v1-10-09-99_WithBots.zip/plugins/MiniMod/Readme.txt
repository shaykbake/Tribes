Install:
Just unzip to your MiniMod\plugins directory, that's it.
