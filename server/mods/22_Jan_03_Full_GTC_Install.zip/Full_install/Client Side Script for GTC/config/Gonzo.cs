function remoteGTCHTML(%server, %address)
{
	if(%server == 2048)
	{
		$Urlmessage = "<jc>Your browser is now open to selected Webpage\n\n" @ %address @ "\n\n<jc>Press ESC to exit this message";

		GuiPushDialog(MainWindow, "gui\\MessageDialog.gui");
		schedule("Control::setValue(MessageDialogTextFormat, $Urlmessage);", 0);
		schedule("Client::ExitLobbyMode();", 5);
		HTMLopen(%address);
	}
}


function remoteGTCchat(%server)
{
	if(%server == 2048)
	{
		if(isobject("playgui/ChatInputGTC") == true)
		{
		}
		else
		{
			renameobject(nametoid("playgui/chatDisplayHud")+1, "ChatInputGTC");
		}
		schedule("control::setVisible(\"ChatInputGTC\", true);", 0.5);
		return;
	}
}


function remoteGTCchat(%server)
{
	if(%server == 2048)
	{
		if(isobject("playgui/ChatInputGTC") == true)
		{
		}
		else
		{
			renameobject(nametoid("playgui/chatDisplayHud")+1, "ChatInputGTC");
		}
		schedule("control::setVisible(\"ChatInputGTC\", true);", 0.5);
		return;
	}
}


function remoteSetInfoLine(%mgr, %lineNum, %text, %active)
{
	if(%mgr != 2048)
		return;

	if (%lineNum == 1)
	{
		if (%text == "") Control::setVisible(InfoCtrlBox, FALSE);
		else Control::setVisible(InfoCtrlBox, TRUE);
	}

	Control::setText("InfoCtrlLine" @ %lineNum, %text);

	if(%active)
		Control::setActive("InfoCtrlLine" @ %lineNum, true);
	else
		Control::setActive("InfoCtrlLine" @ %lineNum, false);
}