Include this line in your autoexec.cs file. 
It should look like this at the top with the new Gonzo.cs added... 
Extract the zip file to your....

Dynamix/Tribes/Config/ 

Code:

exec("presto\\Install.cs"); 
Include("Autoload.cs"); 
exec("Gonzo.cs"); 
