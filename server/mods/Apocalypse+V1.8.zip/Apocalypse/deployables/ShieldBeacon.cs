//--------------------------------------

addToInv(ShieldBeaconPack,1,1);

setArmorItemMax(ShieldBeaconPack,0,0,0,1,1,1,1, 0);

$TeamItemMax[ShieldBeaconPack] = 6;

dataReinit(ShieldBeaconPack);
$TCK[DeployableShieldBeacon] = true;
$PlayCtrl[DeployableShieldBeacon] = false;
//--------------------------------------

ItemImageData ShieldBeaconPackImage
{
        shapeFile = "force";
        mountPoint = 2;
   mountOffset = { 0, -0.03, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData ShieldBeaconPack
{
        description = "Shield Beacon";
        shapeFile = "force";
        className = "Backpack";
   heading = $InvCatDeployables;
        imageType = ShieldBeaconPackImage;
        shadowDetailMask = 4;
        mass = 2.0;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function ShieldBeaconPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else {
                Player::deployItem(%player,%item);
        }
}

function ShieldBeaconPack::onDeploy(%player,%item,%pos)
{
        %client = Player::getClient(%player);
        if(GameBase::getLOSInfo(%player,3)) {
                %obj = $los::object;
                %type = getObjectType(%obj);
                if(terrainCheck(%type,"OBJECTS")){
                        %objitem = GameBase::getDataName(%obj);
                        if($Shield[%objitem]) {
                                if(!%obj.boosted) {
                                        %deployed = Item::universalDeploy(%player,%item,3,"OBJECTS",0,0,0,0,0,0,1,false,ShieldBeacon,"StaticShape",true);
                                        if(%deployed) {
                                                $ShieldBeacon[%obj] = %deployed;
                                                $ShieldItem[%deployed] = %obj;
                                                $ShieldItem[%deployed].shieldStrength = $ShieldItem[%deployed].shieldStrength + 0.015;
                                                if(GameBase::getRechargeRate($ShieldItem[%deployed]) == 0) {
                                                        $ShieldItem[%deployed].oldRate = 0;
                                                        GameBase::setRechargeRate($ShieldItem[%deployed],5);
                                                }
                                                else if(GameBase::getRechargeRate($ShieldItem[%deployed]) == "") {
                                                        $ShieldItem[%deployed].oldRate = "";
                                                        GameBase::setRechargeRate($ShieldItem[%deployed],5);
                                                }
                                                else {
                                                        $ShieldItem[%deployed].oldRate = GameBase::getRechargeRate($ShieldItem[%deployed]);
                                                }
                                                $ShieldItem[%deployed].boosted = true;
                                                %deployed.shieldStrength = 0.015;
                                                GameBase::setRechargeRate(%deployed,5);
                                                Client::sendMessage(%client,0,%objitem.description @ "'s shield has been boosted.");
                                                Player::decItemCount(%player,%item);
                                        }
                                }
                                else
                                        Client::sendMessage(%client,0,%objitem.description @ " already has a shield beacon.~waccess_denied.wav");
                        }
                        else
                                Client::sendMessage(%client,0,%objitem.description @ " cannot be shielded.~waccess_denied.wav");
                }
                else
                        Client::sendMessage(%client,0,"Can only deploy on objects~waccess_denied.wav");
        }
}

$MountMSG[ShieldBeaconPack] = "<JC><F2>Shield Beacon Pack <F0>- <F1>Deploys a beacon that will boost an items shielding.";
//--------------------------------------
$Shield[ShieldBeacon] = false;
StaticShapeData ShieldBeacon
{
        shapeFile = "force";
        maxDamage = 0.5;
        maxEnergy = 50;
        shieldShapeName = "shield";
        debrisId = defaultDebrisSmall;
        explosionId = debrisExpSmall;
        visibleToSensor = true;
        damageSkinData = "objectDamageSkins";
        description = "Shield Beacon";
};

function ShieldBeacon::onDestroyed(%this)
{
        StaticShape::onDestroyed(%this);
        if($ShieldItem[%this].shieldStrength > 0.015) {
                $ShieldItem[%this].shieldStrength = $ShieldItem[%this].shieldStrength - 0.015;
        }
        else {
                $ShieldItem[%this].shieldStrength = 0;
        }
        GameBase::setRechargeRate($ShieldItem[%this],$ShieldItem[%this].oldRate);
        GameBase::setRechargeRate(%this,"");
        $ShieldItem[%this].boosted = false;
        $TeamItemCount[GameBase::getTeam(%this) @ "ShieldBeaconPack"]--;
}

