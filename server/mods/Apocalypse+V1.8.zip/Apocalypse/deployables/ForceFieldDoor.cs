$FireModes[FFDoorPack] = 6;
//--------------------------------------

addToInv(FFDoorPack,1,1);

setArmorItemMax(FFDoorPack,0,0,0,1,1,1,1, 0);

$TeamItemMax[FFDoorPack] = 8;

dataReinit(FFDoorPack);
$TCK[ForceFieldDoor] = true;
$PlayCtrl[ForceFieldDoor] = false;
//--------------------------------------

ItemImageData FFDoorPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
   mountOffset = { 0, -0.03, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData FFDoorPack
{
        description = "Force Field Door";
        shapeFile = "AmmoPack";
        className = "Backpack";
   heading = $InvCatDeployables;
        imageType = FFDoorPackImage;
        shadowDetailMask = 4;
        mass = 2.0;
        elasticity = 0.2;
        price = 400;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function FFDoorPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else {
                Player::deployItem(%player,%item);
        }
}

function FFDoorPack::onDeploy(%player,%item,%pos)
{
        %client = Player::getClient(%player);
        if($WeapMode[%client,FFDoorPack] == "" || $WeapMode[%client,FFDoorPack] == 0)
                $WeapMode[%client,FFDoorPack] = 1;
        else if($WeapMode[%client,FFDoorPack] > $FireModes[FFDoorPack])
                $WeapMode[%client,FFDoorPack] = $FireModes[FFDoorPack];
        if (Item::universalDeploy(%player,%item,3,"LAND",1,1,1,1,1,1,1,true,$ForceFieldDoor[$WeapMode[%client,FFDoorPack]],"StaticShape",true))
                Player::decItemCount(%player,%item);
}

$MountMSG[FFDoorPack,1] = "<JC><F2>Force Field Door Pack <F0>- <F1>Deploys a 3x4 Force Field Door.";
$MountMSG[FFDoorPack,2] = "<JC><F2>Force Field Door Pack <F0>- <F1>Deploys a 5x5 Force Field Door.";
$MountMSG[FFDoorPack,3] = "<JC><F2>Force Field Door Pack <F0>- <F1>Deploys a 4x8 Force Field Door.";
$MountMSG[FFDoorPack,4] = "<JC><F2>Force Field Door Pack <F0>- <F1>Deploys a 4x14 Force Field Door.";
$MountMSG[FFDoorPack,5] = "<JC><F2>Force Field Door Pack <F0>- <F1>Deploys a 4x17 Force Field Door.";
$MountMSG[FFDoorPack,6] = "<JC><F2>Force Field Door Pack <F0>- <F1>Deploys a 6x14 Force Field Door.";
//--------------------------------------
$ForceFieldDoor[1] = ForceFieldDoor3x4;
$ForceFieldDoor[2] = ForceFieldDoor5x5;
$ForceFieldDoor[3] = ForceFieldDoor4x8;
$ForceFieldDoor[4] = ForceFieldDoor4x14;
$ForceFieldDoor[5] = ForceFieldDoor4x17;
$ForceFieldDoor[6] = ForceFieldDoor6x14;
//3 by 4 Force Field Door---------------
$Shield[ForceFieldDoor3x4] = false;
StaticShapeData ForceFieldDoor3x4
{
        className = "ForceField";
        damageSkinData = "objectDamageSkins";
        shapeFile = "forcefield_3x4";
        maxDamage = 4.5;
        maxEnergy = 200;
        mapFilter = 2;
        visibleToSensor = true;
        explosionId = mortarExp;
        debrisId = flashDebrisLarge;
        lightRadius = 12.0;
        lightType=2;
        lightColor = {1.0,0.2,0.2};
        side = "single";
        isTranslucent = true;
        description = "Force Field Door";
};

function ForceFieldDoor3x4::onDestroyed(%this)
{
        ffDestroyed(%this);
}

function ForceFieldDoor3x4::onCollision(%this,%obj)
{
        ffCollision(%this,%obj);
}

//5 by 5 Force Field Door---------------
$Shield[ForceFieldDoor5x5] = false;
StaticShapeData ForceFieldDoor5x5
{
        className = "ForceField";
        damageSkinData = "objectDamageSkins";
        shapeFile = "forcefield_5x5";
        maxDamage = 4.5;
        maxEnergy = 200;
        mapFilter = 2;
        visibleToSensor = true;
        explosionId = mortarExp;
        debrisId = flashDebrisLarge;
        lightRadius = 12.0;
        lightType=2;
        lightColor = {1.0,0.2,0.2};
        side = "single";
        isTranslucent = true;
        description = "Force Field Door";
};

function ForceFieldDoor5x5::onDestroyed(%this)
{
        ffDestroyed(%this);
}

function ForceFieldDoor5x5::onCollision(%this,%obj)
{
        ffCollision(%this,%obj);
}

//4 by 8 Force Field Door---------------
$Shield[ForceFieldDoor4x8] = false;
StaticShapeData ForceFieldDoor4x8
{
        className = "ForceField";
        damageSkinData = "objectDamageSkins";
        shapeFile = "forcefield_4x8";
        maxDamage = 4.5;
        maxEnergy = 200;
        mapFilter = 2;
        visibleToSensor = true;
        explosionId = mortarExp;
        debrisId = flashDebrisLarge;
        lightRadius = 12.0;
        lightType=2;
        lightColor = {1.0,0.2,0.2};
        side = "single";
        isTranslucent = true;
        description = "Force Field Door";
};

function ForceFieldDoor4x8::onDestroyed(%this)
{
        ffDestroyed(%this);
}

function ForceFieldDoor4x8::onCollision(%this,%obj)
{
        ffCollision(%this,%obj);
}

//4 by 14 Force Field Door---------------
$Shield[ForceFieldDoor4x14] = false;
StaticShapeData ForceFieldDoor4x14
{
        className = "ForceField";
        damageSkinData = "objectDamageSkins";
        shapeFile = "forcefield_4x14";
        maxDamage = 4.5;
        maxEnergy = 200;
        mapFilter = 2;
        visibleToSensor = true;
        explosionId = mortarExp;
        debrisId = flashDebrisLarge;
        lightRadius = 12.0;
        lightType=2;
        lightColor = {1.0,0.2,0.2};
        side = "single";
        isTranslucent = true;
        description = "Force Field Door";
};

function ForceFieldDoor4x14::onDestroyed(%this)
{
        ffDestroyed(%this);
}

function ForceFieldDoor4x14::onCollision(%this,%obj)
{
        ffCollision(%this,%obj);
}

//4 by 17 Force Field Door---------------
$Shield[ForceFieldDoor4x17] = false;
StaticShapeData ForceFieldDoor4x17
{
        className = "ForceField";
        damageSkinData = "objectDamageSkins";
        shapeFile = "forcefield_4x17";
        maxDamage = 4.5;
        maxEnergy = 200;
        mapFilter = 2;
        visibleToSensor = true;
        explosionId = mortarExp;
        debrisId = flashDebrisLarge;
        lightRadius = 12.0;
        lightType=2;
        lightColor = {1.0,0.2,0.2};
        side = "single";
        isTranslucent = true;
        description = "Force Field Door";
};

function ForceFieldDoor4x17::onDestroyed(%this)
{
        ffDestroyed(%this);
}

function ForceFieldDoor4x17::onCollision(%this,%obj)
{
        ffCollision(%this,%obj);
}

//6 by 14 Force Field Door---------------
//I am quessing the size by comparing it with the others
$Shield[ForceFieldDoor6x14] = false;
StaticShapeData ForceFieldDoor6x14
{
        className = "ForceField";
        damageSkinData = "objectDamageSkins";
        shapeFile = "forcefield";
        maxDamage = 4.5;
        maxEnergy = 200;
        mapFilter = 2;
        visibleToSensor = true;
        explosionId = mortarExp;
        debrisId = flashDebrisLarge;
        lightRadius = 12.0;
        lightType=2;
        lightColor = {1.0,0.2,0.2};
        side = "single";
        isTranslucent = true;
        description = "Force Field Door";
};

function ForceFieldDoor6x14::onDestroyed(%this)
{
        ffDestroyed(%this);
}

function ForceFieldDoor6x14::onCollision(%this,%obj)
{
        ffCollision(%this,%obj);
}

//Generic Code for all Force Field Doors
function ffDestroyed(%this)
{
        StaticShape::onDestroyed(%this);
        $TeamItemCount[GameBase::getTeam(%this) @ "FFDoorPack"]--;
}

function ffCollision(%this,%obj)
{
        if(getObjectType(%obj)!= "Player" || Player::isDead(%obj))
                return;
        if(TeamCompare(%this,%obj) == Diff)
                return;
        ffopenDoor(%this);
        return;
}

function ffopenDoor(%this)
{
        GameBase::startfadeout(%this);
        %pos=GameBase::getPosition(%this);
        %pos=Vector::add(%pos,"0 0 1000");
        GameBase::setPosition(%this,%pos);
        schedule("GameBase::playSound("@%this@",ForceFieldOpen,0);",0.15);
        schedule("ffcloseDoor("@%this@");",2);
}

function ffcloseDoor(%this)
{
        %pos=GameBase::getPosition(%this);
        %pos=Vector::add(%pos,"0 0 -1000");
        GameBase::setPosition(%this,%pos);
        GameBase::startfadein(%this);
        schedule("GameBase::playSound("@%this@",ForceFieldClose,0);",0.15);
}

