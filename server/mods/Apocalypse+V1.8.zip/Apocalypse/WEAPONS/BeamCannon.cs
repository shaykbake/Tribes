//--------------------------------------

$AutoUse[BeamCannon] = True;
$WeaponAmmo[BeamCannon] = "";

addToInv(BeamCannon,1,1);

setArmorItemMax(BeamCannon,0,0,0,0,0,1,1, 1);

//--------------------------------------

LaserData beamLaser
{
   laserBitmapName   = "warp.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 1.0;
   baseDamageType    = $BeamDamageType;

   beamTime          = 2.0;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 1.0 };

   detachFromShooter = true;
   hitSoundId        = shockExplosion;
};

//----------------------------------------------------------------------------

ItemImageData BeamCannon3Image
{
        shapeFile = "grenadeL";
        mountPoint = 0;
        mountRotation = { 0,3.14, 0 };

        weaponType = 0; // Single Shot
        projectileType = beamLaser;
        accuFire = true;
        reloadTime = 0;
        fireTime = 0.0;
        minEnergy = 1;
        maxEnergy = 20;

        lightType   = 3;  // Weapon Fire
        lightRadius = 1;
        lightTime   = 1;
        lightColor  = { 0.25, 1, 0.25 };

        sfxFire = SoundFirePlasma;
        sfxActivate = SoundPickUpWeapon;
        sfxReload = SoundDiscSpin;
        sfxReady = SoundMortarIdle;
};

ItemData BeamCannon3
{
   heading = $InvCatWeapons[All];
        description = "Beam Cannon";
        className = "Weapon";
   shapeFile  = "grenadeL";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = BeamCannon3Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData BeamCannon2Image
{
   shapeFile  = "paintgun";
        mountPoint = 0;
        mountRotation = { 0, 1.57, 0 };
        mountOffset = { 0.0, 0.0, -0.04 };

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;
        minEnergy = 0;
        maxEnergy = 0;

        accuFire = true;
};

ItemData BeamCannon2
{
   heading = $InvCatWeapons[All];
        description = "Beam Cannon";
        className = "Weapon";
   shapeFile  = "paintgun";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = BeamCannon2Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData BeamCannonImage
{
   shapeFile  = "paintgun";
        mountPoint = 0;
        mountRotation = { 0, -1.57, 0 };
        mountOffset = { 0.0, 0.0, -0.04 };

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;
        minEnergy = 1;
        maxEnergy = 2;

        accuFire = true;
};

ItemData BeamCannon
{
        description = "Beam Cannon";
        className = "Weapon";
        shapeFile = "grenadeL";
        hudIcon = "blaster";
   heading = $InvCatWeapons[All];
        shadowDetailMask = 4;
        imageType = BeamCannonImage;
        price = 275;
        showWeaponBar = true;
};

//Charge Up code for Beam Cannon
$ChargeRate[EnergyPack] = 3;  //with energy pack it will charge up by 3 each cycle
$ChargeRate[PerGenPack] = 15; //with personal genertator it will charge up by 15 each cycle
$ChargeRate[UltimaPack] = 9;  //with ultima pack it will charge up by 9 each cycle

function BeamCannonImage::onFire(%player, %slot)
{
        Player::trigger(%player,$ExtraSlotA,true);
        %client = Player::getClient(%player);
        if(!%player.ChrgOn) {
                %client.BeamChrg = 0;
                %energy = GameBase::getEnergy(%player);
                BeamCannon::Charge(%player,%energy);
        }
        Player::trigger(%player,$ExtraSlotA,false);
}

//charge coded by ProtoManX
function BeamCannon::Charge(%player,%energy)
{
        %client = Player::getClient(%player);
        %armor = Player::getArmor(%player);
        %pack = Player::getMountedItem(%player,$BackpackSlot);
        %state = Player::getItemState(%player,$WeaponSlot);
        if(%state == "Fire") {
                %player.ChrgOn = true;
                if(%energy >= $ChargeRate[%pack] && %client.BeamChrg < %armor.maxEnergy) {
                        %energy -= $ChargeRate[%pack];
                        if(%energy < 0)
                                %energy = 0;
                        GameBase::setEnergy(%player,%energy);
                        %client.BeamChrg += $ChargeRate[%pack];
                }
                if(%client.BeamChrg > %armor.maxEnergy)
                        %client.BeamChrg = %armor.maxEnergy;
                %energy = GameBase::getEnergy(%player);
                Bottomprint(%client, "<JC><F1>Energy Level: <F2>" @ %client.BeamChrg,1);
                schedule("BeamCannon::Charge(" @ %player @ "," @ %energy @ ");",0.1);
        }
        else {
                %player.ChrgOn = false;
                Player::trigger(%player,$ExtraSlotB,true);
                Player::trigger(%player,$ExtraSlotB,false);
        }
}

function BeamCannon::onUse(%player,%item)
{
        %pack = Player::getMountedItem(%player,$BackpackSlot);
        if(%pack == EnergyPack || %pack == PerGenPack || %pack == UltimaPack)
                Weapon::onUse(%player,%item);
        else
                Client::sendMessage(Player::getClient(%player),0,"Must have an Energy Pack or Personal Generator to use Beam Cannon.");
}

function BeamCannon::onMount(%player,%item)
{
        Player::mountItem(%player,BeamCannon2,$ExtraSlotA);
        Player::mountItem(%player,BeamCannon3,$ExtraSlotB);
}

function BeamCannon::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
        Player::unmountItem(%player,$ExtraSlotB);
}

$MountMSG[BeamCannon] = "<JC><F2>Beam Cannon <F0>- <F1>Fires a high powered laser that drains large amounts energy.";

AddWeapon(BeamCannon);
