//--------------------------------------
addAmmo(TrapLauncher,TrapMineAmmo,1,0);

addToInv(PrisonPack,1,1);
addToInv(TrapMineAmmo,1,1);

setArmorItemMax(PrisonPack,0,0,0,1,1,1,1, 0);
setArmorItemMax(TrapMineAmmo,0,0,0,5,5,5,5, 99);

//--------------------------------------

ItemData TrapMineAmmo
{
	description = "Prison Traps";
   heading = $InvCatAmmo;
	className = "Ammo";
	shapeFile = "discammo";
	shadowDetailMask = 4;
	price = 50;
};

ItemImageData TrapLauncher2Image
{
	shapeFile = "discb";
	mountPoint = 0;
	mountOffset = { 0.0, 0.05, 0.0 };

	weaponType = 3;
	minEnergy = 1;
	maxEnergy = 2;

       lightType = 3;  // Weapon Fire
       lightRadius = 2;
       lightTime = 1;
       lightColor = { 0.25, 0.05, 0.85 };

	sfxActivate = SoundPickUpWeapon;
	sfxFire = SoundRepairItem;
};

ItemData TrapLauncher2
{
	description = "Trap Luancher";
	shapeFile = "discb";
	className = "Weapon";
	shadowDetailMask = 4;
	imageType = TrapLauncher2Image;
	showWeaponBar = false;
	hiliteOnActive = false;
	showInventory = false;
	price = 125;
};

ItemImageData TrapLauncherImage
{
	shapeFile = "shieldPack";
	mountPoint = 0;
	mountRotation = { 1.57, 3.14, 0 };
	mountOffset = { 0.0, -0.05, 0.0 };

	weaponType = 3;
//	  projectileType = Null;
	ammoType = TrapMineAmmo;
	reloadTime = 1.0;
	fireTime = 2.0;

       lightType = 3;  // Weapon Fire
       lightRadius = 2;
       lightTime = 1;
       lightColor = { 0.25, 0.25, 0.85 };

	sfxActivate = SoundPickUpWeapon;
	sfxFire = SoundRepairItem;
};

ItemData TrapLauncher
{
	description = "Trap Luancher";
	shapeFile = "shieldPack";
	className = "Weapon";
	hudIcon = "disk";
	shadowDetailMask = 4;
	imageType = TrapLauncherImage;
	showWeaponBar = true;
	hiliteOnActive = true;
	showInventory = false;
	price = 125;
};

function TrapLauncher::onMount(%player,%imageSlot)
{
	Player::mountItem(%player,TrapLauncher2,$ExtraSlotA);
	Player::trigger(%player,$BackpackSlot,true);
}

function TrapLauncher::onUnmount(%player,%imageSlot)
{
	Player::unmountItem(%player,$ExtraSlotA);
	Player::trigger(%player,$BackpackSlot,false);
}

$LauncherPower = 2;
function TrapLauncherImage::onFire(%player, %slot)
{
	Player::decItemCount(%player,TrapMineAmmo,1);
	%obj = newObject("","Mine","TrapMine");
	addToSet("MissionCleanup", %obj);
	%client = Player::getClient(%player);
	GameBase::throw(%obj,%player,((15 * $LauncherPower) * %client.throwStrength),false);
	%player.throwTime = getSimTime() + 0.5;
	GameBase::setTeam(%obj,GameBase::getTeam(%client));
}
//--------------------------------------

ItemImageData PrisonPackImage2
{
	shapeFile = "discb";
	weaponType = 2;  // Sustained

	mountPoint = 2;
	mountOffset = { -0.05, 0.05, 0.0 };
	mountRotation = { 1.57, 0, 0 };

	firstPerson = false;
};

ItemData PrisonPack2
{
	description = "Trap Mine";
	shapeFile = "discb";
	className = "Backpack";
   heading = $InvCatPacks;
	shadowDetailMask = 4;
	imageType = PrisonPackImage2;
	price = 250;
	hudIcon = "energypack";
	showWeaponBar = false;
	hiliteOnActive = false;
	showInventory = false;
};

ItemImageData PrisonPackImage
{
	shapeFile = "shieldPack";
	mountPoint = 2;
	weaponType = 2;  // Sustained
   minEnergy = 0;
	maxEnergy = 0;	 // Energy used/sec for sustained weapons
	mountOffset = { 0, 0.05, 0.05 };
	mountRotation = { 0, 1.57, 0 };
	firstPerson = false;
};

ItemData PrisonPack
{
	description = "Prison Pack";
	shapeFile = "shieldPack";
	className = "Backpack";
   heading = $InvCatPacks;
	shadowDetailMask = 4;
	imageType = PrisonPackImage;
	price = 300;
	hudIcon = "disk";
	showWeaponBar = false;
	hiliteOnActive = false;
	showInventory = true;
};


function PrisonPack::onMount(%player,%item)
{
	Player::setItemCount(%player, TrapLauncher, 1);
	Player::mountItem(%player,PrisonPack2,$ExtraSlotC);
}

function PrisonPack::onUnmount(%player,%item)
{
	Player::setItemCount(%player, TrapLauncher, 0);
	Player::unMountItem(%player,$ExtraSlotC);
	if (Player::getMountedItem(%player,$WeaponSlot) == TrapLauncher) {
		Player::unmountItem(%player,$WeaponSlot);
	}
}

function PrisonPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::mountItem(%player,TrapLauncher,$WeaponSlot);
	}
}

function PrisonPack::onDrop(%player,%item)
{
	if($matchStarted) {
		%mounted = Player::getMountedItem(%player,$WeaponSlot);
		if (%mounted == TrapLauncher) {
			Player::unmountItem(%player,$WeaponSlot);
		}
		else {
			// Remount the existing weapon to make sure the TrapLauncher
			// is not on the delayed mount "stack".
			Player::mountItem(%player,%mounted,$WeaponSlot);
		}
		Item::onDrop(%player,%item);
	}
}

//--------------------------------------

$MountMSG[PrisonPack] = "<JC><F2>Prison Pack <F0>- <F1>Launch traps that will catch enemies in a prison for a short time.";

