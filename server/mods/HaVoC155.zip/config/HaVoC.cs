//Here is where you set up all the features in HaVoC.
//For instructions on what these things mean, refer
//to guide.txt that came with HaVoC or the site as 
//they both have in depth instructions on the 
//settings in this file:
//http://havoc.sirris.com

//Also take a look at the HvCUserList.cs file that came 
//with the HaVoC mod for setting up auto admins based 
//on IP.

$HaVoC::tkLimit = 2;
$HaVoC::tkClientLvl = "1";
$HaVoC::tkServerLvl = "1";
$HaVoC::tkMultiple = "3";

$HaVoC::BanKickTime = "400";

$HaVoC::Eye4anEye = TRUE;

$HaVoC::BaseKillWarning = 1;
$HaVoC::BaseKillLimit = 6;

$HaVoC::SADPassword[1] = "";
$HaVoC::SADPassword[2] = "";
$HaVoC::SADPassword[3] = "";
$HaVoC::SADPassword[4] = "";
$HaVoC::SADPassword[5] = "";

$HaVoC::MasterSADPassword[1] = "";
$HaVoC::MasterSADPassword[2] = "";
$HaVoC::MasterSADPassword[3] = "";
$HaVoC::MasterSADPassword[4] = "";
$HaVoC::MasterSADPassword[5] = "";

$HaVoC::PAPassword[1] = "";
$HaVoC::PAPassword[2] = "";
$HaVoC::PAPassword[3] = "";
$HaVoC::PAPassword[4] = "";
$HaVoC::PAPassword[5] = "";

$HaVoC::PASpecial[1] = TRUE;
$Special::PABan[1] = TRUE;
$Special::PATorture[1] = TRUE;
$Special::PAKick[1] = TRUE;
$Special::PATeamChange[1] = FALSE;
$Special::PAStartMatch[1] = FALSE;
$Special::PATimelimit[1] = FALSE;
$Special::PAMission[1] = FALSE;
$Special::PAServerOptions[1] = FALSE;
$Special::PAFairTeams[1] = FALSE;
$Special::PATeamDamage[1] = FALSE;
$Special::PATourneyMode[1] = FALSE;
$Special::PABalanceTeams[1] = FALSE;

$HaVoC::PASpecial[2] = TRUE;
$Special::PABan[2] = FALSE;
$Special::PATorture[2] = FALSE;
$Special::PAKick[2] = FALSE;
$Special::PATeamChange[2] = FALSE;
$Special::PAStartMatch[2] = FALSE;
$Special::PATimelimit[2] = FALSE;
$Special::PAMission[2] = TRUE;
$Special::PAServerOptions[2] = FALSE;
$Special::PAFairTeams[2] = FALSE;
$Special::PATeamDamage[2] = FALSE;
$Special::PATourneyMode[2] = FALSE;
$Special::PABalanceTeams[2] = TRUE;

$HaVoC::PABan = FALSE;
$HaVoC::PAKick = TRUE;
$HaVoC::PATeamChange = FALSE;
$HaVoC::PAStartMatch = FALSE;
$HaVoC::PATimelimit = TRUE;
$HaVoC::PAMission = TRUE;
$HaVoC::PAServerOptions = FALSE;
$HaVoC::PAFairTeams = TRUE;
$HaVoC::PATeamDamage = TRUE;
$HaVoC::PATourneyMode = FALSE;
$HaVoC::PABalanceTeams = TRUE;

$HaVoC::PVMission = TRUE;
$HaVoC::PVKick = TRUE;
$HaVoC::PVAdmin = FALSE;
$HaVoC::PVFairTeams = TRUE;
$HaVoC::PVTourneyMode = FALSE;
$HaVoC::PVStartMatch = FALSE;
$HaVoC::PVTeamDamage = TRUE;
$HaVoC::PVTime = 11;
$HaVoC::PVBalanceTeams = TRUE;

$HaVoC::Lightning = TRUE;
$HaVoC::LightningStrength = "zero";
$HaVoC::LightningFrequency = 400;
$HaVoC::LightningHandicap = 3;

$HaVoC::DMInventories = TRUE;
$HaVoC::DMSniperWeapons = TRUE;
$HaVoC::DMMines = TRUE;
$HaVoC::DMFullWeapons = TRUE;

$FlagHunter::Inventories = TRUE;
$FlagHunter::AltarCampingTimer = 13;
$FlagHunter::FlagFadeTime = 120;
$FlagHunter::CarryingNumber = 5;
$FlagHunter::YardSaleNumber = 10;
$FlagHunter::YardSaleTime = 30;
$FlagHunter::GreedAmount = 6;
$FlagHunter::HoardStartTime = 5;
$FlagHunter::HoardEndTime = 2;

$Rabbit::Inventories = TRUE;
$Rabbit::ScoreTimer = 5;
$Rabbit::FlagReturnTime = 8;

$Arena::GameTimeLimit = 240;
$Arena::NumberMatchLimit = 3;
$Arena::Scorelimit = 3;
$Arena::ReadyTime = TRUE;  
$Arena::AutoTeamJoin = TRUE;

$HaVoC::AutoAssignTribe = "[HvC]";
$HaVoC::AutoAssignLength = 5;

$HaVoC::KickMessage = "Go away!  You idiot!";

$HaVoC::StationTime = "40";

$HaVoC::PersonalSkin = TRUE;

$HaVoC::TurretPoints = TRUE;

$HaVoC::TurretKillMessages = TRUE;

$HaVoC::FlagReturnTime = "100";

$HaVoC::FairSpawn = "7";

$HaVoC::AutoRespawn = 20;

$HaVoC::FriendlyMines = TRUE;

$HaVoC::RandomMissions = TRUE;
$HaVoC::RandomMissionTypes["Capture the Flag"] = TRUE;
$HaVoC::RandomMissionTypes["Deathmatch"] = FALSE;
$HaVoC::RandomMissionTypes["Multiple Team"] = FALSE;
$HaVoC::RandomMissionTypes["Capture and Hold"] = FALSE;
$HaVoC::RandomMissionTypes["Find and Retrieve"] = FALSE;
$HaVoC::RandomMissionTypes["Defend and Destroy"] = FALSE;
$HaVoC::RandomMissionTypes["Kill the Rabbit"] = FALSE;
$HaVoC::RandomMissionTypes["Flag Hunter"] = FALSE;
$HaVoC::RandomMissionTypes["Team Deathmatch"] = FALSE;
$HaVoC::RandomMissionTypes["Balanced"] = FALSE;
$HaVoC::RandomMissionTypes["Open Call"] = FALSE; 
$HaVoC::RandomMissionTypes["Duel"] = FALSE; 
$HaVoC::RandomMissionTypes["DuelTournament"] = FALSE; 
$HaVoC::RandomMissionTypes["Tribes Racer"] = FALSE; 
$HaVoC::RandomMissionTypes["Tribes Arena"] = FALSE; 

$HaVoC::FairTeams = TRUE;

