June 13, 2000.

    ***** HaVoC version 1.5.5 FINAL *****

Thank you for downloading HaVoC 1.5.5.  This will be the
last major release of HaVo, until, possibly, Tribes 2.
This version is filled with great new stuff, Duel, grappling 
hooks, new teleporters, many new maps, and many other things.

This mod has been a project of mine for over 10 months and I 
feel like it is ready to get on every server out there.  I've 
worked hard on not only the mod but on quite a few maps for it.

For information on running a HaVoC 1.5.5 server refer to
the install.txt file that came with this mod.  For 
information on setting the various features of HaVoC, 
refer to the guide.txt file that came with this mod.
Be sure to read the racersetup.txt so you can see the
Racer skins correctly.

While the majority of HaVoC was written solely by myself, 
this mod does contain work from many authors.  No one
but myself ever worked on it, but I used some code from
other's mods.  Why reinvent the wheel?  Many thanks go
out to many people for thier permission to use thier 
code.  Please take a look at the credits.txt file that
came with the mod and acknowledge all the great people
that have contributed to HaVoC.

[HvC]NaTeDoGG
Nathan Sweet
http://havoc.sirris.com
natedone@hotmail.com