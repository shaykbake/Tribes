***********************
* GunStar version 0.5 *
***********************

Thanks for download the GunStar mod!  This is a server side mod
that is based on a very old game -- GunStar Heroes.

The basic premise is that you can carry 2 orbs.  The weapons the
orbs fire changes with the orbs you are holding.  There are 4 types 
of orbs.  You may press the grenade key to combine or uncombine the 
orbs you are carrying. This allows you to have up to 4 different 
weapons.

Unzip into your Tribes folder.  The scripts.vol file should be placed
in your Tribes\GunStar folder automatically.  Then run your server like 
this:

Tribes.exe -mod GunStar

For more help on running a server refer to my website:
http://havoc.sirris.com

Much thanks goes to [OO]Striker as this mod was his idea, I just brought 
it to life.  It is in no way done, some of the weapons are unbalanced.
But I have alot of other things I'm doing so I don't have much time to 
work on this.  Feel free to continue my efforts!

Nathan Sweet
aka [HvC]NaTeDoGG
http://havoc.sirris.com