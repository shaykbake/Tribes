$TelnetPort = "28001";
$TelnetPassword = "ChangeThis";
$AdminPassword = "ChangeThisAlso";

