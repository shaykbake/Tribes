//////////////////////////////////////////////////////////
////////                Renegadez Update             /////
////////                    v.1.1                    /////
//////////////////////////////////////////////////////////

UPDATES:
*Fixed many crash issues, now the server doesn't crash as much.
*Theres many more but i dont remember cause its been so long.


INSTALL:
*Just extract to your tribes directory.


EMAIL: r_fedor@swbell.net
MSN  : yugio42@hotmail.com
Yahoo: r_fedor@swbell.net
AIM  : yugio42