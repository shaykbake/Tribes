
                       RenWerX (FTA)
              The original creators of Renegades
                  www.planetrenegades.com
 			brings you

                  ******Renegades******
                       Version 4.0b



This is an update patch to Renegades 4.0.  You must have Renegades 4.0 installed
to take advantage of the admin features.  What happened to 4.0a?  4.0a was a 
partial release I provided to a select few servers before beginning on the Tribes2
renegades project.  It never got completed until now, thus the 4.0b version.

NOTE:  Server admins HAVE to update your renegades.cs with this new one

The following is a list of changes over Renegades 4.0:


**********************************************************************************************
********************
***Game Related:
********************

1)  A death from Poison or burn damage will now report a kill message, and credit the 
    initiator with a kill.

*****************
***Clan/matches/practice:
*****************

1)  Added admin option allowing a quick restart of the current map.

2)  Added admin option to disable all TK functions on the fly.

3)  Removed the Tournement mode "select team" window when an admin assigns you to a team.

4)  Added ability to send a private message to any player.

5)  Added loading screen that reports the current server settings.

6)  Added ability for the server to reload the same map, or next map in cycle after a 
    server crash.  (see Renegades.cs for info)

7)  It is now possible to run map packs that contain a staticshape.cs file without 
    conflicting with the mod.

**********************
***Admin changes
**********************

1)  Admins can now vote to change missions/settings, as well as change them on the fly.

2)  "Individual" voting options, as well as admin options are now COMPLETELY configurable 
    in the Renegades.cs

3)  A "more" selection added to the change mission type menu if the mission types exceed 8.

4)  The server will kick/ban any client without a name, and any instances of any name 
    containing ".2"

5)  Ability to vote the deathstar on or off.

6)  Ability to set deathstar to only deploy 3 per map (server hardcode only)

7)  Ability to set the deathstar to be ID'd by the other team for easy locating on cloudy maps

*****************************
***Fixes/bugs/enhancements
*****************************

1)  FIxed Teleporter clip problem

2)  Fixed Satchel deploy problem

3)  Scout armor and Scout Jet should not conflict with scripts

4)  Fixed Item shapeFile crash bug

5)  Fixed an additional crash/lag problem (this limits "per access" item drops to 5 at an 
    inventory station and no ammo drop)

6)  Vehicles can no longer be clipped into bases to the degree previously.

7)  If teams are even, the menu will offer you a choice of either team when coming out of 
    observer mode.

8)  Dropped ammo now disappears in 8 seconds.

9)  Fixed a problem with a turret firing when an admin switches your team at the start of a map.  
    (allowing player to start before matchstart)

10) Fixed an issue whereby a player could bypass the menu commands and gain unauthorized 
    admin status on a server.  Protection added to other menus and commands to prevent
    future tampering.  Any attempts to access any menu in this fashion will result in the
    player being banned as well as the players name and IP being logged in the kicklist.
    (I wouldn't test it if I were you)

11) Plasma, Rail, Missile, and Vulcan turrets can no longer be clipped far enough to a wall, 
    floor, or ceiling that would allow it to fire through the other side.

12) Fixed a bug where you were no longer able to select a weapon after accessing
    an ammostation, if it was destroyed while your ammo was being refilled.

13) Fixed a bug where it was possible to give a deployable Inventory station
    unlimited energy.  Using this bug would allow the player to use beacons, 
    select weapons, change armor, etc. while accessing a station.  This could
    also allow a player (although difficult to do) to cloak other armor classes, 
    as well as give other armor classes the heavy's shield beacon.  (VERY BAD!!)

14) Updated the Hud and splash screen information with RenWerX and the new URL.

15) Streamlined a few functions for performance.

16) Additional protection added to scripts file to prevent tampering.

**********************************************************************************************

Installation:
   Extract the scripts.vol into your dynamix\tribes\renegades folder, and extract the
   renegades.cs and startmission.cs into your dynamix\tribes\config folder.

Coding:
Snypress
EzTarget

