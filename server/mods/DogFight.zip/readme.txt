Extract DogFight.cs to Tribes\Config 
Extract DogFight.vol to Tribes\Dogfight
create a shortcut to tribes go in its properties and add the line -mod DogFight at the end of the target line.