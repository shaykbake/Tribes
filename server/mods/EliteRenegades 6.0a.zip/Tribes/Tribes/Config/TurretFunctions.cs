///////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Off Turrets  //////////////////////////
///////////////////////////////////////////////////////////////////////////


function checkOTurrets(%player,%oturdist)
{
     %playerteam = GameBase::getTeam(%player);
     if(%playerteam == 1)    // Gets team of client!
        %nmeteam = 0;
       else
         %nmeteam = 1;

    %flagpos[0] = ($teamFlag[0]).originalPosition;
    %flagpos[1] = ($teamFlag[1]).originalPosition;
    %oturdist = Vector::getDistance(%flagpos[0], %flagpos[1]) >>0;    // Gets the distance between the flags
    %oturmax = %oturdist / 2;  // Devides the flag distance * 2
    %playerpos = GameBase::getPosition(%player);        // gets the postion of the player seting d
    %zrange = Vector::getDistance(%playerpos, %flagpos[%nmeteam]);  // checks how close the d is to the enemy flag
    if($debugt){
    echo("Distance = " @ %oturdist @ " Max dist = " @ %oturmax @ " Player pos = " @ %zrange @ " Team = " @ %nmeteam @ "");
    }
   %client = Player::getClient(%player); // small maps get 120 meters
   if(%oturdist < 280)
      %oturmax = $Reneg::Odist;

   if(%zrange < %oturmax) // takes the range and checks to see if it is far enuf
        {
          %dist = %oturmax >> 0; // gives your the distance from the enemy flag
          %zdist = %zrange >> 0;  // gives you how far you need to be to set!
        Client::sendMessage(%client,1,"~waccess_denied.wav");
         bottomprint(%client, "<jc><f2> You must be <f0>" @ %dist @ "<f2> meters away from the enemy Flag! \n You are <f0>"@ %zdist @" <f2>Away from the enemy flag now!", 2);
        return 1;
			}
        else
          return 0;
		}



///////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Static Shape //////////////////////////
///////////////////////////////////////////////////////////////////////////


function Static::deployShape(%player,%item,%FieldName,%Fielddata,%FieldPack)
{
     %client = Player::getClient(%player);
     if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
     {
     if (GameBase::getLOSInfo(%player,3))
     {
     if (Vector::dot($los::normal,"0 0 1") > 0.7)
     {
     %rot = GameBase::getRotation(%player);
     %ff = newObject("","StaticShape",%Fielddata,true);
     addToSet("MissionCleanup", %ff);
     GameBase::setTeam(%ff,GameBase::getTeam(%player));
     GameBase::setPosition(%ff,$los::position);
     GameBase::setRotation(%ff,%rot);
     Gamebase::setMapName(%ff,"Deployable: " @ %FieldName @ "#" @ $totalNumForcefield++ @ " " @ Client::getName(%client));
	 Client::sendMessage(%client,0,"You Just Deployed a: " @ %FieldName @ "");
     GameBase::startFadeIn(%ff);
     playSound(SoundPickupBackpack,$los::position);
     playSound(ForceFieldOpen,$los::position);
     $TeamItemCount[GameBase::getTeam(%player) @ %FieldPack]++;
     Client::setOwnedObject(%client, %ff);
     Client::setOwnedObject(%client, %player);
     return true;
     }
     else Client::sendMessage(%client,0,"Can only deploy " @ %item.description @ "s on flat surfaces");
     }
     else Client::sendMessage(%client,0,"Deploy position out of range");
     }
     else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
     return false;
}


//////////////////////////////////////////////////////////////////////////////////////////
///////////////////////// All Turrets  ///////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

$DepGround = 0;
$DepAnywhere = 1;
$DepOutside = 3;
function DeployableTurret::deployShape(%player, %name, %turrdata, %item, %turrlocation)
{
    if($Turdebug) {
    MessageDevAdmin("TurretName = " @ %turrdata @" TurLocation - " @ %turrlocation @"");
    }
    %client = Player::getClient(%player);
    if($Reneg::NoTurrets)
	{
	Client::Sendmessage(%Client,0,"Unable to deploy - Defence Deployment is disabled ~waccess_denied.wav");
	return false;
    }
    else if($Reneg::noOTurrets)
			{
       if(checkOTurrets(%player,%oturdist))
		return;
	}
    if($Reneg::TurretKill)      // turret points
      {
      Client::setOwnedObject(%client, %turret);
	  Client::setOwnedObject(%client, %player);
     }
    if($Reneg::DScoring)    // turret deploy points
     {
    Client::Sendmessage(%client,2,"You recieved one point for setting a " @ %name @"");
    %client.score += 1;
    Game::refreshClientScore(%client);
    }
    if($TeamItemCount[GameBase::getTeam(%player) @ %item] >= $TeamItemMax[%item])
	{
		Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
		return;
	}
    if(!GameBase::getLOSInfo(%player, 3)  || !GameBase::getLOSInfo(%player, 4.5))
	{
	    Client::sendMessage(%client,0,"Deploy position out of range");
		return;
	}
	%obj = getObjectType($los::object);
	if(%obj != "SimTerrain" && %obj != "InteriorShape" && !%turrlocation == $DepAnywhere)  // mask for anywhere
	{
		Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		return;
	}
    %obj = getObjectType($los::object);
	if(%obj != "SimTerrain" && %turrlocation == $DepOutside) // mask for deploy outside
	{
		Client::sendMessage(%client,0,"Can only deploy on terrain");
		return;
	}
    if(%turrdata.Range > 0)
	{
    %set = newObject("set",SimSet);
		%box = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
		%num = CountObjects(%set, %box ,%playerTeam);
		deleteObject(%set);
  if(%num > $MaxNumTurretsInBox)
		{
		    Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			return;
		}
	}
	%set = newObject("set",SimSet);
	%num = containerBoxFillSet(%set, $StaticObjectType, $los::position, $TurretBoxMinLength, $TurretBoxMinWidth, $TurretBoxMinHeight, 0);
	%num = CountObjects(%set, %turrdata, %num);
	deleteObject(%set);
	if($MaxNumTurretsInBox < %num)
	{	Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
		return;
	}


	if(%turrlocation == $DepGround) // Floor deploy only
	{
		if(Vector::dot($los::normal,"0 0 1") <= 0.7)
		{
			Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			return;
		}
		%rot = GameBase::getRotation(%player);
	}
	else if(%turrlocation == $DepAnywhere)  // Anywhere deploy
	{
		%prot = GameBase::getRotation(%player);
		%zRot = getWord(%prot,2);
		if(Vector::dot($los::normal,"0 0 1") > 0.7)// 0.6
			%rot = "0 0 " @ %zRot;
		else
		{
			if(Vector::dot($los::normal,"0 0 -1") > 0.6)
				%rot = "3.14159 0 " @ %zRot;
			else
				%rot = Vector::getRotation($los::normal);
		}
	}
    else if(%turrlocation == $DepOutside)  // outside deploy
	{
		if(Vector::dot($los::normal,"0 0 1") <= 0.6)
		{
			Client::sendMessage(%client,0,"Can only deploy on terrain");
			return;
		}
		%rot = GameBase::getRotation(%player);
	}
	else
		return;

	if(!checkDeployArea(%client,$los::position))
	{
		return;
	}

	%turret = newObject("hellfiregun", "Turret", %turrdata, true);
    addToSet("MissionCleanup", %turret);
	GameBase::setTeam(%turret, GameBase::getTeam(%player));
	GameBase::setPosition(%turret, $los::position);
	GameBase::setRotation(%turret, %rot);
	Gamebase::setMapName(%turret, %name);
    Gamebase::setMapName(%turret,"Remote: " @ %item.description @ "#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
	Client::sendMessage(%client,0,"Remote " @ %item.description @ "");
    playSound(SoundPickupBackpack,$los::position);
	$TeamItemCount[GameBase::getTeam(%player) @ %item]++;

}
// ... end remote turrets....
    






