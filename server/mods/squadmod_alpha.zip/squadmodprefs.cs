exec("ServerPrefs.cs");//
// SquadMod Pref's
//
$SquadModPref::Version = "Alpha";
$SquadModPref::AdminEMail = "killerbunny@planetstarsiege.com";
$SquadModPref::AdminName = "KillerBunny";
$SquadModPref::AutoWeaponSwitch = True;
$SquadModPref::DisorentationTime = 6;
$SquadModPref::JoinQuote = True;
$SquadModPref::MOTD = "Running SquadMod release <f0>" @ $SquadModPref::Version @ "<f1> by KillerBunny";
$SquadModPref::OOBDelay = 5;
$SquadModPref::ParseLocations = True;
$SquadModPref::ProfanityFilter = True;
$SquadModPref::RespawnDelay = 5;
$SquadModPref::RespawnDelayIncFactor = 1;
//
// SquadMod Anti-TK, code by Kaptain Kickass
//
$SquadModPref::antiTK_noWarning = False;
$SquadModPref::antiTK_bantime = 600;
$SquadModPref::antiTK_maxTK = 5;
$SquadModPref::antiTK_kickmsg = "You were kicked for exceding your limit of team kills.";
$SquadModPref::antiTK_bcastmsg = " was kicked for team killing.";
$SquadModPref::antiTK_saveTKsByIP = True;
//
// Remote Admin Stuff
//
$TelnetPort = 12345;
$TelnetPassword = "whatever";
$AdminPassword = "adminpassword";
//
// Server Config
//
$Server::teamName[0] = "Wicked";
$Server::teamSkin[0] = "green";
$Server::teamName[1] = "Mad Skillz";
$Server::teamSkin[1] = "purple";
$Server::teamName[2] = "Children of the Phoenix";
$Server::teamSkin[2] = "cphoenix";

$Server::AutoAssignTeams = True;
$Server::HostName = "KillerBunnys SquadMod Server";
$Server::HostPublicGame = True;
$Server::Info = "TRIBES SquadMod Server\nAdmin: " @ $SquadModPref::AdminName @ "\nEmail: " @ $SquadModPref::AdminEMail;
$Server::MaxPlayers = 8;
$Server::MinVotes = 1;
$Server::MinVotesPct= 0.5;
$Server::MinVoteTime = 45;
$Server::Password = "";
$Server::Port = 28001;
$Server::TeamDamageScale = 1.0;
$Server::timeLimit = 30;
$Server::TourneyMode = False;
$Server::VoteWinMargin = 0.7;
$Server::VotingTime = 20;
$Server::warmupTime = 20;

if($pref::lastMission == "")
	$pref::lastMission = Raindance;

$Server::JoinMOTD = "<jc><f1>Message of the Day:\n" @ $SquadModPref::MOTD;

$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterName0 = "Tribes Master";
$Server::Master1 = "IP:tribes.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";

