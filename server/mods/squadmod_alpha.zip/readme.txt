SquadMod release Alpha by KillerBunny
--------------------------------------
Changes in release Alpha:

+ Optional Profanity Filter 
+ Optional %L parsing in say messages, this will replace %L with the approximate location of the speaker relative to map objects. 
+ Out of bounds damage with a set-able time delay 
+ Optional random funny quote in the MOTD 
+ Anti-TK (Provided by Kaptain Kickass) 
+ Admin command for Match Countdown in Tournament Mode 
+ Beacons are now indestructible to the team that set them, they also explode after 200 seconds. 
+ Optional automatic weapons switching when client runs out of ammo. 
+ Optional respawn delay, and delay increment factor 
+ Enhancements for Tournament Play... 
   +Admin must manually start match 
   +Everyone must have typed "ready" in a say box 
+ Deployable Command station (Provided by LabRat) 
+ Stinger Missle launcher for medium armor (Provided by LabRat) 
+ Medium and Heavy armor energy levels and Heavy armor max speed tweeked 
+ GUI Front end!!

Instructions:
Make a new directory in C:\Dynamix\Tribes\ (or wherever you installed it) called /SquadMod/
Unzip the files to /SquadMod/ and use the following command line for InfiniteSpawn.exe

InfiniteSpawn.exe *28001tribes +exec squadmodprefs.cs -mod SquadMod -dedicated

IMPORTANT: Before you start your server run the SquadMod.exe and set up your server. 
Everything has a tooltip, so if you don't know what it does, just read the tip.

E-mail comments, suggestions, bugs to: killerbunny@planetstarsiege.com