                               =+=Ultra Metal=+=
Now i know your wondering why it says ultra_metal instead of the better known +Hybrid+ name
Well before +Hybrid+ Was +Hybrid+ it was called =+=Ultra_Metal=+=, theres a little nugget of
Hybrid History for yas.


Insallation+




 ==============--------------------------------                    
FILES-=-=-=-

Scripts.vol
UltraMetal.cs
serverLink.cs

============================================================================
INSTALLATION-=-=-=-

To install =+=Ultra Metal=+=.

1: Extract "All Filesl" into Dynamix/Tribes/Config folder.

3: Hosting:: Go to your tribes Short cut & add this to the command line.
	C:\Dynamix\Tribes\Tribes.exe *tribes -mod UltraMetal

4: Dedicated:: Go to your tribes Short cut & add this to the command line.
	C:\Dynamix\Tribes\InfiniteSpawn.exe *tribes -mod UltraMetal -dedicated

============================================================================
CREDITS-=-=-=-

I would like to thank ME,WhIzAtIt
