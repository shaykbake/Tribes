exec(serverUltraMetal);

function serverLink::Start()
{
	serverUltraMetal::Start();
}

function serverLink::InitializeMission()
{
	serverUltraMetal::InitializeMission();
}