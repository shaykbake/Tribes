//--------------------------------------------Thie Is Where to ad Your admins

$CurAdminName = "HH";  //---------dont change admins will not work!			

//----------------------------------------------Public admins Passwords
$hh::PAPassword[0] = "";
$hh::PAPassword[1] = "";
$hh::PAPassword[2] = "";
$hh::PAPassword[3] = "";
$hh::PAPassword[4] = "";
$hh::PAPassword[5] = "";
$hh::PAPassword[6] = "";
$hh::PAPassword[7] = "";
$hh::PAPassword[8] = "";
$hh::PAPassword[9] = "";
$hh::PAPassword[10] = "";
$hh::PAPassword[11] = "";
$hh::PAPassword[12] = "";
$hh::PAPassword[13] = "";
$hh::PAPassword[14] = "";
$hh::PAPassword[15] = "";

//---------------------------------------------Super Admin Passwords
$hh::SadPassword[0] = "";
$hh::SadPassword[1] = "";
$hh::SadPassword[2] = "";
$hh::SadPassword[3] = "";
$hh::SadPassword[4] = "";
$hh::SadPassword[5] = "";
$hh::SadPassword[6] = "";
$hh::SadPassword[7] = "";

//-------------------------------------------- Auto Admins for Super Admins by ip and nick!
$Server::AutoAdmin[0] = "";
$Server::AutoAdmin[1] = "";
$Server::AutoAdmin[2] = "";
$Server::AutoAdmin[3] = "";
$Server::AutoAdmin[4] = "";
$Server::AutoAdmin[5] = "";
$Server::AutoAdmin[6] = "";
$Server::AutoAdmin[7] = "";
$Server::AutoAdmin[8] = "";
$Server::AutoAdmin[9] = "";
$Server::AutoAdmin[10] = "";
$Server::AutoAdmin[11] = "";
$Server::AutoAdmin[12] = "";
$Server::AutoAdmin[13] = "";
$Server::AutoAdmin[14] = "";
$Server::AutoAdmin[15] = "";


$Server::AutoAdminAddr[0] = "";
$Server::AutoAdminAddr[1] = "";
$Server::AutoAdminAddr[2] = "";
$Server::AutoAdminAddr[3] = "";
$Server::AutoAdminAddr[4] = "";
$Server::AutoAdminAddr[5] = "";
$Server::AutoAdminAddr[6] = "";
$Server::AutoAdminAddr[7] = "";
$Server::AutoAdminAddr[8] = "";
$Server::AutoAdminAddr[9] = "";
$Server::AutoAdminAddr[10] = "";
$Server::AutoAdminAddr[11] = "";
$Server::AutoAdminAddr[12] = "";
$Server::AutoAdminAddr[13] = "";
$Server::AutoAdminAddr[14] = "";
$Server::AutoAdminAddr[15] = "";

//------------------------------------example of auto admins---------------------------------------------------------
//--------
//--------$Server::AutoAdmin[0] = "/D:B/Spector"; -------- The NIck for auto admins
//--------$Server::AutoAdminAddr[0] = "IP:209.14.13.12"; -----------  the ip or ip mask for that nick
//--------
//------------------------------------end of example------------------------------------------------------------------