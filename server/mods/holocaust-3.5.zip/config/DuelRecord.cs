$Duel::RecordHolder = "";
$Duel::RecordNum = "";
$Duel::RecordTime = "";
$Duel::RecordTimeHolder = "";
$Duel::RecordTimeLoser = "";
