$CoreMAN::doPatchEcho[0] = "comchat_patch";
$CoreMAN::doPatchEcho[1] = "crown";
$CoreMAN::doPatchEcho[2] = "exec_onMissionInit";
$CoreMAN::doPatchEcho[3] = "MineLauncherFix";
$CoreMAN::doPatchEcho[4] = "Mini_Reactor_Patch";
$CoreMAN::doPatchEcho[5] = "missiontypes_patch";
$CoreMAN::doPatchEcho[6] = "other_patch";
$CoreMAN::doPatchEcho[7] = "patchList";
$CoreMAN::doPatchEcho[8] = "server_patche";
$CoreMAN::doPatchEcho[9] = "tease";
$CoreMAN::doPatchEcho[10] = "VRCheats";


function doPatchEcho(%clientId)
{
	for(%i = 0; $CoreMAN::doPatchEcho[%i] != ""; %i++)
	{
		Client::sendMessage(%clientId,$MsgTypeTeamChat, %name @ ": " @ $CoreMAN::PatchVer[%name] @ "!!!");
	}
}