$CoreMAN::PatchVer[MineLauncherFix] = "11.13.01"; //== Version is based on date just incase your wondering...

MineData MLM
{
        className = "Mine";
   description = "ML Mine";
   shapeFile = "mine";
   shadowDetailMask = 4;
   explosionId = mineExp;
        explosionRadius = 10.0;
        damageValue = 0.65;
        damageType = $MineDamageType;
        kickBackStrength = 150;
        triggerRadius = 2.5;
        maxDamage = 0.5;
        shadowDetailMask = 0;
        destroyDamage = 1.0;
        damageLevel = {1.0, 1.0};
};

function MLM::onAdd(%this)
{
        %this.damage = 0;
        MLM::deployCheck(%this);
}

function MLM::onCollision(%this,%object)
{
        %type = getObjectType(%object);
        %data = GameBase::getDataName(%this);

        if((%type == "Player" || %data == MLM || %data == Vehicle || %type == "Moveable") && GameBase::isActive(%this) && GameBase::getTeam(%this) != GameBase::getTeam(%object))
                GameBase::setDamageLevel(%this, %data.maxDamage);
}

function MLM::deployCheck(%this)
{
        if (GameBase::isAtRest(%this)) {
                GameBase::playSequence(%this,1,"deploy");
                 GameBase::setActive(%this,true);
                %set = newObject("set",SimSet);
                if(1 != containerBoxFillSet(%set,$MineObjectType,GameBase::getPosition(%this),1,1,1,0)) {
                        %data = GameBase::getDataName(%this);
                        GameBase::setDamageLevel(%this, %data.maxDamage);
                }
                deleteObject(%set);
        }
        else
                schedule("MLM::deployCheck(" @ %this @ ");", 3, %this);
}

function MLM::onDestroyed(%this)
{
        $TeamItemCount[GameBase::getTeam(%this) @ "mineammo"]--;
}

function MLM::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

        %data = GameBase::getDataName(%this);
        if((%data.maxDamage/1.5) < %this.damage+%value)
                GameBase::setDamageLevel(%this, %data.maxDamage);
        else
                %this.damage += %value;
}

//==================================
ItemImageData MineLauncherImage
{
	shapeFile = "mortargun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	//projectileType = Deploybox;
	projectileType = unidentified;
	accuFire = true;
	ammoType = MultiMineAmmo;
	reloadTime = 0.5;
	fireTime = 1.0;

	lightType = 3;  // Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 1, 1, 0.2 };

	sfxFire = SoundFireMortar; 
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
	sfxReady = SoundLaserIdle;
};

function MineLauncherImage::onFire(%player, %slot) 
{
	%clientId = player::getclient(%player);
	
	%lc = Player::getItemCount(%player,MultiMineAmmo);
		
	%armor = Player::getArmor(%player);
	%trans = GameBase::getMuzzleTransform(%player);
	%vel = Item::getVelocity(%player);
	%pos = (gamebase::getposition(%player));
	%rot = (gamebase::getrotation(%player));
	%dir = (Vector::getfromrot(%rot));

	if (%lc > 0)
	{
		%this = Projectile::spawnProjectile("Deploybox", %trans, %player, %vel);
		echo(%this);
		%this.deployer = %clientId;

		return;
	}
}

function Deploybox::onAdd(%this)
{
	schedule("DeployMines(" @ %this @ ");",4.0);
}

function DeployMines(%this)
{
	%clientId = %this.deployer;
	echo("MLM deployer = " @ %clientId);

	DeployMines::DropMine(%this,%clientId,"5 5 0");
	DeployMines::DropMine(%this,%clientId,"5 -5 0");
	DeployMines::DropMine(%this,%clientId,"-5 5 0");
	DeployMines::DropMine(%this,%clientId,"-5 -5 0");
	DeployMines::DropMine(%this,%clientId,"0 5 0");
	DeployMines::DropMine(%this,%clientId,"0 0 0");
	DeployMines::DropMine(%this,%clientId,"5 0 0");
	DeployMines::DropMine(%this,%clientId,"-5 0 0");
	DeployMines::DropMine(%this,%clientId,"0 -5 0");
}

function DeployMines::DropMine(%this,%clientId,%vector)
{
	%obj = newObject("","Mine","MLM");
	addToSet("MissionCleanup", %obj);

	%player = client::getownedobject(%clientId);
	%team = GameBase::getTeam(%player);
	GameBase::setTeam(%obj,%team);

	%tPos = GameBase::getPosition(%this);

	%padd = %vector;
	%pos = Vector::add(%tPos, %padd);
	GameBase::setPosition(%obj, %pos);
}