$CoreMAN::PatchVer[Mini_Reactor_Patch] = "11.13.01"; //== Version is based on date just incase your wondering...

ItemImageData ReactorImage
{
	shapeFile = "mortarpack";
	weaponType = 2;  // Sustained

	mountPoint = 2;
	mountOffset = { 0, -0.1, 0 };
	mountRotation = { 0, 3.12, 0 };
	
        lightType = 2;  
	lightRadius = 4;
	lightTime = 1.5;
	lightColor = { 2, 2, 2};
	
        minEnergy = -500;
 	maxEnergy = -500; //== OHHHH SWEAT energy!! OHHHHH SWEAT ENERGY!!! OHHHHH FUCKING SWEAT ENERGY!!!!!
	firstPerson = false;
};

ItemData Reactor
{
	description = "Mega-Reactor *Patched*";
	shapeFile = "generator_p";
	className = "Backpack";
   heading = "kBackpacks";
	shadowDetailMask = 4;
	imageType = ReactorImage;
	price = 3333;
	hudIcon = "energypack";
	showWeaponBar = true;
	hiliteOnActive = true;
	
	
        lightType = 2;  
	lightRadius = 4;
	lightTime = 1.5;
	lightColor = { 2, 2, 2};

};

function Reactor::onMount(%player,%item)
{
	%clientId = Player::getClient(%player);
	schedule("bottomprint(" @ %clientId @ ",\"<L9><B0,4:flag_atbase.bmp><f3>Rerouting energy for <f2>maximum<f3> output from Mini-Reactor.....<B0,4:flag_atbase.bmp>\");",0.1);

	schedule("Player::trigger(" @ %player @ "," @ $BackpackSlot @ ",true);",5);

	GameBase::setEnergy(%player,"-1000"); //== Hehehe.... IM just so evil....

}