function ChangeMOD::Stp1()
{
	for(%client = Client::getFirst(); %client != -1; %client = Client::getNext(%client))
	{
		Player::blowUp(%client);
		Player::Kill(%client);
	}

	schedule("ChangeMOD::Stp2();",0.1);
}

function ChangeMOD::Stp2()
{
	if($MDC::SuperMod == "false" || $MDC::SuperMod == "")
	{
		for(%i = 0; $Weap[%i] != ""; %i++)
		{
			%weapon = $Weap[%i];
			%weaponImg = %weapon.imageType;

			$Weapon::OldReloadSpd[%i] = %weaponImg.reloadTime;
			$Weapon::OldFireSpd[%i] = %weaponImg.fireTime;

			%weaponImg.reloadTime = 0.1;
			%weaponImg.fireTime = 0.0;
			centerprintall("<f1>Loading: " @ %weaponImg @ "<f3>....");
		}

		$MDC::SuperMod = "true";
	}
	else
	{
		for(%i = 0; $Weap[%i] != ""; %i++)
		{
			%weapon = $Weap[%i];
			%weaponImg = %weapon.imageType;

			%weaponImg.reloadTime = $Weapon::OldReloadSpd[%i];
			%weaponImg.fireTime = $Weapon::OldFireSpd[%i];
                        centerprintall("<f1>Loading: " @ %weaponImg @ "<f3>....");
		}

		$MDC::SuperMod = "false";
	}

}

function ChangeMOD()
{
	ChangeMOD::Stp1();
}