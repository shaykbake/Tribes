$CoreMAN::PatchVer[patchList] = "11.15.01"; //== Version is based on date just incase your wondering...

//== This is the list of patches

//== Cannot patch anything as of now, Ill try to fix that problem soon!


exec(Mini_Reactor_Patch); //== Test 3 for pack capability
exec(MineLauncherFix);
exec(comchat_patch);
exec(shotgun);
exec(IMP);
exec(CoreFunks);
exec(admin_patch);
exec(ModEditor);

