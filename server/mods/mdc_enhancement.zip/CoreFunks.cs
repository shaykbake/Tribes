function Core::List()
{
     schedule("Core::ProcessList(0);", 0.1);
}

function Core::ProcessList(%time)
{
     %numClients = getNumClients();
     %numCl = ((2049 + %numClients) + 20);
     %linenum = 10;
     
     for(%k = 0 ; %k < %numClients; %k++) 
          %clientList[%k] = getClientByIndex(%k);
     
     %k = %time;
     if(%k < %numClients)
     {
          %clientId = %clientList[%k];
          %ip = Client::getTransportAddress(%clientId);
          %name = Client::getName(%clientId);
     
          echo("CoreLIST:" @ %clientId @ ":" @ %name @ ":" @ %ip @ ":");

          schedule("Core::ProcessList(" @ %time + 1 @ ");", 0.1);
     }
}