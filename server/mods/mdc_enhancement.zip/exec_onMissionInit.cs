$CoreMAN::PatchVer[exec_onMissionInit] = "11.13.01"; //== Version is based on date just incase your wondering...

//== Files to EXECUTE when a mission starts.
//== Fairly straight foward...

exec(game_patch);
exec(comchat_patch);
exec(admin_patch);
