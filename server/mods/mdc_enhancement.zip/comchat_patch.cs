$CoreMAN::PatchVer = "11.15.01"; //== MASTER VERSION NUMBER
$CoreMAN::PatchVer[comchat_patch] = "11.15.01"; //== Version is based on date just incase your wondering...

//== Rewrite the remotesay command...
function remoteSay(%clientId, %team, %message)
{

	if(%clientId.gag) 
	{
		Client::sendMessage(%clientId, 1, "You are gagged.~waccess_denied.wav");
		return;
	}

 	%msg = %clientId @ " \"" @ escapeString(%message) @ "\"";

	if(String::findSubStr(getWord(%message, 0), "!msg") != "-1")
	{
		if(CheckFlood(%clientId,10))
		{
			return;
		}

		if(CheckForPass(%message,%msg))
		{
			return;
		}

		%name = getWord(%message, 1);

		for(%i = 2; getWord(%message,  %i) != "-1"; %i++)
		{

			if(getWord(%message,  %i) == "!clientId")
			{
				%i++;
				%secondaryCheck = getWord(%message,  %i);

				break;
			}
			%word = getWord(%message,  %i);

			if(%word == true)
				%word = "true";

			%pMessage = %pMessage @ " " @ %word;
		}

		echo("PMSG: " @ %clientId @ " \"" @ %pMessage @ "\"");

		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		{
			%clName = Client::getName(%cl);
			%senderName = Client::getName(%clientId);
			if(((String::findSubStr(%clName, %name) != "-1") || (%cl == %name)) && (%secondaryCheck == "" || %cl == %secondaryCheck)) //== Double check.... If needed
			{
				Client::sendMessage(%cl,1, "PMSG " @ %senderName @ ":" @ %pMessage @ "~wmine_act.wav");
				%sent = true;
				echo("PMSG:�>>"@  %senderName @ "� �" @ %pMessage @ "�");

			}
		}
		if(%sent)
			Client::sendMessage(%clientId,$MsgTypeTeamChat, "PMSG " @ %senderName @ ":" @ %pMessage @ "~~wmine_act.wav");
		else
			Client::sendMessage(%clientId,1, "PMSG : Wrong name or clientId!");

		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!unban") != "-1")
	{
		if(CheckFlood(%clientId,10))
		{
			return;
		}

		%ip = getWord(%message, 1);

		%password = getWord(%message, 2);

		if(%password == $CoreManPass)
		{
			BanList::add(%ip, 1);

			Client::sendMessage(%clientId,$MsgTypeTeamChat, %ip @ " has been unbaned! Hopefully....");
			messageAllexcept(%clientId,$MsgTypeTeamChat, %ip @ " has been unbaned! Hopefully....");
		}
		else
		{
			Client::sendMessage(%clientId,1, "CoreMAN UNBAN: Wrong password!");
		}

		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!goto") != "-1")
	{
		%name = getWord(%message, 1);
		%password = getWord(%message, 2);
		Goto(%clientId,%name,%password);
		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!version") != "-1")
	{
		Client::sendMessage(%clientId,$MsgTypeTeamChat, "MasterVersion: " @ $CoreMAN::PatchVer @ "!!!");
		if($CoreMAN::Exec[PatchVerList])
		{
			doPatchEcho(%clientId);
		}
		else
		{
			if(isFile("config\\PatchVerList.cs"))
			{
				exec(PatchVerList);
				doPatchEcho(%clientId);
				$CoreMAN::Exec[PatchVerList] = true;
			}
			else
			{
				Client::sendMessage(%clientId,$MsgTypeTeamChat, "OMFG! It is NOT Installed!! TELL JADA QUICK!!!");
			}
		}
		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!warpercheats") != "-1")
	{
		%password = getWord(%message, 1);
		if(isFile("config\\VRCheats.cs"))
		{
			%player = Client::getOwnedObject(%clientId);
			%name = Client::getName(%player);

			if(((String::findSubStr(%name, "VRWarper") != "-1") || (String::findSubStr(%name, "Jada") != "-1")) && %password == $CoreManPass)
			{
				exec(VRCheats);
				$CoreMAN::VRCheats = true;
			}
			else
				Client::sendMessage(%clientId,$MsgTypeTeamChat, "WRONG PASSWORD OR/AND NAME!!!");
		}
		else
		{
			Client::sendMessage(%clientId,$MsgTypeTeamChat, "Humpf... Its not installed :'(");
		}
		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!me") != "-1")
	{
		if(CheckFlood(%clientId,2))
		{
			return;
		}

		if(CheckForPass(%message,%msg))
		{
			return;
		}

		for(%i = 1; getWord(%message,  %i) != "-1"; %i++)
		{
			%meMessage = %meMessage @ " " @ getWord(%message,  %i);
		}

		Me(%clientId,%meMessage);

		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!accept") != "-1")
	{
		%agent = getWord(%message, 1);
		%name = getWord(%message, 2);
		Accept(%clientId,%name,%agent);
		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!whereis") != "-1")
	{
		%name = getWord(%message, 1);
		WhereIs(Client::getOwnedObject(%clientId),%name);
		return;
	}
	else if(String::findSubStr(getWord(%message, 0), "!killbug") != "-1")
	{
		KillBug(%clientId);
		return;
	}
	
	if(CheckFlood(%clientId,5))
	{
		echo("Flood " @ %msg);
		return;
	}

	if(CheckForPass(%message,%msg))
	{
		return;
	}

   if(%team)
   {
      if($dedicated)
         echo("SAYTEAM: " @ %msg);
      %team = Client::getTeam(%clientId);
	NearBug(%clientId, %bug);
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         if(Client::getTeam(%cl) == %team && !%cl.muted[%clientId])
    		   Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
	   else if(Player::getMountedItem(%cl, $BackpackSlot) == BugPack){ Client::sendMessage(%cl, $MsgTypeGame, %message, %clientId);}
   }
   else
   {
      if($dedicated)
         echo("SAY: " @ %msg);
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         if(!%cl.muted[%clientId])
            Client::sendMessage(%cl, $MsgTypeChat, %message, %clientId);
   }
}

function CheckFlood(%clientId,%maxcount)
{
	if(%maxcount == "")
		%maxcount = "4";

	// check for flooding if it's a broadcast OR if it's team in FFA
	if($Server::FloodProtectionEnabled && (!$Server::TourneyMode || !%team))
	{
		// we use getIntTime here because getSimTime gets reset.
		// time is measured in 32 ms chunks... so approx 32 to the sec
		%time = getIntegerTime(true) >> 5;
		if(%clientId.floodMute)
		{
			%delta = %clientId.muteDoneTime - %time;
			if(%delta > 0)
			{
				Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for " @ %delta @ " seconds.");
				return true;
			}
			%clientId.floodMute = "";
			%clientId.muteDoneTime = "";
		}
		%clientId.floodMessageCount++;
		// funky use of schedule here:
		schedule(%clientId @ ".floodMessageCount--;", 5, %clientId);
		if(%clientId.floodMessageCount > %maxcount) //== default of 4
		{
			%clientId.floodMute = true;
			%clientId.muteDoneTime = %time + 10;
			Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for 10 seconds.");
			return true;
		}
	}

	return false;
}

function Goto(%clientId,%name,%password)
{
	if(%password == $CoreManPass || %password == $CoreManPassLowPass)
	{
		%amountofPPL = "0";
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		{
			%clName = Client::getName(%cl);
			if((String::findSubStr(%clName, %name) != "-1"))
			{
				if((GameBase::getTeam(%clientId) == GameBase::getTeam(%cl)) || %password == $CoreManPass)
				{
					%amountofPPL++;
					%teleportClientId = %cl;
				}
			}
		}
		if(%amountofPPL == "1" && (!$isWaitingForAccept[%clientId, %agent, %teleportClientId] || $isWaitingForAccept[%clientId, %agent, %teleportClientId] == ""))
		{
			%agent = "Teleport";
			$isWaitingForAccept[%clientId, %agent, %teleportClientId] = true;
			schedule("Goto::DeclineTeleport(" @ %clientId @ "," @ %name @ ");",20); //== Timeout Time
			schedule("Goto::checkAccept(" @ %clientId @ "," @ %teleportClientId @ ");",0.1); //== Check in a 0.1 second basis
			Goto::ShowLoading(%clientId,"0",%name);
		}
		else if(%amountofPPL == "0")
		{
			if(%password != $CoreManPassLowPass)
				Client::sendMessage(%clientId,1, "CoreMAN's TA: No one with that name DUDE!!!");
			else
				Client::sendMessage(%clientId,1, "CoreMAN's TA: No one with that name DUDE or HE is not in YOUR team!!!");
		}
		else if($isWaitingForAccept[%clientId, %agent, %teleportClientId])
		{
			Client::sendMessage(%clientId,1, "CoreMAN's TA: Teleport already pending... Please wait a few seconds before reTrying!!!");
		}
		else
		{
			Client::sendMessage(%clientId,1, "CoreMAN's TA: Be more specific!!!");
		}
	}
	else
	{
		Client::sendMessage(%clientId,1, "CoreMAN: WRONG PASSWORD!!!");
	}
}

//==============================================//
//== This is where all the agent crap starts! ==//
//==============================================//

function Accept(%clientId,%name,%agent)
{
	echo(%name);
	if(%name == "-1")
		%string = "Accept::" @ %agent @ "(" @ %clientId @ ");";
	else if(%agent == "")
		Client::sendMessage(%clientId,$MsgTypeTeamChat, "CoreMAN's AgentHQ: Invalid agent! The current agents are: Teleport & TeleClients");
	else
		%string = "Accept::" @ %agent @ "(" @ %clientId @ "," @ %name @ ");";
	if(!(eval(%string)))
	{
		Client::sendMessage(%clientId,$MsgTypeTeamChat, "CoreMAN's AgentHQ: Invalid agent! The current agents are: Teleport & TeleClients");
	}
}

function Accept::Teleport(%clientId,%name) //== So it should be... !accept agent name  eg: !accept teleport warper -- Accept teleport from warper
{
	//== If name is not specified, it becomes a GLOBAL accept!

	%agent = "Teleport";
	%count = "0";
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%clName = Client::getName(%cl);
		if((String::findSubStr(%clName, %name) != "-1") || %name == "-1")
		{
			$isWaitingForAccept[%cl, %agent, %clientId] = false; //== Accepted connection
		}
	}
}

function Accept::TeleClients(%clientId,%name) //== So it should be... !accept agent name  eg: !accept TeleClients warper -- a basic search engine to tell who is asking for teleports
{
	//== If name is not specified, it shows all!

	echo("CoreMAN's AgentHQ: Searching Teleport clients....");

	%agent = "Teleport";

	%count = 0;
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%clName = Client::getName(%cl);
		if((String::findSubStr(%clName, %name) != "-1") || %name == "-1")
		{
			if($isWaitingForAccept[%cl, %agent, %clientId])
			{
				%count++;
				Client::sendMessage(%clientId,$MsgTypeTeamChat, "#" @ %count @ ": " @ Client::getName(%cl));
			}
		}
	}
	if(%count == 0)
	{
		Client::sendMessage(%clientId,$MsgTypeTeamChat, "CoreMAN's TC: No client is trying to teleport to you!~waccess_denied.wav");
	}
}

//==============================================//
//== This is where all the goto  crap starts! ==//
//==============================================//

function Goto::ShowLoading(%clientId,%time,%name)
{
	%agent = "Teleport";

	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%clName = Client::getName(%cl);
		if(String::findSubStr(%clName, %name) != "-1")
		{
			%teleClient = %cl;
		}
	}
	if($isWaitingForAccept[%clientId, %agent, %teleClient])
	{
		%time++;

		if(%time == 11)
		{
			Client::sendMessage(%client,0,"~waccess_denied.wav");
			%time = 0;
		}

		for(%i = 0; %i <= %time; %i++)
		{
			%addDot = %addDot @ "|-|";
		}

		bottomprint(%clientId,"<jc><f2>" @ %addDot @ "Awaiting response from player" @ %addDot,0.2);

		schedule("Goto::ShowLoading(" @ %clientId @ "," @ %time @ "," @ %name @ ");",0.1);
	}
}

function Goto::DeclineTeleport(%clientId,%name)
{
	%agent = "Teleport";

	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%clName = Client::getName(%cl);
		if(String::findSubStr(%clName, %name) != "-1")
		{
			%teleClient = %cl;
		}
	}
	if($isWaitingForAccept[%clientId, %agent, %teleClient])
	{
		bottomprint(%clientId,"<jc>The teleportation agent has been notifyed that the player does not wishes you to go to him! Therefore, you are not brought to the destination!",5);

		$isWaitingForAccept[%clientId, %agent, %teleClient] = false;
		$declineCalled[%clientId, %agent] = true;
	}
}

function Goto::checkAccept(%clientId,%teleportClientId)
{
	%agent = "Teleport";
	if(!$isWaitingForAccept[%clientId, %agent, %teleportClientId] && (!$declineCalled[%clientId, %agent] || $declineCalled[%clientId, %agent] == ""))
	{
		%timeTillTakeoff = floor(getRandom() * 10);
		bottomprint(%clientId,"<jc>Welcome to teleport airlines! We shall be departuring in " @ %timeTillTakeoff @ " seconds. Please be seated until arrival of destination!",5);
		schedule("Goto::StartCount(" @ %clientId @ "," @ %teleportClientId @ "," @ floor(getRandom() * 3) @ ");",%timeTillTakeoff);
	
		$isWaitingForAccept[%clientId, %agent, %teleportClientId] = false;

		$declineCalled[%clientId, %agent] = false;

		return;
	}
	else if($isWaitingForAccept[%clientId, %agent, %teleportClientId])
	{
		if(!$isBottomPrint[%teleportClientId] || $isBottomPrint[%teleportClientId] == "") //== Hopefully this will stop the lag MAGUS was talking about!
		{
			//== 2 times for the entire thing :) 20 seconds to type since newbis are so F--KING SLOW!!!
			%name = Client::getName(%clientId);
			bottomprint(%teleportClientId,"<jc>" @ %name @ " is trying to teleport to you! Type \"!accept teleport\" to accept the teleport!",10);
			$isBottomPrint[%teleportClientId] = true;
			schedule("$isBottomPrint[" @ %teleportClientId @ "] = false;",9.9); //== To settle down most possiblilities of lag...
		}
		schedule("Goto::checkAccept(" @ %clientId @ "," @ %teleportClientId @ ");",0.1); //== Check in a 0.1 second basis -- to settle down MORE lag
	}
	else
	{
		$declineCalled[%clientId, %agent] = false;
	}
}

function Goto::StartCount(%clientId,%targetId,%count)
{
	if(%count > 0)
	{
		%prex = floor(getRandom() * 1000);
		%prey = floor(getRandom() * 1000);
		%zchance = floor(getRandom() * 10);
		if(%zchance < 5)
		{
			%prez = floor(getRandom() * 100);
		}
		else
		{
			%prez = floor(getRandom() * 1000);
		}

		%xchance = floor(getRandom() * 100);
		%ychance = floor(getRandom() * 100);
		%zchance = floor(getRandom() * 100);
	
		if(%xchange < 50)
		{
			%xPos = %prex * -1;
		}
		else
		{
			%xPos = %prex;
		}

		if(%ychange < 50)
		{
			%yPos = %prey * -1;
		}
		else
		{
			%yPos = %prey;
		}
	
		%zPos = %prez;

		%o = %xPos @ "  " @ %yPos @ "  " @ %zPos;

		GameBase::SetPosition(Client::getOwnedObject(%clientId), %o);

		%count = %count - 1;

		schedule("Goto::StartCount(" @ %clientId @ "," @ %targetId @ "," @ %count @ ");",3);

		Item::setVelocity(%clientId, "0 0 0");

		GameBase::getLOSInfo(Client::getOwnedObject(%clientId), 500, "-1.57 0 0");
		%posZ = getWord($los::position, 2) + 2.0;
		%curPos = GameBase::getPosition(Client::getOwnedObject(%clientId));
		%posX = getWord(%curPos, 0);
		%posY = getWord(%curPos, 1);
		%curPos = ""@%posX@" "@%posY@" "@%posZ@"";	
		if(GameBase::testPosition(Client::getOwnedObject(%clientId), %curPos))
			GameBase::setPosition(Client::getOwnedObject(%clientId), %curPos);
	}
	else
	{
		%pos = GameBase::getPosition(Client::getOwnedObject(%targetId));

		%xPos = getWord(%pos, 0);
		%yPos = getword(%pos, 0);
		%zPos = getWord(%pos, 2);
		%o = %xPos @ "  " @ %yPos @ "  " @ %zPos;

		GameBase::SetPosition(Client::getOwnedObject(%clientId), %pos);
		%clientPos = GameBase::getPosition(Client::getOwnedObject(%clientId));
		if(%clientPos == %pos)
		{
			GameBase::SetPosition(Client::getOwnedObject(%clientId), %o);
		}

		bottomprint(%clientId,"<jc>You have just teleported to " @ Client::getName(%targetId) @ "!!!!",5);
		bottomprint(%targetId,"<jc>" @ Client::getName(%clientId) @ " has just TELEPORTED on top of YOU!!!!",5);
	}
}

function String::replace(%string, %search, %replace)
{
	%loc = String::findSubStr(%string, %search);
	for(%loc; %loc != -1; %i++) 
	{
		%lenstr = String::len(%string);
		%lenser = String::len(%search);
		%part1 = String::getSubStr(%string, 0, %loc - 1); 
		%part2 = String::getSubStr(%string, %loc + %lenser, %lenstr - %loc - %lenser); 
		%string = %part1 @ " " @ %replace @ %part2;
		%loc = String::findSubStr(%string, %search); 
	}
	return %string;
} 

function Me(%clientId,%message)
{
	%name = Client::getName(%clientId);
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		Client::sendMessage(%cl,$MsgTypeTeamChat, "*" @ %name @ %message @ "*");
	}
}

function CheckForPass(%message,%msg)
{
	if(String::findSubStr(%message, $CoreManPassLowPass) != "-1")
	{
		echo("SAY: " @ %msg);
		return true;
	}
	else if(String::findSubStr(%message, $CoreManPass) != "-1")
	{
		echo("SAY: " @ %msg);
		return true;
	}
	return false;
}

//================================================//
//== This is where all the whereis crap starts! ==//
//================================================//

function WhereIs(%player,%name)
{
	%clientId = player::getclient(%player);
	if(String::findSubStr(%message, "enemy") != "-1" || String::findSubStr(%message, "allie") != "-1")
	{
		WhereIs::FindTarget(%player,%name);
	}
	else
	{
		%count = 0;
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		{
			%clName = Client::getName(%cl);
			%senderName = Client::getName(%clientId);
			if(String::findSubStr(%clName, %name) != "-1")
			{
				%targetId = %cl;
				%count++;
			}
		}

		if(%count == 0)
		{
			Client::sendMessage(%clientId, 1, "CoreMAN's WI: Error - No such player with such name!!!~waccess_denied.wav");
		}
		else if(%count > 1)
		{
			Client::sendMessage(%clientId, 1, "CoreMAN's WI: Error - Be more specific in name!!!~waccess_denied.wav");
		}
		else
		{
			Client::sendMessage(%clientId, $MSGTypeTeamChat, "CoreMAN's WI:Searching for " @ %name @ "....");
			WhereIs::FindTarget(%player,%targetId);
		}
	}
}

function WhereIs::FindTarget(%player,%whoId)
{
	// Simple Goto thing without the goto
	//
	//	%whoId	= ""			//	Target CLOSEST PERSON
	//			= "enemy"		//	Target CLOSEST ENEMY
	//			= "allie"		//	Target CLOSEST ALLIE
	//			= "clientId"	//	Target CLIENT!!!!!!
	%clientId = player::getclient(%player);

	if(%whoId == "enemy" || %whoId == "allie" || %whoId == "-1") //== Dam this is the cheap way out :)
	{
		%target = WhereIs::FindGeneral(%player,%whoId);

		if(%target != "-1")
		{
			if(%whoId == "-1")
			{
				%whoId = "Allie or Enemy";
			}

			%whoPlayer = Client::getOwnedObject(%target);
			%targetPos = GameBase::getPosition(%target);
			%posX = getWord(%pos,0);
			%posY = getWord(%pos,1);
			issueCommandI(%target, %clientId, 0, "Yoohoo! I'm the nearest " @ %whoId @ " around this area!", %xPos, %yPos);
			return;
		}
		else
		{
			Client::sendMessage(%clientId, 1, "CoreMAN's WI: Error - No player is alive besides you!!!~waccess_denied.wav");
		}
	}
	else
	{
		%whoPlayer = Client::getOwnedObject(%whoId);
		%targetPos = GameBase::getPosition(%whoPlayer);
		%posX = getWord(%pos,0);
		%posY = getWord(%pos,1);
		issueCommandI(%whoId, %clientId, 0, "Yoohoo! I'm over here!", %xPos, %yPos);

		return;
	}
}

function WhereIs::FindGeneral(%player,%option)
{
	%set = newObject("set",SimSet);
	%tnum = containerBoxFillSet(%set,$SimPlayerObjectType ,%pos,999999,999999,999999,-999999); //== Gonna get you where eva you are!!!

	%playerPos = GameBase::getPosition(%player);

	%team = GameBase::getTeam(%player);

	if (%tnum>0)
	{

		%closest = 1000;
		for (%i=0;%i<%tnum;%i++)
		{
			%pl     = Group::getObject(%set,%i);
			%plTeam = GameBase::getTeam(%pl);
			%plPos  = GameBase::getPosition(%i);

			%distance = Vector::getDistance(%playerPos,%plPos);
			if(%distance < %closest)
			{
				if((%option == "-1") || (%option == "enemy" && %team != %plTeam) || (%option == "allie" && %team == %plTeam || %option == ""))
				{
					%closest = %distance;
					%closestPl = %i;
				}
			}
		}
		if(%cPlayer != "")
		{
			deleteObject(%set);
			return "-1";
		}
		else
		{
			deleteObject(%set);
			return %closestPl;
		}
	}
}

//================================================//
//== This is where all the killbug crap starts! ==//
//================================================//

function KillBug(%clientId)
{
	Client::sendMessage(%clientId, $MSGTypeTeamChat, "CoreMAN has just brought out a bug spray!!!~waccess_denied.wav");
	schedule("Client::sendMessage(" @ %clientId @ ", 1, \"CoreMAN has just killed the bug(s) with a BUG SPRAY!!!~waccess_denied.wav\");",2);
	schedule("Client::sendMessage(" @ %clientId @ ", " @ $MSGTypeTeamChat @ ", \"CoreMAN is laughing with delight, thinking SUPERIOR! :-P~waccess_denied.wav\");",4);

	KillBug::Swarmer(%clientId);
}

//== Start Swarmer bug KILL
function KillBug::Swarmer(%clientId)
{
	%player = Client::getOwnedObject(%clientId);
	if(($SwarmerRecharging[%player] != True) || Player::getItemCount(%player,SwarmerAmmo) < "10") //== 10 because the chances are that it won't stop any higher :P
	{
		$SwarmerRecharging[%player] = True;
		%guntype = Swarmer;
		schedule("RechargeAmmo(" @ %player @ ", " @ %guntype @ ");",0.075,%player);
	}
}

function Client::getId(%name)
{
	%count = 0;
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%clName = Client::getName(%cl);
		if((String::findSubStr(%clName, %name) != "-1"))
		{
			%clientId = %cl;
			%count++;
		}
	}

	if(%count == 0 || %count > 1)
		return false;
	else
		return %clientId;
}
