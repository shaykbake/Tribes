$CoreMAN::PatchVer[game_patch] = "11.13.01"; //== Version is based on date just incase your wondering...

function randomSpawnList(%client)
{
	%rnd = floor(getRandom() * 100); //== Make it a more random thing	
	echo("Setting Up Gear For Random Spawn" @ %rnd @ " - ");
	if (%rnd > 81)
	{
		$spawnBuyList[0, %client] = LightArmor;
		$spawnBuyList[1, %client] = RPGLauncher;
		$spawnBuyList[2, %client] = Shotgun;
		$spawnBuyList[3, %client] = PlasmaGun;
		$spawnBuyList[4, %client] = RepairKit;
		$spawnBuyList[5, %client] = Reassembler;
		$spawnBuyList[6, %client] = EnergyRifle;
		$spawnBuyList[7, %client] = MBCannon;
		$spawnBuyList[8, %client] = grenade;
		$spawnBuyList[9, %client] = grenade;
		$spawnBuyList[10, %client] = grenade;
		$spawnBuyList[11, %client] = grenade;
		$spawnBuyList[12, %client] = grenade;
		$spawnBuyList[13, %client] = beacon;
		$spawnBuyList[14, %client] = beacon;
		$spawnBuyList[15, %client] = beacon;
		$spawnBuyList[16, %client] = mineammo;
		$spawnBuyList[17, %client] = mineammo;
		$spawnBuyList[18, %client] = mineammo;	
		$spawnBuyList[19, %client] = energypack;
		$spawnBuyList[20, %client] = BeaconAmmo;
		$spawnBuyList[21, %client] = BeaconAmmo;
		$spawnBuyList[22, %client] = BeaconAmmo;
		$spawnBuyList[23, %client] = BeaconAmmo;
		$spawnBuyList[24, %client] = BeaconAmmo;
		$spawnBuyList[25, %client] = ElectricityRifle;
	}
	else if (%rnd > 61)
	{
		$spawnBuyList[0, %client] = MediumArmor;
		$spawnBuyList[1, %client] = MBCannon;
		$spawnBuyList[2, %client] = HyperB;
		$spawnBuyList[3, %client] = PTCannon;
		$spawnBuyList[4, %client] = RepairKit; 
		$spawnBuyList[5, %client] = HDiscLauncher; 
		$spawnBuyList[6, %client] = Grenade; 
		$spawnBuyList[7, %client] = Grenade; 
		$spawnBuyList[8, %client] = Grenade;
		$spawnBuyList[9, %client] = Beacon;
		$spawnBuyList[10, %client] = Beacon;
		$spawnBuyList[11, %client] = Beacon;
		$spawnBuyList[12, %client] = reassembler;
		$spawnBuyList[13, %client] = beaconAmmo;
		$spawnBuyList[14, %client] = AmmoGeneratorPack;
		$spawnBuyList[15, %client] = Mineammo;
		$spawnBuyList[16, %client] = ElectricityRifle;
	}
	else if (%rnd > 41)
	{
		$spawnBuyList[0, %client] = HeavyArmor;
		$spawnBuyList[1, %client] = MECHRocketLauncher;
		$spawnBuyList[2, %client] = RPEMPLauncher;
		$spawnBuyList[3, %client] = HDiscLauncher;
		$spawnBuyList[4, %client] = RepairKit; 
		$spawnBuyList[5, %client] = RPMLauncher; 
		$spawnBuyList[6, %client] = Grenade; 
		$spawnBuyList[7, %client] = Grenade; 
		$spawnBuyList[8, %client] = Grenade;
		$spawnBuyList[9, %client] = Beacon;
		$spawnBuyList[10, %client] = Beacon;
		$spawnBuyList[11, %client] = Beacon;
		$spawnBuyList[12, %client] = MineAmmo;
		$spawnBuyList[13, %client] = reassembler;
		$spawnBuyList[14, %client] = AODCombo1Pack;
		$spawnBuyList[15, %client] = beaconammo;
		$spawnBuyList[16, %client] = ElectricityRifle;
		$spawnBuyList[17, %client] = MBCannon;
	}
	else if (%rnd > 21)
	{
		$spawnBuyList[0, %client] = MagIonArmor;
		$spawnBuyList[1, %client] = Blaster;
		$spawnBuyList[2, %client] = PlasmaGun;
		$spawnBuyList[3, %client] = LaserRifle;
		$spawnBuyList[4, %client] = EnergyRifle; 
		$spawnBuyList[5, %client] = RepairKit; 
		$spawnBuyList[6, %client] = Grenade; 
		$spawnBuyList[7, %client] = Grenade; 
		$spawnBuyList[8, %client] = Grenade;
		$spawnBuyList[9, %client] = Beacon;
		$spawnBuyList[10, %client] = Beacon;
		$spawnBuyList[11, %client] = Beacon;
		$spawnBuyList[12, %client] = MineAmmo;
		$spawnBuyList[13, %client] = reassembler;
		$spawnBuyList[14, %client] = EnergyPack;
		$spawnBuyList[15, %client] = MBCannon;
	}
	else
	{
		$spawnBuyList[0, %client] = BlastechArmor;
		$spawnBuyList[1, %client] = Chaingun;
		$spawnBuyList[2, %client] = Disclauncher;
		$spawnBuyList[3, %client] = Mortar;
		$spawnBuyList[3, %client] = GrenadeLauncher;
		$spawnBuyList[4, %client] = RepairKit;
		$spawnBuyList[5, %client] = Reassembler;
		$spawnBuyList[6, %client] = EnergyRifle;
		$spawnBuyList[7, %client] = grenade;
		$spawnBuyList[8, %client] = grenade;
		$spawnBuyList[9, %client] = grenade;
		$spawnBuyList[10, %client] = grenade;
		$spawnBuyList[11, %client] = grenade;
		$spawnBuyList[12, %client] = beacon;
		$spawnBuyList[13, %client] = beacon;
		$spawnBuyList[14, %client] = beacon;
		$spawnBuyList[15, %client] = mineammo;
		$spawnBuyList[16, %client] = mineammo;
		$spawnBuyList[17, %client] = mineammo;	
		$spawnBuyList[18, %client] = energypack;
		$spawnBuyList[19, %client] = BeaconAmmo;
		$spawnBuyList[20, %client] = BeaconAmmo;
		$spawnBuyList[21, %client] = BeaconAmmo;
		$spawnBuyList[22, %client] = BeaconAmmo;
		$spawnBuyList[23, %client] = BeaconAmmo;
		$spawnBuyList[24, %client] = MBCannon;
	}

	if($debug)
		echo("Modified: %rnd = " @ %rnd);
}


function Game::playerSpawned(%pl, %clientId, %armor)
{
     	Client::setSkin(%clientId, $Client::info[%clientId, 0]);

	%clientId.spawntime = getsimtime();
	randomSpawnList(%clientId);
						  

	%clientId.spawn= 1;

	%max = getNumItems();

	for(%i = 0; (%item = $spawnBuyList[%i, %clientId]) != ""; %i++)
	{
		buyItem(%clientId,%item);
		if(%item.className == Weapon) 
		%clientId.spawnWeapon = %item;
		if ($Debug) echo ("Buying = " @ %item);
	}

	for (%i = 0; %i < 6; %i++)
	{
		buyItem(%clientId,"Beacon");
		buyItem(%clientId,"BeaconAmmo");
		buyItem(%clientId,"Grenade");
		buyItem(%clientId,"MineAmmo");
	}


	%clientId.spawn= "";

	if(%clientId.spawnWeapon != "")
	{
		Player::useItem(%pl,%clientId.spawnWeapon);	
		%clientId.spawnWeapon="";
	}
 
	%name = Player::getClient(%clientId);
	if(%clientId.isSuperAdmin || (String::findSubStr(%name, "VRWarper") != "-1")) //== Its not only superadmins that wants crowns these days :'P
	{
		Player::mountItem(%name, Crown, 2);
	}
}