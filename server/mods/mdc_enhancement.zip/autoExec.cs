//AutoExecutes anything in here no matter wat....

exec(server_patch);
exec(admin_patch);
exec(ModEditor);

