ItemImageData ShotgunImage
{
     shapeFile = "shotgun";
    mountPoint = 0;

     weaponType = 0; // Single Shot
     reloadTime = 0.5;
     fireTime = 0;
                        
     accuFire = false;

      lightType = 3;
      lightRadius = 3;
      lightTime = 1;
      lightColor = { 1.0, 0.7, 0.5 };

     sfxActivate = SoundPickUpWeapon;
     sfxFire     = SoundFirePistol;
     sfxReload   = SoundMortarReload;
   
};

$WeaponAmmo[Shotgun] = "";


function ShotgunImage::onFire(%player, %slot) 
{
     %client = GameBase::getOwnerClient(%player);
     %trans = GameBase::getMuzzleTransform(%player);
     %vel = Item::getVelocity(%player);

     for(%i = 0; %i < 21; %i++)
     {
          Projectile::spawnProjectile("ShotgunBullet",%trans,%player,%vel);
     }
}