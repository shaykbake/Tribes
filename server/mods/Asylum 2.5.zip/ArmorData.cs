//----------------------------------------------------------------------------
// Resistor Armor
//----------------------------------------------------------------------------

$DamageScale[rearmor, $LandingDamageType] = 1.0;
$DamageScale[rearmor, $ImpactDamageType] = 1.0;
$DamageScale[rearmor, $CrushDamageType] = 1.0;
$DamageScale[rearmor, $BulletDamageType] = 1.2;
$DamageScale[rearmor, $PlasmaDamageType] = 1.0;
$DamageScale[rearmor, $EnergyDamageType] = 1.3;
$DamageScale[rearmor, $ExplosionDamageType] = 1.0;
$DamageScale[rearmor, $MissileDamageType] = 1.0;
$DamageScale[rearmor, $DebrisDamageType] = 1.2;
$DamageScale[rearmor, $ShrapnelDamageType] = 1.2;
$DamageScale[rearmor, $LaserDamageType] = 1.0;
$DamageScale[rearmor, $MortarDamageType] = 1.3;
$DamageScale[rearmor, $BlasterDamageType] = 1.3;
$DamageScale[rearmor, $ElectricityDamageType] = 1.0;
$DamageScale[rearmor, $MineDamageType] = 1.2;
$DamageScale[rearmor, $FlashDamageType] = 1.0;
$DamageScale[rearmor, $EMPDamageType] = 1.0;
$DamageScale[rearmor, $EqualizerDamageType] = 1.0;
$DamageScale[rearmor, $ShredderDamageType] = 1.0;
$DamageScale[rearmor, $ShotgunDamageType] = 1.0;
$DamageScale[rearmor, $CannonDamageType] = 1.0;
$DamageScale[rearmor, $BlastDamageType] = 1.0;
$DamageScale[rearmor, $FireDamageType] = 1.0;
$DamageScale[rearmor, $NukeDamageType] = 1.0;
$ItemMax[rearmor, Blaster] = 1;
$ItemMax[rearmor, Equalizer] = 0;
$ItemMax[rearmor, Disclauncher] = 1;
$ItemMax[rearmor, GrenadeLauncher] = 0;
$ItemMax[rearmor, Mortar] = 0;
$ItemMax[rearmor, SoulStealer] = 0;
$ItemMax[rearmor, EarthquakeCannon] = 0;
$ItemMax[rearmor, PlasmaGun] = 1;
$ItemMax[rearmor, Shotgun] = 0;
$ItemMax[rearmor, BlastLauncher] = 0;
$ItemMax[rearmor, LaserRifle] = 0;
$ItemMax[rearmor, GravityGun] = 0;
$ItemMax[rearmor, SniperRifle] = 0;
$ItemMax[rearmor, TargetingLaser] = 1;
$ItemMax[rearmor, MineAmmo] = 3;
$ItemMax[rearmor, FlagMineAmmo] = 3;
$ItemMax[rearmor, Grenade] = 5;
$ItemMax[rearmor, Beacon]  = 3;
$ItemMax[rearmor, ForceFieldPack] = 0;
$ItemMax[rearmor, LargeFieldPack] = 0;
$ItemMax[rearmor, BulletAmmo] = 100;
$ItemMax[rearmor, PlasmaAmmo] = 30;
$ItemMax[rearmor, DiscAmmo] = 15;
$ItemMax[rearmor, GrenadeAmmo] = 10;
$ItemMax[rearmor, BlastAmmo] = 0;
$ItemMax[rearmor, MortarAmmo] = 10;
$ItemMax[rearmor, SniperAmmo] = 50;
$ItemMax[rearmor, ShotgunShells] = 50;
$ItemMax[rearmor, EnergyPack] = 1;
$ItemMax[rearmor, RepairPack] = 1;
$ItemMax[rearmor, ShieldPack] = 1;
$ItemMax[rearmor, SensorJammerPack] = 1;
$ItemMax[rearmor, MotionSensorPack] = 1;
$ItemMax[rearmor, PulseSensorPack] = 1;
$ItemMax[rearmor, DeployableSensorJammerPack] = 1;
$ItemMax[rearmor, CameraPack] = 1;
$ItemMax[rearmor, TurretPack] = 0;
$ItemMax[rearmor, AmmoPack] = 1;
$ItemMax[rearmor, RepairKit] = 1;
$ItemMax[rearmor, DeployableInvPack] = 0;
$ItemMax[rearmor, DeployableAmmoPack] = 0;
$ItemMax[rearmor, SatCameraPack] = 0;
$ItemMax[rearmor, AirPlatformPack] = 0;
$ItemMax[rearmor, LargeAirPlatPack] = 0;
$ItemMax[rearmor, FalloutCannon] = 0;
$ItemMax[rearmor, NukeAmmo] = 10;
$ItemMax[rearmor, LaserTurretPack] = 0;
$ItemMax[rearmor, CloakGun] = 0; 
$ItemMax[rearmor, LaserShredder] = 0; 
$MaxWeapons[rearmor] = 5;

//----------------------------------------------------------------------------
// RadCon Armor
//----------------------------------------------------------------------------

$DamageScale[rarmor, $LandingDamageType] = 1.0;
$DamageScale[rarmor, $ImpactDamageType] = 1.0;
$DamageScale[rarmor, $CrushDamageType] = 1.0;
$DamageScale[rarmor, $BulletDamageType] = 1.2;
$DamageScale[rarmor, $PlasmaDamageType] = 1.0;
$DamageScale[rarmor, $EnergyDamageType] = 1.3;
$DamageScale[rarmor, $ExplosionDamageType] = 1.0;
$DamageScale[rarmor, $MissileDamageType] = 1.0;
$DamageScale[rarmor, $DebrisDamageType] = 1.2;
$DamageScale[rarmor, $ShrapnelDamageType] = 1.2;
$DamageScale[rarmor, $LaserDamageType] = 1.0;
$DamageScale[rarmor, $MortarDamageType] = 1.3;
$DamageScale[rarmor, $BlasterDamageType] = 1.3;
$DamageScale[rarmor, $ElectricityDamageType] = 1.0;
$DamageScale[rarmor, $MineDamageType] = 1.2;
$DamageScale[rarmor, $FlashDamageType] = 1.0;
$DamageScale[rarmor, $EMPDamageType] = 1.0;
$DamageScale[rarmor, $EqualizerDamageType] = 1.0;
$DamageScale[rarmor, $ShredderDamageType] = 1.0;
$DamageScale[rarmor, $ShotgunDamageType] = 1.0;
$DamageScale[rarmor, $CannonDamageType] = 1.0;
$DamageScale[rarmor, $BlastDamageType] = 1.0;
$DamageScale[rarmor, $FireDamageType] = 1.0;
$DamageScale[rarmor, $NukeDamageType] = 0;
$ItemMax[rarmor, Blaster] = 1;
$ItemMax[rarmor, Equalizer] = 0;
$ItemMax[rarmor, Disclauncher] = 1;
$ItemMax[rarmor, GrenadeLauncher] = 0;
$ItemMax[rarmor, Mortar] = 0;
$ItemMax[rarmor, SoulStealer] = 0;
$ItemMax[rarmor, EarthquakeCannon] = 0;
$ItemMax[rarmor, PlasmaGun] = 0;
$ItemMax[rarmor, Shotgun] = 0;
$ItemMax[rarmor, BlastLauncher] = 0;
$ItemMax[rarmor, LaserRifle] = 0;
$ItemMax[rarmor, GravityGun] = 0;
$ItemMax[rarmor, SniperRifle] = 0;
$ItemMax[rarmor, TargetingLaser] = 1;
$ItemMax[rarmor, MineAmmo] = 3;
$ItemMax[rarmor, FlagMineAmmo] = 3;
$ItemMax[rarmor, Grenade] = 5;
$ItemMax[rarmor, Beacon]  = 3;
$ItemMax[rarmor, ForceFieldPack] = 0;
$ItemMax[rarmor, LargeFieldPack] = 0;
$ItemMax[rarmor, BulletAmmo] = 100;
$ItemMax[rarmor, PlasmaAmmo] = 30;
$ItemMax[rarmor, DiscAmmo] = 15;
$ItemMax[rarmor, GrenadeAmmo] = 10;
$ItemMax[rarmor, BlastAmmo] = 0;
$ItemMax[rarmor, MortarAmmo] = 10;
$ItemMax[rarmor, SniperAmmo] = 50;
$ItemMax[rarmor, ShotgunShells] = 50;
$ItemMax[rarmor, EnergyPack] = 1;
$ItemMax[rarmor, RepairPack] = 1;
$ItemMax[rarmor, ShieldPack] = 1;
$ItemMax[rarmor, SensorJammerPack] = 1;
$ItemMax[rarmor, MotionSensorPack] = 1;
$ItemMax[rarmor, PulseSensorPack] = 1;
$ItemMax[rarmor, DeployableSensorJammerPack] = 1;
$ItemMax[rarmor, CameraPack] = 1;
$ItemMax[rarmor, TurretPack] = 0;
$ItemMax[rarmor, AmmoPack] = 1;
$ItemMax[rarmor, RepairKit] = 1;
$ItemMax[rarmor, DeployableInvPack] = 0;
$ItemMax[rarmor, DeployableAmmoPack] = 0;
$ItemMax[rarmor, SatCameraPack] = 0;
$ItemMax[rarmor, AirPlatformPack] = 0;
$ItemMax[rarmor, LargeAirPlatPack] = 0;
$ItemMax[rarmor, FalloutCannon] = 1;
$ItemMax[rarmor, NukeAmmo] = 20;
$ItemMax[rarmor, LaserTurretPack] = 0;
$ItemMax[rarmor, CloakGun] = 1; 
$ItemMax[rarmor, LaserShredder] = 0; 
$MaxWeapons[rarmor] = 4;

//----------------------------------------------------------------------------
// Assasin Armor
//----------------------------------------------------------------------------

$DamageScale[aarmor, $LandingDamageType] = 1.0;
$DamageScale[aarmor, $ImpactDamageType] = 1.0;
$DamageScale[aarmor, $CrushDamageType] = 1.0;
$DamageScale[aarmor, $BulletDamageType] = 1.2;
$DamageScale[aarmor, $PlasmaDamageType] = 1.0;
$DamageScale[aarmor, $EnergyDamageType] = 1.3;
$DamageScale[aarmor, $ExplosionDamageType] = 1.0;
$DamageScale[aarmor, $MissileDamageType] = 1.0;
$DamageScale[aarmor, $DebrisDamageType] = 1.2;
$DamageScale[aarmor, $ShrapnelDamageType] = 1.2;
$DamageScale[aarmor, $LaserDamageType] = 1.0;
$DamageScale[aarmor, $MortarDamageType] = 1.3;
$DamageScale[aarmor, $BlasterDamageType] = 1.3;
$DamageScale[aarmor, $ElectricityDamageType] = 1.0;
$DamageScale[aarmor, $MineDamageType] = 1.2;
$DamageScale[aarmor, $FlashDamageType] = 1.0;
$DamageScale[aarmor, $EMPDamageType] = 1.0;
$DamageScale[aarmor, $EqualizerDamageType] = 1.0;
$DamageScale[aarmor, $ShredderDamageType] = 1.0;
$DamageScale[aarmor, $ShotgunDamageType] = 1.0;
$DamageScale[aarmor, $CannonDamageType] = 1.0;
$DamageScale[aarmor, $BlastDamageType] = 1.0;
$DamageScale[aarmor, $FireDamageType] = 1.0;
$DamageScale[aarmor, $NukeDamageType] = 1.0;
$ItemMax[aarmor, Blaster] = 1;
$ItemMax[aarmor, Equalizer] = 0;
$ItemMax[aarmor, Disclauncher] = 1;
$ItemMax[aarmor, GrenadeLauncher] = 0;
$ItemMax[aarmor, Mortar] = 0;
$ItemMax[aarmor, SoulStealer] = 0;
$ItemMax[aarmor, EarthquakeCannon] = 0;
$ItemMax[aarmor, PlasmaGun] = 0;
$ItemMax[aarmor, Shotgun] = 0;
$ItemMax[aarmor, BlastLauncher] = 0;
$ItemMax[aarmor, LaserRifle] = 1;
$ItemMax[aarmor, GravityGun] = 0;
$ItemMax[aarmor, SniperRifle] = 1;
$ItemMax[aarmor, TargetingLaser] = 1;
$ItemMax[aarmor, MineAmmo] = 3;
$ItemMax[aarmor, FlagMineAmmo] = 3;
$ItemMax[aarmor, Grenade] = 5;
$ItemMax[aarmor, Beacon]  = 3;
$ItemMax[aarmor, ForceFieldPack] = 1;
$ItemMax[aarmor, LargeFieldPack] = 1;
$ItemMax[aarmor, BulletAmmo] = 100;
$ItemMax[aarmor, PlasmaAmmo] = 30;
$ItemMax[aarmor, DiscAmmo] = 15;
$ItemMax[aarmor, GrenadeAmmo] = 10;
$ItemMax[aarmor, BlastAmmo] = 0;
$ItemMax[aarmor, MortarAmmo] = 10;
$ItemMax[aarmor, SniperAmmo] = 50;
$ItemMax[aarmor, ShotgunShells] = 50;
$ItemMax[aarmor, EnergyPack] = 1;
$ItemMax[aarmor, RepairPack] = 1;
$ItemMax[aarmor, ShieldPack] = 1;
$ItemMax[aarmor, SensorJammerPack] = 1;
$ItemMax[aarmor, MotionSensorPack] = 1;
$ItemMax[aarmor, PulseSensorPack] = 1;
$ItemMax[aarmor, DeployableSensorJammerPack] = 1;
$ItemMax[aarmor, CameraPack] = 1;
$ItemMax[aarmor, TurretPack] = 0;
$ItemMax[aarmor, AmmoPack] = 1;
$ItemMax[aarmor, RepairKit] = 1;
$ItemMax[aarmor, DeployableInvPack] = 0;
$ItemMax[aarmor, DeployableAmmoPack] = 0;
$ItemMax[aarmor, SatCameraPack] = 1;
$ItemMax[aarmor, AirPlatformPack] = 1;
$ItemMax[aarmor, LargeAirPlatPack] = 1;
$ItemMax[aarmor, FalloutCannon] = 0;
$ItemMax[aarmor, NukeAmmo] = 10;
$ItemMax[aarmor, LaserTurretPack] = 1;
$ItemMax[aarmor, CloakGun] = 0;
$ItemMax[aarmor, LaserShredder] = 1;  
$MaxWeapons[aarmor] = 4;


//----------------------------------------------------------------------------
// Valkyrie Armor
//----------------------------------------------------------------------------
$DamageScale[varmor, $LandingDamageType] = 1.0;
$DamageScale[varmor, $ImpactDamageType] = 1.0;
$DamageScale[varmor, $CrushDamageType] = 1.0;
$DamageScale[varmor, $BulletDamageType] = 1.2;
$DamageScale[varmor, $PlasmaDamageType] = 1.0;
$DamageScale[varmor, $EnergyDamageType] = 1.3;
$DamageScale[varmor, $ExplosionDamageType] = 1.0;
$DamageScale[varmor, $MissileDamageType] = 1.0;
$DamageScale[varmor, $DebrisDamageType] = 1.2;
$DamageScale[varmor, $ShrapnelDamageType] = 1.2;
$DamageScale[varmor, $LaserDamageType] = 1.0;
$DamageScale[varmor, $MortarDamageType] = 1.3;
$DamageScale[varmor, $BlasterDamageType] = 1.3;
$DamageScale[varmor, $ElectricityDamageType] = 1.0;
$DamageScale[varmor, $MineDamageType] = 1.2;
$DamageScale[varmor, $FlashDamageType] = 1.0;
$DamageScale[varmor, $EMPDamageType] = 1.0;
$DamageScale[varmor, $EqualizerDamageType] = 1.0;
$DamageScale[varmor, $ShredderDamageType] = 1.0;
$DamageScale[varmor, $ShotgunDamageType] = 1.0;
$DamageScale[varmor, $CannonDamageType] = 1.0;
$DamageScale[varmor, $BlastDamageType] = 1.0;
$DamageScale[varmor, $FireDamageType] = 1.0;
$DamageScale[varmor, $NukeDamageType] = 1.0;
$ItemMax[varmor, Blaster] = 1;
$ItemMax[varmor, Equalizer] = 1;
$ItemMax[varmor, Disclauncher] = 1;
$ItemMax[varmor, GrenadeLauncher] = 1;
$ItemMax[varmor, Mortar] = 0;
$ItemMax[varmor, SoulStealer] = 0;
$ItemMax[varmor, EarthquakeCannon] = 0;
$ItemMax[varmor, PlasmaGun] = 1;
$ItemMax[varmor, Shotgun] = 1;
$ItemMax[varmor, BlastLauncher] = 0;
$ItemMax[varmor, LaserRifle] = 0;
$ItemMax[varmor, GravityGun] = 0;
$ItemMax[varmor, SniperRifle] = 0;
$ItemMax[varmor, TargetingLaser] = 1;
$ItemMax[varmor, MineAmmo] = 3;
$ItemMax[varmor, FlagMineAmmo] = 3;
$ItemMax[varmor, Grenade] = 5;
$ItemMax[varmor, Beacon]  = 3;
$ItemMax[varmor, ForceFieldPack] = 1;
$ItemMax[varmor, LargeFieldPack] = 1;
$ItemMax[varmor, BulletAmmo] = 100;
$ItemMax[varmor, PlasmaAmmo] = 30;
$ItemMax[varmor, DiscAmmo] = 15;
$ItemMax[varmor, GrenadeAmmo] = 10;
$ItemMax[varmor, BlastAmmo] = 0;
$ItemMax[varmor, MortarAmmo] = 10;
$ItemMax[varmor, SniperAmmo] = 50;
$ItemMax[varmor, ShotgunShells] = 50;
$ItemMax[varmor, EnergyPack] = 1;
$ItemMax[varmor, RepairPack] = 1;
$ItemMax[varmor, ShieldPack] = 1;
$ItemMax[varmor, SensorJammerPack] = 1;
$ItemMax[varmor, MotionSensorPack] = 1;
$ItemMax[varmor, PulseSensorPack] = 1;
$ItemMax[varmor, DeployableSensorJammerPack] = 1;
$ItemMax[varmor, CameraPack] = 1;
$ItemMax[varmor, TurretPack] = 0;
$ItemMax[varmor, AmmoPack] = 1;
$ItemMax[varmor, RepairKit] = 1;
$ItemMax[varmor, DeployableInvPack] = 0;
$ItemMax[varmor, DeployableAmmoPack] = 0;
$ItemMax[varmor, SatCameraPack] = 1;
$ItemMax[varmor, AirPlatformPack] = 1;
$ItemMax[varmor, LargeAirPlatPack] = 1;
$ItemMax[varmor, FalloutCannon] = 0;
$ItemMax[varmor, NukeAmmo] = 10;
$ItemMax[varmor, LaserTurretPack] = 1;
$ItemMax[varmor, CloakGun] = 0; 
$ItemMax[varmor, LaserShredder] = 1; 
$MaxWeapons[varmor] = 6;

//----------------------------------------------------------------------------
// Devastator Armor
//----------------------------------------------------------------------------
$DamageScale[darmor, $LandingDamageType] = 1.0;
$DamageScale[darmor, $ImpactDamageType] = 1.0;
$DamageScale[darmor, $CrushDamageType] = 1.0;
$DamageScale[darmor, $BulletDamageType] = 1.2;
$DamageScale[darmor, $PlasmaDamageType] = 1.0;
$DamageScale[darmor, $EnergyDamageType] = 1.3;
$DamageScale[darmor, $ExplosionDamageType] = 1.0;
$DamageScale[darmor, $MissileDamageType] = 1.0;
$DamageScale[darmor, $DebrisDamageType] = 1.2;
$DamageScale[darmor, $ShrapnelDamageType] = 1.2;
$DamageScale[darmor, $LaserDamageType] = 1.0;
$DamageScale[darmor, $MortarDamageType] = 1.3;
$DamageScale[darmor, $BlasterDamageType] = 1.3;
$DamageScale[darmor, $ElectricityDamageType] = 1.0;
$DamageScale[darmor, $MineDamageType] = 1.2;
$DamageScale[darmor, $FlashDamageType] = 1.0;
$DamageScale[darmor, $EMPDamageType] = 1.0;
$DamageScale[darmor, $EqualizerDamageType] = 1.0;
$DamageScale[darmor, $ShredderDamageType] = 1.0;
$DamageScale[darmor, $ShotgunDamageType] = 1.0;
$DamageScale[darmor, $CannonDamageType] = 1.0;
$DamageScale[darmor, $BlastDamageType] = 1.0;
$DamageScale[darmor, $FireDamageType] = 1.0;
$DamageScale[darmor, $NukeDamageType] = 1.0;
$ItemMax[darmor, Blaster] = 1;
$ItemMax[darmor, Equalizer] = 1;
$ItemMax[darmor, Disclauncher] = 1;
$ItemMax[darmor, GrenadeLauncher] = 1;
$ItemMax[darmor, Mortar] = 1;
$ItemMax[darmor, SoulStealer] = 1;
$ItemMax[darmor, EarthquakeCannon] = 1;
$ItemMax[darmor, PlasmaGun] = 1;
$ItemMax[darmor, Shotgun] = 1;
$ItemMax[darmor, BlastLauncher] = 1;
$ItemMax[darmor, LaserRifle] = 0;
$ItemMax[darmor, GravityGun] = 0;
$ItemMax[darmor, SniperRifle] = 0;
$ItemMax[darmor, TargetingLaser] = 1;
$ItemMax[darmor, MineAmmo] = 3;
$ItemMax[darmor, FlagMineAmmo] = 3;
$ItemMax[darmor, Grenade] = 5;
$ItemMax[darmor, Beacon]  = 3;
$ItemMax[darmor, ForceFieldPack] = 1;
$ItemMax[darmor, LargeFieldPack] = 1;
$ItemMax[darmor, BulletAmmo] = 100;
$ItemMax[darmor, PlasmaAmmo] = 30;
$ItemMax[darmor, DiscAmmo] = 15;
$ItemMax[darmor, GrenadeAmmo] = 10;
$ItemMax[darmor, ShockAmmo] = 10;
$ItemMax[darmor, BlastAmmo] = 10;
$ItemMax[darmor, MortarAmmo] = 10;
$ItemMax[darmor, SniperAmmo] = 50;
$ItemMax[darmor, ShotgunShells] = 50;
$ItemMax[darmor, EnergyPack] = 1;
$ItemMax[darmor, RepairPack] = 1;
$ItemMax[darmor, ShieldPack] = 1;
$ItemMax[darmor, SensorJammerPack] = 1;
$ItemMax[darmor, MotionSensorPack] = 1;
$ItemMax[darmor, PulseSensorPack] = 1;
$ItemMax[darmor, DeployableSensorJammerPack] = 1;
$ItemMax[darmor, CameraPack] = 1;
$ItemMax[darmor, TurretPack] = 1;
$ItemMax[darmor, AmmoPack] = 1;
$ItemMax[darmor, RepairKit] = 1;
$ItemMax[darmor, DeployableInvPack] = 1;
$ItemMax[darmor, DeployableAmmoPack] = 1;
$ItemMax[darmor, SatCameraPack] = 1;
$ItemMax[darmor, AirPlatformPack] = 1;
$ItemMax[darmor, LargeAirPlatPack] = 1;
$ItemMax[darmor, FalloutCannon] = 0;
$ItemMax[darmor, NukeAmmo] = 10;
$ItemMax[darmor, LaserTurretPack] = 1;
$ItemMax[darmor, CloakGun] = 0; 
$ItemMax[darmor, LaserShredder] = 0; 
$MaxWeapons[darmor] = 7;

//----------------------------------------------------------------------------
// Colossus Armor
//----------------------------------------------------------------------------
$DamageScale[carmor, $LandingDamageType] = 1.0;
$DamageScale[carmor, $ImpactDamageType] = 1.0;
$DamageScale[carmor, $CrushDamageType] = 1.0;
$DamageScale[carmor, $BulletDamageType] = 1.2;
$DamageScale[carmor, $PlasmaDamageType] = 1.0;
$DamageScale[carmor, $EnergyDamageType] = 1.3;
$DamageScale[carmor, $ExplosionDamageType] = 1.0;
$DamageScale[carmor, $MissileDamageType] = 1.0;
$DamageScale[carmor, $DebrisDamageType] = 1.2;
$DamageScale[carmor, $ShrapnelDamageType] = 1.2;
$DamageScale[carmor, $LaserDamageType] = 1.0;
$DamageScale[carmor, $MortarDamageType] = 1.3;
$DamageScale[carmor, $BlasterDamageType] = 1.3;
$DamageScale[carmor, $ElectricityDamageType] = 1.0;
$DamageScale[carmor, $MineDamageType] = 1.2;
$DamageScale[carmor, $FlashDamageType] = 1.0;
$DamageScale[carmor, $EMPDamageType] = 1.0;
$DamageScale[carmor, $EqualizerDamageType] = 1.0;
$DamageScale[carmor, $ShredderDamageType] = 1.0;
$DamageScale[carmor, $ShotgunDamageType] = 1.0;
$DamageScale[carmor, $CannonDamageType] = 1.0;
$DamageScale[carmor, $BlastDamageType] = 1.0;
$DamageScale[carmor, $FireDamageType] = 1.0;
$DamageScale[carmor, $NukeDamageType] = 1.0;
$ItemMax[carmor, Blaster] = 1;
$ItemMax[carmor, Equalizer] = 1;
$ItemMax[carmor, Disclauncher] = 1;
$ItemMax[carmor, GrenadeLauncher] = 1;
$ItemMax[carmor, Mortar] = 1;
$ItemMax[carmor, SoulStealer] = 1;
$ItemMax[carmor, EarthquakeCannon] = 1;
$ItemMax[carmor, PlasmaGun] = 1;
$ItemMax[carmor, Shotgun] = 1;
$ItemMax[carmor, BlastLauncher] = 1;
$ItemMax[carmor, LaserRifle] = 0;
$ItemMax[carmor, GravityGun] = 0;
$ItemMax[carmor, SniperRifle] = 0;
$ItemMax[carmor, TargetingLaser] = 1;
$ItemMax[carmor, MineAmmo] = 3;
$ItemMax[carmor, FlagMineAmmo] = 3;
$ItemMax[carmor, Grenade] = 5;
$ItemMax[carmor, Beacon]  = 3;
$ItemMax[carmor, ForceFieldPack] = 1;
$ItemMax[carmor, LargeFieldPack] = 1;
$ItemMax[carmor, BulletAmmo] = 100;
$ItemMax[carmor, PlasmaAmmo] = 30;
$ItemMax[carmor, DiscAmmo] = 15;
$ItemMax[carmor, GrenadeAmmo] = 10;
$ItemMax[carmor, ShockAmmo] = 10;
$ItemMax[carmor, BlastAmmo] = 20;
$ItemMax[carmor, MortarAmmo] = 20;
$ItemMax[carmor, SniperAmmo] = 50;
$ItemMax[carmor, ShotgunShells] = 50;
$ItemMax[carmor, EnergyPack] = 1;
$ItemMax[carmor, RepairPack] = 1;
$ItemMax[carmor, ShieldPack] = 1;
$ItemMax[carmor, SensorJammerPack] = 1;
$ItemMax[carmor, MotionSensorPack] = 1;
$ItemMax[carmor, PulseSensorPack] = 1;
$ItemMax[carmor, DeployableSensorJammerPack] = 1;
$ItemMax[carmor, CameraPack] = 1;
$ItemMax[carmor, TurretPack] = 1;
$ItemMax[carmor, AmmoPack] = 1;
$ItemMax[carmor, RepairKit] = 1;
$ItemMax[carmor, DeployableInvPack] = 1;
$ItemMax[carmor, DeployableAmmoPack] = 1;
$ItemMax[carmor, SatCameraPack] = 1;
$ItemMax[carmor, AirPlatformPack] = 1;
$ItemMax[carmor, LargeAirPlatPack] = 1;
$ItemMax[carmor, FalloutCannon] = 0;
$ItemMax[carmor, NukeAmmo] = 10;
$ItemMax[carmor, LaserTurretPack] = 1;
$ItemMax[carmor, CloakGun] = 1; 
$MaxWeapons[carmor] = 9;

//----------------------------------------------------------------------------
// Resistor Female Armor
//----------------------------------------------------------------------------

$DamageScale[frearmor, $LandingDamageType] = 1.0;
$DamageScale[frearmor, $ImpactDamageType] = 1.0;
$DamageScale[frearmor, $CrushDamageType] = 1.0;
$DamageScale[frearmor, $BulletDamageType] = 1.2;
$DamageScale[frearmor, $PlasmaDamageType] = 1.0;
$DamageScale[frearmor, $EnergyDamageType] = 1.3;
$DamageScale[frearmor, $ExplosionDamageType] = 1.0;
$DamageScale[frearmor, $MissileDamageType] = 1.0;
$DamageScale[frearmor, $DebrisDamageType] = 1.2;
$DamageScale[frearmor, $ShrapnelDamageType] = 1.2;
$DamageScale[frearmor, $LaserDamageType] = 1.0;
$DamageScale[frearmor, $MortarDamageType] = 1.3;
$DamageScale[frearmor, $BlasterDamageType] = 1.3;
$DamageScale[frearmor, $ElectricityDamageType] = 1.0;
$DamageScale[frearmor, $MineDamageType] = 1.2;
$DamageScale[frearmor, $FlashDamageType] = 1.0;
$DamageScale[frearmor, $EMPDamageType] = 1.0;
$DamageScale[frearmor, $EqualizerDamageType] = 1.0;
$DamageScale[frearmor, $ShredderDamageType] = 1.0;
$DamageScale[frearmor, $ShotgunDamageType] = 1.0;
$DamageScale[frearmor, $CannonDamageType] = 1.0;
$DamageScale[frearmor, $BlastDamageType] = 1.0;
$DamageScale[frearmor, $FireDamageType] = 1.0;
$DamageScale[frearmor, $NukeDamageType] = 1.0;
$ItemMax[frearmor, Blaster] = 1;
$ItemMax[frearmor, Equalizer] = 0;
$ItemMax[frearmor, Disclauncher] = 1;
$ItemMax[frearmor, GrenadeLauncher] = 0;
$ItemMax[frearmor, Mortar] = 0;
$ItemMax[frearmor, SoulStealer] = 0;
$ItemMax[frearmor, EarthquakeCannon] = 0;
$ItemMax[frearmor, PlasmaGun] = 1;
$ItemMax[frearmor, Shotgun] = 0;
$ItemMax[frearmor, BlastLauncher] = 0;
$ItemMax[frearmor, LaserRifle] = 0;
$ItemMax[frearmor, GravityGun] = 0;
$ItemMax[frearmor, SniperRifle] = 0;
$ItemMax[frearmor, TargetingLaser] = 1;
$ItemMax[frearmor, MineAmmo] = 3;
$ItemMax[frearmor, FlagMineAmmo] = 3;
$ItemMax[frearmor, Grenade] = 5;
$ItemMax[frearmor, Beacon]  = 3;
$ItemMax[frearmor, ForceFieldPack] = 0;
$ItemMax[frearmor, LargeFieldPack] = 0;
$ItemMax[frearmor, BulletAmmo] = 100;
$ItemMax[frearmor, PlasmaAmmo] = 30;
$ItemMax[frearmor, DiscAmmo] = 15;
$ItemMax[frearmor, GrenadeAmmo] = 10;
$ItemMax[frearmor, BlastAmmo] = 0;
$ItemMax[frearmor, MortarAmmo] = 10;
$ItemMax[frearmor, SniperAmmo] = 50;
$ItemMax[frearmor, ShotgunShells] = 50;
$ItemMax[frearmor, EnergyPack] = 1;
$ItemMax[frearmor, RepairPack] = 1;
$ItemMax[frearmor, ShieldPack] = 1;
$ItemMax[frearmor, SensorJammerPack] = 1;
$ItemMax[frearmor, MotionSensorPack] = 1;
$ItemMax[frearmor, PulseSensorPack] = 1;
$ItemMax[frearmor, DeployableSensorJammerPack] = 1;
$ItemMax[frearmor, CameraPack] = 1;
$ItemMax[frearmor, TurretPack] = 0;
$ItemMax[frearmor, AmmoPack] = 1;
$ItemMax[frearmor, RepairKit] = 1;
$ItemMax[frearmor, DeployableInvPack] = 0;
$ItemMax[frearmor, DeployableAmmoPack] = 0;
$ItemMax[frearmor, SatCameraPack] = 0;
$ItemMax[frearmor, AirPlatformPack] = 0;
$ItemMax[frearmor, LargeAirPlatPack] = 0;
$ItemMax[frearmor, FalloutCannon] = 0;
$ItemMax[frearmor, NukeAmmo] = 10;
$ItemMax[frearmor, LaserTurretPack] = 0;
$ItemMax[frearmor, CloakGun] = 0; 
$MaxWeapons[frearmor] = 4;

//----------------------------------------------------------------------------
// Assasin Female Armor
//----------------------------------------------------------------------------

$DamageScale[faarmor, $LandingDamageType] = 1.0;
$DamageScale[faarmor, $ImpactDamageType] = 1.0;
$DamageScale[faarmor, $CrushDamageType] = 1.0;
$DamageScale[faarmor, $BulletDamageType] = 1.2;
$DamageScale[faarmor, $PlasmaDamageType] = 1.0;
$DamageScale[faarmor, $EnergyDamageType] = 1.3;
$DamageScale[faarmor, $ExplosionDamageType] = 1.0;
$DamageScale[faarmor, $MissileDamageType] = 1.0;
$DamageScale[faarmor, $DebrisDamageType] = 1.2;
$DamageScale[faarmor, $ShrapnelDamageType] = 1.2;
$DamageScale[faarmor, $LaserDamageType] = 1.0;
$DamageScale[faarmor, $MortarDamageType] = 1.3;
$DamageScale[faarmor, $BlasterDamageType] = 1.3;
$DamageScale[faarmor, $ElectricityDamageType] = 1.0;
$DamageScale[faarmor, $MineDamageType] = 1.2;
$DamageScale[faarmor, $FlashDamageType] = 1.0;
$DamageScale[faarmor, $EMPDamageType] = 1.0;
$DamageScale[faarmor, $EqualizerDamageType] = 1.0;
$DamageScale[faarmor, $ShredderDamageType] = 1.0;
$DamageScale[faarmor, $ShotgunDamageType] = 1.0;
$DamageScale[faarmor, $CannonDamageType] = 1.0;
$DamageScale[faarmor, $BlastDamageType] = 1.0;
$DamageScale[faarmor, $FireDamageType] = 1.0;
$DamageScale[faarmor, $NukeDamageType] = 1.0;
$ItemMax[faarmor, Blaster] = 1;
$ItemMax[faarmor, Equalizer] = 0;
$ItemMax[faarmor, Disclauncher] = 1;
$ItemMax[faarmor, GrenadeLauncher] = 0;
$ItemMax[faarmor, Mortar] = 0;
$ItemMax[faarmor, SoulStealer] = 0;
$ItemMax[faarmor, EarthquakeCannon] = 0;
$ItemMax[faarmor, PlasmaGun] = 0;
$ItemMax[faarmor, Shotgun] = 0;
$ItemMax[faarmor, BlastLauncher] = 0;
$ItemMax[faarmor, LaserRifle] = 1;
$ItemMax[faarmor, GravityGun] = 0;
$ItemMax[faarmor, SniperRifle] = 1;
$ItemMax[faarmor, TargetingLaser] = 1;
$ItemMax[faarmor, MineAmmo] = 3;
$ItemMax[faarmor, FlagMineAmmo] = 3;
$ItemMax[faarmor, Grenade] = 5;
$ItemMax[faarmor, Beacon]  = 3;
$ItemMax[faarmor, ForceFieldPack] = 1;
$ItemMax[faarmor, LargeFieldPack] = 1;
$ItemMax[faarmor, BulletAmmo] = 100;
$ItemMax[faarmor, PlasmaAmmo] = 30;
$ItemMax[faarmor, DiscAmmo] = 15;
$ItemMax[faarmor, GrenadeAmmo] = 10;
$ItemMax[faarmor, BlastAmmo] = 0;
$ItemMax[faarmor, MortarAmmo] = 10;
$ItemMax[faarmor, SniperAmmo] = 50;
$ItemMax[faarmor, ShotgunShells] = 50;
$ItemMax[faarmor, EnergyPack] = 1;
$ItemMax[faarmor, RepairPack] = 1;
$ItemMax[faarmor, ShieldPack] = 1;
$ItemMax[faarmor, SensorJammerPack] = 1;
$ItemMax[faarmor, MotionSensorPack] = 1;
$ItemMax[faarmor, PulseSensorPack] = 1;
$ItemMax[faarmor, DeployableSensorJammerPack] = 1;
$ItemMax[faarmor, CameraPack] = 1;
$ItemMax[faarmor, TurretPack] = 0;
$ItemMax[faarmor, AmmoPack] = 1;
$ItemMax[faarmor, RepairKit] = 1;
$ItemMax[faarmor, DeployableInvPack] = 0;
$ItemMax[faarmor, DeployableAmmoPack] = 0;
$ItemMax[faarmor, SatCameraPack] = 1;
$ItemMax[faarmor, AirPlatformPack] = 1;
$ItemMax[faarmor, LargeAirPlatPack] = 1;
$ItemMax[faarmor, FalloutCannon] = 0;
$ItemMax[faarmor, NukeAmmo] = 10;
$ItemMax[faarmor, LaserTurretPack] = 1;
$ItemMax[faarmor, CloakGun] = 0; 
$MaxWeapons[faarmor] = 4;

//------------------------------------------------------------------
// resitor armor data:
//------------------------------------------------------------------

DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};

PlayerData rearmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 1.0;
   maxJetForwardVelocity = 30;
   minJetEnergy = 1;
   jetForce = 250;
   jetEnergyDrain = 0.7;

	maxDamage = 0.50;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 13;
   maxSideSpeed = 12;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 6.0;
	maxEnergy = 70;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 90;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// resitor female armor data:
//------------------------------------------------------------------

PlayerData frearmor
{
   className = "Armor";
   shapeFile = "lfemale";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 1.0;
   maxJetForwardVelocity = 30;
   minJetEnergy = 1;
   jetForce = 250;
   jetEnergyDrain = 0.7;

	maxDamage = 0.50;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 13;
   maxSideSpeed = 12;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 6.0;
	maxEnergy = 70;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 90;
   jumpSurfaceMinDot = 0.2;


   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// assasin armor data:
//------------------------------------------------------------------

PlayerData aarmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 26;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.7;

	maxDamage = 0.66;
   maxForwardSpeed = 13;
   maxBackwardSpeed = 11;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 5.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// assasin female armor data:
//------------------------------------------------------------------

PlayerData faarmor
{
   className = "Armor";
   shapeFile = "lfemale";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 26;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.7;

	maxDamage = 0.66;
   maxForwardSpeed = 13;
   maxBackwardSpeed = 11;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 5.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// valkyrie Armor data:
//------------------------------------------------------------------

PlayerData varmor
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.0;
   maxForwardSpeed = 11.0;
   maxBackwardSpeed = 8.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 5.0;
	
	maxEnergy = 80;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 120;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// radcon Armor data:
//------------------------------------------------------------------

PlayerData rarmor
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.0;
   maxForwardSpeed = 10.0;
   maxBackwardSpeed = 8.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 4.0;
	
	maxEnergy = 80;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// colossus Armor data:
//------------------------------------------------------------------

PlayerData carmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 15;
   minJetEnergy = 1;
   jetForce = 385;
   jetEnergyDrain = 0.8;

	maxDamage = 2.0;
   maxForwardSpeed = 5.0;
   maxBackwardSpeed = 3.0;
   maxSideSpeed = 3.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 20.0;
	maxEnergy = 130;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// devastator Armor data:
//------------------------------------------------------------------

PlayerData darmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 15;
   minJetEnergy = 1;
   jetForce = 385;
   jetEnergyDrain = 0.8;

	maxDamage = 1.32;
   maxForwardSpeed = 7.0;
   maxBackwardSpeed = 5.0;
   maxSideSpeed = 4.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 110;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};


//------------------------------------------------------------------
//
//------------------------------------------------------------------







