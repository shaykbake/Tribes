EditActionMap("playMap.sae");
bindCommand(keyboard0, make, "b", TO, "remoteEval(2048,UseSpecial);");
bindCommand(keyboard0, make, "f", TO, "remoteEval(2048,WeaponModeNext);");
