**************************************
	Tribal Combat
	Install Notes
**************************************

----------
Installing
----------
Extract all the files with folders into your Tribes directory. There should now
be a folder called Combat in the Tribes directory. DO NOT extract these files to any other place!

Inside the Combat folder should be the scripts.vol and a folder called Missions. Inside the 
Missions folder should be various files with a .mis extension and other files with a .dsc extension.

In your Tribes\config folder there should now be a file named combatConfig.cs and a file named combatServerCfg.cs

All is well if the above is true.

---------------------
Running TRIBAL COMBAT
---------------------
You may simply log on to any server that is running this MOD, but in order to use the
weapon mode selection keys, you must enable the combatConfig.cs script.

To do so, you should add this line to your autoexec.cs file located in the Tribes\config folder:

exec(combatConfig);

Keys F11 and F12 will cycle through the weapon modes. Currently there are only two modes.
The speical key has been disabled in this version, and BEACONS preform this function. And the Kneel
key is currently bound to "c". You may change any of these keys to your preference by editing the
combatConfig.cs file.

If you do not have an autoexec.cs file, then simply create a new text file, and rename it autoexec.cs
( the extension MUST be .cs and not .txt ).

-------
Hosting
-------
To host a server with this MOD. Create a shortcut to Tribes. Edit the shortcut properties, and remove
any quotes it may have added to the path. Then add this line to the end of the shortcut:

+exec combatServerCfg -mod combat

Save these changes to the shortcut, and launch.

----------------
Dedicated Server
----------------
To run a dedicated server:

Create a new shortcut to InfiniteSpawn.exe located in your Tribes directory.

Add this line EXACTLY to the end of the path

*tribes +exec combatServerCfg -mod StrategicCombat -dedicated

Please do NOT use any admin scripts while running this MOD. This MOD is not compatable with other admin scripts.

-------------
Notes on Maps
-------------
The COMBAT maps have been edited to allow the use of anti-TK TRAITOR code. No original Tribes map
supports the TRAITOR team. All Anti-TK on original maps will simply result in a kick.

The OPEN CALL maps are NOT fully compatible with COMBAT. This is due to an oversight by the Dev
Team in naming the mission type. There is no easy way to determine the mission type of an open
call map. Thereby, certain effects will act buggy on these maps. Namely the truce code. The Dev
Team should have been more careful with the mission type names.

-------------------
Using other scripts
-------------------
It is NOT recommended to mix and match Tribes Scripts. Unless two scripts have been coordinated with each
other, they can not be guaranteed to work well together.

In particular, DO NOT RUN ANY ADMIN SCRIPT WITH THIS MOD!!! I have coded all the Admin features myself without
bothering to even look at the code of say, IXAdmin. There will be conflict and crashes if you do not heed this
warning! I stress, DO NOT use any other admin script with this MOD. There is absolutely no need for such actions
anyway, as all the admin code needed for this MOD is already there or in the works.

==========
DISCLAIMER
==========
I except NO responsibility should you fail to understand nor follow these instructions exactly. Any apparent
harm done to your computer in any way is your fault, and nothing within this MOD is capable of rendering
any wrong doing to your computer hardware nor software. If you screw up your system, its your fault, not mine. Please do not even attempt to use this MOD if you do not understand how computer systems function. Failure to 
read this disclaimer before installing the MOD does not exempt you in any way. 