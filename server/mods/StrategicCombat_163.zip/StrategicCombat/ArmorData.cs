//------------
// Light Armor
//------------

$DamageScale[larmor, $LandingDamageType] = 1.0;
$DamageScale[larmor, $ImpactDamageType] = 1.0;
$DamageScale[larmor, $CrushDamageType] = 1.1;
$DamageScale[larmor, $BulletDamageType] = 1.0;
$DamageScale[larmor, $PlasmaDamageType] = 1.1;
$DamageScale[larmor, $EnergyDamageType] = 1.1;
$DamageScale[larmor, $ExplosionDamageType] = 1.1;
$DamageScale[larmor, $MissileDamageType] = 1.1;
$DamageScale[larmor, $DebrisDamageType] = 1.3;
$DamageScale[larmor, $ShrapnelDamageType] = 1.3;
$DamageScale[larmor, $LaserDamageType] = 0.85;
$DamageScale[larmor, $MortarDamageType] = 1.4;
$DamageScale[larmor, $BlasterDamageType] = 1.3;
$DamageScale[larmor, $ElectricityDamageType] = 1.1;
$DamageScale[larmor, $MineDamageType] = 1.2;
$DamageScale[larmor, $DrainDamageType] = 1.0;

$ItemMax[larmor, Blaster] = 1;
$ItemMax[larmor, EDGun] = 1;
$ItemMax[larmor, GaussRifle] = 0;
$ItemMax[larmor, SilencedPistol] = 1;
$ItemMax[larmor, SniperRifle] = 0;
$ItemMax[larmor, AssaultRifle] = 0;
$ItemMax[larmor, Chaingun] = 0;
$ItemMax[larmor, AutoCannon] = 0;
$ItemMax[larmor, Disclauncher] = 1;
$ItemMax[larmor, KineticRifle] = 0;
$ItemMax[larmor, GrenadeLauncher] = 0;
$ItemMax[larmor, Mortar] = 0;
$ItemMax[larmor, RocketLauncher] = 0;
$ItemMax[larmor, MissileLauncher] = 1;
$ItemMax[larmor, PlasmaGun] = 1;
$ItemMax[larmor, PlasmaRepeater] = 0;
$ItemMax[larmor, EnergyCannon] = 0;
$ItemMax[larmor, LaserRifle] = 1;
$ItemMax[larmor, EnergyRifle] = 1;
$ItemMax[larmor, TransferGun] = 1;
$ItemMax[larmor, FieldRepairGun] = 0;
$ItemMax[larmor, DemoCharge] = 1;
$ItemMax[larmor, TargetingLaser] = 1;
$ItemMax[larmor, MineAmmo] = 2;
$ItemMax[larmor, Grenade] = 3;
$ItemMax[larmor, Beacon]  = 2;

$ItemMax[larmor, FusionPack] = 80;
$ItemMax[larmor, GaussAmmo] = 10;
$ItemMax[larmor, ARAmmo] = 0;
$ItemMax[larmor, PistolAmmo] = 40;
$ItemMax[larmor, SniperAmmo] = 20;
$ItemMax[larmor, HvyBulletAmmo] = 80;
$ItemMax[larmor, PlasmaAmmo] = 30;
$ItemMax[larmor, FThrowerAmmo] = 0;
$ItemMax[larmor, DiscAmmo] = 15;
$ItemMax[larmor, GrenadeAmmo] = 15;
$ItemMax[larmor, MortarAmmo] = 10;
$ItemMax[larmor, RLAmmo] = 3;
$ItemMax[larmor, MLAmmo] = 1;
$ItemMax[larmor, ACAmmo] = 25;
$ItemMax[larmor, KineticAmmo] = 25;

$ItemMax[larmor, EnergyPack] = 1;
$ItemMax[larmor, RepairPack] = 1;
$ItemMax[larmor, ShieldPack] = 1;
$ItemMax[larmor, SensorJammerPack] = 1;
$ItemMax[larmor, StealthPack] = 1;
$ItemMax[larmor, ComPack] = 1;
$ItemMax[larmor, TelePack] = 1;
$ItemMax[larmor, VehicleRepairPack] = 1;
$ItemMax[larmor, DetPack] = 1;
$ItemMax[larmor, DronePack] = 1;
$ItemMax[larmor, GuidedBombPack] = 0;
$ItemMax[larmor, SurveyDronePack] = 1;
$ItemMax[larmor, AttackDronePack] = 0;
$ItemMax[larmor, RelocatePack] = 0;
$ItemMax[larmor, CoolantPack] = 0;

$ItemMax[larmor, MotionSensorPack] = 1;
$ItemMax[larmor, PulseSensorPack] = 1;
$ItemMax[larmor, DGNPack] = 1;
$ItemMax[larmor, DeployableSensorJammerPack] = 1;
$ItemMax[larmor, CameraPack] = 1;
$ItemMax[larmor, TurretPack] = 0;
$ItemMax[larmor, LaserTurretPack] = 0;
$ItemMax[larmor, AmmoPack] = 1;
$ItemMax[larmor, RepairKit] = 1;
$ItemMax[larmor, DeployableInvPack] = 0;
$ItemMax[larmor, DeployableAmmoPack] = 0;
$ItemMax[larmor, ForceScreen] = 0;
$ItemMax[larmor, Barricade] = 0;
$ItemMax[larmor, TeleportField] = 0;
$ItemMax[larmor, TeleportPad] = 0;
$ItemMax[larmor, ChaingunTurret] = 0;
$ItemMax[larmor, RemoteAutoCannon] = 0;
$ItemMax[larmor, RemoteAACannon] = 0;
$ItemMax[larmor, RemotePlasmaTurret] = 0;
$ItemMax[larmor, MissileTurret] = 0;
$ItemMax[larmor, RemoteELF] = 0;
$ItemMax[larmor, StealthMine] = 0;
$ItemMax[larmor, AntiArmorMine] = 0;

$ItemMax[larmor, EMPBeaconPack] = 0;
$ItemMax[larmor, PowerGeneratorPack] = 0;
$ItemMax[larmor, ShieldBeaconPack] = 0;
$ItemMax[larmor, EmplacementPack] = 0;
$ItemMax[larmor, PortInvPack] = 0;


$MaxWeapons[larmor] = 3;

//************
//Combat Armor
//************
$DamageScale[carmor, $LandingDamageType] = 0.8;
$DamageScale[carmor, $ImpactDamageType] = 0.8;
$DamageScale[carmor, $CrushDamageType] = 1.0;
$DamageScale[carmor, $BulletDamageType] = 0.8;
$DamageScale[carmor, $PlasmaDamageType] = 0.7;
$DamageScale[carmor, $EnergyDamageType] = 0.8;
$DamageScale[carmor, $ExplosionDamageType] = 1.0;
$DamageScale[carmor, $MissileDamageType] = 1.0;
$DamageScale[carmor, $DebrisDamageType] = 1.0;
$DamageScale[carmor, $ShrapnelDamageType] = 1.0;
$DamageScale[carmor, $LaserDamageType] = 0.75;
$DamageScale[carmor, $MortarDamageType] = 1.0;
$DamageScale[carmor, $BlasterDamageType] = 0.8;
$DamageScale[carmor, $ElectricityDamageType] = 1.0;
$DamageScale[carmor, $MineDamageType] = 1.0;
$DamageScale[carmor, $DrainDamageType] = 1.0;

$ItemMax[carmor, Blaster] = 1;
$ItemMax[carmor, EDGun] = 0;
$ItemMax[carmor, GaussRifle] = 0;
$ItemMax[carmor, SilencedPistol] = 0;
$ItemMax[carmor, SniperRifle] = 1;
$ItemMax[carmor, AssaultRifle] = 1;
$ItemMax[carmor, Chaingun] = 1;
$ItemMax[carmor, AutoCannon] = 0;
$ItemMax[carmor, Disclauncher] = 1;
$ItemMax[carmor, KineticRifle] = 0;
$ItemMax[carmor, GrenadeLauncher] = 1;
$ItemMax[carmor, Mortar] = 0;
$ItemMax[carmor, RocketLauncher] = 0;
$ItemMax[carmor, MissileLauncher] = 1;
$ItemMax[carmor, PlasmaGun] = 1;
$ItemMax[carmor, PlasmaRepeater] = 1;
$ItemMax[carmor, EnergyCannon] = 0;
$ItemMax[carmor, LaserRifle] = 0;
$ItemMax[carmor, EnergyRifle] = 1;
$ItemMax[carmor, TransferGun] = 1;
$ItemMax[carmor, FieldRepairGun] = 0;
$ItemMax[carmor, DemoCharge] = 1;
$ItemMax[carmor, TargetingLaser] = 1;
$ItemMax[carmor, MineAmmo] = 3;
$ItemMax[carmor, Grenade] = 5;
$ItemMax[carmor, Beacon]  = 2;

$ItemMax[carmor, FusionPack] = 100;
$ItemMax[carmor, GaussAmmo] = 0;
$ItemMax[carmor, ARAmmo] = 60;
$ItemMax[carmor, PistolAmmo] = 0;
$ItemMax[carmor, SniperAmmo] = 30;
$ItemMax[carmor, HvyBulletAmmo] = 80;
$ItemMax[carmor, PlasmaAmmo] = 40;
$ItemMax[carmor, FThrowerAmmo] = 40;
$ItemMax[carmor, DiscAmmo] = 30;
$ItemMax[carmor, GrenadeAmmo] = 20;
$ItemMax[carmor, MortarAmmo] = 0;
$ItemMax[carmor, RLAmmo] = 3;
$ItemMax[carmor, MLAmmo] = 1;
$ItemMax[carmor, ACAmmo] = 0;
$ItemMax[carmor, KineticAmmo] = 0;

$ItemMax[carmor, EnergyPack] = 1;
$ItemMax[carmor, RepairPack] = 1;
$ItemMax[carmor, ShieldPack] = 1;
$ItemMax[carmor, SensorJammerPack] = 1;
$ItemMax[carmor, StealthPack] = 0;
$ItemMax[carmor, ComPack] = 1;
$ItemMax[carmor, TelePack] = 1;
$ItemMax[carmor, VehicleRepairPack] = 1;
$ItemMax[carmor, DetPack] = 1;
$ItemMax[carmor, DronePack] = 1;
$ItemMax[carmor, GuidedBombPack] = 0;
$ItemMax[carmor, SurveyDronePack] = 0;
$ItemMax[carmor, AttackDronePack] = 1;
$ItemMax[carmor, RelocatePack] = 1;
$ItemMax[carmor, CoolantPack] = 0;

$ItemMax[carmor, MotionSensorPack] = 0;
$ItemMax[carmor, PulseSensorPack] = 0;
$ItemMax[carmor, DGNPack] = 0;
$ItemMax[carmor, DeployableSensorJammerPack] = 0;
$ItemMax[carmor, CameraPack] = 0;
$ItemMax[carmor, TurretPack] = 0;
$ItemMax[carmor, LaserTurretPack] = 0;
$ItemMax[carmor, AmmoPack] = 1;
$ItemMax[carmor, RepairKit] = 1;
$ItemMax[carmor, DeployableInvPack] = 0;
$ItemMax[carmor, DeployableAmmoPack] = 1;
$ItemMax[carmor, ForceScreen] = 0;
$ItemMax[carmor, Barricade] = 0;
$ItemMax[carmor, TeleportField] = 0;
$ItemMax[carmor, TeleportPad] = 0;
$ItemMax[carmor, ChaingunTurret] = 0;
$ItemMax[carmor, RemoteAutoCannon] = 0;
$ItemMax[carmor, RemoteAACannon] = 0;
$ItemMax[carmor, RemotePlasmaTurret] = 0;
$ItemMax[carmor, MissileTurret] = 0;
$ItemMax[carmor, RemoteELF] = 0;
$ItemMax[carmor, StealthMine] = 0;
$ItemMax[carmor, AntiArmorMine] = 0;

$ItemMax[carmor, 	EMPBeaconPack] = 0;
$ItemMax[carmor, 	PowerGeneratorPack] = 0;
$ItemMax[carmor, 	ShieldBeaconPack] = 0;
$ItemMax[carmor, 	EmplacementPack] = 0;
$ItemMax[carmor, PortInvPack] = 0;

$MaxWeapons[carmor] = 4;

//-------------
// Medium Armor
//-------------
$DamageScale[marmor, $LandingDamageType] = 1.0;
$DamageScale[marmor, $ImpactDamageType] = 1.0;
$DamageScale[marmor, $CrushDamageType] = 1.0;
$DamageScale[marmor, $BulletDamageType] = 0.8;
$DamageScale[marmor, $PlasmaDamageType] = 0.6;
$DamageScale[marmor, $EnergyDamageType] = 1.0;
$DamageScale[marmor, $ExplosionDamageType] = 0.8;
$DamageScale[marmor, $MissileDamageType] = 1.0;
$DamageScale[marmor, $ShrapnelDamageType] = 0.8;
$DamageScale[marmor, $DebrisDamageType] = 0.8;
$DamageScale[marmor, $LaserDamageType] = 0.75;
$DamageScale[marmor, $MortarDamageType] = 1.0;
$DamageScale[marmor, $BlasterDamageType] = 1.0;
$DamageScale[marmor, $ElectricityDamageType] = 1.0;
$DamageScale[marmor, $MineDamageType] = 0.8;
$DamageScale[marmor, $DrainDamageType] = 1.0;

$ItemMax[marmor, Blaster] = 1;
$ItemMax[marmor, EDGun] = 0;
$ItemMax[marmor, GaussRifle] = 1;
$ItemMax[marmor, SilencedPistol] = 0;
$ItemMax[marmor, SniperRifle] = 0;
$ItemMax[marmor, AssaultRifle] = 0;
$ItemMax[marmor, Chaingun] = 0;
$ItemMax[marmor, AutoCannon] = 0;
$ItemMax[marmor, Disclauncher] = 1;
$ItemMax[marmor, KineticRifle] = 0;
$ItemMax[marmor, GrenadeLauncher] = 1;
$ItemMax[marmor, Mortar] = 0;
$ItemMax[marmor, RocketLauncher] = 1;
$ItemMax[marmor, MissileLauncher] = 1;
$ItemMax[marmor, PlasmaGun] = 1;
$ItemMax[marmor, PlasmaRepeater] = 0;
$ItemMax[marmor, EnergyCannon] = 0;
$ItemMax[marmor, LaserRifle] = 0;
$ItemMax[marmor, EnergyRifle] = 1;
$ItemMax[marmor, TransferGun] = 0;
$ItemMax[marmor, FieldRepairGun] = 1;
$ItemMax[marmor, DemoCharge] = 0;
$ItemMax[marmor, TargetingLaser] = 1;
$ItemMax[marmor, MineAmmo] = 4;
$ItemMax[marmor, Grenade] = 1;
$ItemMax[marmor, Beacon] = 3;

$ItemMax[marmor, FusionPack] = 80;
$ItemMax[marmor, GaussAmmo] = 10;
$ItemMax[marmor, ARAmmo] = 0;
$ItemMax[marmor, PistolAmmo] = 0;
$ItemMax[marmor, SniperAmmo] = 0;
$ItemMax[marmor, HvyBulletAmmo] = 0;
$ItemMax[marmor, PlasmaAmmo] = 40;
$ItemMax[marmor, FThrowerAmmo] = 100;
$ItemMax[marmor, DiscAmmo] = 15;
$ItemMax[marmor, GrenadeAmmo] = 15;
$ItemMax[marmor, MortarAmmo] = 0;
$ItemMax[marmor, RLAmmo] = 3;
$ItemMax[marmor, MLAmmo] = 1;
$ItemMax[marmor, ACAmmo] = 0;
$ItemMax[marmor, KineticAmmo] = 0;

$ItemMax[marmor, EnergyPack] = 1;
$ItemMax[marmor, RepairPack] = 1;
$ItemMax[marmor, ShieldPack] = 1;
$ItemMax[marmor, ComPack] = 1;
$ItemMax[marmor, TelePack] = 1;
$ItemMax[marmor, VehicleRepairPack] = 0;
$ItemMax[marmor, DetPack] = 0;
$ItemMax[marmor, DronePack] = 1;
$ItemMax[marmor, GuidedBombPack] = 0;
$ItemMax[marmor, SurveyDronePack] = 0;
$ItemMax[marmor, AttackDronePack] = 0;
$ItemMax[marmor, RelocatePack] = 0;
$ItemMax[marmor, CoolantPack] = 0;

$ItemMax[marmor, SensorJammerPack] = 1;
$ItemMax[marmor, MotionSensorPack] = 1;
$ItemMax[marmor, PulseSensorPack] = 1;
$ItemMax[marmor, DGNPack] = 1;
$ItemMax[marmor, DeployableSensorJammerPack] = 1;
$ItemMax[marmor, StealthPack] = 0;
$ItemMax[marmor, CameraPack] = 1;
$ItemMax[marmor, TurretPack] = 1;
$ItemMax[marmor, LaserTurretPack] = 1;
$ItemMax[marmor, AmmoPack] = 1;
$ItemMax[marmor, RepairKit] = 1;
$ItemMax[marmor, DeployableInvPack] = 1;
$ItemMax[marmor, DeployableAmmoPack] = 1;
$ItemMax[marmor, ForceScreen] = 1;
$ItemMax[marmor, Barricade] = 1;
$ItemMax[marmor, TeleportField] = 1;
$ItemMax[marmor, TeleportPad] = 1;
$ItemMax[marmor, ChaingunTurret] = 1;
$ItemMax[marmor, RemoteAutoCannon] = 1;
$ItemMax[marmor, RemoteAACannon] = 1;
$ItemMax[marmor, RemotePlasmaTurret] = 1;
$ItemMax[marmor, MissileTurret] = 1;
$ItemMax[marmor, RemoteELF] = 1;
$ItemMax[marmor, StealthMine] = 1;
$ItemMax[marmor, AntiArmorMine] = 1;

$ItemMax[marmor, 	EMPBeaconPack] = 1;
$ItemMax[marmor, 	PowerGeneratorPack] = 1;
$ItemMax[marmor, 	ShieldBeaconPack] = 1;
$ItemMax[marmor, 	EmplacementPack] = 1;
$ItemMax[marmor,  PortInvPack] = 0;

$MaxWeapons[marmor] = 4;

//--------------
// Assault Armor
//--------------
$DamageScale[harmor, $LandingDamageType] = 0.9;
$DamageScale[harmor, $ImpactDamageType] = 0.9;
$DamageScale[harmor, $CrushDamageType] = 0.9;
$DamageScale[harmor, $BulletDamageType] = 0.4;
$DamageScale[harmor, $PlasmaDamageType] = 0.4;
$DamageScale[harmor, $EnergyDamageType] = 0.6;
$DamageScale[harmor, $ExplosionDamageType] = 0.6;
$DamageScale[harmor, $MissileDamageType] = 1.0;
$DamageScale[harmor, $DebrisDamageType] = 0.8;
$DamageScale[harmor, $ShrapnelDamageType] = 0.8;
$DamageScale[harmor, $LaserDamageType] = 0.8;
$DamageScale[harmor, $MortarDamageType] = 0.7;
$DamageScale[harmor, $BlasterDamageType] = 0.7;
$DamageScale[harmor, $ElectricityDamageType] = 1.0;
$DamageScale[harmor, $MineDamageType] = 0.8;
$DamageScale[harmor, $DrainDamageType] = 1.0;

$ItemMax[harmor, Blaster] = 1;
$ItemMax[harmor, EDGun] = 0;
$ItemMax[harmor, GaussRifle] = 0;
$ItemMax[harmor, SilencedPistol] = 0;
$ItemMax[harmor, SniperRifle] = 0;
$ItemMax[harmor, AssaultRifle] = 0;
$ItemMax[harmor, Chaingun] = 1;
$ItemMax[harmor, AutoCannon] = 1;
$ItemMax[harmor, Disclauncher] = 1;
$ItemMax[harmor, KineticRifle] = 0;
$ItemMax[harmor, GrenadeLauncher] = 1;
$ItemMax[harmor, Mortar] = 1;
$ItemMax[harmor, RocketLauncher] = 1;
$ItemMax[harmor, MissileLauncher] = 1;
$ItemMax[harmor, PlasmaGun] = 1;
$ItemMax[harmor, PlasmaRepeater] = 1;
$ItemMax[harmor, EnergyCannon] = 0;
$ItemMax[harmor, LaserRifle] = 0;
$ItemMax[harmor, EnergyRifle] = 1;
$ItemMax[harmor, TransferGun] = 1;
$ItemMax[harmor, FieldRepairGun] = 0;
$ItemMax[harmor, DemoCharge] = 1;
$ItemMax[harmor, TargetingLaser] = 1;
$ItemMax[harmor, MineAmmo] = 3;
$ItemMax[harmor, Grenade] = 4;
$ItemMax[harmor, Beacon] = 1;

$ItemMax[harmor, FusionPack] = 60;
$ItemMax[harmor, GaussAmmo] = 0;
$ItemMax[harmor, ARAmmo] = 0;
$ItemMax[harmor, PistolAmmo] = 0;
$ItemMax[harmor, SniperAmmo] = 0;
$ItemMax[harmor, HvyBulletAmmo] = 200;
$ItemMax[harmor, PlasmaAmmo] = 50;
$ItemMax[harmor, FThrowerAmmo] = 100;
$ItemMax[harmor, DiscAmmo] = 30;
$ItemMax[harmor, GrenadeAmmo] = 30;
$ItemMax[harmor, MortarAmmo] = 10;
$ItemMax[harmor, RLAmmo] = 6;
$ItemMax[harmor, MLAmmo] = 2;
$ItemMax[harmor, ACAmmo] = 85;
$ItemMax[harmor, KineticAmmo] = 0;

$ItemMax[harmor, EnergyPack] = 1;
$ItemMax[harmor, RepairPack] = 1;
$ItemMax[harmor, ShieldPack] = 0;
$ItemMax[harmor, SensorJammerPack] = 1;
$ItemMax[harmor, StealthPack] = 0;
$ItemMax[harmor, ComPack] = 1;
$ItemMax[harmor, TelePack] = 1;
$ItemMax[harmor, VehicleRepairPack] = 0;
$ItemMax[harmor, DetPack] = 0;
$ItemMax[harmor, DronePack] = 1;
$ItemMax[harmor, GuidedBombPack] = 1;
$ItemMax[harmor, SurveyDronePack] = 0;
$ItemMax[harmor, AttackDronePack] = 0;
$ItemMax[harmor, RelocatePack] = 0;
$ItemMax[harmor, CoolantPack] = 0;

$ItemMax[harmor, MotionSensorPack] = 1;
$ItemMax[harmor, PulseSensorPack] = 1;
$ItemMax[harmor, DGNPack] = 0;
$ItemMax[harmor, DeployableSensorJammerPack] = 1;
$ItemMax[harmor, CameraPack] = 1;
$ItemMax[harmor, TurretPack] = 0;
$ItemMax[harmor, LaserTurretPack] = 0;
$ItemMax[harmor, AmmoPack] = 1;
$ItemMax[harmor, RepairKit] = 1;
$ItemMax[harmor, DeployableInvPack] = 0;
$ItemMax[harmor, DeployableAmmoPack] = 1;
$ItemMax[harmor, Barricade] = 0;
$ItemMax[harmor, TeleportField] = 0;
$ItemMax[harmor, TeleportPad] = 0;
$ItemMax[harmor, ForceScreen] = 0;
$ItemMax[harmor, ChaingunTurret] = 0;
$ItemMax[harmor, RemoteAutoCannon] = 0;
$ItemMax[harmor, RemoteAACannon] = 0;
$ItemMax[harmor, RemotePlasmaTurret] = 0;
$ItemMax[harmor, MissileTurret] = 0;
$ItemMax[harmor, RemoteELF] = 0;
$ItemMax[harmor, StealthMine] = 0;
$ItemMax[harmor, AntiArmorMine] = 0;

$ItemMax[harmor, 	EMPBeaconPack] = 0;
$ItemMax[harmor, 	PowerGeneratorPack] = 0;
$ItemMax[harmor, 	ShieldBeaconPack] = 0;
$ItemMax[harmor, 	EmplacementPack] = 0;
$ItemMax[harmor,  PortInvPack] = 0;

$MaxWeapons[harmor] = 5;

//**************
//Defender Armor
//**************
$DamageScale[darmor, $LandingDamageType] = 0.5;
$DamageScale[darmor, $ImpactDamageType] = 0.5;
$DamageScale[darmor, $CrushDamageType] = 0.5;
$DamageScale[darmor, $BulletDamageType] = 0.3;
$DamageScale[darmor, $PlasmaDamageType] = 0.3;
$DamageScale[darmor, $EnergyDamageType] = 0.3;
$DamageScale[darmor, $ExplosionDamageType] = 0.4;
$DamageScale[darmor, $MissileDamageType] = 0.6;
$DamageScale[darmor, $DebrisDamageType] = 0.4;
$DamageScale[darmor, $ShrapnelDamageType] = 0.4;
$DamageScale[darmor, $LaserDamageType] = 0.5;
$DamageScale[darmor, $MortarDamageType] = 0.25;
$DamageScale[darmor, $BlasterDamageType] = 0.3;
$DamageScale[darmor, $ElectricityDamageType] = 0.3;
$DamageScale[darmor, $MineDamageType] = 0.2;
$DamageScale[darmor, $DrainDamageType] = 0.9;

$ItemMax[darmor, Blaster] = 1;
$ItemMax[darmor, EDGun] = 0;
$ItemMax[darmor, GaussRifle] = 0;
$ItemMax[darmor, SilencedPistol] = 0;
$ItemMax[darmor, SniperRifle] = 0;
$ItemMax[darmor, AssaultRifle] = 0;
$ItemMax[darmor, Chaingun] = 1;
$ItemMax[darmor, AutoCannon] = 1;
$ItemMax[darmor, Disclauncher] = 0;
$ItemMax[darmor, KineticRifle] = 1;
$ItemMax[darmor, GrenadeLauncher] = 0;
$ItemMax[darmor, Mortar] = 1;
$ItemMax[darmor, RocketLauncher] = 1;
$ItemMax[darmor, MissileLauncher] = 1;
$ItemMax[darmor, PlasmaGun] = 1;
$ItemMax[darmor, PlasmaRepeater] = 1;
$ItemMax[darmor, EnergyCannon] = 1;
$ItemMax[darmor, LaserRifle] = 0;
$ItemMax[darmor, EnergyRifle] = 1;
$ItemMax[darmor, TransferGun] = 0;
$ItemMax[darmor, FieldRepairGun] = 1;
$ItemMax[darmor, DemoCharge] = 0;
$ItemMax[darmor, TargetingLaser] = 1;
$ItemMax[darmor, MineAmmo] = 6;
$ItemMax[darmor, Grenade] = 6;
$ItemMax[darmor, Beacon] = 1;

$ItemMax[darmor, FusionPack] = 60;
$ItemMax[darmor, GaussAmmo] = 0;
$ItemMax[darmor, ARAmmo] = 0;
$ItemMax[darmor, PistolAmmo] = 0;
$ItemMax[darmor, SniperAmmo] = 0;
$ItemMax[darmor, HvyBulletAmmo] = 100;
$ItemMax[darmor, PlasmaAmmo] = 40;
$ItemMax[darmor, FThrowerAmmo] = 100;
$ItemMax[darmor, DiscAmmo] = 0;
$ItemMax[darmor, GrenadeAmmo] = 0;
$ItemMax[darmor, MortarAmmo] = 10;
$ItemMax[darmor, RLAmmo] = 6;
$ItemMax[darmor, MLAmmo] = 3;
$ItemMax[darmor, ACAmmo] = 40;
$ItemMax[darmor, KineticAmmo] = 25;

$ItemMax[darmor, EnergyPack] = 1;
$ItemMax[darmor, RepairPack] = 0;
$ItemMax[darmor, ShieldPack] = 1;
$ItemMax[darmor, SensorJammerPack] = 0;
$ItemMax[darmor, StealthPack] = 0;
$ItemMax[darmor, ComPack] = 1;
$ItemMax[darmor, TelePack] = 0;
$ItemMax[darmor, VehicleRepairPack] = 0;
$ItemMax[darmor, DetPack] = 0;
$ItemMax[darmor, DronePack] = 1;
$ItemMax[darmor, GuidedBombPack] = 1;
$ItemMax[darmor, SurveyDronePack] = 1;
$ItemMax[darmor, AttackDronePack] = 1;
$ItemMax[darmor, RelocatePack] = 0;
$ItemMax[darmor, CoolantPack] = 0;

$ItemMax[darmor, MotionSensorPack] = 1;
$ItemMax[darmor, PulseSensorPack] = 0;
$ItemMax[darmor, DGNPack] = 1;
$ItemMax[darmor, DeployableSensorJammerPack] = 1;
$ItemMax[darmor, CameraPack] = 1;
$ItemMax[darmor, TurretPack] = 1;
$ItemMax[darmor, LaserTurretPack] = 1;
$ItemMax[darmor, AmmoPack] = 0;
$ItemMax[darmor, RepairKit] = 1;
$ItemMax[darmor, DeployableInvPack] = 1;
$ItemMax[darmor, DeployableAmmoPack] = 1;
$ItemMax[darmor, ForceScreen] = 1;
$ItemMax[darmor, Barricade] = 1;
$ItemMax[darmor, TeleportField] = 0;
$ItemMax[darmor, TeleportPad] = 0;
$ItemMax[darmor, ChaingunTurret] = 1;
$ItemMax[darmor, RemoteAutoCannon] = 1;
$ItemMax[darmor, RemoteAACannon] = 1;
$ItemMax[darmor, RemotePlasmaTurret] = 1;
$ItemMax[darmor, MissileTurret] = 1;
$ItemMax[darmor, RemoteELF] = 1;
$ItemMax[darmor, StealthMine] = 1;
$ItemMax[darmor, AntiArmorMine] = 1;

$ItemMax[darmor, 	EMPBeaconPack] = 0;
$ItemMax[darmor, 	PowerGeneratorPack] = 0;
$ItemMax[darmor, 	ShieldBeaconPack] = 0;
$ItemMax[darmor, 	EmplacementPack] = 0;
$ItemMax[darmor, PortInvPack] = 0;

$MaxWeapons[darmor] = 5;

//-------------
// SCV Armor
//-------------
$DamageScale[scvarmor, $LandingDamageType] = 0.7;
$DamageScale[scvarmor, $ImpactDamageType] = 0.7;
$DamageScale[scvarmor, $CrushDamageType] = 0.7;
$DamageScale[scvarmor, $BulletDamageType] = 0.6;
$DamageScale[scvarmor, $PlasmaDamageType] = 0.5;
$DamageScale[scvarmor, $EnergyDamageType] = 0.8;
$DamageScale[scvarmor, $ExplosionDamageType] = 0.5;
$DamageScale[scvarmor, $MissileDamageType] = 0.9;
$DamageScale[scvarmor, $ShrapnelDamageType] = 0.7;
$DamageScale[scvarmor, $DebrisDamageType] = 0.6;
$DamageScale[scvarmor, $LaserDamageType] = 0.8;
$DamageScale[scvarmor, $MortarDamageType] = 0.7;
$DamageScale[scvarmor, $BlasterDamageType] = 0.6;
$DamageScale[scvarmor, $ElectricityDamageType] = 0.8;
$DamageScale[scvarmor, $MineDamageType] = 0.5;
$DamageScale[scvarmor, $DrainDamageType] = 0.8;

$ItemMax[scvarmor, Blaster] = 0;
$ItemMax[scvarmor, EDGun] = 0;
$ItemMax[scvarmor, GaussRifle] = 0;
$ItemMax[scvarmor, SilencedPistol] = 0;
$ItemMax[scvarmor, SniperRifle] = 0;
$ItemMax[scvarmor, AssaultRifle] = 0;
$ItemMax[scvarmor, Chaingun] = 0;
$ItemMax[scvarmor, AutoCannon] = 0;
$ItemMax[scvarmor, Disclauncher] = 0;
$ItemMax[scvarmor, KineticRifle] = 0;
$ItemMax[scvarmor, GrenadeLauncher] = 0;
$ItemMax[scvarmor, Mortar] = 0;
$ItemMax[scvarmor, RocketLauncher] = 0;
$ItemMax[scvarmor, MissileLauncher] = 0;
$ItemMax[scvarmor, PlasmaGun] = 0;
$ItemMax[scvarmor, PlasmaRepeater] = 0;
$ItemMax[scvarmor, EnergyCannon] = 0;
$ItemMax[scvarmor, LaserRifle] = 0;
$ItemMax[scvarmor, EnergyRifle] = 0;
$ItemMax[scvarmor, TransferGun] = 0;
$ItemMax[scvarmor, FieldRepairGun] = 1;
$ItemMax[scvarmor, DemoCharge] = 0;
$ItemMax[scvarmor, TargetingLaser] = 1;
$ItemMax[scvarmor, MineAmmo] = 0;
$ItemMax[scvarmor, Grenade] = 0;
$ItemMax[scvarmor, Beacon] = 4;

$ItemMax[scvarmor, FusionPack] = 0;
$ItemMax[scvarmor, GaussAmmo] = 0;
$ItemMax[scvarmor, ARAmmo] = 0;
$ItemMax[scvarmor, PistolAmmo] = 0;
$ItemMax[scvarmor, SniperAmmo] = 0;
$ItemMax[scvarmor, HvyBulletAmmo] = 0;
$ItemMax[scvarmor, PlasmaAmmo] = 0;
$ItemMax[scvarmor, FThrowerAmmo] = 0;
$ItemMax[scvarmor, DiscAmmo] = 0;
$ItemMax[scvarmor, GrenadeAmmo] = 0;
$ItemMax[scvarmor, MortarAmmo] = 0;
$ItemMax[scvarmor, RLAmmo] = 0;
$ItemMax[scvarmor, MLAmmo] = 0;
$ItemMax[scvarmor, ACAmmo] = 0;
$ItemMax[scvarmor, KineticAmmo] = 0;

$ItemMax[scvarmor, EnergyPack] = 0;
$ItemMax[scvarmor, RepairPack] = 0;
$ItemMax[scvarmor, ShieldPack] = 0;
$ItemMax[scvarmor, ComPack] = 0;
$ItemMax[scvarmor, TelePack] = 0;
$ItemMax[scvarmor, VehicleRepairPack] = 0;
$ItemMax[scvarmor, DetPack] = 0;
$ItemMax[scvarmor, DronePack] = 0;
$ItemMax[scvarmor, GuidedBombPack] = 0;
$ItemMax[scvarmor, SurveyDronePack] = 0;
$ItemMax[scvarmor, AttackDronePack] = 0;
$ItemMax[scvarmor, RelocatePack] = 0;
$ItemMax[scvarmor, CoolantPack] = 0;

$ItemMax[scvarmor, SensorJammerPack] = 0;
$ItemMax[scvarmor, MotionSensorPack] = 1;
$ItemMax[scvarmor, PulseSensorPack] = 1;
$ItemMax[scvarmor, DGNPack] = 0;
$ItemMax[scvarmor, DeployableSensorJammerPack] = 1;
$ItemMax[scvarmor, StealthPack] = 0;
$ItemMax[scvarmor, CameraPack] = 0;
$ItemMax[scvarmor, TurretPack] = 1;
$ItemMax[scvarmor, LaserTurretPack] = 1;
$ItemMax[scvarmor, AmmoPack] = 0;
$ItemMax[scvarmor, RepairKit] = 1;
$ItemMax[scvarmor, DeployableInvPack] = 0;
$ItemMax[scvarmor, DeployableAmmoPack] = 0;
$ItemMax[scvarmor, ForceScreen] = 1;
$ItemMax[scvarmor, Barricade] = 1;
$ItemMax[scvarmor, TeleportField] = 1;
$ItemMax[scvarmor, TeleportPad] = 0;
$ItemMax[scvarmor, ChaingunTurret] = 1;
$ItemMax[scvarmor, RemoteAutoCannon] = 1;
$ItemMax[scvarmor, RemoteAACannon] = 1;
$ItemMax[scvarmor, RemotePlasmaTurret] = 1;
$ItemMax[scvarmor, MissileTurret] = 1;
$ItemMax[scvarmor, RemoteELF] = 1;
$ItemMax[scvarmor, StealthMine] = 1;
$ItemMax[scvarmor, AntiArmorMine] = 1;

$ItemMax[scvarmor, EMPBeaconPack] = 1;
$ItemMax[scvarmor, PowerGeneratorPack] = 1;
$ItemMax[scvarmor, ShieldBeaconPack] = 1;
$ItemMax[scvarmor, EmplacementPack] = 0;
$ItemMax[scvarmor, PortInvPack] = 1;

$MaxWeapons[scvarmor] = 1;

//-------------------
// light Female Armor
//-------------------
$DamageScale[lfemale, $LandingDamageType] = 1.0;
$DamageScale[lfemale, $ImpactDamageType] = 1.0;	
$DamageScale[lfemale, $CrushDamageType] = 1.1;	
$DamageScale[lfemale, $BulletDamageType] = 1.0;
$DamageScale[lfemale, $PlasmaDamageType] = 1.1;
$DamageScale[lfemale, $EnergyDamageType] = 1.3;
$DamageScale[lfemale, $ExplosionDamageType] = 1.1;
$DamageScale[lfemale, $MissileDamageType] = 1.1;
$DamageScale[lfemale, $ShrapnelDamageType] = 1.3;
$DamageScale[lfemale, $DebrisDamageType] = 1.3;
$DamageScale[lfemale, $LaserDamageType] = 0.85;
$DamageScale[lfemale, $MortarDamageType] = 1.4;
$DamageScale[lfemale, $BlasterDamageType] = 1.3;
$DamageScale[lfemale, $ElectricityDamageType] = 1.1;
$DamageScale[lfemale, $MineDamageType] = 1.2;
$DamageScale[lfemale, $DrainDamageType] = 1.0;

$ItemMax[lfemale, Blaster] = 1;
$ItemMax[lfemale, EDGun] = 1;
$ItemMax[lfemale, GaussRifle] = 0;
$ItemMax[lfemale, SilencedPistol] = 1;
$ItemMax[lfemale, SniperRifle] = 0;
$ItemMax[lfemale, AssaultRifle] = 1;
$ItemMax[lfemale, Chaingun] = 0;
$ItemMax[lfemale, AutoCannon] = 0;
$ItemMax[lfemale, Disclauncher] = 1;
$ItemMax[lfemale, KineticRifle] = 0;
$ItemMax[lfemale, GrenadeLauncher] = 0;
$ItemMax[lfemale, Mortar] = 0;
$ItemMax[lfemale, RocketLauncher] = 0;
$ItemMax[lfemale, MissileLauncher] = 1;
$ItemMax[lfemale, PlasmaGun] = 1;
$ItemMax[lfemale, PlasmaRepeater] = 0;
$ItemMax[lfemale, EnergyCannon] = 0;
$ItemMax[lfemale, LaserRifle] = 1;
$ItemMax[lfemale, EnergyRifle] = 1;
$ItemMax[lfemale, TransferGun] = 1;
$ItemMax[lfemale, FieldRepairGun] = 0;
$ItemMax[lfemale, DemoCharge] = 1;
$ItemMax[lfemale, TargetingLaser] = 1;
$ItemMax[lfemale, MineAmmo] = 2;
$ItemMax[lfemale, Grenade] = 3;
$ItemMax[lfemale, Beacon] = 2;

$ItemMax[lfemale, FusionPack] = 80;
$ItemMax[lfemale, GaussAmmo] = 10;
$ItemMax[lfemale, ARAmmo] = 80;
$ItemMax[lfemale, PistolAmmo] = 40;
$ItemMax[lfemale, SniperAmmo] = 20;
$ItemMax[lfemale, HvyBulletAmmo] = 80;
$ItemMax[lfemale, PlasmaAmmo] = 30;
$ItemMax[lfemale, FThrowerAmmo] = 100;
$ItemMax[lfemale, DiscAmmo] = 15;
$ItemMax[lfemale, GrenadeAmmo] = 15;
$ItemMax[lfemale, MortarAmmo] = 10;
$ItemMax[lfemale, RLAmmo] = 3;
$ItemMax[lfemale, MLAmmo] = 1;
$ItemMax[lfemale, ACAmmo] = 25;
$ItemMax[lfemale, KineticAmmo] = 0;

$ItemMax[lfemale, EnergyPack] = 1;
$ItemMax[lfemale, RepairPack] = 1;
$ItemMax[lfemale, ShieldPack] = 1;
$ItemMax[lfemale, SensorJammerPack] = 1;
$ItemMax[lfemale, StealthPack] = 1;
$ItemMax[lfemale, ComPack] = 1;
$ItemMax[lfemale, TelePack] = 1;
$ItemMax[lfemale, VehicleRepairPack] = 1;
$ItemMax[lfemale, DetPack] = 1;
$ItemMax[lfemale, DronePack] = 1;
$ItemMax[lfemale, GuidedBombPack] = 0;
$ItemMax[lfemale, SurveyDronePack] = 1;
$ItemMax[lfemale, AttackDronePack] = 0;
$ItemMax[lfemale, RelocatePack] = 0;
$ItemMax[lfemale, CoolantPack] = 0;

$ItemMax[lfemale, MotionSensorPack] = 1;
$ItemMax[lfemale, PulseSensorPack] = 1;
$ItemMax[lfemale, DGNPack] = 1;
$ItemMax[lfemale, DeployableSensorJammerPack] = 1;
$ItemMax[lfemale, CameraPack] = 1;
$ItemMax[lfemale, TurretPack] = 0;
$ItemMax[lfemale, LaserTurretPack] = 0;
$ItemMax[lfemale, AmmoPack] = 1;
$ItemMax[lfemale, RepairKit] = 1;
$ItemMax[lfemale, DeployableInvPack] = 0;
$ItemMax[lfemale, DeployableAmmoPack] = 0;
$ItemMax[lfemale, ForceScreen] = 0;
$ItemMax[lfemale, Barricade] = 0;
$ItemMax[lfemale, TeleportField] = 0;
$ItemMax[lfemale, TeleportPad] = 0;
$ItemMax[lfemale, ChaingunTurret] = 0;
$ItemMax[lfemale, RemoteAutoCannon] = 0;
$ItemMax[lfemale, RemoteAACannon] = 0;
$ItemMax[lfemale, RemotePlasmaTurret] = 0;
$ItemMax[lfemale, MissileTurret] = 0;
$ItemMax[lfemale, RemoteELF] = 0;
$ItemMax[lfemale, StealthMine] = 0;
$ItemMax[lfemale, AntiArmorMine] = 0;

$ItemMax[lfemale, EMPBeaconPack] = 0;
$ItemMax[lfemale, PowerGeneratorPack] = 0;
$ItemMax[lfemale, ShieldBeaconPack] = 0;
$ItemMax[lfemale, EmplacementPack] = 0;
$ItemMax[lfemale, PortInvPack] = 0;

$MaxWeapons[lfemale] = 3;

//********************
// Combat Female Armor
//********************
$DamageScale[fcarmor, $LandingDamageType] = 0.8;
$DamageScale[fcarmor, $ImpactDamageType] = 0.8;
$DamageScale[fcarmor, $CrushDamageType] = 1.0;
$DamageScale[fcarmor, $BulletDamageType] = 0.8;
$DamageScale[fcarmor, $PlasmaDamageType] = 0.7;
$DamageScale[fcarmor, $EnergyDamageType] = 0.8;
$DamageScale[fcarmor, $ExplosionDamageType] = 1.0;
$DamageScale[fcarmor, $MissileDamageType] = 1.0;
$DamageScale[fcarmor, $DebrisDamageType] = 1.0;
$DamageScale[fcarmor, $ShrapnelDamageType] = 1.0;
$DamageScale[fcarmor, $LaserDamageType] = 0.75;
$DamageScale[fcarmor, $MortarDamageType] = 1.0;
$DamageScale[fcarmor, $BlasterDamageType] = 0.8;
$DamageScale[fcarmor, $ElectricityDamageType] = 1.0;
$DamageScale[fcarmor, $MineDamageType] = 1.0;
$DamageScale[fcarmor, $DrainDamageType] = 1.0;

$ItemMax[fcarmor, Blaster] = 1;
$ItemMax[fcarmor, EDGun] = 0;
$ItemMax[fcarmor, GaussRifle] = 0;
$ItemMax[fcarmor, SilencedPistol] = 0;
$ItemMax[fcarmor, SniperRifle] = 1;
$ItemMax[fcarmor, AssaultRifle] = 1;
$ItemMax[fcarmor, Chaingun] = 1;
$ItemMax[fcarmor, AutoCannon] = 0;
$ItemMax[fcarmor, Disclauncher] = 1;
$ItemMax[fcarmor, KineticRifle] = 0;
$ItemMax[fcarmor, GrenadeLauncher] = 1;
$ItemMax[fcarmor, Mortar] = 0;
$ItemMax[fcarmor, RocketLauncher] = 0;
$ItemMax[fcarmor, MissileLauncher] = 1;
$ItemMax[fcarmor, PlasmaGun] = 1;
$ItemMax[fcarmor, PlasmaRepeater] = 1;
$ItemMax[fcarmor, EnergyCannon] = 0;
$ItemMax[fcarmor, LaserRifle] = 0;
$ItemMax[fcarmor, EnergyRifle] = 1;
$ItemMax[fcarmor, TransferGun] = 1;
$ItemMax[fcarmor, FieldRepairGun] = 0;
$ItemMax[fcarmor, DemoCharge] = 1;
$ItemMax[fcarmor, TargetingLaser] = 1;
$ItemMax[fcarmor, MineAmmo] = 3;
$ItemMax[fcarmor, Grenade] = 5;
$ItemMax[fcarmor, Beacon]  = 2;

$ItemMax[fcarmor, FusionPack] = 100;
$ItemMax[fcarmor, GaussAmmo] = 0;
$ItemMax[fcarmor, ARAmmo] = 100;
$ItemMax[fcarmor, PistolAmmo] = 0;
$ItemMax[fcarmor, SniperAmmo] = 30;
$ItemMax[fcarmor, HvyBulletAmmo] = 80;
$ItemMax[fcarmor, PlasmaAmmo] = 40;
$ItemMax[fcarmor, FThrowerAmmo] = 40;
$ItemMax[fcarmor, DiscAmmo] = 30;
$ItemMax[fcarmor, GrenadeAmmo] = 20;
$ItemMax[fcarmor, MortarAmmo] = 0;
$ItemMax[fcarmor, RLAmmo] = 3;
$ItemMax[fcarmor, MLAmmo] = 1;
$ItemMax[fcarmor, ACAmmo] = 0;
$ItemMax[fcarmor, KineticAmmo] = 0;

$ItemMax[fcarmor, EnergyPack] = 1;
$ItemMax[fcarmor, RepairPack] = 1;
$ItemMax[fcarmor, ShieldPack] = 1;
$ItemMax[fcarmor, SensorJammerPack] = 1;
$ItemMax[fcarmor, StealthPack] = 0;
$ItemMax[fcarmor, ComPack] = 1;
$ItemMax[fcarmor, TelePack] = 1;
$ItemMax[fcarmor, VehicleRepairPack] = 1;
$ItemMax[fcarmor, DetPack] = 1;
$ItemMax[fcarmor, DronePack] = 1;
$ItemMax[fcarmor, GuidedBombPack] = 0;
$ItemMax[fcarmor, SurveyDronePack] = 0;
$ItemMax[fcarmor, AttackDronePack] = 1;
$ItemMax[fcarmor, RelocatePack] = 1;
$ItemMax[fcarmor, CoolantPack] = 0;

$ItemMax[fcarmor, MotionSensorPack] = 0;
$ItemMax[fcarmor, PulseSensorPack] = 0;
$ItemMax[fcarmor, DGNPack] = 0;
$ItemMax[fcarmor, DeployableSensorJammerPack] = 0;
$ItemMax[fcarmor, CameraPack] = 0;
$ItemMax[fcarmor, TurretPack] = 0;
$ItemMax[fcarmor, LaserTurretPack] = 0;
$ItemMax[fcarmor, AmmoPack] = 1;
$ItemMax[fcarmor, RepairKit] = 1;
$ItemMax[fcarmor, DeployableInvPack] = 0;
$ItemMax[fcarmor, DeployableAmmoPack] = 1;
$ItemMax[fcarmor, ForceScreen] = 0;
$ItemMax[fcarmor, Barricade] = 0;
$ItemMax[fcarmor, TeleportField] = 0;
$ItemMax[fcarmor, TeleportPad] = 0;
$ItemMax[fcarmor, ChaingunTurret] = 0;
$ItemMax[fcarmor, RemoteAutoCannon] = 0;
$ItemMax[fcarmor, RemoteAACannon] = 0;
$ItemMax[fcarmor, RemotePlasmaTurret] = 0;
$ItemMax[fcarmor, MissileTurret] = 0;
$ItemMax[fcarmor, RemoteELF] = 0;
$ItemMax[fcarmor, StealthMine] = 0;
$ItemMax[fcarmor, AntiArmorMine] = 0;

$ItemMax[fcarmor, EMPBeaconPack] = 0;
$ItemMax[fcarmor, PowerGeneratorPack] = 0;
$ItemMax[fcarmor, ShieldBeaconPack] = 0;
$ItemMax[fcarmor, EmplacementPack] = 0;
$ItemMax[fcarmor, PortInvPack] = 0;

$MaxWeapons[fcarmor] = 4;

//--------------------
// Medium Female Armor
//--------------------
$DamageScale[mfemale, $LandingDamageType] = 1.0;
$DamageScale[mfemale, $ImpactDamageType] = 1.0;
$DamageScale[mfemale, $CrushDamageType] = 1.0;
$DamageScale[mfemale, $BulletDamageType] = 0.8;
$DamageScale[mfemale, $EnergyDamageType] = 1.0;
$DamageScale[mfemale, $PlasmaDamageType] = 0.6;
$DamageScale[mfemale, $ExplosionDamageType] = 0.8;
$DamageScale[mfemale, $MissileDamageType] = 1.0;
$DamageScale[mfemale, $ShrapnelDamageType] = 0.8;
$DamageScale[mfemale, $DebrisDamageType] = 0.8;
$DamageScale[mfemale, $LaserDamageType] = 0.75;
$DamageScale[mfemale, $MortarDamageType] = 1.0;
$DamageScale[mfemale, $BlasterDamageType] = 1.0;
$DamageScale[mfemale, $ElectricityDamageType] = 1.0;
$DamageScale[mfemale, $MineDamageType] = 0.8;
$DamageScale[mfemale, $DrainDamageType] = 1.0;

$ItemMax[mfemale, Blaster] = 1;
$ItemMax[mfemale, EDGun] = 0;
$ItemMax[mfemale, GaussRifle] = 1;
$ItemMax[mfemale, SilencedPistol] = 0;
$ItemMax[mfemale, SniperRifle] = 0;
$ItemMax[mfemale, AssaultRifle] = 1;
$ItemMax[mfemale, Chaingun] = 0;
$ItemMax[mfemale, AutoCannon] = 0;
$ItemMax[mfemale, Disclauncher] = 1;
$ItemMax[mfemale, KineticRifle] = 0;
$ItemMax[mfemale, GrenadeLauncher] = 1;
$ItemMax[mfemale, Mortar] = 0;
$ItemMax[mfemale, RocketLauncher] = 1;
$ItemMax[mfemale, MissileLauncher] = 1;
$ItemMax[mfemale, PlasmaGun] = 1;
$ItemMax[mfemale, PlasmaRepeater] = 0;
$ItemMax[mfemale, EnergyCannon] = 0;
$ItemMax[mfemale, EnergyRifle] = 1;
$ItemMax[mfemale, TransferGun] = 0;
$ItemMax[mfemale, FieldRepairGun] = 1;
$ItemMax[mfemale, DemoCharge] = 0;
$ItemMax[mfemale, TargetingLaser] = 1;
$ItemMax[mfemale, MineAmmo] = 4;
$ItemMax[mfemale, Grenade] = 1;
$ItemMax[mfemale, Beacon] = 3;

$ItemMax[mfemale, FusionPack] = 80;
$ItemMax[mfemale, GaussAmmo] = 10;
$ItemMax[mfemale, ARAmmo] = 100;
$ItemMax[mfemale, PistolAmmo] = 0;
$ItemMax[mfemale, ARAmmo] = 0;
$ItemMax[mfemale, SniperAmmo] = 0;
$ItemMax[mfemale, HvyBulletAmmo] = 0;
$ItemMax[mfemale, PlasmaAmmo] = 40;
$ItemMax[mfemale, FThrowerAmmo] = 100;
$ItemMax[mfemale, DiscAmmo] = 15;
$ItemMax[mfemale, GrenadeAmmo] = 20;
$ItemMax[mfemale, MortarAmmo] = 0;
$ItemMax[mfemale, RLAmmo] = 3;
$ItemMax[mfemale, MLAmmo] = 1;
$ItemMax[mfemale, ACAmmo] = 0;
$ItemMax[mfemale, KineticAmmo] = 0;

$ItemMax[mfemale, EnergyPack] = 1;
$ItemMax[mfemale, RepairPack] = 1;
$ItemMax[mfemale, ShieldPack] = 1;
$ItemMax[mfemale, SensorJammerPack] = 1;
$ItemMax[mfemale, StealthPack] = 0;
$ItemMax[mfemale, ComPack] = 0;
$ItemMax[mfemale, TelePack] = 1;
$ItemMax[mfemale, VehicleRepairPack] = 0;
$ItemMax[mfemale, DetPack] = 1;
$ItemMax[mfemale, DronePack] = 1;
$ItemMax[mfemale, GuidedBombPack] = 0;
$ItemMax[mfemale, SurveyDronePack] = 0;
$ItemMax[mfemale, AttackDronePack] = 0;
$ItemMax[mfemale, RelocatePack] = 0;
$ItemMax[mfemale, CoolantPack] = 0;

$ItemMax[mfemale, MotionSensorPack] = 1;
$ItemMax[mfemale, PulseSensorPack] = 1;
$ItemMax[mfemale, DGNPack] = 1;
$ItemMax[mfemale, DeployableSensorJammerPack] = 1;
$ItemMax[mfemale, CameraPack] = 1;
$ItemMax[mfemale, TurretPack] = 1;
$ItemMax[mfemale, LaserTurretPack] = 1;
$ItemMax[mfemale, AmmoPack] = 1;
$ItemMax[mfemale, RepairKit] = 1;
$ItemMax[mfemale, DeployableInvPack] = 1;
$ItemMax[mfemale, DeployableAmmoPack] = 1;
$ItemMax[mfemale, ForceScreen] = 1;
$ItemMax[mfemale, Barricade] = 1;
$ItemMax[mfemale, TeleportField] = 1;
$ItemMax[mfemale, TeleportPad] = 1;
$ItemMax[mfemale, ChaingunTurret] = 1;
$ItemMax[mfemale, RemoteAutoCannon] = 1;
$ItemMax[mfemale, RemoteAACannon] = 1;
$ItemMax[mfemale, RemotePlasmaTurret] = 1;
$ItemMax[mfemale, MissileTurret] = 1;
$ItemMax[mfemale, RemoteELF] = 1;
$ItemMax[mfemale, StealthMine] = 1;
$ItemMax[mfemale, AntiArmorMine] = 1;

$ItemMax[mfemale, EMPBeaconPack] = 1;
$ItemMax[mfemale, PowerGeneratorPack] = 1;
$ItemMax[mfemale, ShieldBeaconPack] = 1;
$ItemMax[mfemale, EmplacementPack] = 1;
$ItemMax[mfemale, PortInvPack] = 0;

$MaxWeapons[mfemale] = 4;

//------------------
// light armor data:
//------------------

DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};

PlayerData larmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 25;
   minJetEnergy = 1;
   jetForce = 240;
   jetEnergyDrain = 0.7;

   maxDamage = 0.8;
   maxForwardSpeed = 16;
   maxBackwardSpeed = 13;
   maxSideSpeed = 13;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 70;
   drag = 1.3;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 80;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//**********************
// Combat Armor Data
//**********************
PlayerData carmor
{
   className = "Armor";
   shapeFile = "larmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.9;
   maxJetForwardVelocity = 20;
   minJetEnergy = 1;
   jetForce = 230;
   jetEnergyDrain = 0.9;

   maxDamage = 1.2;
   maxForwardSpeed = 12.0;
   maxBackwardSpeed = 11.0;
   maxSideSpeed = 11.0;
   groundForce = 35 * 13.0;
   mass = 10.0;
   groundTraction = 3.0;
	
   maxEnergy = 90;
   drag = 1.0;
   density = 1.3;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 115;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium Armor data:
//------------------------------------------------------------------

PlayerData marmor
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 0.9;

   maxDamage = 1.3;
   maxForwardSpeed = 9.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
   maxEnergy = 90;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Assault Armor data:
//------------------------------------------------------------------

PlayerData harmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 12;
   minJetEnergy = 1;
   jetForce = 400;
   jetEnergyDrain = 1.0;

   maxDamage = 1.8;
   maxForwardSpeed = 5.5;
   maxBackwardSpeed = 5.0;
   maxSideSpeed = 5;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 150;
   drag = 1.0;
   density = 2.5;
   horzVelClamp = 21;
   canCrouch = false;

   minDamageSpeed = 25;
   damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};



//***********************************
//Defender Armor Data
//***********************************

PlayerData darmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
   debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
   mapFilter = 1;
   mapIcon = "M_player";

   maxJetSideForceFactor = 1.0;
   maxJetForwardVelocity = 5.5;
   minJetEnergy = 1;
   jetForce = 525;
   jetEnergyDrain = 1.3;

   maxDamage = 1.4;
   maxForwardSpeed = 2.75;
   maxBackwardSpeed = 2.5;
   maxSideSpeed = 2.5;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 24.0;
   maxEnergy = 220;
   drag = 2.0;
   density = 3.0;
   canCrouch = false;

   minDamageSpeed = 25;
   damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
   // firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// Light female data:
//------------------------------------------------------------------

PlayerData lfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 25;
   minJetEnergy = 1;
   jetForce = 240;
   jetEnergyDrain = 0.7;

   maxDamage = 0.8;
   maxForwardSpeed = 16;
   maxBackwardSpeed = 13;
   maxSideSpeed = 13;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 70;
   drag = 2.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 80;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };


   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.85;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.88;
   boxCrouchTorsoPercentage = 0.35;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//**********************
// Female Combat Armor Data
//**********************
PlayerData fcarmor
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.9;
   maxJetForwardVelocity = 20;
   minJetEnergy = 1;
   jetForce = 230;
   jetEnergyDrain = 0.9;

   maxDamage = 1.2;
   maxForwardSpeed = 12.0;
   maxBackwardSpeed = 11.0;
   maxSideSpeed = 11.0;
   groundForce = 35 * 13.0;
   mass = 10.0;
   groundTraction = 3.0;
	
   maxEnergy = 90;
   drag = 1.0;
   density = 1.2;

   minDamageSpeed = 25;
   damageScale = 0.005;

   jumpImpulse = 115;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };


   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium female data:
//------------------------------------------------------------------

PlayerData mfemale
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 0.9;

   canCrouch = false;
   maxDamage = 1.3;
   maxForwardSpeed = 9.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	maxEnergy = 90;
   mass = 13.0;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
//
//------------------------------------------------------------------



//------------------------------------------------------------------
// SCV Armor data:
//------------------------------------------------------------------

PlayerData scvarmor
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";


   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 10;
   minJetEnergy = 1;
   jetForce = 375;
   jetEnergyDrain = 0.9;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 12;
   minJetEnergy = 1;
   jetForce = 440;
   jetEnergyDrain = 0.9;

	maxDamage = 1.1;
   maxForwardSpeed = 10.0;
   maxBackwardSpeed = 6.0;
   maxSideSpeed = 6.0;
   groundForce = 35 * 18.0;
   mass = 17.0;
   groundTraction = 3.5;
	
	maxEnergy = 150;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 180;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

