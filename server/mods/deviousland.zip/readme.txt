Welcome to DeviousLand the MOD!


To run this server-side mod, make a directory in your tribes directory called "deviousland"

copy the scripts.vol into that folder.

when starting tribes, use  "Tribes.exe -mod deviousland"

or for dedicated servers, use "infinitespawn *tribes -mod deviousland -dedicated"

if you are using the deviousland maps, extract all of their files into your base\missions\  directory.

the maps Vandalwood, Gantry, and Triptych were originally designed to be played with Vandals versus Empire, with Arbiters as the third team.

DeviousLand features four unique teams (more may follow).  
Each team is allowed to purchase unique armors and weapons
thru a system of TeamTags.  TeamTags currently work based
on the name of the teams that are playing.


	For instance: if Team 0 is called "Vandals" then they
can buy Vandal Kinetic Armor, Vandal Sniper Suit, Vandal Hologram, Kinetic DeathTouch, Vandal HyperBlaster, and the Vandal Interceptor.

Currently, people seem to want different teams fighting, so the instance of 
a Vandals versus Vandals battle has not arisen.  It could be easily implemented, but both teams would be using the same name, which could be confusing.   

***************** To setup the order of the teams on your server *********

			you can do it two ways:
			the first is by changing the lines 
			in your serverprefs.cs file	
			to read (in whatever order you want)

		    $server::teamName0 = "Arbiters";
		    $server::teamName1 = "Vandals";
		    $server::teamName2 = "Empire";
	  	    $server::teamName3 = "Insatiable";


			the second way to change the teams can be done in-game
			by typing one of the above lines in the console, but
			the changes will only take effect when the level changes.


* Note - These names must be spelled exactly!			


The first two teams named are usually the ones people will use, unless MultipleTeam maps are being played.  It might be a good idea to name the higher up teams #3 -#7 to Arbiters, Empire, Vandals, or Insatiable so that people are not left with normal equipment in a multi-team map.


			in order to make this a completely server-side mod, 
			i have not implemented any new skins,
			the skin for Vandals is "green",

				for Empire is "orange",

				for Arbiters is "purple",

				for Insatiable is "beagle".

*these skins will automatically kick in during play, but for some reason
only after you have played at least one mission with the current team lineup...
So, after switching the teams around, the first mission of the first game
may have wrong colored teams unless you specify them in your serverprefs.


Deviousland, the mod, has been playtested extensively, and weeks of gameplay have shown that no one team is better at dominating a game than another.  People always complain that the other team has better stuff, but they may not fully understand what their stuff does.  On maps with a lot of open space, Vandals seem to have an edge.  Empire has an advantage in Capture and Hold because of their walls and Arbiters have an advantage on levels with floating structures/bases because they can fly.  Insatiables have not been tested as much, may still be a little too powerful.


There are known errors, such as a message of Player::getItemCount couldn't find player.  The mod may crash at some point, but it should respawn normally (if dedicated with infinitespawn). The mod is unfinished, but it is ready to distribute.  Hope you have fun with it. 

The Mod uses many addable items which may slow down gameplay in long games.  You will probably want to lower the number of people allowed on your server.  Running a P2 350, i can have a 30 player game usually but i don't usually allow more than 22 on the Mod server.  


if you have questions, comments, suggestions, or errors to report
contact Mojica (misterdevious@hotmail.com)

for more Deviousness go to http://members.xoom.com/mrdevious/




---Mojica