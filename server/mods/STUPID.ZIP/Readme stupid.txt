To use this mod create a new folder called scripts, then
put the unzip the files and put them in it, then create another 
folder called stupid, and put the scripts folder in it, then be sure 
to put the stupid folder in your Tribes directory, and finally add 
-mod stupid to your command line.

Sorry it's so complicated, but I'm not familiar with winzip:^P

Report any problems to ATruex6542@aol.com thx and I hope you enjoy!!!