This is DuelMOD.

To install, simply unzip the file into your Tribes directory.
It will place DuelMOD.cs into your base directory, and the DuelMap into the base/missions directory.
To change the map from ctf to duel, just change the mission.  Duel is it's own mission type.
You might have to restart the server very quickly to do this, it's simple.

If there's any questions, email me at shihan@midsouth.rr.com

Enjoy

- Drink|Kahlua