//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\\
//                                         .:(Genocide):.                                                       \\
//                                          Server Prefs                                                        \\
//                                 Modification By: .:(A):.SlipKnot                                             \\
//                             Administration Coded By: ]|420|[*CraCka                                          \\
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\\


//------------------------
$AutoBanTime = "18000000";  //Ban time of a player in seconds
//------------------------


//------------------------
$CodeRed::LowScore = "On";  //Auto-Kicks player if score reaches -10
$CodeRed::AntiTK = "On";    //Auto-Kicks player if he/she TK's 4 times
//------------------------


//------------------------
$VoteKick = "False";        //Allows Regular Players to Vote to KICK
$VoteAdmin = "False";       //Allows Regular Players to Vote to ADMIN
//------------------------


//----------------------------
//Banned Names Upto 100 blocks *Note* you must match ARMBAN name with the players IP in ARMBANIP
//----------------------------
$ArmBan[0] = "";
$ArmBan[1] = "";
$ArmBan[2] = "";
$ArmBan[3] = "";
$ArmBan[4] = "";
$ArmBan[5] = "";
$ArmBan[6] = "";
$ArmBan[7] = "";
$ArmBan[8] = "";
$ArmBan[9] = "";
//---------------------------


//-----------------------------
//Banned IPs upto 100 IP Blocks *Note* IP must match name above
//-----------------------------
$ArmBanIP[0] = "";
$ArmBanIP[1] = "";
$ArmBanIP[2] = "";
$ArmBanIP[3] = "";
$ArmBanIP[4] = "";
$ArmBanIP[5] = "";
$ArmBanIP[6] = "";
$ArmBanIP[7] = "";
$ArmBanIP[8] = "";
$ArmBanIP[9] = "";
//-----------------------------


//----------------------------------------------------
// Admin Data - 4 Levels of admin
//
// "Server Master" or Owner Admin
// "God" or God Admin
// "Demi-God" or Super Admin
// "Fetus" or Public Admin
//_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-
//    *READ THIS*
// You can set upto 20 God,Demi-God
// and Fetus Admin names and password
// but only *1* Owner Name and Password
// To setup a player with admin you must 
// first choose his or her level of admin
// Next choose his or her private PW to login
// *Note* you must have his or her game name 
// Spelled perfect it is case sensitive.
//-=-=-=-=-=-=-=-=-=EXAMPLE-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//
// IE $SuperPassword[0] = "heythere";
//    $SuperName[0] = ".:(A):.SlipKnot
//
//
// What this allows is multiple pws for ppl
// but it also acts as an alarm if say 
// .:(A):.Kevin:. tried to login with that pw
// it would alert everyone on the server
// So only the name that is on the $SuperName
// Can login with the password for that specific name
//----------------------------------------------------

//++++++++++++++++++++++++++++++++++
$OwnerPassword[0] = "YourPW";
$OwnerName[0] = "YourName";
//++++++++++++++++++++++++++++++++++


//==================================
// Telenet & Console Log Options
//==================================
$TelnetPort = 8888;
$TelnetPassword = "YourTelenetPW";
//==================================
// Make this value to "2" to produce 
// server logs. Set to "0" for no 
// log.
// The server log will appear as
// console.log in the TRIBES folder
//==================================
$console::logmode = "2";
//==================================


//----------------------------------
// God Admin Logins
//----------------------------------
$GodPassword[0] = "ChangePW";
$GodName[0] = "ChangeName";

$GodPassword[1] = "ChangePW";
$GodName[1] = "ChangeName";

$GodPassword[2] = "ChangePW";
$GodName[2] = "ChangeName";

$GodPassword[3] = "ChangePW";
$GodName[3] = "ChangeName";

$GodPassword[4] = "ChangePW";
$GodName[4] = "ChangeName";

$GodPassword[5] = "ChangePW";
$GodName[5] = "ChangeName";
//----------------------------------


//----------------------------------
// Demi-God Or Super Admin Logins
//----------------------------------
$SuperPassword[0] = "ChangePW";
$SuperName[0] = "ChangeName";

$SuperPassword[1] = "ChangePW";
$SuperName[1] = "ChangeName";

$SuperPassword[2] = "ChangePW";
$SuperName[2] = "ChangeName";

$SuperPassword[3] = "ChangePW";
$SuperName[3] = "ChangeName";

$SuperPassword[4] = "ChangePW";
$SuperName[4] = "ChangeName";

$SuperPassword[5] = "ChangePW";
$SuperName[5] = "ChangeName";
//----------------------------------


//----------------------------------
// Fetus or Public Admin Logins
//----------------------------------
$PublicPassword[0] = "ChangePW";
$PublicName[0] = "ChangeName";

$PublicPassword[1] = "ChangePW";
$PublicName[1] = "ChangeName";

$PublicPassword[2] = "ChangePW";
$PublicName[2] = "ChangeName";

$PublicPassword[3] = "ChangePW";
$PublicName[3] = "ChangeName";

$PublicPassword[4] = "ChangePW";
$PublicName[4] = "ChangeName";

$PublicPassword[5] = "ChangePW";
$PublicName[5] = "ChangeName";
//----------------------------------

//---------------------
// Admin Logouts - Do not edit or the function becomes useless
//---------------------
$Logout = "Logout";
$Logout2 = "logout";
//---------------------


//-------------------------------------------------------
// Server Information that the mod runs 
// when you hit tab and select Server Info option
// Edit to fit your Prefs
//-------------------------------------------------------
$OwnerName = "Your Name";
$Clan = "YourClan or N/A";
$ClanTag = "Clan Tag Here";
$ClanSite = "Clan URL Here";
$Admin = "Admins Names";
$Rules = "\n<jc><f3>1. <F2>No Spawn Killing\n<F3>2. <F2>No Off-Side Turreting\n<F3>3. <F2>No TKing\n<F3>4. <F2>No Cammping.";
//-------------------------------------------------------
// The rules above are just the rules i've played with 
// since i started playing, Edit to your liking
//--------------------------------------------------------


//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
// Basic Server Prefs
//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-


//__________Server Skins & Team Names____________
$Server::teamName[0] = ".:(A):.";
$Server::teamSkin[0] = "AnarchyXxX";
$Server::teamName[1] = "+]-[+";
$Server::teamSkin[1] = "HybridOriginalv2K3";
$Server::teamName[2] = "]|420|[";
$Server::teamSkin[2] = "cphoenix";
$Server::teamName[3] = "=151=";
$Server::teamSkin[3] = "AnarchyAssault";
$Server::teamName[4] = "Generic 1";
$Server::teamSkin[4] = "base";
$Server::teamName[5] = "Generic 2";
$Server::teamSkin[5] = "base";
$Server::teamName[6] = "Generic 3";
$Server::teamSkin[6] = "base";
$Server::teamName[7] = "Generic 4";
$Server::teamSkin[7] = "base";


$Server::MaxPlayers = "10";
$Server::HostPublicGame = true;
$Server::AutoAssignTeams = true;
$Server::Port = "28001";

$Server::timeLimit = 60;
$Server::warmupTime = 5;

if($pref::lastMission == "")
   $pref::lastMission = Raindance;

$Server::MinVoteTime = 45;
$Server::VotingTime = 20;
$Server::VoteWinMargin = 0.55;
$Server::VoteAdminWinMargin = 0.66;
$Server::MinVotes = 1;
$Server::MinVotesPct = 0.5;
$Server::VoteFailTime = 30; // 30 seconds if your vote fails + $Server::MinVoteTime

$Server::TourneyMode = false;
$Server::TeamDamageScale = 0;

$Server::Info = "<jc><f1>Genocide\n<f3>Admin: <f2>YourName\n<f3>Email: <f2>YourE-Mail@Host.com\n<f3>Mod Info: <f2>www.TeamHybrid.Org";
$Server::JoinMOTD = "<jc><f2>Message of the day:\nThis is Genocide By: <f3>.:(A):.SlipKnot\n<f1>Welcome To <F2>My <F1>Realm\nFew Rules Here:\n<f3>1. No Spawn Killing\n2. No Off-Side Turreting\n3. No TKing\n4. No Cammping\nFire For Chaos!!!";

$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "US Tribes Master";//100
$Server::MasterName1 = "UK Tribes Master";
$Server::MasterName2 = "Australian Tribes Master";
$Server::CurrentMaster = 0;

$Server::respawnTime = 1; // number of seconds before a respawn is allowed

// default translated masters:
$Server::XLMasterN0 = "IP:209.185.222.237:28000";
$Server::XLMasterN1 = "IP:209.67.28.148:28000";
$Server::XLMasterN2 = "IP:198.74.40.67:28000";
$Server::FloodProtectionEnabled = true;


