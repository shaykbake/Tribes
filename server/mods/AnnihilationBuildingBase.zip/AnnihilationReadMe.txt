Version 1.20

Directions:
Unzip these files into your Tribes directory.  Use InfiniteSpawn to run your server.  I recommend that you use InfiniteSpawn 1.1 as it can detect a server that is locked up.  The target path command for your server should read something like this:

C:\Games\Tribes\InfiniteSpawn.exe *28001tribes.exe -mod annihilation +exec serverConfig -dedicated

assuming your tribes path is c:\games\tribes\, you are using InfiniteSpawn 1.1 and your server is set to port 28001.

Please post your questions to the forum available on the Annihilation website www.zerovoid.net.

Good Luck getting everything running.


Sevnn

website - www.zerovoid.net
email - tatribes@yahoo.com