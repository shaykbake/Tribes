// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "player.cs"
// __________________________________________________________________________
//


function Player::leaveMissionArea(%player)
{
%cl = Player::getClient(%player);
Client::sendMessage(%cl,1,"You have left the mission area.");
%player.outArea=1;
alertPlayer(%player, 3);
}
function Player::checkLMATimeout(%player, %seqCount)
{
echo("MISC: Checking player timeout " @ %player @ " " @ %seqCount);
if(%player.dieSeqCount == %seqCount)
remoteKill(Player::getClient(%player));
}
function Player::enterMissionArea(%player)
{
%player.outArea="";
%player.dieSeqCount = 0;
%player.timeLeft = %player.timeLeft - (getSimTime() - %player.leaveTime);
}
function leaveMissionAreaDamage(%client)
{
%player = Client::getOwnedObject(%client);
if(%player.outArea == 1)
{
if(!Player::isDead(%player))
{
Player::setDamageFlash(%client,0.1);
GameBase::setDamageLevel(%player,GameBase::getDamageLevel(%player) + $Arena::OOBDamageIncrements);
schedule("leaveMissionAreaDamage(" @ %client @ ");",1);
}
else
{
playNextAnim(%client);
schedule("Client::onKilled(" @ %client @ "," @ %client @ "," @ $OOBDamageType @ ");",2);
}
}
}
function Player::onDamage(%this,%type,%value,%pos,%vec,%mom,%vertPos,%quadrant,%object)
{
if (Player::isExposed(%this))
{
%damagedClient = Player::getClient(%this);
%shooterClient = %object;
Player::applyImpulse(%this,%mom);
%friendlyfire = false;
if($teamplay && %damagedClient != %shooterClient && Client::getTeam(%damagedClient) == Client::getTeam(%shooterClient) )
{
if (%shooterClient != -1)
{
%curTime = getSimTime();
if ((%curTime - %this.DamageTime > 3.5 || %this.LastHarm != %shooterClient) && %damagedClient != %shooterClient && $Server::TeamDamageScale > 0)
{
%friendlyfire = true;
if(%type != $MineDamageType) {
Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ "!");
Client::sendMessage(%damagedClient,0,"You took Friendly Fire from " @ Client::getName(%shooterClient) @ "!");
}
else {
Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ " with your mine!");
Client::sendMessage(%damagedClient,0,"You just stepped on Teamate " @ Client::getName(%shooterClient) @ "'s mine!");
}
%this.LastHarm = %shooterClient;
%this.DamageStamp = %curTime;
}
}
%friendFire = $Server::TeamDamageScale;
}
else if(%type == $ImpactDamageType && Client::getTeam(%object.clLastMount) == Client::getTeam(%damagedClient))
{
%friendFire = $Server::TeamDamageScale;
}
else
{
%friendFire = 1.0;
}
if (!Player::isDead(%this))
{
%armor = Player::getArmor(%this);
if (%vertPos == "head" && %type == $LaserDamageType)
{
if (%armor == "harmor")  {
if(%quadrant == "middle_back" || %quadrant == "middle_front" || %quadrant == "middle_middle") {
%value += (%value * 0.3);
}
}
else {
%value += (%value * 0.3);
}
}
if (%type != -1 && %this.shieldStrength)
{
%energy = GameBase::getEnergy(%this);
%strength = %this.shieldStrength;
if (%type == $ShrapnelDamageType || %type == $MortarDamageType)
{
%strength *= 0.75;
}
%absorb = %energy * %strength;
if (%value < %absorb)
{
GameBase::setEnergy(%this,%energy - ((%value / %strength)*%friendFire));
%thisPos = getBoxCenter(%this);
%offsetZ =((getWord(%pos,2))-(getWord(%thisPos,2)));
GameBase::activateShield(%this,%vec,%offsetZ);
%value = 0;
}
else
{
GameBase::setEnergy(%this,0);
%value = %value - %absorb;
}
}
if (%value)
{
%weapontypestr = "";
%targetbodypart = "";
if (($ArenaDisplayHotShots == 1) && (Arena::MatchMode == 0) && (%damagedClient != %shooterClient))
{
if (%type == $ExplosionDamageType) {
%weapontypestr = "Disc Launcher";
}
else if (%type == $PlasmaDamageType) {
%weapontypestr = "Plasma Gun";
}
else if (%type == $LaserDamageType) {
%weapontypestr = "Laser Rifle";
}
if (%weapontypestr != "")
{
if (%vertPos == "head") {
%targetbodypart = "Head Shot";
}
}
}
%value = $DamageScale[%armor, %type] * %value * %friendFire;
%dlevel = GameBase::getDamageLevel(%this) + %value;
%spillOver = %dlevel - %armor.maxDamage;
GameBase::setDamageLevel(%this,%dlevel);
%flash = Player::getDamageFlash(%this) + %value * 2;
if (%flash > 0.75)
{
%flash = 0.75;
}
Player::setDamageFlash(%this,%flash);
if ((%weapontypestr != "") && (%targetbodypart != ""))
{
if ((%damagedClient != "") && (%damagedClient > 0) && (%shooterClient != "") && (%shooterClient > 0))
{
if (%value >= 0.27)
{
Client::sendMessage(%damagedClient, 0, "You just got hit by a " @ %weapontypestr @ " " @ %targetbodypart @ " from " @ Client::getName(%shooterClient));
Client::sendMessage(%shooterClient, 0, "You just hit a " @ %weapontypestr @ " " @ %targetbodypart @ " on " @ Client::getName(%damagedClient) @ " !");
%damagedClient.shotAtHeadShot++;
%shooterClient.shotHitHeadShot++;
}
}
}
if (%type != $BulletDamageType) {
if ((%damagedClient != "") && (%damagedClient > 0)) {
%damagedClient.shotAtTotal++;
if (%friendlyfire == true) {
%damagedClient.shotAtTD++;
}
}
if ((%shooterClient != "") && (%shooterClient > 0)) {
%shooterClient.shotHitTotal++;
if (%friendlyfire == true) {
%shooterClient.shotHitTD++;
}
}
}
else {
if ((%damagedClient != "") && (%damagedClient > 0)) {
%damagedClient.shotCGAtTotal++;
if (%friendlyfire == true) {
%damagedClient.shotCGAtTD++;
}
}
if ((%shooterClient != "") && (%shooterClient > 0)) {
%shooterClient.shotCGHitTotal++;
if (%friendlyfire == true) {
%shooterClient.shotCGHitTD++;
}
}
}
if (!Player::isDead(%this))
{
if(%damagedClient.lastDamage < getSimTime())
{
%sound = radnomItems(3,injure1,injure2,injure3);
playVoice(%damagedClient,%sound);
%damagedClient.lastdamage = getSimTime() + 1.5;
}
}
else
{
if (%spillOver > 0.5 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType|| %type == $MissileDamageType))
{
Player::trigger(%this, $WeaponSlot, false);
%weaponType = Player::getMountedItem(%this,$WeaponSlot);
if(%weaponType != -1)
{
Player::dropItem(%this,%weaponType);
}
Player::blowUp(%this);
}
else
{
if ((%value > 0.40 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType || %type == $MissileDamageType )) || (Player::getLastContactCount(%this) > 6) )
{
if(%quadrant == "front_left" || %quadrant == "front_right") {
%curDie = $PlayerAnim::DieBlownBack;
}
else {
%curDie = $PlayerAnim::DieForward;
}
}
else if (Player::isCrouching(%this))
{
%curDie = $PlayerAnim::Crouching;
}
else if (%vertPos=="head")
{
if(%quadrant == "front_left" ||	%quadrant == "front_right"	) {
%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieBack);
}
else {
%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieForward);
}
}
else if (%vertPos == "torso")
{
if(%quadrant == "front_left" ) {
%curDie = radnomItems(3, $PlayerAnim::DieLeftSide, $PlayerAnim::DieChest, $PlayerAnim::DieForwardKneel);
}
else if(%quadrant == "front_right") {
%curDie = radnomItems(3, $PlayerAnim::DieChest, $PlayerAnim::DieRightSide, $PlayerAnim::DieSpin);
}
else if(%quadrant == "back_left" ) {
%curDie = radnomItems(4, $PlayerAnim::DieLeftSide, $PlayerAnim::DieGrabBack, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
}
else if(%quadrant == "back_right") {
%curDie = radnomItems(4, $PlayerAnim::DieGrabBack, $PlayerAnim::DieRightSide, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
}
}
else if (%vertPos == "legs")
{
if(%quadrant == "front_left" ||	%quadrant == "back_left") {
%curDie = $PlayerAnim::DieLegLeft;
}
if(%quadrant == "front_right" ||	%quadrant == "back_right") {
%curDie = $PlayerAnim::DieLegRight;
}
}
Player::setAnimation(%this, %curDie);
}
if(%type == $ImpactDamageType && %object.clLastMount != "")  {
%shooterClient = %object.clLastMount;
}
Client::onKilled(%damagedClient,%shooterClient, %type);
}
}
}
}
}
$arenaplayer_cs_version = "$Revision: 10 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaPlayer.cs v" @ $Arena::Version @ ", internal version " @ $arenaplayer_cs_version);
