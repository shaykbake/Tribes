// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "game.cs"
// __________________________________________________________________________
//

function Game::refreshClientScore(%clientId)
{
%team = Client::getTeam(%clientId);
if(%team == -1) {
%teamForOrder = 9;
}
else {
%teamForOrder = %team;
}
%teamstr = getTeamName(%clientId.matchteam);
if (%teamstr == "0") {
%teamstr = "";
}
if (%clientId.matchTeam == -2) {
if (%clientId.lock == true) {
%teamstr = "[Obs]";
} else {
%teamstr = "(Obs)";
}
}
%admin = "";
if (%clientId.isServerSuperAdmin) {
if (%clientId.isServerSuperAdminInvisible) {
%admin = " ";
}
else {
%admin = $ArenaScoreListLetter_SuperAdmin;
}
}
else if (%clientId.isSuperAdmin) {
%admin = $ArenaScoreListLetter_SuperAdmin;
}
else if (%clientId.isTrustedAdmin) {
%admin = $ArenaScoreListLetter_TrustedAdmin;
}
else if (%clientId.isAdmin) {
%admin = $ArenaScoreListLetter_Admin;
}
else {
%admin = " ";
}
if (%clientId.isTeamCaptain)
%admin = %admin @ "T";
if ($UseNewScoringSystem == 1) {
%sortindicator = %clientId.scoreKillDeathRank + (9 - %teamForOrder) * 30000;
%scorekill = %clientId.scoreKills - %clientId.scoreTKs;
%scoredeath = %clientId.scoreDeaths - %clientId.scoreTKed;
Client::setScore(%clientId,  %clientId.onteam @ " %n\t" @ %teamstr @ "\t " @ %scorekill @ "/" @ %scoredeath @ "\t%p\t%l\t" @ %admin, %sortindicator);
}
else {
%sortindicator = %clientId.score + (9 - %teamForOrder) * 10000;
Client::setScore(%clientId,  %clientId.onteam @ " %n\t" @ %teamstr @ "\t  " @ %clientId.score  @ "\t%p\t%l\t" @ %admin, %sortindicator);
}
}
function Game::menuRequest(%clientId)
{
%curItem = 0;
Client::buildMenu(%clientId, "Options", "options", true);
if (!$matchStarted || !$Server::TourneyMode)
{
Client::addMenuItem(%clientId, %curItem++ @ "Change Teams/Observe", "changeteams");
}
if (%clientId.selClient)
{
%sel = %clientId.selClient;
%name = Client::getName(%sel);
if($curVoteTopic == "" && !%clientId.isAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Vote to admin " @ %name, "vadmin " @ %sel);
Client::addMenuItem(%clientId, %curItem++ @ "Vote to kick " @ %name, "vkick " @ %sel);
}
if(%clientId.isAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Kick " @ %name, "kick " @ %sel);
if (%clientId.isServerSuperAdmin) {
if (%sel.isServerSuperAdmin) {
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
else if (%sel.isAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Unadmin " @ %name, "unadmin " @ %sel);
}
else
{
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
}
else if (%clientId.isSuperAdmin)
{
if (%sel.isServerSuperAdmin || %sel.isSuperAdmin) {
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
else if (%sel.isAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Unadmin " @ %name, "unadmin " @ %sel);
}
else
{
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
}
else if (%clientId.isTrustedAdmin)
{
if (%sel.isServerSuperAdmin || %sel.isSuperAdmin || %sel.isTrustedAdmin) {
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
else if (%sel.isAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Unadmin " @ %name, "unadmin " @ %sel);
}
else
{
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
}
else
{
Client::addMenuItem(%clientId, %curItem++ @ "Admin " @ %name, "admin " @ %sel);
}
if (%clientId.isSuperAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Ban " @ %name, "ban " @ %sel);
}
Client::addMenuItem(%clientId, %curItem++ @ "Change " @ %name @ "'s team", "fteamchange " @ %sel);
}
else if (%clientId.isTeamCaptain)
{
Client::addMenuItem(%clientId, %curItem++ @ "Change " @ %name @ "'s team", "tfteamchange " @ %sel);
}
if(%clientId.muted[%sel])
Client::addMenuItem(%clientId, %curItem++ @ "Unmute " @ %name, "unmute " @ %sel);
else
Client::addMenuItem(%clientId, %curItem++ @ "Mute " @ %name, "mute " @ %sel);
if(%clientId.observerMode == "observerOrbit")
Client::addMenuItem(%clientId, %curItem++ @ "Observe " @ %name, "observe " @ %sel);
}
if (%clientId.selClient && %clientId.isServerSuperAdmin)
{
%sel = %clientId.selClient;
%name = Client::getName(%sel);
Client::addMenuItem(%clientId, %curItem++ @ "Player options", "playerdetails");
}
else
{
Client::addMenuItem(%clientId, %curItem++ @ "Arena Options", "arenaop");
}
if($curVoteTopic != "" && %clientId.vote == "")
{
Client::addMenuItem(%clientId, %curItem++ @ "Vote YES to " @ $curVoteTopic, "voteYes " @ $curVoteCount);
Client::addMenuItem(%clientId, %curItem++ @ "Vote NO to " @ $curVoteTopic, "voteNo " @ $curVoteCount);
}
else if($curVoteTopic == "" && !%clientId.isAdmin)
{
Client::addMenuItem(%clientId, %curItem++ @ "Vote to change mission", "vcmission");
}
else if (%clientId.isAdmin)
{
if($curVoteTopic == "" && %clientId.isAdmin && $AllAdminsCanVoteMaps == 1)
{
Client::addMenuItem(%clientId, %curItem++ @ "Vote to change mission", "vcmission");
}
Client::addMenuItem(%clientId, %curItem++ @ "Force mission change", "cmission");
if((%clientId.isSuperAdmin && $OnlySuperAdminCanResetServer == 1) || ($OnlySuperAdminCanResetServer != 1))
{
Client::addMenuItem(%clientId, %curItem++ @ "Reset Server Defaults", "reset");
}
}
}
function processMenuInitialPickTeam(%clientId, %team)
{
if ( (%team == "") || ((%team != "-2") && (%team != "-1") && (%team != "0") && (%team != "1") && (%team != "9")) ) {
Arena::TabMenuExploit(%clientId, "processMenuInitialPickTeam(" @ %clientId @ ", " @ %team @ ")");
}
else {
if($Server::TourneyMode && $matchStarted) {
%team = -2;
}
if(%team == -2) {
Observer::enterObserverMode(%clientId);
%clientId.matchteam = -2;
}
if(%team == -1) {
Game::assignClientTeam(%clientId);
%team = Client::getTeam(%clientId);
}
if(%team != -2) {
GameBase::setTeam(%clientId, %team);
if($TeamEnergy[%team] != "Infinite")
$TeamEnergy[%team] += $InitialPlayerEnergy;
%clientId.teamEnergy = 0;
Client::setControlObject(%clientId, -1);
Game::playerSpawn(%clientId, false);
%clientId.matchteam = %team;
if ($Arena::MatchStatus == 0 || $Arena::MatchStatus == 2)
{
%clientId.notready = true;
if ($Arena::ReadyTime && %team != -2)
{
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
schedule("Arena::CheckReadyState(" @ %clientId @ ");", $ArenaCheckReadyStateDurationReadyUpDisabled);
}
else {
schedule("Arena::CheckReadyState(" @ %clientId @ ");", $ArenaCheckReadyStateDuration);
}
}
}
}
}
Game::refreshClientScore(%clientId);
}
function processMenuTFPickTeam(%clientId, %team)
{
if(%clientId.isTeamCaptain) {
processMenuPickTeam(%clientId.ptc, %team, %clientId);
}
%clientId.ptc = "";
}
function processMenuOptions(%clientId, %option)
{
%opt = getWord(%option, 0);
%cl = getWord(%option, 1);
if (%opt == "fteamchange")
{
%clientId.ptc = %cl;
Client::buildMenu(%clientId, "Pick a team:", "FPickTeam", true);
Client::addMenuItem(%clientId, "0Observer", -2);
Client::addMenuItem(%clientId, "1Automatic", -1);
for(%i = 0; %i < getNumTeams(); %i = %i + 1)
client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
if (!%cl.lock)
Client::addMenuItem(%clientId, "9Observer/LockOut", 9);
return;
}
else if(%opt == "tfteamchange")
{
%clientId.ptc = %cl;
Client::buildMenu(%clientId, "Pick a team:", "TFPickTeam", true);
if (%cl.matchteam == -2)
Client::addMenuItem(%clientId, "0Your Team", %clientId.matchteam);
else if (%cl.matchteam == %clientId.matchteam)
Client::addMenuItem(%clientId, "0Observer", -2);
return;
}
else if(%opt == "changeteams")
{
if (($ArenaPlayersCantTeamThemselvesPreMatchMode == 1) && ($Arena::MatchMode == 1)) {
Client::buildMenu(%clientId, "Pick a team:", "PickTeam", true);
Client::addMenuItem(%clientId, "0Admin must do teams", -2);
return;
}
else {
if(!$matchStarted || !$Server::TourneyMode)
{
Client::buildMenu(%clientId, "Pick a team:", "PickTeam", true);
if (%clientId.lock) {
Client::addMenuItem(%clientId, "9Observer/UnLockMe", 9);
}
else {
Client::addMenuItem(%clientId, "0Observer", -2);
if (($Arena::MatchMode == 1) || (%clientId.matchTeam == -2))
{
Client::addMenuItem(%clientId, "1Automatic", -1);
if ((%clientId.isServerSuperAdmin) || ($Arena::MatchMode == 1)) {
for(%i = 0; %i < getNumTeams(); %i = %i + 1) {
Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
}
}
}
Client::addMenuItem(%clientId, "9Observer/LockMeOut", 9);
}
return;
}
}
}
else if(%opt == "mute")
{
%clientId.muted[%cl] = true;
%clientId.mutedName[%cl] = Client::getName(%cl);
}
else if(%opt == "unmute")
{
%clientId.muted[%cl] = "";
%clientId.mutedName[%cl] = "";
}
else if(%opt == "globalmute")
{
%cl.mutedGlobal = true;
%cl.mutedGlobalWarned = false;
%cl.mutedGlobalName = Client::getName(%cl);
if ($GlobalMuteDuration != 0)
{
%mutemin = floor($GlobalMuteDuration / 60);
%mutesec = $GlobalMuteDuration - %mutemin*60;
%muteduration = "";
if (%mutemin > 0) {
%muteduration = %mutemin @ " minute";
if (%mutemin > 1) {
%muteduration = %muteduration @ "s";
}
}
if (%mutesec > 0) {
if (%muteduration != "") {
%muteduration = %muteduration @ " ";
}
%muteduration = %muteduration @ %mutesec @ " second";
if (%mutesec > 1) {
%muteduration = %muteduration @ "s";
}
}
Client::sendMessage(%cl,1,"You have been globally muted for " @ %muteduration @ ".");
schedule("Arena::RemoveGlobalUnmute(" @ %cl @");", $GlobalMuteDuration);
}
else
{
Client::sendMessage(%cl,1,"You have been globally muted.");
}
}
else if(%opt == "globalunmute")
{
Arena::RemoveGlobalUnmute(%cl);
}
else if(%opt == "vkick")
{
%cl.voteTarget = true;
Admin::startVote(%clientId, "kick " @ Client::getName(%cl), "kick", %cl);
}
else if(%opt == "vadmin")
{
if (%cl.isAdmin) {
Client::sendMessage(%clientId, 1, "Can't vote to admin " @ Client::getName(%cl) @ " : he/she is already an admin.");
}
else {
if ($ArenaMaxNumberOfAdmins == 0) {
Client::sendMessage(%clientId, 1, "Server is configured to prevent admin votes. Vote cancelled.");
}
else if ($ArenaMaxNumberOfAdmins < 0) {
%cl.voteTarget = true;
Admin::startVote(%clientId, "admin " @ Client::getName(%cl), "admin", %cl);
}
else {
%admCnt = Arena::CountNumberOfAdmins(-1);
if (%admCnt < $ArenaMaxNumberOfAdmins) {
%cl.voteTarget = true;
Admin::startVote(%clientId, "admin " @ Client::getName(%cl), "admin", %cl);
}
else {
Client::sendMessage(%clientId, 1, "There are enough admins at this time. Vote cancelled.");
}
}
}
}
else if(%opt == "vetd")
{
Admin::startVote(%clientId, "enable team damage", "etd", 0);
}
else if(%opt == "vdtd")
{
Admin::startVote(%clientId, "disable team damage", "dtd", 0);
}
else if(%opt == "etd")
{
Admin::setTeamDamageEnable(%clientId, true);
}
else if(%opt == "dtd")
{
Admin::setTeamDamageEnable(%clientId, false);
}
else if (%opt == "voteYes" && %cl == $curVoteCount)
{
%clientId.vote = "yes";
centerprint(%clientId, "", 0);
}
else if(%opt == "voteNo" && %cl == $curVoteCount)
{
%clientId.vote = "no";
centerprint(%clientId, "", 0);
}
else if(%opt == "kick")
{
Client::buildMenu(%clientId, "Confirm kick:", "kaffirm", true);
Client::addMenuItem(%clientId, "8Kick " @ Client::getName(%cl), "yes " @ %cl);
Client::addMenuItem(%clientId, "9Don't kick " @ Client::getName(%cl), "no " @ %cl);
return;
}
else if(%opt == "ban")
{
Client::buildMenu(%clientId, "Confirm Ban:", "baffirm", true);
Client::addMenuItem(%clientId, "8Ban " @ Client::getName(%cl), "yes " @ %cl);
Client::addMenuItem(%clientId, "9Don't ban " @ Client::getName(%cl), "no " @ %cl);
return;
}
else if(%opt == "permaban")
{
Client::buildMenu(%clientId, "Confirm Perma-Ban:", "pbaffirm", true);
Client::addMenuItem(%clientId, "8Perma-Ban " @ Client::getName(%cl), "yes " @ %cl);
Client::addMenuItem(%clientId, "9Don't Perma-Ban " @ Client::getName(%cl), "no " @ %cl);
return;
}
else if(%opt == "admin")
{
Client::buildMenu(%clientId, "Confirm admim:", "aaffirm", true);
if (%clientId.isSuperAdmin) {
Client::addMenuItem(%clientId, "1A-Admin " @ Client::getName(%cl), "yes " @ %cl);
Client::addMenuItem(%clientId, "2M-Admin " @ Client::getName(%cl), "yesM " @ %cl);
Client::addMenuItem(%clientId, "3S-Admin " @ Client::getName(%cl), "yesS " @ %cl);
Client::addMenuItem(%clientId, "4Don't admin " @ Client::getName(%cl), "no " @ %cl);
}
else {
Client::addMenuItem(%clientId, "1Admin " @ Client::getName(%cl), "yes " @ %cl);
Client::addMenuItem(%clientId, "2Don't admin " @ Client::getName(%cl), "no " @ %cl);
}
return;
}
else if(%opt == "unadmin")
{
Client::buildMenu(%clientId, "Confirm unadmim:", "uaaffirm", true);
Client::addMenuItem(%clientId, "1Unadmin " @ Client::getName(%cl), "yes " @ %cl);
Client::addMenuItem(%clientId, "2Don't unadmin " @ Client::getName(%cl), "no " @ %cl);
return;
}
else if(%opt == "smatch")
{
Admin::startMatch(%clientId);
}
else if(%opt == "vcmission")
{
Admin::changeMissionMenu(%clientId, %opt);
return;
}
else if(%opt == "cmission")
{
Admin::changeMissionMenu(%clientId, %opt);
return;
}
else if (%opt == "cwinscore")
{
if ((%clientId.isServerSuperAdmin) || ($ArenaFixedWinningScore != 1) || ($Arena::MatchMode == 1)) {
Client::buildMenu(%clientId, "Change Winning Score:", "cwscore", true);
if (%clientId.isSuperAdmin) {
Client::addMenuItem(%clientId, "01 out of 1", 1);
Client::addMenuItem(%clientId, "12 out of 3", 2);
}
Client::addMenuItem(%clientId, "23 out of 5", 3);
Client::addMenuItem(%clientId, "34 out of 7", 4);
Client::addMenuItem(%clientId, "45 out of 9", 5);
if ($Arena::ScorelimitMax >= 6)
Client::addMenuItem(%clientId, "56 out of 11", 6);
if ($Arena::ScorelimitMax >= 7)
Client::addMenuItem(%clientId, "67 out of 13", 7);
if ($Arena::ScorelimitMax >= 8)
Client::addMenuItem(%clientId, "78 out of 15", 8);
if ($Arena::ScorelimitMax >= 9)
Client::addMenuItem(%clientId, "89 out of 17", 9);
if ($Arena::ScorelimitMax >= 10)
Client::addMenuItem(%clientId, "910 out of 19", 10);
}
return;
}
else if (%opt == "resetmatch")
{
Arena::ResetMatch();
messageall(0, Client::getName(%clientId) @ " has reset the match.");
return;
}
else if (%opt == "rerandomteams")
{
Client::buildMenu(%clientId, "Team:", "rrndteams", true);
Client::addMenuItem(%clientId, "1Only teamed players", "teamed " @ %clientId);
Client::addMenuItem(%clientId, "2All connected players", "all " @ %clientId);
return;
}
else if (%opt == "pskinoff")
{
%clientId.customSkin = false;
for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
Client::setSkin(%cl, $Server::teamSkin[Client::getTeam(%cl)]);
}
Client::sendMessage(%clientId, 1, "You have DISABLED Personal Skins (PSkin).");
return;
}
else if (%opt == "pskinon")
{
%clientId.customSkin = true;
if ($Arena::MatchMode == 0) {
for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
Client::setSkin(%cl, $Client::info[%cl, 0]);
}
Client::sendMessage(%clientId, 1, "You have ENABLED Personal Skins (PSkin).");
}
else {
for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
Client::setSkin(%cl, $Server::teamSkin[Client::getTeam(%cl)]);
}
Client::sendMessage(%clientId, 1, "You have ENABLED Personal Skins (PSkin), but skins will not be shown until server is in Public mode.");
}
return;
}
else if (%opt == "forcematch")
{
if (($Arena::MatchMode == 1) || ($Arena::MatchStatus == 0) || ($Arena::ForceMatchAcceptOverride == 1))
{
messageall(0, Client::getName(%clientId) @ " has forced the countdown to start");
Arena::ForceMatchStart();
}
return;
}
else if (%opt == "ereadytime")
{
$Arena::ReadyTime = true;
messageAll(0, Client::getName(%clientId) @ " has enabled ReadyUp Time Limit.");
return;
}
else if (%opt == "dreadytime")
{
$Arena::ReadyTime = false;
messageAll(0, Client::getName(%clientId) @ " has disabled ReadyUp Time Limit.");
return;
}
else if (%opt == "eautoteam")
{
$Arena::AutoTeamJoin = true;
messageAll(0, Client::getName(%clientId) @ " has enabled AutoTeamJoin.");
return;
}
else if (%opt == "dautoteam")
{
$Arena::AutoTeamJoin = false;
messageAll(0, Client::getName(%clientId) @ " has disabled AutoTeamJoin.");
return;
}
else if (%opt == "cstrip")
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.isSuperAdmin)
{
if (%clientId.isServerSuperAdmin)
{
if (! %cl.isServerSuperAdmin)
{
%cl.isAdmin = false;
%cl.isTrustedAdmin = false;
%cl.isSuperAdmin = false;
Game::refreshClientScore(%cl);
}
}
}
else if (%cl.isTrustedAdmin)
{
if (%clientId.isSuperAdmin)
{
%cl.isAdmin = false;
%cl.isTrustedAdmin = false;
Game::refreshClientScore(%cl);
}
}
else if (%cl.isAdmin)
{
%cl.isAdmin = false;
Game::refreshClientScore(%cl);
}
}
messageAll(0, Client::getName(%clientId) @ " has stripped admin rights from the public.");
return;
}
else if (%opt == "givecaptain")
{
if (%clientId.matchteam == %cl.matchteam)
{
%clientId.isTeamCaptain = false;
%cl.isTeamCaptain = true;
messageAll(0, Client::getName(%clientId) @ " has handed over the Team Captain rights to " @ Client::getName(%cl));
Game::refreshClientScore(%cl);
Game::refreshClientScore(%clientId);
}
return;
}
else if (%opt == "ematchmode")
{
if ($PubAdminsMayNotChangePubMatchMode == 1) {
if (%clientId.isSuperAdmin) {
}
else if (%clientId.isTrustedAdmin) {
}
else if (%clientId.isAdmin) {
return;
}
}
messageAll(0, Client::getName(%clientId) @ " has put the server into Match Mode.");
Arena::EnterMatchMode();
return;
}
else if (%opt == "epubmode")
{
if ($PubAdminsMayNotChangePubMatchMode == 1) {
if (%clientId.isSuperAdmin) {
}
else if (%clientId.isTrustedAdmin) {
}
else if (%clientId.isAdmin) {
return;
}
}
messageAll(0, Client::getName(%clientId) @ " has put the server into Public Play Mode.");
Arena::EnterPubMode();
return;
}
else if(%opt == "ctimelimit")
{
if((%clientId.isSuperAdmin && $OnlySuperAdminCanChangeTimeLimit == 1) || ($OnlySuperAdminCanChangeTimeLimit != 1))
{
Client::buildMenu(%clientId, "Change Time Limit:", "ctlimit", true);
Client::addMenuItem(%clientId, "110 Minutes", 10);
Client::addMenuItem(%clientId, "215 Minutes", 15);
Client::addMenuItem(%clientId, "320 Minutes", 20);
Client::addMenuItem(%clientId, "425 Minutes", 25);
Client::addMenuItem(%clientId, "530 Minutes", 30);
Client::addMenuItem(%clientId, "645 Minutes", 45);
Client::addMenuItem(%clientId, "760 Minutes", 60);
Client::addMenuItem(%clientId, "8No Time Limit", 0);
return;
}
}
else if(%opt == "reset")
{
if((%clientId.isSuperAdmin && $OnlySuperAdminCanResetServer == 1) || ($OnlySuperAdminCanResetServer != 1))
{
Client::buildMenu(%clientId, "Confirm Reset:", "raffirm", true);
Client::addMenuItem(%clientId, "1Reset", "yes");
Client::addMenuItem(%clientId, "2Don't Reset", "no");
return;
}
}
else if(%opt == "observe")
{
Observer::setTargetClient(%clientId, %cl);
return;
}
else if (%opt == "playerdetails")
{
%curItem = 0;
Client::buildMenu(%clientId, "Player Details", "options", true);
if(%clientId.isServerSuperAdmin)
{
%sel = %clientId.selClient;
%name = Client::getName(%sel);
%ip = Client::getTransportAddress(%sel);
Client::addMenuItem(%clientId, %curItem++ @ "Perma-Ban " @ %name, "permaban " @ %sel);
if(%sel.mutedGlobal)
Client::addMenuItem(%clientId, %curItem++ @ "Global Unmute " @ %name, "globalunmute " @ %sel);
else
Client::addMenuItem(%clientId, %curItem++ @ "Global Mute " @ %name, "globalmute " @ %sel);
Client::addMenuItem(%clientId, %curItem++ @ %ip @ " ", "");
}
return;
}
else if (%opt == "arenaop")
{
%curItem = 0;
Client::buildMenu(%clientId, "Options", "options", true);
if (%clientId.isAdmin)
{
if ((%clientId.isServerSuperAdmin) || ($ArenaFixedWinningScore != 1) || ($Arena::MatchMode == 1)) {
Client::addMenuItem(%clientId, %curItem++ @ "Change Winning Score", "cwinscore");
}
Client::addMenuItem(%clientId, %curItem++ @ "Reset Match", "resetmatch");
Client::addMenuItem(%clientId, %curItem++ @ "Force Match/Game Start", "forcematch");
if((%clientId.isSuperAdmin && $OnlySuperAdminCanChangeReadyUp == 1) || ($OnlySuperAdminCanChangeReadyUp != 1))
{
if ($DisableReadyUpTimer != 1)
{
if(!$Arena::Readytime)
Client::addMenuItem(%clientId, %curItem++ @ "Enable ReadyUp Timelimit", "ereadytime");
else
Client::addMenuItem(%clientId, %curItem++ @ "Disable ReadyUp Timelimit", "dreadytime");
}
}
if((%clientId.isSuperAdmin && $OnlySuperAdminCanChangeAutoJoin == 1) || ($OnlySuperAdminCanChangeAutoJoin != 1))
{
if(!$Arena::AutoTeamJoin)
Client::addMenuItem(%clientId, %curItem++ @ "Enable AutoTeamJoining", "eautoteam");
else
Client::addMenuItem(%clientId, %curItem++ @ "Disable AutoTeamJoining", "dautoteam");
}
if ($PubAdminsMayNotChangePubMatchMode == 1) {
if ((%clientId.isSuperAdmin) || (%clientId.isTrustedAdmin)) {
if(!$Arena::MatchMode) {
Client::addMenuItem(%clientId, %curItem++ @ "Enter Match Mode", "ematchmode");
}
else {
Client::addMenuItem(%clientId, %curItem++ @ "Enter Public Mode", "epubmode");
}
}
}
else {
if(!$Arena::MatchMode) {
Client::addMenuItem(%clientId, %curItem++ @ "Enter Match Mode", "ematchmode");
}
else {
Client::addMenuItem(%clientId, %curItem++ @ "Enter Public Mode", "epubmode");
}
}
if (%clientId.isSuperAdmin || (($TrustedAdminCanStripRegularAdmin == 1) && %clientId.isTrustedAdmin)) {
Client::addMenuItem(%clientId, %curItem++ @ "Strip Public Admins", "cstrip");
}
if($Arena::MatchMode == 0) {
Client::addMenuItem(%clientId, %curItem++ @ "Re-Randomize teams", "rerandomteams");
}
}
if(%clientId.isTeamCaptain && %clientId.selClient)
{
%sel = %clientId.selClient;
%name = Client::getName(%sel);
Client::addMenuItem(%clientId, %curItem++ @ "Make " @ %name @ " the Captain", "givecaptain " @ %sel);
}
if ($ArenaUseLabRatPSkin == 1) {
if (%clientId.customSkin == true) {
Client::addMenuItem(%clientId, %curItem++ @ "Disable Personal Skins", "pskinoff");
}
else {
Client::addMenuItem(%clientId, %curItem++ @ "Enable Personal Skins", "pskinon");
}
}
return;
}
Game::menuRequest(%clientId);
}
function processMenuAAffirm(%clientId, %opt)
{
if(%clientId.isAdmin)
{
%atype = getWord(%opt, 0);
if ((%atype == "yes") || (%atype == "yesM") || (%atype == "yesS"))
{
%cl = getWord(%opt, 1);
%isProhibited = Admin::LizCheckNoAdminIPList(%cl);
if (%isProhibited == 1)
{
Client::sendMessage(%clientId, 0, "You can not make " @ Client::getName(%cl) @ " into an admin.");
}
else
{
if ($ArenaMaxNumberOfAdmins == 0) {
Client::sendMessage(%clientId, 0, "The server administrator has disabled this feature.");
}
else if ($ArenaMaxNumberOfAdmins < 0) {
if ((%atype == "yesS") && (%clientId.isSuperAdmin)) {
%cl.isSuperAdmin = true;
%cl.isTrustedAdmin = true;
%cl.isAdmin = true;
messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into a Super admin.");
bottomprint(%cl, "<jc><f0>You have been made <f2>Super Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
else if ((%atype == "yesM") && (%clientId.isTrustedAdmin)) {
%cl.isTrustedAdmin = true;
%cl.isAdmin = true;
messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into a Moderator admin.");
bottomprint(%cl, "<jc><f0>You have been made <f2>Moderator Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
else {
%cl.isAdmin = true;
messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into an admin.");
bottomprint(%cl, "<jc><f0>You have been made <f2>Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
Game::refreshClientScore(%cl);
}
else {
%admCnt = Arena::CountNumberOfAdmins(-1);
if (%admCnt < $ArenaMaxNumberOfAdmins) {
if ((%atype == "yesS") && (%clientId.isSuperAdmin)) {
%cl.isSuperAdmin = true;
%cl.isTrustedAdmin = true;
%cl.isAdmin = true;
messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into a Super admin.");
bottomprint(%cl, "<jc><f0>You have been made <f2>Super Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
else if ((%atype == "yesM") && (%clientId.isTrustedAdmin)) {
%cl.isTrustedAdmin = true;
%cl.isAdmin = true;
messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into a Moderator admin.");
bottomprint(%cl, "<jc><f0>You have been made <f2>Moderator Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
else {
%cl.isAdmin = true;
messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into an admin.");
bottomprint(%cl, "<jc><f0>You have been made <f2>Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
Game::refreshClientScore(%cl);
}
else {
Client::sendMessage(%clientId, 0, "Your request to admin " @ Client::getName(%cl) @ " was denied because the number of admins limit (" @ $ArenaMaxNumberOfAdmins @ ") has been reached.");
}
}
}
}
}
Game::menuRequest(%clientId);
}
function processMenuUAAffirm(%clientId, %opt)
{
if(getWord(%opt, 0) == "yes")
{
%cl = getWord(%opt, 1);
if (%clientId.isServerSuperAdmin)
{
if (%cl.isServerSuperAdmin) {
Client::sendMessage(%clientId, 0, "Impossible to remove admin from " @ Client::getName(%cl));
}
else if (%cl.isAdmin)
{
%cl.isSuperAdmin = false;
%cl.isTrustedAdmin = false;
%cl.isAdmin = false;
messageAll(0, Client::getName(%clientId) @ " has removed admin from " @ Client::getName(%cl));
Game::refreshClientScore(%cl);
bottomprint(%cl, "<jc><f0>You have been <f2>stripped of your Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
}
else if (%clientId.isSuperAdmin)
{
if (%cl.isServerSuperAdmin || %cl.isSuperAdmin) {
Client::sendMessage(%clientId, 0, "Impossible to remove admin from " @ Client::getName(%cl));
}
else if (%cl.isAdmin)
{
%cl.isSuperAdmin = false;
%cl.isTrustedAdmin = false;
%cl.isAdmin = false;
messageAll(0, Client::getName(%clientId) @ " has removed admin from " @ Client::getName(%cl));
Game::refreshClientScore(%cl);
bottomprint(%cl, "<jc><f0>You have been <f2>stripped of your Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
}
else if (%clientId.isTrustedAdmin)
{
if (%cl.isServerSuperAdmin || %cl.isSuperAdmin || %cl.isTrustedAdmin) {
Client::sendMessage(%clientId, 0, "Impossible to remove admin from " @ Client::getName(%cl));
}
else if (%cl.isAdmin)
{
%cl.isSuperAdmin = false;
%cl.isTrustedAdmin = false;
%cl.isAdmin = false;
messageAll(0, Client::getName(%clientId) @ " has removed admin from " @ Client::getName(%cl));
Game::refreshClientScore(%cl);
bottomprint(%cl, "<jc><f0>You have been <f2>stripped of your Admin<f0> by <f1>" @ Client::getName(%clientId), $adminMessageToPlayerDuration);
}
}
else
{
Client::sendMessage(%clientId, 0, "You can not remove admin from " @ Client::getName(%cl));
}
}
Game::menuRequest(%clientId);
}
function processMenuPBAffirm(%clientId, %opt)
{
if(getWord(%opt, 0) == "yes") {
if(%clientId.isServerSuperAdmin) {
Admin::kick(%clientId, getWord(%opt, 1), "pban");
}
}
Game::menuRequest(%clientId);
}
function processMenuCWScore(%clientId, %opt)
{
if ((%opt <= 0) || (%opt > $Arena::ScorelimitMax)) {
Arena::TabMenuExploit(%clientId, "processMenuCWScore(" @ %clientId @ ", " @ %opt @ ")");
}
else {
messageAll(0, Client::getName(%clientId) @ " has changed the Winning Score to " @ %opt);
$Arena::Scorelimit = %opt;
}
}
function processMenuPickTeam(%clientId, %team, %adminClient)
{
if ( (%team == "") || ((%team != "-2") && (%team != "-1") && (%team != "0") && (%team != "1") && (%team != "9")) )
{
Arena::TabMenuExploit(%clientId, "processMenuPickTeam(" @ %clientId @ ", " @ %team @ ", " @ %adminClient @ ")");
}
else
{
if ((%team != -1) && (%team == Client::getTeam(%clientId))) {
return;
}
if ((%clientId.lock) && (%adminClient != ""))
{
if ($AllAdminsCanChangeLockedPlayerTeam == 1)
{
messageAll(0, Client::getname(%clientId) @ " has been unlocked by " @ Client::getname(%adminClient) @ ".");
%clientId.lock = false;
}
else
{
Client::sendMessage(%adminClient,3, Client::getName(%clientId) @ " has locked himself out of play.  He will not be able to join a team until he selects a team or unlocks himself from the Tab Menu.");
Game::refreshClientScore(%clientId);
ObjectiveMission::refreshTeamScores();
return;
}
}
if(%clientId.observerMode == "justJoined")
{
if (%clientId.timeWentInObsSimTime < 0) {
%clientId.timeWentInObsSimTime = floor(getSimTime());
}
%clientId.observerMode = "";
centerprint(%clientId, "");
}
if ((%team == 9) && (%clientId.lock))
{
messageAll(0, Client::getname(%clientId) @ " has unlocked himself.");
Client::sendMessage(%clientId,3, "You can join the game by selecting a team using the Tab Menu.");
%clientId.lock = false;
%team = -2;
}
else if (%team != 9)
{
%clientId.lock = false;
}
else
{
%clientId.lock = true;
messageAll(0, Client::getname(%clientId) @ " has locked himself out of play.  He will be unable to join the game until he unlocks himself via the Player Menu.");
Client::sendMessage(%clientId,3, "You can join the game again by selecting a team using the Tab Menu.");
%team = -2;
}
if (%team == -1)
{
%clientId.timeWentInObsSimTime = -1;
if (Arena::CountTeam(0)  > Arena::CountTeam(1))
{
%team = 1;
%clientId.matchteam = 1;
}
else if (Arena::CountTeam(0)  < Arena::CountTeam(1))
{
%team = 0;
%clientId.matchteam = 0;
}
else if ($TeamMatchScore[0] > $TeamMatchscore[1])
{
%clientId.matchteam = 1;
%team = 1;
}
else
{
%team = 0;
%clientId.matchteam = 0;
}
}
if(%team == -2)
{
if (%clientId.timeWentInObsSimTime < 0) {
%clientId.timeWentInObsSimTime = floor(getSimTime());
}
if(Observer::enterObserverMode(%clientId))
{
%clientId.notready = "";
if(%adminClient == "") {
messageAll(0, Client::getName(%clientId) @ " became an observer.");
}
else {
messageAll(0, Client::getName(%clientId) @ " was forced into observer mode by " @ Client::getName(%adminClient) @ ".");
}
if ((Arena::CountTeamPlayers(%clientId.matchteam) == 0) && (%clientId.matchteam != -2) && $Arena::MatchStatus != 0)  // If the observer was the last guy on the team, the other team wins
{
%temp = 1 - %clientId.matchteam;
%clientId.matchteam = -2;
centerPrintAll("<jc>" @ getTeamName(%otherTeam) @ " has won the game\n\n\n" @ Arena::GetTeamScoresString(), 10);
$Arena::MatchStatus = 2;
Arena::GameOver(%temp);
}
else if ($Arena::MatchMode == 1 && %clientId.isTeamCaptain)
{
%clientId.isTeamCaptain = false;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchteam == %clientId.matchteam && %cl != %clientId)
{
%cl.isTeamCaptain = true;
messageAll(0, Client::getName(%cl) @ " has become the Team Captain of " @ getTeamName(%cl.matchteam));
Game::refreshClientScore(%cl);
}
}
}
%clientId.matchteam = -2;
%clientId.onteam = " ";
}
Game::refreshClientScore(%clientId);
ObjectiveMission::refreshTeamScores();
return;
}
else if($Arena::MatchStatus == 1)
{
%clientId.timeWentInObsSimTime = -1;
%clientId.matchteam = %team;
Game::refreshClientScore(%clientId);
if (%adminClient == "") {
messageAll(0, Client::getName(%clientId) @ " has joined the "  @ getTeamName(%team) @ " team, and will spawn after this game.");
}
else {
messageAll(0, Client::getName(%clientId) @ " has joined the "  @ getTeamName(%team) @ " team, and will spawn after this game, this done by " @ Client::getName(%adminClient) @ ".");
}
Game::refreshClientScore(%clientId);
ObjectiveMission::refreshTeamScores();
return;
}
%player = Client::getOwnedObject(%clientId);
if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
{
playNextAnim(%clientId);
Player::kill(%clientId);
}
%clientId.observerMode = "";
if (%adminClient == "") {
messageAll(0, Client::getName(%clientId) @ " changed teams.");
}
else {
messageAll(0, Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient) @ ".");
}
GameBase::setTeam(%clientId, %team);
%clientId.teamEnergy = 0;
Client::clearItemShopping(%clientId);
if(Client::getGuiMode(%clientId) != 1)
Client::setGuiMode(%clientId,1);
Client::setControlObject(%clientId, -1);
Game::playerSpawn(%clientId, false);
%team = Client::getTeam(%clientId);
%clientId.matchteam = %team; // Sets the clients.matchteam to whatever team he joined
if ($Arena::MatchMode == 1 && Arena::CountTeamPlayers(%team) == 1)
{
%clientId.isTeamCaptain = true;
messageAll(0, Client::getName(%clientId) @ " has become the Team Captain of " @ getTeamName(%team));
}
Game::refreshClientScore(%clientId);
ObjectiveMission::refreshTeamScores();
if ($Arena::ReadyTime && %team != -2)
{
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
schedule("Arena::CheckReadyState(" @ %clientId @ ");", $ArenaCheckReadyStateDurationReadyUpDisabled);
}
else {
schedule("Arena::CheckReadyState(" @ %clientId @ ");", $ArenaCheckReadyStateDuration);
}
}
}
}
function Game::startMatch()
{
$matchStarted = true;
$missionStartTime = getSimTime();
messageAll(0, "Match started.");
Game::resetScores();
%numTeams = getNumTeams();
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Game::refreshClientScore(%cl);
}
Game::checkTimeLimit();
}
function Game::playerSpawn(%clientId, %respawn)
{
if(!$ghosting)
return false;
Client::clearItemShopping(%clientId);
%spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);
if(!%respawn)
{
bottomprint(%clientId, "<jc><f0>Tribes Arena Version " @ $Arena::Version @ "\n<f0>Mission: <f1>" @ $missionName @ "   <f0>Mission Type: <f1>" @ $Game::missionType @ "\n<f0>Press <f1>'O'<f0> for specific objectives.", 5);
}
if(%spawnMarker) {
%clientId.guiLock = "";
%clientId.dead = "";
if(%spawnMarker == -1)
{
%spawnPos = "0 0 300";
%spawnRot = "0 0 0";
}
else
{
%spawnPos = GameBase::getPosition(%spawnMarker);
%spawnRot = GameBase::getRotation(%spawnMarker);
}
if(!String::ICompare(Client::getGender(%clientId), "Male"))
%armor = "larmor";
else
%armor = "lfemale";
%pl = spawnPlayer(%armor, %spawnPos, %spawnRot);
echo("SPAWN: cl:" @ %clientId @ " pl:" @ %pl @ " marker:" @ %spawnMarker @ " armor:" @ %armor);
if(%pl != -1)
{
GameBase::setTeam(%pl, Client::getTeam(%clientId));
Client::setOwnedObject(%clientId, %pl);
Game::playerSpawned(%pl, %clientId, %armor, %respawn);
if ($Arena::MatchStatus != 1)
{
%clientId.observerMode = "pregame";
Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
Observer::setOrbitObject(%clientId, %pl, 3, 3, 3);
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
%clientId.notready = "";
centerprint(%clientId, $Server::joinMOTD @ "\n\n<f1><jc>" @ $PreGameMessage[%clientId.matchteam] @ "\n", 0);
}
else {
%clientId.notready = true;
centerprint(%clientId, $Server::joinMOTD @ "\n\n<f1><jc>" @ $PreGameMessage[%clientId.matchteam] @ "\n" @ $Arena::ReadyUpMessage, 0);
}
}
%clientId.onteam = "*";
}
return true;
}
else
{
Client::sendMessage(%clientId,0,"Sorry No Respawn Positions Are Empty - Try again later ");
return false;
}
}
function Game::playerSpawned(%pl, %clientId, %armor)
{
if (($ArenaUseLabRatPSkin == 1) && ($Arena::MatchMode == 0)) {
if (%clientId.customSkin == true) {
Client::setSkin(%clientId, $Client::info[%clientId, 0]);
}
else {
Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
}
}
else {
Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
}
%clientId.spawn= 1;
%max = getNumItems();
for(%i = 0; (%item = $spawnBuyList[%i]) != ""; %i++)
{
buyItem(%clientId,%item);
if(%item.className == Weapon)
%clientId.spawnWeapon = %item;
}
%clientId.spawn= "";
if(%clientId.spawnWeapon != "") {
Player::useItem(%pl,%clientId.spawnWeapon);
%clientId.spawnWeapon="";
}
}
function Game::initialMissionDrop(%clientId)
{
Client::setGuiMode(%clientId, $GuiModePlay);
GameBase::setTeam(%clientId, -1);
Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
%camSpawn = Game::pickObserverSpawn(%clientId);
Observer::setFlyMode(%clientId, GameBase::getPosition(%camSpawn),
GameBase::getRotation(%camSpawn), true, true);
%clientId.observerMode = "pickingTeam";
if($Arena::MatchStatus != 0)
{
%clientId.observerMode = "observerFly";
if ($Arena::MatchMode)
{
bottomprint(%clientId, $Server::JoinMOTD @
"\n\n<jc><f1>Server is running Tribes Arena v" @ $Arena::Version @
" and is in Match mode. Please wait until its finished. " @
"Score limit is " @ $Arena::Scorelimit @ ".");
}
else
{
bottomprint(%clientId, $Server::JoinMOTD @
"\n\n<jc><f1>Server is running Tribes Arena v" @ $Arena::Version @
" and is in Public mode.\n" @
"* You will spawn as soon as this game is over *" @
"Score limit is " @ $Arena::Scorelimit @ ".");
processMenuPickTeam(%clientId, -1);
}
Game::RefreshClientScore(%clientId);
return;
}
else
{
bottomprint(%clientId, "<jc><f1>Server is running Tribes Arena v" @ $Arena::Version @ "." @
"Match has not yet started. Pick a Team. " @
"Score limit is " @ $Arena::Scorelimit @ ".");
if ($Arena::AutoTeamJoin)
processMenuPickTeam(%clientId, -1);
else
processMenuPickTeam(%clientId, -2);
}
%clientId.justConnected = "";
Game::RefreshClientScore(%clientId);
Client::sendMessage(%clientId, 1, "Hello " @ Client::getName(%clientId) @ ", and welcome to Tribes Arena " @ $Arena::Version @ ".  Please hit 'O' to review the rules and objectives of Arena.  Also, you can visit " @ $Arena::WebSiteURL @ " for Tribes Arena downloads. Have fun!");
}
function Game::onPlayerConnected(%playerId)
{
Arena::ResetPlayerOptions(%playerId);
Arena::ResetPlayerMapScore(%playerId);
Arena::ResetPlayerTotalScore(%playerId);
if (($LizStatsLoaded == 1) && ($ArenaRestorePlayerScoresOnReconnect == 1) && ($Arena::MatchMode == 0))
{
%name = Client::GetName(%playerId);
%taddr = Client::getTransportAddress(%playerId);
%plidx = LizStats::FindLastDroppedPlayer(%name, %taddr);
if (%plidx >= 0)
{
if ($LizStats::LastDroppedPlayers::Map[%plidx] == $missionName)
{
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%time = $LizStats::DateTime::NbSec;
%time = %time - $LizStats::LastDroppedPlayers::Time[%plidx];
} else {
%time = 0;
}
if (%time < 60)
{
LizStats::GetLastDroppedPlayerStats(%playerId, %plidx);
Game::refreshClientScore(%playerId);
Client::sendMessage(%playerId, 1, "Quick disconnect/reconnect detected: your previous score and statistics were restored.");
}
}
}
}
Arena::ComputePlayerRatios(%playerId);
%playerId.justConnected = true;
%playerId.matchteam = -2;
%playerId.FreeInvTimer = false;
$menuMode[%playerId] = "None";
%playerId.onteam = " ";
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
%playerId.muted[%cl] = "";
%playerId.mutedName[%cl] = "";
%playerId.muteGlobal = "";
%playerId.muteGlobalName = "";
}
Game::refreshClientScore(%playerId);
%playerId.VoteIncrementalDelay = 0;
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
LizStats::UpdateServerStatsTotalConnects(1);
ObjectiveMission::setObjectiveHeading();
}
}
function Client::onKilled(%playerId, %killerId, %damageType)
{
echo("GAME: kill " @ %killerId @ " " @ %playerId @ " " @ %damageType);
%playerId.guiLock = true;
Client::setGuiMode(%playerId, $GuiModePlay);
if(%playerId.IsDeadNow == 1) {
return;
}
%playerId.IsDeadNow = 1;
if(!String::ICompare(Client::getGender(%playerId), "Male"))
{
%playerGender = "his";
}
else
{
%playerGender = "her";
}
%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
%victimName = Client::getName(%playerId);
Client::sendMessage(%playerId,0,"~warenafatality.wav");
if(!%killerId)
{
messageAll(0, strcat(%victimName, " dies."), $DeathMessageMask);
%playerId.scoreDeaths++;
%playerId.totalDeaths++;
Arena::ComputePlayerRatios(%playerId);
%clientteam = Client::getTeam(%client);
$TeamNbDeaths[%clientteam]++;
ObjectiveMission::refreshTeamScores();
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1)) {
LizStats::UpdateServerStatsTotalDeaths(1);
}
}
else if(%killerId == %playerId)
{
if (%damageType == $OOBDamageType) {
%oopsMsg = %victimName @ " dies out of mission area.";
}
else {
%oopsMsg = sprintf($deathMsg[-2, %ridx], %victimName, %playerGender);
}
messageAll(0, %oopsMsg, $DeathMessageMask);
%playerId.score--;
%playerId.scoreSuicide++;
%playerId.totalSuicide++;
%playerId.scoreDeaths++;
%playerId.totalDeaths++;
Arena::ComputePlayerRatios(%playerId);
Arena::ComputePlayerRatios(%killerId);
%playerteam = Client::getTeam(%playerId);
$TeamNbDeaths[%playerteam]++;
ObjectiveMission::refreshTeamScores();
if ($Arena::MatchStatus != 1)
{
schedule("Arena::PickTeam(" @ %playerId @ ", -2);", 2);
}
Game::refreshClientScore(%playerId);
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1)) {
LizStats::UpdateServerStatsTotalSuicides(1);
LizStats::UpdateServerStatsTotalDeaths(1);
}
}
else
{
if(!String::ICompare(Client::getGender(%killerId), "Male"))
{
%killerGender = "his";
}
else
{
%killerGender = "her";
}
if($teamplay && (Client::getTeam(%killerId) == Client::getTeam(%playerId)))
{
if(%damageType != $MineDamageType)
messageAll(0, strcat(Client::getName(%killerId),
" mows down ", %killerGender, " teammate, ", %victimName), $DeathMessageMask);
else
messageAll(0, strcat(Client::getName(%killerId),
" killed ", %killerGender, " teammate, ", %victimName ," with a mine."), $DeathMessageMask);
%playerId.scoreDeaths++;
%playerId.totalDeaths++;
%playerId.scoreTKed++;
%playerId.totalTKed++;
%killerId.scoreTKs++;
%killerId.totalTKs++;
%killerId.score--;
Arena::ComputePlayerRatios(%playerId);
Arena::ComputePlayerRatios(%killerId);
Game::refreshClientScore(%playerId);
Game::refreshClientScore(%killerId);
%playerteam = Client::getTeam(%playerId);
$TeamNbDeaths[%playerteam]++;
ObjectiveMission::refreshTeamScores();
if (%killerId.scoreTKs == 1)
%scoTKth = %killerId.scoreTKs @ "st";
else if (%killerId.scoreTKs == 2)
%scoTKth = %killerId.scoreTKs @ "nd";
else
%scoTKth = %killerId.scoreTKs @ "th";
if (($WarnTKersWithTheirTotalTKCount == 1) && ($Arena::MatchMode != 1))
{
if ($UseNewScoringSystem == 1) {
Client::sendMessage(%killerId,1,"You have TK'd " @ %victimName @ ". You have lost one kill.");
Client::sendMessage(%playerId,0,"You have been TK'd by " @ Client::getName(%killerId) @ ".");
}
else {
Client::sendMessage(%killerId,1,"You have TK'd " @ %victimName);
Client::sendMessage(%playerId,0,"You have been TK'd by " @ Client::getName(%killerId));
}
Client::sendMessage(%killerId,1,"This is your " @ %scoTKth @ " TK on this map (TK:K ratio of " @ %killerId.scoreTKKillRatio @ ")");
Client::sendMessage(%playerId,0,"This was his " @ %scoTKth @ " TK on this map (TK:K ratio of " @ %killerId.scoreTKKillRatio @ ")");
}
if ($WarnAdminsWhenTKer == 1)
{
if ((%killerId.scoreTKKillRatio > 1) || (%killerId.score <= -2))
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%cl.isAdmin) || (%cl.isTrustedAdmin) || (%cl.isSuperAdmin))
{
Client::sendMessage(%cl, 1, %victimName @ " has been TK'd by " @ Client::getName(%killerId));
Client::sendMessage(%cl, 1, "This was " @ Client::getName(%killerId) @ "'s " @ %scoTKth @ " TK on this map (TK:K ratio of " @ %killerId.scoreTKKillRatio @ ")");
}
}
}
}
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1)) {
LizStats::UpdateServerStatsTotalTKs(1);
LizStats::UpdateServerStatsTotalDeaths(1);
}
}
else
{
%obitMsg = sprintf($deathMsg[%damageType, %ridx], Client::getName(%killerId),
%victimName, %killerGender, %playerGender);
messageAll(0, %obitMsg, $DeathMessageMask);
%playerId.scoreDeaths++;
%killerId.score++;
%killerId.scoreKills++;
%playerId.totalDeaths++;
%killerId.totalKills++;
Arena::ComputePlayerRatios(%playerId);
Arena::ComputePlayerRatios(%killerId);
Game::refreshClientScore(%killerId);
Game::refreshClientScore(%playerId);
%killerteam = Client::getTeam(%killerId);
$TeamNbKills[%killerteam]++;
%playerteam = Client::getTeam(%playerId);
$TeamNbDeaths[%playerteam]++;
ObjectiveMission::refreshTeamScores();
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1)) {
LizStats::UpdateServerStatsTotalKills(1);
LizStats::UpdateServerStatsTotalDeaths(1);
ObjectiveMission::setObjectiveHeading();
}
}
}
if ($Arena::MatchStatus == 1)
{
schedule("Arena::PickTeam(" @ %playerId @ ", -2);", 2);
schedule("Arena::CheckTeamDeath( " @ %playerId.matchteam @ ");", 3);
schedule("Arena::CheckAllTeamDeaths();", 4);
}
else
{
Arena::PickTeam(%playerId, -2);
}
}
function Client::leaveGame(%clientId)
{
%set = nameToID("MissionCleanup/ObjectivesSet");
for(%i = 0; (%obj = Group::getObject(%set, %i)) != -1; %i++) {
GameBase::virtual(%obj, "clientDropped", %clientId);
}
if ((%clientId.isTeamCaptain == true) && ($Arena::MatchMode == 1))
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl != %clientId && %cl.matchteam == %clientId.matchteam && %clientId.isTeamCaptain == true)
{
%clientId.isTeamCaptain = false;
%cl.isTeamCaptain = true;
messageAll(0, Client::getName(%cl) @ " has become the new Team Captain of " @ getTeamName(%matchteam));
break;
}
}
}
%clientId.isTeamCaptain = false;
if (Client::getTeam(%clientId) > -1)
{
Arena::PickTeam(%clientId, -2);
if (Arena::CountTeamPlayers(%clientId.matchteam) == 0 && $Arena::MatchStatus != 0)
{
$Arena::MatchStatus = 2;
%otherteam = 1 - %clientId.matchteam;
%clientId.matchteam = -2;
Game::refreshClientScore(%clientId);
centerPrintAll("<jc>" @ getTeamName(%otherTeam) @ " has won the game\n\n\n" @ Arena::GetTeamScoresString(), 5);
schedule("Arena::GameOver(%otherteam);", 4);
}
}
if ($Arena::MatchMode == 0) {
Arena::CheckIfTeamsAreEven();
}
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if ($UseNewScoringSystem == 1) {
LizStats::UpdateMapStatsCheckClientRank(%clientId, $Arena::MatchMode);
}
else {
LizStats::UpdateMapStatsCheckClientScore(%clientId, $Arena::MatchMode);
}
}
}
function remoteObjectivesMode(%clientId)
{
remoteSCOM(%clientId, -1);
Client::setGuiMode(%clientId, $GuiModeObjectives);
}
function remotePlayMode(%clientId)
{
remoteSCOM(%clientId, -1);
Client::setGuiMode(%clientId, $GuiModePlay);
}
$arenagame_cs_version = "$Revision: 18 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaGame.cs v" @ $Arena::Version @ ", internal version " @ $arenagame_cs_version);
