// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "item.cs"
// __________________________________________________________________________
//

function checkResources(%player,%item,%delta,%noMessage)
{
%client = Player::getClient(%player);
%team = Client::getTeam(%client);
%extraAmmo = 0 ;
if (Player::getMountedItem(%client,$BackpackSlot) == ammopack && $AmmoPackMax[%item] != "") {
%extraAmmo = $AmmoPackMax[%item];
if(%delta == $ItemMax[Player::getArmor(%client), %item])
%delta = %delta + %extraAmmo;
}
if($TestCheats == 0 && %client.spawn == "") {
%energy = $TeamEnergy[%team];
%station = %player.Station;
%sName = GameBase::getDataName(%station);
if(%sName == DeployableInvStation || %sName == DeployableAmmoStation)
{
%energy = %station.Energy;
}
if(%energy != "Infinite")
{
if (%item.price * %delta > %energy)
%delta = %energy / %item.price;
if(%delta < 1 )
{
if(%noMessage == "")
Client::sendMessage(%client,0,"Couldn't buy " @ %item.description @ " - "@ %energy @ " Energy points left");
return 0;
}
}
}
if(%item == RepairPatch) {
%pDamage = GameBase::getDamageLevel(%player);
if(GameBase::getDamageLevel(%player) > 0)
return 1;
return 0;
}
else if($TeamItemMax[%item] != "" && !$TestCheats)
{
if($TeamItemMax[%item] <= $TeamItemCount[%team, %item]) {
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return 0;
}
}
else if(%item.className == Weapon) {
%armor = Player::getArmor(%client);
%wcount = Player::getItemClassCount(%client,"Weapon");
if (Player::getItemClassCount(%client,"Weapon") >= $MaxWeapons[%armor]) {
Client::sendMessage(%client,0,"To many weapons for " @ $ArmorName[%armor].description @ " to carry");
return 0;
}
}
if(%item.className != Armor && %item.className != Vehicle) {
%count = Player::getItemCount(%client,%item);
%max = $ItemMax[(Player::getArmor(%client)), %item] + %extraAmmo ;
if(%delta + %count >= %max)
{
%delta = %max - %count;
}
}
return %delta;
}
function buyItem(%client,%item,%fromfavs)
{
if ($FixInventorySpamExploit == 1)
{
if (%client.InvBuyCount > $FixInventorySpamExploitMaxBuyCountPerInvenVisit)
{
return 0;
}
else if (%client.InvBuyCount >= $FixInventorySpamExploitMaxBuyCountPerInvenVisit)
{
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" has reached the maximum number of purchases per inventory visit.");
Client::sendMessage(%client,0,"You have reached the maximum number of purchases per inventory visit.");
%client.InvBuyCount = $FixInventorySpamExploitMaxBuyCountPerInvenVisit + 1;
return 0;
}
}
%player = Client::getOwnedObject(%client);
%armor = Player::getArmor(%client);
if (($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats || %client.spawn) &&
($ItemMax[%armor, %item] || %item.className == Armor || %item.className == Vehicle || $TestCheats))
{
if (%item.className == Armor)
{
%buyarmor = $ArmorType[Client::getGender(%client), %item];
if(%armor != %buyarmor || Player::getItemCount(%client,%item) == 0)
{
teamEnergyBuySell(%player,$ArmorName[%armor].price);
if(checkResources(%player,%item,1))
{
teamEnergyBuySell(%player,$ArmorName[%buyarmor].price * -1);
Player::setArmor(%client,%buyarmor);
checkMax(%client,%buyarmor);
armorChange(%client);
Player::setItemCount(%client, $ArmorName[%armor], 0);
Player::setItemCount(%client, %item, 1);
if (Player::getMountedItem(%client,$BackpackSlot) == ammopack)
fillAmmoPack(%client);
if ($TeamItemMax[%item] != "")
$TeamItemCount[GameBase::getTeam(%client),%item]++;
if ($FixInventorySpamExploit == 1)
%client.InvBuyCount++;
return 1;
}
teamEnergyBuySell(%player,$ArmorName[%armor].price * -1);
}
}
else if (%item.className == Backpack)
{
if($TeamItemMax[%item] != "")
{
if($TeamItemCount[GameBase::getTeam(%client) @ %item] >= $TeamItemMax[%item])
return 0;
}
%pack = Player::getMountedItem(%client,$BackpackSlot);
if (%pack != -1)
{
if(%pack == ammopack)
checkMax(%client,%armor);
else if(%pack == EnergyPack)
{
if(Player::getItemCount(%client,"LaserRifle") > 0)
{
Client::sendMessage(%client,0,"Sold Energy Pack - Auto Selling Laser Rifle");
remoteSellItem(%client,22);
}
}
teamEnergyBuySell(%player,%pack.price);
Player::decItemCount(%client,%pack);
}
if (checkResources(%player,%item,1) || $TestCheats)
{
teamEnergyBuySell(%player,%item.price * -1);
Player::incItemCount(%client,%item);
Player::useItem(%client,%item);
if(%item == ammopack)
fillAmmoPack(%client);
if ($TeamItemMax[%item] != "")
$TeamItemCount[GameBase::getTeam(%client), %item]++;
if ($FixInventorySpamExploit == 1)
%client.InvBuyCount++;
return 1;
}
else if(%pack != -1)
{
teamEnergyBuySell(%player,%pack.price * -1);
Player::incItemCount(%client,%pack);
Player::useItem(%client,%pack);
if(%pack == ammopack)
fillAmmoPack(%client);
}
}
else if(%item.className == Weapon)
{
if(checkResources(%player,%item,1))
{
if(%item == LaserRifle && Player::getItemCount(%client,"EnergyPack") == 0)
{
buyItem(%client,"EnergyPack", 0);
Client::sendMessage(%client,0,"Bought Laser Rifle - Auto buying Energy Pack");
}
Player::incItemCount(%client,%item);
teamEnergyBuySell(%player,(%item.price * -1));
%ammoItem =  %item.imageType.ammoType;
if(%ammoItem != "")
{
%delta = checkResources(%player,%ammoItem,$ItemMax[%armor, %ammoItem]);
if(%delta || $TestCheats)
{
teamEnergyBuySell(%player,(%ammoItem.price * -1 * %delta));
Player::incItemCount(%client,%ammoitem,%delta);
}
}
if ($TeamItemMax[%item] != "")
$TeamItemCount[GameBase::getTeam(%client),%item]++;
if ($FixInventorySpamExploit == 1)
%client.InvBuyCount++;
return 1;
}
}
else if(%item.className == Vehicle)
{
if($TeamItemCount[GameBase::getTeam(%client) @ %item] < $TeamItemMax[%item])
{
%shouldBuy = VehicleStation::checkBuying(%client,%item);
if(%shouldBuy == 1)
{
teamEnergyBuySell(%player,(%item.price * -1));
if ($FixInventorySpamExploit == 1)
%client.InvBuyCount++;
return 1;
}
else if(%shouldBuy == 2)
{
if ($FixInventorySpamExploit == 1)
%client.InvBuyCount++;
return 1;
}
}
}
else {
if($TeamItemMax[%item] != "")
{
if($TeamItemCount[GameBase::getTeam(%client) @ %item] >= $TeamItemMax[%item])
return 0;
}
%delta = checkResources(%player,%item,$ItemMax[%armor, %item]);
if(%delta || $TestCheats)
{
teamEnergyBuySell(%player,(%item.price * -1 * %delta));
Player::incItemCount(%client,%item,%delta);
if ($FixInventorySpamExploit == 1)
%client.InvBuyCount++;
return 1;
}
}
}
return 0;
}
function remoteSellItem(%client,%type)
{
if (isPlayerBusy(%client))
return;
%item = getItemData(%type);
%player = Client::getOwnedObject(%client);
if ($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats)
{
if(Player::getItemCount(%client,%item) && %item.className != Armor)
{
%numsell = 1;
if(%item.className == Ammo || %item.className == HandAmmo)
{
%count = Player::getItemCount(%client, %item);
if(%count < $SellAmmo[%item])
%numsell = %count;
else
%numsell = $SellAmmo[%item];
}
else if (%item == ammopack)
checkMax(%client,Player::getArmor(%client));
else if($TeamItemMax[%item] != "")
{
if(%item.className == Vehicle)
$TeamItemCount[(Client::getTeam(%client)) @ %item]--;
else
$TeamItemCount[(Client::getTeam(%client)),%item]--;
}
if(%item == EnergyPack)
{
if(Player::getItemCount(%client,"LaserRifle") > 0)
{
Client::sendMessage(%client,0,"Sold Energy Pack - Auto Selling Laser Rifle");
remoteSellItem(%client,22);
}
}
teamEnergyBuySell(%player,%item.price * %numsell);
Player::setItemCount(%player,%item,(%count-%numsell));
updateBuyingList(%client);
Client::SendMessage(%client,0,"~wbuysellsound.wav");
return 1;
}
}
Client::sendMessage(%client,0,"Cannot sell item ~wC_BuySell.wav");
}
function remoteThrowItem(%client,%type,%strength)
{
%player = Client::getOwnedObject(%client);
if(%player.Station == "" && %player.waitThrowTime + $WaitThrowTime <= getSimTime()) {
if(GameBase::getControlClient(%player) != -1 || %player.vehicle != "") {
%item = getItemData(%type);
if (%item == Grenade || %item == MineAmmo) {
if (%strength < 0)
%strength = 0;
else
if (%strength > 100)
%strength = 100;
%client.throwStrength = 0.3 + 0.7 * (%strength / 100);
Player::useItem(%client,%item);
}
}
}
}
$arenaitem_cs_version = "$Revision: 16 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaItem.cs v" @ $Arena::Version @ ", internal version " @ $arenaitem_cs_version);
