// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "server.cs"
// __________________________________________________________________________
//


function Server::nextMission(%replay)
{
if (%replay || $Server::TourneyMode)
{
%nextMission = $missionName;
}
else
{
%nextMission = $nextMission[$missionName];
%nextMisOk = false;
while (%nextMisOk == false)
{
%lastplayed = LizStats::CheckLastPlayedMaps(%nextMission);
if (%lastplayed != 0)
{
echo("SERVER: Skipping mission '" @ %nextMission @ "' because it was recently played.");
%nextMission = $nextMission[%nextMission];
}
else
{
%nextMisOk = true;
}
}
}
echo ("Changing to mission ", %nextMission, ".");
Server::loadMission(%nextMission);
}
function Server::loadMission(%missionName, %immed)
{
if($loadingMission) {
return;
}
%missionFile = "missions\\" $+ %missionName $+ ".mis";
if(File::FindFirst(%missionFile) == "")
{
%missionName = $firstMission;
%missionFile = "missions\\" $+ %missionName $+ ".mis";
if(File::FindFirst(%missionFile) == "")
{
echo("MISC: invalid nextMission and firstMission...");
echo("MISC: aborting mission load.");
return;
}
}
echo("MISC: Notifying players of mission change: ", getNumClients(), " in game");
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Client::setGuiMode(%cl, $GuiModeVictory);
%cl.guiLock = true;
%cl.nospawn = true;
remoteEval(%cl, missionChangeNotify, %missionName);
}
$loadingMission = true;
$missionName = %missionName;
$missionFile = %missionFile;
$prevNumTeams = getNumTeams();
$TeamItemMax[HeavyArmor] = "";
$TeamItemMax[LaserRifle] = "";
exec(observer);
exec(player);
exec(admin);
exec(comchat);
exec(game);
exec(gui);
exec(server);
exec(station);
exec(item);
exec(staticshape);
exec(objectives);
deleteObject("MissionGroup");
deleteObject("MissionCleanup");
deleteObject("ConsoleScheduler");
resetPlayerManager();
resetGhostManagers();
$matchStarted = false;
$countdownStarted = false;
$ghosting = false;
resetSimTime();
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1) && ($LizStatsSaveAfterMap == 1))
{
LizStats::SaveAll();
}
$MODInfo = "";
newObject(ConsoleScheduler, SimConsoleScheduler);
if(!%immed)
schedule("Server::finishMissionLoad();", 18);
else
Server::finishMissionLoad();
}
function Server::onClientConnect(%clientId)
{
if(!String::NCompare(Client::getTransportAddress(%clientId), "LOOPBACK", 8))
{
%clientId.isAdmin = true;
%clientId.isSuperAdmin = true;
}
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
echo("CONNECT: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" " @ Client::getTransportAddress(%clientId) @ %dtstr);
%clip = Client::getTransportAddress(%clientId);
for (%akidx = 1; %akidx <= $AutoKickIPListCount; %akidx++)
{
if ($AutoKickIPList[%akidx] != "")
{
%result = String::FindSubStr(%clip, $AutoKickIPList[%akidx]);
if ((%result != -1) && (%result != ""))
{
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" will be kicked by Auto-Kick" @ %dtstr);
BanList::add(%clip, $AutoKickIPListDuration);
schedule("Arena::AutoKickPlayer(" @ %clientId @ ");", 1, %clientId);
}
}
}
if ($KickBlankPlayers == 1)
{
%nonblankcount = 0;
%blankcount = 0;
%clname = Client::getName(%clientId);
%chridx = 0;
while (1) {
%res = String::GetSubStr(%clname, %chridx, 1);
if ((%res == -1) || (%res == ""))
break;
if (%res == " ")
%blankcount++;
else
%nonblankcount++;
%chridx++;
}
if (%nonblankcount == 0)
{
Client::sendMessage(%clientId,0,"Checking for invalid player names...");
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" will be kicked for blanks. (" @ %blankcount @ " blanks and " @ %nonblankcount @ " non blanks)" @ %dtstr);
Client::sendMessage(%clientId,0,"Get a valid name and come back later.");
BanList::add(%clip, $KickBlankPlayersDuration);
schedule("Arena::AutoKickBlanks(" @ %clientId @ ");", 1, %clientId);
}
}
for (%akidx = 1; %akidx <= $AutoAdminIPListCount; %akidx++)
{
if ($AutoAdminIPList[%akidx] != "")
{
%result = String::FindSubStr(%clip, $AutoAdminIPList[%akidx]);
if ((%result != -1) && (%result != ""))
{
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" is being auto-adminned" @ %dtstr);
%clientId.isAdmin = true;
Client::sendMessage(%clientId,0,"You have been made an admin by the server.");
Game::refreshClientScore(%clientId);
}
}
}
schedule("Arena::AutoKickAFKersFullServer();", 1, %clientId);
%clientId.noghost = true;
%clientId.messageFilter = -1; // all messages
remoteEval(%clientId, SVInfo, version(), $Server::Hostname, $modList, $Server::Info, $ItemFavoritesKey);
remoteEval(%clientId, MODInfo, $MODInfo);
remoteEval(%clientId, FileURL, $Server::FileURL);
for(%i = 0; %i < 10; %i++) {
$Client::info[%clientId, %i] = "";
}
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1))
{
LizStats::UpdateConnectedPlayersStats(0);
}
Game::onPlayerConnected(%clientId);
}
function Server::onClientDisconnect(%clientId)
{
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1))
{
LizStats::UpdateConnectedPlayersStats(1);
}
if (($LizStatsLoaded == 1) && ($ArenaRestorePlayerScoresOnReconnect == 1) && ($Arena::MatchMode == 0))
{
%name = Client::GetName(%clientId);
%taddr = Client::getTransportAddress(%clientId);
%plidx = LizStats::FindLastDroppedPlayer(%name, %taddr);
if (%plidx >= 0) {
LizStats::DeleteLastDroppedPlayerByIndex(%plidx);
}
else {
LizStats::DeleteLastDroppedPlayerByIndex($LizStats::LastDroppedPlayersCount);
}
LizStats::InsertLastDroppedPlayerStats(%clientId, 0);
}
%player = Client::getOwnedObject(%clientId);
if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player)) {
playNextAnim(%player);
Player::kill(%player);
}
Client::setControlObject(%clientId, -1);
Client::leaveGame(%clientId);
Game::CheckTourneyMatchStart();
if (getNumClients() == 1) {
Server::refreshData();
}
}
$arenaserver_cs_version = "$Revision: 16 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaServer.cs v" @ $Arena::Version @ ", internal version " @ $arenaserver_cs_version);
