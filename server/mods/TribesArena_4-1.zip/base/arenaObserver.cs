// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "observer.cs"
// __________________________________________________________________________
//


function Observer::triggerUp(%client)
{
if(%client.observerMode == "dead")
{
if(%client.dieTime + $Server::respawnTime < getSimTime())
{
if(Game::playerSpawn(%client, true))
{
%client.observerMode = "";
Observer::checkObserved(%client);
}
}
}
else if(%client.observerMode == "observerOrbit")
{
Observer::nextObservable(%client);
}
else if(%client.observerMode == "observerFly")
{
%camSpawn = Game::pickObserverSpawn(%client);
Observer::setFlyMode(%client, GameBase::getPosition(%camSpawn),
GameBase::getRotation(%camSpawn), true, true);
}
else if(%client.observerMode == "justJoined")
{
%client.observerMode = "";
Game::playerSpawn(%client, false);
}
else if(%client.observerMode == "pregame" && ($Arena::MatchStatus == 0 || ($Arena::MatchStatus == 2 && $Arena::MatchMode == 1 && %client.isTeamCaptain)))
{
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
%client.notready = "";
}
else {
if(%client.notready)
{
%client.notready = "";
MessageAll(0, Client::getName(%client) @ " is READY.");
if ($Arena::MatchMode == 1) {
centerprint(%client, $PreGameMessage[%client.matchteam] @ "\nWaiting for teams to be ready (FIRE if not ready).", 0);
}
else {
centerprint(%client, $PreGameMessage[%client.matchteam] @ "\nWaiting for teams to be ready.", 0);
}
Arena::PreGameMode();
}
else
{
if ($Arena::MatchMode == 1)
{
%client.notready = true;
MessageAll(0, Client::getName(%client) @ " is NOT READY.");
bottomprint(%client, $PreGameMessage[%client.matchteam] @ "Press FIRE when ready.", 0);
}
}
}
}
}
$arenaobserver_cs_version = "$Revision: 16 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaObserver.cs v" @ $Arena::Version @ ", internal version " @ $arenaobserver_cs_version);
