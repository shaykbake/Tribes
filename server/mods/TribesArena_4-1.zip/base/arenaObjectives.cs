// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "objectives.cs"
// __________________________________________________________________________
//


function ObjectiveMission::setObjectiveHeading()
{
for(%i = -1; %i < getNumTeams(); %i++) {
for(%s = %lineNb+1; %s < 30 ;%s++)
Team::setObjective(%i, %s, " ");
Team::clearObjectives(%i);
}
if ($missionComplete)
{
%curLeader = 0;
%tieGame = false;
%tie = 0;
%tieTeams[%tie] = %curLeader;
for(%i = 0; %i < getNumTeams() ; %i++)
echo("GAME: teamfinalscore " @ %i @ " " @ $teamScore[%i]);
for(%i = 1; %i < getNumTeams() ; %i++)
{
if($teamScore[%i] == $teamScore[%curLeader]) {
%tieGame = true;
%tieTeams[%tie++] = %i;
}
else if($teamScore[%i] > $teamScore[%curLeader])
{
%curLeader = %i;
%tieGame = false;
%tie = 0;
%tieTeams[%tie] = %curLeader;
}
}
if (%tieGame)
{
for(%g = 0; %g <= %tie; %g++)
{
%names = %names @ getTeamName(%tieTeams[%g]);
if(%g == %tie-1)
%names = %names @ " and ";
else if(%g != %tie)
%names = %names @ ", ";
}
if(%tie > 1)
%names = %names @ " all";
}
for(%i = -1; %i < getNumTeams(); %i++)
{
objective::displayBitmap(%i,0);
if(!%tieGame) {
if(%i == %curLeader)
{
if($teamScore[%curLeader] == 1)
Team::setObjective(%i, 1, "<F5>           Your team won the mission with " @ $teamScore[%curLeader] @ " point!");
else
Team::setObjective(%i, 1, "<F5>           Your team won the mission with " @ $teamScore[%curLeader] @ " points!");
}
else
{
if($teamScore[%curLeader] == 1)
Team::setObjective(%i, 1, "<F5>     The " @ getTeamName(%curLeader) @ " team won the mission with " @ $teamScore[%curLeader] @ " point!");
else
Team::setObjective(%i, 1, "<F5>     The " @ getTeamName(%curLeader) @ " team won the mission with " @ $teamScore[%curLeader] @ " points!");
}
}
else
{
if(getNumTeams() > 2)
{
Team::setObjective(%i, 1, "<F5>     The " @ %names @ " tied with a score of " @ $teamScore[%curLeader]);
}
else
Team::setObjective(%i, 1, "<F5>     The mission ended in a tie where each team had a score of " @ $teamScore[%curLeader]);
}
Team::setObjective(%i, 2, " ");
}
}
else
{
for(%i = -1; %i < getNumTeams(); %i++)
{
objective::displayBitmap(%i,0);
Team::setObjective(%i,1, "<f5>Mission Completion:");
Team::setObjective(%i,2, "<f1>   - " @ $Arena::Scorelimit @ " points needed to win the match.");
Team::setObjective(%i,3, "<f1>   - " @ Arena::GetTeamScoresString(-1));
}
}
if(!$Server::timeLimit)
%str = "<f1>   - No time limit on the game.";
else if ($timeLimitReached)
%str = "<f1>   - Time limit reached.";
else if ($missionComplete)
{
%time = getSimTime() - $missionStartTime;
%minutes = Time::getMinutes(%time);
%seconds = Time::getSeconds(%time);
if(%minutes < 10)
%minutes = "0" @ %minutes;
if(%seconds < 10)
%seconds = "0" @ %seconds;
%str = "<f1>   - Total match time: " @ %minutes @ ":" @ %seconds;
}
else
%str = "<f1>   - Time remaining: " @ floor($Server::timeLimit - (getSimTime() - $missionStartTime) / 60) @ " minutes.";
$ArenaObjectiveLine = 7 + getNumTeams() + 1;
%maxgamestotal = $Arena::ScoreLimit * 2 - 1;
for(%i = -1; %i < getNumTeams(); %i++)
{
%lineNb = 4;
Team::setObjective(%i, %lineNb  , " ");
Team::setObjective(%i, %lineNb++, "<f5>Mission Information:");
Team::setObjective(%i, %lineNb++, "<f1>   - Mission Name: " @ $missionName);
if (%str != "") {
Team::setObjective(%i, %lineNb++, %str);
}
Team::setObjective(%i, %lineNb++, " ");
Team::setObjective(%i, %lineNb++, "<f5>Arena v" @ $Arena::Version @ " Rules:");
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
}
else {
Team::setObjective(%i, %lineNb++, "<f1>   - Hit FIRE to Ready Up for each match");
}
Team::setObjective(%i, %lineNb++, "<f1>   - Match is won when a team wins " @ $Arena::ScoreLimit @ " out of " @ %maxgamestotal @ " games");
Team::setObjective(%i, %lineNb++, "<f1>   - Kill all players in ennemy team to win the game");
Team::setObjective(%i, %lineNb++, "<f1>   - In the TAB score list, a * indicates a player is still alive");
Team::setObjective(%i, %lineNb++, " ");
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if ($LizStatsMap == 1)
{
%topscoretext = "";
if ($LizStats::MapStatsMapHighestScoreResetDate != "") {
%topscoretext = %topscoretext @ " since " @ $LizStats::MapStatsMapHighestScoreResetDate;
}
if ($Arena::MatchMode == 0) {
%topscoretext = %topscoretext @ " in Public mode";
}
else {
%topscoretext = %topscoretext @ " in Match mode";
}
Team::setObjective(%i, %lineNb++, "<f5>Top " @ $LizStatsMapsMapHighestScore @ " Scores on " @ $missionName @ %topscoretext);
%scorecount = 0;
%lasttopscorename = "";
for(%highscore = 0; %highscore < $LizStatsMapsMapHighestScore; %highscore++)
{
%statstr = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %highscore, $Arena::MatchMode];
if ($UseNewScoringSystem == 1)
{
%rank = getWord(%statstr, 0);
if ((%rank != "") && (%rank != $LizStatsScoresNull)) {
%nbkills = getWord(%statstr, 1);
%nbdeaths = getWord(%statstr, 2);
%score = getWord(%statstr, 3);
%nbtks = getWord(%statstr, 4);
%nbtked = getWord(%statstr, 5);
%nbsuicide = getWord(%statstr, 6);
%hscoredate = getWord(%statstr, 7);
%hscoretime = getWord(%statstr, 8);
%name = LizStats::ExtractClientNameRankMethod(%highscore, $Arena::MatchMode);
if ((%name != %lasttopscorename)  && (%name != ""))
{
if ((%hscoredate != "0") && (%hscoretime != "0")) {
%extrascorestr = " on " @ %hscoredate @ " at " @ %hscoretime;
} else {
%extrascorestr = "";
}
Team::setObjective(%i, %lineNb++, "<f3>   " @ %highscore+1 @ ")\t " @
%name @ " with " @
%nbkills @ " kills, " @
%nbdeaths @ " deaths, " @
%nbtks @ " TKs, " @
%nbsuicide @ " suicides, " @
%nbtked @ " TKdeaths, " @
%score @ " points" @ %extrascorestr);
%lasttopscorename = %name;
%scorecount++;
}
}
}
else
{
%score = getWord(%statstr, 0);
if (%score != $LizStatsScoresNull) {
%nbkills = getWord(%statstr, 1);
%name = LizStats::ExtractClientNameScoreMethod(%highscore, $Arena::MatchMode);
if (%name != %lasttopscorename)
{
if (%score >= 0)
{
Team::setObjective(%i, %lineNb++, "<f3>   " @ %highscore+1 @ ")\t " @
%name @ " with " @ %score @ " points and " @ %nbkills @ " kills");
%lasttopscorename = %name;
%scorecount++;
}
}
}
}
}
if (%scorecount == 0)
Team::setObjective(%i, %lineNb++, "<f3>   No high scores yet");
Team::setObjective(%i, %lineNb++, " ");
}
if ($LizStatsServer == 1)
{
Team::setObjective(%i, %lineNb++, "<f5>" @ $missionName @ " Statistics");
%mapplayed = $LizStats::ServerStatsTotalMapsPlayed[$LizStats::CleanMissionType,$LizStats::CleanMissionName];
if ((%mapplayed == "") || (%mapplayed == 0))
%mapplayed = 1;
if (($LizStats::ServerStatsTotalAllMapsPlayed > 0) && ($LizStats::ServerStatsTotalAllMapsPlayed != "")) {
%mappercent = (%mapplayed * 100) / $LizStats::ServerStatsTotalAllMapsPlayed;
%mappercent = floor(%mappercent);
}
else
%mappercent = "100";
if (%mappercent != "")
%mappercent = "(" @ %mappercent @ "% of total maps played)";
Team::setObjective(%i, %lineNb++, "<f3>   - " @ $missionName @ " was played " @ %mapplayed @ " times " @ %mappercent);
%mapplayed = $LizStats::ServerStatsTotalGamesPlayed[$LizStats::CleanMissionType,$LizStats::CleanMissionName];
if ((%mapplayed == "") || (%mapplayed == 0))
%mapplayed = 1;
if (($LizStats::ServerStatsTotalAllGamesPlayed > 0) && ($LizStats::ServerStatsTotalAllGamesPlayed != "")) {
%mappercent = (%mapplayed * 100) / $LizStats::ServerStatsTotalAllGamesPlayed;
%mappercent = floor(%mappercent);
}
else
%mappercent = "100";
if (%mappercent != "")
%mappercent = "(" @ %mappercent @ "% of total games played)";
Team::setObjective(%i, %lineNb++, "<f3>   - " @ %mapplayed @ " games were played on " @ $missionName @ " " @ %mappercent);
Team::setObjective(%i, %lineNb++, " ");
}
if ($LizStatsServer == 1)
{
Team::setObjective(%i, %lineNb++, "<f5>\"" @ $Server::HostName @ "\" Server Statistics");
Team::setObjective(%i, %lineNb++, "<f3>   - " @
$LizStats::ServerStatsTotalAllGamesPlayed @
" games were played (" @
$LizStats::ServerStatsTotalAllMapsPlayed @
" maps)");
Team::setObjective(%i, %lineNb++, "<f3>   - " @
$LizStats::ServerStatsTotalConnects @ " players connected for a total of " @
$LizStats::ServerStatsTotalKills @ " kills, " @
$LizStats::ServerStatsTotalDeaths @ " deaths, " @
$LizStats::ServerStatsTotalSuicides @ " suicides, " @
$LizStats::ServerStatsTotalTKs @ " TKs");
Team::setObjective(%i, %lineNb++, " ");
}
}
Team::setObjective(%i, %lineNb++, "<f6>Visit " @ $Arena::WebSiteURL @ " for the latest version of Tribes Arena.");
for(%s = %lineNb+1; %s < 30 ;%s++)
Team::setObjective(%i, %s, " ");
}
}
function ObjectiveMission::refreshTeamScores()
{
%nt = getNumTeams();
setTeamScoreHeading("Team Name\t\x88Score\t\xB8K/D\t\xE4Worth");
for(%i = -1; %i < %nt; %i++)
{
if ((%i >= 0) && (%i <= 8)) {
%worth = floor(Arena::GetTeamWorthinessRatio(%i) / 10);
} else {
%worth = "";
}
Team::setScore(%i, "%t\t" @ $TeamMatchScore[%i] @ "\t" @ $TeamNbKills[%i] @ "/"
@ $TeamNbDeaths[%i] @ "\t" @ %worth, $TeamMatchScore[%i]);
Team::setObjective(%i,$firstTeamLine, "<f1>   - " @ Arena::GetTeamScoresString(-1));
}
}
function ObjectiveMission::checkScoreLimit()
{
}
function TowerSwitch::timeLimitCheckPoints(%this,%client,%numChange)
{
}
function alertPlayer(%player, %count)
{
if(%player.outArea == 1) {
%clientId = Player::getClient(%player);
Client::sendMessage(%clientId,1,"~wLeftMissionArea.wav");
if(%count > 1)
schedule("alertPlayer(" @ %player @ ", " @ %count - 1 @ ");",1.5,%clientId);
else
schedule("leaveMissionAreaDamage(" @ %clientId @ ");",1,%clientId);
}
}
function Mission::init()
{
if ($LizStatsLoaded == 1)
{
$LizStats::CleanMissionName = LizStats::ParseName($missionName);
$LizStats::CleanMissionType = LizStats::ParseName($Arena::MissionType);
}
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
LizStats::UpdateServerStatsTotalMapsPlayed(1);
}
if (($LizStatsLoaded == 1) && ($Arena::MatchMode == 0))
{
LizStats::UpdatePlayedMaps($missionName);
}
setTeamScoreHeading("Team Name\t\x88Score\t\xB8K/D\t\xE4Worth");
if ($UseNewScoringSystem == 1) {
setClientScoreHeading("  Player Name\t\x6DTeam\t\xA4 Score\t\xD3Ping\t\xEFPL\t\xFFAdmin");
}
else {
setClientScoreHeading("  Player Name\t\x6FTeam\t\xA6Score\t\xCFPing\t\xEDPL\t\xFFAdmin");
}
$firstTeamLine = 3;
$firstObjectiveLine = $firstTeamLine + getNumTeams() + 1;
for(%i = -1; %i < getNumTeams(); %i++)
{
$teamFlagStand[%i] = "";
$teamFlag[%i] = "";
$deltaTeamScore[%i] = 0;
$teamScore[%i] = 0;
newObject("TeamDrops" @ %i, SimSet);
addToSet(MissionCleanup, "TeamDrops" @ %i);
%dropSet = nameToID("MissionGroup/Teams/Team" @ %i @ "/DropPoints/Random");
for(%j = 0; (%dropPoint = Group::getObject(%dropSet, %j)) != -1; %j++)
addToSet("MissionCleanup/TeamDrops" @ %i, %dropPoint);
}
$numObjectives = 0;
newObject(ObjectivesSet, SimSet);
addToSet(MissionCleanup, ObjectivesSet);
Group::iterateRecursive(MissionGroup, ObjectiveMission::initCheck);
%group = nameToID("MissionCleanup/ObjectivesSet");
ObjectiveMission::setObjectiveHeading();
for(%i = 0; (%obj = Group::getObject(%group, %i)) != -1; %i++)
{
%obj.objectiveLine = 31;
ObjectiveMission::objectiveChanged(%obj);
}
Arena::ResetTeamMapScore();
ObjectiveMission::refreshTeamScores();
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Arena::ResetPlayerMapScore(%cl);
Arena::ComputePlayerRatios(%cl);
Game::refreshClientScore(%cl);
%cl.VoteIncrementalDelay = 0;
}
$TestMissionType = "ARENA";
AI::setupAI();
}
$arenaobjectives_cs_version = "$Revision: 16 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaObjectives.cs v" @ $Arena::Version @ ", internal version " @ $arenaobjectives_cs_version);
