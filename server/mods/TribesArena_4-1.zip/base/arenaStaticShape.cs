// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "staticshape.cs"
// __________________________________________________________________________
//

StaticShapeData Generator
{
description = "Generator";
shapeFile = "generator";
className = "Generator";
sfxAmbient = SoundGeneratorPower;
debrisId = flashDebrisLarge;
explosionId = flashExpLarge;
maxDamage = 1000.0;
visibleToSensor = true;
mapFilter = 4;
mapIcon = "M_generator";
damageSkinData = "objectDamageSkins";
shadowDetailMask = 16;
};
StaticShapeData SolarPanel
{
description = "Solar Panel";
shapeFile = "solar_med";
className = "Generator";
debrisId = flashDebrisMedium;
maxDamage = 1000.0;
visibleToSensor = true;
mapFilter = 4;
mapIcon = "M_generator";
damageSkinData = "objectDamageSkins";
shadowDetailMask = 16;
explosionId = flashExpLarge;
};
StaticShapeData PortGenerator
{
description = "Portable Generator";
shapeFile = "generator_p";
className = "Generator";
debrisId = flashDebrisSmall;
sfxAmbient = SoundGeneratorPower;
maxDamage = 1000.0;
mapIcon = "M_generator";
damageSkinData = "objectDamageSkins";
shadowDetailMask = 16;
explosionId = flashExpMedium;
visibleToSensor = true;
mapFilter = 4;
};
$arenastaticshape_cs_version = "$Revision: 16 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaStaticShape.cs v" @ $Arena::Version @ ", internal version " @ $arenastaticshape_cs_version);
