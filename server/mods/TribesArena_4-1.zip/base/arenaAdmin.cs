// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "admin.cs"
// __________________________________________________________________________
//

$curVoteTopic = "";
$curVoteAction = "";
$curVoteOption = "";
$curVoteCount = 0;
$adminMessageToPlayerDuration = 4;
function Admin::LizCheckProtectedIPList(%clientId, %reason)
{
%ip = Client::getTransportAddress(%clientId);
for(%tmpindex = 1; %tmpindex <= $ProtectedIPListCount; %tmpindex++)
{
if ($ProtectedIPList[%tmpindex] != "") {
%idx = String::FindSubStr(%ip, $ProtectedIPList[%tmpindex]);
if (%idx != -1)
{
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" was protected by ProtectedIPList[" @ %tmpindex @ "] from '" @ %reason @ "'");
return 1;
}
}
}
return 0;
}
function Admin::LizCheckNoAdminIPList(%clientId)
{
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
%ip = Client::getTransportAddress(%clientId);
for(%tmpindex = 1; %tmpindex <= $NoAdminIPListCount; %tmpindex++)
{
if ($NoAdminIPList[%tmpindex] != "") {
%idx = String::FindSubStr(%ip, $NoAdminIPList[%tmpindex]);
if (%idx != -1)
{
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" was found on the NoAdminIPList[" @ %tmpindex @ "]" @ %dtstr);
return 1;
}
}
}
return 0;
}
function Admin::LizCheckAdminPasswordNameLookupExceptionIP(%clientId)
{
%ip = Client::getTransportAddress(%clientId);
for(%tmpindex = 1; %tmpindex <= $AdminPasswordNameLookupExceptionIPCount; %tmpindex++)
{
if ($AdminPasswordNameLookupExceptionIP[%tmpindex] != "") {
%idx = String::FindSubStr(%ip, $AdminPasswordNameLookupExceptionIP[%tmpindex]);
if (%idx != -1)
{
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" was found on the AdminPasswordNameLookupExceptionIP[" @ %tmpindex @ "]");
return 1;
}
}
}
return 0;
}
function Admin::LizCheckAdminPasswordNameLookup(%clientId)
{
%name = Client::getName(%clientId);
for(%tmpindex = 1; %tmpindex <= $AdminPasswordNameLookupCount; %tmpindex++)
{
if ($AdminPasswordNameLookup[%tmpindex] != "") {
%idx = String::FindSubStr(%name, $AdminPasswordNameLookup[%tmpindex]);
if (%idx != -1)
{
return 1;
}
}
}
return 0;
}
function Admin::changeMissionMenu(%clientId, %option)
{
Client::buildMenu(%clientId, "Pick Mission Type", "cmtype", true);
%index = 1;
if ($MList::TypeCount < 2) {
$TypeStart = 0;
}
else {
$TypeStart = 1;
}
for(%type = $TypeStart; %type < $MLIST::TypeCount; %type++)
{
if($MLIST::Type[%type] != "Training")
{
if (($MapTypeChangeOnlySuperAdmin == 1) && ($MLIST::Type[%type] != $Arena::MissionType))
{
if (%clientId.IsSuperAdmin)
{
Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type], %type @ " 0 " @ %option);
%index++;
}
}
else
{
if (($MapDuelOnlySuperAdmin == 1) && ($MLIST::Type[%type] == "Duel"))
{
if (%clientId.IsSuperAdmin)
{
Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type], %type @ " 0 " @ %option);
%index++;
}
}
else
{
Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type], %type @ " 0 " @ %option);
%index++;
}
}
}
}
}
function processMenuCMType(%clientId, %options)
{
%curItem = 0;
%option = getWord(%options, 0);
%first = getWord(%options, 1);
%extraoption = getWord(%options, 2);
Client::buildMenu(%clientId, "Pick Mission (R=recnt.played)", "cmission", true);
for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%option], %first + %i)) != -1; %i++)
{
if (%i > 6)
{
Client::addMenuItem(%clientId, %i+1 @ "More missions...", "more " @ %first + %i @
" " @ %option @ " " @ %extraoption);
break;
}
%misName = $MLIST::EName[%misIndex];
%lastplayed = LizStats::CheckLastPlayedMaps(%misName);
if (%lastplayed != 0) {
%misName = %misName @ " [R]";
}
Client::addMenuItem(%clientId, %i+1 @ %misName, %misIndex @ " " @
%option @ " " @ %extraoption);
}
}
function processMenuCMission(%clientId, %option)
{
if(getWord(%option, 0) == "more")
{
%first = getWord(%option, 1);
%type = getWord(%option, 2);
%extraoption = getWord(%option, 3);
processMenuCMType(%clientId, %type @ " " @ %first @ " " @ %extraoption);
return;
}
%mi = getWord(%option, 0);
%mt = getWord(%option, 1);
%misName = $MLIST::EName[%mi];
%misType = $MLIST::Type[%mt];
if(%misType == "" || %misType == "Training")
return;
for(%i = 0; true; %i++)
{
%misIndex = getWord($MLIST::MissionList[%mt], %i);
if(%misIndex == %mi)
break;
if(%misIndex == -1)
return;
}
if ($AllAdminsCanVoteMaps == 1)
{
if(%clientId.isAdmin && getWord(%option, 2) == "cmission")
{
messageAll(0, Client::getName(%clientId) @ " changed the mission to " @ %misName @ " (" @ %misType @ ")");
Vote::changeMission();
Server::loadMission(%misName);
}
else
{
if (($Game::missionType != "") && ($Game::missionType == $Arena::GameMissionType) && ($Arena::MatchMode == 0) && ($LizStatsLoaded == 1))
{
if (LizStats::CheckIfCurrentMap(%misName) == true)
{
Client::sendMessage(%clientId, 1, "You are already playing " @ $missionName @ ". Vote cancelled.");
}
else
{
if ((%client.isTrustedAdmin == true) || (%client.isSuperAdmin == true) || (%client.isServerSuperAdmin == true))
{
Admin::startVote(%clientId, "change mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName);
Game::menuRequest(%clientId);
}
else
{
%timedelta = -1;
%curtime = getIntegerTime(true) >> 5;
if ($LizStats::VoteTimes::LastMapChangeVotePassTime >= 0) {
if ($LizStats::VoteTimes::LastMapChangeVotePassTime <= %curtime) {
%timedelta = %curtime - $LizStats::VoteTimes::LastMapChangeVotePassTime;
}
}
if (($ArenaMinTimeBetweenPassedMapVotes >= 0) && (%timedelta > 0) && (%timedelta <= $ArenaMinTimeBetweenPassedMapVotes))
{
Client::sendMessage(%clientId, 1, "A mission change vote has recently passed. You can not start another vote just yet. Vote cancelled.");
}
else
{
%timedelta = -1;
%curtime = getIntegerTime(true) >> 5;
if ($LizStats::VoteTimes::LastMapChangeVoteFailTime >= 0) {
if ($LizStats::VoteTimes::LastMapChangeVoteFailTime <= %curtime) {
%timedelta = %curtime - $LizStats::VoteTimes::LastMapChangeVoteFailTime;
}
}
if (($ArenaMinTimeBetweenFailedMapVotes >= 0) && (%timedelta > 0) && (%timedelta <= $ArenaMinTimeBetweenFailedMapVotes))
{
Client::sendMessage(%clientId, 1, "A mission change vote has recently failed. You can not start another vote just yet. Vote cancelled.");
}
else
{
%maxroundsleft = Arena::ComputeMaxRoundsLeft();
if (($ArenaMapSoonOverNbRounds >= 0) && (%maxroundsleft >= 0) && (%maxroundsleft <= $ArenaMapSoonOverNbRounds))
{
Client::sendMessage(%clientId, 1, "There are only " @ %maxroundsleft @ " rounds left max! Please wait until map is over and grow some patience. Vote cancelled.");
}
else
{
%lastplayed = LizStats::CheckLastPlayedMaps(%misName);
if (%lastplayed != 0)
{
%recentmaplist = LizStats::GetRecentMapList();
if (%recentmaplist != "") {
%recentmaplist = "Recently played maps are: " @ %recentmaplist @ ". ";
}
Client::sendMessage(%clientId, 1, "This map has already been played too recently. Please select another map. Vote cancelled.");
}
else
{
Admin::startVote(%clientId, "change mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName);
Game::menuRequest(%clientId);
}
}
}
}
}
}
}
else
{
Admin::startVote(%clientId, "change mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName);
Game::menuRequest(%clientId);
}
}
}
else
{
if(%clientId.isAdmin)
{
messageAll(0, Client::getName(%clientId) @ " changed the mission to " @ %misName @ " (" @ %misType @ ")");
Vote::changeMission();
Server::loadMission(%misName);
}
else
{
Admin::startVote(%clientId, "change the mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName);
Game::menuRequest(%clientId);
}
}
}
function remoteAdminPassword(%client, %password)
{
if($AdminPassword == "")
return;
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
%isProhibited = Admin::LizCheckNoAdminIPList(%client);
if (%isProhibited == 1)
return;
if (%password == $UnadminPassword) {
%client.isAdmin = false;
%client.isTrustedAdmin = false;
%client.isSuperAdmin = false;
%client.isServerSuperAdmin = false;
Game::refreshClientScore(%client);
bottomprint(%client, "<jc><f0>You have <f2>removed your admin<f0> using the unadmin password", $adminMessageToPlayerDuration);
return;
}
for(%tmpindex = 1; %tmpindex <= $KickMyselfCount; %tmpindex++)
{
if (%password == $KickMyselfPassword[%tmpindex])
{
Client::sendMessage(%client, 1, "You have just entered the 'kick myself' password. Just stop asking for it?");
schedule("remoteAdminPasswordKick(" @ %client @ ");", 1, %client);
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" has entered the kick password..");
}
}
if($AdminPassword != "" && %password == $AdminPassword)
{
if ($AdminPasswordNameLookupEnable == 1)
{
%exceptionlist = Admin::LizCheckAdminPasswordNameLookupExceptionIP(%client);
if (%exceptionlist == 0) {
%namelookup = Admin::LizCheckAdminPasswordNameLookup(%client);
if (%namelookup == 0) {
Client::sendMessage(%client,1,"Your name is not on the registered admins list. Contact the server admin if you feel this is an error.");
return;
}
}
}
%client.isAdmin = true;
%client.isTrustedAdmin = true;
%client.isSuperAdmin = true;
Game::refreshClientScore(%client);
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" has been super admined using AdminPassword" @ %dtstr);
bottomprint(%client, "<jc><f0>You have become <f2>Super Admin<f0> using the sad password", $adminMessageToPlayerDuration);
}
for(%tmpindex = 1; %tmpindex <= $TrustedAdminCount; %tmpindex++)
{
if (%password == $TrustedAdminPassword[%tmpindex])
{
if ($AdminPasswordNameLookupEnable == 1)
{
%exceptionlist = Admin::LizCheckAdminPasswordNameLookupExceptionIP(%client);
if (%exceptionlist == 0) {
%namelookup = Admin::LizCheckAdminPasswordNameLookup(%client);
if (%namelookup == 0) {
Client::sendMessage(%client,1,"Your name is not on the registered admins list. Contact the server admin if you feel this is an error.");
return;
}
}
}
%client.isAdmin = true;
%client.isTrustedAdmin = true;
Game::refreshClientScore(%client);
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" has been admined using TrustedAdminPassword" @ %dtstr);
bottomprint(%client, "<jc><f0>You have become <f2>Moderator Admin<f0> using the sad password", $adminMessageToPlayerDuration);
}
}
for(%tmpindex = 1; %tmpindex <= $RegularAdminCount; %tmpindex++)
{
if (%password == $RegularAdminPassword[%tmpindex])
{
if ($AdminPasswordNameLookupEnable == 1)
{
%exceptionlist = Admin::LizCheckAdminPasswordNameLookupExceptionIP(%client);
if (%exceptionlist == 0) {
%namelookup = Admin::LizCheckAdminPasswordNameLookup(%client);
if (%namelookup == 0) {
Client::sendMessage(%client,1,"Your name is not on the registered admins list. Contact the server admin if you feel this is an error.");
return;
}
}
}
%client.isAdmin = true;
Game::refreshClientScore(%client);
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" has been admined using RegularAdminPassword" @ %dtstr);
bottomprint(%client, "<jc><f0>You have become <f2>Admin<f0> using the sad password", $adminMessageToPlayerDuration);
}
}
}
function remoteAdminPasswordKick(%client)
{
%isProtected = Admin::LizCheckProtectedIPList(%client, "Admin password kick");
if (%isProtected == 1)
{
Client::sendMessage(%client, 1, "You are on the protected IP list. Kick/ban cancelled.");
return;
}
%ip = Client::getTransportAddress(%client);
if(%ip == "")
return;
BanList::add(%ip, $AdminKickPasswordTimeSeconds);
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
%name = Client::getName(%client);
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" was kicked for using the kick password" @ %dtstr);
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
LizStats::UpdateServerStatsTotalKicks(1);
MessageAll(0, %name @ " has decided to come back later..");
Net::kick(%client, "You were " @ %word @ " by yourself.");
}
function remoteSetPassword(%client, %password)
{
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
if((%client.isSuperAdmin) || (%client.isTrustedAdmin && $TrustedAdminCanSetServerPassword == 1))
{
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" has changed server password to \"" @ %password @ "\"" @ %dtstr);
$Server::Password = %password;
}
}
function remoteSetTimeLimit(%client, %time)
{
%time = floor(%time);
if (%time == $Server::timeLimit || (%time != 0 && %time < 1))
return;
if (%client.isAdmin)
{
$Server::timeLimit = %time;
if(%time)
messageAll(0, Client::getName(%client) @ " changed the time limit to " @ %time @ " minute(s).");
else
messageAll(0, Client::getName(%client) @ " disabled the time limit.");
}
}
function remoteSetTeamInfo(%client, %team, %teamName, %skinBase)
{
if(%team >= 0 && %team < 8 && %client.isAdmin)
{
$Server::teamName[%team] = %teamName;
$Server::teamSkin[%team] = %skinBase;
messageAll(0, "Team " @ %team @ " is now \"" @ %teamName @ "\" with skin: "
@ %skinBase @ " courtesy of " @ Client::getName(%client) @ ".  Changes will take effect next mission.");
}
}
function remoteVoteYes(%clientId)
{
%clientId.vote = "yes";
centerprint(%clientId, "", 0);
}
function remoteVoteNo(%clientId)
{
%clientId.vote = "no";
centerprint(%clientId, "", 0);
}
function Admin::startMatch(%admin)
{
if(%admin == -1 || %admin.isAdmin)
{
if(!$CountdownStarted && !$matchStarted)
{
if(%admin == -1)
messageAll(0, "Match start countdown forced by vote.");
else
messageAll(0, "Match start countdown forced by " @ Client::getName(%admin));
Game::ForceTourneyMatchStart();
}
}
}
function Admin::setTeamDamageEnable(%admin, %enabled)
{
if(%admin == -1 || %admin.isAdmin)
{
if(%enabled)
{
$Server::TeamDamageScale = 1;
if(%admin == -1)
messageAll(0, "Team damage set to ENABLED by consensus.");
else
messageAll(0, Client::getName(%admin) @ " ENABLED team damage.");
}
else
{
$Server::TeamDamageScale = 0;
if(%admin == -1)
messageAll(0, "Team damage set to DISABLED by consensus.");
else
messageAll(0, Client::getName(%admin) @ " DISABLED team damage.");
}
}
}
function Admin::kick(%admin, %client, %ban)
{
if(%ban == "pban")
{
%permaban = true;
%ban = true;
%word = "perma-banned";
%wordverb = "perma-ban";
%cmd = "PERMABAN: ";
}
else if(%ban)
{
%permaban = false;
%word = "banned";
%wordverb = "ban";
%cmd = "BAN: ";
}
else
{
%permaban = false;
%word = "kicked";
%wordverb = "kick";
%cmd = "KICK: ";
}
if (%admin == -1) {
%wordoption = "vote";
}
else {
%wordoption = "by admin " @ Client::getName(%admin);
}
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
echo("LIZADMIN: " @ %admin @ " \"" @
escapeString(Client::getName(%admin)) @
"\" on " @ Client::getTransportAddress(%admin) @
" wants to " @ %wordverb @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @ %dtstr);
%isProtected = Admin::LizCheckProtectedIPList(%client, %wordverb @ " " @ %wordoption);
if (%isProtected == 1)
{
Client::sendMessage(%client, 1, "You are on the protected IP list. Kick/ban from " @ Client::getName(%admin) @ " cancelled.");
Client::sendMessage(%admin, 1, "You are unfortunately not able to do that.");
return;
}
if(%admin != %client && (%admin == -1 || %admin.isAdmin))
{
if(%ban && !%admin.isSuperAdmin)
return;
if(%permaban && !%admin.isServerSuperAdmin)
return;
if(%client.isSuperAdmin)
{
if(%admin.isServerSuperAdmin)
{
}
else
{
if(%admin == -1)
messageAll(0, "A super admin cannot be " @ %word @ ".");
else
Client::sendMessage(%admin, 0, "A super admin cannot be " @ %word @ ".");
return;
}
}
if(%client.isTrustedAdmin)
{
if(%ban)
{
}
else
{
if (%admin.isSuperAdmin)
{
}
else
{
if ($TrustedAdminCanNotBeKicked == 1)
{
if(%admin == -1)
messageAll(0, "This admin cannot be " @ %word @ ".");
else
Client::sendMessage(%admin, 0, "A super admin cannot be " @ %word @ ".");
return;
}
}
}
}
%ip = Client::getTransportAddress(%client);
echo("LIZADMIN: " @ %cmd @ %admin @ " " @ %client @ " " @ %ip @ %dtstr);
if(%ip == "")
return;
if(%permaban)
BanList::add(%ip, $AdminPermaBanTimeSeconds);
else if(%ban)
BanList::add(%ip, $AdminBanTimeSeconds);
else
BanList::add(%ip, $AdminKickTimeSeconds);
%name = Client::getName(%client);
if(%admin == -1)
{
echo("LIZADMIN: " @ %client @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @
" was " @ %word @ " from vote" @ %dtstr);
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if (%word == "banned")
LizStats::UpdateServerStatsTotalBans(1);
else if (%word == "kicked")
LizStats::UpdateServerStatsTotalKicks(1);
}
MessageAll(0, %name @ " was " @ %word @ " from vote.");
Net::kick(%client, "You were " @ %word @ " by  consensus.");
}
else
{
echo("LIZADMIN: " @ %admin @ " \"" @
escapeString(Client::getName(%admin)) @
"\" on " @ Client::getTransportAddress(%admin) @
" has " @ %word @ " \"" @
escapeString(Client::getName(%client)) @
"\" on " @ Client::getTransportAddress(%client) @ %dtstr);
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if (%word == "banned")
LizStats::UpdateServerStatsTotalBans(1);
else if (%word == "kicked")
LizStats::UpdateServerStatsTotalKicks(1);
}
MessageAll(0, %name @ " was " @ %word @ " by " @ Client::getName(%admin) @ ".");
Net::kick(%client, "You were " @ %word @ " by " @ Client::getName(%admin));
}
}
}
function Admin::setModeFFA(%clientId)
{
if($Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
{
$Server::TeamDamageScale = 0;
if(%clientId == -1)
messageAll(0, "Server switched to Free-For-All Mode.");
else
messageAll(0, "Server switched to Free-For-All Mode by " @ Client::getName(%clientId) @ ".");
$Server::TourneyMode = false;
centerprintall(); // clear the messages
if(!$matchStarted && !$countdownStarted)
{
if($Server::warmupTime)
Server::Countdown($Server::warmupTime);
else
Game::startMatch();
}
}
}
function Admin::setModeTourney(%clientId)
{
if(!$Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
{
$Server::TeamDamageScale = 1;
if(%clientId == -1)
messageAll(0, "Server switched to Tournament Mode.");
else
messageAll(0, "Server switched to Tournament Mode by " @ Client::getName(%clientId) @ ".");
$Server::TourneyMode = true;
Server::nextMission();
}
}
function Admin::voteFailed()
{
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1)) {
LizStats::VoteFailTimesUpdate($curVoteAction, $curVoteTopic);
}
$curVoteInitiator.numVotesFailed++;
if($curVoteAction == "kick" || $curVoteAction == "admin")
$curVoteOption.voteTarget = "";
}
function Admin::voteSucceded()
{
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1)) {
LizStats::VotePassTimesUpdate($curVoteAction, $curVoteTopic);
}
$curVoteInitiator.numVotesFailed = "";
if($curVoteAction == "kick")
{
if($curVoteOption.voteTarget)
Admin::kick(-1, $curVoteOption);
}
else if($curVoteAction == "admin")
{
if($curVoteOption.voteTarget)
{
%isProhibited = Admin::LizCheckNoAdminIPList($curVoteOption);
if (%isProhibited == 1)
{
messageAll(0, Client::getName($curVoteOption) @ " can not become an administrator.");
}
else
{
$curVoteOption.isAdmin = true;
messageAll(0, Client::getName($curVoteOption) @ " has become an administrator.");
Game::refreshClientScore($curVoteOption);
bottomprint(%client, "<jc><f0>You have become <f2>Admin<f0> by <f2>vote<f0>", $adminMessageToPlayerDuration);
}
if($curVoteOption.menuMode == "options")
Game::menuRequest($curVoteOption);
}
$curVoteOption.voteTarget = false;
}
else if(($curVoteAction == "cmission") || ($curVoteAction == "vcmission"))
{
messageAll(0, "Changing to mission " @ $curVoteOption @ ".");
Vote::changeMission();
Server::loadMission($curVoteOption);
}
else if($curVoteAction == "tourney")
Admin::setModeTourney(-1);
else if($curVoteAction == "ffa")
Admin::setModeFFA(-1);
else if($curVoteAction == "etd")
Admin::setTeamDamageEnable(-1, true);
else if($curVoteAction == "dtd")
Admin::setTeamDamageEnable(-1, false);
else if($curVoteOption == "smatch")
Admin::startMatch(-1);
}
function Admin::countVotes(%curVote)
{
if (%curVote != $curVoteCount) {
return;
}
%votesFor = 0;
%votesAgainst = 0;
%votesAbstain = 0;
%totalClients = 0;
%totalVotes = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
%totalClients++;
if(%cl.vote == "yes")
{
%votesFor++;
%totalVotes++;
}
else if(%cl.vote == "no")
{
%votesAgainst++;
%totalVotes++;
}
else {
%votesAbstain++;
}
}
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1)) {
LizStats::VoteTimesUpdate($curVoteAction, $curVoteTopic);
}
%minVotes = floor($Server::MinVotesPct * %totalClients);
if (%minVotes < $Server::MinVotes) {
%minVotes = $Server::MinVotes;
}
if (%totalVotes < %minVotes)
{
messageAll(0, "Vote to " @ $curVoteTopic @ " failed because there were " @
"not enough votes (" @ %votesFor @ " to " @ %votesAgainst @ " with " @
%votesAbstain @ " abstentions)");
Admin::voteFailed();
}
else
{
if ($curVoteAction == "admin") {
%margin = $Server::VoteAdminWinMargin;
}
else {
%margin = $Server::VoteWinMargin;
}
if (%votesFor / %totalVotes >= %margin)
{
messageAll(0, "Vote to " @ $curVoteTopic @ " passed (" @ %votesFor @
" to " @ %votesAgainst @ " with " @ %votesAbstain @ " abstentions)");
Admin::voteSucceded();
}
else if ($curVoteAction == "kick")
{
%votesFor = 0;
%votesAgainst = 0;
%votesAbstain = 0;
%totalVotes = 0;
for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
if (%cl.matchTeam == $curVoteOption.kickTeam)
{
if(%cl.vote == "yes")
{
%votesFor++;
%totalVotes++;
}
else if(%cl.vote == "no")
{
%votesAgainst++;
%totalVotes++;
}
else {
%votesAbstain++;
}
}
}
if ((%totalVotes >= $Server::MinVotes) && (%votesFor / %totalVotes >= $Server::VoteWinMargin))
{
messageAll(0, "Vote to " @ $curVoteTopic @ " passed (" @ %votesFor @
" to " @ %votesAgainst @ " with " @ %votesAbstain @ " abstentions)");
Admin::voteSucceded();
}
else
{
messageAll(0, "Vote to " @ $curVoteTopic @ " failed (" @ %votesFor @
" to " @ %votesAgainst @ " with " @ %votesAbstain @ " abstentions)");
Admin::voteFailed();
}
}
else
{
messageAll(0, "Vote to " @ $curVoteTopic @ " failed (" @ %votesFor @
" to " @ %votesAgainst @ " with " @ %votesAbstain @ " abstentions)");
Admin::voteFailed();
}
}
$curVoteTopic = "";
}
function Admin::startVote(%clientId, %topic, %action, %option)
{
if(%clientId.lastVoteTime == "")
%clientId.lastVoteTime = -$Server::MinVoteTime;
%time = getIntegerTime(true) >> 5;
%diff = %clientId.lastVoteTime + $Server::MinVoteTime - %time;
if ((%clientId.VoteIncrementalDelay != "") && (%clientId.VoteIncrementalDelay != 0))
%diff = %diff + %clientId.VoteIncrementalDelay;
if(%diff > 0)
{
Client::sendMessage(%clientId, 0, "You can't start another vote for " @ floor(%diff) @ " seconds.");
return;
}
if($curVoteTopic == "")
{
if(%clientId.numFailedVotes)
%time += %clientId.numFailedVotes * $Server::VoteFailTime;
%clientId.lastVoteTime = %time;
if ((%clientId.VoteIncrementalDelay == 0) || (%clientId.VoteIncrementalDelay == ""))
%clientId.VoteIncrementalDelay = 0.1;
else
%clientId.VoteIncrementalDelay = %clientId.VoteIncrementalDelay + $MapVoteIncrementalDelay;
$curVoteInitiator = %clientId;
$curVoteTopic = %topic;
$curVoteAction = %action;
$curVoteOption = %option;
if(%action == "kick")
$curVoteOption.kickTeam = GameBase::getTeam($curVoteOption);
$curVoteCount++;
bottomprintall("<jc><f1>" @ Client::getName(%clientId) @ " <f0>initiated a vote to <f1>" @ $curVoteTopic, 10);
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
%cl.vote = "";
%clientId.vote = "yes";
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
if(%cl.menuMode == "options")
Game::menuRequest(%clientId);
schedule("Admin::countVotes(" @ $curVoteCount @ ", true);", $Server::VotingTime, 35);
}
else
{
Client::sendMessage(%clientId, 0, "Voting already in progress.");
}
}
function remoteSelectClient(%clientId, %selId)
{
if(%clientId.selClient != %selId)
{
%clientId.selClient = %selId;
if(%clientId.menuMode == "options")
Game::menuRequest(%clientId);
remoteEval(%clientId, "setInfoLine", 1, "Player Info for " @ Client::getName(%selId) @ ":");
remoteEval(%clientId, "setInfoLine", 2, "Real Name: " @ $Client::info[%selId, 1]);
remoteEval(%clientId, "setInfoLine", 3, "Email Addr: " @ $Client::info[%selId, 2]);
remoteEval(%clientId, "setInfoLine", 4, "Tribe: " @ $Client::info[%selId, 3]);
remoteEval(%clientId, "setInfoLine", 5, "URL: " @ $Client::info[%selId, 4]);
remoteEval(%clientId, "setInfoLine", 6, "Other: " @ $Client::info[%selId, 5]);
}
}
function processMenuFPickTeam(%clientId, %team)
{
if(%clientId.isAdmin)
processMenuPickTeam(%clientId.ptc, %team, %clientId);
%clientId.ptc = "";
}
function processMenuKAffirm(%clientId, %opt)
{
if(getWord(%opt, 0) == "yes")
Admin::kick(%clientId, getWord(%opt, 1));
Game::menuRequest(%clientId);
}
function processMenuBAffirm(%clientId, %opt)
{
if(getWord(%opt, 0) == "yes")
Admin::kick(%clientId, getWord(%opt, 1), true);
Game::menuRequest(%clientId);
}
function processMenuRAffirm(%clientId, %opt)
{
if(%opt == "yes" && %clientId.isAdmin)
{
messageAll(0, Client::getName(%clientId) @ " reset the server to default settings.");
Server::refreshData();
}
Game::menuRequest(%clientId);
}
function processMenuCTLimit(%clientId, %opt)
{
remoteSetTimeLimit(%clientId, %opt);
}
$arenaadmin_cs_version = "$Revision: 18 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaAdmin.cs v" @ $Arena::Version @ ", internal version " @ $arenaadmin_cs_version);
