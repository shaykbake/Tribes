// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// MAIN MODULE
// __________________________________________________________________________
// Original Tribes Arena v 2.3 and prior versions
// by Robert "Rasia" Hinkle
// __________________________________________________________________________
// INTERESTING COMMAND LINE FUNCTIONS:
//
//    Arena::ListPlayers();
//       Will display all connected players, and their score
//    Arena::DisplayVersion();
//       Will display all arena files revisions and ensure everything is 
//       properly installed. See the Arena_Readme.txt for more information 
//       on that command.
// __________________________________________________________________________
//
// Rasia's comments:
//
// This is a mission type taken from the idea of Clan Arena back in the good 
// old Quake 1 days. Its a Team DM game, in which everyone spawns, you rush 
// for weapons, and try to kill each other. When you die, you sit in observer 
// mode until one team is all dead.  When that happens everyone respawns.
// I used a couple definations here:  a Match is a full compatition between 
// two teams.  Each match is made up of a set of Games.  When one team fully 
// dies, thats the end of a game.  Most matches are 3 out of 5 Games.
// I want to thank TheGriffin and Ninja for the help!
//
// Special Thanks goes to Figy, for being the closest to guess the Number of 
// lines of Code Arena.cs is late at night when I was bored!!
// Honorable mention goes to DVCxPanda who got within 2 lines for his second 
// guess
//
// Special Thanks to [PEN]Spiffy and [PEN]Venom for helping me test out the 
// latest build (2.3) 
// HUGE Thanks to Nookie, for being my little test dummy on, trying to fix 
// the OpenGl crash bug!!
// __________________________________________________________________________
//

exec("arenaInit.cs");
exec("arenaAdmin.cs");
exec("arenaComchat.cs");
exec("arenaGame.cs");
exec("arenaGUI.cs");
exec("arenaItem.cs");
exec("arenaObjectives.cs");
exec("arenaObserver.cs");
exec("arenaPlayer.cs");
exec("arenaServer.cs");
exec("arenaStation.cs");
exec("arenaStaticShape.cs");
function Arena::PickTeam(%clientId, %team, %adminClient)
{
if (%team != -1 && %team == Client::getTeam(%clientId))
return;
if (%clientId.lock)
return;
if (%clientId.observerMode == "justJoined")
{
if (%clientId.timeWentInObsSimTime < 0) {
%clientId.timeWentInObsSimTime = floor(getSimTime());
}
%clientId.observerMode = "";
centerprint(%clientId, "");
}
if (%team == -2)
{
if (%clientId.timeWentInObsSimTime < 0) {
%clientId.timeWentInObsSimTime = floor(getSimTime());
}
if(Observer::enterObserverMode(%clientId))
{
%clientId.notready = "";
%clientId.onteam = " ";
}
Game::refreshClientScore(%clientId);
ObjectiveMission::refreshTeamScores();
return;
}
%clientId.timeWentInObsSimTime = -1;
%player = Client::getOwnedObject(%clientId);
if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
{
playNextAnim(%clientId);
Player::kill(%clientId);
}
%clientId.observerMode = "";
if(%team == -1)
{
Game::assignClientTeam(%clientId);
%team = Client::getTeam(%clientId);
}
GameBase::setTeam(%clientId, %team);
%clientId.teamEnergy = 0;
Client::clearItemShopping(%clientId);
if (Client::getGuiMode(%clientId) != 1)
Client::setGuiMode(%clientId,1);
Client::setControlObject(%clientId, -1);
Game::playerSpawn(%clientId, false);
%team = Client::getTeam(%clientId);
Game::RefreshClientScore(%clientId);
ObjectiveMission::refreshTeamScores();
if ($Arena::ReadyTime && %team != -2)
{
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
schedule("Arena::CheckReadyState(" @ %clientId @ ");", $ArenaCheckReadyStateDurationReadyUpDisabled);
}
else {
schedule("Arena::CheckReadyState(" @ %clientId @ ");", $ArenaCheckReadyStateDuration);
}
}
}
function Arena::CheckTeamDeath(%team)
{
%teamCount = Arena::CountTeamPlayers(%team);
%otherteam = 1 - %team;
if (%teamCount == 1) {
%gender = Arena::LastAlivePlayerGender(%team);
if (%gender == 0)
messageAll(0, getTeamName(%team) @ " has one member left.  FINISH HER!~warenafinisher.wav");
else
messageAll(0, getTeamName(%team) @ " has one member left.  FINISH HIM!~warenafinishim.wav");
}
if (%teamCount < 1 && $Arena::MatchStatus == 1)
{
$Arena::MatchStatus = 2;
centerPrintAll("<jc>" @ getTeamName(%otherTeam) @ " has won the game\n\n\n" @ Arena::GetTeamScoresString(%otherteam), 3);
schedule("Arena::GameOver(" @ %otherteam @ ");", 4);
}
}
function Arena::CheckAllTeamDeaths()
{
if ($Arena::MatchStatus == 1)
{
%teamCount[0] = Arena::CountGameStartTeamPlayers(0);
%teamCount[1] = Arena::CountGameStartTeamPlayers(1);
if ((%teamCount[0] == 0) && (%teamCount[1] > 0))
{
$Arena::MatchStatus = 2;
centerPrintAll("<jc>" @ getTeamName(1) @ " has won the game\n\n\n" @ Arena::GetTeamScoresString(1), 3);
schedule("Arena::GameOver(1);", 4);
}
else if ((%teamCount[0] > 0) && (%teamCount[1] == 0))
{
$Arena::MatchStatus = 2;
centerPrintAll("<jc>" @ getTeamName(0) @ " has won the game\n\n\n" @ Arena::GetTeamScoresString(0), 3);
schedule("Arena::GameOver(0);", 4);
}
else if ((%teamCount[0] == 0) && (%teamCount[1] == 0))
{
$Arena::MatchStatus = 2;
centerPrintAll("<jc>Both teams have no more alive players... Tie game.", 3);
schedule("Arena::TieGame(0);", 4);
}
}
}
function Arena::GameOver(%winningTeam)
{
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if ($UseNewScoringSystem == 1) {
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
LizStats::UpdateMapStatsCheckClientRank(%cl, $Arena::MatchMode);
}
}
else {
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
LizStats::UpdateMapStatsCheckClientScore(%cl, $Arena::MatchMode);
}
}
}
}
Arena::AutoKickAFKersFullServer();
ObjectiveMission::setObjectiveHeading();
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Client::setGuiMode(%clientId, $GuiModePlay);
if (%cl.matchteam != -2)
{
%player = Client::getOwnedObject(%cl);
if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
{
playNextAnim(%cl);
Player::kill(%cl);
if ($Arena::MatchMode == 1 && %cl.isTeamCaptain) {
%cl.notready = true;
}
}
Arena::PickTeam(%cl, -2);
}
}
$Arena::ForceMatchAcceptOverride = 0;
$TeamMatchScore[%winningTeam]++;
ObjectiveMission::refreshTeamScores();
if ($TeamMatchScore[0] > $TeamMatchScore[1])
{
$PreGameMessage[0] = "<f1><jc>You are winning by " @ $TeamMatchScore[0] - $TeamMatchScore[1] @ ".  You need " @  $Arena::Scorelimit - $TeamMatchScore[0] @ " games to win! \n ";
$PreGameMessage[1] = "<f1><jc>You are losing by " @ $TeamMatchScore[0] - $TeamMatchScore[1] @ ".  They need " @ $Arena::Scorelimit - $TeamMatchScore[0] @ " games to win! \n ";
}
else if ($TeamMatchScore[0] < $TeamMatchScore[1])
{
$PreGameMessage[1] = "<f1><jc>You are winning by " @ $TeamMatchScore[1] - $TeamMatchScore[0] @ ".  You need " @ $Arena::Scorelimit - $TeamMatchScore[1] @ " games to win! \n ";
$PreGameMessage[0] = "<f1><jc>You are losing by " @ $TeamMatchScore[1] - $TeamMatchScore[0] @ ".  They need " @ $Arena::Scorelimit - $TeamMatchScore[1] @ " games to win! \n ";
}
else
{
$PreGameMessage[0] = "<f1><jc>You are tied.  You need " @ $Arena::Scorelimit - $TeamMatchScore[0] @ " games to win! \n ";
$PreGameMessage[1] = "<f1><jc>You are tied.  You need " @ $Arena::Scorelimit - $TeamMatchScore[1] @ " games to win! \n ";
}
if ($TeamMatchScore[%winningTeam] >= $Arena::Scorelimit || Arena::CountTeam(1 - %winningTeam) == 0)
{
$Arena::ReadyUpMessage = $Arena::ReadyUpMessageBackup;
Arena::MatchCompleted(%winningTeam);
if ($Arena::MatchStatus == 3)
{
schedule("Arena::ResetMatch();", 11);
}
return;
}
else
{
if ($Arena::MatchMode == 1)
$Arena::ReadyUpMessage = "Only your Captain needs to hit fire to READY up";
else
$Arena::ReadyUpMessage = "";
schedule("Arena::PutClientsBackOnTeams();", 6);
schedule("Arena::PreGameMode();", 7);
}
}
function Arena::PutClientsBackOnTeams()
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchteam != -2)
{
Arena::PickTeam(%cl, %cl.matchteam);
Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
%cl.notready = "";
}
else {
%cl.notready = true;
}
}
}
}
function Arena::MatchCompleted(%winningTeam)
{
if ($Arena::NumberMatchLimit <= 1) {
%extramsg="\nSwitching to next map in rotation...";
} else {
if ($Arena::MatchMode == 0) {
%extramsg="\n\nTeams will be randomized for the next match.";
} else {
%extramsg="\n\nMatch is now OVER.";
}
}
centerPrintAll("<jc>" @ getTeamName(%winningTeam) @ " has won the match!!" @ %extramsg, 4);
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchteam == %winningTeam)
{
%cl.score = %cl.score + 5;
%cl.scoreMatchWon++;
%cl.totalMatchWon++;
Arena::ComputePlayerRatios(%cl);
Game::refreshClientScore(%cl);
Client::sendMessage(%cl,0,"~warenaoutstanding.wav");
}
else
{
%cl.scoreMatchLost++;
%cl.totalMatchLost++;
Client::sendMessage(%cl,0,"~wflagcapture.wav");
}
}
$Arena::AutoEvenLastScore = -2;
schedule("Arena::ResetMatch();", 4);
$Arena::NumberMatchLimit--;
}
function Arena::ResetMatch()
{
if ($Arena::NumberMatchLimit < 1 && $Arena::NumberMatchLimit != "")
{
Server::NextMission();
return;
}
$Arena::MatchStatus = 0;
$PreGameMessage[0] = "<f1><jc>You are tied.  You need " @ $Arena::Scorelimit @ " games to win \n ";
$PreGameMessage[1] = "<f1><jc>You are tied.  You need " @ $Arena::Scorelimit @ " games to win \n ";
for (%i = 0; %i < getNumTeams(); %i++) {
$TeamMatchScore[%i] = 0;
}
$Arena::ResetMatchModeScoreNextRound = 1;
ObjectiveMission::refreshTeamScores();
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
%player = Client::getOwnedObject(%cl);
%cl.matchteam = -2;
%cl.isTeamCaptain = false;
%cl.FreeInvTimer = false;
if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
{
playNextAnim(%cl);
Player::kill(%cl);
}
if (!$Arena::AutoTeamJoin)
{
processMenuPickTeam(%cl, -2);
bottomprint(%cl, "<jc><f1>Server is running Tribes Arena v" @ $Arena::Version @ " and is in Pre-Match Mode. Pick a Team.  Score limit is " @ $Arena::Scorelimit, 5);
}
Game::refreshClientScore(%cl);
}
if ($Arena::AutoTeamJoin)
{
while(true)
{
%currenthighscore = -50000;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
%cl.notready = "";
}
else {
%cl.notready = true;
}
if (%cl.matchteam == -2 && %cl.lock == false)
{
%currentscore = %cl.score;
if (!%currentscore)
%currentscore = 0;
if (%currentscore > %currenthighscore || %currenthighscore == -50000)
{
%currenthighscore = %currentscore;
%currenthighclient = %cl;
}
}
}
if (%currenthighscore != -50000)
{
processMenuPickTeam(%currenthighclient, -1);
Game::refreshClientScore(%currenthighclient);
}
else
{
break;
}
}
}
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
LizStats::UpdateServerStatsTotalMatchesPlayed(1);
}
}
function Arena::CheckReadyStatus()
{
if ($Arena::MatchMode == 0)
{
if ($Arena::MatchStatus != 0)
return true;
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
return true;
}
%NotReadyString = "Clients not ready:";
%NotReadyCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if(%cl.observerMode == "pregame" && %cl.notready)
{
%NotReadyCount++;
%NotReadyString = %NotReadyString @ " " @ Client::getName(%cl);
}
}
if (%NotReadyCount > 0)
{
%NotReadyString = %NotReadyString @ ".";
if (%NotReadyCount < 4)
messageAll(0, %NotReadyString);
return false;
}
else
return true;
}
else
{
%NotReadyString = "Teams not ready:";
%NotReadyCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if(%cl.isTeamCaptain && %cl.notready)
{
%NotReadyCount++;
%NotReadyString = %NotReadyString @ " " @ getTeamName(Client::getTeam(%cl));
}
}
if (%NotReadyCount > 0)
{
%NotReadyString = %NotReadyString @ ".";
if (%NotReadyCount < 4)
messageAll(0, %NotReadyString);
return false;
}
else
return true;
}
}
function Arena::PreGameMode()
{
if (Arena::CountTeamPlayers(0) < 1 || Arena::CountTeamPlayers(1) < 1)
{
messageAll(0, "Teams not full, waiting for more players");
$Arena::ForceMatchAcceptOverride = 1;
}
else
{
if (Arena::CheckReadyStatus())
{
if ($Arena::MatchStatus == 3)
return;
if ($Arena::MatchMode == 0) {
Arena::CheckIfTeamsAreEven();
}
ObjectiveMission::setObjectiveHeading();
if ($Arena::MatchStatus == 0)
messageAll(0, "Arena Battle Starts in 10 seconds~wrumble.wav");
else
messageAll(0, "Arena Battle Starts in 10 seconds");
$Arena::MatchStatus = 3;
if ($Arena::MatchMode == 0) {
Arena::CheckIfTeamsAreEven();
}
schedule("messageAll(0, \"Arena Battle Starts in 5 seconds\");", 5);
schedule("messageAll(0, \"Arena Battle Starts in 4 seconds\");", 6);
schedule("messageAll(0, \"Arena Battle Starts in 3 seconds\");", 7);
schedule("messageAll(0, \"Arena Battle Starts in 2 seconds\");", 8);
schedule("messageAll(0, \"Arena Battle Starts in 1 seconds\");", 9);
schedule("Arena::StartGame();", 10);
}
}
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if ($UseNewScoringSystem == 1) {
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
LizStats::UpdateMapStatsCheckClientRank(%cl, $Arena::MatchMode);
}
}
else {
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
LizStats::UpdateMapStatsCheckClientScore(%cl, $Arena::MatchMode);
}
}
}
}
function Arena::ForceMatchStart()
{
if (($Arena::MatchMode == 1) || ($Arena::MatchStatus == 0) || ($Arena::ForceMatchAcceptOverride == 1))
{
$Arena::ForceMatchAcceptOverride = 0;
}
else
{
return;
}
if ($Arena::MatchMode == 0) {
Arena::CheckIfTeamsAreEven();
}
ObjectiveMission::setObjectiveHeading();
if ($Arena::MatchStatus == 0)
messageAll(0, "Arena Battle Starts in 10 seconds~wrumble.wav");
else
messageAll(0, "Arena Battle Starts in 10 seconds");
$Arena::MatchStatus = 3;
if ($Arena::MatchMode == 0)
{
Arena::CheckIfTeamsAreEven();
}
schedule("messageAll(0, \"Arena Battle Starts in 5 seconds\");", 5);
schedule("messageAll(0, \"Arena Battle Starts in 4 seconds\");", 6);
schedule("messageAll(0, \"Arena Battle Starts in 3 seconds\");", 7);
schedule("messageAll(0, \"Arena Battle Starts in 2 seconds\");", 8);
schedule("messageAll(0, \"Arena Battle Starts in 1 seconds\");", 9);
schedule("Arena::StartGame();", 10);
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
if ($UseNewScoringSystem == 1) {
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
LizStats::UpdateMapStatsCheckClientRank(%cl, $Arena::MatchMode);
}
}
else {
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
LizStats::UpdateMapStatsCheckClientScore(%cl, $Arena::MatchMode);
}
}
}
}
function Arena::StartGame()
{
$Arena::ForceMatchAcceptOverride = 0;
$Arena::MatchStatus = 1;
$Arena::GameStartTime = getSimTime();
Arena::CheckGameTimeLimit();
Arena::ResetItemCounts();
messageAll(0, "FIGHT!!!!~wfight.wav");
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (Client::getTeam(%cl) != %cl.matchteam && %cl.matchteam != -2) {
Arena::PickTeam(%cl, %cl.matchteam);
}
%cl.InvTrips = 0;
%cl.IsDeadNow = 0;
%cl.InvLastBuyTime = -1;
%cl.InvBuyCount = 0;
%cl.EnergyWarning = 0;
if (%cl.matchteam != -2)
{
%cl.observerMode = "";
Client::setControlObject(%cl, Client::getOwnedObject(%cl));
bottomprint(%cl, "", 0);
}
%cl.gameStartTeam = %cl.matchteam;
}
if (($Arena::ResetMatchModeScoreNextRound == 1) && ($Arena::MatchMode == 1))
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
Arena::ResetPlayerMapScore(%cl);
Arena::ComputePlayerRatios(%cl);
Game::refreshClientScore(%cl);
}
Arena::ResetTeamMapScore();
ObjectiveMission::refreshTeamScores();
}
$Arena::ResetMatchModeScoreNextRound = 0;
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
LizStats::UpdateServerStatsTotalGamesPlayed(1);
}
if ($AutoObsAFKers == 1)
{
Arena::GetAllPlayersPosition(0);
if ($Arena::MatchMode == 0) {
schedule("Arena::CheckAllPlayersForAFK(" @ $Arena::GameStartTime @ ");", $Arena::AFKDetectTimeFirstCheck);
}
}
}
function Arena::LastAlivePlayerGender(%team)
{
%teamCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (Client::getTeam(%cl) == %team)
{
if(!String::ICompare(Client::getGender(%cl), "Male"))
{
return 1;
}
else
{
return 0;
}
}
}
echo("MISC: Returning default stuff");
return 1;
}
function Arena::CountTeamPlayers(%team)
{
%teamCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (Client::getTeam(%cl) == %team)
%teamCount++;
}
return %teamCount;
}
function Arena::CountAliveTeamPlayers(%team)
{
%teamCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((Client::getTeam(%cl) == %team) && (%cl.onteam == "*"))
%teamCount++;
}
return %teamCount;
}
function Arena::CountGameStartTeamPlayers(%team)
{
%teamCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%cl.gameStartTeam == %team) && (%cl.onteam == "*"))
%teamCount++;
}
return %teamCount;
}
function Arena::CountTeam(%team)
{
%teamCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchteam == %team)
%teamCount++;
}
return %teamCount;
}
function Arena::CheckReadyState(%clientId)
{
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
}
else {
if (%clientId.notready && $Arena::ReadyTime && ($Arena::MatchStatus == 0 || $Arena::MatchStatus == 2))
{
processMenuPickTeam(%clientId, -2);
messageAll(0, Client::getName(%clientId) @ " didn't ready up in time and was placed in observer mode.");
}
}
if ($Arena::MatchStatus == 0 || $Arena::MatchStatus == 2)
{
Arena::PreGameMode();
}
}
function ceiling(%number)
{
if (floor(%number) == %number)
return %number;
else
return (1 + floor(%number));
}
function Arena::EnterMatchMode()
{
$Arena::AutoTeamJoin = false;
$Arena::ReadyTime = false;
$Arena::Scorelimit = $Arena::ScorelimitMatchMode;
messageAll(0, "Server has changed the Winning Score to " @ $Arena::Scorelimit);
$Arena::MatchMode = 1;
$TeamItemMax[LaserRifle] = 2;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Arena::ResetPlayerMapScore(%cl);
Arena::ComputePlayerRatios(%cl);
Game::refreshClientScore(%cl);
}
Arena::ResetMatch();
}
function Arena::EnterPubMode()
{
$Arena::AutoTeamJoin = true;
$Arena::ReadyTime = true;
$Arena::Scorelimit = $Arena::ScorelimitPubMode;
messageAll(0, "Server has changed the Winning Score to " @ $Arena::Scorelimit);
$Arena::MatchMode = 0;
if ($SniperRifleLimitInPubMode >= 0) {
$TeamItemMax[LaserRifle] = $SniperRifleLimitInPubMode;
}
else {
$TeamItemMax[LaserRifle] = "";
}
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Arena::ResetPlayerMapScore(%cl);
Arena::ComputePlayerRatios(%cl);
Game::refreshClientScore(%cl);
}
Arena::ResetMatch();
}
function Arena::CheckGameTimeLimit()
{
if ($Arena::GameTimeLimit == 0 || $Arena::MatchStatus != 1)
return;
%currentTime = getSimTime();
%currentTime = floor(%currentTime);
$Arena::GameStartTime = floor($Arena::GameStartTime);
if (($Arena::GameStartTime + $Arena::GameTimeLimit) <= %currentTime)
{
Arena::GameTimeLimitHit();
}
else if (($Arena::GameStartTime + $Arena::GameTimeLimit - 5) == %currentTime)
{
messageAll(0, "5 SECONDS LEFT IN THE GAME!!!");
schedule("Arena::CheckGameTimeLimit();", 5);
}
else if (($Arena::GameStartTime + $Arena::GameTimeLimit - 10) == %currentTime)
{
messageAll(0, "10 SECONDS LEFT IN THE GAME!!!");
schedule("Arena::CheckGameTimeLimit();", 5);
}
else if (($Arena::GameStartTime + $Arena::GameTimeLimit - 30) == %currentTime)
{
messageAll(0, "30 seconds left, better hurry!!!");
schedule("Arena::CheckGameTimeLimit();", 5);
}
else if (($Arena::GameStartTime + $Arena::GameTimeLimit - 60) == %currentTime)
{
messageAll(0, "1 Minute left in the Game");
schedule("Arena::CheckGameTimeLimit();", 5);
}
else if (($Arena::GameStartTime + $Arena::GameTimeLimit - 120) == %currentTime)
{
messageAll(0, "2 Minutes left in the Game");
schedule("Arena::CheckGameTimeLimit();", 5);
}
else
{
schedule("Arena::CheckGameTimeLimit();", 5);
}
}
function Arena::GameTimeLimitHit()
{
if (Arena::CountTeamPlayers(0) > Arena::CountTeamPlayers(1))
{
messageAll(0, getTeamName(0) @ " has WON!");
Arena::GameOver(0);
}
else if (Arena::CountTeamPlayers(0) < Arena::CountTeamPlayers(1))
{
messageAll(0, getTeamName(1) @ " has WON!");
Arena::GameOver(1);
}
else
{
Arena::TieGame(1);
}
}
function Arena::TieGame(%gamelimitexpired)
{
if (%gamelimitexpired == 1) {
messageAll(0, "The timelimit has run out, and both teams have the same amount of units left.  The game will be replayed.");
}
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchteam != -2)
{
%player = Client::getOwnedObject(%cl);
if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
{
playNextAnim(%cl);
Player::kill(%cl);
}
Arena::PickTeam(%cl, -2);
}
}
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchteam != -2)
{
Arena::PickTeam(%cl, %cl.matchteam);
Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
if (($DisableReadyUpTimer == 1) && ($Arena::MatchMode == 0)) {
%cl.notready = "";
}
else {
%cl.notready = false;
}
bottomprint(%cl, $PreGameMessage[%cl.matchteam] @ "Game starting in 10 seconds", 0);
}
}
Arena::PreGameMode();
}
function Arena::ResetItemCounts()
{
$TeamItemCount[0,LaserRifle] = 0;
$TeamItemCount[1,LaserRifle] = 0;
}
function remoteBuyFavorites(%client,%favItem0,%favItem1,%favItem2,%favItem3,%favItem4,%favItem5,%favItem6,%favItem7,%favItem8,%favItem9,%favItem10,%favItem11,%favItem12,%favItem13,%favItem14,%favItem15,%favItem16,%favItem17,%favItem18,%favItem19)
{
if (isPlayerBusy(%client))
return;
%time = getIntegerTime(true) >> 4; // int half seconds
if(%time <= %client.lastBuyFavTime)
return;
%client.lastBuyFavTime = %time;
%station = (Client::getOwnedObject(%client)).Station;
if(%station != "" )
{
%stationName = GameBase::getDataName(%station);
if(%stationName == DeployableInvStation || %stationName == DeployableAmmoStation)
%energy = %station.Energy;
else
%energy = $TeamEnergy[Client::getTeam(%client)];
if(%energy == "Infinite" || %energy > 0)
{
%error = 0;
%bought = 0;
%max = getNumItems();
for (%i = 0; %i < %max; %i = %i + 1)
{
%item = getItemData(%i);
if ($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats)
{
%count = Player::getItemCount(%client,%item);
if(%count)
{
if(%item.className != Armor)
{
teamEnergyBuySell(Client::getOwnedObject(%client),(%item.price * %count));
if ($TeamItemMax[%item] != "")
$TeamItemCount[GameBase::getTeam(%client), %item]--;
}
Player::setItemCount(%client, %item, 0);
}
}
}
for (%i = 0; %i < 20; %i++)
{
if(%favItem[%i] != "")
{
%item = getItemData(%favItem[%i]);
if ((Client::isItemShoppingOn(%client,%item)) && ($ItemMax[Player::getArmor(%client),  %item] > Player::getItemCount(%client,%item) || %item.className == Armor))
{
if(!buyItem(%client,%item, 1))
%error = 1;
else
%bought++;
}
}
}
if(%bought)
{
if(%error)
Client::sendMessage(%client,0,"~wC_BuySell.wav");
else
Client::SendMessage(%client,0,"~wbuysellsound.wav");
}
updateBuyingList(%client);
}
}
}
function Arena::SetFreeTimer(%clientId)
{
%clientId.FreeInvTimer = false;
if ($Arena::MatchStatus == 1) {
Client::sendMessage(%clientId, 0, "Your shopping trip has now been recorded, you have " @
2 - %clientId.InvTrips @ " left");
}
}
function remoteSelectClient(%clientId, %selId)
{
if(%clientId.selClient != %selId)
{
%clientId.selClient = %selId;
if(%clientId.menuMode == "options") {
Game::menuRequest(%clientId);
}
remoteEval(%clientId, "setInfoLine", 1,
"Player Info for " @ Client::getName(%selId) @ ":");
if (($ReplaceTabMenuPlayerInfoByStats == 1) && ($LizStatsLoaded == 1) && ($LizStatsEnable == 1))
{
%timeafk = "";
if (%selId.matchTeam == -2)
{
if (%selId.timeWentInObsSimTime >= 0)
{
%currentTime = getSimTime();
%currentTime = floor(%currentTime);
if (%currentTime > %selId.timeWentInObsSimTime) {
%timeafk = %currentTime - %selId.timeWentInObsSimTime;
%timeafk = LizStats::SecondsToTime_HMS(%timeafk);
} else {
%timeafk = %selId.timeWentInObsSimTime - %currentTime;
%timeafk = LizStats::SecondsToTime_HMS(%timeafk);
%timeafk = "-" @ %timeafk;
}
}
}
Arena::ComputePlayerRatios(%selId);
remoteEval(%clientId, "setInfoLine", 2, %selId.scoreKills @ " kills/" @
%selId.scoreDeaths @ " deaths/" @
%selId.scoreTKs @ " TKs/" @
%selId.scoreSuicide @ " suicides/" @
%selId.scoreTKed @ " TKdeaths/" @
"Score: " @ %selId.score);
remoteEval(%clientId, "setInfoLine", 3, "K:D " @ %selId.scoreKillDeathRatio @
", TK:K " @ %selId.scoreTKKillRatio @
", S:D " @ %selId.scoreSuicideDeathRatio @ "%");
remoteEval(%clientId, "setInfoLine", 4, "Hits: " @ %selId.shotHitTotal @ " (" @
%selId.shotHitTD @ " TD, " @
%selId.shotHitHeadShot @ " HS), " @
"Damaged: " @ %selId.shotAtTotal @ " (" @
%selId.shotAtTD @ " TD, " @
%selId.shotAtHeadShot @ " HS)");
remoteEval(%clientId, "setInfoLine", 5, "TD:Hits " @ %selId.shotHitTDRatio @ "%, " @
"HS:Hits " @ %selId.shotHitHeadShotRatio @ "%, " @
"TD:Dmgd " @ %selId.shotAtTDRatio @ "%, " @
"HS:Dmgd " @ %selId.shotAtHeadShotRatio @ "%");
if (%timeafk != "")
{
remoteEval(%clientId, "setInfoLine", 6, "Been observer for " @ %timeafk);
}
else
{
remoteEval(%clientId, "setInfoLine", 6, "Won " @ %selId.scoreMatchWon @
" of " @ (%selId.scoreMatchWon+%selId.scoreMatchLost) @ " matches " @
"(W:L " @ %selId.scoreTeamVictoryRatio @ "%)"
);
}
}
else
{
remoteEval(%clientId, "setInfoLine", 2,
"Real Name: " @ $Client::info[%selId, 1] @ ", " @
"Email: " @ $Client::info[%selId, 2]);
remoteEval(%clientId, "setInfoLine", 3,
"Tribe: " @ $Client::info[%selId, 3]);
remoteEval(%clientId, "setInfoLine", 4,
"URL: " @ $Client::info[%selId, 4]);
remoteEval(%clientId, "setInfoLine", 5,
"Other: " @ $Client::info[%selId, 5]);
remoteEval(%clientId, "setInfoLine", 6, "Stats: " @
%selId.scoreKills @ " kills, " @
%selId.scoreDeaths @ " deaths, " @
%selId.scoreTKs @ " TKs, " @
%selId.scoreSuicide @ " suicides.");
}
}
}
function Arena::AutoKickBlanks(%clientId)
{
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" was kicked for having a blank name" @ %dtstr);
Net::kick(%clientId, "Get a real name.");
}
function Arena::AutoKickPlayer(%clientId)
{
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(Client::getName(%clientId)) @
"\" on " @ Client::getTransportAddress(%clientId) @
" was kicked by Auto-Kick" @ %dtstr);
Net::kick(%clientId, "Critical error #1.");
}
function Arena::CheckIfTeamsAreEven()
{
if ($Arena::MatchMode == 1) {
return;
}
if ($ArenaAutoEvenTeams != 1) {
return;
}
%teamcnt[0] = Arena::CountTeam(0);
%teamcnt[1] = Arena::CountTeam(1);
if (%teamcnt[0] == %teamcnt[1]) {
%teamdelta = 0;
}
else if (%teamcnt[0] > %teamcnt[1]) {
%srcteam = 0;
%dstteam = 1;
%teamdelta = %teamcnt[0] - %teamcnt[1];
}
else if (%teamcnt[0] < %teamcnt[1]) {
%srcteam = 1;
%dstteam = 0;
%teamdelta = %teamcnt[0] - %teamcnt[1];
}
else {
%teamdelta = 0;
}
if (%teamdelta > 1)
{
messageall(0, "Teams are uneven in number of players per team. Transferring player(s)..");
for (%xfercnt = 0; %xfercnt < (%teamdelta / 2); %xfercnt++)
{
%ridx = floor(getRandom() * (%teamcnt[%srcteam] - 0.01));
if (%ridx < 1) %ridx = 1;
if (%ridx > %teamcnt[%srcteam]) %ridx = %teamcnt[%srcteam];
%tidx = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
%team = %cl.matchteam;
if (%team == %srcteam)
{
%tidx++;
if (%tidx == %ridx) {
Client::sendMessage(%cl, 1, "You are being switched teams to even teams out.");
processMenuPickTeam(%cl, %dstteam);
Game::refreshClientScore(%cl);
break;
}
}
}
}
}
if ($ArenaAutoEvenTeamsOnSkill == 1)
{
%numPlayers = getNumClients();
%teamWorth[0] = Arena::GetTeamWorthinessRatio(0);
%teamWorth[1] = Arena::GetTeamWorthinessRatio(1);
%teamWorthDiff = 0.0;
if (%teamWorth[0] > %teamWorth[1]) {
%teamWorthDiff = %teamWorth[0] - %teamWorth[1];
%teamWorthDiff = %teamWorthDiff / %teamWorth[0];
%teamIsBest = 0;
%teamIsWorst = 1;
}
if (%teamWorth[0] < %teamWorth[1]) {
%teamWorthDiff = %teamWorth[1] - %teamWorth[0];
%teamWorthDiff = %teamWorthDiff / %teamWorth[1];
%teamIsWorst = 0;
%teamIsBest = 1;
}
else {
%teamWorthDiff = 0;
%teamIsWorst = -1;
%teamIsBest = -1;
}
%totalTeamKills = $TeamNbKills[0] + $TeamNbKills[1];
%totalTeamScores = $TeamMatchScore[0] + $TeamMatchScore[1];
if ((%teamWorthDiff > 0) && (%teamWorthDiff > $Arena::TeamCompareRatio))
{
if ($Arena::AutoEvenLastScore < %totalTeamScores-2)
{
$Arena::AutoEvenLastScore = %totalTeamScores;
%teamWorthDiff = 1;
%teamBestPlayer = Arena::GetBestPlayer(%teamIsBest);
%teamWorstPlayer = Arena::GetWorstPlayer(%teamIsWorst);
if (%teamBestPlayer == 0) {
%teamWorthDiff= 0;
}
}
else
{
%teamWorthDiff= 0;
}
}
else {
%teamWorthDiff= 0;
}
if (%teamWorthDiff != 0)
{
messageall(0, "Teams are uneven skill-wise. Swapping player..");
if ((%teamBestPlayer != 0) && (%teamWorstPlayer != 0)) {
Client::sendMessage(%teamBestPlayer, 1, "You are being switched teams to even teams out.");
processMenuPickTeam(%teamBestPlayer, %teamIsWorst);
Game::refreshClientScore(%teamBestPlayer);
Client::sendMessage(%teamWorstPlayer, 1, "You are being switched teams to even teams out.");
processMenuPickTeam(%teamWorstPlayer, %teamIsBest);
Game::refreshClientScore(%teamWorstPlayer);
}
}
}
}
function Arena::DisplayFileVersion(%filename, %version)
{
if (($Arena::Loaded == 1) && (%version != ""))
echo("VERSION: File " @ %filename @ " version " @ %version);
else if ($Arena::Loaded == 1)
echo("VERSION: File " @ %filename @ " is not the updated version");
else
echo("VERSION: File " @ %filename @ " not loaded");
}
function Arena::DisplayVersion()
{
echo("VERSION: Tribes Arena v" @ $Arena::Version);
Arena::DisplayFileVersion("arena.cs",              $arena_cs_version);
Arena::DisplayFileVersion("arenaInit.cs",          $arenainit_cs_version);
Arena::DisplayFileVersion("arenaAdmin.cs",         $arenaadmin_cs_version);
Arena::DisplayFileVersion("arenaComchat.cs",       $arenacomchat_cs_version);
Arena::DisplayFileVersion("arenaGame.cs",          $arenagame_cs_version);
Arena::DisplayFileVersion("arenaGUI.cs",           $arenagui_cs_version);
Arena::DisplayFileVersion("arenaItem.cs",          $arenaitem_cs_version);
Arena::DisplayFileVersion("arenaObjectives.cs",    $arenaobjectives_cs_version);
Arena::DisplayFileVersion("arenaObserver.cs",      $arenaobserver_cs_version);
Arena::DisplayFileVersion("arenaPlayer.cs",        $arenaplayer_cs_version);
Arena::DisplayFileVersion("arenaServer.cs",        $arenaserver_cs_version);
Arena::DisplayFileVersion("arenaStation.cs",       $arenastation_cs_version);
Arena::DisplayFileVersion("arenaStaticShape.cs",   $arenastaticshape_cs_version);
if (($LizStatsLoaded == 1) && ($lizstats_cs_version != ""))
echo("VERSION: File lizStats.cs version " @ $lizstats_cs_version);
else if ($LizStatsLoaded == 1)
echo("VERSION: File lizStats.cs is not the updated version");
else
echo("VERSION: File lizStats.cs not loaded");
}
function Arena::RemoveGlobalUnmute(%clientId)
{
%clientId.mutedGlobal = "";
%clientId.mutedGlobalWarned = "";
%clientId.mutedGlobalName = "";
Client::sendMessage(%clientId,1,"You have been unmuted.");
}
function Arena::ResetTeamMapScore()
{
%nt = getNumTeams();
for(%i = -1; %i < %nt; %i++)
{
$TeamNbKills[%i] = 0;
$TeamNbDeaths[%i] = 0;
}
}
function Arena::ResetPlayerMapScore(%clientId)
{
%clientId.score = 0;
%clientId.scoreKills = 0;
%clientId.scoreTKs = 0;
%clientId.scoreDeaths = 0;
%clientId.scoreTKed = 0;
%clientId.scoreSuicide = 0;
%clientId.shotAtTotal = 0;
%clientId.shotAtHeadShot = 0;
%clientId.shotAtTD = 0;
%clientId.shotHitTotal = 0;
%clientId.shotHitHeadShot = 0;
%clientId.shotHitTD = 0;
%clientId.shotCGAtTotal = 0;
%clientId.shotCGAtHeadShot = 0;
%clientId.shotCGAtTD = 0;
%clientId.shotCGHitTotal = 0;
%clientId.shotCGHitHeadShot = 0;
%clientId.shotCGHitTD = 0;
%clientId.scoreMatchWon = 0;
%clientId.scoreMatchLost = 0;
Arena::ComputePlayerRatios(%clientId);
}
function Arena::ResetPlayerOptions(%clientId)
{
if ($ArenaUseLabRatPSkin == 1) {
if ($ArenaUseLabRatPSkinDefault == 1) {
%clientId.customSkin = true;
}
else {
%clientId.customSkin = false;
}
}
else {
%clientId.customSkin = false;
}
%currentTime = getSimTime();
%currentTime = floor(%currentTime);
%clientId.timeWentInObsSimTime = -1;
}
function Arena::ResetPlayerTotalScore(%clientId)
{
%clientId.totalKills = 0;
%clientId.totalTKs = 0;
%clientId.totalDeaths = 0;
%clientId.totalTKed = 0;
%clientId.totalSuicides = 0;
%clientId.totalMatchWon = 0;
%clientId.totalMatchLost = 0;
Arena::ComputePlayerRatios(%clientId);
}
function Arena::FormatFloat(%stat, %nbdecimals)
{
if (%stat == "") {
%stat = "0.000000000000000000000";
}
else {
%idx = String::FindSubStr(%stat, ".");
if (%idx == -1) {
%stat = %stat @ ".000000000000000000000";
}
}
%idx = String::FindSubStr(%stat, ".");
if (%idx == -1) {
return %result;
}
if (%nbdecimals > 0) {
%result = String::GetSubStr(%stat, 0, %idx+1+%nbdecimals);
}
else {
%result = String::GetSubStr(%stat, 0, %idx);
}
return %result;
}
function Arena::ComputePlayerRatios(%clientId)
{
%clientId.scoreKillDeathRank =   (%clientId.scoreKills - %clientId.scoreTKs) * 1000
+ %clientId.scoreKillDeathRatio * 100
+  99
- %clientId.scoreDeaths
+ %clientId.scoreTKed
+ %clientId.score;
if (%clientId.scoreDeaths > 0) {
%clientId.scoreKillDeathRatio = (%clientId.scoreKills / %clientId.scoreDeaths);
}
else {
%clientId.scoreKillDeathRatio = %clientId.scoreKills;
}
if (%clientId.totalDeaths > 0) {
%clientId.totalKillDeathRatio = (%clientId.totalKills / %clientId.totalDeaths);
}
else {
%clientId.totalKillDeathRatio = %clientId.totalKills;
}
%clientId.scoreKillDeathRatio = Arena::FormatFloat(%clientId.scoreKillDeathRatio, 2);
%clientId.totalKillDeathRatio = Arena::FormatFloat(%clientId.totalKillDeathRatio, 2);
if (%clientId.scoreKills > 0) {
%clientId.scoreTKKillRatio = (%clientId.scoreTKs / %clientId.scoreKills);
}
else {
%clientId.scoreTKKillRatio = %clientId.scoreTKs;
}
if (%clientId.totalKills > 0) {
%clientId.totalTKKillRatio = (%clientId.totalTKs / %clientId.totalKills);
}
else {
%clientId.totalTKKillRatio = %clientId.totalTKs;
}
%clientId.scoreTKKillRatio = Arena::FormatFloat(%clientId.scoreTKKillRatio, 2);
%clientId.totalTKKillRatio = Arena::FormatFloat(%clientId.totalTKKillRatio, 2);
if (%clientId.scoreDeaths > 0) {
%clientId.scoreSuicideDeathRatio = (100 * %clientId.scoreSuicide / %clientId.scoreDeaths);
}
else {
%clientId.scoreSuicideDeathRatio = 0;
}
if (%clientId.totalDeaths > 0) {
%clientId.totalSuicideDeathRatio = (100 * %clientId.totalSuicides / %clientId.totalDeaths);
}
else {
%clientId.totalSuicideDeathRatio = 0;
}
%clientId.scoreSuicideDeathRatio = Arena::FormatFloat(%clientId.scoreSuicideDeathRatio, 0);
%clientId.totalSuicideDeathRatio = Arena::FormatFloat(%clientId.totalSuicideDeathRatio, 0);
%totalmatches = %clientId.scoreMatchWon + %clientId.scoreMatchLost;
if (%totalmatches > 0) {
%clientId.scoreTeamVictoryRatio = (100 * %clientId.scoreMatchWon / %totalmatches);
}
else {
%clientId.scoreTeamVictoryRatio = 0;
}
if (%totalmatches > 0) {
%clientId.totalTeamVictoryRatio = (100 * %clientId.totalMatchWon / %totalmatches);
}
else {
%clientId.totalTeamVictoryRatio = 0;
}
%clientId.scoreTeamVictoryRatio = Arena::FormatFloat(%clientId.scoreTeamVictoryRatio, 0);
%clientId.totalTeamVictoryRatio = Arena::FormatFloat(%clientId.totalTeamVictoryRatio, 0);
if (%clientId.shotAtTotal > 0) {
%clientId.shotAtTDRatio = (100 * %clientId.shotAtTD / %clientId.shotAtTotal);
}
else {
%clientId.shotAtTDRatio = 0;
}
%clientId.shotAtTDRatio = Arena::FormatFloat(%clientId.shotAtTDRatio, 0);
if (%clientId.shotAtTotal > 0) {
%clientId.shotAtHeadShotRatio = (100 * %clientId.shotAtHeadShot / %clientId.shotAtTotal);
}
else {
%clientId.shotAtHeadShotRatio = 0;
}
%clientId.shotAtHeadShotRatio = Arena::FormatFloat(%clientId.shotAtHeadShotRatio, 0);
if (%clientId.shotHitTotal > 0) {
%clientId.shotHitTDRatio = (100 * %clientId.shotHitTD / %clientId.shotHitTotal);
}
else {
%clientId.shotHitTDRatio = 0;
}
%clientId.shotHitTDRatio = Arena::FormatFloat(%clientId.shotHitTDRatio, 0);
if (%clientId.shotHitTotal > 0) {
%clientId.shotHitHeadShotRatio = (100 * %clientId.shotHitHeadShot / %clientId.shotHitTotal);
}
else {
%clientId.shotHitHeadShotRatio = 0;
}
%clientId.shotHitHeadShotRatio = Arena::FormatFloat(%clientId.shotHitHeadShotRatio, 0);
}
function Arena::ListPlayers()
{
echo("ARENA: Connected players:");
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
%clname = Client::getName(%clientId);
%clip = Client::getTransportAddress(%cl);
%team = Client::getTeam(%cl);
echo("ARENA: Client " @ %cl @ " " @ %clname @ " on " @ %clip @
" on team " @ %team @
" has " @
%cl.scoreKills @ " kills, " @
%cl.scoreDeaths @ " deaths, " @
%cl.scoreTKs @ " TKs, " @
%cl.scoreTKed @ " TKed, " @
%cl.scoreSuicide @ " suicides, " @
%cl.score @ " points, " @
" for a rank of " @ %cl.scoreKillDeathRank);
}
}
function Arena::GetPlayerPosition(%clientId, %index)
{
$Arena::playerPos[%clientId,%index] = Gamebase::getPosition(%clientId);
$Arena::playerRot[%clientId,%index] = Gamebase::getRotation(%clientId);
}
function Arena::GetAllPlayersPosition(%index)
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
Arena::GetPlayerPosition(%cl, %index);
}
}
function Arena::CheckAllPlayersForAFK(%gamestarttime)
{
if (%gamestarttime != $Arena::GameStartTime) {
return;
}
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.onteam == "*")
{
Arena::GetPlayerPosition(%cl, 1);
if (($Arena::MatchMode == 0) && ($Arena::MatchStatus == 1))
{
if ($Arena::playerPos[%cl,0] == $Arena::playerPos[%cl,1])
{
if ($Arena::playerRot[%cl,0] == $Arena::playerRot[%cl,1])
{
Client::sendMessage(%cl,3, "You have been placed in observer because you were AFK.");
processMenuPickTeam(%cl, 9);
}
}
}
$Arena::playerPos[%cl,0] = $Arena::playerPos[%cl,1];
$Arena::playerRot[%cl,0] = $Arena::playerRot[%cl,1];
}
}
%teamcnt[0] = Arena::CountAliveTeamPlayers(0);
%teamcnt[1] = Arena::CountAliveTeamPlayers(1);
if ((%teamcnt[0] > 0) || (%teamcnt[1] > 0)) {
if ($Arena::MatchMode == 0)
{
if ($AutoObsAFKers == 1)
{
schedule("Arena::CheckAllPlayersForAFK(" @ %gamestarttime @ ");", $Arena::AFKDetectTimeNextChecks);
}
}
}
}
function processMenuRRndTeams(%clientId, %opt)
{
%adminId = getWord(%opt, 1);
if(getWord(%opt, 0) == "all") {
Arena::ReRandomizeTeams(1, %adminId);
}
else if(getWord(%opt, 0) == "teamed") {
Arena::ReRandomizeTeams(0, %adminId);
}
else {
Arena::TabMenuExploit(%clientId, "processMenuRRndTeams(" @ %clientId @ ", " @ %opt @ ")");
}
Game::menuRequest(%clientId);
}
function Arena::ReRandomizeTeams(%allplayers, %adminId)
{
if (%allplayers == 0) {
messageall(0, Client::getName(%adminId) @ " has re-randomized teams (all players).");
}
else {
messageall(0, Client::getName(%adminId) @ " has re-randomized teams.");
}
%numTeams = getNumTeams();
%numPlayers = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%allplayers == 1) || (%cl.matchTeam >= 0)) {
%numPlayers++;
}
}
%numPlayersOnTeam[0] = 0;
%numPlayersOnTeam[1] = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%allplayers == 1) || (%cl.matchTeam >= 0))
{
%nrnd = floor(getRandom() * 4.99) + 1;
for (%i = 0; %i < %nrnd; %i++) {
%rtm = floor(getRandom() * 999.9 + getRandom() * 99.9 + getRandom() * 9.99);
}
%rtm = (%rtm/2) - floor(%rtm/2);
if (%rtm > 0) %rtm = 1;
if (%numPlayersOnTeam[%rtm] > (%numPlayers / 2)) {
if (%rtm == 0) %rtm = 1;
else %rtm = 0;
}
processMenuPickTeam(%cl, %rtm);
%numPlayersOnTeam[%rtm]++;
}
}
}
function Arena::TabMenuExploit(%clientId, %exploitparams)
{
if ($LizStatsLoaded == 1) {
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%dtstr = " " @ $LizStats::DateTime::Date @ " " @ $LizStats::DateTime::Time;
}
else {
%dtstr = "";
}
}
else {
%dtstr = "";
}
%name = Client::getName(%clientId);
%ip = Client::getTransportAddress(%clientId);
messageall(1, %name @ " attempted to use the Tab Menu Exploit and crash the server. Player will be kicked.");
echo("LIZADMIN: " @ %clientId @ " \"" @
escapeString(%name) @ "\" on " @ %ip @
" was kicked for using the Tab Menu exploit" @ %dtstr @ ", context: " @ %exploitparams);
schedule("Arena::TabMenuExploitKick(" @ %clientId @ ");", $ArenaTabMenuExploitKickDelay);
}
function Arena::TabMenuExploitKick(%clientId, %ip)
{
%name = Client::getName(%clientId);
%ip = Client::getTransportAddress(%clientId);
BanList::add(%ip, $TabMenuExploitKickTimeSeconds);
Net::kick(%clientId, "You stupid kid... Get lost.");
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1)) {
LizStats::UpdateServerStatsTotalKicks(1);
}
}
function Arena::CountNumberOfAdmins(%team)
{
%admCount = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%team < 0) || (Client::getTeam(%cl) == %team)) {
if (%cl.isAdmin || %cl.isTrustedAdmin || %cl.isSuperAdmin || %cl.isServerSuperAdmin) {
%admCount++;
}
}
}
return %admCount;
}
function Arena::GetBestPlayer(%team)
{
%bestId = 0;
%bestScore = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%team < 0) || (Client::getTeam(%cl) == %team)) {
if (%cl.scoreKillDeathRank > %bestScore) {
%bestId = %cl;
%bestScore = %cl.scoreKillDeathRank;
}
}
}
return %bestId;
}
function Arena::GetWorstPlayer(%team)
{
%worstId = 0;
%worstScore = 99999;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%team < 0) || (Client::getTeam(%cl) == %team)) {
if ((%cl.scoreKills > 0) || (%cl.scoreDeaths > 0)) {
if (%cl.scoreKillDeathRank < %worstScore) {
%worstId = %cl;
%worstScore = %cl.scoreKillDeathRank;
}
}
}
}
return %worstId;
}
function Arena::GetTeamWorthinessRatio(%team)
{
if (%team < 0) {
return 0;
}
%totalScore = 0;
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (%cl.matchTeam == %team) {
%totalScore = %totalScore + (%cl.scoreKillDeathRank / 10);
}
}
return %totalScore;
}
function Arena::MessageTo(%playername, %message)
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (Client::getName(%cl) == %playername) {
Client::sendMessage(%cl, 1, %message);
}
}
}
function Arena::ClientByName(%playername)
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if (Client::getName(%cl) == %playername) {
return %cl;
}
}
return 0;
}
function Arena::AutoKickAFKersFullServer()
{
if (($ArenaKickAFKPlayersFullServer >= 0) && ($Arena::MatchMode == 0))
{
%numClients = getNumClients();
if (%numClients >= $Server::MaxPlayers)
{
for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%cl.team == -2) || (%cl.matchTeam == -2))
{
if (%cl.observerMode != "justJoined")
{
if (%cl.timeWentInObsSimTime >= 0)
{
%currentTime = floor(getSimTime());
if (%currentTime > %cl.timeWentInObsSimTime)
{
%timeafk = %currentTime - %cl.timeWentInObsSimTime;
%timeafkhms = LizStats::SecondsToTime_HMS(%timeafk);
if (%timeafk >= $ArenaKickAFKPlayersFullServer)
{
%isProtected = Admin::LizCheckProtectedIPList(%cl, "disconnect because afk (" @ %timeafkhms @ ") on full server");
if (%isProtected != 1)
{
%name = Client::getName(%cl);
echo("LIZADMIN: " @ %cl @ " \"" @
escapeString(Client::getName(%cl)) @
"\" on " @ Client::getTransportAddress(%cl) @
" was disconnected for being AFK (" @ %timeafkhms @ ") on full server");
Net::kick(%cl, "You have been AFK for " @ %timeafkhms @ " on a full server.");
messageAll(0, %name @ " was disconnected for being AFK for " @ %timeafkhms @ " on a full server.");
break;
}
}
}
}
}
}
}
}
}
}
function Arena::AutoPasswordFullServer()
{
if (($LizStatsEnable == 1) && ($LizStatsLoaded == 1))
{
}
}
function Arena::ComputeMaxRoundsLeft()
{
%maxroundsleft = ($Arena::NumberMatchLimit - 1) * (($Arena::Scorelimit * 2) - 1);
%maxroundsleft = %maxroundsleft + $Arena::Scorelimit - $TeamMatchScore[0];
%maxroundsleft = %maxroundsleft + $Arena::Scorelimit - $TeamMatchScore[1];
%maxroundsleft = %maxroundsleft - 1;
if (%maxroundsleft < 0) {
%maxroundsleft = 0;
}
return %maxroundsleft;
}
function Arena::GetTeamScoresString(%winningteam)
{
if (%winningteam == 0) {
%team0score = $TeamMatchScore[0] + 1;
} else {
%team0score = $TeamMatchScore[0];
}
if (%winningteam == 1) {
%team1score = $TeamMatchScore[1] + 1;
} else {
%team1score = $TeamMatchScore[1];
}
%tsstr = getTeamName(0) @ ": " @ %team0score @ ", " @
getTeamName(1) @ ": " @ %team1score;
return %tsstr;
}
$arena_cs_version = "$Revision: 72 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: arena.cs v" @ $Arena::Version @ ", internal version " @ $arena_cs_version);
