// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "comchat.cs"
// __________________________________________________________________________
//

$MsgTypeSystem = 0;
$MsgTypeGame = 1;
$MsgTypeChat = 2;
$MsgTypeTeamChat = 3;
$MsgTypeCommand = 4;
$spamControlCheckTeamChat = 0;
$spamControlCheckGlobalChat = 1;
$spamControlCheckCommand = 2;
$spamControlCheckLocalAnim = 3;
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckTeamChat,   0] = 6;           // No wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckTeamChat,   1] = 4;           // With wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckGlobalChat, 0] = 6;           // No wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckGlobalChat, 1] = 4;           // With wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckCommand,    0] = 6;           // No wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckCommand,    1] = 4;           // With wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckLocalAnim,  0] = 5;           // No wav (for 5 sec)
$spamControlCheckMaxNbfloodMessageCount[$spamControlCheckLocalAnim,  1] = 5;           // With wav (for 5 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckTeamChat,   0] = 12;   // No wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckTeamChat,   1] = 9;    // With wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckGlobalChat, 0] = 12;   // No wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckGlobalChat, 1] = 9;    // With wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckCommand,    0] = 12;   // No wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckCommand,    1] = 9;    // With wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckLocalAnim,  0] = 10;   // No wav (for 20 sec)
$spamControlCheckMaxNbfloodLongRunMessageCount[$spamControlCheckLocalAnim,  1] = 10;   // With wav (for 20 sec)
function verifyClientMuteStatus(%clientId, %supposedlyMutedClient)
{
if (%clientId.muted[%supposedlyMutedClient])
{
if ((%clientId.mutedName[%supposedlyMutedClient] != Client::getName(%supposedlyMutedClient)) && (%clientId.mutedName[%supposedlyMutedClient] != ""))
{
%clientId.muted[%supposedlyMutedClient] = "";
%clientId.mutedName[%supposedlyMutedClient] = "";
}
}
if (%supposedlyMutedClient.mutedGlobal)
{
if ((%supposedlyMutedClient.mutedGlobalName != Client::getName(%supposedlyMutedClient)) && (%supposedlyMutedClient.mutedGlobalName != ""))
{
%supposedlyMutedClient.mutedGlobal = "";
%supposedlyMutedClient.mutedGlobalWarned = "";
%supposedlyMutedClient.mutedGlobalName = "";
}
}
}
function teamMessages(%mtype, %team1, %message1, %team2, %message2, %message3)
{
%numPlayers = getNumClients();
for(%i = 0; %i < %numPlayers; %i = %i + 1)
{
%id = getClientByIndex(%i);
if(Client::getTeam(%id) == %team1)
{
Client::sendMessage(%id, %mtype, %message1);
}
else if(%message2 != "" && Client::getTeam(%id) == %team2)
{
Client::sendMessage(%id, %mtype, %message2);
}
else if(%message3 != "")
{
Client::sendMessage(%id, %mtype, %message3);
}
}
}
function messageAll(%mtype, %message, %filter)
{
if(%filter == "")
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
Client::sendMessage(%cl, %mtype, %message);
else
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if(%cl.messageFilter & %filter)
Client::sendMessage(%cl, %mtype, %message);
}
}
}
function messageAllExcept(%except, %mtype, %message)
{
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
if(%cl != %except)
Client::sendMessage(%cl, %mtype, %message);
}
function spamControlCheck(%clientId, %msgtype, %msgtypestr, %messagecontent)
{
%clientId.spamControlTriggered = false;
if (($Arena::MatchMode == 1) && (%msgtype == $spamControlCheckTeamChat)) {
return;
}
%time = getIntegerTime(true) >> 5;
if (%clientId.floodMute[%msgtype])
{
%delta = %clientId.muteDoneTime[%msgtype] - %time;
if (%delta > 0)
{
%clientId.lizfloodWarningLast = %delta;
if (%clientId.lizfloodWarning[%msgtype][%delta] == false)
{
%clientId.lizfloodWarning[%msgtype][%delta] = true;
Client::sendMessage(%clientId, $MSGTypeGame, "SPAM! You cannot " @ %msgtypestr @ " for " @ %delta @ " seconds.");
}
%clientId.spamControlTriggered = true;
return;
}
%clientId.floodMute[%msgtype] = "";
%clientId.muteDoneTime[%msgtype] = "";
}
%clientId.floodMessageCount[%msgtype]++;
%clientId.floodLongRunMessageCount[%msgtype]++;
schedule(%clientId @ ".floodMessageCount[" @ %msgtype @ "]--;", 5, %clientId);
schedule(%clientId @ ".floodLongRunMessageCount[" @ %msgtype @ "]--;", 20, %clientId);
if (%msgtype == $spamControlCheckLocalAnim) {
%withwav = 1;
}
else {
%idx = String::FindSubStr(%messagecontent, "~");
if (%idx >= 0) {
%withwav = 1;
}
else {
%withwav = 0;
}
}
if (%clientId.floodMessageCount[%msgtype] > $spamControlCheckMaxNbfloodMessageCount[%msgtype, %withwav])
{
%clientId.lizfloodWarningLast = 10;
for (%idx1 = 0; %idx1 <= 10; %idx1++) {
for (%idx2 = 0; %idx2 <= 10; %idx2++) {
%clientId.lizfloodWarning[%idx1][%idx2] = false;
}
}
%clientId.floodMute[%msgtype] = true;
%clientId.muteDoneTime[%msgtype] = %time + 10;
Client::sendMessage(%clientId, $MSGTypeGame, "SPAM! You cannot " @ %msgtypestr @ " for 10 seconds.");
%clientId.spamControlTriggered = true;
return;
}
if (%clientId.floodLongRunMessageCount[%msgtype] > $spamControlCheckMaxNbfloodLongRunMessageCount[%msgtype, %withwav])
{
%clientId.lizfloodWarningLast = 10;
for (%idx1 = 0; %idx1 <= 10; %idx1++) {
for (%idx2 = 0; %idx2 <= 10; %idx2++) {
%clientId.lizfloodWarning[%idx1][%idx2] = false;
}
}
%clientId.floodMute[%msgtype] = true;
%clientId.muteDoneTime[%msgtype] = %time + 10;
Client::sendMessage(%clientId, $MSGTypeGame, "SPAM! You cannot " @ %msgtypestr @ " for 10 seconds..");
%clientId.spamControlTriggered = true;
return;
}
}
function remoteSay(%clientId, %team, %message)
{
%msg = %clientId @ " \"" @ escapeString(%message) @ "\"";
if ($Server::FloodProtectionEnabled && (!$Server::TourneyMode || !%team))
{
if (%team) {
spamControlCheck(%clientId, $spamControlCheckTeamChat, "team chat", %message);
} else {
spamControlCheck(%clientId, $spamControlCheckGlobalChat, "global chat", %message);
}
if (%clientId.spamControlTriggered == true) {
return;
}
}
if (%team)
{
if($dedicated) {
if ($DisplayPlayerNameInSayLogMessages == 1)
echo("SAYTEAM: " @ Client::getName(%clientId) @ ": " @ %msg);
else
echo("SAYTEAM: " @ %msg);
}
%team = Client::getTeam(%clientId);
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%cl.muted[%clientId]) || (%clientId.mutedGlobal))
{
verifyClientMuteStatus(%cl, %clientId);
}
if(Client::getTeam(%cl) == %team && !%cl.muted[%clientId])
{
if (!%clientId.mutedGlobal)
{
Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
}
else
{
if (!%clientId.mutedGlobalWarned)
{
Client::sendMessage(%clientId,2,"You have been muted and can not talk for now.");
}
%clientId.mutedGlobalWarned = true;
}
}
}
}
else
{
if($dedicated) {
if ($DisplayPlayerNameInSayLogMessages == 1)
echo("SAY: " @ Client::getName(%clientId) @ ": " @ %msg);
else
echo("SAY: " @ %msg);
}
for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
{
if ((%cl.muted[%clientId]) || (%clientId.mutedGlobal))
{
verifyClientMuteStatus(%cl, %clientId);
}
if (!%cl.muted[%clientId])
{
if (!%clientId.mutedGlobal)
{
Client::sendMessage(%cl, $MsgTypeChat, %message, %clientId);
}
else
{
if (!%clientId.mutedGlobalWarned)
{
Client::sendMessage(%clientId,2,"You have been muted and can not talk for now.");
}
%clientId.mutedGlobalWarned = true;
}
}
}
}
}
function remoteIssueCommand(%commander, %cmdIcon, %command, %wayX, %wayY,
%dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14)
{
if ($Server::FloodProtectionEnabled && !$Server::TourneyMode)
{
spamControlCheck(%clientId, $spamControlCheckCommand, "issue commands", "~");
if (%clientId.spamControlTriggered == true) {
return;
}
}
if($dedicated) {
echo("COMMANDISSUE: " @ %commander @ " \"" @ escapeString(%command) @ "\"");
}
for(%i = 1; %dest[%i] != ""; %i = %i + 1)
{
if ((%dest[%i].muted[%commander]) || (%commander.mutedGlobal))
{
verifyClientMuteStatus(%dest[%i], %commander);
}
if (!%dest[%i].muted[%commander])
{
if (!%commander.mutedGlobal)
{
issueCommandI(%commander, %dest[%i], %cmdIcon, %command, %wayX, %wayY);
}
else
{
if (!%commander.mutedGlobalWarned)
{
Client::sendMessage(%commander,2,"You have been muted and can not issue commands for now.");
}
%commander.mutedGlobalWarned = true;
}
}
}
}
function remoteIssueTargCommand(%commander, %cmdIcon, %command, %targIdx,
%dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14)
{
if($dedicated) {
echo("COMMANDISSUE: " @ %commander @ " \"" @ escapeString(%command) @ "\"");
}
for(%i = 1; %dest[%i] != ""; %i = %i + 1)
{
if ((%dest[%i].muted[%commander]) || (%commander.mutedGlobal))
{
verifyClientMuteStatus(%dest[%i], %commander);
}
if (!%dest[%i].muted[%commander])
{
if (!%commander.mutedGlobal)
{
issueTargCommand(%commander, %dest[%i], %cmdIcon, %command, %targIdx);
}
else
{
if (!%commander.mutedGlobalWarned)
{
Client::sendMessage(%commander,2,"You have been muted and can not issue commands for now.");
}
%commander.mutedGlobalWarned = true;
}
}
}
}
function remoteCStatus(%clientId, %status, %message)
{
if(setCommandStatus(%clientId, %status, %message))
{
if($dedicated)
echo("COMMANDSTATUS: " @ %clientId @ " \"" @ escapeString(%message) @ "\"");
}
else
remoteSay(%clientId, true, %message);
}
function remoteLMSG(%clientId, %wav)
{
if ($ArenaLocalAnimSpamControl == 1)
{
if ($Server::FloodProtectionEnabled)
{
%team = Client::getTeam(%clientId);
if ((%team != -1) && (%team != -2)) {
spamControlCheck(%clientId, $spamControlCheckLocalAnim, "local anim", "");
if (%clientId.spamControlTriggered == true) {
return;
}
}
}
}
playVoice(%clientId, %wav);
}
function remoteplayAnimWav(%clientId, %anim, %wav)
{
if ($ArenaLocalAnimSpamControl == 1)
{
if ($Server::FloodProtectionEnabled)
{
%team = Client::getTeam(%clientId);
if ((%team != -1) && (%team != -2)) {
spamControlCheck(%clientId, $spamControlCheckLocalAnim, "local anim", "");
if (%clientId.spamControlTriggered == true) {
return;
}
}
}
}
remotePlayAnim(%clientId, %anim);
playVoice(%clientId, %wav);
}
$arenacomchat_cs_version = "$Revision: 20 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaComchat.cs v" @ $Arena::Version @ ", internal version " @ $arenacomchat_cs_version);
