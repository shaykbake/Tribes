// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Modified "station.cs"
// __________________________________________________________________________
//

function Station::onEndSequence(%this,%thread)
{
if (%thread == 1 && GameBase::isActive(%this))
{
GameBase::playSequence(%this,2,"use");
return true;
}
%client = %this.target;
if(%client == "")
{
%player = Station::getTarget(%this);
%client = Player::getClient(%player);
}
if(%client != "")
{
if(Client::getGuiMode(%client) != 1)
Client::setGuiMode(%client,1);
%team = Client::getTeam(%client);
if(%team == GameBase::getTeam(%this) || GameBase::getTeam(%this) == -1)
{
if (GameBase::getDamageState(%this) == "Enabled")
{
if (GameBase::isPowered(%this))
{
if (%client.FreeInvTimer == false)
{
if ($Arena::MatchStatus == 1)
{
%client.FreeInvTimer = true;
schedule("Arena::SetFreeTimer(" @ %client @");", 5);
%client.InvTrips++;
if ($FixInventorySpamExploit == 1)
{
%client.InvBuyCount = 0;
}
}
}
}
}
}
if($TeamEnergy[%team] != "Infinite")
{
if(%this.clTeamEnergy != %client.TeamEnergy)
{
if(%client.teamEnergy < 0)
Client::sendMessage(%client,0,"Your total mission purchases have come to " @ (%client.teamEnergy * -1) @ ".");
else
Client::sendMessage(%client,0,"You have increased the Team Energy by " @ %client.teamEnergy @ ".");
}
if((%client.teamEnergy -%client.EnergyWarning < $TeammateSpending) && ($TeammateSpending != 0) && !$TeamEnergyCheat)
{
TeamMessages(0, %team, "Teammate " @ Client::getName(%client) @ " has spent " @ (%client.teamEnergy *-1) @ " of the TeamEnergy");
%client.EnergyWarning = %client.teamEnergy;
}
if($TeamEnergy[%team] < $WarnEnergyLow)
TeamMessages(0, %team, "TeamEnergy Low: " @ $TeamEnergy[%team]);
}
}
if(%this.target != "")
{
(Client::getOwnedObject(%this.target)).Station = "";
%this.target = "";
}
if(GameBase::getDataName(%this) == VehicleStation && %this.vehiclePad.busy < getSimTime())
VehiclePad::checkSeq(%this.vehiclePad, %this);
%this.clTeamEnergy = "";
return false;
}
function Station::onCollision(%this, %object)
{
dbecho(3, "STATION: Collision (" @ %this @ "," @ %object @ ")");
%obj = getObjectType(%object);
if (%obj == "Player")
{
%client = Player::getClient(%object);
if(GameBase::getTeam(%object) == GameBase::getTeam(%this) || GameBase::getTeam(%this) == -1)
{
if (GameBase::getDamageState(%this) == "Enabled")
{
if (GameBase::isPowered(%this))
{
if (%client.InvTrips < 2 || %client.FreeInvTimer == true)
{
if(%this.enterTime == "")
%this.enterTime = getSimTime();
GameBase::setActive(%this,true);
}
else
Client::sendMessage(%client,0,"You have already accessed Stations 2 times~waccess_denied.wav");
}
else
Client::sendMessage(%client,0,"Unit is not powered");
}
else
Client::sendMessage(%client,0,"Unit is disabled");
}
else if(Station::getTarget(%this) == %object)
{
%curTime = getSimTime();
if(%curTime - %object.stationDeniedStamp > 3.5 && GameBase::getDamageState(%this) == "Enabled")
{
Client::clearItemShopping(%client);
Station::onDeactivate(%this);
Station::onEndSequence(%this,1);
if(Client::getGuiMode(%client) != 1)
Client::setGuiMode(%client,1);
%object.stationDeniedStamp = %curTime;
Client::sendMessage(%client,0,"--ACCESS DENIED-- Wrong Team ~waccess_denied.wav");
}
}
}
}
StaticShapeData InventoryStation
{
description = "Station Supply Unit";
shapeFile = "inventory_sta";
className = "Station";
visibleToSensor = true;
sequenceSound[0] = { "activate", SoundActivateInventoryStation };
sequenceSound[1] = { "power", SoundInventoryStationPower };
sequenceSound[2] = { "use", SoundUseInventoryStation };
maxDamage = 1000.0;
debrisId = flashDebrisLarge;
mapFilter = 4;
mapIcon = "M_station";
damageSkinData = "objectDamageSkins";
shadowDetailMask = 16;
triggerRadius = 1.5;
explosionId = flashExpLarge;
};
$arenastation_cs_version = "$Revision: 16 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: ArenaStation.cs v" @ $Arena::Version @ ", internal version " @ $arenastation_cs_version);
