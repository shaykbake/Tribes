// __________________________________________________________________________
// Tribes Arena v4.1 for Starsiege Tribes                          2002-12-17
// by Lizard (irc.dynamix.com on #lizrena, or lizard@arenapeople.com)
// __________________________________________________________________________
// Arena Initialization
// __________________________________________________________________________
//


$Arena::Version = "4.1";                                    // Current Arena version
$Arena::Author = "Lizard";                                  // Arena author
$Arena::AuthorEmail = "lizard@arenapeople.com";             // Arena author email
$Arena::WebSiteURL = "www.arenapeople.com";                 // Arena Web Site URL
$Arena::GameTimeLimit = 240;                                // Game Limit in seconds
$Arena::NumberMatchLimit = 3;                               // After this many matches the server 
$Arena::NumberMatchLimitBackup = $Arena::NumberMatchLimit;  // cycles to next map (Defualt 3).  Set = "" 
                                                            // if you don't want this feature (or if it 
                                                            // keeps crashing the server)
$Server::TimeLimit = 0;                                     // Server object time limit (overridden)
$Arena::Scorelimit = 4;                                     // Default ScoreLimit
$Arena::ScorelimitPubMode = 4;                              // Default ScoreLimit for Public Mode
$Arena::ScorelimitMatchMode = 5;                            // Default ScoreLimit for Match Mode
$Arena::ScorelimitMax = 5;                                  // Maximum ScoreLimit that can be set by an admin (physical max is 10 and min is 5)
$Arena::ReadyTime = true;                                   // Ready Up
$Arena::AutoTeamJoin = true;                                // Auto join teams on connect


//////////// Don't Modify below this line

$Arena::Loaded = 1;
$ArenaScoreListLetter_SuperAdmin   = "S";
$ArenaScoreListLetter_TrustedAdmin = "M";
$ArenaScoreListLetter_Admin        = "A";
$Arena::AFKDetectTimeFirstCheck = 32;
$Arena::AFKDetectTimeNextChecks = 32;
$Arena::TeamCompareRatio = 0.5;
$Arena::AutoEvenLastScore = 0;
$TeamMatchScore[0] = 0;
$TeamMatchScore[1] = 0;
$Server::TeamDamageScale = 1;
$PreGameMessage[0] = "<f1><jc>You are tied.  You need " @ $Arena::Scorelimit @ " games to win \n ";
$PreGameMessage[1] = "<f1><jc>You are tied.  You need " @ $Arena::Scorelimit @ " games to win \n ";
$ItemFavoritesKey = "Arena";
$Arena::MatchStatus = 0;
$Arena::MatchMode = 0;
$Arena::OOBDamageIncrements = 0.07;
$OOBDamageType = 320;
$InvList[TurretPack] = 0;
$RemoteInvList[TurretPack] = 0;
$InvList[MineAmmo] = 0;
$RemoteInvList[MineAmmo] = 0;
$AmmoPackMax[MineAmmo] = 0;
$AmmoPackItems[6] = Beacon;
$InvList[DeployableInvPack] = 0;
$InvList[DeployableAmmoPack] = 0;
$InvList[Mortar] = 0;
$InvList[MortarAmmo] = 0;
$RemoteInvList[Mortar] = 0;
$RemoteInvList[MortarAmmo] = 0;
$TeamItemCount[0,HeavyArmor] = 0;
$TeamItemCount[1,HeavyArmor] = 0;
$TeamItemCount[0,LaserRifle] = 0;
$TeamItemCount[1,LaserRifle] = 0;
$TeamItemMax[HeavyArmor] = 0;
if ($SniperRifleLimitInPubMode >= 0) {
$TeamItemMax[LaserRifle] = $SniperRifleLimitInPubMode;
}
else {
$TeamItemMax[LaserRifle] = "";
}
$Arena::MissionType = "Tribes Arena";
$Arena::GameMissionType = "Arena";
$TestMissionType = "ARENA";
$Arena::ReadyUpMessageBackup = "Get ready for ACTION!";
$Arena::ReadyUpMessage = $Arena::ReadyUpMessageBackup;
$ArenaCheckReadyStateDuration = 20;
$ArenaCheckReadyStateDurationReadyUpDisabled = 3;
$ArenaTabMenuExploitKickDelay = 2;
$ArenaPlayersCantTeamThemselvesPreMatchMode = 1;
$ArenaAdvSpamCtrlDepth = 5;
$Arena::ResetMatchModeScoreNextRound = 0;
$MODInfo = "<f2>Arena v" @ $Arena::Version;
if (($LizStatsLoaded == 1) && ($LizStatsEnable == 1)) {
$MODInfo = $MODInfo @ " and LizStats v" @ $LizStatsVersion;
}
$MODInfo = $MODInfo @ "\n" @
"by " @ $Arena::Author @ " (" @ $Arena::AuthorEmail @ ")\n" @
"http://" @ $Arena::WebSiteURL @ "\n\n" @
"<f0>Press O in-game for Objectives to get scores and details.\n ";
$arenainit_cs_version = "$Revision: 11 $ on $Date: 1/03/03 3:19p $";
echo("VERSION: arenaInit.cs v" @ $Arena::Version @ ", internal version " @ $arenainit_cs_version);
