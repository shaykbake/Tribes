// __________________________________________________________________________
// LizStats v1.91 for Starsiege Tribes                             2003-01-06
// by Lizard (irc.dynamix.com on #lizrena, or belgarion@tribes2universe.com)
// __________________________________________________________________________
// STATISTICS MODULE
// __________________________________________________________________________
// INTERESTING COMMAND LINE FUNCTIONS:
//
//    function LizStats::Quit() 
//       Stops the server even if it is running LizAutoRestart
//    function LizStats::Restart() 
//       Restarts the server assuming it is running LizAutoRestart
//    function LizStats::ResetTopScores(%dateReset)
//       Will reset the top scores for both modes
//       mode (%arenamode=1)
//    function LizStats::DisplayPlayedMaps()
//       Will display the most recent played maps
//    function LizStats::ShowMapStatsMapHighestScore()
//       Will display the map's highest score
// __________________________________________________________________________


// __________________________________________________________________________
// Loading module
// __________________________________________________________________________
// 
if ($LizStatsLoaded == 1)
{
   echo("LIZSTATS: Warning. Stats module already loaded. That means you have an exec(lizStats.cs) in two or more places.");
}

    
// __________________________________________________________________________
// Constants
// __________________________________________________________________________
// 
$LizStatsVersion = "1.91";                         // lizStats version
$LizStatsMapStatsDBVersion = "0190";               // lizStats DB version (map stats)
$LizStatsServerStatsDBVersion = "0190";            // lizStats DB version (server stats)
$LizStatsURL = "www.arenapeople.com";              // lizStats URL
$LizStatsMapsMapHighestScore = 5;                  // Top "#" of best scores for that map
$LizStatsMapsMapHighestKills = 5;                  // Top "#" of best number of kills for that map
$LizStatsMapsMapHighestKDRatio = 5;                // Top "#" of best kills/deaths ratio for that map
$LizStatsMapsMapWorstScore = 5;                    // Top "#" of worst scores for that map
$LizStatsEnableDateTimeLookup = 1;                 // Enable date/time lookup using lizExtraDateTime

// __________________________________________________________________________
// Global Variable Initialization -- DO NOT EDIT BELOW
// __________________________________________________________________________
// 
$LizStats::CleanMissionName = "undefined_mission_name";
$LizStats::CleanMissionType = "undefined_mission_type";
$LizStats::debugEnabled = 0;
$LizStats::LastPlayedMapsCount = 10;
$LizStats::LastDroppedPlayersCount = $Server::MaxPlayers;
echo("LIZSTATS: Loading Statistics module...");
$LizStatsScoresNull = -99999;
function LizStats::StartUp()
{
LizStats::CleanUp();
LizStats::ResetAll();
LizStats::LoadAll();
LizStats::InitializeLastPlayedMaps();
}
function LizStats::FormatStat(%stat, %totalchars)
{
%bigstr = %stat @ "                                   ";
%result = String::GetSubStr(%bigstr, 0, %totalchars);
return %result;
}
function LizStats::FloatToInteger(%stat)
{
%idx = String::FindSubStr(%stat, ".");
if (%idx == -1)
return %result;
%result = String::GetSubStr(%stat, 0, %idx);
return %result;
}
function LizStats::ReplaceChar(%str, %chartoreplace, %replacementchar)
{
%result = %str;
while (1)
{
%idx = String::FindSubStr(%result, %chartoreplace);
if (%idx == -1)
break;
%pre = String::GetSubStr(%result, 0, %idx);
%post = String::GetSubStr(%result, %idx+1, 10000);
%result = %pre @ %replacementchar @ %post;
}
return %result;
}
function LizStats::strLen(%str)
{
for (%i = 0; String::GetSubStr(%str, %i, 1) != ""; %i++)
{
}
return %i;
}
function LizStats::ArrangeMultispace(%str)
{
%result = %str;
while (1)
{
%idx = String::FindSubStr(%result, "  ");
if (%idx == -1)
break;
%pre = String::GetSubStr(%result, 0, %idx);
%post = String::GetSubStr(%result, %idx+2, 999);
%result = %pre @ " " @ %post;
}
if (String::GetSubStr(%result, 0, 1) == " ") {
%result = String::GetSubStr(%result, 1, 999);
}
%strlen = LizStats::strLen(%result) - 1;
if (String::GetSubStr(%result, %strLen, 1) == " ") {
%result = String::GetSubStr(%result, 0, %strlen);
}
return %result;
}
function LizStats::fixNameBadCharString(%str)
{
%result = escapeString(%str);
%chridx = 0;
while (1) {
%res = String::GetSubStr(%result, %chridx, 1);
if ((%res == -1) || (%res == "")) {
break;
}
if (%res == " ") {
%begstr = String::GetSubStr(%result, 0, %chridx);
%endstr = String::GetSubStr(%result, %chridx, 999);
%result = %begstr @ "\\" @ %endstr;
%chridx++;
}
%chridx++;
}
return %result;
}
function LizStats::RemoveQuotes(%str)
{
%result = LizStats::ReplaceChar(%str, "\"", "");
return %result;
}
function LizStats::ParseName(%str)
{
%result = String::convertSpaces(%str);
%result = LizStats::ReplaceChar(%result, "-", "_");
%result = LizStats::ReplaceChar(%result, "/", "_");
%result = LizStats::ReplaceChar(%result, "\\", "_");
%result = LizStats::ReplaceChar(%result, "~", "_");
%result = LizStats::ReplaceChar(%result, "%", "_");
%result = LizStats::ReplaceChar(%result, "$", "_");
return %result;
}
function LizStats::CleanUpAll()
{
if ($LizStatsServer == 1)
LizStats::CleanUpServer();
if ($LizStatsMap == 1)
LizStats::CleanUpMaps();
}
function LizStats::CleanUpMaps()
{
deleteVariables("$LizStats::MapStats*");
}
function LizStats::CleanUpServer()
{
deleteVariables("$LizStats::ServerStats*");
}
function LizStats::ResetAll()
{
if ($LizStatsServer == 1)
LizStats::ResetServer();
if ($LizStatsMap == 1)
LizStats::ResetMaps();
}
function LizStats::ResetServer()
{
echo("LIZSTATS: Resetting server statistics.");
for(%type = $TypeStart; %type < $MLIST::TypeCount; %type++)
{
%mistype = LizStats::ParseName($MLIST::Type[%type]);
if(%mistype != "Training")
{
for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%type], %i)) != -1; %i++)
{
%misname = LizStats::ParseName($MLIST::EName[%misIndex]);
$LizStats::ServerStatsTotalGamesPlayed[%mistype, %misname] = 0;
$LizStats::ServerStatsTotalMatchesPlayed[%mistype, %misname] = 0;
$LizStats::ServerStatsTotalMapsPlayed[%mistype, %misname] = 0;
}
}
}
$LizStats::ServerStatsDBVersion = $LizStatsServerStatsDBVersion;
$LizStats::ServerStatsTotalAllMapsPlayed = 0;
$LizStats::ServerStatsTotalAllMatchesPlayed = 0;
$LizStats::ServerStatsTotalAllGamesPlayed = 0;
$LizStats::ServerStatsTotalConnects = 0;
$LizStats::ServerStatsTotalKicks = 0;
$LizStats::ServerStatsTotalBans = 0;
$LizStats::ServerStatsTotalKills = 0;
$LizStats::ServerStatsTotalDeaths = 0;
$LizStats::ServerStatsTotalTKs = 0;
$LizStats::ServerStatsTotalSuicides = 0;
}
function LizStats::ResetMaps()
{
echo("LIZSTATS: Resetting map statistics.");
$LizStats::MapStatsDBVersion = $LizStatsMapStatsDBVersion;
$LizStats::MapStatsMapHighestScoreResetDate = "";
if ($MList::TypeCount < 2)
$TypeStart = 0;
else
$TypeStart = 1;
for(%type = $TypeStart; %type < $MLIST::TypeCount; %type++)
{
%mistype = LizStats::ParseName($MLIST::Type[%type]);
if(%mistype != "Training")
{
for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%type], %i)) != -1; %i++)
{
%misname = LizStats::ParseName($MLIST::EName[%misIndex]);
for (%highscore = 0; %highscore < $LizStatsMapsMapHighestScore; %highscore++)
for (%arenamode = 0; %arenamode <= 1; %arenamode++)
$LizStats::MapStatsMapHighestScore[%mistype, %misname, %highscore, %arenamode] = $LizStatsScoresNull;
}
}
}
}
function LizStats::LoadAll()
{
if ($LizStatsServer == 1)
LizStats::LoadServer();
if ($LizStatsMap == 1)
LizStats::LoadMaps();
}
function LizStats::LoadServer()
{
echo("LIZSTATS: Reloading server statistics, please be patient..");
if ($Server::HostFileExtension == "") {
%filename = "lizStatisticsServer.cs";
}
else {
%filename = "lizStatistics" @ $Server::HostFileExtension @ "Server.cs";
}
exec(%filename);
if (($LizStats::ServerStatsDBVersion != "") && ($LizStats::ServerStatsDBVersion != $LizStatsServerStatsDBVersion)) {
echo("LIZSTATS: =========== IMPORTANT ===========");
echo("LIZSTATS: Server statistics database format has changed and is " @
"incompatible with current revision of LizStats (LizStats v" @
$LizStatsVersion @ " uses DB format " @ $LizStatsServerStatsDBVersion @
" and current database is of format " @ $LizStats::ServerStatsDBVersion @ ").");
%backupfilename = LizStats::SaveServer($LizStats::ServerStatsDBVersion);
echo("LIZSTATS: Current server statistics are being backed up to " @ %backupfilename @
" for your convenience, and server statistics will now be reset.");
LizStats::ResetServer();
LizStats::SaveServer();
echo("LIZSTATS: =================================");
}
return %filename;
}
function LizStats::LoadMaps()
{
echo("LIZSTATS: Reloading maps statistics, please be patient..");
if ($Server::HostFileExtension == "") {
%filename = "lizStatisticsMap.cs";
}
else {
%filename = "lizStatistics" @ $Server::HostFileExtension @ "Map.cs";
}
exec(%filename);
if ($LizStats::MapStatsDBVersion != $LizStatsMapStatsDBVersion) {
echo("LIZSTATS: =========== IMPORTANT ===========");
echo("LIZSTATS: Map and Highscore statistics database format has changed " @
"and is incompatible with current revision of LizStats (LizStats v" @
$LizStatsVersion @ " uses DB format " @ $LizStatsMapStatsDBVersion @
" and current database is of format " @ $LizStats::MapStatsDBVersion @ ").");
%backupfilename = LizStats::SaveMaps($LizStats::MapStatsDBVersion);
echo("LIZSTATS: Current map statistics are being backed up to " @ %backupfilename @
" for your convenience, and map statistics will now be reset.");
echo("LIZSTATS: If you wish for a reset date to appear in high score table, " @
" please use the command log-in the tribes console and type: " @
"LizStats::ResetTopScores(\"YYYY-MM-DD\"); <enter> where YYYY-MM-DD " @
"is the current date.");
LizStats::ResetMaps();
LizStats::SaveMaps();
echo("LIZSTATS: =================================");
}
return %filename;
}
function LizStats::SaveAll()
{
if ($LizStatsServer == 1)
LizStats::SaveServer("");
if ($LizStatsMap == 1)
LizStats::SaveMaps("");
}
function LizStats::SaveServer(%DBversionExt)
{
echo("LIZSTATS: Saving server statistics.");
if (%DBversionExt == "") {
$LizStats::ServerStatsDBVersion = $LizStatsServerStatsDBVersion;
}
if ($Server::HostFileExtension == "") {
if (%DBversionExt != "") {
%filename = "config\\lizStatisticsServer." @ %DBversionExt @ ".cs";
} else {
%filename = "config\\lizStatisticsServer.cs";
}
}
else {
if (%DBversionExt != "") {
%filename = "config\\lizStatistics" @ $Server::HostFileExtension @ "Server." @ %DBversionExt @ ".cs";
} else {
%filename = "config\\lizStatistics" @ $Server::HostFileExtension @ "Server.cs";
}
}
export("LizStats::ServerStats*", %filename, false);
return %filename;
}
function LizStats::SaveMaps(%DBversionExt)
{
echo("LIZSTATS: Saving maps statistics.");
if (%DBversionExt == "") {
$LizStats::MapStatsDBVersion = $LizStatsMapStatsDBVersion;
}
if ($Server::HostFileExtension == "") {
if (%DBversionExt != "") {
%filename = "config\\lizStatisticsMap." @ %DBversionExt @ ".cs";
} else {
%filename = "config\\lizStatisticsMap.cs";
}
}
else {
if (%DBversionExt != "") {
%filename = "config\\lizStatistics" @ $Server::HostFileExtension @ "Map." @ %DBversionExt @ ".cs";
} else {
%filename = "config\\lizStatistics" @ $Server::HostFileExtension @ "Map.cs";
}
}
export("LizStats::MapStats*", %filename, false);
return %filename;
}
function LizStats::UpdateServerStatsTotalMapsPlayed(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalMapsPlayed[$LizStats::CleanMissionType, $LizStats::CleanMissionName] += %count;
$LizStats::ServerStatsTotalAllMapsPlayed += %count;
}
}
function LizStats::UpdateServerStatsTotalMatchesPlayed(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalMatchesPlayed[$LizStats::CleanMissionType, $LizStats::CleanMissionName] += %count;
$LizStats::ServerStatsTotalAllMatchesPlayed += %count;
}
}
function LizStats::UpdateServerStatsTotalGamesPlayed(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalGamesPlayed[$LizStats::CleanMissionType, $LizStats::CleanMissionName] += %count;
$LizStats::ServerStatsTotalAllGamesPlayed += %count;
}
}
function LizStats::UpdateServerStatsTotalConnects(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalConnects += %count;
}
}
function LizStats::UpdateServerStatsTotalKicks(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalKicks += %count;
}
}
function LizStats::UpdateServerStatsTotalBans(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalBans += %count;
}
}
function LizStats::UpdateServerStatsTotalKills(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalKills += %count;
}
}
function LizStats::UpdateServerStatsTotalDeaths(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalDeaths += %count;
}
}
function LizStats::UpdateServerStatsTotalTKs(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalTKs += %count;
}
}
function LizStats::UpdateServerStatsTotalSuicides(%count)
{
if ($LizStatsServer == 1)
{
$LizStats::ServerStatsTotalSuicides += %count;
}
}
function LizStats::ShowMapStatsMapHighestScore(%arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::ShowMapStatsMapHighestScore - bad parameter %arenamode = " @ %arenamode);
return;
}
for (%currow = 0; %currow < $LizStatsMapsMapHighestScore; %currow++)
{
echo("LIZSTATS: (DEBUG) HighScore Row " @ %currow @ " is " @ $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow, %arenamode]);
}
}
function LizStats::DeleteTableRowMapStatsMapHighestScore(%row, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::DeleteTableRowMapStatsMapHighestScore - bad parameter %arenamode = " @ %arenamode);
return;
}
%firstrow = %row;
%lastrow = $LizStatsMapsMapHighestScore - 2;
for (%currow = %firstrow; %currow <= %lastrow; %currow++)
{
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow, %arenamode] =
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow+1, %arenamode];
}
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, $LizStatsMapsMapHighestScore - 1, %arenamode] = $LizStatsScoresNull;
}
function LizStats::InsertTableRowMapStatsMapHighestScore(%row, %cscore, %ckills, %cname, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::InsertTableRowMapStatsMapHighestScore - bad parameter %arenamode = " @ %arenamode);
return;
}
%lastrow = %row; // + 1 - 1;
%firstrow = $LizStatsMapsMapHighestScore - 1;
for (%currow = %firstrow; %currow >= %lastrow; %currow--)
{
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow, %arenamode] =
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow-1, %arenamode];
}
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %row, %arenamode] =
%cscore @ " " @ %ckills @ " " @ %cname;
}
function LizStats::InsertTableRowMapStatsMapHighestRank(%row, %crank, %ckills, %cdeaths, %cscore, %cTKs, %cTKed, %csuicide, %ccurdate, %ccurtime, %cname, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::InsertTableRowMapStatsMapHighestRank - bad parameter %arenamode = " @ %arenamode);
return;
}
%lastrow = %row; // + 1 - 1;
%firstrow = $LizStatsMapsMapHighestScore - 1;
for (%currow = %firstrow; %currow >= %lastrow; %currow--)
{
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow, %arenamode] =
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %currow-1, %arenamode];
}
$LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %row, %arenamode] =
%crank @ " " @ %ckills @ " " @ %cdeaths @ " " @ %cscore @ " " @ %cTKs @ " " @ %cTKed @ " " @
%csuicide @ " " @ %ccurdate @ " " @ %ccurtime @ " " @ %cname;
}
function LizStats::ExtractClientNameScoreMethod(%row, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::ExtractClientNameScoreMethod - bad parameter %arenamode = " @ %arenamode);
return "";
}
%completestr = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %row, %arenamode];
%playername = "";
%paramidx = 2;
while (1)
{
%newstr = getWord(%completestr, %paramidx);
if (%newstr != -1)
{
if (%playername == "")
%playername = %newstr;
else
%playername = %playername @ " " @ %newstr;
}
else
{
break;
}
%paramidx++;
}
return %playername;
}
function LizStats::ExtractClientNameRankMethod(%row, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::ExtractClientNameRankMethod - bad parameter %arenamode = " @ %arenamode);
return "";
}
%completestr = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %row, %arenamode];
%playername = "";
%paramidx = 9;
while (1)
{
%newstr = getWord(%completestr, %paramidx);
if (%newstr != -1)
{
if (%playername == "")
%playername = %newstr;
else
%playername = %playername @ " " @ %newstr;
}
else
{
break;
}
%paramidx++;
}
return %playername;
}
function LizStats::UpdateMapStatsCheckClientScore(%client, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::UpdateMapStatsCheckClientScore - bad parameter %arenamode = " @ %arenamode);
return;
}
if ($LizStatsMap == 1)
{
if (%client.score < 0) {
return;
}
%newhighscore = -1;
for (%highscore = $LizStatsMapsMapHighestScore - 1; %highscore >= 0; %highscore--)
{
%sstr   = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %highscore, %arenamode];
%sscore = getWord(%sstr, 0);
if ((%client.score > %sscore) || ((%sscore == $LizStatsScoresNull) && (%client.score >= %sscore))){
%newhighscore = %highscore;
}
}
if (%newhighscore == -1) {
return;
}
%cname = LizStats::ArrangeMultispace(Client::getName(%client));
for (%highscore = 0; %highscore < $LizStatsMapsMapHighestScore; %highscore++)
{
%sstr  = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %highscore, %arenamode];
%sname = LizStats::ExtractClientNameScoreMethod(%highscore, %arenamode);
if (%sname == -1) {
%sname = "";
}
if ((%sname == %cname) && (%sname != ""))
{
%sscore = getWord(%sstr, 0);
if (%client.score <= %sscore) {
return;
}
LizStats::DeleteTableRowMapStatsMapHighestScore(%highscore, %arenamode);
break;
}
}
LizStats::InsertTableRowMapStatsMapHighestScore(%newhighscore, %client.score, %client.scoreKills, %cname, %arenamode);
}
}
function LizStats::UpdateMapStatsCheckClientRank(%client, %arenamode)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::UpdateMapStatsCheckClientRank - bad parameter %arenamode = " @ %arenamode);
return;
}
if ($LizStatsMap == 1)
{
%newhighscore = -1;
for (%highscore = $LizStatsMapsMapHighestScore - 1; %highscore >= 0; %highscore--)
{
%sstr  = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %highscore, %arenamode];
%srank = getWord(%sstr, 0);
if ((%client.scoreKillDeathRank > %srank) || ((%srank == $LizStatsScoresNull) && (%client.scoreKillDeathRank >= %srank))) {
%newhighscore = %highscore;
}
}
if (%newhighscore == -1) {
return;
}
%cname = LizStats::ArrangeMultispace(Client::getName(%client));
for (%highscore = 0; %highscore < $LizStatsMapsMapHighestScore; %highscore++)
{
%sstr  = $LizStats::MapStatsMapHighestScore[$LizStats::CleanMissionType, $LizStats::CleanMissionName, %highscore, %arenamode];
%sname = LizStats::ExtractClientNameRankMethod(%highscore, %arenamode);
if (%sname == -1) {
%sname = "";
}
if ((%sname == %cname) && (%sname != ""))
{
%srank = getWord(%sstr, 0);
if (%client.scoreKillDeathRank <= %srank) {
return;
}
LizStats::DeleteTableRowMapStatsMapHighestScore(%highscore, %arenamode);
break;
}
}
LizStats::GetDateTime(false);
if ($LizStats::DateTime::Enabled == 1) {
%curdate = $LizStats::DateTime::Date;
%curtime = $LizStats::DateTime::Time;
}
else {
%curdate = "0";
%curtime = "0";
}
if (%curdate == "") {
%curdate = "0";
}
if (%curtime == "") {
%curtime = "0";
}
LizStats::InsertTableRowMapStatsMapHighestRank(%newhighscore,
%client.scoreKillDeathRank, %client.scoreKills, %client.scoreDeaths,
%client.score, %client.scoreTKs, %client.scoreTKed, %client.scoreSuicide,
%curdate, %curtime, %cname, %arenamode);
}
}
function LizStats::ResetTopScores(%dateReset)
{
LizStats::ResetTopScore(0, %dateReset);
LizStats::ResetTopScore(1, %dateReset);
}
function LizStats::ResetTopScore(%arenamode, %dateReset)
{
if ((%arenamode == "") || (%arenamode < 0) || (%arenamode > 1)) {
echo("LIZSTATS: LizStats::ResetTopScore - bad parameter %arenamode = " @ %arenamode);
echo("LIZSTATS: You must specify ArenaMode in parameter (0: Pub Mode, 1: Match Mode).");
echo("LIZSTATS: Syntax is LizStats::ResetTopScore(%arenamode, %dateReset)");
return;
}
if (%arenamode == 0) {
echo("LIZSTATS: Resetting top scores for Pub Mode");
}
else if (%arenamode == 1) {
echo("LIZSTATS: Resetting top scores for Match Mode");
}
else {
echo("LIZSTATS: Resetting top scores (unknown %arenamode " @ %arenamode @ ")");
}
if ($MList::TypeCount < 2)
$TypeStart = 0;
else
$TypeStart = 1;
for(%type = $TypeStart; %type < $MLIST::TypeCount; %type++)
{
%mistype = LizStats::ParseName($MLIST::Type[%type]);
if(%mistype != "Training")
{
for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%type], %i)) != -1; %i++)
{
%misname = LizStats::ParseName($MLIST::EName[%misIndex]);
for(%highscore = 0; %highscore < $LizStatsMapsMapHighestScore; %highscore++)
$LizStats::MapStatsMapHighestScore[%mistype, %misname, %highscore, %arenamode] = $LizStatsScoresNull;
}
}
}
$LizStats::MapStatsMapHighestScoreResetDate = %dateReset;
ObjectiveMission::setObjectiveHeading();
}
function LizStats::InitializeLastPlayedMaps()
{
for (%i = 1; %i <= $LizStats::LastPlayedMapsCount; %i++)
{
$LizStats::LastPlayedMaps[%i] = "";
}
}
function LizStats::CheckLastPlayedMaps(%mapname)
{
for (%i = 1; %i <= $LizStats::LastPlayedMapsCount; %i++)
{
if ((%mapname == $LizStats::LastPlayedMaps[%i]) && ($LizStats::LastPlayedMaps[%i] != ""))
return %i;
}
return 0;
}
function LizStats::CheckIfCurrentMap(%mapname)
{
if (%mapname == $missionName)
return true;
else
return false;
}
function LizStats::DisplayPlayedMaps()
{
echo("LIZSTATS: Recently played maps:");
for (%i = 1; %i <= $LizStats::LastPlayedMapsCount; %i++)
{
echo("LIZSTATS: " @ %i @ ") " @ $LizStats::LastPlayedMaps[%i]);
}
}
function LizStats::GetRecentMapList()
{
%recentmaps = "";
for (%i = 1; %i <= $LizStats::LastPlayedMapsCount; %i++)
{
if ($LizStats::LastPlayedMaps[%i] != "") {
if (%recentmaps != "") {
%recentmaps = %recentmaps @ ", ";
}
%recentmaps = %recentmaps @ $LizStats::LastPlayedMaps[%i];
}
}
return %recentmaps;
}
function LizStats::UpdatePlayedMaps(%mapname)
{
if (%mapname == "") {
return;
}
%mapindex = 0;
for (%i = 1; %i <= $LizStats::LastPlayedMapsCount; %i++) {
if ((%mapname == $LizStats::LastPlayedMaps[%i]) && ($LizStats::LastPlayedMaps[%i] != "")) {
%mapindex = %i;
break;
}
}
if (%mapindex > 0) {
for (%i = %mapindex; %i <= $LizStats::LastPlayedMapsCount-1; %i++) {
$LizStats::LastPlayedMaps[%i] = $LizStats::LastPlayedMaps[%i+1];
}
}
for (%i = $LizStats::LastPlayedMapsCount; %i > 1; %i--) {
$LizStats::LastPlayedMaps[%i] = $LizStats::LastPlayedMaps[%i-1];
}
$LizStats::LastPlayedMaps[1] = %mapname;
}
function LizStats::ExtractIPFromTA(%taddr)
{
%idx = String::FindSubStr(%taddr, "IP:");
if (%idx >= 0) {
%ip = String::GetSubStr(%taddr, %idx+3, 99999);
}
else {
%ip = %taddr;
}
%idx = String::FindSubStr(%ip, ":");
if (%idx >= 0) {
%result = String::GetSubStr(%ip, 0, %idx);
}
else {
%result = %ip;
}
return %result;
}
function LizStats::ResetLastDroppedPlayers()
{
for (%idx = 0; %idx < $LizStats::LastDroppedPlayersCount; %idx++)
{
$LizStats::LastDroppedPlayers::Name[%idx] = "";
$LizStats::LastDroppedPlayers::IPAddr[%idx] = "";
$LizStats::LastDroppedPlayers::Map[%idx] = "";
$LizStats::LastDroppedPlayers::Time[%idx] = 0;
$LizStats::LastDroppedPlayers::Score[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreKills[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreTKs[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreDeaths[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreTKed[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreSuicide[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreMatchWon[%idx] = 0;
$LizStats::LastDroppedPlayers::ScoreMatchLost[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalKills[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalTKs[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalDeaths[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalTKed[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalSuicides[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalMatchWon[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalMatchLost[%idx] = 0;
}
}
function LizStats::SetLastDroppedPlayerStats(%cl, %idx)
{
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
%time = $LizStats::DateTime::NbSec;
} else {
%time = 0;
}
%name = Client::GetName(%cl);
%ip = LizStats::ExtractIPFromTA(Client::getTransportAddress(%cl));
$LizStats::LastDroppedPlayers::Name[%idx] = %name;
$LizStats::LastDroppedPlayers::IPAddr[%idx] = %ip;
$LizStats::LastDroppedPlayers::Map[%idx] = $missionName;
$LizStats::LastDroppedPlayers::Time[%idx] = %time;
$LizStats::LastDroppedPlayers::Score[%idx] = %cl.score;
$LizStats::LastDroppedPlayers::ScoreKills[%idx] = %cl.scoreKills;
$LizStats::LastDroppedPlayers::ScoreTKs[%idx] = %cl.scoreTKs;
$LizStats::LastDroppedPlayers::ScoreDeaths[%idx] = %cl.scoreDeaths;
$LizStats::LastDroppedPlayers::ScoreTKed[%idx] = %cl.scoreTKed;
$LizStats::LastDroppedPlayers::ScoreSuicide[%idx] = %cl.scoreSuicide;
$LizStats::LastDroppedPlayers::ScoreMatchWon[%idx] = %cl.scoreMatchWon;
$LizStats::LastDroppedPlayers::ScoreMatchLost[%idx] = %cl.scoreMatchLost;
$LizStats::LastDroppedPlayers::TotalKills[%idx] = %cl.totalKills;
$LizStats::LastDroppedPlayers::TotalTKs[%idx] = %cl.totalTKs;
$LizStats::LastDroppedPlayers::TotalDeaths[%idx] = %cl.totalDeaths;
$LizStats::LastDroppedPlayers::TotalTKed[%idx] = %cl.totalTKed;
$LizStats::LastDroppedPlayers::TotalSuicides[%idx] = %cl.totalSuicides;
$LizStats::LastDroppedPlayers::TotalMatchWon[%idx] = %cl.totalMatchWon;
$LizStats::LastDroppedPlayers::TotalMatchLost[%idx] = %cl.totalMatchLost;
}
function LizStats::GetLastDroppedPlayerStats(%cl, %idx)
{
%cl.score = $LizStats::LastDroppedPlayers::Score[%idx];
%cl.scoreKills = $LizStats::LastDroppedPlayers::ScoreKills[%idx];
%cl.scoreTKs = $LizStats::LastDroppedPlayers::ScoreTKs[%idx];
%cl.scoreDeaths = $LizStats::LastDroppedPlayers::ScoreDeaths[%idx];
%cl.scoreTKed = $LizStats::LastDroppedPlayers::ScoreTKed[%idx];
%cl.scoreSuicide = $LizStats::LastDroppedPlayers::ScoreSuicide[%idx];
%cl.scoreMatchWon = $LizStats::LastDroppedPlayers::ScoreMatchWon[%idx];
%cl.scoreMatchLost = $LizStats::LastDroppedPlayers::ScoreMatchLost[%idx];
%cl.totalKills = $LizStats::LastDroppedPlayers::TotalKills[%idx];
%cl.totalTKs = $LizStats::LastDroppedPlayers::TotalTKs[%idx];
%cl.totalDeaths = $LizStats::LastDroppedPlayers::TotalDeaths[%idx];
%cl.totalTKed = $LizStats::LastDroppedPlayers::TotalTKed[%idx];
%cl.totalSuicides = $LizStats::LastDroppedPlayers::TotalSuicides[%idx];
%cl.totalMatchWon = $LizStats::LastDroppedPlayers::TotalMatchWon[%idx];
%cl.totalMatchLost = $LizStats::LastDroppedPlayers::TotalMatchLost[%idx];
}
function LizStats::DisplayLastDroppedPlayers()
{
echo("LIZSTATS: Last dropped players:");
%count = 0;
for (%idx = 0; %idx < $LizStats::LastDroppedPlayersCount; %idx++)
{
%name = $LizStats::LastDroppedPlayers::Name[%idx];
%ip = $LizStats::LastDroppedPlayers::IPAddr[%idx];
%map = $LizStats::LastDroppedPlayers::Map[%idx];
%time = $LizStats::LastDroppedPlayers::Time[%idx];
%score = $LizStats::LastDroppedPlayers::Score[%idx];
%kills = $LizStats::LastDroppedPlayers::ScoreKills[%idx];
%deaths = $LizStats::LastDroppedPlayers::ScoreDeaths[%idx];
if ((%name != "") && (%ip != "") && (%map != "")) {
echo("LIZSTATS: LDP[" @ %idx @ "] " @ %name @ "/" @ %ip @
"/" @ %map @ " dropped at " @ %time @
" had a score of " @ %score @ " (" @ %kills @ "/" @ %deaths @ ")");
}
else {
echo("LIZSTATS: LDP[" @ %idx @ "] is empty");
}
}
}
function LizStats::FindLastDroppedPlayer(%name, %taddr)
{
if (%name == "") {
return -1;
}
%ip = LizStats::ExtractIPFromTA(%taddr);
if (%ip == "") {
return -1;
}
for (%idx = 0; %idx < $LizStats::LastDroppedPlayersCount; %idx++)
{
if ((%name == $LizStats::LastDroppedPlayers::Name[%idx]) && (%ip == $LizStats::LastDroppedPlayers::IPAddr[%idx])) {
return %idx;
}
}
return -1;
}
function LizStats::InsertLastDroppedPlayerStats(%clientId, %insidx)
{
for (%idx = $LizStats::LastDroppedPlayersCount-1; %idx >= %insidx+1; %idx--)
{
$LizStats::LastDroppedPlayers::Name[%idx] = $LizStats::LastDroppedPlayers::Name[%idx-1];
$LizStats::LastDroppedPlayers::IPAddr[%idx] = $LizStats::LastDroppedPlayers::IPAddr[%idx-1];
$LizStats::LastDroppedPlayers::Map[%idx] = $LizStats::LastDroppedPlayers::Map[%idx-1];
$LizStats::LastDroppedPlayers::Time[%idx] = $LizStats::LastDroppedPlayers::Time[%idx-1];
$LizStats::LastDroppedPlayers::Score[%idx] = $LizStats::LastDroppedPlayers::Score[%idx-1];
$LizStats::LastDroppedPlayers::ScoreKills[%idx] = $LizStats::LastDroppedPlayers::ScoreKills[%idx-1];
$LizStats::LastDroppedPlayers::ScoreTKs[%idx] = $LizStats::LastDroppedPlayers::ScoreTKs[%idx-1];
$LizStats::LastDroppedPlayers::ScoreDeaths[%idx] = $LizStats::LastDroppedPlayers::ScoreDeaths[%idx-1];
$LizStats::LastDroppedPlayers::ScoreTKed[%idx] = $LizStats::LastDroppedPlayers::ScoreTKed[%idx-1];
$LizStats::LastDroppedPlayers::ScoreSuicide[%idx] = $LizStats::LastDroppedPlayers::ScoreSuicide[%idx-1];
$LizStats::LastDroppedPlayers::ScoreMatchWon[%idx] = $LizStats::LastDroppedPlayers::ScoreMatchWon[%idx-1];
$LizStats::LastDroppedPlayers::ScoreMatchLost[%idx] = $LizStats::LastDroppedPlayers::ScoreMatchLost[%idx-1];
$LizStats::LastDroppedPlayers::TotalKills[%idx] = $LizStats::LastDroppedPlayers::TotalKills[%idx-1];
$LizStats::LastDroppedPlayers::TotalTKs[%idx] = $LizStats::LastDroppedPlayers::TotalTKs[%idx-1];
$LizStats::LastDroppedPlayers::TotalDeaths[%idx] = $LizStats::LastDroppedPlayers::TotalDeaths[%idx-1];
$LizStats::LastDroppedPlayers::TotalTKed[%idx] = $LizStats::LastDroppedPlayers::TotalTKed[%idx-1];
$LizStats::LastDroppedPlayers::TotalSuicides[%idx] = $LizStats::LastDroppedPlayers::TotalSuicides[%idx-1];
$LizStats::LastDroppedPlayers::TotalMatchWon[%idx] = $LizStats::LastDroppedPlayers::TotalMatchWon[%idx-1];
$LizStats::LastDroppedPlayers::TotalMatchLost[%idx] = $LizStats::LastDroppedPlayers::TotalMatchLost[%idx-1];
}
LizStats::SetLastDroppedPlayerStats(%clientId, %insidx);
}
function LizStats::DeleteLastDroppedPlayerByIndex(%delidx)
{
for (%idx = %delidx; %idx < $LizStats::LastDroppedPlayersCount-1; %idx++)
{
$LizStats::LastDroppedPlayers::Name[%idx] = $LizStats::LastDroppedPlayers::Name[%idx+1];
$LizStats::LastDroppedPlayers::IPAddr[%idx] = $LizStats::LastDroppedPlayers::IPAddr[%idx+1];
$LizStats::LastDroppedPlayers::Map[%idx] = $LizStats::LastDroppedPlayers::Map[%idx+1];
$LizStats::LastDroppedPlayers::Time[%idx] = $LizStats::LastDroppedPlayers::Time[%idx+1];
$LizStats::LastDroppedPlayers::Score[%idx] = $LizStats::LastDroppedPlayers::Score[%idx+1];
$LizStats::LastDroppedPlayers::ScoreKills[%idx] = $LizStats::LastDroppedPlayers::ScoreKills[%idx+1];
$LizStats::LastDroppedPlayers::ScoreTKs[%idx] = $LizStats::LastDroppedPlayers::ScoreTKs[%idx+1];
$LizStats::LastDroppedPlayers::ScoreDeaths[%idx] = $LizStats::LastDroppedPlayers::ScoreDeaths[%idx+1];
$LizStats::LastDroppedPlayers::ScoreTKed[%idx] = $LizStats::LastDroppedPlayers::ScoreTKed[%idx+1];
$LizStats::LastDroppedPlayers::ScoreSuicide[%idx] = $LizStats::LastDroppedPlayers::ScoreSuicide[%idx+1];
$LizStats::LastDroppedPlayers::ScoreMatchWon[%idx] = $LizStats::LastDroppedPlayers::ScoreMatchWon[%idx+1];
$LizStats::LastDroppedPlayers::ScoreMatchLost[%idx] = $LizStats::LastDroppedPlayers::ScoreMatchLost[%idx+1];
$LizStats::LastDroppedPlayers::TotalKills[%idx] = $LizStats::LastDroppedPlayers::TotalKills[%idx+1];
$LizStats::LastDroppedPlayers::TotalTKs[%idx] = $LizStats::LastDroppedPlayers::TotalTKs[%idx+1];
$LizStats::LastDroppedPlayers::TotalDeaths[%idx] = $LizStats::LastDroppedPlayers::TotalDeaths[%idx+1];
$LizStats::LastDroppedPlayers::TotalTKed[%idx] = $LizStats::LastDroppedPlayers::TotalTKed[%idx+1];
$LizStats::LastDroppedPlayers::TotalSuicides[%idx] = $LizStats::LastDroppedPlayers::TotalSuicides[%idx+1];
$LizStats::LastDroppedPlayers::TotalMatchWon[%idx] = $LizStats::LastDroppedPlayers::TotalMatchWon[%idx+1];
$LizStats::LastDroppedPlayers::TotalMatchLost[%idx] = $LizStats::LastDroppedPlayers::TotalMatchLost[%idx+1];
}
$LizStats::LastDroppedPlayers::Name[$LizStats::LastDroppedPlayersCount-1] = "";
$LizStats::LastDroppedPlayers::IPAddr[$LizStats::LastDroppedPlayersCount-1] = "";
$LizStats::LastDroppedPlayers::Map[$LizStats::LastDroppedPlayersCount-1] = "";
$LizStats::LastDroppedPlayers::Time[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::Score[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreKills[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreTKs[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreDeaths[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreTKed[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreSuicide[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreMatchWon[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::ScoreMatchLost[$LizStats::LastDroppedPlayersCount-1] = 0;
$LizStats::LastDroppedPlayers::TotalKills[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalTKs[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalDeaths[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalTKed[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalSuicides[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalMatchWon[%idx] = 0;
$LizStats::LastDroppedPlayers::TotalMatchLost[%idx] = 0;
}
function LizStats::InitDateTime()
{
$LizStats::DateTime::Filename = "config\\lizExtraDatetime.cs";
$LizStats::DateTime::FilenameExec = "lizExtraDatetime";
$LizStats::DateTime::LastReadMap = "";
$LizStats::DateTime::LastReadTime = 0;
$LizStats::DateTime::Enabled = 0;
$LizStats::DateTime::Date = "0000-00-00";
$LizStats::DateTime::Time = "00:00:00";
$LizStats::DateTime::DOW = "";
$LizStats::DateTime::TimeZone = "";
$LizStats::DateTime::TZRFC = "";
$LizStats::DateTime::NbSec = "0";
if (IsFile($LizStats::DateTime::Filename)) {
File::delete($LizStats::DateTime::Filename);
}
export("$LizStats::DateTime::*", $LizStats::DateTime::Filename, true);
}
function LizStats::GetDateTime(%precisetime)
{
if (%precisetime == true) {
if ($LizStats::DateTime::Enabled == 0) {
if ($LizStats::DateTime::LastReadTime > 0) {
%currentTime = getSimTime();
%currentTime = floor(%currentTime);
%timeDiff = %currentTime - $LizStats::DateTime::LastReadTime;
if (%timeDiff > 60) {
%doread = 1;
} else {
%doread = 0;
}
} else {
%doread = 1;
}
} else {
%doread = 1;
}
} else {
%doread = 1;
}
if ((%doread == 1) && ($LizStatsEnableDateTimeLookup == 1)) {
if (isFile($LizStats::DateTime::Filename)) {
exec($LizStats::DateTime::FilenameExec);
}
else {
$LizStats::DateTime::Enabled = 0;
$LizStats::DateTime::Date = "0000-00-00";
$LizStats::DateTime::Time = "00:00:00";
$LizStats::DateTime::DOW = "";
$LizStats::DateTime::TimeZone = "";
$LizStats::DateTime::TZRFC = "";
$LizStats::DateTime::NbSec = "0";
}
}
else {
$LizStats::DateTime::Enabled = 0;
$LizStats::DateTime::Date = "0000-00-00";
$LizStats::DateTime::Time = "00:00:00";
$LizStats::DateTime::DOW = "";
$LizStats::DateTime::TimeZone = "";
$LizStats::DateTime::TZRFC = "";
$LizStats::DateTime::NbSec = "0";
}
if (%precisetime == false)
{
$LizStats::DateTime::Time = String::GetSubStr($LizStats::DateTime::Time, 0, 5);
}
}
function LizStats::DisplayDateTime()
{
LizStats::GetDateTime(true);
if ($LizStats::DateTime::Enabled == 1) {
echo("LIZSTATS: Current date/time is" @
" " @ $LizStats::DateTime::DOW @
" " @ $LizStats::DateTime::Date @
" " @ $LizStats::DateTime::Time @
" " @ $LizStats::DateTime::TimeZone @
" (" @ $LizStats::DateTime::TZRFC @ ")");
}
else {
echo("LIZSTATS: Unable to get current date/time (lizExtraDateTime script is not be running or badly installed)");
}
}
function LizStats::SecondsToTime_MS(%nbsec)
{
%min = floor(%nbsec / 60);
%sec = %nbsec - (%min * 60);
%timestr = %min @ ":";
if (%sec < 10) {
%timestr = %timestr @ "0" @ %sec;
} else {
%timestr = %timestr @ %sec;
}
return %timestr;
}
function LizStats::SecondsToTime_HMS(%nbsec)
{
%min = floor(%nbsec / 60);
%sec = %nbsec - (%min * 60);
%hour = floor(%min / 60);
%min = %min - (%hour * 60);
%timestr = %hour @ ":";
if (%min < 10) {
%timestr = %timestr @ "0" @ %min @ ":";
} else {
%timestr = %timestr @ %min @ ":";
}
if (%sec < 10) {
%timestr = %timestr @ "0" @ %sec;
} else {
%timestr = %timestr @ %sec;
}
return %timestr;
}
function LizStats::VoteTimesReset()
{
$LizStats::VoteTimes::LastVote = "";
$LizStats::VoteTimes::LastVoteTime = -1;
$LizStats::VoteTimes::LastAdminVote = "";
$LizStats::VoteTimes::LastAdminVoteTime = -1;
$LizStats::VoteTimes::LastKickVote = "";
$LizStats::VoteTimes::LastKickVoteTime = -1;
$LizStats::VoteTimes::LastMapChangeVote = "";
$LizStats::VoteTimes::LastMapChangeVoteTime = -1;
$LizStats::VoteTimes::LastVotePass = "";
$LizStats::VoteTimes::LastVotePassTime = -1;
$LizStats::VoteTimes::LastAdminVotePass = "";
$LizStats::VoteTimes::LastAdminVotePassTime = -1;
$LizStats::VoteTimes::LastKickVotePass = "";
$LizStats::VoteTimes::LastKickVotePassTime = -1;
$LizStats::VoteTimes::LastMapChangeVotePass = "";
$LizStats::VoteTimes::LastMapChangeVotePassTime = -1;
$LizStats::VoteTimes::LastVoteFail = "";
$LizStats::VoteTimes::LastVoteFailTime = -1;
$LizStats::VoteTimes::LastAdminVoteFail = "";
$LizStats::VoteTimes::LastAdminVoteFailTime = -1;
$LizStats::VoteTimes::LastKickVoteFail = "";
$LizStats::VoteTimes::LastKickVoteFailTime = -1;
$LizStats::VoteTimes::LastMapChangeVoteFail = "";
$LizStats::VoteTimes::LastMapChangeVoteFailTime = -1;
}
function LizStats::VoteTimesDisplay()
{
if ($LizStats::VoteTimes::LastVoteTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastVote = " @ $LizStats::VoteTimes::LastVote);
echo("LIZSTATS: $LizStats::VoteTimes::LastVoteTime = " @ $LizStats::VoteTimes::LastVoteTime);
}
if ($LizStats::VoteTimes::LastAdminVoteTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastAdminVote = " @ $LizStats::VoteTimes::LastAdminVote);
echo("LIZSTATS: $LizStats::VoteTimes::LastAdminVoteTime = " @ $LizStats::VoteTimes::LastAdminVoteTime);
}
if ($LizStats::VoteTimes::LastKickVoteTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastKickVote = " @ $LizStats::VoteTimes::LastKickVote);
echo("LIZSTATS: $LizStats::VoteTimes::LastKickVoteTime = " @ $LizStats::VoteTimes::LastKickVoteTime);
}
if ($LizStats::VoteTimes::LastMapChangeVoteTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastMapChangeVote = " @ $LizStats::VoteTimes::LastMapChangeVote);
echo("LIZSTATS: $LizStats::VoteTimes::LastMapChangeVoteTime = " @ $LizStats::VoteTimes::LastMapChangeVoteTime);
}
if ($LizStats::VoteTimes::LastVotePassTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastVotePass = " @ $LizStats::VoteTimes::LastVotePass);
echo("LIZSTATS: $LizStats::VoteTimes::LastVotePassTime = " @ $LizStats::VoteTimes::LastVotePassTime);
}
if ($LizStats::VoteTimes::LastAdminVotePassTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastAdminVotePass = " @ $LizStats::VoteTimes::LastAdminVotePass);
echo("LIZSTATS: $LizStats::VoteTimes::LastAdminVotePassTime = " @ $LizStats::VoteTimes::LastAdminVotePassTime);
}
if ($LizStats::VoteTimes::LastKickVotePassTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastKickVotePass = " @ $LizStats::VoteTimes::LastKickVotePass);
echo("LIZSTATS: $LizStats::VoteTimes::LastKickVotePassTime = " @ $LizStats::VoteTimes::LastKickVotePassTime);
}
if ($LizStats::VoteTimes::LastMapChangeVotePassTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastMapChangeVotePass = " @ $LizStats::VoteTimes::LastMapChangeVotePass);
echo("LIZSTATS: $LizStats::VoteTimes::LastMapChangeVotePassTime = " @ $LizStats::VoteTimes::LastMapChangeVotePassTime);
}
if ($LizStats::VoteTimes::LastVoteFailTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastVoteFail = " @ $LizStats::VoteTimes::LastVoteFail);
echo("LIZSTATS: $LizStats::VoteTimes::LastVoteFailTime = " @ $LizStats::VoteTimes::LastVoteFailTime);
}
if ($LizStats::VoteTimes::LastAdminVoteFailTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastAdminVoteFail = " @ $LizStats::VoteTimes::LastAdminVoteFail);
echo("LIZSTATS: $LizStats::VoteTimes::LastAdminVoteFailTime = " @ $LizStats::VoteTimes::LastAdminVoteFailTime);
}
if ($LizStats::VoteTimes::LastKickVoteFailTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastKickVoteFail = " @ $LizStats::VoteTimes::LastKickVoteFail);
echo("LIZSTATS: $LizStats::VoteTimes::LastKickVoteFailTime = " @  $LizStats::VoteTimes::LastKickVoteFailTime);
}
if ($LizStats::VoteTimes::LastMapChangeVoteFailTime > 0) {
echo("LIZSTATS: $LizStats::VoteTimes::LastMapChangeVoteFail = " @  $LizStats::VoteTimes::LastMapChangeVoteFail);
echo("LIZSTATS: $LizStats::VoteTimes::LastMapChangeVoteFailTime = " @ $LizStats::VoteTimes::LastMapChangeVoteFailTime);
}
}
function LizStats::VoteTimesUpdate(%voteaction, %votetopic)
{
$LizStats::VoteTimes::LastVote = %votetopic;
$LizStats::VoteTimes::LastVoteTime = getIntegerTime(true) >> 5;
if (%voteaction == "admin") {
$LizStats::VoteTimes::LastAdminVote = %votetopic;
$LizStats::VoteTimes::LastAdminVoteTime = getIntegerTime(true) >> 5;
}
else if (%voteaction == "kick") {
$LizStats::VoteTimes::LastKickVote = %votetopic;
$LizStats::VoteTimes::LastKickVoteTime = getIntegerTime(true) >> 5;
}
else if ((%voteaction == "cmission") || (%voteaction == "vcmission")) {
$LizStats::VoteTimes::LastMapChangeVote = %votetopic;
$LizStats::VoteTimes::LastMapChangeVoteTime = getIntegerTime(true) >> 5;
}
}
function LizStats::VotePassTimesUpdate(%voteaction, %votetopic)
{
$LizStats::VoteTimes::LastVotePass = %votetopic;
$LizStats::VoteTimes::LastVotePassTime = getIntegerTime(true) >> 5;
if (%voteaction == "admin") {
$LizStats::VoteTimes::LastAdminVotePass = %votetopic;
$LizStats::VoteTimes::LastAdminVotePassTime = getIntegerTime(true) >> 5;
}
else if (%voteaction == "kick") {
$LizStats::VoteTimes::LastKickVotePass = %votetopic;
$LizStats::VoteTimes::LastKickVotePassTime = getIntegerTime(true) >> 5;
}
else if ((%voteaction == "cmission") || (%voteaction == "vcmission")) {
$LizStats::VoteTimes::LastMapChangeVotePass = %votetopic;
$LizStats::VoteTimes::LastMapChangeVotePassTime = getIntegerTime(true) >> 5;
}
}
function LizStats::VoteFailTimesUpdate(%voteaction, %votetopic)
{
$LizStats::VoteTimes::LastVoteFail = %votetopic;
$LizStats::VoteTimes::LastVoteFailTime = getIntegerTime(true) >> 5;
if (%voteaction == "admin") {
$LizStats::VoteTimes::LastAdminVoteFail = %votetopic;
$LizStats::VoteTimes::LastAdminVoteFailTime = getIntegerTime(true) >> 5;
}
else if (%voteaction == "kick") {
$LizStats::VoteTimes::LastKickVoteFail = %votetopic;
$LizStats::VoteTimes::LastKickVoteFailTime = getIntegerTime(true) >> 5;
}
else if ((%voteaction == "cmission") || (%voteaction == "vcmission")) {
$LizStats::VoteTimes::LastMapChangeVoteFail = %votetopic;
$LizStats::VoteTimes::LastMapChangeVoteFailTime = getIntegerTime(true) >> 5;
}
}
function LizStats::SaveVolatileServerPrefs()
{
}
function LizStats::RestoreVolatileServerPrefs()
{
}
function LizStats::UpdateConnectedPlayersStats(%removeamount)
{
$LizStats::MRTG::PlayersMax = $server::maxplayers;
$LizStats::MRTG::PlayersCount = getNumClients() - %removeamount;
if ($Server::HostFileExtension == "") {
export("LizStats::MRTG::Players*", "config\\lizStatsPlayerCount.cs", false);
}
else {
export("LizStats::MRTG::Players*", "config\\lizStatsPlayerCount" @ $Server::HostFileExtension @ ".cs", false);
}
}
function LizStats::Quit()
{
}
function LizStats::Restart()
{
}
LizStats::SaveVolatileServerPrefs();
LizStats::ResetLastDroppedPlayers();
LizStats::InitDateTime();
LizStats::VoteTimesReset();
$LizStatsLoaded = 1;
$lizstats_cs_version = "$Revision: 64 $ on $Date: 12/17/02 3:40p $";
echo("LIZSTATS: VERSION: lizstats.cs version " @ $lizstats_cs_version);
