// __________________________________________________________________________
// autoexec.cs
// __________________________________________________________________________
// Start custom scripts for your server (server configuration for example)
// __________________________________________________________________________


// Execute Server Config
echo("SERVER: Executing ServerConfig.cs");
exec("ServerConfig.cs");

