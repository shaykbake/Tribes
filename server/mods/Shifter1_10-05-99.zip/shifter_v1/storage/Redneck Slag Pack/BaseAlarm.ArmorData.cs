// This is a MiniMod Plugin.
// This is the Base Alarm from the Redneck Slag Pack mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    BaseAlarm.ArmorData.cs
//    BaseAlarm.item.cs
//    BaseAlarm.reinitData.cs
//    BaseAlarm.staticshape.cs
//    BaseAlarm.station.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, BaseAlarm] = 0;
$ItemMax[lfemale, BaseAlarm] = 0;
$ItemMax[marmor, BaseAlarm] = 1;
$ItemMax[mfemale, BaseAlarm] = 1;
$ItemMax[harmor, BaseAlarm] = 1;
$ItemMax[sarmor, BaseAlarm] = 0;
$ItemMax[sfemale, BaseAlarm] = 0;
$ItemMax[spyarmor, BaseAlarm] = 0;
$ItemMax[spyfemale, BaseAlarm] = 0;
$ItemMax[barmor, BaseAlarm] = 0;
$ItemMax[bfemale, BaseAlarm] = 0;
$ItemMax[earmor, BaseAlarm] = 1;
$ItemMax[efemale, BaseAlarm] = 1;
$ItemMax[aarmor, BaseAlarm] = 0;
$ItemMax[afemale, BaseAlarm] = 0;
$ItemMax[darmor, BaseAlarm] = 0;
$ItemMax[tarmor, BaseAlarm] = 0;
$ItemMax[scvarmor, BaseAlarm] = 0;
