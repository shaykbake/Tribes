// MiniMod plugin
// Fusion Blaster created/ported By, Dewy.

$ItemClass = 5;
$Item = FusionGun;
$qty = 1;
MiniMod::Build::Classes();

$ItemClass = 6;
$Item = FusionGun;
$qty = 1;
MiniMod::Build::Classes();

