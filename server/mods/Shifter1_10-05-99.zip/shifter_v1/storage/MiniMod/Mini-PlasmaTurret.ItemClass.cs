// This is a MiniMod Plugin.
// This is the Mini-Plasma turret created/ported by Dewy.

$ItemClass = 10;
$Item = PlasmaPack;
$qty = 1;
MiniMod::Build::Classes();
