// This is a MiniMod Plugin.
// This plugin is the Dissection Turret from the MiniMod.
// Note: Code is based off of PeterT's Watchdog Turret plugin.
// Ported by Dewy.

$ItemClass = 12;
$Item = DissectionPack;
$qty = 1;
MiniMod::Build::Classes();
