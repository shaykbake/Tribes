// This is a MiniMod plugin
// This is the Shotgun From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.


$deathMsg[$ShotgunDamageType, 0]	       = "%1 says WHAT. %2 looked like %3 armor needed some vents.";
$deathMsg[$ShotgunDamageType, 1]	       = "R.I.P. Here lies %2. %1's Shotgun took %3 'Izzass' out.";
$deathMsg[$ShotgunDamageType, 2]	       = "%1 pulled out a deuce and capped %2 REAL good.";
$deathMsg[$ShotgunDamageType, 3]	       = "%1 pointed a Sawed-off at %2 while singing, 'Another one bites the dust.'";
