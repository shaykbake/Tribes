// This is a MiniMod plugin
// This is the Shotgun From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

$DamageScale[larmor, $ShotgunDamageType] = 1.0; 
$ItemMax[larmor, Shotgun] = 1; 
$ItemMax[larmor, ShotgunShells] = 20; 
$DamageScale[marmor, $ShotgunDamageType] = 1.0; 
$ItemMax[marmor, Shotgun] = 1; 
$ItemMax[marmor, ShotgunShells] = 40; 
$DamageScale[harmor, $ShotgunDamageType] = 1.0; 
$ItemMax[harmor, Shotgun] = 1; 
$ItemMax[harmor, ShotgunShells] = 60; 
$DamageScale[lfemale, $ShotgunDamageType] = 1.0; 
$ItemMax[lfemale, Shotgun] = 1; 
$ItemMax[lfemale, ShotgunShells] = 20; 
$DamageScale[mfemale, $ShotgunDamageType] = 1.0; 
$ItemMax[mfemale, Shotgun] = 1; 
$ItemMax[mfemale, ShotgunShells] = 40; 
