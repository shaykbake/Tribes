// This is a MiniMod Plugin.
// This plugin is based on the Watchdog (Spotter) Turret from
// the hvTactical mod. It was initially ported by PeterT and
// then adapted by Epsilon into something quite different.
//
// To install this plugin just...
// Add:
//
//    SeekerTurret.ArmorData.cs
//    SeekerTurret.baseProjData.cs
//    SeekerTurret.item.cs
//    SeekerTurret.reinitData.cs
//    SeekerTurret.station.cs
//    SeekerTurret.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, SeekerPack] = 0;
$ItemMax[lfemale, SeekerPack] = 0;
$ItemMax[marmor, SeekerPack] = 0;
$ItemMax[mfemale, SeekerPack] = 0;
$ItemMax[harmor, SeekerPack] = 1;
$ItemMax[sarmor, SeekerPack] = 0;
$ItemMax[sfemale, SeekerPack] = 0;
$ItemMax[spyarmor, SeekerPack] = 0;
$ItemMax[spyfemale, SeekerPack] = 0;
$ItemMax[barmor, SeekerPack] = 0;
$ItemMax[bfemale, SeekerPack] = 0;
$ItemMax[earmor, SeekerPack] = 1;
$ItemMax[efemale, SeekerPack] = 1;
$ItemMax[afemale, SeekerPack] = 0;
$ItemMax[aarmor, SeekerPack] = 0;
$ItemMax[darmor, SeekerPack] = 0;
$ItemMax[tarmor, SeekerPack] = 0;
$ItemMax[scvarmor, SeekerPack] = 0;
