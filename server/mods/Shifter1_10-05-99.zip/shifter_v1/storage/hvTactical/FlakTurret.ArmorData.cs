// This is a MiniMod Plugin.
// This plugin is the Flak Turret from the hvTactical mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    FlakTurret.ArmorData.cs
//    FlakTurret.baseProjData.cs
//    FlakTurret.item.cs
//    FlakTurret.reinitData.cs
//    FlakTurret.station.cs
//    FlakTurret.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, FlakPack] = 0;
$ItemMax[lfemale, FlakPack] = 0;
$ItemMax[marmor, FlakPack] = 1;
$ItemMax[mfemale, FlakPack] = 1;
$ItemMax[harmor, FlakPack] = 1;
$ItemMax[sarmor, FlakPack] = 0;
$ItemMax[sfemale, FlakPack] = 0;
$ItemMax[spyarmor, FlakPack] = 0;
$ItemMax[spyfemale, FlakPack] = 0;
$ItemMax[barmor, FlakPack] = 0;
$ItemMax[bfemale, FlakPack] = 0;
$ItemMax[earmor, FlakPack] = 1;
$ItemMax[efemale, FlakPack] = 1;
$ItemMax[aarmor, FlakPack] = 0;
$ItemMax[afemale, FlakPack] = 0;
$ItemMax[darmor, FlakPack] = 1;
$ItemMax[tarmor, FlakPack] = 0;
$ItemMax[scvarmor, FlakPack] = 0;
