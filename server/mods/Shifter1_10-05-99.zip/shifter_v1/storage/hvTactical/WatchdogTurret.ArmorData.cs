// This is a MiniMod Plugin.
// This plugin is the GuardDog (Spotter) Turret from the hvTactical mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    WatchdogTurret.ArmorData.cs
//    WatchdogTurret.baseProjData.cs
//    WatchdogTurret.item.cs
//    WatchdogTurret.reinitData.cs
//    WatchdogTurret.station.cs
//    WatchdogTurret.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, WatchdogPack] = 1;
$ItemMax[lfemale, WatchdogPack] = 1;
$ItemMax[marmor, WatchdogPack] = 1;
$ItemMax[mfemale, WatchdogPack] = 1;
$ItemMax[harmor, WatchdogPack] = 1;
$ItemMax[sarmor, WatchdogPack] = 1;
$ItemMax[sfemale, WatchdogPack] = 1;
$ItemMax[spyarmor, WatchdogPack] = 1;
$ItemMax[spyfemale, WatchdogPack] = 1;
$ItemMax[barmor, WatchdogPack] = 0;
$ItemMax[bfemale, WatchdogPack] = 0;
$ItemMax[earmor, WatchdogPack] = 1;
$ItemMax[efemale, WatchdogPack] = 1;
$ItemMax[afemale, WatchdogPack] = 1;
$ItemMax[aarmor, WatchdogPack] = 1;
$ItemMax[darmor, WatchdogPack] = 1;
$ItemMax[tarmor, WatchdogPack] = 1;
$ItemMax[scvarmor, WatchdogPack] = 1;
