// This is a MiniMod Plugin.
// This plugin is the Seed Pack from the Ideal mod. Ported by Dewy.
//
// To install this plugin just...
// Add:
//
//    SeedPack.ArmorData.cs
//    SeedPack.item.cs
//    SeedPack.reinitData.cs
//    SeedPack.station.cs
//
// to your MiniMod/plugins directory.

$InvList[TreePack] = 1;
$RemoteInvList[TreePack] = 1;
