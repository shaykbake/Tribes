// This is a MiniMod Plugin.
// This plugin is the Seed Pack from the Ideal mod. Ported by Dewy.
//
// To install this plugin just...
// Add:
//
//    SeedPack.ArmorData.cs
//    SeedPack.item.cs
//    SeedPack.reinitData.cs
//    SeedPack.station.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, TreePack] = 1;
$ItemMax[lfemale, TreePack] = 1;
$ItemMax[marmor, TreePack] = 1;
$ItemMax[mfemale, TreePack] = 1;
$ItemMax[harmor, TreePack] = 1;
$ItemMax[sarmor, TreePack] = 1;
$ItemMax[sfemale, TreePack] = 1;
$ItemMax[spyarmor, TreePack] = 1;
$ItemMax[spyfemale, TreePack] = 1;
$ItemMax[barmor, TreePack] = 0;
$ItemMax[bfemale, TreePack] = 0;
$ItemMax[earmor, TreePack] = 1;
$ItemMax[efemale, TreePack] = 1;
$ItemMax[aarmor, TreePack] = 0;
$ItemMax[afemale, TreePack] = 0;
$ItemMax[darmor, TreePack] = 1;
$ItemMax[tarmor, TreePack] = 1;
$ItemMax[scvarmor, TreePack] = 0;
