///-----------------------------------------------
/// description = "Door 4x17 Force Field Door";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[sarmor, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[barmor, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[harmor, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[darmor, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[marmor, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[mfemale, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[earmor, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[efemale, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[lfemale, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[sfemale, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[bfemale, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[spyarmor, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[spyfemale, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[adarmor, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[sadarmor, doorfourbyseventeenForceFieldPack] = 0;
$ItemMax[parmor, doorfourbyseventeenForceFieldPack] = 0;