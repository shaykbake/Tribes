///-----------------------------------------------
/// Description - "Accelerator pad";
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
/// Original Idea ripped from Z-Tek
/// http://216.169.122.124/Z-Tek
///-----------------------------------------------

$InvList[AccelPPack] = 1;
$RemoteInvList[AccelPPack] = 1;