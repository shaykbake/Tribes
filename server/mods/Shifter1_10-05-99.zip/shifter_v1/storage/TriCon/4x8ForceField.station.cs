///-----------------------------------------------
/// description = "4x8 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[fourbyeightForceFieldPack] = 1;
$RemoteInvList[fourbyeightForceFieldPack] = 1;