///-----------------------------------------------
/// description = "Jail Capture Pads";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[JailCapPack] = 1;
$RemoteInvList[JailCapPack] = 1;