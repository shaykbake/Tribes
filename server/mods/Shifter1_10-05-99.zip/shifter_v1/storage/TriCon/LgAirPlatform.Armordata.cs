///-----------------------------------------------
/// description = "Air Large Platform";
/// MiniMod Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, LargeAirPlatPack] = 1;
$ItemMax[sarmor, LargeAirPlatPack] = 0;
$ItemMax[barmor, LargeAirPlatPack] = 0;
$ItemMax[harmor, LargeAirPlatPack] = 1;
$ItemMax[darmor, LargeAirPlatPack] = 0;
$ItemMax[marmor, LargeAirPlatPack] = 1;
$ItemMax[mfemale, LargeAirPlatPack] = 1;
$ItemMax[earmor, LargeAirPlatPack] = 1;
$ItemMax[efemale, LargeAirPlatPack] = 1;
$ItemMax[lfemale, LargeAirPlatPack] = 1;
$ItemMax[sfemale, LargeAirPlatPack] = 0;
$ItemMax[bfemale, LargeAirPlatPack] = 0;
$ItemMax[spyarmor, LargeAirPlatPack] = 0;
$ItemMax[spyfemale, LargeAirPlatPack] = 0;
$ItemMax[adarmor, LargeAirPlatPack] = 1;
$ItemMax[sadarmor, LargeAirPlatPack] = 1;
$ItemMax[parmor, LargeAirPlatPack] = 0;