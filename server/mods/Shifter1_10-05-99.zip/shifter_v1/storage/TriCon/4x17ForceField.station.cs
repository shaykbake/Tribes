///-----------------------------------------------
/// description = "4x17 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[fourbyseventeenForceFieldPack] = 1;
$RemoteInvList[fourbyseventeenForceFieldPack] = 1;