///-----------------------------------------------
/// description = "Hologram";
/// MiniMod Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, HoloPack] = 1;
$ItemMax[sarmor, HoloPack] = 1;
$ItemMax[barmor, HoloPack] = 1;
$ItemMax[harmor, HoloPack] = 1;
$ItemMax[darmor, HoloPack] = 1;
$ItemMax[marmor, HoloPack] = 1;
$ItemMax[mfemale, HoloPack] = 1;
$ItemMax[earmor, HoloPack] = 1;
$ItemMax[efemale, HoloPack] = 1;
$ItemMax[lfemale, HoloPack] = 1;
$ItemMax[sfemale, HoloPack] = 1;
$ItemMax[bfemale, HoloPack] = 1;
$ItemMax[spyarmor, HoloPack] = 1;
$ItemMax[spyfemale, HoloPack] = 1;
$ItemMax[adarmor, HoloPack] = 1;
$ItemMax[sadarmor, HoloPack] = 1;
$ItemMax[parmor, HoloPack] = 0;