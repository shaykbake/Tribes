///-----------------------------------------------
/// description = "Jail Cell";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[jailpack] = 1;
$RemoteInvList[jailpack] = 0;