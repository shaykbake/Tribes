///-----------------------------------------------
/// description = "Jail Gun";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[JailGun] = 1;
$RemoteInvList[JailGun] = 1;

