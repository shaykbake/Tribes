///-----------------------------------------------
/// description = "3x4 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, threebyfourForceFieldPack] = 1;
$ItemMax[sarmor, threebyfourForceFieldPack] = 1;
$ItemMax[barmor, threebyfourForceFieldPack] = 0;
$ItemMax[harmor, threebyfourForceFieldPack] = 0;
$ItemMax[darmor, threebyfourForceFieldPack] = 0;
$ItemMax[marmor, threebyfourForceFieldPack] = 1;
$ItemMax[mfemale, threebyfourForceFieldPack] = 1;
$ItemMax[earmor, threebyfourForceFieldPack] = 1;
$ItemMax[efemale, threebyfourForceFieldPack] = 1;
$ItemMax[lfemale, threebyfourForceFieldPack] = 1;
$ItemMax[sfemale, threebyfourForceFieldPack] = 1;
$ItemMax[bfemale, threebyfourForceFieldPack] = 0;
$ItemMax[spyarmor, threebyfourForceFieldPack] = 0;
$ItemMax[spyfemale, threebyfourForceFieldPack] = 0;
$ItemMax[adarmor, threebyfourForceFieldPack] = 0;
$ItemMax[sadarmor, threebyfourForceFieldPack] = 0;
$ItemMax[parmor, threebyfourForceFieldPack] = 0;