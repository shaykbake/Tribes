///-----------------------------------------------
/// description = "Jail Cell";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, jailpack] = 1;
$ItemMax[sarmor, jailpack] = 0;
$ItemMax[barmor, jailpack] = 0;
$ItemMax[harmor, jailpack] = 0;
$ItemMax[darmor, jailpack] = 0;
$ItemMax[marmor, jailpack] = 1;
$ItemMax[mfemale, jailpack] = 1;
$ItemMax[earmor, jailpack] = 1;
$ItemMax[efemale, jailpack] = 1;
$ItemMax[lfemale, jailpack] = 1;
$ItemMax[sfemale, jailpack] = 0;
$ItemMax[bfemale, jailpack] = 0;
$ItemMax[spyarmor, jailpack] = 0;
$ItemMax[spyfemale, jailpack] = 0;
$ItemMax[adarmor, jailpack] = 0;
$ItemMax[sadarmor, jailpack] = 0;
$ItemMax[parmor, jailpack] = 0;