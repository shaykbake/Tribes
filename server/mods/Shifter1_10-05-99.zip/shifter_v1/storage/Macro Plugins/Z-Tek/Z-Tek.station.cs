// This is a MiniMod plugin.
// This is the PhaseLok+SheildGens Pack from the Z-Tek mod. Ported by Dewy.

$InvList[PhaseLokPack] = 1;
$RemoteInvList[PhaseLokPack] = 1;
$InvList[DShieldPack] = 1;
$RemoteInvList[DShieldPack] = 0;
