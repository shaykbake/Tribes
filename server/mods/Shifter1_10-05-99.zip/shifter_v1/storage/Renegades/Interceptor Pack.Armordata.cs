//This is a MiniMod Plugin...
//This is the Interceptor Pack from the ol' Renegades1.2 mod. Ported&Modified by Dewy.

$ItemMax[aarmor, MechPack] = 0;
$ItemMax[tarmor, MechPack] = 0;
$ItemMax[larmor, MechPack] = 1;
$ItemMax[marmor, MechPack] = 0;
$ItemMax[harmor, MechPack] = 0;
$ItemMax[lfemale, MechPack] = 1;
$ItemMax[mfemale, MechPack] = 0;
$ItemMax[sarmor, MechPack] = 1;
$ItemMax[sfemale, MechPack] = 1;
$ItemMax[barmor, MechPack] = 0;
$ItemMax[darmor, MechPack] = 0;
$ItemMax[bfemale, MechPack] = 0;
$ItemMax[spyarmor, MechPack] = 1;
$ItemMax[spyfemale, MechPack] = 1;
$ItemMax[earmor, MechPack] = 0;
$ItemMax[efemale, MechPack] = 0;

