//This is a MiniMod Plugin...
//This is the Teleport Pad from the ol' Renegades1.2 mod. Ported&Modified by Dewy.

$ItemMax[aarmor, TeleportPack] = 1;
$ItemMax[tarmor, TeleportPack] = 1;
$ItemMax[larmor, TeleportPack] = 0;
$ItemMax[marmor, TeleportPack] = 1;
$ItemMax[harmor, TeleportPack] = 0;
$ItemMax[lfemale, TeleportPack] = 0;
$ItemMax[mfemale, TeleportPack] = 1;
$ItemMax[sarmor, TeleportPack] = 0;
$ItemMax[sfemale, TeleportPack] = 0;
$ItemMax[barmor, TeleportPack] = 0;
$ItemMax[darmor, TeleportPack] = 0;
$ItemMax[bfemale, TeleportPack] = 0;
$ItemMax[spyarmor, TeleportPack] = 0;
$ItemMax[spyfemale, TeleportPack] = 0;
$ItemMax[earmor, TeleportPack] = 1;
$ItemMax[efemale, TeleportPack] = 1;

