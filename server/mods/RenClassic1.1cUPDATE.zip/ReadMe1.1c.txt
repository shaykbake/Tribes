
                        RenWerX
                         (FTA)
              The original creators of Renegades
                  www.planetrenegades.com
 			brings you

               ******Renegades Classic******
                       Version 1.1c



This is an **update patch** to Renegades Classic.  You must have version 1.1a
or later installed to take advantage of the admin features.  

The following is a list of changes over Renegades Classic 1.1b


**********************************************************************************************

*****************************
***Fixes/bugs/enhancements
*****************************

1)  Fixed a bug where you were no longer able to select a weapon after accessing
    an ammostation, if it was destroyed while your ammo was being refilled.

2)  Fixed a bug where it was possible to give a deployable Inventory station
    unlimited energy.  Using this bug would allow the player to use beacons, 
    select weapons, change armor, etc. while accessing a station.  This could
    also allow a player (although difficult to do) to cloak other armor classes, 
    as well as give other armor classes the heavy's shield beacon.  (VERY BAD!!)

3)  Updated the Hud and splash screen information with RenWerX and the new URL.

4)  Small change to the Admin security mentioned in the 1.1b release.


**********************************************************************************************

NOTES:
   I did a brief test on the changes, and everything seems to work as expected.  If you
   find any issues with this patch please let me know at snypress@planetrenegades.com



Installation:

   Extract the scripts.vol into your dynamix\tribes\renegades directory overwriting your
   older scripts.vol.

Coding by: Snypress (snypress@planetrenegades.com)

