// This is a MiniMod plugin
// This is the Rail Turret From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ RailTurret] = 0;
}
