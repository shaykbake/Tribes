// Flare Gun by [BIO]iCE.! and [BIO]EvilBastard (uses a Tool Slot)
SoundData SoundFlare
{
	wavFilename = "explo3.wav";
	profile = Profile3dLudicrouslyFar;
};