// Flare Gun by [BIO]iCE.! and [BIO]EvilBastard (uses a Tool Slot)

%cnt = %cnt + AmmoStation::resupply(%player,FlareGun,FlareAmmo,5); 
