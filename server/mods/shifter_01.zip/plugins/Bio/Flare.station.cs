// Flare Gun by [BIO]iCE.! and [BIO]EvilBastard (uses a Tool Slot)
//---------------------------------------------------------------------
// List of all items available to buy from inventory station
//---------------------------------------------------------------------

$InvList[FlareGun] = 1;

$InvList[FlareAmmo] = 1;
  
//---------------------------------------------------------------------
// List of all items available to buy from Remote Station
//---------------------------------------------------------------------

$RemoteInvList[FlareGun] = 1;

$RemoteInvList[FlareAmmo] = 1;
