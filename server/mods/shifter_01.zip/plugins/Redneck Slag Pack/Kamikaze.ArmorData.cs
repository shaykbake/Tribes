//-----------------------------------
//Redneck Slag Pack
//-----------------------------------

//-----------------------------------
//   Light Armor
//-----------------------------------

$DamageScale[larmor, $KamikazeDamageType] = 3.0;
$ItemMax[larmor, KamikazePack] = 1;

//-----------------------------------
//   Medium Armor
//-----------------------------------

$DamageScale[marmor, $KamikazeDamageType] = 2.0;
$ItemMax[marmor, KamikazePack] = 1;

//-----------------------------------
//   Heavy Armor
//-----------------------------------

$DamageScale[harmor, $KamikazeDamageType] = 1.0;
$ItemMax[harmor, KamikazePack] = 0;

//-----------------------------------
//   Light Female Armor
//-----------------------------------

$DamageScale[lfemale, $KamikazeDamageType] = 3.0;
$ItemMax[lfemale, KamikazePack] = 1;

//-----------------------------------
//   Medium Female Armor
//-----------------------------------

$DamageScale[mfemale, $KamikazeDamageType] = 2.0;
$ItemMax[mfemale, KamikazePack] = 1;