// This is a MiniMod Plugin.
// This plugin is the Plasma Cannon from the Redneck Slag Pack.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    PlasmaCannon.ArmorData.cs
//    PlasmaCannon.baseProjData.cs
//    PlasmaCannon.item.cs
//    PlasmaCannon.station.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, PlasmaCannon] = 0;
$ItemMax[lfemale, PlasmaCannon] = 0;
$ItemMax[marmor, PlasmaCannon] = 0;
$ItemMax[mfemale, PlasmaCannon] = 0;
$ItemMax[harmor, PlasmaCannon] = 1;

$ItemMax[sarmor, PlasmaCannon] = 0;
$ItemMax[sfemale, PlasmaCannon] = 0;
$ItemMax[spyarmor, PlasmaCannon] = 0;
$ItemMax[spyfemale, PlasmaCannon] = 0;
$ItemMax[barmor, PlasmaCannon] = 0;
$ItemMax[bfemale, PlasmaCannon] = 0;
$ItemMax[earmor, PlasmaCannon] = 0;
$ItemMax[efemale, PlasmaCannon] = 0;
$ItemMax[aarmor, PlasmaCannon] = 0;
$ItemMax[afemale, PlasmaCannon] = 0;
$ItemMax[darmor, PlasmaCannon] = 1;

