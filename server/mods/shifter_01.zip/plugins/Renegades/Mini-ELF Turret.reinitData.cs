//This is a MiniMod Plugin...
//This is the ELF turret from the ol' Renegades1.2 mod. Ported&Modified by Dewy.

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ ShockPack] = 0;
}
