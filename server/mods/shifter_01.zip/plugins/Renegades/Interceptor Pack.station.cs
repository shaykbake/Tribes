//This is a MiniMod Plugin...
//This is the Interceptor Pack from the ol' Renegades1.2 mod. Ported&Modified by Dewy.

$InvList[MechPack] = 1;
$RemoteInvList[MechPack] = 1;
$VehicleInvList[JetVehicle] = 1;
