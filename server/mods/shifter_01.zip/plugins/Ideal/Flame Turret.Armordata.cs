// This is a MiniMod Plugin.
// This plugin is the Flame Turret from the Ideal mod.
// Ported by Dewy.
//
// To install this plugin just...
// Add:
//
//    Flame Turret.ArmorData.cs
//    Flame Turret.baseExpData.cs
//    Flame Turret.baseProjData.cs
//    Flame Turret.item.cs
//    Flame Turret.Nsound.cs
//    Flame Turret.reinitData.cs
//    Flame Turret.staticshape.cs
//    Flame Turret.station.cs
//    Flame Turret.turret.cs
//
// to your MiniMod/plugins directory.

$DamageScale[larmor, $FlameDamageType] = 0.9;
$DamageScale[lfemale, $FlameDamageType] = 0.9;
$DamageScale[marmor, $FlameDamageType] = 1.0;
$DamageScale[mfemale, $FlameDamageType] = 1.0;
$DamageScale[harmor, $FlameDamageType] = 1.1;
$DamageScale[sarmor, $FlameDamageType] = 1.4;
$DamageScale[sfemale, $FlameDamageType] = 1.4;
$DamageScale[spyarmor, $FlameDamageType] = 1.4;
$DamageScale[spyfemale, $FlameDamageType] = 1.4;
$DamageScale[barmor, $FlameDamageType] = 1.0;
$DamageScale[bfemale, $FlameDamageType] = 1.0;
$DamageScale[earmor, $FlameDamageType] = 1.0;
$DamageScale[efemale, $FlameDamageType] = 1.0;
$DamageScale[aarmor, $FlameDamageType] = 1.0;
$DamageScale[afemale, $FlameDamageType] = 1.0;
$DamageScale[barmor, $FlameDamageType] = 1.0;
$DamageScale[bfemale, $FlameDamageType] = 1.0;
$DamageScale[darmor, $FlameDamageType] = 1.0;
$DamageScale[tarmor, $FlameDamageType] = 1.3;
$DamageScale[scvarmor, $FlameDamageType] = 1.0;


$ItemMax[larmor, FlameTurretPack] = 0;
$ItemMax[lfemale, FlameTurretPack] = 0;
$ItemMax[marmor, FlameTurretPack] = 0;
$ItemMax[mfemale, FlameTurretPack] = 0;
$ItemMax[harmor, FlameTurretPack] = 1;
$ItemMax[sarmor, FlameTurretPack] = 0;
$ItemMax[sfemale, FlameTurretPack] = 0;
$ItemMax[spyarmor, FlameTurretPack] = 0;
$ItemMax[spyfemale, FlameTurretPack] = 0;
$ItemMax[barmor, FlameTurretPack] = 0;
$ItemMax[bfemale, FlameTurretPack] = 0;
$ItemMax[earmor, FlameTurretPack] = 1;
$ItemMax[efemale, FlameTurretPack] = 1;
$ItemMax[aarmor, FlameTurretPack] = 0;
$ItemMax[afemale, FlameTurretPack] = 0;
$ItemMax[darmor, FlameTurretPack] = 0;
$ItemMax[tarmor, FlameTurretPack] = 0;
$ItemMax[scvarmor, FlameTurretPack] = 0;
