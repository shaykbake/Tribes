// This is a MiniMod plugin.
// This is the PhaseLok+SheildGens Pack from the Z-Tek mod. Ported by Dewy.

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ DShieldPack] = 0;
		$TeamItemCount[%i @ PhaseLokPack] = 0;
}
