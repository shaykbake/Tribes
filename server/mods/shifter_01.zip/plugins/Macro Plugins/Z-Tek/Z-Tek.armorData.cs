// This is a MiniMod plugin.
// This is the PhaseLok+SheildGens Pack from the Z-Tek mod. Ported by Dewy.

$ItemMax[infarmor, DShieldPack] = 0;
$ItemMax[larmor, DShieldPack] = 0;
$ItemMax[marmor, DShieldPack] = 0;
$ItemMax[solarmor, DShieldPack] = 0;
$ItemMax[solfarmor, DShieldPack] = 0;
$ItemMax[avarmor, DShieldPack] = 0;
$ItemMax[harmor, DShieldPack] = 1;
$ItemMax[dreadarmor, DShieldPack] = 0;
$ItemMax[inffarmor, DShieldPack] = 0;
$ItemMax[lfarmor, DShieldPack] = 0;
$ItemMax[mfemale, DShieldPack] = 0;
$ItemMax[avfarmor, DShieldPack] = 0;
$ItemMax[predarmor, DShieldPack] = 0;
$ItemMax[predfarmor, DShieldPack] = 0;
$ItemMax[earmor, DShieldPack] = 1;
$ItemMax[efemale, DShieldPack] = 1;

$ItemMax[infarmor, PhaseLokPack] = 0;
$ItemMax[larmor, PhaseLokPack] = 0;
$ItemMax[marmor, PhaseLokPack] = 1;
$ItemMax[solarmor, PhaseLokPack] = 0;
$ItemMax[solfarmor, PhaseLokPack] = 0;
$ItemMax[avarmor, PhaseLokPack] = 0;
$ItemMax[harmor, PhaseLokPack] = 1;
$ItemMax[dreadarmor, PhaseLokPack] = 0;
$ItemMax[inffarmor, PhaseLokPack] = 0;
$ItemMax[lfarmor, PhaseLokPack] = 0;
$ItemMax[mfemale, PhaseLokPack] = 0;
$ItemMax[avfarmor, PhaseLokPack] = 0;
$ItemMax[predarmor, PhaseLokPack] = 0;
$ItemMax[predfarmor, PhaseLokPack] = 0;
$ItemMax[earmor, PhaseLokPack] = 1;
$ItemMax[efemale, PhaseLokPack] = 1;
