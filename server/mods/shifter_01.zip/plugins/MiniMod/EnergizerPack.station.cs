// This is a MiniMod Plugin.
// This plugin is the Energizer Pack. Created/Ported by Dewy.

$InvList[EnergizerPack] = 1; // You want the main Inventory stations to show it right?
$RemoteInvList[EnergizerPack] = 1; // You want the deployable Inventory stations to show it right?