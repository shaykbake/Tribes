//This a MiniMod Plugin.
//This is the default "ShitList" that ships with MiniMod v.07 or higher.

//You May "ShitList" anybody by their Nickname, IP address or IP Mask.
// Syntax: MiniMod::ShitList("Nickname", "The message you want them to read.");
//     or: MiniMod::ShitList("207.252.246.2", "The message you want them to read.");
//                   Bans just that IP address.
//
//     or: MiniMod::ShitList("207.252.246.", "The message you want them to read.");
//                   Bans the IP range from 207.252.246.0 through 207.252.246.255.
//                   (Please don't make this mask TOO wide.)

MiniMod::ShitList("B.F.M.", "You have been 'BlackListed' for known attempts at 'Server Take-Over's.");

