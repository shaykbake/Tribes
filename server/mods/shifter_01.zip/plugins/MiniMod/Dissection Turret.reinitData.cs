// This is a MiniMod Plugin.
// This plugin is the Dissection Turret from the MiniMod.
// Note: Code is based off of PeterT's Watchdog Turret plugin.
// Ported by Dewy.

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ DissectionPack] = 0;
}
