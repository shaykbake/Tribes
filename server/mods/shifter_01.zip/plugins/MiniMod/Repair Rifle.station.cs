// This is a MiniMod Plugin.
// This Plugin is the Repair Rifle.
// Requirements: MiniMod v.07 or later
//   and the Energizer Pack Plugin.

$InvList[RepairRifle] = 1; // You want the main Inventory stations to show it right?
$RemoteInvList[RepairPack] = 1; // You want the deployable Inventory stations to show it right?
