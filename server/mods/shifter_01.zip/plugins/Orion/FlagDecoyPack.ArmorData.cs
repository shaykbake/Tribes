// This is a MiniMod Plugin.
// This plugin is the Flag Decoy Pack from the Orion mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    FlagDecoyPack.ArmorData.cs
//    FlagDecoyPack.item.cs
//    FlagDecoyPack.station.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, FakeFlag] = 1;
$ItemMax[lfemale, FakeFlag] = 1;
$ItemMax[marmor, FakeFlag] = 1;
$ItemMax[mfemale, FakeFlag] = 1;
$ItemMax[harmor, FakeFlag] = 1;
$ItemMax[sarmor, FakeFlag] = 1;
$ItemMax[sfemale, FakeFlag] = 1;
$ItemMax[spyarmor, FakeFlag] = 1;
$ItemMax[spyfemale, FakeFlag] = 1;
$ItemMax[barmor, FakeFlag] = 1;
$ItemMax[bfemale, FakeFlag] = 1;
$ItemMax[earmor, FakeFlag] = 1;
$ItemMax[efemale, FakeFlag] = 1;
$ItemMax[afemale, FakeFlag] = 1;
$ItemMax[aarmor, FakeFlag] = 1;
$ItemMax[darmor, FakeFlag] = 1;
$ItemMax[tarmor, FakeFlag] = 1;
$ItemMax[scvarmor, FakeFlag] = 0;
