// This is a MiniMod Plugin.
// This plugin is the Flag Decoy Pack from the Orion mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    FlagDecoyPack.ArmorData.cs
//    FlagDecoyPack.item.cs
//    FlagDecoyPack.station.cs
//
// to your MiniMod/plugins directory.

$InvList[FakeFlag] = 1;
$RemoteInvList[FakeFlag] = 1;
