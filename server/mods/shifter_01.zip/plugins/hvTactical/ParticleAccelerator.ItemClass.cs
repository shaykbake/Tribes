// This is a MiniMod Plugin.
// This plugin is the Particle Accelerator from the hvTactical mod.
// Ported by PeterT.

$ItemClass = 28;
$Item = ClusterBomb;
$qty = 1;

MiniMod::Build::Classes();

$ItemClass = 29;
$Item = ClusterBomb;
$qty = 1;

MiniMod::Build::Classes();

