// This is a MiniMod Plugin.
// This plugin is the GuardDog (Shockwave) Turret from the hvTactical mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    GuardDogTurret.ArmorData.cs
//    GuardDogTurret.baseProjData.cs
//    GuardDogTurret.item.cs
//    GuardDogTurret.reinitData.cs
//    GuardDogTurret.station.cs
//    GuardDogTurret.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, ConPack] = 0;
$ItemMax[lfemale, ConPack] = 0;
$ItemMax[marmor, ConPack] = 0;
$ItemMax[mfemale, ConPack] = 0;
$ItemMax[harmor, ConPack] = 1;
$ItemMax[sarmor, ConPack] = 0;
$ItemMax[sfemale, ConPack] = 0;
$ItemMax[spyarmor, ConPack] = 0;
$ItemMax[spyfemale, ConPack] = 0;
$ItemMax[barmor, ConPack] = 0;
$ItemMax[bfemale, ConPack] = 0;
$ItemMax[earmor, ConPack] = 1;
$ItemMax[efemale, ConPack] = 1;
$ItemMax[aarmor, ConPack] = 0;
$ItemMax[afemale, ConPack] = 0;
$ItemMax[darmor, ConPack] = 0;
$ItemMax[tarmor, ConPack] = 0;
$ItemMax[scvarmor, ConPack] = 0;
