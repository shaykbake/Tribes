///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ newdoorfour] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}