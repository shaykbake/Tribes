///-----------------------------------------------
/// description = "JailGun";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, JailGun] = 1;
$ItemMax[marmor, JailGun] = 1;
$ItemMax[harmor, JailGun] = 1;
$ItemMax[lfemale, JailGun] = 1;
$ItemMax[mfemale, JailGun] = 1;
$ItemMax[hfemale, JailGun] = 1;
$ItemMax[sarmor, JailGun] = 1;
$ItemMax[darmor, JailGun] = 1;
$ItemMax[barmor, JailGun] = 1;
$ItemMax[sfemale, JailGun] = 1;
$ItemMax[bfemale, JailGun] = 1;
$ItemMax[spyarmor, JailGun] = 1;
$ItemMax[spyfemale, JailGun] = 1;
$ItemMax[earmor, JailGun] = 1;
$ItemMax[efemale, JailGun] = 1;
$ItemMax[afemale, JailGun] = 1;
$ItemMax[aarmor, JailGun] = 1;
$ItemMax[adarmor, JailGun] = 1;
$ItemMax[sadarmor, JailGun] = 1;
$ItemMax[cyarmor, JailGun] = 1;
$ItemMax[cyfemale, JailGun] = 1;

