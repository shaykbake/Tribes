///-----------------------------------------------
/// description = "5x5 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[fivebyfiveForceFieldPack] = 1;
$RemoteInvList[fivebyfiveForceFieldPack] = 1;