///-----------------------------------------------
/// description = "Hologram";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[HoloPack] = 1;
$RemoteInvList[HoloPack] = 1;