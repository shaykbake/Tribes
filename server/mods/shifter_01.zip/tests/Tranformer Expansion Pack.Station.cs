$InvList[TransAPCPack] = 1;
$RemoteInvList[TransAPCPack] = 0;

$InvList[TransHAPCPack] = 1;
$RemoteInvList[TransHAPCPack] = 0;

