$ItemMax[tarmor, TransAPCPack] = 1;
$ItemMax[tarmor, TransHAPCPack] = 1;
