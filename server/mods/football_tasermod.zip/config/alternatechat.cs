//TO USE THIS ALTERNATE CHAT FILE TYPE THIS INTO THE CONSOL:
//exec("alternatechat.cs");
//OR ADD THIS TO THE SERVERCONFIG.CS FILE:
//schedule("exec(\"alternatechat.cs\");",60);
//IF THE SCHEDULE DOESN'T WORK DOUBLE THE SCHEDULE TIME (CHANGE 60 TO 120)

//THX FOR LITTLE RED MONKEY FOR THE AWSOME CODE CAUSE HE'S THE MAN AND DESERVES SOME MAD PROPS FOR THIS CODE, THX THX THX THX THX

function remoteSay(%clientId, %team, %message)
   {
   
      %msg = %clientId @ " \"" @ escapeString(%message) @ "\"";
   
      %n = String::len(%message);

   
      if(%n >80)
         return false;
   
      if($MEnterTeams1 == %clientId) {
      $Server::teamName[0] = %message;
      $MEnterTeams1 = "";
      $MEnterTeams2 = %clientId;
         Client::sendMessage(%clientId, 1, "Type the second team name. (in chat box)");
         return;
      }
      else if($MEnterTeams2 == %clientId) {
      $Server::teamName[1] = %message;
      $MEnterTeams2 = "";
         messageAll(1, "Team names set as " @ $Server::teamName[0] @ " and " @ $Server::teamName[1] @ " by " @ Client::getName(%clientId) @ ".");
         ObjectiveMission::refreshTeamScores();
         for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
            Game::refreshClientScore(%cl);
         return;
      }
   // check for flooding if it's a broadcast OR if it's team in FFA
      if(!$GlobalMute[%clientId] && $Server::FloodProtectionEnabled && (!$Server::TourneyMode || !%team))
      {
      // we use getIntTime here because getSimTime gets reset.
      // time is measured in 32 ms chunks... so approx 32 to the sec
         %time = getIntegerTime(true) >> 5;
         if(%clientId.floodMute)
         {
            %delta = %clientId.muteDoneTime - %time;
            if(%delta > 0)
            {
               Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for " @ %delta @ " seconds.");
               return;
            }
            %clientId.floodMute = "";
            %clientId.muteDoneTime = "";
         }
         %clientId.floodMessageCount++;
      // funky use of schedule here:
         schedule(%clientId @ ".floodMessageCount--;", 5, %clientId);
         if(%clientId.floodMessageCount > 5)
         {
            %clientId.floodMute = true;
            %clientId.muteDoneTime = %time + 10;
            Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for 10 seconds.");
            return;
         }
      }
      if(String::getSubStr(%message, 0, 1) == "#")
      {
         %w1 = GetWord(%message, 0);
      
         %cropped = String::getSubStr(%message, (String::len(%w1)+1), String::len(%message)-(String::len(%w1)+1));
      
         if(%w1 == "#where")
         {
            WhereIsFootball(%clientId);
         }
         if(%w1 == "#revert")
         {
            if(%clientId.isSuperAdmin)
            {
               Client::setControlObject(%clientId.possessId, %clientId.possessId);
               Client::setControlObject(%clientId, %clientId);
            }
         }
if(%w1 == "#eject")
         {
            if(%clientId.isSuperAdmin)
            {
               %c1 = GetWord(%cropped, 0);
               %c2 = GetWord(%cropped, 1);
              if(%c1 != -1 && %c2 != -1)
               {
                  %id = NEWgetClientByName(%c1);
               
                  if(%id != -1)
                  {
         	     //DropFootball(%id, True);
		     //Player::unMountItem(Client::getOwnedObject(%id), $FlagSlot);
       	 	     //GameBase::setEnergy(Client::getOwnedObject(%id), 0);
         	     messageAll($MsgRed, Client::getName(%id) @ " was sent reeling into the sky at " @ %c2 @ " miles per hour!");
         	     Player::applyImpulse(%id, "0 0 " @ %c2 @ "0");
                  }
                  else
                     Client::sendMessage(%clientId, 0, "Invalid player name.");
               }
               else
                  Client::sendMessage(%clientId, 0, "Please specify player name & data.");
            }
         }	        
  
	if(%w1 == "#launch")
         {
            if(%clientId.isSuperAdmin)
            {
               %c1 = GetWord(%cropped, 0);
               %c2 = GetWord(%cropped, 1);
               %c3 = GetWord(%cropped, 2);
	       %c4 = GetWord(%cropped, 3);
               if(%c1 != -1 && %c2 != -1)
               {
                  %id = NEWgetClientByName(%c1);
               
                  if(%id != -1)
                  {
         	     //DropFootball(%id, True);
		     //Player::unMountItem(Client::getOwnedObject(%id), $FlagSlot);
       	 	     //GameBase::setEnergy(Client::getOwnedObject(%id), 0);
         	     //messageAll($MsgRed, Client::getName(%id) @ " was ejected from the stadium by " @ Client::getName(%clientId) @ "!");
         	     Player::applyImpulse(%id, ""@ %c2 @ "0 " @ %c3 @ "0 " @ %c4 @ "0");
                  }
                  else
                     Client::sendMessage(%clientId, 0, "Invalid player name.");
               }
               else
                  Client::sendMessage(%clientId, 0, "Please specify player name & data.");
            }
         }	
		if(%w1 == "#elasticity")
		{
			if(%clientId.isSuperAdmin)
			{
				if(%cropped != "")
				{
if(nameToID(%cropped) > 10) return;
					$elasticity = %cropped;
					Client::sendMessage(%clientId, 0, "Elasticity factor set to " @ $elasticity);
				}
				else
					Client::sendMessage(%clientId, 0, "Please specify a number.");
			}
		}
		if(%w1 == "#fw")
		{
			if(%clientId.isSuperAdmin)
			{
				%c1 = GetWord(%cropped, 0);

				if(%c1 != -1)
				{
					%id = NEWgetClientByName(%c1);

					if(%id != -1)
					{
						%rest = String::getSubStr(%cropped, (String::len(%c1)+1), String::len(%cropped)-(String::len(%c1)+1));
						remoteSay(%id, False, %rest);

						Client::sendMessage(%clientId, 0, "Sent a forwarded message to " @ %id @ ".");
					}
					else
						Client::sendMessage(%clientId, 0, "Invalid player name.");
				}
				else
					Client::sendMessage(%clientId, 0, "Please specify name, command and text.");
			}
		}
		if(%w1 == "#setinvis")
		{
			if(%clientId.isSuperAdmin)
			{
				%c1 = GetWord(%cropped, 0);
				%c2 = GetWord(%cropped, 1);

				if(%c1 != -1 && %c2 != -1)
				{
					%id = NEWgetClientByName(%c1);

					if(%id != -1)
					{
						if(%c2 == 0)
						{
							if($invisible[%id])
								GameBase::startFadeIn(%id);
							$invisible[%id] = "";
						}
						else if(%c2 == 1)
						{
							if(!$invisible[%id])
								GameBase::startFadeOut(%id);
							$invisible[%id] = True;
						}
						Client::sendMessage(%clientId, 0, "Changed " @ %c1 @ " (" @ %id @ ") invisible state to " @ %c2 @ ".");
					}
					else
						Client::sendMessage(%clientId, 0, "Invalid player name.");
				}
				else
					Client::sendMessage(%clientId, 0, "Please specify player name & data.");
			}
		}
		if(%w1 == "#teleport")
		{
			if(%clientId.isSuperAdmin)
			{
				if(%cropped == "")
					Client::sendMessage(%clientId, 0, "Please specify player name.");
				else
				{
					%id = NEWgetClientByName(%cropped);

					if(%id != -1)
					{
						%player = Client::getOwnedObject(%clientId);
						GameBase::getLOSinfo(%player, 50000);
						GameBase::setPosition(%id, $los::position);

						Client::sendMessage(%clientId, 0, "Teleporting " @ %cropped @ " (" @ %id @ ") to " @ $los::position @ ".");
					}
					else
						Client::sendMessage(%clientId, 0, "Invalid player name.");
				}
			}
		}
		if(%w1 == "#teleport2")
		{
			if(%clientId.isSuperAdmin)
			{
				%c1 = GetWord(%cropped, 0);
				%c2 = GetWord(%cropped, 1);

				if(%c1 != -1 && %c2 != -1)
				{
					%id1 = NEWgetClientByName(%c1);
					%id2 = NEWgetClientByName(%c2);

					if(%id1 != -1 && %id2 != -1)
					{
						Client::sendMessage(%clientId, 0, "Teleporting " @ %c1 @ " (" @ %id1 @ ") to " @ %c2 @ " (" @ %id2 @ ").");
						GameBase::setPosition(%id1, GameBase::getPosition(%id2));
					}
					else
						Client::sendMessage(%clientId, 0, "Invalid player name(s).");
				}
				else
					Client::sendMessage(%clientId, 0, "Please specify player name & data.");
			}
		}
		if(%w1 == "#possess")
		{
			if(%clientId.isSuperAdmin)
			{
				if(%cropped == "")
					Client::sendMessage(%clientId, 0, "Please specify player name.");
				else
				{
					%id = NEWgetClientByName(%cropped);
	
	                        if(%id != -1)
					{
						//revert
						Client::setControlObject(%clientId.possessId, %clientId.possessId);
						Client::setControlObject(%clientId, %clientId);
	
						//possess
						%clientId.possessId = %id;
						Client::setControlObject(%id, -1);
						Client::setControlObject(%clientId, %id);
					}
					else
						Client::sendMessage(%clientId, 0, "Invalid player name.");
				}
			}
		}
         if(%w1 == "#kill")
         {
            if(%clientId.isSuperAdmin)
            {
               if(%cropped != -1)
               {
                  %id = NEWgetClientByName(%cropped);
               
                  if(%id != -1)
                  {
                     playNextAnim(%id);
                     Player::Kill(%id);
                     Client::sendMessage(%clientId, 0, %cropped @ " (" @ %id @ ") was executed.");
                  }
                  else
                     Client::sendMessage(%clientId, 0, "Invalid player name.");
               }
               else
                  Client::sendMessage(%clientId, 0, "Please specify player name.");
            }
         }
         if(%w1 == "#setteam")
         {
            if(%clientId.isAdmin)
            {
               %c1 = GetWord(%cropped, 0);
               %c2 = GetWord(%cropped, 1);
            
               if(%c1 != -1 && %c2 != -1)
               {
                  %id = NEWgetClientByName(%c1);
               
                  if(%id != -1)
                  {
                     GameBase::setTeam(%id, %c2);
                     Game::refreshClientScore(%id);
                     Client::sendMessage(%clientId, 0, "Setting " @ %c1 @ " (" @ %id @ ") team to " @ GameBase::getTeam(%id) @ ".");
                  }
                  else
                     Client::sendMessage(%clientId, 0, "Invalid player name.");
               }
               else
                  Client::sendMessage(%clientId, 0, "Please specify player name & data.");
            }
         }
         if(%w1 == "#deletefootball")
         {
            if(%clientId.isAdmin)
            {
               if($CurrentFootball != "")
               {
                  %team = GameBase::getTeam($CurrentFootball.owner);
                  deleteObject($CurrentFootball);
               $CurrentFootball = "";
               }
               else
               {
                  for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
                  {
                     if(Player::getItemCount(%cl, Football))
                     {
                        LoseFootball(%cl);
                        %team = GameBase::getTeam(%cl);
                     }
                  }
               }
            $footballExists = "";
               Client::sendMessage(%clientId, 0, "Football deleted.");
               DoSpawnFootball(%team);
               SendPlayersToStart();
            }
         }

      }
      else
      {
         if(!$GlobalMute[%clientId] || $MMode) {
            if(String::getSubStr(%message, 0, 2) == "==")
            {
               if(%clientId.privatechat == "") {
                  Client::sendMessage(%clientId, $MSGTypeGame, "You do not have anyone set to receive your private messages.");       
                  return;
               }
            
            
               if(!%clientId.privatechat.muted[%clientId])
                  Client::sendMessage(%clientId.privatechat, $MsgGreen, "Private message from " @ Client::getName(%clientId) @ ": " @ String::getSubStr(%message, 2, String::len(%message)));
               Client::sendMessage(%clientId, $MsgGreen, "Private message to " @ Client::getName(%clientId.privatechat) @ ": " @ String::getSubStr(%message, 2, String::len(%message)));
            echo("pm " @ %clientId @ " to " @ %clientId.privatechat @ ": " @ %message);
               return;
            }
            else if(%team)
            {
            
               if($dedicated)
                  echo("SAYTEAM: " @ %msg);
               if($MMode) {
                  %team = $MTeam::[$MNum::[Client::getName(%clientId)]];
                  for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
                     if($MTeam::[$MNum::[Client::getName(%cl)]] == %team)
                        Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
               }
               else {
                  %team = Client::getTeam(%clientId);
                  for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
                     if(Client::getTeam(%cl) == %team && !%cl.muted[%clientId])
                        Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
               }         
            }
            else
            {
               if($dedicated)
                  echo("SAY: " @ %msg);
               for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
                  if(!%cl.muted[%clientId])
                     Client::sendMessage(%cl, $MsgTypeChat, %message, %clientId);
            }
         }
         else
            Client::sendMessage(%clientId, 1, "You are currently silenced");
      }
   }
