// Annihilation 2.3 sample mission list.
// This file can be executed from annihilation.cs

MissionList::clear();

	MissionList::addMission("Wop!");
	MissionList::addMission("Suicide");
	MissionList::addMission("Strange_Land");
	MissionList::addMission("Scooby_Snack");	
	MissionList::addMission("RoachMotel");	
	MissionList::addMission("PartyGirl");	
	MissionList::addMission("Mortum");	
	MissionList::addMission("Moon_Walk");	
	MissionList::addMission("Monky_Map");	
	MissionList::addMission("Jive_Turkey");	
	MissionList::addMission("Inferno_X");	
	MissionList::addMission("Highside");
	MissionList::addMission("Hall_of_the_King");	
	MissionList::addMission("Gore_Globe");	
	MissionList::addMission("GlassSide");			
	MissionList::addMission("Enlightenment");	
	MissionList::addMission("Dog_Fight");
	MissionList::addMission("Damn_Tarts");
	MissionList::addMission("Challenge");
	MissionList::addMission("Canyoneros");
	MissionList::addMission("Bullseye");
	MissionList::addMission("Brood");
	MissionList::addMission("Blue_Buddha");
	MissionList::addMission("Bitter_Cold");
	MissionList::addMission("Behind_the_Enemy_Line");
	MissionList::addMission("A_Snipers_Dream");
	MissionList::addMission("Attack_on_Zeta Bot");
	MissionList::addMission("Arsenal_Warfare");
	MissionList::addMission("Air_Raid");
	MissionList::addMission("1V");

$pref::LastMission = "1V";
MissionList::initNextMission();