// Annihilation Auto admin.
// See the instructions in the Setup.txt
// Please note that 192.168.*.* is a LAN address and not a web address.
// Unless they're sitting next to you connected to your home lan,
// there's no way anyone can gain admin with this IP mask.
// This is here to serve as an example. 

$AnnAdmin::Mask1 = "Owner 192.168.*.*";
$AnnAdmin::Name1 = "{-o-} Plasmatic";
