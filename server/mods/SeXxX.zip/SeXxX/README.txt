

=============================================
   SEX mod copyright May 2001 Steve madden 
          ziptiezmail@netscape.net
             n3ppvw@home.com
               icq 77161332
         http://plasmatica.cjb.net/
        If you want to use any code 
	 from the mod, contact me.
 If you need to modify it to fix a problem, 
        PLEASE! Let me know about it.


Thanks, Steve aka Plasmatic


=============================================
Optical rockets highly modified from code received from Sevnn.
Vortex turret code from Scavenger, highly modified.
Thanks to the great programmers at Dynamix, this mod is based on their BASE mod.