//----------------------------------------------------------------------------------
//-----------------------      TAC Map Ratings      ----------------------------
//----------------------------------------------------------------------------------
//
//	Put a value of "false" here to ignore this feature of TAC.
//	Put a value of "true" here to use this feature
$TAC::MRenabled = "true";


//----------------------------------------------------------------------------------
// 	$MR::ratioString allows you to choose what map rating will be played when
//	eg.
//		$MR::ratioString="1 1 2 4";
//		This will play two verypopular maps, then one popular map, then one
//		unpopular map.  It will then start again.
//
//	the default setup is:
//  	verypopular=	4 or 40%
//  	popular=		3 or 30%
//  	average=		2 or 20%
//  	unpopular=		1 or 10%
//
//	change them to whatever you please
//
$TAC::MRratioString="1 2 1 3 2 4 1 2 3 1";


//----------------------------------------------------------------------------------
//	To change the rating of a map, just change the field after the maps name.
//	To enter a new map, simply copy insert a new call to MR::setRating ("newMap", "rating");
//	Possible ratings are:
//			verypopular
//			popular
//			average
//			unpopular
//			neverplay
//
//	Any map that isn't given a rating is automatically assigned "average"
//

TAC::MRsetRating ("A_HighRise_Hell_D&D",		"verypopular");
TAC::MRsetRating ("BadLands_C&H",	 			"verypopular");
TAC::MRsetRating ("HawkEye_CTF", 				"verypopular");
TAC::MRsetRating ("Ice_Fusion_CTF", 			"verypopular");
TAC::MRsetRating ("JustHoldIt_C&H", 			"verypopular");
TAC::MRsetRating ("ParsonsSkys_CTF", 			"verypopular");
TAC::MRsetRating ("TheNoFlyZone_CTF",			"verypopular");
TAC::MRsetRating ("PotHole_CTF", 				"verypopular");
TAC::MRsetRating ("Sarkanus-3_C&H", 			"verypopular");

TAC::MRsetRating ("Air_Coaster_CTF", 			"popular");
TAC::MRsetRating ("Altitude_C&H",	 			"popular");
TAC::MRsetRating ("Close_C&H",		 			"popular");
TAC::MRsetRating ("DeathValley_CTF", 			"popular");
TAC::MRsetRating ("Winter_CTF",		 			"popular");
TAC::MRsetRating ("Outpost_D&D", 				"popular");
TAC::MRsetRating ("SkiJump_CTF", 				"popular");
TAC::MRsetRating ("Sunny_Days_CTF", 			"popular");

TAC::MRsetRating ("BigSkies_CTF", 				"average");
TAC::MRsetRating ("Dead_Landing_CTF", 			"average");
TAC::MRsetRating ("NightFlyers_CTF", 			"average");
TAC::MRsetRating ("DryHeat_F&R", 				"average");
TAC::MRsetRating ("A_Dark_Night_TDM", 			"average");

TAC::MRsetRating ("FogHorn_F&R", 				"unpopular");
TAC::MRsetRating ("Hairball_TDM", 				"unpopular");
TAC::MRsetRating ("RuleTheSkies_TDM", 			"unpopular");
