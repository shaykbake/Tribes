$Snipers::BanKickTime = "600";
$Snipers::fairTeams = "true";
$Snipers::PABan = "false";
$Snipers::PAKick = "true";
$Snipers::PAMission = "true";

$Snipers::PADetongue = "true";		//Allows PublicAdmins to have the ability to detongue someone
$Snipers::PABlowUp = "true";			//Allows PublicAdmins to have the ability to blowup someone
$Snipers::PAStripVoteRights = "true";	//Allows PublicAdmins to have the ability to strip someones ability to vote

$Snipers::PAModOptions = "false";
$Snipers::PAResetDefaults = "true";
$Snipers::PATeamChange = "true";
$Snipers::PATeamDamage = "true";
$Snipers::PATeamInfo = "false";
$Snipers::PATimelimit = "false";
$Snipers::PATourneyMode = "false";
$Snipers::PAVote = "false";

$Snipers::tkClientLvl = "1";
$Snipers::tkLimit = "3";
$Snipers::tkMultiple = "3";
$Snipers::tkServerLvl = "3";
$TelnetPort = 28001;


//You now have the ability to enable out of area damage.  Set this to true to enable.
//If you take a repair pack and try to live outside the mission area, you will be 
//teleported back to the original location that you entered in about 45 seconds.
//This works in free for all mode only
$Snipers::OutOfAreaDamage = true;

//Set to 1 if you want to enable the ban/kick by name, on player connect.  Make sure to set
//up your list in the config\\BBNList.cs
$BanByName::IsOn = 0;

//logs the name and IP of everyone who connects, to config\\Connect.log
$ConnectLog = true; 

//log people who are kicked by admins, to config\\KickList.log
$ExportAKicks = false; 

//log people who are kicked by the computer, to config\\KickList.log
$ExportCKicks = false; 

//log everyone who is auto-admined to config\\AdminLog.log
$ExportAdmin = 0;

//log all admins punishments applied to players to config\\AdminPunish.log
$ExportAdminPun = 1;

//What you want it to say when an admin kicks a client, this is a centerprint message
//The "\n" will seperate lines of text on the screen... Example....
$Admin::KickMessage = "For being a complete Idiot, and total moron.....\n\n You are being kicked off of this server. \n\n Come back when you no longer have an attack of the dumbass.";

//If you want to see your personal skins.  The skins must be installed in your(clientside)
//tribes\base\skins directory, and set this option to true.
$Snipers::PersonalSkin = "true"; 

//When set to true, no one can blow you out of ANY stations
//I wouldn't set this unless you have the station kick on also.
//Without the station kick, they can tie up a station for the rest of the game
//if they want, and nothing will blow them out!!
//If the person gets blocked in so that the station kick function can't
//kick them out, THEN you can shoot them out of the station, but not before.
$StationLockTD = "true";  // no knock from station with teamdamage off
$StationLockNTD = "true";  // no knock from station with teamdamage on

//How long the server will wait before ejecting someone out of a inventory station.  This
//only works when there are more then 3 people in the game
$Snipers::StationTime = "60";  //range is 10-60

$PA::noKick = "false";  //if set to true, public admins cant be kicked by a vote

//Special message for the owner when you gain super admin
//status with the SAD code and reports this name in the server info menu
$Owner::Name = "King Shit{|XK|}"; 

//ownerpassword gives God admin status, adminpassword gives
//superadmin status, and of course publicpassword gives public
//admin status

$TelnetPassword = "password";
$OwnerPassword = "password";
$AdminPassword = "password";
$PublicPassword = "password";

//Enables stat tracking in console.  Usage will echo flag caps, returns, drops, 
//objective captures, destroyed objects.....etc.
$StatTrack = true;