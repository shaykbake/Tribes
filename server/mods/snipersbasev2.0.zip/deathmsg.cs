//---------------------------------------------------------------------------------
//
//	DEATH MESSAGES
//
//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------
// Player death messages - %1 = killer's name, %2 = victim's name
//       %3 = killer's gender pronoun (his/her), %4 = victim's gender pronoun
//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------
//	ICE
//---------------------------------------------------------------------------------
$deathMsg[$IceDamageType, 0] = "%2 freezes to death.";
$deathMsg[$IceDamageType, 1] = "%2 now knows what Ice Cream feels like.";
$deathMsg[$IceDamageType, 2] = "%2 gets a sudden chill.";
$deathMsg[$IceDamageType, 3] = "%2 say's 'A bit nipply in here!'";

//---------------------------------------------------------------------------------
//	KAMIKAZE
//---------------------------------------------------------------------------------
$deathMsg[$KamikazeDamageType, 0] = "%2 learns to hate Kamikazes. %1 teaches a harsh lesson.";
$deathMsg[$KamikazeDamageType, 1] = "%1 died for his cause and took %2 with %3self.";
$deathMsg[$KamikazeDamageType, 2] = "%1 defines \"Kamikaze\" for %2.";
$deathMsg[$KamikazeDamageType, 3] = "%1 takes %2 to the afterlife with %3self.";
$deathMsg[$KamikazeDamageType, 4] = "%1 makes a successfull run on %2.";

//---------------------------------------------------------------------------------
//	MELEE
//---------------------------------------------------------------------------------
$deathMsg[$MeleeDamageType, 0] = "%2 let %1 sneek up behind him.";
$deathMsg[$MeleeDamageType, 1] = "%1 cut %2 down to size.";
$deathMsg[$MeleeDamageType, 2] = "%2 got sawed in half by %1.";
$deathMsg[$MeleeDamageType, 3] = "%2 never saw it coming from %1";
$deathMsg[$MeleeDamageType, 4] = "%2 was mutilated by %1.";

//---------------------------------------------------------------------------------
//	BOOSTER
//---------------------------------------------------------------------------------
$deathMsg[$BoosterDamageType, 0] = "%2 got to close to %1's after burner's.";
$deathMsg[$BoosterDamageType, 1] = "%1 gave %2 a boost.";
$deathMsg[$BoosterDamageType, 2] = "%2 got coocked by %1's thruster's.";
$deathMsg[$BoosterDamageType, 3] = "%1 say's to %2 'OOoooo! Toasty!'";
$deathMsg[$BoosterDamageType, 4] = "%2 was ingulfed by %1's after burner's.";

//---------------------------------------------------------------------------------
//	BLIND
//---------------------------------------------------------------------------------
$deathMsg[$BlindDamageType, 0] = "%2 got blinded to death by %1.";
$deathMsg[$BlindDamageType, 1] = "%2's eye's were dissolved by %1.";
$deathMsg[$BlindDamageType, 2] = "%2 got his eye's removed by %1.";
$deathMsg[$BlindDamageType, 3] = "%2 never saw it coming from %1.";
$deathMsg[$BlindDamageType, 4] = "%2 gets flashed by %1.";

//---------------------------------------------------------------------------------
//	FLASH
//---------------------------------------------------------------------------------
$deathMsg[$FlashDamageType, 0] = "%1 blows %2 up real good.";
$deathMsg[$FlashDamageType, 1] = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$FlashDamageType, 2] = "%1 gives %2 a fatal concussion.";
$deathMsg[$FlashDamageType, 3] = "%2 never saw it coming from %1.";
$deathMsg[$FlashDamageType, 4] = "%2 gets flashed by %1.";

//---------------------------------------------------------------------------------
//	POISON
//---------------------------------------------------------------------------------
$deathMsg[$PoisonDamageType, 0] = "%2 dies of poison.";
$deathMsg[$PoisonDamageType, 1] = "%2 gets a lethal injection.";
$deathMsg[$PoisonDamageType, 2] = "%2 falls victim to a deadly virus.";
$deathMsg[$PoisonDamageType, 3] = "%2 could not find the vaccine in time.";
$deathMsg[$PoisonDamageType, 4] = "%2 gasps %3 last breath.";

//---------------------------------------------------------------------------------
//	LANDING
//---------------------------------------------------------------------------------
$deathMsg[$LandingDamageType, 0] = "%2 crippled %4 Landing Gear.";
$deathMsg[$LandingDamageType, 1] = "%2 dives face first into the gravel.";
$deathMsg[$LandingDamageType, 2] = "%2 needs a spatuala after that fall.";
$deathMsg[$LandingDamageType, 3] = "%2 got %4 head put up %4 ass.";

//---------------------------------------------------------------------------------
//	IMPACT
//---------------------------------------------------------------------------------
$deathMsg[$ImpactDamageType, 0] = "%2 is nothing more than a new smear on %1's windshield.";
$deathMsg[$ImpactDamageType, 1] = "%2 get's grinded into the gravel by %1's vehicle.";
$deathMsg[$ImpactDamageType, 2] = "%2 leaves a nasty scratch on %1's fender.";
$deathMsg[$ImpactDamageType, 3] = "%1 takes %2's head off with his wing.";

//---------------------------------------------------------------------------------
//	BULLET
//---------------------------------------------------------------------------------
$deathMsg[$ShotgunDamageType, 0] = "%1 blows %2 away.";
$deathMsg[$ShotgunDamageType, 1] = "%1 gives %2 an overdose of lead.";
$deathMsg[$ShotgunDamageType, 2] = "%1 fills %2 full of holes.";
$deathMsg[$ShotgunDamageType, 3] = "%1 blows right through %2.";

//---------------------------------------------------------------------------------
//	ENERGY
//---------------------------------------------------------------------------------
$deathMsg[$EnergyDamageType, 0] = "%2 dies of turret trauma.";
$deathMsg[$EnergyDamageType, 1] = "%2 is chewed to pieces by a turret.";
$deathMsg[$EnergyDamageType, 2] = "%2 walks into a stream of turret fire.";
$deathMsg[$EnergyDamageType, 3] = "%2 ends up on the wrong side of a turret.";

//---------------------------------------------------------------------------------
//	PLASMA
//---------------------------------------------------------------------------------
$deathMsg[$PlasmaDamageType, 0] = "%2 feels the warm glow of %1's plasma.";
$deathMsg[$PlasmaDamageType, 1] = "%1 gives %2 a white-hot plasma injection.";
$deathMsg[$PlasmaDamageType, 2] = "%1 asks %2, 'Got plasma?'";
$deathMsg[$PlasmaDamageType, 3] = "%1 gives %2 a plasma transfusion.";

//---------------------------------------------------------------------------------
//	EXPLOSIVE
//---------------------------------------------------------------------------------
$deathMsg[$ExplosionDamageType, 0] = "%2 catches a Frisbee of Death thrown by %1.";
$deathMsg[$ExplosionDamageType, 1] = "%1 blasts %2 with a well-placed disc.";
$deathMsg[$ExplosionDamageType, 2] = "%1's spinfusor caught %2 by surprise.";
$deathMsg[$ExplosionDamageType, 3] = "%2 falls victim to %1's Stormhammer.";

//---------------------------------------------------------------------------------
//	SHRAPNEL
//---------------------------------------------------------------------------------
$deathMsg[$ShrapnelDamageType, 0] = "%1 blows %2 up real good.";
$deathMsg[$ShrapnelDamageType, 1] = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$ShrapnelDamageType, 2] = "%1 gives %2 a fatal concussion.";
$deathMsg[$ShrapnelDamageType, 3] = "%2 never saw it coming from %1.";

//---------------------------------------------------------------------------------
//	LASER
//---------------------------------------------------------------------------------
$deathMsg[$LaserDamageType, 0] = "%1 adds %2 to %3 list of sniper victims.";
$deathMsg[$LaserDamageType, 1] = "%1 fells %2 with a sniper shot.";
$deathMsg[$LaserDamageType, 2] = "%2 becomes a victim of %1's laser rifle.";
$deathMsg[$LaserDamageType, 3] = "%2 stayed in %1's crosshairs for too long.";

//---------------------------------------------------------------------------------
//	MORTAR
//---------------------------------------------------------------------------------
$deathMsg[$MortarDamageType, 0] = "%1 mortars %2 into oblivion.";
$deathMsg[$MortarDamageType, 1] = "%2 didn't see that last mortar from %1.";
$deathMsg[$MortarDamageType, 2] = "%1 inflicts a mortal mortar wound on %2.";
$deathMsg[$MortarDamageType, 3] = "%1's mortar takes out %2.";

//---------------------------------------------------------------------------------
//	BLASTER
//---------------------------------------------------------------------------------
$deathMsg[$BlasterDamageType, 0] = "%2 gets a blast out of %1.";
$deathMsg[$BlasterDamageType, 1] = "%2 succumbs to %1's rain of blaster fire.";
$deathMsg[$BlasterDamageType, 2] = "%1's puny blaster shows %2 a new world of pain.";
$deathMsg[$BlasterDamageType, 3] = "%2 meets %1's master blaster.";

//---------------------------------------------------------------------------------
//	ELECTRICITY
//---------------------------------------------------------------------------------
$deathMsg[$ElectricityDamageType, 0] = "%2 gets zapped with %1's ELF gun.";
$deathMsg[$ElectricityDamageType, 1] = "%1 gives %2 a nasty jolt.";
$deathMsg[$ElectricityDamageType, 2] = "%2 gets a real shock out of meeting %1.";
$deathMsg[$ElectricityDamageType, 3] = "%1 short-circuits %2's systems.";

//---------------------------------------------------------------------------------
//	CRUSH
//---------------------------------------------------------------------------------
$deathMsg[$CrushDamageType, 0] = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 1] = "%2 is crushed.";
$deathMsg[$CrushDamageType, 2] = "%2 gets smushed flat.";
$deathMsg[$CrushDamageType, 3] = "%2 gets caught in the machinery.";

//---------------------------------------------------------------------------------
//	DEBRIS
//---------------------------------------------------------------------------------
$deathMsg[$DebrisDamageType, 0] = "%2 is a victim among the wreckage.";
$deathMsg[$DebrisDamageType, 1] = "%2 is killed by debris.";
$deathMsg[$DebrisDamageType, 2] = "%2 becomes a victim of collateral damage.";
$deathMsg[$DebrisDamageType, 3] = "%2 got too close to the exploding stuff.";

//---------------------------------------------------------------------------------
//	MISSILE
//---------------------------------------------------------------------------------
$deathMsg[$MissileDamageType, 0] = "%2 takes a missile up the keister.";
$deathMsg[$MissileDamageType, 1] = "%2 gets shot down.";
$deathMsg[$MissileDamageType, 2] = "%2 gets real friendly with a rocket.";
$deathMsg[$MissileDamageType, 3] = "%2 feels the burn from a warhead.";

//---------------------------------------------------------------------------------
//	MINE
//---------------------------------------------------------------------------------
$deathMsg[$MineDamageType, 0] = "%1 blows %2 up real good.";
$deathMsg[$MineDamageType, 1] = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$MineDamageType, 2] = "%1 gives %2 a fatal concussion.";
$deathMsg[$MineDamageType, 3] = "%2 never saw it coming from %1.";

//---------------------------------------------------------------------------------
//	SUICIDE
//---------------------------------------------------------------------------------
//   %1 = player name,  %2 = player gender pronoun

$deathMsg[-2,0] = "%1 kicks %2 own ass.";
$deathMsg[-2,1] = "%1 takes %2 own life.";
$deathMsg[-2,2] = "%1 kills %2 own dumb self.";
$deathMsg[-2,3] = "%1 decides to see what the afterlife is like.";

$numDeathMsgs = 4;