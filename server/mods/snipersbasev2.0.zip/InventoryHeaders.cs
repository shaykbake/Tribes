$InvHead[ihVeh] = "aVehicle";
$InvHead[ihArm] = "aArmor";
$InvHead[ihWea] = "bWeapons";
$InvHead[ihMwe] = "cMisc. Weapons";
$InvHead[ihMis] = "dMiscellany";
$InvHead[ihBac] = "eBackpacks";
$InvHead[ihDes] = "fDeployable Sensors";
$InvHead[ihDet] = "gDeployable Turrets";
$InvHead[ihDem] = "hDeployable Misc.";
$InvHead[ihDep] = "iDeployable Platforms";
$InvHead[ihJad] = "jJail Deployables";
$InvHead[ihAmm] = "xAmmunition";

