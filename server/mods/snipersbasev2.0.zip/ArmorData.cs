//------------------------------------------------------------------
//
//	ARMOR EXECUTABLE
//
//------------------------------------------------------------------
$DefaultArmor[Male] = DMmale;
$DefaultArmor[Female] = DMfemale;
exec(player);
exec(Armor_Light);
exec(Armor_Medium);
exec(Armor_Flight);
exec(Armor_Engineer);
exec(Armor_DM);
exec(Armor_Penis);