# Damage Types
#
$ImpactDamageType		  = -1;
$LandingDamageType	  =  0;
$BulletDamageType      =  1;
$EnergyDamageType      =  2;
$PlasmaDamageType      =  3;
$ExplosionDamageType   =  4;
$ShrapnelDamageType    =  5;
$LaserDamageType       =  6;
$MortarDamageType      =  7;
$BlasterDamageType     =  8;
$ElectricityDamageType =  9;
$CrushDamageType       = 10;
$DebrisDamageType      = 11;
$MissileDamageType     = 12;
$MineDamageType        = 13;

//--------------------------------------
BulletData PaintSplat
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = PaintSplatExp;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 3.5;
   damageType         = $Paintball;
   explosionRadius    = 3.0;

   aimDeflection      = 3.003;
   muzzleVelocity     = 40.0;
   totalTime          = 1.0;
   inheritedVelocityScale = 1.0;
   isVisible          = True;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData PaintSplat2
{
   bulletShapeName    = "enbolt.dts";
   explosionTag       = PaintSplatExp;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 3.5;
   damageType         = $Paintball;
   explosionRadius    = 3.0;

   aimDeflection      = 3.003;
   muzzleVelocity     = 40.0;
   totalTime          = 1.0;
   inheritedVelocityScale = 1.0;
   isVisible          = True;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData ChaingunBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.11;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.005;
   muzzleVelocity     = 425.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//--------------------------------------
BulletData FusionBolt
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.25;
   damageType         = $EnergyDamageType;

   muzzleVelocity     = 50.0;
   totalTime          = 6.0;
   liveTime           = 4.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

//--------------------------------------
BulletData MiniFusionBolt
{
   bulletShapeName    = "enbolt.dts";
   explosionTag       = energyExp;

   damageClass        = 0;
   damageValue        = 0.1;
   damageType         = $EnergyDamageType;

   muzzleVelocity     = 80.0;
   totalTime          = 4.0;
   liveTime           = 2.0;

   lightRange         = 3.0;
   lightColor         = { 0.25, 0.25, 1.0 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

//--------------------------------------
BulletData BlasterBolt
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = blasterExp;

   damageClass        = 0;
   damageValue        = 0.125;
   damageType         = $BlasterDamageType;

   muzzleVelocity     = 200.0;
   totalTime          = 2.0;
   liveTime           = 1.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

//--------------------------------------
BulletData PlasmaBolt
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.45;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 55.0;
   totalTime          = 3.0;
   liveTime           = 2.0;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

//--------------------------------------
RocketData DiscShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 15;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

//--------------------------------------
GrenadeData GrenadeShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 150;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 1.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "smoke.dts";
};

//--------------------------------------
GrenadeData MortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//--------------------------------------
GrenadeData MortarTurretShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 400;
   collisionRadius    = 1.0;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.32;
   damageType         = $MortarDamageType;

   explosionRadius    = 30.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 400;
   totalTime          = 1000.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//--------------------------------------
RocketData FlierRocket
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 250.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;

   soundId = SoundJetHeavy;
};

//--------------------------------------
SeekingMissileData TurretMissile
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;
   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;
   explosionRadius  = 9.5;
   kickBackStrength = 175.0;

   muzzleVelocity    = 72.0;
   totalTime         = 10;
   liveTime          = 10;
   seekingTurningRadius    = 9;
   nonSeekingTurningRadius = 75.0;
   proximityDist     = 1.5;
   smokeDist         = 1.75;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   soundId = SoundJetHeavy;
};

function SeekingMissile::updateTargetPercentage(%target)
{
   return GameBase::virtual(%target, "getHeatFactor");
}

//-------------------------------------- 
// These are kinda oddball dat's
// the lasers really don't fit into
// the typical projectile catagories...
//--------------------------------------
LaserData sniperLaser
{
   laserBitmapName   = "laserPulse.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.007;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

TargetLaserData targetLaser
{
   laserBitmapName   = "paintPulse.bmp";

   damageConversion  = 0.0;
   baseDamageType    = 0;

   lightRange        = 2.0;
   lightColor        = { 0.25, 1.0, 0.25 };

   detachFromShooter = false;
};

LightningData lightningCharge
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageType;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.06;
   energyDrainPerSec = 60.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;//075;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

LightningData turretCharge
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageType;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.06;
   energyDrainPerSec = 60.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

function Lightning::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
   %damVal = %timeSlice * %damPerSec;
   %enVal  = %timeSlice * %enDrainPerSec;

   GameBase::applyDamage(%target, $ElectricityDamageType, %damVal, %pos, %vec, %mom, %shooterId);

   %energy = GameBase::getEnergy(%target);
   %energy = %energy - %enVal;
   if (%energy < 0) {
      %energy = 0;
   }
   GameBase::setEnergy(%target, %energy);
}

RepairEffectData RepairBolt
{
   bitmapName       = "repairadd.bmp";
   boltLength       = 5.0;
   segmentDivisions = 4;
   beamWidth        = 0.125;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.85, 0.25, 0.25 };
};

function RepairBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (%target == %player) {
	   %player.repairTarget = -1;
		if (GameBase::getDamageLevel(%player) != 0) {
			%player.repairRate = 0.05;
			%player.repairTarget = %player;
			Client::sendMessage(%client, 0, "AutoRepair On");
		}
		else {
			Client::sendMessage(%client,0,"Nothing in range");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}
	}
	else {
      %player.repairTarget = %target;
		%player.repairRate   = 0.1;
		if (getObjectType(%player.repairTarget) == "Player") {
			%rclient = Player::getClient(%player.repairTarget);
			%name = Client::getName(%rclient);
		}
		else { 
			%name = GameBase::getMapName(%target);
			if(%name == "") {
				%name = (GameBase::getDataName(%player.repairTarget)).description;
			}
		}
		if (GameBase::getDamageLevel(%player.repairTarget) == 0) {
			Client::sendMessage(%client,0,%name @ " is not damaged");
			Player::trigger(%player,$WeaponSlot,false);
			%player.repairTarget = -1;
			return;
		}
		if (getObjectType(%player.repairTarget) == "Player") {
			Client::sendMessage(%rclient,0,"Being repaired by " @ Client::getName(%client));
		}
		Client::sendMessage(%client,0,"Repairing " @ %name);
	}
	%rate = GameBase::getAutoRepairRate(%player.repairTarget) + %player.repairRate;
	GameBase::setAutoRepairRate(%player.repairTarget,%rate);
}

function RepairBolt::onRelease(%this, %player)
{
	%object = %player.repairTarget;
	if (%object != -1) {
		%client = Player::getClient(%player);
		if (%object == %player) {
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Client::sendMessage(%client,0,"Repair Done");
			}
			else {
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
      if (%rate < 0)
         %rate = 0;
      
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

function RepairBolt::checkDone(%this, %player)
{
	if (Player::isTriggered(%player,$WeaponSlot) && 
       Player::getMountedItem(%player,$WeaponSlot) == RepairGun &&
		 %player.repairTarget != -1) {
		%object = %player.repairTarget;
		if (%object == %player) {
			if (GameBase::getDamageLevel(%player) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
		else {
			if (GameBase::getDamageLevel(%object) == 0) {
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
	}
}
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE1paap2aa/























































7::::::::::::::::::::::::::::::::::::,RRRRRRRRRRRRRRRRRRRRRRRRPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPf																											)222222222222222222222222222222222222222222222EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEppppppppppppppppppaaipcccccccccccccccccccccccccccai1111111111111111122222222222222222222222222222f	pddddddddddai1bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbccccccccccccccccccaiiiiiiiiiiiipcddddddddddddddddddaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii���������������������������������^���������������~�|�����������������������������������������������������������������������������������������������������������������������`_�]\[ZYX��U���Q�+����K��������丳?>ڶ�������������������������������������������������������������������������������������������������������� ����������񲷼�������������jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ*<q!3HVAN////////////////////C=====================================6OFDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR$;9999999999999999999999999999999999999999


































2gggggggggggggggggggggggggggggggggggg7777777777777777777777:111111111111111111111111111,,,,,,,,,,,,,,,,,,,,,,,,PEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEfccccccccccccccccccccccccccccccc	aiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii)bppppppppppppppppppppppppppaiddcccccccccccccccccccccccccccccccccccccccccccccccccaiipppppppppppppppppppppppppaaggggggggggggggggggggggggggggggg1222222222222222222dSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSfipccccccccccccccccccccccccccccccccccaiiiiiiiiiiiiiii																								ppppppppppppppppppppaibddddddddddddddddddddddddddddddddaiccn4"BCCCCCCCCCCCCCCCCCCCCCCCCCk/FFFFFFFFFFFFFFFFFFFF=========================================================TDR





























55555555555555555555555555555555555555555555555557:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::,PEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE02gS111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111pppppppppppbfffffffffffffffffffffffffaiidddddddddddddddddddddddddaacccccccccccnidppppppppppppppppppppppppppppppppppai																								)))))))))))))))))))))))))))))))02bS1ggggggggggggggggggggggggggggggggggggggggggdccccccccccai																													nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnaippooooooooooosdcfffffffffffffffffffffffffaiiiiiiinnnnnnnnnnnnnnnnnnnnnnnnnaaaaaaaaaaaaaaavMLyyyyyyyyyyyyyu$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG%xW3HVAN6kkkkkkkkkkkkkkkk9OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO;4"BCDDDDDDDDDDDDDDDDDDDDDDDDD/FFFFFFFFFFFFFFFFFFFF===========================================================================================TR





























5555555555555555555555555555555555555555555555555P7::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::0hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh,)E11111111111111111111111111111112b	Sggggggggggggggggggo spccccccccccciiiiiinddddddddddddddddddddddddddddddddddaiiiiiiffffffffffffffffffffffffffffffffffffffesoc nppppppppppaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeaiiiiiiiiiiiidddddddddddddd00000000000000mu1h2222222222222222222																															gbfSsoc npppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeaaaaaaaiiod spccccccccccccccccccccccnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeB.vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvkkkkkkkkkkkkkkkkLy4"MMMMMMMMMMMMMMMMMMMMMMMMMMMMDDDDDDDDDDDDDDDDDDDDDDDDD/FFFFFFFFFFFFFFFFFFFF=CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCTR





























555555555555555555555000000000000000000000000000000000000P71):}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}	muuuuuuuuuuuuuuf2222222222222222222,hooooooooooooooooooooooooooooooog                             bpdddddddddddsaiiiiiiiiiiiiiiiiiiiiiiiiiiScccccccceeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneep           ooooooooooooooooooddddddddddddddddddaiiiiiiiiiiiinssssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiccrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrl1	0uuuuuuuuuuuuufmEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE22222222222222222222222222222hhhhhhhhhhhhhhhgp           oooooooooooooooooobdnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiisssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiirlc                                                             opdddddddddddddddddsSSSSSSSSeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa&'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++z{#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@w9I8-((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((*Jqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj<$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx3%VWNHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO.vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvkBTy4"MMMMMMMMMMMMMMMMMMMMMMMMMMMMDL7FFFFFFFFFFFFFFFFFFFF=CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC///////////////////





























55555555555555555555555555555555555555555555555555555555PRu))))))))))))))))))))))}!;;;;;;;;;;;;;;;;;;;;;;;;:EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE	011111111111111111111111111111fmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm22222222222222lhhhhhhhhhhhhhhh rocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiSggggggggeeeeeeeeeeeeeeeeeeeeeeeeeee oldrscnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnaiiiiiiiiiiiibppppppppeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiee0uuuuuuuuuuuu,m	111111111111111111111111111112ffffffffffffffffffffffffffffffSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSShotd slnrbbbbbbbbbbbbbbbccccccccccccccccccccccaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiippotd slnrgcccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.vCkBTy4"""""""""""""""""""""""""""""""""""""""""""""""""""""""""DL7FFFFFFFFFFFFFFFFFFFF============================///////////////////





























55555555555555555555555555555555555555)PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR10uEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEm	,::::::::::::::2fffffffffffffffffffffffffffffppppppppppppppppppStbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb oldrscnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnghhhhhhhheeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeee	10ufffffffffffffmmmmmmmmmmmmbbbbbbbbbbbbbb2222222222222222222222222222222222                                              lgSrtcpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppoooooooooooddddddddddaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiisssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneerlc                                                             tttttttttttphooooooooooooooooooooooaiiiiiiiiiiiindddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiss33333333333333333333333333333333333333333333333333333333339I8-----------------------------------------$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx(((((((((((((((((((((((NVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVW%H...............................................A6OMBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"CkvLy4T=====================DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD/FFFFFFFFFFFFFFFFFFFF75















































E)PPPPPPPPPPPPPPPPPPPPPPPPPPP	RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR0,,,,,,,,,,,,,,,,,,,,,,f1mubbbbbbbbbbbbb22222222222222222222222222222222222222222222222222222ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggrlc                                                             tttttttttttphSonnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiils rtcpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppoooooooooooooooooddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaab0	fffffffffffffffffffffffffffffmu111111111111111222222222222222222222222llllllllllllllg h:tsprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeet plosdrnccccccccccaiiiiiiiiiiiiSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiee44444444444444444444444.MBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"CkvLyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy=====================DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD/FT,5;
7	PER)))))))))))))))))))))))))))))))))))))))))))))ub000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000mfhhhhhhhhhhhhhhh21ttttttttttttttttttttttttttpppppppppppppppppppppppppppppppgo dlnsS::::::::::::::::::::::rrrrrrrrrrrrrrrrrrrrrraiiiiiiiiiiiiiiiiiiiiiiccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiipto dlnssssssssssssssssssrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiimub02222222222222222222222222222222222222222																															hhhhhhhhhhhhhhhfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1111111111111tSSSSSSSSSSSSSS plosdrnnnnnnnccccccccccccccccccggggggggeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllsprocdiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeee�ٯ�������������������������������^���������������~�|�����������������������������������������������������������耀����������������������������������������������������������������������������������������������������������_�]`[�Y\�ZUX��Q�����K����������?�ڳ�>�� �������8�������������������'�&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++z{#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@w*Jqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj<}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}9I3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GNxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx(%V-WyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyHA66666666666666666666666.MB4FFFFFFFFFFFFFFFFFFFF"CkvLLLLLLLLLLLLLLLL





























=====================DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD//////////////////////////////////////////////////////////,5;OTbRPPPPPPPPPPPPPPPPPPPE7)))))))))))))))))))))))))))))mu:::::::::::::::::::::::::::::::::::::::::2222222222220SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSh	 f1llllllllllllllllllllllllllllllstrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrcpppppppppppooooooooooaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiddddddddeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeslr ctttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttgppppppppppppppppppppppaiiiiiiiiiiiinoooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiidduuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuummmmmmmmmmmmbS2h0ffffffffffffffffffffffffffffffffffffffffffffffff																						1slr ctttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttgggggggggggggpnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiild strrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrcpppppppppppppppppoooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaaLLLLLLLLLLLLLLLLLyyyyyyyyyyyyyyyyyyyyyyy.MB/FFFFFFFFFFFFFFFFFFFF"Ckv44444444444444444444444444444444444444444444444444444444





























=====================DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD::::::::::::::::::::::::::::::::::,5R7PTESuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu)ffffffffffffbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmh02llllllllllllllllllllllllllllllllllllllllllllllll g	tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsprociiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiii11111111eeeeeeeeeeeeeeeeeeeeeeeeeeet                                                             lpdosnrrrrrrrrrraiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieebSuuuuuuuuuuuuuuuuuuuuuuuuuuuuu0ffffffffffffffffffffffffffgggggggggggggggggggggggggggggggggggghmt2222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222p olnddddddddddddd	ssssssssssssssssssssssaiiiiiiiiiiiiiiiiiiiiiirrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiicccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccctp olnd1sssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiirrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii8!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!9IMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$G%x-(3Vv;WHAAAAAAAAAAAAAAAAAyyyyyyyyyyyyyyyyyyyyyyy.LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL/FFFFFFFFFFFFFFFFFFFF"CkBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB6





























=====================D444444444444444444444444::::::::::::::::::::::::::::::::::,5u7777777777777777777TRRRRRRRRRRRRRRRRRRRRRRRRRPPPPPPPPPPPPbSSSSSSSSSSSSSSSSSSSSSSEh0ffffffffffffffffffffffffffffffffffffffffffgggggggggggggggggggggggggggggggggggg)))))))))))))))cm2ttttttttttttttttttttttttttttttttttttttttttt                                                             lpdosnnnnnnnr1111111111111111111111111eeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlcdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsproiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiii								eeeeeeeeeeeeeeeeeeeeeeeeeeeffffffffffffbSSSSSSSSSSSSSSSSSSSSSSSSSSSh0uuuuuuuuuuuuuuuuuuuuuuuuuuggggggggggggggggggggggggggggg               ml12dtscrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrppppppppppaiiiiiiiiiiii																															ooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneedls rtttttttttttcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccaiiiiiiiiiiiinpppppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiioo.MvFyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyykkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk/L
"CCCCCCCCCCCCCCCCCCCCDDDDDDDDDDDDDDDDDDDDDDDDDDDDOBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB===========================================================================================================:4T5,,,,,,,,,,,,,,,,,,,,,,7777777777777777777777777777777777fRRRRRRRRRRRRRRRRRRRRRRRRRbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbPPPPPPPPPPPPPPPPPPPPPPPPPPPEEEEEEEEEEEE0SSSSSSSSSSSSShguuuuuuuuuuuuuuuuuuuuuuuuuuuu11111111111111111111111111111	mdls rtttttttttttcccccccccccccccccc2222222222222222222222222222222222222222222222222222222222222nnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiippppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilo dtscrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaaaaabf)))))))))))))))0SSSSSSSSSSSS	guhllllllllllllll1                                              tocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspriiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiimmmmmmmmeeeeeeeeeeeeeeeeeeeeeeeeeeet clllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllopdnssssssssssaiiiiiiiiiiii2rrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiee999999999999999999999999999999999999999999999999999999999999''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&;#++++++++++++++++++++++++++++++++++++++++++++++++zw{@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ<*qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq8!jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN%$-G3xI(CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCVWHMvFy.....................kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk/L
"""""""""""""""""DDDDDDDDDDDDDDDDDDDDDDDDDDDDOABBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB================================================================================================================:4T555555555555555555555555555555ffffffffffffffffffffffffffffffffffffffffR7,,,,,,,,,,,,,,,,SSSSSSSSSSSSSbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbuuuuuuuuuuuuuuu0)PPPPPPPPPPPPPPPPPP	ggggggggggggthhhhhhhhhhhhhhccccccccccccccccccccccccccccccc1111111111111111111111111111111111111111111111111111111111111 plno22222222222222222222222222222ddddddddddddddddddddddaiiiiiiiiiiiiiiiiiiiiiissssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiirrcttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt plnomddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiisssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiii0SSSSSSSSSSSSSbguuuuuuuuuuuuuuuffffffffffffffffffffffffffffffffffffffffffffffff	Errrrrrrrrrrrht22222222222222 clllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllopdnnnnnnnsm11111111eeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlrocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeee"""""""""""""""""""""""CMvFy=====================kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk/L
.5DDDDDDDDDDDDDDDDDDDDDDDDDDDD6BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB:4TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTRRRRRRRRRRRRRRRRRRR,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,7777777777777770S))))))))))))))))	gub222222222222222222222222222222222222222222222222f EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEElmhotdrsccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiippppppppeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeold stttttttttttr1ccccccccccccccccccccccaiiiiiiiiiiiinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiippSSSSSSSSSSSSSSS	0uuuuuuuuuuuuu2ggggggggggggggggggbPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPmffffffffffffffffffffffffffffffffffffffffold stttttttttttr1hcnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilp otdrsccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa9;8}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}FNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-----------------------------------------3$IGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGx
O(VWWWWWWWWWWWWWWWWWWWWWWWCMv""""""""""""""""""""""""""""""""""=====================kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk/LyT5DDDDDDDDDDDDDDDDDDDDDDDDDDDD6HB.))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))):44444444444444444	,RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR2SSSSSSSSSSSSSSSE7PPPPPPPPPPPPPPPPuuuuuuuuuuuuu0000000000000000000000000000000000000000000000bglllllllllllllllllllllllllllllllm 1ftprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeet rlcppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppponddddddddddaiiiiiiiiiiiihsssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeee2SSSSSSSSSSSSSSSbbbbbbbbbbbbbbbbbbbbbbbbbu	11111111111111111111111111111111111111111111110tgggggggggggggggggggggggggggggggrrrrrrrrrrrrrrmc                                                             lnphfooooooooooooooooooooooaiiiiiiiiiiiiiiiiiiiiiidddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiissrtc                                                             lnppppppppppppooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiLF






















CMvBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=====================kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk/"4T5DDDDDDDDDDDDDDDDDDDDDDDDDDDDAyE))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))):.SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS,,,,,,,,,,,,,,,,,,,,RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRuuuuuuuuuuuuu2PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPbbbbbbbbbbbbbbbbbbbbbbbbb777777777777777777777777777711111111111111111111111111111	s0gthhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh rlcppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppponnnnnnnddddddddddddmmmmmmmmeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlsprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiffffffffeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuu2222222222222222222222222222222222222222222222bShhhhhhhhhhhhhh111111111111111 	0llllllllllllgptosdrrrrrrrrrrrccccccccccaiiiiiiiiiiiiffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeplo dtttttttttttsmrrrrrrrrrrrrrrrrrrrrrraiiiiiiiiiiiinccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii��ٯ�������������������������������^���������������~�|����������������������������������������������������������ؑ����������������������������������������������������������_�]`[�Y\�ZUX��QĀ���K����������?�ڳ�>�� ��������#�����ƾ��º�������<�������������������������������������������������������������''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww@zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz{JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ+++++++++++++++++++++++++++++++++++++++++++++-!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*q9;8}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}ONNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%FI3333333333333333333333333333333333333333$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GM6x(VL=======================C
/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBv5kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkAW4T"""""""""""""""""""""""""""DDDDDDDDDDDDDDDDDDDDDDDDDDDD:E)yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP,..................................................RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRub2hhhhhhhhhhhhhhhhhh1S																																							f0plo dtttttttttttsmgrnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll ptosdrrrrrrrrrrrrrrrrrcccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaahhhhhhhhhhhhh77777777777777777777777777777	b2uf1SSSSSSSSSSSSSSSSSSlllllllllllllllllllllllll mmmmmmmmmmmmmmmtttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttsprocdiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii00000000eeeeeeeeeeeeeeeeeeeeeeeeeeet slrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrcpnooooooooooaiiiiiiiiiiiigddddddddeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeFML=======================CCCCCCCCCCCCCCCCCCCCCCCCCCCC/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBv5k























H4T"""""""""""""""""""""""""""DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD:E)yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy7PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP,...................................................................2hhhhhhhhhhhhhRRRRRRRRRRRRRRRRRRRRRRS	bbbbbbbbbbbbbbbbbbbbbbbbbbbbbmf1utttttttttttttttttttttttttttttttssssssssssssssssssssssssssssssssssssssssssr clnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnngggggggggggggggppppppppppppppppppppppaiiiiiiiiiiiiiiiiiiiiiioooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiddstr clnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn0ppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiib2hhhhhhhhhhhhh1S																																																							mfffffffffffffffffffffffffffffduuuuuuuuuuuuuuuuuutgggggggggggggg slrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrcpnnnnnnno0000000000000000000eeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsprociiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeee666666666666666666666666666666666-9;8jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOONNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%33333333333333333333333333333333333333333333333333333333$kAGx(FML=====================================DDDDDDDDDDDDDDDDDDDDDDDDDDDD/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBv5CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCHV4T"""""""""""""""""""""""""""


































:E)yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh7.P,	b2RRRRRRRRRRRRRRRRf1SSSSSSSSSSSSSgggggggggggggggggggggggggggggggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm                             ul000000000000000000000000000000000000000000000000000000000000000000000000000000tpdosssssssssssrrrrrrrrrraiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeelp otttttttttttddddddddddddssssssssssssssssssssssaiiiiiiiiiiiinrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiicc2	fbShg1mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm000000000000000000000000000000000000uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuulp otttttttttttdddddddddddddddddddddddddddddsnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiirrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilc                                                             tpdosssssssssssssssssrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaa55555555555555555555555kFML===========================DDDDDDDDDDDDDDDDDDDDDDDDDDDD/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvW4T"CRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR:E)y
f..............................777777777777777777777Pg2																									,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Shbbbbbbbbbbbbbbbmmmmmmmmmmmmm1lllllllllllllllllllllllllllllll0                                                tcdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsproiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiuuuuuuuueeeeeeeeeeeeeeeeeeeeeeeeeeet dlscrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnppppppppppaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieehg2																																									Sffffffffffffffffffffffffffmbt1111111111111111111111111111111dddddddddddddd0s rlnccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccaiiiiiiiiiiiiiiiiiiiiiipppppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiioodts rlncuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuueeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiippppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiii8'<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&A@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#wzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{J!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}*********************************-9;6LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLOINNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%jq3vH$GxxxxxxxxxxxxxxxxxxxxxxxkFM5"""""""""""""""""""""""""""DDDDDDDDDDDDDDDDDDDDDDDDDDDD/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyW(4TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR:E)C2..................................................
7ShggggggggggggggggggggggPmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm																																							fob1tttttttttttttttttttttttttttttttttttttttttttttttt dlscrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnnnnnnnpu00000000eeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspriiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii,,,,,,,,eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeShgggggggggggggggmmmmmmmmmmmmm222222222222222222222222222222222222222222	 fblu1ctttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttopdddddddddddssssssssssaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiirrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeclllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll pttttttttttto0ddddddddddddddddddddddaiiiiiiiiiiiinssssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiirrMLvDkFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"""""""""""""""""""""""""""55555555555555555555555555555555555/BBBBBBBBBBBBBBBBBBBBBBBBBBBBTyyyyyyyyyyyyyyyyyyyy=================V444444444444444444444444)))))))))))))))))))))))))RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR:EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE.CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh777777777777777SSSSSSSSSSSSSggggggggggggggggggmmmmmmmmmmmm2ffffffffffffffu																Pbclllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll pttttttttttto01dnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiisssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilr ctttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttopdddddddddddddddddsssssssssssssssssssssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaaaaaaaaaahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhfffffffffffffgS,,,,,,,,,,,,2mllllllllllllllu 0	trocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiibbbbbbbbeeeeeeeeeeeeeeeeeeeeeeeeeeet oldrscnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnaiiiiiiiiiiii1ppppppppeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeH8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA-9;FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOONNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN%66666666666666666666666666BW3$GLvDkM4444444444444444444444444444444444"""""""""""""""""""""""""""55555555555555555555555555555555555///////////////////////ETyyyyyyyyyyyyyyyyyyyy=================Vxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)))))))))))))))))))))))))RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR::::::::::::::::::::::::::::::::::::::::::::::::::::...................................................Cgggggggggggggggggghhhhhhhhhhhhhhhh
2fffffffffffffffffffffffffff0,777777777777Stmmmmmmmmmmmmmmoooooooooooooooooooooooooooooooud slnr1	ccccccccccccccccccccccaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiippotd slnrbcccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiigggggggggggggggggghhhhhhhhhhhh2fffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0PPPPPPPPPPPPPPPpSmt11111111111111 oldrscnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnbuuuuuuuueeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiii								eeeeeeeeeeeeeeeeeeeeeeeeeee/FBLvDk(4444444444444444444444444444444444"""""""""""""""""""""""""""55555555555555555555555555555555555M:ETyyyyyyyyyyyyyyyyyyyy=========================================================================================)))))))))))))))))))))))))RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR...............................................................fffffffffffffg,CP











2h111111111111111111111111111111100000000000000000000000000000               Slbmrtcpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppoooooooooooddddddddddaiiiiiiiiiiii														sssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneerlc                                                             tttttttttttpuooooooooooooooooooooooaiiiiiiiiiiiindddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiissgf77777777777772222222222222222221111111111110hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhbbbbbbbbbbbbbbbbbbbbbbbbbbbbb	Srlc                                                             tttttttttttpumonnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiils rtcpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppooooooooooooooooodddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaa���ٯ�������������������������������^���������������~�|���������������������������������������������������������绒@�����������������������������������������������������������`_�]\[ZYX��U���Q݀���K��������丳?>ڶ���� �ő�9���������ƺ��������'&<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<������������������������������������������������������W###########################################wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwz!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJj+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA-HDIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO*N666666666666666666666666666666666666666;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%VVVVVVVVVVVVVVVVVVVVVVVVVV3$FBLv/////////////////(G4444444444444444444444444444444444"""""""""""""""""""""""""""5kkkkkkkkkkkkkkkkkkkkk:ETyyyyyyyyyyyyyyyyyyyy=M,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,)))))))))))))))))))))))))RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR777777777777777777777777777777...............................................................1gfCPPPPPPPPPPPPPPP222222222222222222222222222222	0hhhhhhhhhhhhlllllllllllllllllllllllllllllllb uuuuuuuuuuuuuuuuuuuuuuuuuuuuutsprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiSSSSSSSSeeeeeeeeeeeeeeeeeeeeeeeeeeet plosdrnccccccccccaiiiiiiiiiiiimmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeee1gfhhhhhhhhhhhhhhh2
u	0000000000000ttttttttttttttttttttttttttttttttttttttttttppppppppppppppbo dlnsmmmmmmmmmmmmmmmmmmmmmmmmmmmmmrrrrrrrrrrrrrrrrrrrrrraiiiiiiiiiiiiiiiiiiiiiiccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiipto dlnsSrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiii5DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDFBLv=================x4444444444444444444444444444444444"""""""""""""""""""""""""""/////////////////////////////////////////////////////////:ETyyyyyyyyyyyyyyyyyyyyk,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,)))))))))))))))))))))))))RMg.77777777777777777777777777777777777777777777777777777777777777777777777777777777777777777772222222222222222221CCCCCCCCCCCCCCCCCCCCCCCC0hhhhhhhhhhhhhhhffffffffffffffu	














































































































tmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm plosdrnnnnnnncSbbbbbbbbeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllsprocdiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee2222222222222222221	0hgmmmmmmmmmmmmmmuf PPPPPPPPPPPPPlSSSSSSSSSSSSstrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrcpppppppppppooooooooooaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiddddddddeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeslr ctttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttbppppppppppppppppppppppaiiiiiiiiiiiinoooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiddddddddddddddddddddddddddddddddddddddddddddddddddddddddd9W8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA-VIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIHD6q;NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOL(%%%%%%%%%%%%%%%%%%%%%%%%%%35x$FBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=================v::::::::::::::::::::::::::::::::::"4444444444444444444444444444444444444444444444444444444444444444444444444444////////////////TyER,kkkkkkkkkkkkkkkkkkkkkk))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))C.7MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM


















	2h1m0ugPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPSfffffffffffffffffffffffffffffffffffffffffslr ctttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttbbbbbbbbbbbbpnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiild strrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrcpppppppppppppppppooooooooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm																												h122222222222222222222222222222ug0llllllllllllllS bftdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsprociiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeet                                                             lpdosnrrrrrrrrrraiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiee"DL5GFByyyyyyyyyyyyyyyyyyyyyyyyyyy=================v:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::////////////////T4
R,kkkkkkkkkkkkkkkkkkkkkk)EEEEEEEEEEEEEEE7CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC....................................M1mmmmmmmmmmmmmmmmmmPPPPPPPPPPPPPPPPPPPPPPPggggggggggggggggggggggggggggggggggggggggggggggh	bbbbbbbbbbbbbbbbbbbbbbbbbbbbbu2t00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000Sp olnddddddddddddfssssssssssssssssssssssaiiiiiiiiiiiiiiiiiiiiiirrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiicccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccctp olndddddddddddddsssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiirrrrrrrreeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiih1mmmmmmmmmmmmmmmmmmuggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggbbbbbbbbbbbbbbbbbbbbbbbbbbbbb	c20ttttttttttttttttttttttttt                                                             lpdosnnnnnnnrrrrrrrrrrrrrSSSSSSSSeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlcdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsproiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiffffffffeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&'@<((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((!#wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww}zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz{jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ+++++++++++++++++++++++++++++++++++++++++++++9W8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII66666666666666666666666666666666666666666;HOqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq-NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx%%%%%%%%%%%%%%%%%%%%%%%%%%DL5G3"Tyyyyyyyyyyyyyyyyyyyyyyyyyyy=================v:B))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))//////////////////////////////////////////////////P
R,kkkkkkkkkkkkkkkkkkkkkk4mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm777777777777777777777777777777777777CE........................MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM1hhhhhhhhhhhhhhhhhhhhhhhhhhhhhugggggggggggggggggggggggggggggggggggggggggggggggggggggggggggbbbbbbbbbbbbbbb 	2lllllllllllll0dtscrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrppppppppppaiiiiiiiiiiiiffffffffffffffooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneedls rtttttttttttcSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSaiiiiiiiiiiiinpppppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiioo1mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmghhhhhhhhhhhhubbbbbbbbbbbbbbbbbb																																																									f2dls rtttttttttttcS0000000000000000000000000000000000000000000000000000000000000nnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiippppppppeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilo dtscrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrpppppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaa:FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFDL5$$$$$$$$$$$$$$$$Tyyyyyyyyyyyyyyyyyyyyyyyyyyy=================v""""""""""""""""""""""))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))/BBBBBBBBBBBBBBBBBBBBBBBBP
R,kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkE74CCCCCCCCCCCC1mmmmmmmmmmmmmmmmmmmmmmm.	ghhhhhhhhhhhhhhhhhhhMfbbbbbbbbbbbbbbbbbbulllllllllllllllllllllllllllllllllllllllllll SSSSSSSSSSSSSSStocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspriiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiii22222222eeeeeeeeeeeeeeeeeeeeeeeeeeet clllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllopdnssssssssssaiiiiiiiiiiii0rrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieehhhhhhhhhhhh1mmmmmmmmmmmmmmmmmm	gggggggggggggggggggggggggggggSfbbbbbbbbbbbbbbbbbbbbbbbbbbbbtuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuucccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc plno000000000000000ddddddddddddddddddddddaiiiiiiiiiiiiiiiiiiiiiissssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiirrcttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt plno2ddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiisssssssseeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiixxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx(9W8A55555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555V6I;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO-HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH*vGNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN%FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFDL:////////////////Tyyyyyyyyyyyyyyyyyyyyyyyyyyy=================$$$$$$$$$$$$$$$$$$$$$$$$$$kkkkkkkkkkkkkkkkkkkkkk))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))""""""""""""""""""""""""""""""""""""""""""""""P
R,B1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE44444444444444444444444444444444444444444444444444444444444444447ghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhCbbbbbbbbbbbbbbbbbb	mmmmmmmmmmmmmmSfffffffffffffffffffffffffffffrrrrrrrrrrrrrrrrrrrrrrrrrrrr.ut0000000000000000000000000000000 clllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllopdnnnnnnns22222222222222222222eeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeaa tlrocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddspiiiiiiiiiiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeee	ghhhhhhhhhhhhfbbbbbbbbbbbbbbbbbb100000000000000Sm                             Ml2uotdrsccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiippppppppeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiinnnnnnnnnnnnnneeold stttttttttttrrrrrrrrrrrrrccccccccccccccccccccccaiiiiiiiiiiiinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiippL5vTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTDFFFFFFFFFFFFFFFFF////////////////:)))))))))))))))))))))))))))=yyyyyyyyyyyyyyyyyyyyykkkkkkkkkkkkkkkkkkkkkk3PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"4R


















EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEB																																																																hhhhhhhhhhhhhhhhhhhhhhhhhhhh7fggggggggggggggggggggggggggggg0bS1111111111111111111111111111111111111111112mmmmmmmmmmmmmmmMCold stttttttttttrrrrrrrrrrrrrucnnnnnnnneeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiilp otdrscccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiinnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeaa0h	fffffffffffffffffffffffffffffffffffffffffffffffffffffffffgggggggggggggggS1bllllllllllllll2             mtprocdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsiiiiiiiiiiiinnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii........eeeeeeeeeeeeeeeeeeeeeeeeeeet rlcppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppponddddddddddaiiiiiiiiiiiiusssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiee����ٯ�������������������������������^���������������~�|������������������������������������������������������������������������������������������������������Լ����������``````````````````````````````````````````````��\_Z]X[�Y���U���Qɀ���K�������>��?������� ��8����������ƺ�������&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�'<G!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}#wjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{Jqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq+++++++++++++++++++++++++++++++++(9WxDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD6666666666666666666666666666666666666666666666666666666666;VOI---------------------------------------------------------------------------------------------------------------------------------------AH=$*********************************************NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN5vTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL////////////////:)))))))))))))))))))))))))))Fkkkkkkkkkkkkkkkkkkkkkk3%PPPPPPPPPPPPPPPPPPPPyyyyyyyyyyyyyyyyyyyyyyyyyyyy,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"4RRRRRRRRRRRRRRRRRRRRRRRRR																																																																																			E
BBBBBBBBBBBB0hMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM1111111111111111111111111111111111111111111111fffffffffffffffffffffffffffSgtbbbbbbbbbbbbbbrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr2c                                                             lnpumooooooooooooooooooooooaiiiiiiiiiiiiiiiiiiiiiidddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiissrtc                                                             lnp.7ooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiddddddddeeeeeeeeeeeeeeeeeeeeeeaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii0hS11111111111111111111111111111																																																									fsgbtuuuuuuuuuuuuuu rlcppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppponnnnnnndC22222222eeeeeeeeeeeeeeeeeeeeeeaaaaaaaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeee