//Commander Training 
//-------------------------

exec("game.cs");
exec("training_AI.cs");
$Train::missionType = "COMMAND";
$pref::mapFilter = 15;
$pref::mapNames = true;

function Game::initialMissionDrop(%clientId)
{
   GameBase::setTeam(%clientId, 0);
   Client::setGuiMode(%clientId, $GuiModePlay);
   Game::playerSpawn(%clientId, false);
   Training::displayBitmap(0);
   command::initTargets(%clientId);
   Training::setupAI( %clientId );
}


function command::initTargets(%cl)
{
  $panelsDes = 0;
  $numCompleted = 0;
  $TrainMissionComplete = false;
  %group = nameToId("MissionGroup\\Teams\\Team1\\base");
  %numObj = Group::objectCount(%group);
  $numTargets = 0;
  %lineNum = 7;
  $init = true;
  
  %set = newObject(ObjectivesSet, SimSet);
  addToSet(MissionCleanup, ObjectivesSet);
  
  for(%i = 0; %i < %numObj; %i++)
  {
    %Obj = Group::getObject(%group, %i);
	
    if(%Obj.target)
	{
      %Obj.destroyed = false;
      $targets[%i] = %Obj;
	  $completed[%i] = false;
	  %Obj.lineNum = %lineNum++;
	  $numTargets++;
	  %Obj.position = GameBase::getPosition(%Obj);
	  addToSet(%set, %Obj);
	  Command::checkMissionObjectives(%cl, %Obj);
	}
  }
  Command::intro(%cl);
}

function Command::intro(%clientId)
{
   bottomprint(%clientId, "<jc><f1>Training Mission 4 - Commander and Target laser Training", 5);
   schedule("messageAll(0, \"~wshell_click.wav\");", 0);
   schedule("firstObjective1(" @ %clientId @ ");", 5);
   schedule("command::setWayPoint(" @ %clientId @ ");", 5);
}

function firstObjective1(%clientId)
{
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Here are your orders.\", 5);", 0);
   schedule("messageAll(0, \"~wshell_click.wav\");", 0);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>The enemy base has been located by your scouts, and a mortar attack has been issued to clear the way for offensive troops.  It is going to be your job to set up targets for the two heavy armor troops that are under your command.\", 15);", 5);
   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
   firstObjective2(%clientId);
}  
  
function firstObjective2(%clientId)
{  
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Before you do anything, you will need to be briefed on using your base inventory machine so that you can get equipped for your mission.\", 15);", 20);
   schedule("messageAll(0, \"~wshell_click.wav\");", 20);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>In front of you is an inventory station. Walk up to it to bring up the inventory screen. The list on the right are things that you may purchase. Things in your personal inventory are displayed on the left side of the screen.\", 15);", 35);
   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
   firstObjective3(%clientId);
}  
  
function firstObjective3(%clientId)
{ 
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>You are going to need a targeting laser for this mission to target objects for your mortar men. To purchase a targeting laser scroll down on the buy menu until you come to the weapons section. Choose the targeting laser by double clicking on it.\", 15);", 50);
   schedule("messageAll(0, \"~wshell_click.wav\");", 50);
   firstObjective4(%clientId);
}
  
  
function firstObjective4(%clientId)
{ 
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Once you have the targeting laser, hit the inventory key(I), exit your base,  and we will move on to the commander screen briefing.\", 15);", 65);
   schedule("messageAll(0, \"~wshell_click.wav\");", 65);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>To view your commander screen, press the C key. You should see a map of the mission area. This is a top down view of everything in the area.\", 15);", 80);
   schedule("messageAll(0, \"~wshell_click.wav\");", 80);
   firstObjective5(%clientId);
}  
  
function firstObjective5(%clientId)
{ 
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>You are represented by a solid green triangle somewhere near the building labeled Home Base. It should be within your senor range circle. Use the zoom button at the bottom right to zoom in on your base.\", 151);", 95);
   schedule("messageAll(0, \"~wshell_click.wav\");", 95);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>To command your men, click on them either from the list of players on the top right, or by clicking on them on the map. When they are selected, a box will appear around them.\", 15);", 110);
   schedule("messageAll(0, \"~wshell_click.wav\");", 110);
   firstObjective6(%clientId);
}  
  
function firstObjective6(%clientId)
{ 
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>To give them a waypoint just choose a command from the bottom right menu.  For example, choose one of your troops and issue him to attack a waypoint by pressing the A key and then clicking on the map where you want him to go.\", 15);", 125);
   schedule("messageAll(0, \"~wshell_click.wav\");", 125);
   secondObjective1(%clientId); 
}

function secondObjective1(%clientId)
{   
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Your men will not fire until they have a target, however. This is where you come in. You are going to target objects for them to attack with the targeting laser.\", 15);", 140);
   schedule("messageAll(0, \"~wshell_click.wav\");", 140);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>On the Commander screen you will see location A and location B.\", 20);", 155);
   schedule("messageAll(0, \"~wshell_click.wav\");", 155);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Once they are in position, it will be time for you to advance to a position near the waypoint given to you. Once you get there you can start lighting up targets.\", 15);", 170);
   schedule("messageAll(0, \"~wshell_click.wav\");", 170);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>To target things, just aim at the object with your crosshair and then pull the trigger. You must hold the fire button down to keep the beam targeting the object.\", 15);", 185);
   schedule("messageAll(0, \"~wshell_click.wav\");", 185);
   schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>You should see the mortars take out the targets. If you notice that the mortars are landing long or short, adjust where you fire the beam. Use your zoom(E) to help target objects.\", 15);", 200);
   schedule("messageAll(0, \"~wshell_click.wav\");", 200);
   secondObjective2(%clientId);
}

function secondObjective2(%clientId)
{
  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>There are 6 targets that need to be destroyed. 3 Solar panels, 1 Sensor, and 2 Turrets.  Your first target will be the enemy's solar panels that supply their power. They are just West of thier base.\", 15);", 215);
  schedule("messageAll(0, \"~wshell_click.wav\");", 215);
  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Taking out their power first will negate all the shields for concurrent targets. Even if they have some kind of backup system, the sensors should be down long enough to take them out.\", 15);", 230);
  schedule("messageAll(0, \"~wshell_click.wav\");", 230);
  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Next, take out the enemy sensor.  If the enemy does repair power to their base, they will be blind to our infiltration.\", 15);", 245);
  schedule("messageAll(0, \"~wshell_click.wav\");", 245);
  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Now we need to take out the turrets that guard the entrance. They should be easy to destroy provided the enemy has not restored power as of yet.\", 15);", 260);
  schedule("messageAll(0, \"~wshell_click.wav\");", 260);
  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>The best approch is to send your men to location A for the solar panels and the main Sensor, and then move them to location B for the 2 turrets.\", 15);", 275);
  schedule("messageAll(0, \"~wshell_click.wav\");", 275);
  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Your waypoint has been set to the first target.  Good luck.\", 10);", 290);
  schedule("messageAll(0, \"~wshell_click.wav\");", 290);
}  

function checkTargetsDestroyed(%this)
{
   %cl = Client::getFirst();
   Command::checkMissionObjectives(%cl, %this);
   
   if(!$TrainMissionComplete && $panelsDes > 2)
      Command::setWayPoint(%cl, %this);
}

function StaticShape::objectiveDestroyed(%this)
{
  dbecho(2,"shape destroyed");
  $numCompleted++;
  
  for(%i = 0; %i < $numTargets; %i++)
  {
    if(%this == $targets[%i])
	{
	  $panelsDes++;
	  $completed[%i] = true;
	  %cl = Client::getFirst(); 
	  %this.destroyed = true;
	  if($panelsDes == 3)
	  {
	     bottomprint(%cl, "<f1><jc>You have destroyed the solar panels", 5);
         messageAll(0, "~wshell_click.wav");
		 Ai::soundHelper( 2051, 2049, cheer3 );
	  }
	}
  }
  checkTargetsDestroyed(%this);
}


function Sensor::onDestroyed(%this)
{
	%this.shieldStrength = 0;
	GameBase::setRechargeRate(%this,0);
	Sensor::onDeactivate(%this);
	sensor::objectiveDestroyed(%this);
	%sensorName = GameBase::getDataName(%this);
	if(%sensorName == "DeployableSensorJammer") 
   	$TeamItemCount[GameBase::getTeam(%this) @ "DeployableSensorJammerPack"]--;
	else if(%sensorName == "DeployableMotionSensor") 
   	$TeamItemCount[GameBase::getTeam(%this) @ "MotionSensorPack"]--;
	else if(%sensorName == "DeployablePulseSensor") 
   	$TeamItemCount[GameBase::getTeam(%this) @ "PulseSensorPack"]--;
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.40, 
		0.1, 250, 100);
}


function sensor::objectiveDestroyed(%this)
{
    
  dbecho(2, "sensor destroyed");
  $numCompleted++;
  for(%i = 0; %i < $numTargets; %i++)
  {
    if(%this == $targets[%i])
	{
	  $completed[%i] = true;
	  %cl = Client::getFirst(); 
	  %this.destroyed = true;
	  bottomprint(%cl, "<f1><jc>You have destroyed " @ %this.objective, 5);
      Ai::soundHelper( 2051, 2049, cheer4 );
	  
	}
  }
  checkTargetsDestroyed(%this);
}

function Turret::onDestroyed(%this)
{
	%this.shieldStrength = 0;
	GameBase::setRechargeRate(%this,0);
	Turret::onDeactivate(%this);
	Turret::objectiveDestroyed(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 9, 3, 0.40, 
		0.1, 200, 100); 
}



function turret::objectiveDestroyed(%this)
{
    
  dbecho(2,"turret destroyed");
  $numCompleted++;
  for(%i = 0; %i < $numTargets; %i++)
  {
    if(%this == $targets[%i])
	{
	  $completed[%i] = true;
	  %cl = Client::getFirst(); 
	  %this.destroyed = true;
	  bottomprint(%cl, "<f1><jc>You have destroyed " @ %this.objective, 5);
      Ai::soundHelper( 2050, 2049, cheer2 );
	  
	}
  }
  checkTargetsDestroyed(%this);
}


function Command::setWayPoint(%cl)
{
   %nextTarget = 0;
   %group = nameToID("MissionCleanup/ObjectivesSet");
   %target = Group::getObject(%group, %nextTarget);

   while(%target.destroyed)
   {   
      %nextTarget++;
      %target = Group::getObject(%group, %nextTarget);
   } 
   
   %x = getWord(%target.position, 0);
   %y = getWord(%target.position, 1);

   if($init)
      %delay = 10;
   else 
      %delay = 5;
   
   if(!%target.init)
       schedule("bottomprint(" @ %cl @ ", \"<jc><f1>Waypoint set to " @ %target.objective @ "\", 5);", 5);
   issueCommand(%cl, %cl, 0, "Waypoint set to next objective", %x, %y);
   $init = false;
}

function Training::setupAI(%clientId)
{
  %group = "MissionGroup\\AI";
  $numGuards = Group::objectCount(%group);
    
  
  if( %group == -1 || $numGuards == 0 )
    dbecho(2,"No AI exists...");  
  
  else 
  {  
    for(%guard = 1; %guard <= $numGuards; %guard++)
    {
      %AIname = "guard" @ %guard;
      createAI(%AIname, %group @ "\\guard" @ %guard, larmor, $AI_Names[floor(getRandom() * 15)]);
 	  GameBase::setTeam(AI::getId( %AIname ), 0);
 	  AI::setVar( %AIname,  iq,  100 );
 	  AI::setVar( %AIname,  attackmode, 1 );
 	}
    
	AI::DirectiveTargetLaser( "Guard1", %clientId );
	AI::DirectiveTargetLaser( "Guard2", %clientId );
	AI::callWithId("Guard1", Player::setItemCount, Mortar, 1);
	AI::callWithId("Guard1", Player::setItemCount, MortarAmmo, 10000);
	AI::callWithId("Guard1", Player::mountItem, mortar, 0);
	AI::callWithId("Guard2", Player::setItemCount, Mortar, 1);
	AI::callWithId("Guard2", Player::setItemCount, MortarAmmo, 10000);
	AI::callWithId("Guard2", Player::mountItem, mortar, 0);
	AI::SetVar( "*", triggerPct, 100 );
  }
}


function command::checkMissionObjectives(%cl, %shape)
{
  if(command::MissionObjectives( Client::getTeam(%cl), %cl, %shape ))
   {
      bottomprint(%cl, "<f1><jc>You have completed the commander and targeting laser training!", 8);
      schedule("training::MissionComplete(" @ %cl @ " );", 8);
   }
}

function Command::MissionObjectives( %teamId, %cl, %this )
{
   %teamName = getTeamName(%teamId); 
   %player = Client::getOwnedObject(%cl);

   %enemyTeamName = getTeamName(%enemyTeam);
  
   if($numCompleted == $numTargets)
   {
     $TrainMissionComplete = true;
     return "True";
   }
   
   Team::setObjective(%teamId, 1, "<f5><jl>Mission Completion:");
   Team::setObjective(%teamId, 2, "<f1>   -Destroy all enemy targets that are assigned");
   Team::setObjective(%teamId, 3, "\n");
   Team::setObjective(%teamId, 4, "<f5>Mission Information:");
   Team::setObjective(%teamId, 5, "<f1>   -Mission Name: Commander and Targeting laser Training");
   Team::setObjective(%teamId, 6, "\n"); 
   Team::setObjective(%teamId, 7, "<f5><jl>Mission Obejectives:");
   
   if(%this.destroyed)
   {
      %status = "<f1><Bitem_ok.bmp>\n   -You successfully destroyed " @ %this.objective;
   }
   else
   {
      %status = "<f1><Bitem_damaged.bmp>\n   -You have not destroyed " @ %this.objective;
   }

   if(%this.lineNum == 8)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 9)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 10)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 11)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 12)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 13)
      Team::setObjective(%teamId, %this.lineNum, %status);

   return "False";
}

function missionSummary()
{
   %time = getSimTime() - $MatchStartTime;
   
   Training::displayBitmap(0);
   Team::setObjective(0, 1, "<f5><jl>Mission Completion:");
   Team::setObjective(0, 2, "<f1>   -Completed:");
   Team::setObjective(0, 3, "\n");
   Team::setObjective(0, 4, "<f5><jl>Mission Information:");
   Team::setObjective(0, 5, "<f1>   -Mission Name: Commander and Target laser Training");
   Team::setObjective(0, 6, "\n");
   
   Team::setObjective(0, 7, "<f5><j1>Mission Summary:");
   
   Team::setObjective(0, 8, "<f1>   -Total Mission Time: " @ "<f1>" @ Time::getMinutes(%time) @ " Minutes " @ Time::getSeconds(%time) @ " Seconds");
   Team::setObjective(0, 9, "<f1>   -Total enemy kills: " @ $AIkilled);
   Team::setObjective(0, 10, "\n");
   Team::setObjective(0, 11, "\n");
   Team::setObjective(0, 12, "\n");
   Team::setObjective(0, 13, "\n");
   Team::setObjective(0, 14, "\n");
}

function Training::missionComplete(%cl)
{
  schedule("Client::setGuiMode(" @ %cl @ ", " @ $GuiModeObjectives @ ");", 0);
  missionSummary();
  remoteEval(2049, TrainingEndMission);
}

function remoteTrainingEndMission()
{
   schedule("EndGame();", 8);
}


//these just disable certain behaviors
function StaticShape::objectiveDisabled(%this)
{
}

function StaticShape::objectiveEnabled(%this)
{
}

function remoteScoresOn(%clientId)
{
}

function remoteScoresOff(%clientId)
{
}


function Flag::onCollision(%this, %object)
{
   dbecho( 2, "Flag collision called for " @ %this @ " and " @ %object );
}

daammaaodd]]]]]]]]]]]]]]]]]]]]]]]]]]aoooooooooomaadooooooooooooooooooom:::::::::::::::::::::::::::::kMMMMMMMMMMMMMMMMaooooooooooooooooooooooooooo.maaaaaaaaaaaoooooooooodddddddddddaa.1oooooooooooooooooood:::::::::::::::maooooooooooooooooooooooooooomdaaaaaaaaaaaoooooooooo											aayyyyyyyyyyy9|@&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*6.>q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{0���������������������<"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8888888888888888888888888888888888888888888888888888888888888888888888888888888888EF]ooooooooooooooooooo	DkM1:daoooooooooooooooooooooooooooumdddddddddddaaaaaaaaaaaooooooooooooooooooooooooooooooooooaa..............yu",d1goooooooooooooooooooooooooooooooooooooooooooooooommmmmmmmmmmaooooooooooooooooooooooooooo:ddddddddddduaaaaaaaaaaaoooooooooommmmmmmmmmmaaaaaaaaaaaaaaaaaaaaaabhhhhhhhhhhhhhhhhh\1k00000000000000000000000000	.:",yyyyyyyyyyygggggggggggggggooooooooooooooooooooooooomddddddduaaaaaaaaoooooooooooooooooooooooooooooooooooooooooooooouuuuuuuuuuuuuuuuuuuuuuuuuuDmaaaaaaaaaaaaaaaaaooooooooooooooooooooooodddddddddddddddddaaaaaaauuuuuuuue,,,,,,,,,,,,,,1:hb.aoooooooooM"ygggggggggggggggggdddddddddddddddddddddddddmaoeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolduuuuuuuummmmmmmmmmmmmmmaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeaeeeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooooommmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOW6>j9kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk<
88888888888888888888888888888888\FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000000000000000000000EEEEEEEEEEEb,1:yh.M	dullllllllleeeeeeeeaaaaaaaaaaaaaaaaaoooooooooooooooooooooooeeeeeeeeeeeeeee"""""""""""""""""""""aaaaaaao      mruuuuuuuuuuuaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeegdddddddddddaol                                    eeeeeeeul11111111111111(b.,:ymrrrrrrrrrrrrrrrhhhhhhhhhhhhhhhhgDaeo                                             edddddddddao                                          rllllllllllllllllmeeeeeeeeduaoooooooooooooooooooo                           e"aaaaaaaaaaaaaaaaaaaaaooooooooooooooooonnnnnnnnnnnnnnnn0A$$$$$$$$$$$$$$$$$$$$11111111111111111\               Mkkkkkkkkkkkkkk(rb.g:y,,,,,,dlllllllloooooooooe"hmmmmmmmmmmmmmmmmmmmmaaaaaaaaaaao aaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeuuuuuuuatrdnnnnnnD]]]]]]]]]]]oul                                   eeeeeeeeeeemaeo                                          															11111111111111(betygd":.,rrrrrrunmmmmmmmmmmmmmmmmmmmao                                             eeeeeeeelaooooooooooooooooooooo              hduttttttmrrrrrrrrr elnaaaaaaaaaaaaaaaaaaaaooooooooooo        oooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaa((((((((((((((((((((((((((((((((((((((((((((�������������������������������������������������������������������������������������������������������������������������������������������������������߷��������������������������������������������������������������������������������������������������������������`�^���Z�X������������������������������������������������������Q���žK����������?��������N������ԭ�������������������������������������������������������������������������������ð�#########################################��L''''''''''''''''''''''''''''''''''''''''''''''''''''�������������������������������������������������� %}�HYU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~zVPPPPPPPPPPPPPPPPPPPB------------|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm/&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&@qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq*�J!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!W6>j$SSSSSSSSSSSSSSSSSSO


























{M9<8F0																																																			1\AAAAAAAAAAAAAAAkDohhhhhhhhhhhhhhbyug"d:......lt aaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrraon                                    eeeeeeenumd,lllllltttttttttttaeo                                             errrrrrrrrao                                  ,(((((((((((((11111111111111111111111111]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]hhhhhhhhhngbm:yyyyyyyyyyyyyy"uuuuuutdeeeeeeeerlaoooooooooooooooooooo                           eeeeeeeeeeeaaaaaaaaaaaaaaaaaaaaaooooooo .mtnnnnnnruuuuuuuuoooooooooeeeeeeeeeeeddddddddddddddddddddaaaaaaaaaaao aaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeelllllllErs																			%M\$0T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,kkkkkkkkkkkkkkkkkkkkkkkkkkkk(SA1a...............hgtb:myyyyyyyyyyyyyyyyyyyyyyyyyyyyynolu                                   eeeeeeeeeeedaeo                                          etmsssssssssssrrrrrrl"dnnnnnnnnnao                                             eeeeeeeeuaooooooooooooooooooooo       lllllllllllllllllllllllllllllllllD,.(h11111111myyyyyyyyyyyyyyyyyyyyyyyyygbtssssssdrrrrrrrrr eu":aaaaaaaaaaaaaaaaaaaaooooooooooo        oooooooooennnnnnnnnnnnnnnnnnnnnaaaaaaaooooooooooomtldddddddddddddddus aaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeenrrrrrrrrrrraoooooooooooooo                                    eeeeeeeg2w=GPBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB-555555555555555555555555555555555CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC/33333333333333333333333333Nx+W6>9jO
]]]]]]]]]]]]]]]]]]]]]<8																																																													%EFukkkkkkkkkkkkkkkkkkkM\\\\\\\\\\\\$0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDT.................Sh,y(((((((((((((1111111111111111111111111111b"mtldddddddddddddddddddddddddsnaeo                                             errrrrrrrrao                                          mul::::::::::ttttttsdeeeeeeeerrrrrrrrrrraoooooooooooooooooooo                           enaaaaaaaaaaaaaaaaaaaaaooooooosi............hgyAAAAAAAAAAAAA,,,,,,,,,,,,,,( lmmmmmmmmmmub1::::::::::::::::::::rttttttttoooooooooenddddddddddddddddddddaaaaaaaaaaao aaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerslaaaaaaaiiiiiiiiiimuuuuuun"ooooooooooot                                   eeeeeeedddddddddddaeo                                          s	Ifkwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww2$%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%M\\\\\\\\\\\\\\\\\\\.0DDDDDDDDDDDyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhhhhhhhhgATTTTTTTTTTTTT:,(breminnnnnnnnnnluuuuuud"111111111111111ao                                             ettttttttttttttaooooooooooooooooooooo       dssssssssssssssssssnmlirrrrrrrrrrrrrrrrrrrrrrre tuuuuuuuaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaasy.ttttttttttttttcpppppppppppp:hgS""""""""""""",(dolnrmmmmmmmmmmmiiiiii        aaaaaaaaaeeeeeeeeeeeeeeebbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbaaaaao                      eeeeeeeeeeeeeeeeeeeeeuuuuuuu1stttttttrlllllllllllndmmmmmmaoui                                   eeeeeeeeeeeeeeeeeeeeeeeeeeaeo                                                       HHHHHHHHHHHHHHHHHHHHHHH[[[[[[[[[[[[[[[[[[[[[[RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR}||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||_______________________________________________________________________________qqqqqqqqqqqqqqqqqqqqqqqqq77777777777777777777777777777777777777777777777777;&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&=)v4444444444444444444444444444444444444444444444444444444444444444444444444@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*CPBGGGGGGGGGGGGGGGGGGGGGGGGGG555555555555555555555555555555555-/3333333333333333333333333333333333333333333333333333333333333333x+NsIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII6666666666666666666666666666669WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW]>jOE




































<888888888888888888888!fk\	2$$$$$$$$$$$$$$$$$wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwyM%A0DDDDDDDDDDDDDDDDDDDu:.cp""""""""""""hgggggggggggggggSSSSSSSSSSSSSSSSSSSSSSSSSSSS,1(eeeeeeeeeeerdltnnnnnnnnnnnnnnnmmmmmmmmmmmmmmmao                                             eiiiiiiiiiiiiiiaooooooooooooooooooooo                suuuuuuuudddddddddddtrblllllllllllllle innnnnnnaaaaaaaaaaaaaaaaaaaaooooooo                    oemmmmmmmmmmmmmmmmmmmmmmmmmmmaaaaaaas:yi"""""""""""""".cccccccccccccccpppppppppppph1gTTTTTTTTTTTTTTTTTTTTTTotdb,,,,,,,,,,,urrrrrr        aaaaaaaaaemllllllllllllllllllllllllllllllllaaaaao                      eeeeeeeeeeeeeeeeeeeeennnnnnnmsiiiiiii(tudddddddddddddddddddddddddaonr                                   eeeeeeelllllllllllaeo                                          s\IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIfkFM2$	DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDw:%A"S0nnnnnnnnnnnnnnnyyyyyyyyyyyyyy.1cppppppppppppbhgTTTTTTTTTTTTTTTTTTTmeu((((((((((((((((((((((tiddddddlllllllllllllllllllllllllao                                             errrrrrrrrrrrrraooooooooooooooooooooo       lsnnnnnnnnnnnnnnnnnui,mtttttttttttttte rdddddddaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaasssssssssssssss"r1:yyyyyyyyyyyyyyb.cp((((((((((((hgloiiiiiiiiiimun,,,,,,,,,,,,,,,,,,,,,        aaaaaaaaaeeeeeeeeeeettttttttttttttttttttttttttttttttaaaaao                      eeeeeeeeeeeeeeeeeeeeedddddddddddddddddsrrrrrrrminnnnnnnnnnluuuuuuaoddddddddddddd                                   eeeeeeetttttttttttaeo                                          1)BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=444444444444444444444444444444444CPv333333333333333333333333335G+/-666666666666666666xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxsINNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN99999999999999999999999999999]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]kEW>j8O$\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\




































F<MSf	DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD2T%Awdb":y((((((((((((((.c,pppppppppppphhhhhhhhhhhenmlirrrrrrrrrrrrrrrtuuuuuuuuuuuuuuuao                                             eeeeeeeeeeeeeggggggggggggggaooooooooooooooooooooo       tsddddddddlnrmmmmmmmmmmmiiiiiiiiiiiiiie                0000000000000000aaaaaaaaaaaaaaaaaaaaooooooo                    oeuuuuuuuuuuuuuuuuuuuuuuuuuuuaaaaaaasbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb1":y((((((((((((((.c,pppppppppppphhhhhhhhhhhhhtorlllllllllllndmmmmmm        aaaaaaaaaeuiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiaaaaao                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeusgggggggggggggggggrdltnnnnnnaoooooooooom                                   eeeeeeeiiiiiiiiiiiaeo                                          ssssssssssssssssssssI$SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\{MkA	Dfb2TTTTTTTTTTTTTTTTTTT%wwwwwwwwwwwwwwwwwwwwwwwwwyyyyyyyyyyyyyyy1"c:((((((((((((((h.,puedddddddddddtrggggggggggggllllllinnnnnnnnnnnnnnnao                                             emmmmmmmmmmmmmmaooooooooooooooooooooo       issssssssssssssssstdddddddddddddddddddddddurrrrrrrrrrrrrre mlllllllaaaaaaaaaaaaaaaaaaaaooooooo                    oennnnnnnnnnnnnnnnnnnnnnnnnnnaaaaaaasybmc0000000000000001h":(gggggggggggggg.,ioooooooooooooptuddddddddddddddddddddddddd        aaaaaaaaaenrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrraaaaao                      eeeeeeeeeeeeeeeeeeeeelllllllnsmmmmmmmuuuuuuuuuuuuuuuuuuuuutiddddddaolllllllllll                                   eeeeeeerrrrrrrrrrraeo                                          cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''UzYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY�~VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV[[[[[[[[[[[[[[[[[[[[[[RHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||_}}}}}}}}}}}}}}}}}}}}}qqqqqqqqqqqqqqqqqqqqqqqqq77777777777777777777777777777777777777777777777777;&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&==============================================================================================================================================================@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@PBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB)555555555555555555555555555555555C4/33333333333333333333333333vx+G9666666666666666666-sIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIN]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE888888888888888888888888888888W>FjMMMMMMMMMMMMMMMMMMMM$SDO
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\kAy	{*************************************w2Tflhb0%%%%%%%%%%%%%%%g1":::::::::::::((((((((((((((.neeeeeeeeeeuiiiiiiiiiiii,mttttttrdddddddddddddddao                                             eeeeeeeeeeeeeeeeeeeeeeeeaooooooooooooooooooooo       rslllllllliiiiiiiiiimunppppppppppppppe           tttttttaaaaaaaaaaaaaaaaaaaaooooooo                    oedddddddddddddddddddddddddddaaaaaaashyyyyyyyyyyygcbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb1"""""""""""":((((((((((((((rominnnnnnnnnnluuuuuu        aaaaaaaaaedp................................aaaaao                      eeeeeeeeeeeeeeeeeeeeetttttttdsssssssssssssssssnmlirrrrrrrrrrrrrrraotu                                   eeeeeee,,,,,,,,,,,aeo                                          sDIMMMMMMMMMMMMMMMMMMM$SSSSSSSSSSSSSSSSSSSS	\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\TkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAh<wg02tttttttttttttycbbbbbbbbbbbbbbbbbbbbbbbbbbbfffffffffffffff1p":(delnrmmmmmmmmmmmiiiiii,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,ao                                             euuuuuuuuuuuuuuaooooooooooooooooooooo       .sttttttttrlllllllllllndmmmmmmmmmmmmmme uiiiiiiiaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaasssssssssssssguuuuuuuuuuuuhycpb%%%%%%%%%%%%%%%,1":.(ooooooooooordltnnnnnn        aaaaaaaaaeeeeeeeeeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmaaaaao                      eeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiisuuuuuuudddddddddddtrrrrrrrrrrrrrrllllllaoin                                   eeeeeeemmmmmmmmmmmaeo                                                                                      CPB==========================555555555555555555555555555555555)/3444444444444444444x+v]96GsI-----------------------------------------------EN888888888888888888888888888888888888888888SFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFW!>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>DMMMMMMMMMMMMMMMMMMMAjOOOOOOOOOOOOOOOOOOOO	0$$$$$$$$$$$$$$$$$TTTTTTTTTTTTTk\\\\\\\\\\\\\\\\<
wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwipghy,cb%2...............1""""""""""etdddddddddddddd:::::::::::urrrrrrmlllllllllllllllao                                             ennnnnnnnnnnnnnaooooooooooooooooooooo       msiiiiiiii(tuddddddddddddddddddddddddddddddddde nrrrrrrraaaaaaaaaaaaaaaaaaaaooooooo                    oelllllllllllllllllllllllllllaaaaaaaspppppppppppppn,,,,,,,,,,,,gh.ycbbbbbbbbbbbbbbfffffffffffffff1mou(""""""""""tidddddd        aaaaaaaaaellllllllllllllllllllllllllllllllllllllllllaaaaao                      eeeeeeeeeeeeeeeeeeeeerrrrrrrlsnnnnnnnnnnnnnnnnui:mttttttaord                                   eeeeeeeeeeeeeeeeeeeeeeeeeeeaeo                                          sAIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII0MMMMMMMMMMMMMMMMMMMDkkkkkkkkkkkkkkkkkkkk	SwwwwwwwwwwwwwwwwwT$p\\\\\\\\\\\\\\\\,%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%r........................gggggggggggggghyc(bfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffleiiiiiiiiiimun:1111111111111111tttttttttttttttao                                             eddddddddddddddaooooooooooooooooooooo                 srrrrrrrrminnnnnnnnnnluuuuuuuuuuuuuue d"""""""aaaaaaaaaaaaaaaaaaaaooooooo                    oetttttttttttttttttttttttttttaaaaaaas.,ddddddddddddddpppppppppppppppppppppppp(ghy:cb22222222222onmlirrrrrrrrrrrrrrr        aaaaaaaaaetuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuaaaaao                      eeeeeeeeeeeeeeeeeeeee"""""""""""""""""""""tsdddddddlnrmmmmmmmmmmmiiiiiiao1111111111                                   eeeeeeeuuuuuuuuuuuaeo                                                       ______________________________________________________________________________________________________________________________[[[[[[[[[[[[[[[[[[[[[[R&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||H{{{{{{{{{{{{{{{{{{{{{qqqqqqqqqqqqqqqqqqqqqqqqq77777777777777777777777777777777777777777777777777;}BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@CPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP333333333333333333333333335=+/)666666666666666666x4E]9vsIG-88888888888888888888888888888888888888888888888FNNNNNNNNNNNNNNNNNNN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!<W	AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0T>jDk%MSw....................................f\\\\\\\\\\\\\\\\$1,pppppppppppppppppppppppp(ghy:cb2222222222222222222222222222222222222O"terlllllllllllndmmmmmmuiiiiiiiiiiiiiiiao                                             eeeeeeeeeeeeeeeeeeeeeeeaooooooooooooooooooooo       ussssssssssssssssssssssssssssssssrdltnnnnnnnnnnnnnne          mmmmmmmaaaaaaaaaaaaaaaaaaaaooooooo                    oeiiiiiiiiiiiiiiiiiiiiiiiiiiiaaaaaaas1..................................,pyyyyyyyyyyyyy(gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggh:cuodddddddddddtrrrrrrrrrrrrrrrbllllll        aaaaaaaaaeinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnaaaaao                      eeeeeeeeeeeeeeeeeeeeemmmmmmmisssssssssssssssstd"""""""""""urrrrrraoml                                   eeeeeeennnnnnnnnnnaeo                                          sTI	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%0AAAAAAAAAAAAAAAAADkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkSwM11111111111111111111ffffffffffff2\my..............,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,$ppppppppppppp(((((((((((((((gh:ie"ctudddddddddddddddddddddddddnrrrrrrrrrrrrrrrao                                             ellllllllllllllaooooooooooooooooooooo       nsmmmmmmmmubbbbbbbbbbtidddddddddddddde lllllllllllllllllaaaaaaaaaaaaaaaaaaaaooooooo                    oerrrrrrrrrrrrrrrrrrrrrrrrrrraaaaaaasyyyyyyyyyyyyl
1............................,ppppppppppppp"(ghnoooooooooouib:mtttttt        aaaaaaaaaerddddddddddddddddddddddddddddddddaaaaao                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeersllllllliiiiiiiiiimunccccccaooooooooooot                                   eeeeeeedddddddddddaeo                                          
BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBCPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP333333333333333333333333335=+/)666666666666666666x4E]9vG-8sI*FFFFFFFFFFFFFFFFFFFFFFFFFFFFFN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<000000000000000000000000000000000000000000000000000000000000000000W>Tk%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	wwwwwwwwwwwwwwwwwDA2222222222222222SSSSSSSSSSSSSSSSSSSyMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMjf\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\1."""""""""""""",pbbbbbbbbbbbbb(greminnnnnnnnnnluuuuuudchhhhhhhhhhhhhhhao                                             ettttttttttttttaooooooooooooooooooooo       dssssssssssssssssssnmlirrrrrrrrrrrrrrrrrrrrrrre tuuuuuuuaaaaaaaaaaaaaaaaaaaaooooooo                    oe:::::::::::::::::::::::::::aaaaaaasssssssssssssssyt"$$$$$$$$$$$$1b..............,cppppppppppppp(dolnrmmmmmmmmmmmiiiiii        aaaaaaaaae:gggggggggggggggggggggggggggggggggggggggggaaaaao                      eeeeeeeeeeeeeeeeeeeeeuuuuuuuhstttttttrlllllllllllndmmmmmmaoui                                   eeeeeeeeeeeeeeeeeeeeeeeeeeaeo                                          sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssI0Dk%TSwwwwwwwwwwwwwwwww	O2222222222222222AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM"\\\\\\\\\\\\\\\\\\\\uby$ffffffffffffc1..............:,ppppppppppppph(eeeeeeeeeeerdltnnnnnnnnnnnnnnnmmmmmmmmmmmmmmmao                                             eiiiiiiiiiiiiiiaooooooooooooooooooooo                suuuuuuuudddddddddddtrglllllllllllllle innnnnnnaaaaaaaaaaaaaaaaaaaaooooooo                    oemmmmmmmmmmmmmmmmmmmmmmmmmmmaaaaaaasb"icccccccccccccccyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy::::::::::::1.hhhhhhhhhhhhhh,ppppppppppotdgggggggggggggggggggggggurrrrrr        aaaaaaaaaemllllllllllllllllllllllllllllllllaaaaao                      eeeeeeeeeeeeeeeeeeeeennnnnnnmsiiiiiii(tudddddddddddddddddddddddddaonr                                   eeeeeeelllllllllllaeo                                          -c������������������������œ���������������������������������������������������������������������������������������ߔ��������������������������������������������������������������������������������������������������������������`�^���Z�X���������������������������������������������������Q��຾K����������?��������٬���������������������������������������������������������ƴ��#��������                                                    ��������������������������������������������LU'''''''''''''''''''''''''''''''''''''''''''zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzY~VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV;_R&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||![H{{{{{{{{{{{{{{{{{{{{{qqqqqqqqqqqqqqqqqqqqqqqqq7CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ3PPPPPPPPPPPPPPPPPP=+5])6/
4ExsI9v*@GGGGGGGGGGGGGGGGGGGGGGGGGGGGG8%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%FN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDWTS\k	O>b2w$$$$$$$$$$$$$$$$$$$MAn:"""""""""""""""yhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh1g..............,meu(pppppppppptiddddddlllllllllllllllllllllllllao                                             errrrrrrrrrrrrraooooooooooooooooooooo       lsnnnnnnnnnnnnnnnnnuiiiiiiiiiiiiimtttttttttttttte rdddddddaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaas:brhc"""""""""""""""gyffffffffffff(1..............loiiiiiiiiiimunnnnnnnnnnnnn,,,,,,        aaaaaaaaaeeeeeeeeeeettttttttttttttttttttttttttttttttaaaaao                      eeeeeeeeeeeeeeeeeeeeedddddddddddddddddsrrrrrrrminnnnnnnnnnluuuuuuaodp                                   eeeeeeetttttttttttaeo                                          ssssssssssssssssIIIIIIIIIIIIIIIII\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD2TS%M	jk:w$hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhdgbc"(((((((((((((((yfAAAAAAAAAAAAAAAAAAAAAAAA1...........enmlirrrrrrrrrrrrrrrtuuuuuuuuuuuuuuuao                                             epppppppppppppppppppppppppppaooooooooooooooooooooo       tsddddddddlnrmmmmmmmmmmmiiiiiiiiiiiiiie ,,,,,,,,,,,,,,,,aaaaaaaaaaaaaaaaaaaaooooooo                    oeuuuuuuuuuuuuuuuuuuuuuuuuuuuaaaaaaasgh,:bc"(((((((((((((((yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy1.ptorlllllllllllndmmmmmm        aaaaaaaaaeuiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiaaaaao                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeussssssssssssssssssssssssssssssrdltnnnnnnaoooooooooom                                   eeeeeeeiiiiiiiiiiiaeo                                          ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,33333333333333333333333333B-+C666666666666666666=PE])5555555555555555555555555555555555555555555555
4/sIx99999999999999999999999999999vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvGDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD8FNO<SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS\jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW222222222222222222222222222222222222222222222222222222222220%Mg	Tfw$kkkkkkkkkk"h:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbc(((((((((((((((.yyyyyyyyyyyyyyyyyyyyyyyyuedddddddddddtrrrrrrrrrrrrrr1llllllinnnnnnnnnnnnnnnao                                             emmmmmmmmmmmmmmaooooooooooooooooooooo       issssssssssssssssstdpppppppppppurrrrrrrrrrrrrre mlllllllaaaaaaaaaaaaaaaaaaaaooooooo                    oennnnnnnnnnnnnnnnnnnnnnnnnnnaaaaaaas"gmA,h:.bc((((((((((((((((((((((((((((yyyyyyyyyyyyyiopppppppppppptuddddddddddddddddddddddddd        aaaaaaaaaenrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrraaaaao                      eeeeeeeeeeeeeeeeeeeeelllllllnsmmmmmmmu1111111111tiddddddaolllllllllll                                   eeeeeeerrrrrrrrrrraeo                                          sDISSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS\\\\\\\\\\\\\\\\																																																													2>$%M0"TfAwkkkkkkkkkkkkkkkkkkkkl.g,hhhhhhhhhhhhhh:bcp(((((((((((((((yneeeeeeeeeeui1111111111111mttttttrdddddddddddddddao                                             eeeeeeeeeeeeeeeeeeeeeeeeaooooooooooooooooooooo       rslllllllliiiiiiiiiimunnnnnnnnnnnnnnnnnnnnnnnnne           tttttttaaaaaaaaaaaaaaaaaaaaooooooo                    oedddddddddddddddddddddddddddaaaaaaas.""""""""""""""""""""""""""""""""""""""""""g,ph:b1c(((((((((((((((rominnnnnnnnnnluuuuuu        aaaaaaaaaeddddddddddddyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyaaaaao                      eeeeeeeeeeeeeeeeeeeeetttttttdsssssssssssssssssnmlirrrrrrrrrrrrrrraotu                                   eeeeeeeeeeeeeeeeeeeeeeeeeeeeeaeo                                                       !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;R&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||_*H{{{{{{{{{{{{{{{{{{{{{qqqqqqqqqqqqqqqqqqqqqqqqq7[BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}3333333333333333333333333333333333333333333333333333333333=+-)666666666666666666C4E]PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
5sI/xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx99999999999999999999999999999999999999999999999v\OG8FWN2DSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSM<jjjjjjjjjjjjjjjj	AAAAAAAAAAAAAAAAA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>$.%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%kTf0tp"""""""""""""""""""wg1,h::::::::::::bc(delnrmmmmmmmmmmmiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiao                                             euuuuuuuuuuuuuuaooooooooooooooooooooo       ysttttttttrlllllllllllndmmmmmmmmmmmmmme uiiiiiiiaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaasp.u11111111111111"""""""""""""""""""""""""""""""g,hhhhhhhhhhhhh:bcy(ooooooooooordltnnnnnn        aaaaaaaaaeeeeeeeeeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmaaaaao                      eeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiisuuuuuuudddddddddddtrrrrrrrrrrrrrrrllllllaoin                                   eeeeeeemmmmmmmmmmmaeo                                          sMI2ASSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSD%%%%%%%%%%%%%%%%	\ffffffffffffffffffffffffffffffffffffffffff$$$$$$$$$$$$$$$$$pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppk1111111111111111111Tiiiiiiiiiiii..............""""""""""""""""""""""""""""""""0g,yh:bbbbbbbbbbetdddddddddddddddcccccccccccurrrrrrmlllllllllllllllao                                             ennnnnnnnnnnnnnaooooooooooooooooooooo       msiiiiiiii(tuddddddddddddddddddddddddddddddddde nrrrrrrraaaaaaaaaaaaaaaaaaaaooooooo                    oelllllllllllllllllllllllllllaaaaaaassssssssssss1nnnnnnnnnnnnnp..............y"wggggggggggggggg,h:mou(bbbbbbbbbbtidddddd        aaaaaaaaaellllllllllllllllllllllllllllllllllllllllllaaaaao                      eeeeeeeeeeeeeeeeeeeeerrrrrrrlsnnnnnnnnnnnnnnnnuicmttttttaord                                   eeeeeeeeeeeeeeeeeeeeeeeeeeeaeo                                                                               3BBBBBBBBBBBBBBBBBB=+++++++++++++++++++++++++++++++++])6-
4ECCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC@PsI5///////////////////////////////////////////////xO99999999999999999999999999999999999999999999999999999999999WvG8>F	M2A$N<D%%%%%%%%%%%%%%%%%%%S\fffffffffffffffffffffffffffffffffffffffffffffffffffffjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjkkkkkkkkkkkkkkkkkry1p............................"wT(g,hleiiiiiiiiiimunc::::::::::::::::tttttttttttttttao                                             eddddddddddddddaooooooooooooooooooooo                 srrrrrrrrminnnnnnnnnnluuuuuuuuuuuuuue dbbbbbbbaaaaaaaaaaaaaaaaaaaaooooooo                    oetttttttttttttttttttttttttttaaaaaaasyyyyyyyyyyyyddddddddddddddddddddddddddd1p(.............."c0g,,,,,,,,,,,onmlirrrrrrrrrrrrrrr        aaaaaaaaaetuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuaaaaao                      eeeeeeeeeeeeeeeeeeeeebhhhhhhhtsdddddddlnrmmmmmmmmmmmiiiiiiao::::::::::                                   eeeeeeeuuuuuuuuuuuaeo                                          s$I																			2AMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMD%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%k\fSyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyywwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww::::::::::::::::::::::::1p(.............."c00000000000000000g,bterlllllllllllndmmmmmmuiiiiiiiiiiiiiiiao                                             eeeeeeeeeeeeeeeeeeeeeeeaooooooooooooooooooooo       ushhhhhhhhhhhhhhhhhhrdltnnnnnnnnnnnnnne          mmmmmmmaaaaaaaaaaaaaaaaaaaaooooooo                    oeiiiiiiiiiiiiiiiiiiiiiiiiiiiaaaaaaas::::::::::::::::::::::::pyyyyyyyyyyyyyyyyyyyyyyyy"1(.,,,,,,,,,,,,,,cTuodddddddddddtrhgllllll        aaaaaaaaaeinnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnaaaaao                      eeeeeeeeeeeeeeeeeeeeemmmmmmmisssssssssssssssstdbbbbbbbbbbburrrrrraoml                                   eeeeeeennnnnnnnnnnaeo                                          ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU�L'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''JzY~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!77777777777777777777777777777777777777R&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&||||||||||||||||||||||||||||;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;*H{{{{{{{{{{{{{{{{{{{{{qqqqqqqqqqqqqqqqqqqqqqqqq_333333333333333333333333333333333333VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV}[[[[[[[[[[[[[[[[[[[[[[[[[[[+666666666666666666=BE])))))))))))))))))))))))))))))))))@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
4---------------------------------------------------------------------------------------------------------------CsIP5O/WxA>9vGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG8%$																			fFNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM<w22222222222222222222222222222222222222222222222222222222222k:\D00000000000000000000000000000000000Sm"""""""""""""""yyyyyyyyyyyy,,,,,,,,,,,,,1(h..............ciebTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTtudddddddddddddddddddddddddnrrrrrrrrrrrrrrrao                                             ellllllllllllllaooooooooooooooooooooo       nsmmmmmmmmuggggggggggtidddddddddddddde lllllllllllllllllaaaaaaaaaaaaaaaaaaaaooooooo                    oerrrrrrrrrrrrrrrrrrrrrrrrrrraaaaaaas":l,pppppppppppppppyhhhhhhhhhhhhhhhhhhhhhhhh1b(..............noooooooooouigcmtttttt        aaaaaaaaaerddddddddddddddddddddddddddddddddaaaaao                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeersllllllliiiiiiiiiimunnnnnnnnnnnnnnnnnnnnnnaooooooooooot                                   eeeeeeedddddddddddaeo                                          sfI%w																			$\MjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAk2"D0,TTTTTTTTTTTTTTTTTTTTTTTTTTh:pppppppppppppppbyyyyyyyyyyyyyyyyyyyyyyyyg1(.reminnnnnnnnnnluuuuuudddddddddddddddddSSSSSSSSSSSSSSSSSSSSSSSSSSSSao                                             ettttttttttttttaooooooooooooooooooooo       dssssssssssssssssssnmlirrrrrrrrrrrrrrrrrrrrrrre tuuuuuuuaaaaaaaaaaaaaaaaaaaaooooooo                    oecccccccccccccccccccccccccccaaaaaaash,tb":pgggggggggggggggyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy1(dolnrmmmmmmmmmmmiiiiii        aaaaaaaaaec.........................................aaaaao                      eeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuuuuuuuuustttttttrlllllllllllndmmmmmmaoui                                   eeeeeeeeeeeeeeeeeeeeeeeeeeaeo                                          bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb=+3)66666666666666666666666666666666666666666664E]BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
































OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO-sICPW5>////////////////////////////////////////////////////////////x9vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvGjFN8%wkf$\T	AAAAAAAAAAAAAAAAAAAAhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhMMMMMMMMMMMMMMMMMD02ug,"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::pppppppppppppppycccccccccccccccccccccccc11111111111111(eeeeeeeeeeerdltnnnnnnnnnnnnnnnmmmmmmmmmmmmmmmao                                             eiiiiiiiiiiiiiiaooooooooooooooooooooo                suuuuuuuudddddddddddtr.lllllllllllllle innnnnnnaaaaaaaaaaaaaaaaaaaaooooooo                    oemmmmmmmmmmmmmmmmmmmmmmmmmmmaaaaaaasghiSb,"c:ppppppppppppppppppppppppppppyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyotd.11111111111urrrrrr        aaaaaaaaaemllllllllllllllllllllllllllllllllaaaaao                      eeeeeeeeeeeeeeeeeeeeennnnnnnmsiiiiiii(tudddddddddddddddddddddddddaonr                                   eeeeeeelllllllllllaeo                                          skIIIIIIIIIIIIIIIIIIIT%w<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<$\f0AAAAAAAAAAAAAAAAAAAA	gMMMMMMMMMMMMMMMMMSD2222222222222222222222222222222222222222222222222222222222222nchb,,,,,,,,,,,,,,":p...............yyyyyyyyyyyymeu((((((((((((((((((((((tiddddddlllllllllllllllllllllllllao                                             errrrrrrrrrrrrraooooooooooooooooooooo       lsnnnnnnnnnnnnnnnnnui1mtttttttttttttte rdddddddaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaascgrrrrrrrrrrrrrrrrrrrrrrrrrrrrrhb.,":(pppppppppppppppyloiiiiiiiiiimun11111111111111111        aaaaaaaaaeeeeeeeeeeettttttttttttttttttttttttttttttttaaaaao                      eeeeeeeeeeeeeeeeeeeeedddddddddddddddddsrrrrrrrminnnnnnnnnnluuuuuuaoddddddddddddd                                   eeeeeeetttttttttttaeo                                                                                                                                                                                                                                                                                                                                                          77777777777777777777777777777777777777R&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&|!@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*H{{{{{{{{{{{{{{{{{{{{{q;[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[_}}}}}}}}}}}}}}}}}}=++++++++++++++++++++++++++++++++++])63
4EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEBWOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOsI-C>PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP5wwwwwwwwwwwwwwwwwwwwwwwwwwwwww/x9Nv\kkkkkkkkkkkkkkkkkkkTTTTTTTTTTTTTTTTTTTTGj<FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFS%f0cA$2MMMMMMMMMMMMMMMMM	d.ggggggggggggggggDh(b,"1:pppppppppppppppppppppppppenmlirrrrrrrrrrrrrrrtuuuuuuuuuuuuuuuao                                             eeeeeeeeeeeeeyyyyyyyyyyyyyyaooooooooooooooooooooo       tsddddddddlnrmmmmmmmmmmmiiiiiiiiiiiiiie                           aaaaaaaaaaaaaaaaaaaaooooooo                    oeuuuuuuuuuuuuuuuuuuuuuuuuuuuaaaaaaas.cccccccccccccccccccccccccgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggh(b,"1:ppppppppppppppppppppppppppptorlllllllllllndmmmmmm        aaaaaaaaaeuiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiaaaaao                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeusyyyyyyyyyyyyyyyyyrdltnnnnnnaoooooooooom                                   eeeeeeeiiiiiiiiiiiaeo                                          ssssssssssssssssssssI\SSSSSSSSSSSSSSSSSSSTkA88888888888888888888888888888888888888888888888888888888888wwwwwwwwwwwwwwwwwf0%.$222222222222222222222222222MMMMMMMMMMhccccccccccccccg"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""	(bbbbbbbbbbbbbbb,1:uedddddddddddtrypllllllinnnnnnnnnnnnnnnao                                             emmmmmmmmmmmmmmaooooooooooooooooooooo       issssssssssssssssstdddddddddddddddddddddddurrrrrrrrrrrrrre mlllllllaaaaaaaaaaaaaaaaaaaaooooooo                    oennnnnnnnnnnnnnnnnnnnnnnnnnnaaaaaaashhhhhhhhhhhhm".ccccccccccccccccccccccccccccgD(yb,1iooooooooooooo:tuddddddddddddddddddddddddd        aaaaaaaaaenrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrraaaaao                      eeeeeeeeeeeeeeeeeeeeelllllllnsmmmmmmmupppppppppptiddddddaolllllllllll                                   eeeeeeerrrrrrrrrrraeo                                          "+666666666666666666=E])))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
43333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333>WOBsIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII------------------------------------------CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCPTN5/x<999999999999999999999999999999999999999999999999999999999999999999999999999999\S0vGkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwwwwwwwwwwwwwwwwwhf8jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj$2%llllllllllllllllllllllllll.cyyyyyyyyyyyyyygDMMMMMMMMMMMMM(b,neeeeeeeeeeuip1mttttttrdddddddddddddddao                                             eeeeeeeeeeeeeeeeeeeeeeeeaooooooooooooooooooooo       rslllllllliiiiiiiiiimun::::::::::::::e           tttttttaaaaaaaaaaaaaaaaaaaaooooooo                    oedddddddddddddddddddddddddddaaaaaaassssssssssssssshhhhhhhhhhhy"""""""""""".............ccccccccccccccgp	(brominnnnnnnnnnluuuuuu        aaaaaaaaaed:,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,aaaaao                      eeeeeeeeeeeeeeeeeeeeetttttttdsssssssssssssssssnmlirrrrrrrrrrrrrrraotu                                   eeeeeee11111111111aeo                                          s0IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII\SSSSSSSSSSSSSSSSSSSSfkAT2wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFyD$ttttttttttttth""""""""""""p.cccccccccccccc:g	%(delnrmmmmmmmmmmmiiiiii1bbbbbbbbbbbbbbbbbbbbbbbbao                                             euuuuuuuuuuuuuuaooooooooooooooooooooo       ,sttttttttrlllllllllllndmmmmmmmmmmmmmme uiiiiiiiaaaaaaaaaaaaaaaaaaaaooooooo                    oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaasssssssssssssyuppppppppppppppph"::::::::::::.c11111111111111gM,(ooooooooooordltnnnnnn        aaaaaaaaaeeeeeeeeeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmaaaaao                      eeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiisuuuuuuudddddddddddtrbllllllaoin                                   eeeeeeemmmmmmmmmmmaeo                                                                                   pppppppppppppppppppppppppppppppppppppppppppppppppppppppp������������������������œ��������������������������������ߕ���������������������������������������������������������������������������������������������������������������`�^���Z�X�