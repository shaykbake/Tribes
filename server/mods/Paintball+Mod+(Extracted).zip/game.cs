$MODVersion = "v1.0";

$MODInfo = "<f0>Welcome to <f2>PAINTBALL! <f0>"@$MODVersion@"\n"@
           "<jc><f2>Mod By; |K0RN|\n"@
           "<f1>Special Codes By:[RR]MisterPibb\n"@
           "<f2>Have Fun!";

function AllWordsAccept(%String,%AWord) {
  %RString = "";
  for ( %i = 0; ( %CurrWord = GetWord(%String,%i) ) != -1; %i++  ) {
    if ( %CurrWord != %AWord ) {
      if ( %RString == "" ) {
        %RString = %CurrWord;
      } else {
        %RString =  %RString @ " " @ %CurrWord;
      }
    }
  }
  return %RString;
}
function CheckWord(%String,%AWord) {
  for ( %i = 0; ( %CurrWord = GetWord(%String,%i) ) != -1; %i++  ) {
    if ( %CurrWord == %AWord ) {
      return true;
    }
  }
  return false;
}

//Get rid of the annoying " base" at the end of the modlist
$ModList = AllWordsAccept($ModList,"base");

//Add the mod's version onto the end of the modlist
if (!CheckWord($ModList,$MODVersion)) {
  $ModList = $ModList @ " " @ $MODVersion;
}

if ( $DModList == "" || $DModList == -1 || !$DModList ) {
   $DModList = $ModList;
}

echo("Mod: " @ $ModList);

exec("comchat.cs");
$SensorNetworkEnabled = true;

$GuiModePlay = 1;
$GuiModeCommand = 2;
$GuiModeVictory = 3;
$GuiModeInventory = 4;
$GuiModeObjectives = 5;
$GuiModeLobby = 6;


//  Global Variables
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
// Energy each team is given at beginning of game
//---------------------------------------------------------------------------------
$DefaultTeamEnergy = "Infinite";

//---------------------------------------------------------------------------------
// Team Energy variables
//---------------------------------------------------------------------------------
$TeamEnergy[-1] = $DefaultTeamEnergy; 
$TeamEnergy[0]  = $DefaultTeamEnergy; 
$TeamEnergy[1]  = $DefaultTeamEnergy; 
$TeamEnergy[2]  = $DefaultTeamEnergy; 
$TeamEnergy[3]  = $DefaultTeamEnergy; 
$TeamEnergy[4]  = $DefaultTeamEnergy; 
$TeamEnergy[5]  = $DefaultTeamEnergy; 
$TeamEnergy[6]  = $DefaultTeamEnergy; 				
$TeamEnergy[7]  = $DefaultTeamEnergy; 

//---------------------------------------------------------------------------------
// Time in sec player must wait before he can throw a Grenade or Mine after leaving
//	a station.
//---------------------------------------------------------------------------------
$WaitThrowTime = 2;

//---------------------------------------------------------------------------------
// If 1 then Team Spending Ignored -- Team Energy is set to $MaxTeamEnergy every
// 	$secTeamEnergy.
//---------------------------------------------------------------------------------
$TeamEnergyCheat = 0;

//---------------------------------------------------------------------------------
// MAX amount team energy can reach
//---------------------------------------------------------------------------------
$MaxTeamEnergy = 700000;

//---------------------------------------------------------------------------------
//  Time player has to put flag in flagstand before it gets returned to its last
//  location. 
//---------------------------------------------------------------------------------
$flagToStandTime = 180;	  

//---------------------------------------------------------------------------------
// Amount to inc team energy every ($secTeamEnergy) seconds
//---------------------------------------------------------------------------------
$incTeamEnergy = 700;

//---------------------------------------------------------------------------------
// (Rate is sec's) Set how often TeamEnergy is incremented
//---------------------------------------------------------------------------------
$secTeamEnergy = 30;

//---------------------------------------------------------------------------------
// (Rate is sec's) Items respwan
//---------------------------------------------------------------------------------
$ItemRespawnTime = 0;

//---------------------------------------------------------------------------------
//Amount of Energy remote stations start out with
//---------------------------------------------------------------------------------
$RemoteAmmoEnergy = 2500; 
$RemoteInvEnergy = 3000;

//---------------------------------------------------------------------------------
// TEAM ENERGY -  Warn team when teammate has spent x amount - Warn team that 
//				  energy level is low when it reaches x amount 
//---------------------------------------------------------------------------------
$TeammateSpending = -4000;  //Set = to 0 if don't want the warning message
$WarnEnergyLow = 4000;	    //Set = to 0 if don't want the warning message

//---------------------------------------------------------------------------------
// Amount added to TeamEnergy when a player joins a team
//---------------------------------------------------------------------------------
$InitialPlayerEnergy = 5000;

//---------------------------------------------------------------------------------
// REMOTE TURRET
//---------------------------------------------------------------------------------
$MaxNumTurretsInBox = 2;     //Number of remote turrets allowed in the area
$TurretBoxMaxLength = 50;    //Define Max Length of the area
$TurretBoxMaxWidth =  50;    //Define Max Width of the area
$TurretBoxMaxHeight = 25;    //Define Max Height of the area

$TurretBoxMinLength = 10;	  //Define Min Length from another turret
$TurretBoxMinWidth =  10;	  //Define Min Width from another turret
$TurretBoxMinHeight = 10;    //Define Min Height from another turret

//---------------------------------------------------------------------------------
//	Object Types	
//---------------------------------------------------------------------------------
$SimTerrainObjectType    = 1 << 1;
$SimInteriorObjectType   = 1 << 2;
$SimPlayerObjectType     = 1 << 7;

$MineObjectType		    = 1 << 26;	
$MoveableObjectType	    = 1 << 22;
$VehicleObjectType	 	 = 1 << 29;  
$StaticObjectType			 = 1 << 23;	   
$ItemObjectType			 = 1 << 21;	  

//---------------------------------------------------------------------------------
// CHEATS
//---------------------------------------------------------------------------------
$ServerCheats = 0;
$TestCheats = 0;

//---------------------------------------------------------------------------------
//Respawn automatically after X sec's -  If 0..no respawn
//---------------------------------------------------------------------------------
$AutoRespawn = 0;

//---------------------------------------------------------------------------------
// Player death messages - %1 = killer's name, %2 = victim's name
//       %3 = killer's gender pronoun (his/her), %4 = victim's gender pronoun
//---------------------------------------------------------------------------------
$deathMsg[$LandingDamageType, 0]      = "%2 falls to %3 death.";
$deathMsg[$LandingDamageType, 1]      = "%2 forgot to tie %3 bungie cord.";
$deathMsg[$LandingDamageType, 2]      = "%2 bites the dust in a forceful manner.";
$deathMsg[$LandingDamageType, 3]      = "%2 fall down go boom.";
$deathMsg[$ImpactDamageType, 0]      = "%1 makes quite an impact on %2.";
$deathMsg[$ImpactDamageType, 1]      = "%2 becomes the victim of a fly-by from %1.";
$deathMsg[$ImpactDamageType, 2]      = "%2 leaves a nasty dent in %1's fender.";
$deathMsg[$ImpactDamageType, 3]      = "%1 says, 'Hey %2, you scratched my paint job!'";
$deathMsg[$BulletDamageType, 0]      = "%1 ventilates %2 with %3 chaingun.";
$deathMsg[$BulletDamageType, 1]      = "%1 gives %2 an overdose of lead.";
$deathMsg[$BulletDamageType, 2]      = "%1 fills %2 full of holes.";
$deathMsg[$BulletDamageType, 3]      = "%1 guns down %2.";
$deathMsg[$EnergyDamageType, 0]      = "%2 dies of turret trauma.";
$deathMsg[$EnergyDamageType, 1]      = "%2 is chewed to pieces by a turret.";
$deathMsg[$EnergyDamageType, 2]      = "%2 walks into a stream of turret fire.";
$deathMsg[$EnergyDamageType, 3]      = "%2 ends up on the wrong side of a turret.";
$deathMsg[$PlasmaDamageType, 0]      = "%2 feels the warm glow of %1's plasma.";
$deathMsg[$PlasmaDamageType, 1]      = "%1 gives %2 a white-hot plasma injection.";
$deathMsg[$PlasmaDamageType, 2]      = "%1 asks %2, 'Got plasma?'";
$deathMsg[$PlasmaDamageType, 3]      = "%1 gives %2 a plasma transfusion.";
$deathMsg[$ExplosionDamageType, 0]   = "%2 catches a Frisbee of Death thrown by %1.";
$deathMsg[$ExplosionDamageType, 1]   = "%1 blasts %2 with a well-placed disc.";
$deathMsg[$ExplosionDamageType, 2]   = "%1's spinfusor caught %2 by surprise.";
$deathMsg[$ExplosionDamageType, 3]   = "%2 falls victim to %1's Stormhammer.";
$deathMsg[$ShrapnelDamageType, 0]    = "%1 blows %2 up real good.";
$deathMsg[$ShrapnelDamageType, 1]    = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$ShrapnelDamageType, 2]    = "%1 gives %2 a fatal concussion.";
$deathMsg[$ShrapnelDamageType, 3]    = "%2 never saw it coming from %1.";
$deathMsg[$LaserDamageType, 0]       = "%1 adds %2 to %3 list of sniper victims.";
$deathMsg[$LaserDamageType, 1]       = "%1 fells %2 with a sniper shot.";
$deathMsg[$LaserDamageType, 2]       = "%2 becomes a victim of %1's laser rifle.";
$deathMsg[$LaserDamageType, 3]       = "%2 stayed in %1's crosshairs for too long.";
$deathMsg[$MortarDamageType, 0]      = "%1 mortars %2 into oblivion.";
$deathMsg[$MortarDamageType, 1]      = "%2 didn't see that last mortar from %1.";
$deathMsg[$MortarDamageType, 2]      = "%1 inflicts a mortal mortar wound on %2.";
$deathMsg[$MortarDamageType, 3]      = "%1's mortar takes out %2.";
$deathMsg[$BlasterDamageType, 0]     = "%1 caps %2, %2 Is now out of this round.";
$deathMsg[$BlasterDamageType, 1]     = "%1 caps %2, %2 Is now out of this round.";
$deathMsg[$BlasterDamageType, 2]     = "%1 caps %2, %2 Is now out of this round.";
$deathMsg[$BlasterDamageType, 3]     = "%1 caps %2, %2 Is now out of this round.";
$deathMsg[$ElectricityDamageType, 0] = "%2 gets zapped with %1's ELF gun.";
$deathMsg[$ElectricityDamageType, 1] = "%1 gives %2 a nasty jolt.";
$deathMsg[$ElectricityDamageType, 2] = "%2 gets a real shock out of meeting %1.";
$deathMsg[$ElectricityDamageType, 3] = "%1 short-circuits %2's systems.";
$deathMsg[$CrushDamageType, 0]		 = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 1]		 = "%2 is crushed.";
$deathMsg[$CrushDamageType, 2]		 = "%2 gets smushed flat.";
$deathMsg[$CrushDamageType, 3]		 = "%2 gets caught in the machinery.";
$deathMsg[$DebrisDamageType, 0]		 = "%2 is a victim among the wreckage.";
$deathMsg[$DebrisDamageType, 1]		 = "%2 is killed by debris.";
$deathMsg[$DebrisDamageType, 2]		 = "%2 becomes a victim of collateral damage.";
$deathMsg[$DebrisDamageType, 3]		 = "%2 got too close to the exploding stuff.";
$deathMsg[$MissileDamageType, 0]	    = "%2 takes a missile up the keister.";
$deathMsg[$MissileDamageType, 1]	    = "%2 gets shot down.";
$deathMsg[$MissileDamageType, 2]	    = "%2 gets real friendly with a rocket.";
$deathMsg[$MissileDamageType, 3]	    = "%2 feels the burn from a warhead.";
$deathMsg[$MineDamageType, 0]	       = "%1 blows %2 up real good.";
$deathMsg[$MineDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$MineDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$MineDamageType, 3]	       = "%2 never saw it coming from %1.";

// "you just killed yourself" messages
//   %1 = player name,  %2 = player gender pronoun

$deathMsg[-2,0]						 = "%1 caps %1, %1 Is now out of this round.";
$deathMsg[-2,1]						 = "%1 caps %1, %1 Is now out of this round.";
$deathMsg[-2,2]						 = "%1 caps %1, %1 Is now out of this round.";
$deathMsg[-2,3]						 = "%1 caps %1, %1 Is now out of this round.";

$numDeathMsgs = 4;
//---------------------------------------------------------------------------------

$spawnBuyList[0] = LightArmor;
$spawnBuyList[1] = Delta;
$spawnBuyList[2] = "";
$spawnBuyList[3] = "";
$spawnBuyList[4] = "";
$spawnBuyList[5] = "";

function remotePlayMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModePlay);
   }
}

function remoteCommandMode(%clientId)
{
   // can't switch to command mode while a server menu is up
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);  // force the bandwidth to be full command
		if(%clientId.observerMode != "pregame")
		   checkControlUnmount(%clientId);
		Client::setGuiMode(%clientId, $GuiModeCommand);
   }
}

function remoteInventoryMode(%clientId)
{
   if(!%clientId.guiLock && !Observer::isObserver(%clientId))
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeInventory);
   }
}

function remoteObjectivesMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeObjectives);
   }
}

function remoteScoresOn(%clientId)
{
   if(!%clientId.menuMode)
      Game::menuRequest(%clientId);
}

function remoteScoresOff(%clientId)
{
   Client::cancelMenu(%clientId);
}

function remoteToggleCommandMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeCommand)
		remoteCommandMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleInventoryMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeInventory)
		remoteInventoryMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleObjectivesMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeObjectives)
		remoteObjectivesMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function Time::getMinutes(%simTime)
{
   return floor(%simTime / 60);
}

function Time::getSeconds(%simTime)
{
   return %simTime % 60;
}

function Game::pickRandomSpawn(%team)
{
   %group = nameToID("MissionGroup/Teams/team" @ %team @ "/DropPoints/Random");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;
  	%spawnIdx = floor(getRandom() * (%count - 0.1));
  	%value = %count;
	for(%i = %spawnIdx; %i < %value; %i++) {
		%set = newObject("set",SimSet);
		%obj = Group::getObject(%group, %i);
		if(containerBoxFillSet(%set,$SimPlayerObjectType|$VehicleObjectType,GameBase::getPosition(%obj),2,2,4,0) == 0) {
			deleteObject(%set);
			return %obj;		
		}
		if(%i == %count - 1) {
			%i = -1;
			%value = %spawnIdx;
		}
		deleteObject(%set);
	}
   return false;
}

function Game::pickStartSpawn(%team)
{
   %group = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\DropPoints\\Start");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;

   %spawnIdx = $lastTeamSpawn[%team] + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   $lastTeamSpawn[%team] = %spawnIdx;
   return Group::getObject(%group, %spawnIdx);
}

function Game::pickTeamSpawn(%team, %respawn)
{
   if(%respawn)
      return Game::pickRandomSpawn(%team);
   else
   {
      %spawn = Game::pickStartSpawn(%team);
      if(%spawn == -1)
         return Game::pickRandomSpawn(%team);
      return %spawn;
   }
}

function Game::pickObserverSpawn(%client)
{
   %group = nameToID("MissionGroup\\ObserverDropPoints");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team" @ Client::getTeam(%client) @ "\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team0\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      return -1;
   %spawnIdx = %client.lastObserverSpawn + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   %client.lastObserverSpawn = %spawnIdx;
	return Group::getObject(%group, %spawnIdx);
}

function UpdateClientTimes(%time)
{
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      remoteEval(%cl, "setTime", -%time);
}

function Game::notifyMatchStart(%time)
{
   messageAll(0, "Match starts in " @ %time @ " seconds.");
   UpdateClientTimes(%time);
}

function Game::startMatch()
{
   $matchStarted = true;
   $missionStartTime = getSimTime();
   messageAll(0, "Match started.");
	Game::resetScores();	

   %numTeams = getNumTeams();
   for(%i = 0; %i < %numTeams; %i = %i + 1) {
		if($TeamEnergy[%i] != "Infinite")
			schedule("replenishTeamEnergy(" @ %i @ ");", $secTeamEnergy);
	}

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
		if(%cl.observerMode == "pregame")
      {
         %cl.observerMode = "";
         Client::setControlObject(%cl, Client::getOwnedObject(%cl));
      }
   	Game::refreshClientScore(%cl);
	}
   Game::checkTimeLimit();
}

function Game::pickPlayerSpawn(%clientId, %respawn)
{
   return Game::pickTeamSpawn(Client::getTeam(%clientId), %respawn);
}

function Game::playerSpawn(%clientId, %respawn)
{
   if(!$ghosting)
      return false;

	Client::clearItemShopping(%clientId);
   %spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);
   if(!%respawn)
   {
      // initial drop
      bottomprint(%clientId, "<jc><f0>Mission: <f1>" @ $missionName @ "   <f0>Mission Type: <f1>" @ $Game::missionType @ "\n<f0>Press <f1>'O'<f0> for specific objectives.", 5);
   }
	if(%spawnMarker) {   
		%clientId.guiLock = "";
	 	%clientId.dead = "";
	   if(%spawnMarker == -1)
	   {
	      %spawnPos = "0 0 300";
	      %spawnRot = "0 0 0";
	   }
	   else
	   {
	      %spawnPos = GameBase::getPosition(%spawnMarker);
	      %spawnRot = GameBase::getRotation(%spawnMarker);
	   }

		if(!String::ICompare(Client::getGender(%clientId), "Male"))
	      %armor = "larmor";
	   else
	      %armor = "lfemale";

	   %pl = spawnPlayer(%armor, %spawnPos, %spawnRot);
	   echo("SPAWN: cl:" @ %clientId @ " pl:" @ %pl @ " marker:" @ %spawnMarker @ " armor:" @ %armor);
	   if(%pl != -1)
	   {
	      GameBase::setTeam(%pl, Client::getTeam(%clientId));
	      Client::setOwnedObject(%clientId, %pl);
	      Game::playerSpawned(%pl, %clientId, %armor, %respawn);
	      
	      if($matchStarted)
	         Client::setControlObject(%clientId, %pl);
	      else
	      {
	         %clientId.observerMode = "pregame";
	         Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
	         Observer::setOrbitObject(%clientId, %pl, 3, 3, 3);
	      }
	   }
      return true;
	}
	else {
		Client::sendMessage(%clientId,0,"Sorry No Respawn Positions Are Empty - Try again later ");
      return false;
	}
}

function Game::playerSpawned(%pl, %clientId, %armor)
{						  
	%clientId.spawn= 1;
	%max = getNumItems();
   for(%i = 0; (%item = $spawnBuyList[%i]) != ""; %i++)
   {
		buyItem(%clientId,%item);	
		if(%item.className == Weapon) 
			%clientId.spawnWeapon = %item;
	}
	%clientId.spawn= "";
	if(%clientId.spawnWeapon != "") {
		Player::useItem(%pl,%clientId.spawnWeapon);	
   	%clientId.spawnWeapon="";
	}
} 

function Game::autoRespawn(%client)
{
	if(%client.dead == 1)
		Game::playerSpawn(%client, "true");
}

function onServerGhostAlwaysDone()
{
}

function Game::initialMissionDrop(%clientId)
{
	Client::setGuiMode(%clientId, $GuiModePlay);

   if($Server::TourneyMode)
      GameBase::setTeam(%clientId, -1);
   else
   {
      if(%clientId.observerMode == "observerFly" || %clientId.observerMode == "observerOrbit")
      {
	      %clientId.observerMode = "observerOrbit";
	      %clientId.guiLock = "";
         Observer::jump(%clientId);
         return;
      }
      %numTeams = getNumTeams();
      %curTeam = Client::getTeam(%clientId);

      if(%curTeam >= %numTeams || (%curTeam == -1 && (%numTeams < 2 || $Server::AutoAssignTeams)) )
         Game::assignClientTeam(%clientId);
   }    
	Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
   %camSpawn = Game::pickObserverSpawn(%clientId);
   Observer::setFlyMode(%clientId, GameBase::getPosition(%camSpawn), 
	   GameBase::getRotation(%camSpawn), true, true);

   if(Client::getTeam(%clientId) == -1)
   {
      %clientId.observerMode = "pickingTeam";

      if($Server::TourneyMode && ($matchStarted || $matchStarting))
      {
         %clientId.observerMode = "observerFly";
         return;
      }
      else if($Server::TourneyMode)
      {
         if($Server::TeamDamageScale)
            %td = "ENABLED";
         else
            %td = "DISABLED";
         bottomprint(%clientId, "<jc><f1>Server is running in Competition Mode\nPick a team.\nTeam damage is " @ %td, 0);
      }
      Client::buildMenu(%clientId, "Pick a team:", "InitialPickTeam");
      Client::addMenuItem(%clientId, "0Observe", -2);
      Client::addMenuItem(%clientId, "1Automatic", -1);
      for(%i = 0; %i < getNumTeams(); %i = %i + 1)
         Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
      %clientId.justConnected = "";
   }
   else 
   {
      Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
      if(%clientId.justConnected)
      {
         centerprint(%clientId, $Server::JoinMOTD, 0);
         %clientId.observerMode = "justJoined";
         %clientId.justConnected = "";
      }
      else if(%clientId.observerMode == "justJoined")
      {
         centerprint(%clientId, "");
         %clientId.observerMode = "";
         Game::playerSpawn(%clientId, false);
      }
      else
         Game::playerSpawn(%clientId, false);
	}
	if($TeamEnergy[Client::getTeam(%clientId)] != "Infinite")
		$TeamEnergy[Client::getTeam(%clientId)] += $InitialPlayerEnergy;
	%clientId.teamEnergy = 0;
}

function processMenuInitialPickTeam(%clientId, %team)
{
   if($Server::TourneyMode && $matchStarted)
      %team = -2;

   if(%team == -2)
   {
      Observer::enterObserverMode(%clientId);
   }
   if(%team == -1)
   {
      Game::assignClientTeam(%clientId);
      %team = Client::getTeam(%clientId);
   }
   if(%team != -2)
   {
      GameBase::setTeam(%clientId, %team);
		if($TeamEnergy[%team] != "Infinite")
			$TeamEnergy[%team] += $InitialPlayerEnergy;
      %clientId.teamEnergy = 0;
      Client::setControlObject(%clientId, -1);
      Game::playerSpawn(%clientId, false);
   }
   if($Server::TourneyMode && !$CountdownStarted)
   {
      if(%team != -2)
      {
         bottomprint(%clientId, "<f1><jc>Press FIRE when ready.", 0);
         %clientId.notready = true;
         %clientId.notreadyCount = "";
      }
      else
      {
         bottomprint(%clientId, "", 0);
         %clientId.notready = "";
         %clientId.notreadyCount = "";
      }
   }
}

function Game::ForceTourneyMatchStart()
{
   %playerCount = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pregame")
         %playerCount++;
   }
   if(%playerCount == 0)
      return;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")   
         processMenuInitialPickTeam(%cl, -2); // throw these guys into observer
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
   }
   Server::Countdown(30);
}

function Game::CheckTourneyMatchStart()
{
   if($CountdownStarted || $matchStarted)
      return;
   
   // loop through all the clients and see if any are still notready
   %playerCount = 0;
   %notReadyCount = 0;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")
      {
         %notReady[%notReadyCount] = %cl;
         %notReadyCount++;
      }   
      else if(%cl.observerMode == "pregame")
      {
         if(%cl.notready)
         {
            %notReady[%notReadyCount] = %cl;
            %notReadyCount++;
         }
         else
            %playerCount++;
      }
   }
   if(%notReadyCount)
   {
      if(%notReadyCount == 1)
         MessageAll(0, Client::getName(%notReady[0]) @ " is holding things up!");
      else if(%notReadyCount < 4)
      {
         for(%i = 0; %i < %notReadyCount - 2; %i++)
            %str = Client::getName(%notReady[%i]) @ ", " @ %str;

         %str = %str @ Client::getName(%notReady[%i]) @ " and " @ Client::getName(%notReady[%i+1]) 
                     @ " are holding things up!";
         MessageAll(0, %str);
      }
      return;
   }

   if(%playerCount != 0)
   {
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
      Server::Countdown(30);
   }
}


function Game::checkTimeLimit()
{
   // if no timeLimit set or timeLimit set to 0,
   // just reschedule the check for a minute hence
   $timeLimitReached = false;

   if(!$Server::timeLimit)
   {
      schedule("Game::checkTimeLimit();", 60);
      return;
   }
   %curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
   if(%curTimeLeft <= 0 && $matchStarted)
   {
      echo("GAME: Timelimit reached.");
      $timeLimitReached = true;
      Server::nextMission();
   }
   else
   {
      schedule("Game::checkTimeLimit();", 20);
      UpdateClientTimes(%curTimeLeft);
   }
}

function Game::resetScores(%client)
{
	if(%client == "") {
	   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
	      %cl.scoreKills = 0;
   	   %cl.scoreDeaths = 0;
			%cl.ratio = 0;
      	%cl.score = 0;
		}
	}
	else {
      %client.scoreKills = 0;
  	   %client.scoreDeaths = 0;
		%client.ratio = 0;
     	%client.score = 0;
	}
}

function remoteSetArmor(%player, %armorType)
{
	if ($ServerCheats) {
		checkMax(Player::getClient(%player),%armorType);
	   Player::setArmor(%player, %armorType);
	}
	else if($TestCheats) {
	   Player::setArmor(%player, %armorType);
	}
}


function Game::onPlayerConnected(%playerId)
{
   %playerId.scoreKills = 0;
   %playerId.scoreDeaths = 0;
	%playerId.score = 0;
   %playerId.justConnected = true;
   $menuMode[%playerId] = "None";
   Game::refreshClientScore(%playerId);
}

function Game::assignClientTeam(%playerId)
{
   if($teamplay)
   {
      %name = Client::getName(%playerId);
      %numTeams = getNumTeams();
      if($teamPreset[%name] != "")
      {
         if($teamPreset[%name] < %numTeams)
         {
            GameBase::setTeam(%playerId, $teamPreset[%name]);
            echo(Client::getName(%playerId), " was preset to team ", $teamPreset[%name]);
            return;
         }            
      }
      %numPlayers = getNumClients();
      for(%i = 0; %i < %numTeams; %i = %i + 1)
         %numTeamPlayers[%i] = 0;

      for(%i = 0; %i < %numPlayers; %i = %i + 1)
      {
         %pl = getClientByIndex(%i);
         if(%pl != %playerId)
         {
            %team = Client::getTeam(%pl);
            %numTeamPlayers[%team] = %numTeamPlayers[%team] + 1;
         }
      }
      %leastPlayers = %numTeamPlayers[0];
      %leastTeam = 0;
      for(%i = 1; %i < %numTeams; %i = %i + 1)
      {
         if( (%numTeamPlayers[%i] < %leastPlayers) || 
            ( (%numTeamPlayers[%i] == %leastPlayers) && 
            ($teamScore[%i] < $teamScore[%leastTeam] ) ))
         {
            %leastTeam = %i;
            %leastPlayers = %numTeamPlayers;
         }
      }
      GameBase::setTeam(%playerId, %leastTeam);
      echo(Client::getName(%playerId), " was automatically assigned to team ", %leastTeam);
   }
   else
   {
      GameBase::setTeam(%playerId, 0);
   }
}

function Client::onKilled(%playerId, %killerId, %damageType)
{
   echo("GAME: kill " @ %killerId @ " " @ %playerId @ " " @ %damageType);
   %playerId.guiLock = true;
   Client::setGuiMode(%playerId, $GuiModePlay);
	if(!String::ICompare(Client::getGender(%playerId), "Male"))
   {
      %playerGender = "his";
   }
	else
	{
		%playerGender = "her";
	}
	%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
	%victimName = Client::getName(%playerId);


   if(!%killerId)
   {
      messageAll(0, strcat(%victimName, " dies."), $DeathMessageMask);
      %playerId.scoreDeaths++;
  }
   else if(%killerId == %playerId)
   {
	  %oopsMsg = sprintf($deathMsg[-2, %ridx], %victimName, %playerGender);
      messageAll(1, %oopsMsg, $DeathMessageMask);
      %playerId.scoreDeaths++;
      %playerId.score--;
      Game::refreshClientScore(%playerId);
   }
   else
   {
		if(!String::ICompare(Client::getGender(%killerId), "Male"))
		{
			%killerGender = "his";
		}
		else
		{
			%killerGender = "her";
		}
      if($teamplay && (Client::getTeam(%killerId) == Client::getTeam(%playerId)))
      {
		if(%damageType != $MineDamageType) 
	    	messageAll(0, strcat(Client::getName(%killerId), 
   	        " mows down ", %killerGender, " teammate, ", %victimName), $DeathMessageMask);
		else 
	         messageAll(0, strcat(Client::getName(%killerId), 
   	     	" killed ", %killerGender, " teammate, ", %victimName ," with a mine."), $DeathMessageMask);
		 %killerId.scoreDeaths++;
       %killerId.score--;
       Game::refreshClientScore(%killerId);
      }
      else
      {
	     %obitMsg = sprintf($deathMsg[%damageType, %ridx], Client::getName(%killerId),
	       %victimName, %killerGender, %playerGender);
         messageAll(1, %obitMsg, $DeathMessageMask);
         %killerId.scoreKills++;
         %playerId.scoreDeaths++;  // test play mode
         %killerId.score++;
         Game::refreshClientScore(%killerId);
         Game::refreshClientScore(%playerId);
      }
   }
   Game::clientKilled(%playerId, %killerId);
}

function Game::clientKilled(%playerId, %killerId)
{
   // do nothing
}

function Client::leaveGame(%clientId)
{
   // do nothing
}

function Player::enterMissionArea(%player)
{
   echo("Player " @ %player @ " entered the mission area.");
}

function Player::leaveMissionArea(%player)
{
   echo("Player " @ %player @ " left the mission area.");
}

function GameBase::getHeatFactor(%this)
{
   return 0.0;
}

	ݨ��������������������������������������W�~����8Ɂܹ������������������������������������������������������ͳ����������������������������������������������������������������������`_^���Z���������������������������������������������������������������Q�����לּ���۩���彿��������ٯֵ����J���ߴ��#���������������������������������������������������aa���z9 �	oaaaaaaaaaaaaaaaaaaaaooaaaaaaaaaaaaaaaaaaaaaaaaaaau7????????????????????????????????????????????????????oaaaaaaaaaaaaaaaaaaaa1ooua														doaa	DDDDDDDDDDDDDDDDDDDduooaaaaaaaaaaaaaaaaaaaaaaaaaaa1doaauooDC211111111111111111																																																									auuuuuuuuuuuuuudoaaudddddddddddddddddddooaaaaaaaaaaaaaaaaaaaaaaaaaaam	1udoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooumaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaWWWWWWWWWWWWWWdoaa	yvRu+LC.4D2222222222222222222222222222221111111111111111111dmooaaaaaaaaaaaaaaaaaaaaaaaaaaauuuuuuuuuuuuuuuuudoaamooyccccccccccccccccccccccccccccccccccccccccc																												1amudoaaccccccccccccccmmmmmmmmmmmmdddddddddddddddddddooooooooaaaaaaauuvTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTCUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU'333333333333333333333333333333333333333333333333333333333333&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&72+LRRRRRRRRRRRRRRRRR.444444444444444444444444444444444444444444444444444444444444444Dyccccccccccccccmmmmmmmmmmmmmmmmmmdddddddoaaaaaaaaaaaaaaaaaaaaaaaaaa							ooooooooooooooooooooooooouuuuuuuuuuuuuuuuuucaaaaaaa1mmmmmmmdoooooooaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"""""""""""""""""""""""""""""""""""""""""""""""""""""""""1yudddddddcooooooooaaaaaaammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm							udoooooooaaaaaaaaecccccccoo2222222222222222222222222vTTTTTTTTTTTTTTTTTTTffffffffffffffffffffffffCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCE1...........................+LLLLLLLLLLLLLLLLLLLLLLLLLLLLRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"""""""""""muuuuuuuuuuuuuuuuuuaeeeeeeec																														Wdddddddoaaaaaaaeeeeeeeeeeeeuuuuuuuuuuuuuucmmmmmmmddddddddddddoooooooaaaaaaaaeyyyyyyyoo																			fu11111111111111111cccccccccccddddddddddddddddddddaeeeeeeey"mmmmmmmmmmmmmmmmmmoaaaaaaaeecudlDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDoooooooaaaaaaaaemmmmmmmoooooooooooooooooooooooooooooooooooo[[[[[[[[[[[[[[[[[[[[[[[[[[jP''''''''''''''''''''''''''''''''''''''''
F43222222222222222222222222222222vTTTTTTTTTTTTTTTTTTTTTTTTCCCCCCCCCCCCCCCCCCCCCCCCCE.1gggggggggggggggggggggggggggg+++++++++++++++++++++++++++Lc																			dyfDRRRRRRRRRRRRRRRRRuuuuuuuuuuuulllllllaeeeeeeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmmoaaaaaaaee"ddddddddddddcmuuuuuuuuuuuuuuuuuuuuloooooooaaaaaaaaeeeeeeeeeeeeeeeeeooooooooy1"																			ggggggggggggfWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWmddddddddddddddcccccccaeeeeeeeeeeeeeeeeeullllllllllllloaaaaaaaeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmdlcccccccccccccoooooooaaeeeeeeeuuuuuuuuuuuuuooE,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,222222222222222222222222222222yhCTvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv............................D+m1""""""""""""""f																						lllllllllllllllllgaaaaaaaeudddddddddddddddddddoooooooaeeeeeeecccccccccccccccmmmmmmmmmmmmmmmmmmmmmmllllllllllllllllllllllllllllllllllllLuuuuuuuuuuuuuoaaaaaaaeedddddddddddddoooooooaafyhccccccccccccccccccc1mmmmmmmmmmmmmmmmm"""""""""""""""""""""""""R											edlllllllllllllllllllllllllllooaeuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuumgcddddddddddddddoaeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuullllllloaaaaaaaaaaaaaaaaaaaaaee'OB>\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\;H62:}KqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqJX{UVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV8z?99999999999999999999999999****************************************************************************************************jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj[.4PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
E,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,WFyvCCCCCCCCCCCCCCCCCCCCCCCCCCCTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT3333333333333333333333333333333333333333333333333333Dffffffffffffhhhhhhhhhhhhhhhhhhhg1"R+dmuclllllllllllllllllllloooooooooooooooooooooaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooddddddddddddu	lmaeeeeeeeeeeecccccccccccccccccccccccccccccccccoaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeyhpgf"""""""""""""""""""ddddddddddddu	1lmmmmmmmmmmmmmmmmmoaaaaaaaaaaaaaaaaaaaaaeecccccccoooooooooooooooooooooaaaaaaaaaaaaaaaaaaaaaaaaaaLdmueclllllllllllllllllllllllllllooaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee IwwwwwwwwwwwwwwwwwwwwwwwwwwwA2.:/E,RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR$vCCCCCCCCCCCCCCCCCCCCCTTTTTTTTTTTTTTTTTTTTTTTTTTTTTThhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&""""""""""""""""yyyyyyyyyyyyyyyyyyyyyyyyyyyypgLDfffffffffffffffffff	mmmmmmmmmmmmmmcdoaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeul       oaaaaaaaaaaaaaaaaaaaaaeemmmmmmmmmmmmc111111111111111111111111ld       oooooooooooooooooooooaaeu                           ooyh+"""""""""""""""""""""""""""""""""mmmmmmmmmmmmmmmmmpcccccccccccccccccccggggggggggggggggggggggl1faeuuuuuuuuuuuuuu                                 oaeddddddddddddddddddddd            clmuuuuuuuuuuuuuuuuuuoaeeeeeeeeeeeeeeeeeeeeed														       oaaaaaaaaaaaaaaaaaaaaaeeI-xO=>'EjB\\\\\\\\\\\\\\\\\\\\\\\\\\4444444444444444444444444444444;[WPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
TTTTTTTTTTTTTTTTTTTTTTTTTTTA2.:/wy$RCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC,vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvL7FFFFFFFFFFFFFFFFFFF+++++++++++++++++++++++++"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhl1pucdmmmmmmmmmmmmmmmmmmmmmmmmm       oooooooooooooooooooooaae	g                           ooulddddddddddddddddddddddddcaefm                                 oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  "yyyyyyyyyyyyyyy1111111111111111111DDDDDDDDDDDDDDDDuhhhhhhhhhhhhhhhhhhd																														lfpppppppppppppppppoaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeecm       oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeedguuuuuuuuuuuulmmmmmmmmmmm       oooooooooooooooooooooaaec                           oo$ESI-TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTA2.:/wwwwwwwwwwwwwwwwwwwwwwwwwwwy,CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCRvDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDL3+"	1111111111111111111111111111111111111111111111111111111111111hggggggggggggggggggggggggggggggggggffffffffffffdmuaecl                                 oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                        nnnnnnnnnnnntmpcdddddddoaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeul       oaaaaaaaaaaaaaaaaaaaaaee																																								"yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy1111111111hgggggggggggggggggggggggggmnctttttttttttppppppppppppppppppld       oooooooooooooooooooooaaeu                           oooooooooooooooooooooormsccccccccccccccccccccccccnltaeuf                                 oaeddddddddddddddddddddd  j!$N]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]UVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV5555555555555555555555555555555555555666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHO<>xk=24'B\WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[P777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777SI-TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTAE3
:/wwwwwwwwwwwwwwwwwwwwwwwwwww,C."DRRRRRRRRRRRRRRRRRRRRRRRRRRRRvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvL	pppppppppppppppppppppppppppppppppppyyyyyyyyyyyy1hmmmmmmmmmmcrrrrrrrrrrrsllllllllllllllunnnnnnnoaeeeeeeeeeeeeeeeeeeeeedtfg       oaaaaaaaaaaaaaaaaaaaaaeemccccccccccccccccccccccccccccccclrusdddddddddddddddddddddddddddddddn       oooooooooooooooooooooaaet                           oo++++++++++++++++++++++++++++++++++++++++++++++++"fppppppppppppppppp	cy11111111111mlllllllllllluuuuuuuuuudrrrrrrrrrrrrrrrrrrhsaetttttttttttttt                                 oaennnnnnnnnnnnnnnnnnnnn            lcumddddddddddddggggggggggtrrrrrrroaeeeeeeeeeeeeeeeeeeeeenssssssssssssss       oaaaaaaaaaaaaaaaaaaaaaeeAAAAAAAAAAAAAAAAAAAA)2$CCCCCCCCCCCCCCCCCCCCCCCCSI-TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTMMMMMMMMMMMMMMMMMMMMMMMMMF:/wwwwwwwwwwwwwwwwwwwwwwwwwww,EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDR.vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv++++++++++++++++++++++++++++++++++++++fp"l	yuuuuuuuuuuudcg1mttttttttttttnnnnnnnnnnnnnnnnnnnnnnnr       oooooooooooooooooooooaaes                           ooudlhhhhhhhhhhhtcnmmmmmmmmmmmmmmmmmmmmmmmmmaessssssssss                                 oaerrrrrrrrrrrrrrrrrrrrr                                               pppppppppppppppppppLLLLLLLLLLLLLLLLLLgf"	dddddddddhyutlnnnnnnnnnnnnnnnnnnnnnnnncsmmmmmmmoaeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrr       oaaaaaaaaaaaaaaaaaaaaaeedddddddd1itttttttttnuuuuuuuuuuuuuulsssssssssssrccccccccccm       oooooooooooooooooooooaaeeeeeeeeeeee                           ooooooo3N]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]Gj!O<>xk=4S%WBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\;&['P::::::::::::::::::::)2$CCCCCCCCCCCCCCCCCCCCCCCCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA-TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTMMMMMMMMMMMMMMMMMMMMMMMMMFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFIIIIIIIIIIIIIIII,wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww/ELDR.v+++++++++++++++"pppppppppppppppppppppppppppppppppppddddddddddddddddddg1f	httttttttniiiiiiiiiiiiiiiiiiiiiisurllllllllllllllllllllaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnyyyyyyyyyyyyyyyyyyyyysirrrrrrrrrrrrrrrrrruuuuuuuuuuuulllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1"pppppppppppppppttttttttttttttttttttttttttttttttttn	ggggggggggggggdsyfrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiimucl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonstrddddddddddhhhhhhhhhhhhhhhhhhhmicccccccccaeeeeeeeeeeeu                                     oael                                                        (0S%b:
)2$CCCCCCCCCCCCCCCCCCCCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTMMMMMMMMMMMMMMMMMMMMMMMMM-I,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,////////////////////////////wwwwwwwwwwwwwwwwwwwwwwwwwwwpvEDRRRRRRRRRRRRRRRRRRR	1"""""""""""""""""""""............................................syyyyyyyyyyyyyyyyyyrnnnnnnnnnnttttttttttttdmhgcccccccccccccccccciiiiiioaelllllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeuussssssssssssssrnnnnnnnnnnttttttttttttdmfccccccccccccccccccil            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeee            oooooooooooooooooooooaaaaaaaaaaaaaa"ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppy	1111111111111111111u++++++++++++++++++++++++++++hhhhhhhhhhhhhhhhhnstrddddddddddffffffffffffffffffffffffffffffffffffmiceeeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnntudsgrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiimoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  �6|@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@������������������������������������������������Yݣ���������������������������������������~��������������������������������������������������������Ɂ���ͳ������������������������������������������������������������������_����`^���Z���������������������������������������������������������������Q�ջ��ꬼ����������������������������������������������x����彿��������#�ֵ���ٲ��ߴ������������������������������������������������������� �������������������������������������������������������������K?}JXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq88888888888888888888888888888888888888z{V9*5UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUFHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH3N]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]Gj!O<>77777777777777777777777777777777
=4WBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\;&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&['PkL(0S%b::::::::::::::::::::::::/2$CCCCCCCCCCCCCCCCCCCCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA))))))))))))))))))))))))))))))))))))))))))))))))))MMMMMMMMMMMMMMMMMMMMMMMMM-I,TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTvwDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDE1"ppppppppppppphy																nnnnnnnnnnnnnnnnnnn+Rtfffffffffffffffddddddddddddddggggggggggggggggguuuuuuuusirrrrrrrrrrrrrrrrrrllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedttttttttttttttttttnnnnnnnnnnnnnnnnnnnnniuuuuuuuuuslrrrrrrrrrrrrrrrrrrrrcccccccccccc            oooooooooooooooooooooaaem                                oop	1"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""fhyyyyyyyyyyyyyddddddddddddddddddddddddddddddddddddddddddddddddddd...............ggggggggtinnnnnnnnnnnnnnnnnnnnnnluuuuuuuuuuuscraemmmmmmmmmm                                     oaeeeeeeeeeeee                                        diiiiiiiiiiiiiiiiiiiiiiiiitlnnnnnnnnnnnnnnnnnnnnnnnncumssssssoaeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrr             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0:L(((((((((((((((((((((((((((((((((((((((($%bSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS/222222222222222222222222MMMMMMMMMMMMMMMMMMMMAC,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,)D-IIIIIIIIIIIIIIIIIIIIIIIII+vwT																																																						"pf1yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhdiiiiiiiiiiiiiiiii.EEEEEEEEEtlnnnnnnnnnnnnnnnnnnnnnnnncumssssssssssss            oaaaaaaaaaaaaaaaaaaaaaeer            oooooooooooooooooooooaaddddddddddggggggggtinnnnnnnnnnnnnnnnnnnnnnluuuuuuuuuuuscerm                                ooaeeeeeeeeeeee                                     ffffffffffffffff"p															yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy1dhhhhhhhhhhhhhhhhhhgggggggggggggggggggggggggggggggggggggggggggggggttttttttttnnnnnnnnnnnnnnnnnnnnniuuuuuuuuuslrrrrrrrrrrroaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnRRRRRRRRRRRRRRRRRRRRRRRuuuuuuuusirrrrrrrrrrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeePF3N]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]Gj!O<>b4
B=\WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxA:L(((((((((((((((((((((((((((((((((((((((('$%0IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII/222222222222222222222222MMMMMMMMMMMMMMMMMMMMS.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,)D-Cpw+++++++++++++++++++++++++++vvvvvvvvvvvvvvvvvvvvvvvvvTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT"fgggggggggggggggy	t1hnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnduRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRssssssssssrrrrrrrrrrrrrrrrrrrimmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonutsdrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmmciaeeeeeeeeeeeeeeeeeee                                     oael                                 "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyypppppppppppppppppppgggggggggggggggffffffffffffff	1uEhsnrttttttttttttdmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmccccccccccccccccccccccccccccccccoaeliiiiiiiiiiiiiiiiiiiii             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuuusnrttttttttttttdmmmmmmmmmmmmmcccccccccccccccccccccccccccl            oaaaaaaaaaaaaaaaaaaaaaeei            oooooooooooooooooooooaa%%%%%%%%%%%%%%%%%%%%A:L(k$b-IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII/222222222222222222222222M0R.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,)DSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSwwwwwwwwwwwwwwwwwwwwwwwww+Cvvvvvvvvvvvvvvvyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"ETTTTTTTTTTTTTTTTTTTgpppppppppf																														1nutsdrrrrrrrrrrrrrhhhhhhhhhhhhhhhhhhhhhmmmmmmmmceiiiiiiiiiii                                ooael                                     nnnnnnnnnnnnnntttttttttduuuuuuuuuuuuuuuuuussssssssssrrrrrrrrrrrrrrrrrrrimoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                              gggggggggggggggyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"npfttttttttttttt	ddddddddddddddddddddddddddddddd111111111111111111uuuuuuuusirllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedthnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnniulsssssssssssrcccccccccccc            oooooooooooooooooooooaaem                                oo<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<@VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV555555555555555555555555555555555555555555555|6HUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777PF3N]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]Gj!O&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&$B4\

























=;W[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx>MMMMMMMMMMMMMMMMMMMMA:L(kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk%D-IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII/222222222222222222222222bER.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,)0yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyCwS+++++++++++++++++++ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggvvvvvvvvvvvvvvvvd"phf																											ttttttttniiiiiiiiiiiiiilllllllllllllllllllucsaemr                                     oaeeeeeeeeeeee                                          dddddddd1itlnnnnnnnnnnnnnnnnnnnnnnnncccccccccmuuuuuuoaeeeeeeeeeeeesssssssssssssssssssss             oaeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrryyyyyyyyyyyyygTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT"""""""""""""""""hhhhhhhhhhhhhhhh	ppppppppppdddddddd1fitlnnnnnnnnnnnnnnnnnnnnnnnncccccccccmuuuuuuuuuuuu            oaaaaaaaaaaaaaaaaaaaaaees            oooooooooooooooooooooaadrrrrrrrrrrrrrrrrrrrrrrrrrrrttttttttniiiiiiiiiiiiiilllllllllllllllllllucesm                                ooaeeeeeeeeeeee                                     ''''''''''''''''''''''''MMMMMMMMMMMMMMMMMMMMA:L($)D-IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII/2%%%%%%%%%%%%%%%%%%%%%%%%%%%%ER.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,bbbbbbbbbbbbbCCCCCCCCCCCCCCCCCCCCCCCCCSSSSSSSSSSSSSSSSSSSSSSSSSSS0w"""""""""""""""yyyyyyyyyyyyyyyyyyy	T+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++gdddddddddddddddddhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhp1trnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnniulsssssssssssoaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnffffffffffffffrrrrrrrrrrrrrrrrrruuuuuuuusiiiiiiiiiiiilllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy""""""""""""""""""""""""""""""""""""""""""""	vvvvvvvvvvvvvvvvvvvtgggggggggggggggggnphhhhhhhhhhhhhhdddddddddffffffffffffffffurssssssssssssssssssssssssssssmicl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnnntuds111111111111rmmmmmmmmmmccccccccaeeeeeeeeeeei                                     oael                                 kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkPF3N]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]Gj!O(\BBBBBBBBBBBBBBBBBBBBBBBBBB4;
[=xW>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<222222222222222222222222MMMMMMMMMMMMMMMMMMMMA:L')D-IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII/$TTTTTTTTTTTTTTTTTTTTTTTTTTTTER.,,,,,,,,,,,,,,,,,,,,,%%%%%%%%%%%%%%%SC0000000000000000000000000bbbbbbbbbbbbbbbbbbbbbbbbbbbvwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww"ypppppppppppppppppp																																												gggggggggfffffffffffffffffunsttttttttttttdm1hcrrrrrrrrrrrrrrrrrrrrrrrrroaellllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiunsttttttttttttdmmmmmmmmmmmmmmmmcrrrrrrrrrrrrrrrrrrrrl            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeee            oooooooooooooooooooooaa"	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++fppppppppppppppppppyiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii1gnnnnnnnnntudsssssssssssssssssssssssssssssssssssssssssssrmmmmmmmmmmceeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnntidddddddddhurssssssssssssssssssssssssssssmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  L/222222222222222222222222MMMMMMMMMMMMMMMMMMMMA:(((((((((((((((((((((((((((((((((((((((((((((((((()D-IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIvTTTTTTTTTTTTTTTTTTTTTTTTTTTTER.,$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$0SbC%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	+++++++++++++++++++++++++++"1fpppppppppppppppnyyyyyyyyyyyyyttttttttttttttttttttttttttttttttttddddddddddddddhgirrrrrrrrrrrrrrrrrruuuuuuuusllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedtttttttttttttttttnrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiluuuuuuuuuuuscccccccccccc            oooooooooooooooooooooaaem                                oowpppppppppppppppppp																																																																												1f"dddddddddddddddyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhrttttttttttnnnnnnnnnnnnnnnnnnnnnliiiiiiiiiiiiiiiiiiicuaems                                     oaeeeeeeeeeeee                                 rddddddddddggggggggtlnnnnnnnnnnnnnnnnnnnnnnnncimmmmmmmmmmmmmmoaeeeeeeeeeeeeuuuuuuuuuuuuuuuuuuuuu             oaeeeeeeeeeeeeeeeeeeeeess77777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777??????????????????????????????????????????????????????????JKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK}333333333333333333333333333333333333333333333333333333333333Xqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq8zV{95@|||||||||||||||||||||||||||||||||||||||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH*6!&UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkPFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]GjN'\BBBBBBBBBBBBBBBBBBBBBBBBBB4;
OOOOOOOOOOOOOOOOOOOOOOOO>x<W===============================:/2L))))))))))))))))))))AMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM((((((((((((((((((((((((((((-ID,vTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTbR.E+0S$pC%	wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff11111111111111111"""""""""""""""""""yrddddddddddggggggggggggggggggggtlnnnnnnnnnnnnnnnnnnnnnnnncimmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeeu            oooooooooooooooooooooaadshrttttttttttnnnnnnnnnnnnnnnnnnnnnliiiiiiiiiiiiiiiiiiiceum                                ooaeeeeeeeeeeee                                                                  																											pppppppppppppppppppffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd11111111111111111h"ygtsnrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiluuuuuuuuuuuoaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnsirrrrrrrrrrrrrrrrrruuuuuuuuuuuuuuuuuuulllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeAI:/2L)))))))))))))))))))))))))))))))))))))))))))....................................................................................((((((((((((((((((((((((((((-Mw,vTbRDDDDDDDDDDDDDDDDDDDDDDDDDDD+0S$C%EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE																hhhhhhhhhhhhhhhhhhhfptttttttttttttttttt1nyyyyyyyyyyyyyyyyyyyyyyyyyyyyyydiiiiiiiiiiiii"""""""""surrrrrrrrrrrrrrrrrrrrrmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonitttttttttduggggggggggggsmrccccccccccaeeeeeeeeeeeeeeeeee                                     oael                                 	fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffyhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhppppppppppppppppppiiiiiiiiiiiii111111111nuttttttttttttdmgggggggggggggggggcsssssssssssrrrrrroaellllllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiinuttttttttttttdm"csssssssssssrl            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeee            oooooooooooooooooooooaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkPF3[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]GjjjjjjjjjjjjjjjjjjjjB'4\

























>;<O=xNW-I:/2L)AR....................................................................................(((((((((((((((((((((((((((((((((((((((((((((((((((%w,vTbMMMMMMMMMMMMMMM000000000000000000000000000$+DSSSSSSSSSSSSSSSSSSSfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff													yhhhhhhhhhhhhhhhhhhhhhhhhhCCCCCCCCCCCCCCCCCCCCCCCppppppppppppppggggggggggggggggggnitttttttttdu"111111111111smrceeeeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnnttttttttdiiiiiiiiiiiiiiiiiiiiiiiiisurrrrrrrrrrrrrrrrrrrrrmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                              hhhhhhhhhhhhhhhhhhhfffffffffffffffgggggggggggggy	nEEEEEEEEEEEEEEEEt"pddddddddddddddddddddddddddddddddddddddddddddddddddddddsirrrrrrrrrrrrrrrrrrullllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedt1nssssssssssssssrrrrrrrrrrrrrrrrrilllllllllllllllllllucccccccccccc            oooooooooooooooooooooaaem                                oo))))))))))))))))))))))))))))-I:/2LLLLLLLLLLLLLLLLLLLLbR....................................................................................(AAAAAAAAAAAAAAAAAAAAAAAAA%w,vTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTf$0DDDDDDDDDDDDDDDDDDDDDDDDDDDM+yhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"gggggggggggggggggggggggggggd	ES1111111111111111pppppppppppppppppstrnnnnnnnnnnnnnnnnnnnnnnnllllllllllllllllllicccccccccaemu                                     oaeeeeeeeeeeee                                 sdrrrrrrrrrrrrrrrrrrrrrrrrrrrtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccmiiiiiioaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             oaeeeeeeeeeeeeeeeeeeeeeuuyyyyyyyyyyyyyyyyyyyf"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh	g111111111111111pCsdrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccmiiiiiiiiiiii            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeee            oooooooooooooooooooooaaduuuuuuuuuuuuuuuuustrnnnnnnnnnnnnnnnnnnnnnnnlllllllllllllllllliceeeeeeeeem                                ooaeeeeeeeeeeee                                     G5V||||||||||||||||||||||||||||||||||||||H@777777777777777777777777777777777777777&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&6UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkPF3[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]!L4B
'>\<<<<<<<<<<<<<<<<<<<<<<<<<<=;NOjx((((((((((((((((((((((((((((-I:/2))))))))))))))))))))))))))))))))))))WbR.......................................................................................................EEEEEEEEEEEEEEEEEEEEEEEEE%w,vTA"D$M00000000000000000000000000000000000000000000000000																			fyppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppphdg1111111111111111111111111111111C++++++++++++++++++tunssssssssssssssrrrrrrrrrrrrrrrrrillllllllllllllllllloaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnnnnuuuuuuuusirrrrrrrrrrrrrrrrrrrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeefffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff																			"""""""""""""""""pppppppppppppythgnS11111111111111dddddddddddddddddddddddddddddddddddddiuuuuuuuuussssssssssssrmmmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnntidddddddddddddddddddddddddddddddddddddumscraeeeeeeeeeeeeeeeeeeee                                     oael                                 222222222222222222222222222222((((((((((((((((((((((((((((-I:/LTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTbR.......................................................)CEEEEEEEEEEEEEEEEEEEEEEEEE%w,vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvMDDDDDDDDDDDDDDDDDDDDDDDD$A0000000000000000000000000000000000000000000000000000000000000000000000000	fSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSp""""""""""""""yhhhhhhhhhhhhhhhhhhhhhhhginnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmmmm1cuuuuuuuuuuussssssoaelrrrrrrrrrrrrrrrrrrrrr             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeinnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmcuuuuuuuuuuusl            oaaaaaaaaaaaaaaaaaaaaaeer            oooooooooooooooooooooaa	pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp+++++++++++++++++ffffffffff"yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhnnnnnnnntidddddddddddddddddddddddggggggggggggumscerrrrrrrrrrr                                ooael                                     nnnnnnnnnnnnnnttttttttttdddddddd1iuuuuuuuuussssssssssssrmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                     GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkPF3[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]/
4>B<'=\NNNNNNNNNNNNNNNNNNNNNNNNNNj;!OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO((((((((((((((((((((((((((((-I:2vTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTxbR...................................LSCEEEEEEEEEEEEEEEEEEEEEEEEE%w,))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))MADDDDDDDDDDDDDDDDDDDD$$$$$$$$$$$$$$$$$ppppppppppppp																																	+0000000000000000000nf"tttttttttttttttydddddddddddddd1hhhhhhhhhhuuuuuuuusirrrrrrrrrllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedtgnuuuuuuuuuuuuuussssssssssrrrrrrrrliiiiiiiiiiiiiiiiiiicccccccccccc            oooooooooooooooooooooaaem                                ooooooooooooooooooooooooooooooooooooooooooooooooooooooooppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp	dddddddddddddddddddfg"y1utsnrrrrrrrrrrrrrrlllllllllllllllllllllllllllciaemmmmmmmmm                                     oaeeeeeeeeeeee                                 udshrtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccccmmmmmmmmmmmmmoaeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiii             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee(::::::::::::::::::::::::::::::::::::::::::::::::::/W-IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIvT2ER.b,SCLA%wwwwwwwwwwwwwwwwwwwwwwwww++++++++++++++++++++++++M))))))))))))))))))))))))))))))))))))))))))))))$Dpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppg	yfudsh"rtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccccmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeei            oooooooooooooooooooooaaddddddddd1utsnrrrrrrrrrrrrrrlllllllllllllllllllllllllllceim                                ooaeeeeeeeeeeee                                                                     ppppppppppppp0yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyddddddddddddddddddg1	fhtttttttttnuuuuuuuuuuuuuussssssssssrrrrrrrrliiiiiiiiiiioaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdn"""""""""""""""""""""""""""""""uuuuuuuusirrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaee�������������������������������������������������Yݣ���������������������������������������~��������������������������������������������������������Ɂ���ͳ������������������������������������������������������������������_����`^���Z���������������������������������������������������������������Q�ջ��ꬼ���������������������������������������������ۯ���彿��������#�ֵ�������������������������������ٲ��ߴ������������������������������������������������������� ��JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ������������������������������������������������������������????????????????????????????????????????????????????????????????????????????????????????????????????8888888888888888888888888888888888888888888888888888888}KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqX5z{||||||||||||||||||||||||||||||||||||||||||||||||||||9HV77777777777777777777777777777777777777&@�************************************************************************************************************************************************6UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGPF3[]]]]]]]]]]]]]]]]]]]]]]kI>
<4=BN'j\!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!;.::::::::::::::::::::::::::::::::::::::::::::::::::/WO-(wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwvT2ERRRRRRRRRRRRRRRRRRRRRRRRRRRR$,SCLA%bbbbbbbbbbbbbM++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))ppppppppppppppp1yyyyyyyyyyyyyyyy00000000000000000000ttttttttttttttttttttttttttttttttttnfggggggggggggggdddddddddd"																iuuuuuuuuuuuusmrcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnnnnttttttttdihhhhhhhhhhhhhhhhhhhhmucsaeeeeeeeeeeer                                     oael                                 ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppf1yyyyyyyyyyyyyyyyyyyyyyyyyyyyDDDDDDDDDDDDDDDDDDDDDDDDDD"""""""""""""""""""""""""nittttttttttttdmhgcccccccccccccccccccuuuuuuoaelsssssssssssssssssssss             oaeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnittttttttttttdm	cccccccccccccccccccul            oaaaaaaaaaaaaaaaaaaaaaees            oooooooooooooooooooooaa-R.::::::::::::::::::::::::::::::::::::::::::::::::::/xI%wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwvT2E(0$,SCLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMMMMMMMMMMMMMMMMMMMMMMMMM+bbbbbbbbbbbbbbbbbbbbbbbbyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyp"f1111111111111rrrrrrrrrrrrrrrD))))))))))))))hhhhhhhhhhhhhhhhhnnnnnnnnnnttttttttdi																																					mucesssssssssss                                ooael                                     nnnnnnnnnnnnnntrddddddddddggggggggggggggggiuuuuuuuuuuuusmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                              1yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyh"fpnnnnnnnnnnnnnnnnnnnnnnnnnnnt																				ddddddddddddddgggggggggggggggggrrrrrrrrrrrrrrrrrruuuuuuuusillllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedttttttttttttttttttnnnnnnnnnnnnnnnnnnnnnnurssssssssssllllllllllllllllllicccccccccccc            oooooooooooooooooooooaaem                                ooWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGPF3[]]]]]]]]]]]]]]]]]]]]]]x>
<4=BN'j\!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!;kER.::::::::::::::::::::::::::::::::::::::::::::::::::/-A%wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwvT2ID0$,SCL((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((bMMMMMMMMMMMMMMMMMMMMMMMMMMMM+f1yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy	h"""""""""""""""""""dppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppgggggggggtunsssssssssssssslrrrrrrrrrrrrrrrrrrrrccccccccaemi                                     oaeeeeeeeeeeee                                         duuuuuuuuuuuuuuuuustlnnnnnnnnnnnnnnnnnnnnnnnncrmmmmmmmmmmmmmmmoaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             oaeeeeeeeeeeeeeeeeeeeeeiifyyyyyyyyyyyyyyyy	1"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""phhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh)))))))))))))))))))))duuuuuuuuuuuuuuuuuuuuuuuuuuuuuuustlnnnnnnnnnnnnnnnnnnnnnnnncrmmmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeee            oooooooooooooooooooooaadigggggggggtunsssssssssssssslrrrrrrrrrrrrrrrrrrrrceeeeeeeem                                ooaeeeeeeeeeeee                                     /2ER.::::::::::::::::::::::::::::::::::::::::::::::::::OLA%wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwvT--------------------D0$,SCI	bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb(Mpyyyyyyyyyyyyyyyyf)+"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""1dhhhhhhhhhhhhhhhhhhgggggggggggggggggggggggggggggggggggggggggggggggtinnnnnnnnnnnnnnnnnnnnnnursssssssssslllllllllllllllllloaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnnnirrrrrrrrrrrrrrrrrruuuuuuuusssssssssssslllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeepy	gggggggggggggggggggggggg"ft1hnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnndrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiiiiiiiiiumscl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonrttttttttttdddddddddddddddddddddddddddddddddddimmmmmmmmmcuaeeeeeeeeeees                                     oael                                 ]H|75&VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV@;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;6WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUPF3[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
x4>B<'=\NNNNNNNNNNNNNNNNNNNNNNNNNNjjjjjjjjjjjjjjjjjjjjjj!T2ER.:::::::::::::::::::::/CLA%wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwvOOOOOOOOOOOOOOOOOOOOOOO))))))))))))))))))))D0$,S-yyyyyyyyyyyyyyyyyyyyyyyyyyyyb(((((((((((((((((((((((((IIIIIIIIIIIIIIIIIIIIIIIIIII"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""ppppppppppppppppppppppppppppggggggggggggggggggggggggM														f1rrrrrrrrrrrrrrrhhhhhhhhhhnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmciiiiiiiiiiiiiiiiiiiiiiiioaeluuuuuuuuuuuuuuuuuuuuu             oaeeeeeeeeeeeeeeeeeeeeessrrrrrrrrrrrrrrrrrrrrrrrnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmmmmmciiiiiiiiiiiiiiiiiiil            oaaaaaaaaaaaaaaaaaaaaaeeu            oooooooooooooooooooooaap+"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""yyyyyyyyyyyyyyyyyyyyyyyyyyyggggggggggggggggs	ffffffffffffffffffffffffffffff1nrttttttttttddddddddddddddddddddddddddhhhhhhhhhhhhimmmmmmmmmceuuuuuuuuuuu                                ooael                                     nnnnnnnnnnnnnntsdrrrrrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiiiiiiiiiumoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                      vT2ER.::::::::::::::::::::::::::::::SCLA%wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww////////////////////////))))))))))))))))))))D0$,kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk((((((((((((((((((((((((((((Ib-------------------------g+++++++++++++++++++++++++++"pppppppppppppppppppppppppppppppppppppppppppynnnnnnnnnnnnnnnn	tttttttttttttttttttfddddddddddddddddddddddddddddddd1sirrrrrrrrrrrrrrrrrruuuuuuuullllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedthniiiiiiiiiiiiiiiiiiiiiisurlllllllllllllllllllllllllllcccccccccccc            oooooooooooooooooooooaaem                                oo"""""""""""""gMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMpdyyyyyyyyyyyyyyyyh	ffffffffffffffffffitttttttttnuuuuuuuuuuuuuulsssssssssssrccccccccccaemmmmmmmm                                     oaeeeeeeeeeeee                                 iddddddddd1utlnnnnnnnnnnnnnnnnnnnnnnnncsmrrrrrroaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW''''''''''''''''''''''''''''']]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]PF3GO
x4>B<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<22222222222222222222222222\\\\\\\\\\\\\\\\\\\\\\N=j:vTTTTTTTTTTTTTTTTTTTTTLR.EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEESCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC%wA,,,,,,,,,,,,,,,,,,,,,,,,)/I0$D+((((((((((((((((((((((((((((k!!!!!!!!!!!!!b-MMMMMMMMMMMMMMMMMMMMMMMMM"""""""""""""""""""gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggyyyyyyyyyyyyyyyyyhpffffffffffffffffiddddddddd1	utlnnnnnnnnnnnnnnnnnnnnnnnncsmrrrrrrrrrrrr            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeee            oooooooooooooooooooooaaddddddddddddddddddddddddditttttttttnuuuuuuuuuuuuuulsssssssssssrceeeeeeeeeem                                ooaeeeeeeeeeeee                                                       yyyyyyyyyyyyyyyyyyyyyyyyyyy"""""""""""""fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffgdddddddddddddddddhhhhhhhhhhhhhhhhhhpppppppppppppppp1ttttttttniiiiiiiiiiiiiiiiiiiiiisurlllllllllllllllllllloaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdn																					sirrrrrrrrrrrrrrrrrruuuuuuuuuuuulllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaee.w:vTTTTTTTTTTTTTTTTTTTTTLR2$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$SCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC%EM,,,,,,,,,,,,,,,,,,,,,,,,)/I0A""""""""""""""""""""""""""""+b(DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDyyyyyyyyyyyyyyyyyyyyyyyyyyy------------------------------------ffffffffffffffffffffffffffftgggggggggggggggggnnnnnnnnnnnnnnnnhhhhhhhhhhhhhhds	prrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiimucl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonstrdddddddddd1111111111111111111micccccccccaeeeeeeeeeeeu                                     oael                                                                                                                                   y"""""""""""""""""""""""""""""""""ffffffffffffffffffffffffffffffffffffffffffffgs																	rnnnnnnnnnnttttttttttttdm1hcccccccccccccccccciiiiiioaelllllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeuussssssssssssssrnnnnnnnnnnttttttttttttdmpccccccccccccccccccil            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeee            oooooooooooooooooooooaa3333333333333333333333333333333333333333333333333333333333JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}????????????????????????????????????????????????????????????????????????????????????????????8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888qKHXz7{&||||||||||||||||||||||||||||||||||||||||||||||955555555555555555555555555555555VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW''''''''''''''''''''''''''''']]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]6UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUFPRxO>
<44444444444444444444444444BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=\GN%w:vTTTTTTTTTTTTTTTTTTTTTL.0$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$SCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC222222222222222222222222222M,,,,,,,,,,,,,,,,,,,,,,,,)/IEybbbbbbbbbbbbbbbbbbbbbbbbbbbbD+A(fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffj																																	"uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu1gnstrddddddddddpppppppppppppppppppppppppppppppppppmiceeeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnntudshrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiimoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                               fffffffffffffffy1																-n"""""""""""""""""""tpppppppppppppddddddddddddddhguuuuuuuusirrrrrrrrrrrrrrrrrrllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedtttttttttttttttttnnnnnnnnnnnnnnnnnnnnniuuuuuuuuuslrrrrrrrrrrrrrrrrrrrrcccccccccccc            oooooooooooooooooooooaaem                                ooLLLLLLLLLLLLLLLLLLLL%w:vTTTTTTTTTTTTTTTTTTTTTRI0$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$SCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC...................................................M,,,,,,,,,,,,,,,,,,,,,,,,)/222222222222222DbAAAAAAAAAAAAAAAAAAAAAAAAAAAAE+++++++++++++++++++++++++++++++++fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffp1	yd-("""""""""""""""""""""""""""""""""""""""""""""""hhhhhhhhtinnnnnnnnnnnnnnnnnnnnnnluuuuuuuuuuuscraemmmmmmmmmm                                     oaeeeeeeeeeeee                                        digggggggggtlnnnnnnnnnnnnnnnnnnnnnnnncumssssssoaeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrr             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeefffffffffffffffpppppppppppppppppp																																																													!11111111111111111yyyyyyyyyyyyy""""""""digggggggggggggggggggggggggggtlnnnnnnnnnnnnnnnnnnnnnnnncumssssssssssss            oaaaaaaaaaaaaaaaaaaaaaeer            oooooooooooooooooooooaaddddddddddhhhhhhhhtinnnnnnnnnnnnnnnnnnnnnnluuuuuuuuuuuscerm                                ooaeeeeeeeeeeee                                                           k[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW''''''''''''''''''''''''''''']3333333333333333333333333333333333333FFFFFFFFFFFFFFFFFFFFF>x<OOOOOOOOOOOOOOOOOOOOOOOOOO





















4=BGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGP\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\%w:vTL/I0$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$SCR---------------------------------------------------M,,,,,,,,,,,,,,,,,,,,,,,,).pADEb2222222222222222222222222222!N+ffffffffffffffffffffffffffffffffffffffffff																																																																														d11111111111111111hy"gttttttttttnnnnnnnnnnnnnnnnnnnnniuuuuuuuuuslrrrrrrrrrrroaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnuuuuuuuusirrrrrrrrrrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee(fphhhhhhhhhhhhh																tttttttttttttttttt1n""""""""""""""""""""""""""""""duuuuuuuuuuuuuuuuuuuyssssssssssrrrrrrrrrrrrrrrrrrrimmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonutsdrgggggggggggggggggggggmmmmmmmmciaeeeeeeeeeeeeeeeeeee                                     oael                                 TCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC%w:vvvvvvvvvvvvvvvvvvvvv)/I0$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$SLj---------------------------------------------------M,,,,,,,,,,,,,,,,,,,,,,,,RfEA2D.b																																																													(((((((((((((((((((((((((((((((((((((((((("hhhhhhhhhhhhhppppppppppppppppppppppppppppppppppppppppppppppuuuuuuuuuuuuuuuuuuu1snrttttttttttttdmgggggggggggggggggccccccccccccccccccccccccccccccccoaeliiiiiiiiiiiiiiiiiiiii             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuuusnrttttttttttttdmycccccccccccccccccccccccccccl            oaaaaaaaaaaaaaaaaaaaaaeei            oooooooooooooooooooooaa+++++++++++++																																																													fffffffffffffffffff"hhhhhhhhhhhhhhhhhhhhhhhpppppppppppppppppppppppppppppggggggggggggggggggnutsdry111111111111111111111mmmmmmmmceiiiiiiiiiii                                ooael                                     nnnnnnnnnnnnnntttttttttduuuuuuuuuuuuuuuuussssssssssrrrrrrrrrrrrrrrrrrrimoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                      7H&|*55555555555555555555555555555555VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUk[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW''''''''''''''''''''''''''''']3@6v<>>>>>>>>>>>>>>>>>>>>>>>>>>xxxxxxxxxxxxxxxxxxxxxxO=
G4PBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFSCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC%w:TTTTTTTTTTTTTTTTTTTTTTTT)/I0$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$(j\---------------------------------------------------M,LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL2E.ARDhhhhhhhhhhhhh	+bggggggggggggggggggg"fnnnnnnnnnnnnnnnptyyyyyyyyyyyyyyyydddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddduuuuuuuusirllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedt1nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnniulsssssssssssrcccccccccccc            oooooooooooooooooooooaaem                                oo	"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhyggggggggggggggggggggggggggggggggggggggggggggggdfffffffffffffff1pppppppppppppppppppppppppppppppppppppppppttttttttniiiiiiiiiiiiiilllllllllllllllllllucsaemr                                     oaeeeeeeeeeeee                                          ddddddddddddddddddddddddditlnnnnnnnnnnnnnnnnnnnnnnnncccccccccmuuuuuuoaeeeeeeeeeeeesssssssssssssssssssss             oaeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr:SCv/%wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww)T-0$I,(NNNNNNNNNNNNNNNNNNNNN...........................MMMMMMMMMMMMMMMMMMMMMMMMM+2EL"ARRRRRRRRRRRRR	yhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhfg1111111111111111111111111111DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDdddddddddddddddddddddddddpitlnnnnnnnnnnnnnnnnnnnnnnnncccccccccmuuuuuuuuuuuu            oaaaaaaaaaaaaaaaaaaaaaees            oooooooooooooooooooooaadrrrrrrrrrrrrrrrrrrrrrrrrrrttttttttniiiiiiiiiiiiiilllllllllllllllllllucesm                                ooaeeeeeeeeeeee                                     yfffffffffffff	""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""hdg11111111111111111bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbtrnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnniulsssssssssssoaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnpppppppppppppprrrrrrrrrrrrrrrrrruuuuuuuusiiiiiiiiiiiilllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeej!!!!!!!!!!!!!!!!!!!!!!!k[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW''''''''''''''''''''''''''''']3wwwwwwwwwwwwwwwwwwwwwwwwww<<<<<<<<<<<<<<<<<<<<<<>=xGOP
F444444444444444444444444444444444B$:SCv/%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM)T-00000000000000000000000000000000000000000000000,(NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN...........................I	E+A2222222222222222222222222LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLfffffffffffffyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"thgnnnnnnnnnnnnnnn11111111111111dddddddddpbRurssssssssssssssssssssssssssssmicl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnnntudsssssssssssssssssssssssssssssrmmmmmmmmmmccccccccaeeeeeeeeeeei                                     oael                                                                                                                           f																																														yyyyyyyyyyyyyy"hhhhhhhhhpgunsttttttttttttdmmmmmmmmmmmmmmmmmm1crrrrrrrrrrrrrrrrrrrrrrrrroaellllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiunsttttttttttttdmDcrrrrrrrrrrrrrrrrrrrrl            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeee            oooooooooooooooooooooaa%0$:SCv/wwwwwwwwwwwwwwwwwwwwwwwwwwwMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM)T------------------------------bbbbbbbbbbbbbbbbbbbbbbbbbbbb,(\\\\\\\\\\\\\\\\\\\\\....................fAEEEEEEEEEEEEEEEEEEEEEEEEE+I2222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222ppppppppppppppppppppppppppppppp	iy"""""""""""""""""""""""""""""""hnnnnnnnnntudsDLggggggggggggrmmmmmmmmmmceeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnntiddddddddd1urssssssssssssssssssssssssssssmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                                                               ffffffffffffffffffpppppppppppppppppppppppppppn	ytR"dddddddddddddd1hirrrrrrrrrrrrrrrrrruuuuuuuusllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedtgnrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiluuuuuuuuuuuscccccccccccc            oooooooooooooooooooooaaem                                oo���������������������������������������������������������������������������������������ݣY�����������������������������������������~������������������������������������������������������ɺ����ʾ�����Ǹ��````````````````````````````````````````````````````````_��������^���Z������������������������������������������������������������Q�����������������������������������������������������ۯ����Ϯ�������#�]�������ߴ���������������������������������������������������������? 򶶶��������������������������������������}qJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ���������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������8HKX|75&V*zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{NUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUj!!!!!!!!!!!!!!!!!!!!!!!k[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW'''''''''''''''''''''''''''''@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@///////////////////////////////////////////////=<G>PxFOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
34-0$:SCv%...........................MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM)TwDbbbbbbbbbbbbbbbbbbbbbbbbbbbb,(\BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBAIEEEEEEEEEEEEEEEEEEEE++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++R222222222222222222pfddddddddddddd	gy"1rttttttttttnnnnnnnnnnnnnnnnnnnnnliiiiiiiiiiiiiiiiiiicuaems                                     oaeeeeeeeeeeee                                 rddddddddddhhhhhhhhtlnnnnnnnnnnnnnnnnnnnnnnnncimmmmmmmmmmmmmmoaeeeeeeeeeeeeuuuuuuuuuuuuuuuuuuuuu             oaeeeeeeeeeeeeeeeeeeeeesssssssssssssssssssssssssssssssssssssssssssssssssLLLLLLLLLLLLLLLLLppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppgf"	rddddddddddhyyyyyyyytlnnnnnnnnnnnnnnnnnnnnnnnncimmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeeu            oooooooooooooooooooooaads1rttttttttttnnnnnnnnnnnnnnnnnnnnnliiiiiiiiiiiiiiiiiiiceum                                ooaeeeeeeeeeeee                                     vT-0$:SC/////////////////////...........................MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM)%RDbbbbbbbbbbbbbbbbbbbbbbbbbbbb,((((((((((((((((((((((((((((((((((((((((wLLLLLLLLLLLLLLLLLLLLLLLLLAIEEEEEEEEEEEEEEEEEEEE+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppddddddddddddddddddg1f	htsnrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiluuuuuuuuuuuoaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnyyyyyyyyyyyyyysirrrrrrrrrrrrrrrrrruuuuuuuuuuuuuuuuuuulllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee21"pppppppppppppppttttttttttttttttttttttttttttttttttn	ggggggggggggggdiyfffffffffsurrrrrrrrrrrrrrrrrrrrrmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonitttttttttduhhhhhhhhhhhhsmrccccccccccaeeeeeeeeeeeeeeeeee                                     oael                                 \Nj!!!!!!!!!!!!!!!!!!!!!!!k[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW'''''''''''''''''''''''''''''C======================GGGGGGGGGGGGGGGGGGGGGGGGGGP<F>6x3O]
)T-0$:Svvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv444444444444444444444...........................MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM/+RDbbbbbbbbbbbbbbbbbbbbbbbbbbbb,(%%%%%%%%%%%%%%%%ALEEEEEEEEEEEEEEEEEEEEEEEEEwIppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp	1"222222222222222222222222222222222222222222222222222222222222222iyyyyyyyyyyyyyyyyyyyyyyyyyynuttttttttttttdmhgcsssssssssssrrrrrroaellllllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiinuttttttttttttdmfcsssssssssssrl            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeee            oooooooooooooooooooooaaaaaaaaaaaaaa"ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppy	1111111111111111111111111111111111111111111111111111111111111111111111111111111111hhhhhhhhhhhhhhhhhnitttttttttdufffffffffffffffffffffffffffffsmrceeeeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnnttttttttdigggggggggsurrrrrrrrrrrrrrrrrrrrrmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  SSSSSSSSSSSSSSSSSSSSSSSS)T-0$:C(BBBBBBBBBBBBBBBBBBBBB...........................MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMv2+RDbbbbbbbbbbbbbbbbbbbbbbbbbbbb,/////////////////////////////////////////////////////////////EAwL%%%%%%%%%%%%%%%%%%%%%%%%%1"ppppppppppppphy																nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnItfffffffffffffffddddddddddddddggggggggggggggggggggggggsirrrrrrrrrrrrrrrrrrullllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedttttttttttttttttttnssssssssssssssrrrrrrrrrrrrrrrrrilllllllllllllllllllucccccccccccc            oooooooooooooooooooooaaem                                oop	1"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""fhyyyyyyyyyyyyyddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddgstrnnnnnnnnnnnnnnnnnnnnnnnllllllllllllllllllicccccccccaemu                                     oaeeeeeeeeeeee                                 sdrrrrrrrrrrrrrrrrrrrrrrrrrrtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccmiiiiiioaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             oaeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuuuuuuuuuuuuu|H5555555555555555555555555555555555555V77777777777777777777777777777777&UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU'@999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999\Nj!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!F[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk======================GGGGGGGGGGGGGGGGGGGGGGGGGGP<<<<<<<<<<<<<<<<<<<<<<<<<<<<<T3666666666666666666666666666666666666666]x>O::::::::::::::::::::::::)SSSSSSSSSSSSSSSSSSSSS0$-----------------------------------(B
CRRRRRRRRRRRRRRRRRRRRRRRRRRRM.,2+vwbbbbbbbbbbbbbbbbbbbbbbbbbbbbDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDEA/	L%"pf1yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhsdrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccmiiiiiiiiiiii            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeee            oooooooooooooooooooooaadugstrnnnnnnnnnnnnnnnnnnnnnnnlllllllllllllllllliceeeeeeeeem                                ooaeeeeeeeeeeee                                     ffffffffffffffff"p															yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy1dhhhhhhhhhhhhhhhhhhgggggggggggggggggggggggggggggggggggggggggggggggtunssssssssssssssrrrrrrrrrrrrrrrrrillllllllllllllllllloaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnIIIIIIIIIIIIIIuuuuuuuusirrrrrrrrrrrrrrrrrrrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaee$M::::::::::::::::::::::::)SSSSSSSSSSSSSSSSSSSSS0TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT(4CRRRRRRRRRRRRRRRRRRRRRRRRRRR--------------------,2+vwb.pAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALED////////////////////////////////////////////////////////////////////////////"fgggggggggggggggy	t1hnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnddddddddI%%%%%%%%%%%%%iuuuuuuuuussssssssssssrmmmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnntiddddddddddddddddddddddddddddddddddddumscraeeeeeeeeeeeeeeeeeeee                                     oael                                 "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyypppppppppppppppppppgggggggggggggggffffffffffffff	11111111111111111111111111111111hinnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmcuuuuuuuuuuussssssoaelrrrrrrrrrrrrrrrrrrrrr             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeinnnnnnnnnttttttttttttdmmmmmmmmmmmmmcuuuuuuuuuuusl            oaaaaaaaaaaaaaaaaaaaaaeer            oooooooooooooooooooooaaB'\Nj!!!!!!!!!!!!!!!!!!!!!!!F[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW00000000000000000000000000000000000000000000000000000000000000000000000000000000000000=<G3P]]]]]]]]]]]]]]]]]]]]]]]]]]]]]>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>kxxxxxxxxxxxxxxxxxxxxxxxxxxxM::::::::::::::::::::::::)SSSSSSSSSSSSSSSSSSSSS$bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb(4OCRTIIIIIIIIIIIIIIIIIIII,2+vw----------------LADDDDDDDDDDDDDDDDDDDDDDDDDDDDDD.EEEEEEEEEEEEEEEyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"""""""""""""""""""""""""///////////////////gppppppppppf																														1nnnnnnnntidddddddddddddddddddddhhhhhhhhhhhhumscerrrrrrrrrrr                                ooael                                     nnnnnnnnnnnnnnttttttttttdddddddddddddddddddddddddiuuuuuuuuussssssssssssrmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                              gggggggggggggggyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy%%%%%%%%%%%%%%%%%%%"npfttttttttttttt	ddddddddddddddddddddddddddddddd1111111111uuuuuuuusirrrrrrrrrllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedthnuuuuuuuuuuuuuussssssssssrrrrrrrrliiiiiiiiiiiiiiiiiiicccccccccccc            oooooooooooooooooooooaaem                                ooooooooooooooooooooooRRRRRRRRRRRRRRRRRRRRRRRRRRRM::::::::::::::::::::::::)S0wbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb(
C$$$$$$$$$$$$$$$$$$$$$$$$$IIIIIIIIIIIIIIIIIIII,2+vTyDL.A------------------------------------------------ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg%EEEEEEEEEEEEEEEEd"phf																		utsnrrrrrrrrrrrrrrlllllllllllllllllllllllllllciaemmmmmmmmm                                     oaeeeeeeeeeeee                                 uds1rtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccccmmmmmmmmmmmmmoaeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiii             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeyyyyyyyyyyyyyg/////////////////////////////////////////////////////////////"""""""""""""""""hhhhhhhhhhhhhhhh	puds1frtlnnnnnnnnnnnnnnnnnnnnnnnnccccccccccmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeei            oooooooooooooooooooooaaddddddddddddddddddddddddddutsnrrrrrrrrrrrrrrlllllllllllllllllllllllllllceim                                ooaeeeeeeeeeeee                                                                        q????????????????????????????????????????????????????????????????????????????????????????????????????????????????}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}J*********************************************************************************************************************************************************|8K5{XVHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHU7@&44444444444444444444444444444444444444444444444444444444444444444444449zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzB'\Nj!!!!!!!!!!!!!!!!!!!!!!!F[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW66666666666666666666666666666666666666666666666SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<3=]G>PkkkkkkkkkkkkkkkkkkkkkkkkkkkkkCRRRRRRRRRRRRRRRRRRRRRRRRRRRM::::::::::::::::::::::::)))))))))))))))))))))vwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb(
x0%%%%%%%%%%%%%%%%%%%%%%%%%IIIIIIIIIIIIIIIIIIII,2+$$$$$$$$$$$$$.D-LTA"""""""""""""""yyyyyyyyyyyyyyyyyyy	//////////////////////////////////////////////////////////////////////////////////////////gdddddddddddddddddhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhp1tttttttttnuuuuuuuuuuuuuussssssssssrrrrrrrrliiiiiiiiiiioaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnfffffffffffffffffffffffffffffffuuuuuuuusirrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy""""""""""""""""""""""""""""""""""""""""""""	EEEEEEEEEEEEEEEEEEEtgggggggggggggggggnphhhhhhhhhhhhhhddddddddddfffffffffffffffffffffffffffffffiuuuuuuuuuuuusmrcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnnnnttttttttdi11111111111111111111mucsaeeeeeeeeeeer                                     oael                                 )OCRRRRRRRRRRRRRRRRRRRRRRRRRRRM::::::::::::::::::::::::S+vwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb(((((((((((((((((((((/%%%%%%%%%%%%%%%%%%%%%%%%%IIIIIIIIIIIIIIIIIIII,2000000000000000-.TD$LEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"ypppppppppppppppppp																																												ggggggggggffffffffffffffffffffffffnittttttttttttdm1hcccccccccccccccccccuuuuuuoaelsssssssssssssssssssss             oaeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnittttttttttttdmmmmmmmmmmmmmmmmcccccccccccccccccccul            oaaaaaaaaaaaaaaaaaaaaaees            oooooooooooooooooooooaa"																																																																																																								fppppppppppppppppppyrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr1gnnnnnnnnnnttttttttdiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiimucesssssssssss                                ooael                                     nnnnnnnnnnnnnntrddddddddddhhhhhhhhhhhhhhhhiuuuuuuuuuuuusmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  
4B'\Nj!!!!!!!!!!!!!!!!!!!!!!!F[;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW<<<<<<<<<<<<<<<<<<<<<<<<<<3333333333333333333333]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]>=kGPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOCRRRRRRRRRRRRRRRRRRRRRRRRRRRM:)2+vwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbSE/%%%%%%%%%%%%%%%%%%%%%%%%%IIIIIIIIIIIIIIIIIIII,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T-$.0DDDDDDDDDDDDDDDDDD																														L"1fpppppppppppppppnyyyyyyyyyyyyyttttttttttttttttttttttttttttttttttddddddddddddddhgrrrrrrrrrrrrrrrrrruuuuuuuusillllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedtttttttttttttttttnnnnnnnnnnnnnnnnnnnnnnurssssssssssllllllllllllllllllicccccccccccc            oooooooooooooooooooooaaem                                ooApppppppppppppppppp																																																																												1f"dddddddddddddddyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhhhtunsssssssssssssslrrrrrrrrrrrrrrrrrrrrccccccccaemi                                     oaeeeeeeeeeeee                                         dugstlnnnnnnnnnnnnnnnnnnnnnnnncrmmmmmmmmmmmmmmmoaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             oaeeeeeeeeeeeeeeeeeeeeeiiC:(xxxxxxxxxxxxxxxxxxxxxxxxvvvvvvvvvvvvvvvvvvvvvvvvvvvMRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR2+)%bbbbbbbbbbbbbbbbbbbbbbbbbbbbw,E/S$IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIT---------------------p.0	ADDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff11111111111111111"""""""""""""""""""yyyyyyyyydugggggggggggggstlnnnnnnnnnnnnnnnnnnnnnnnncrmmmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeee            oooooooooooooooooooooaadihhhhhhhhhtunsssssssssssssslrrrrrrrrrrrrrrrrrrrrceeeeeeeem                                ooaeeeeeeeeeeee                                                                  	Lpppppppppppppppppppffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd11111111111111111h"ygtinnnnnnnnnnnnnnnnnnnnnnursssssssssslllllllllllllllllloaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnirrrrrrrrrrrrrrrrrruuuuuuuusssssssssssslllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeWV55555555555555555555555555555555|UH@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@7O6&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
4B'\Nj!!!!!!!!!!!!!!!!!!!!!!!F[;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;M3<]]]]]]]]]]]]]]]]]]]]]]]]]]>>>>>>>>>>>>>>>>>>>>>>kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk====================================GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGPPPPPPPPPPPPPPPPPPPPPPPPPPPP:(xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxvvvvvvvvvvvvvvvvvvvvvvvvvvvCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC2+)%bRA,E/S$IwLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLT---------------------.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000																hhhhhhhhhhhhhhhhhhhfptttttttttttttttttt1nyyyyyyyyyyyyyyyyyyyyyyyyyyyyyydrrrrrrrrrrrrr""""""""""iiiiiiiiiiiiiiiiiiiiiiiiiiiumscl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonrttttttttttddddddddggggggggggggimmmmmmmmmcuaeeeeeeeeeees                                     oael                                 	fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffDyhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhpppppppppppppppppprrrrrrrrrrrrr1111111111nnnnnnnnttttttttttttdmgggggggggggggggggciiiiiiiiiiiiiiiiiiiiiiiioaeluuuuuuuuuuuuuuuuuuuuu             oaeeeeeeeeeeeeeeeeeeeeessrrrrrrrrrrrrrrrrrrrrrrrnnnnnnnnttttttttttttdm"ciiiiiiiiiiiiiiiiiiil            oaaaaaaaaaaaaaaaaaaaaaeeu            oooooooooooooooooooooaaaaaaaaaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbbbbbbbbb:((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((vMIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII2+)%C0A,E/S$RRRRRRRRRRRRRRRTLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLw-------------------fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff													yhD.ssssssssssssssssppppppppppppppggggggggggggggggggnrttttttttttdddddddd"111111111111immmmmmmmmceuuuuuuuuuuu                                ooael                                     nnnnnnnnnnnnnntsdrrrrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiiiiiiiiiumoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                              hhhhhhhhhhhhhhhhhhhfffffffffffffffgggggggggggggy	nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnt"pdddddddddddddddddddddddddddddddddddddddddddddddsirrrrrrrrrrrrrrrrrruuuuuuuullllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedt1niiiiiiiiiiiiiiiiiiiiiisurlllllllllllllllllllllllllllcccccccccccc            oooooooooooooooooooooaaem                                ooxO
4B'\Nj!!!!!!!!!!!!!!!!!!!!!!!F[;v]3><kkkkkkkkkkkkkkkkkkkkkkkkkk=WG%bbbbbbbbbbbbbbbbbbbbbbbbbbbb:((((((((((((((((((((((((((((((((((PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP$IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII2+)MD0A,E/SCfffffffffffffffffffffTwLRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRyhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"gggggggggggggggggggggggggggd																									-1111111111111111pppppppppppppppppitttttttttnuuuuuuuuuuuuuulsssssssssssrccccccccccaemmmmmmmm                                     oaeeeeeeeeeeee                                 iddddddddddddddddddddddddddutlnnnnnnnnnnnnnnnnnnnnnnnncsmrrrrrroaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeyyyyyyyyyyyyyyyyyyyf"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh	g111111111111111p.idddddddddddddddddddddddddddddddddddddddddutlnnnnnnnnnnnnnnnnnnnnnnnncsmrrrrrrrrrrrr            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeee            oooooooooooooooooooooaadddddddddddddddddddddddditttttttttnuuuuuuuuuuuuuulsssssssssssrceeeeeeeeeem                                ooaeeeeeeeeeeee                                                            )%bbbbbbbbbbbbbbbbbbbbbbbbbbbb:(((((((((((((((((((((((((((((vS$IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII2+++++++++++++++++++++++++++++++++++++++++++++++++++D0A,E/M"wwwwwwwwwwwwwwwwwwwwwRTCL																			fyppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppphdg1111111111111111111111111111111...............................................ttttttttniiiiiiiiiiiiiiiiiiiiiisurlllllllllllllllllllloaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnsirrrrrrrrrrrrrrrrrruuuuuuuuuuuulllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeefffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff																			"""""""""""""""""pppppppppppppythgn-11111111111111dssssssssssssssssssssssssssssssrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiimucl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonstrdddddddddddddddddddddddddddddddddddddddddddddmicccccccccaeeeeeeeeeeeu                                     oael                                 �6����������������������������������������������������ݛ��Y����������������������������������������������������������������������������������������낱��~�����ʾ���γ_Ǹ��````````````````````````````````````````````````````````������������^���Z��QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ��쯩���۬����Ϯ�#������[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[������ߴ��ٲ������} qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq����������������������������������������������������???????????????????????????????????????????????????????????????????????????????????????????????????????????{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{J*VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV8U5@|||||||||||||||||||||||||||||||||H9KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK7&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO
4B'\Nj!!!!!!!!!!!!!!!!!!!!!!!Fxxxxxxxxxxxxxxxxxxxxxxxxxxxxx]3><kkkkkkkkkkkkkkkkkkkkkkkkkk=WG;+)%bbbbbbbbbbbbbbbbbbbbbbbbbbbb:((((((((((((((((((((((((/S$IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII2v.........................D0A,EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERwCCCCCCCCCCCCCCCCCCCCCMTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT	f-LLLLLLLLLLLLLLLLLp""""""""""""""yhssssssssssssssssgrnnnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmmmm1cccccccccccccccccciiiiiioaelllllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeuussssssssssssssrnnnnnnnnnnttttttttttttdmmmmmmmmmmmmmmmccccccccccccccccccil            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeee            oooooooooooooooooooooaa	pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppfu"yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhnstrddddddddddddddddddddddddgggggggggggggggggggmiceeeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnntuds1rrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiiiimoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  (2+)%bbbbbbbbbbbbbbbbbbbbbbbbbbbb:PE/S$IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII-.........................D0A,vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvCRMwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwppppppppppppp																																																														TTTTTTTTTTTTTTTTTTTnf"tttttttttttttttydddddddddddddd1huuuuuuuusirrrrrrrrrrrrrrrrrrllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedtgnnnnnnnnnnnnnnnnnnnnniuuuuuuuuuslrrrrrrrrrrrrrrrrrrrrcccccccccccc            oooooooooooooooooooooaaem                                ooooooooooooooLLLLLLLLLLLLLLLLLppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp	dddddddddddddddddddfg"y11111111tinnnnnnnnnnnnnnnnnnnnnnluuuuuuuuuuuscraemmmmmmmmmm                                     oaeeeeeeeeeeee                                        dihhhhhhhhhtlnnnnnnnnnnnnnnnnnnnnnnnncumssssssoaeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrr             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeF[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[O
44444444444444444444444444'\Nj!!!!!!!!!!!!!!!!!!!!!!!BGGGGGGGGGGGGGGGGGGGGGGGGGGGGG]3><kx)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))====================================:2+(Sbbbbbbbbbbbbbbbbbbbbbbbbbbbb%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%E/PWWWWWWWWWWWWWWWWWWWWWWWWWIIIIIIIIIIIIIIIIIIII$,-........................M0ADDDDDDDDDDDDDDDDDDDDDDDDDDDDDDCRvLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLwpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppg	yffffffffdih"""""""""tlnnnnnnnnnnnnnnnnnnnnnnnncumssssssssssss            oaaaaaaaaaaaaaaaaaaaaaeer            oooooooooooooooooooooaadddddddddd11111111tinnnnnnnnnnnnnnnnnnnnnnluuuuuuuuuuuscerm                                ooaeeeeeeeeeeee                                                                     pppppppppppppTyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyddddddddddddddddddg1	fhttttttttttnnnnnnnnnnnnnnnnnnnnniuuuuuuuuuslrrrrrrrrrrroaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdn"""""""""""""""""""""""uuuuuuuusirrrrrrrrrrrrrrrrrrrrlllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee:2+(Sb)AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE/;;;;;;;;;;;;;;;;;;;;;;;;;I%%%%%%%%%%%%%%%%%%%%%,-........................M0$$$$$$$$$$$$$RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRLCDvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvppppppppppppppp1yyyyyyyyyyyyyyyyTTTTTTTTTTTTTTTTTTTTTTTTTTTttttttttttttttttttttttttttttttttttnfggggggggggggggdu"	ssssssssssrrrrrrrrrrrrrrrrrrrimmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonutsdrhhhhhhhhhhhhhhhhhhhhhmmmmmmmmciaeeeeeeeeeeeeeeeeeee                                     oael                                 ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppf1yyyyyyyyyyyyyyyyyyyyyyyyyyyywwwwwwwwwwwwwwwwwu""""""""""""""""""snrttttttttttttdmhgccccccccccccccccccccccccccccccccoaeliiiiiiiiiiiiiiiiiiiii             oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuuusnrttttttttttttdm	cccccccccccccccccccccccccccl            oaaaaaaaaaaaaaaaaaaaaaeei            oooooooooooooooooooooaaaaaaaaaaaaaaaaaaaaaaaaUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU@VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV56||||||||||||||||||||||||||||||||||HPzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz7&F[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
44444444444444444444444444'\Nj!Ob]G>>>>>>>>>>>>>>>>>>>>>>>>>>>>>k3333333333333333333333333333333333333333<=xBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBIIIIIIIIIIIIIIIIIIII:2+(SSSSSSSSSSSSSSSSSSSSSSSSSSSS0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE/;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;)TTTTTTTTTTTTTTTTTTTTT,-........................M%%%%%%%%%%%%%%%%%%%LRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD$Cyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyp"f11111111111111111111111111111111111wvvvvvvvvvvvvvvhhhhhhhhhhhhhhhhhnutsdr																																						mmmmmmmmceiiiiiiiiiii                                ooael                                     nnnnnnnnnnnnnntttttttttdugssssssssssrrrrrrrrrrrrrrrrrrrimoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                              1yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyh"fpnnnnnnnnnnnnnnnnnnnnnnnnnnnt																											ddddddddddddddgggggggggggggggggggggggggggggggggguuuuuuuusirllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedttttttttttttttttttnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnniulsssssssssssrcccccccccccc            oooooooooooooooooooooaaem                                ooSSSSSSSSSSSSSSSSSSSSSSSSSIIIIIIIIIIIIIIIIIIII:2+(bM0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE/WWWWWWWWWWWWWWWWWWWWWWWWWWWWwTTTTTTTTTTTTTTTTTTTTT,-........................))))))))))))))))DL$R%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%f1yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy	h"""""""""""""""""""dppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppCggggggggggttttttttniiiiiiiiiiiiiilllllllllllllllllllucsaemr                                     oaeeeeeeeeeeee                                          dddddddddddddddddddddddditlnnnnnnnnnnnnnnnnnnnnnnnncccccccccmuuuuuuoaeeeeeeeeeeeesssssssssssssssssssss             oaeeeeeeeeeeeeeeeeeeeeerrfyyyyyyyyyyyyyyyy	1"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""phhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhvvvvvvvvvvvvvvvvvvvvvvdddddddddddddddddddddddddddddddddddddditlnnnnnnnnnnnnnnnnnnnnnnnncccccccccmuuuuuuuuuuuu            oaaaaaaaaaaaaaaaaaaaaaees            oooooooooooooooooooooaadrggggggggggttttttttniiiiiiiiiiiiiilllllllllllllllllllucesm                                ooaeeeeeeeeeeee                                     ;PF[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
44444444444444444444444444'\Nj!(>]kGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG=3<BxOOOOOOOOOOOOOOOOOOOOOOWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWIIIIIIIIIIIIIIIIIIII:2+SSSSSSSSSSSSSSSSSSSSSSSSM0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE/bbbbbbbbbbbbbbbbbbbbbbbbbbbwTTTTTTTTTTTTTTTTTTTTT,-............................	$D%L)Rpyyyyyyyyyyyyyyyyfvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""1dhhhhhhhhhhhhhhhhhhgggggggggggggggggggggggggggggggggggggggggggggggtrnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnniulsssssssssssoaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdnnnnnnnnnnnnnnnnnnnnnnnnnnnnrrrrrrrrrrrrrrrrrruuuuuuuusiiiiiiiiiiiilllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeepy	gC"ft1hnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnndddddddddddddddddddddddddddddddddddddddddurssssssssssssssssssssssssssssmicl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonnnnnnnnntudssssssssssssssssssssssssssssrmmmmmmmmmmccccccccaeeeeeeeeeeei                                     oael                                 +///////////////////////////////////////////////////////IIIIIIIIIIIIIIIIIIII:2(........................M0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAESvvvvvvvvvvvvvvvvvvvvvvvvvvvwTTTTTTTTTTTTTTTTTTTTT,-by%$)DDDDDDDDDDDDDDDDDDDDDDDDDDDDL"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""ppppppppppppppppppppppppppppgCR														f11111111111111111111111hunsttttttttttttdmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmcrrrrrrrrrrrrrrrrrrrrrrrrroaellllllllllllllllllllllllllll             oaeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiunsttttttttttttdmmmmmmmmmmmmmmmmmmmcrrrrrrrrrrrrrrrrrrrrl            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeee            oooooooooooooooooooooaapppppppppppppppppppppppppppppp"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""yyyyyyyyyyyyyyyyyyyyyyyyyyyggggggggggggggggi	ffffffffffffffffffffffffffffff1nnnnnnnnntudssssssssssssssssssshhhhhhhhhhhhrmmmmmmmmmmceeeeeeeeeeeeeeeeee                                ooael                                     nnnnnnnnnnnnnntiddddddddddddddddddddddddddurssssssssssssssssssssssssssssmoaelc                                      oaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee  jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj}qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������?9J*****************************************UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@88888888888888888888888888888888888888888888888888888888888888886VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV5zK|WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH7;PF[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&44444444444444444444444444'\N
2k>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>]=GB3O<!xE////////////////////////////////////////////////////////////////////////////IIIIIIIIIIIIIIIIIIII:+-........................M0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA(CvvvvvvvvvvvvvvvvvvvvvvvvvvvwTTTTTTTTTTTTTTTTTTTTT,SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS)%%%%%%%%%%%%%%%%%%%%%%%%%%%%$bDggggggggggggggggggggggggggggggL"pppppppppppppppppppppppppppppppppppppppppppynnnnnnnnnnnnnnnn	tttttttttttttttttttfddddddddddddddddddddddddddddddd1irrrrrrrrrrrrrrrrrruuuuuuuusllllllllllllllllllllllloaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemc            oaaaaaaaaaaaaaaaaaaaaaeedthnrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiluuuuuuuuuuuscccccccccccc            oooooooooooooooooooooaaem                                oo"""""""""""""gRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRpdyyyyyyyyyyyyyyyyh	ffffffffffffffffffrttttttttttnnnnnnnnnnnnnnnnnnnnnliiiiiiiiiiiiiiiiiiicuaems                                     oaeeeeeeeeeeee                                 rdddddddddd11111111tlnnnnnnnnnnnnnnnnnnnnnnnncimmmmmmmmmmmmmmoaeeeeeeeeeeeeuuuuuuuuuuuuuuuuuuuuu             oaeeeeeeeeeeeeeeeeeeeeesssssssssssssssssssssssssssssssssssss:E/222222222222222222222222IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII-.+++++++++++++++++++++++++++0AM,Cv((((((((((((((((((((((((((((TTTTTTTTTTTTTTTTTTTTTwwwwwwwwwwwwwwwwwwwwwwwwwwwwww)%SSSSSSSSSSSSS$bRD"""""""""""""""""""gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggyyyyyyyyyyyyyyyyyhpffffffffffffffffrdddddddddd1								tlnnnnnnnnnnnnnnnnnnnnnnnncimmmmmmmmmmmmmmmmmmmm            oaaaaaaaaaaaaaaaaaaaaaeeu            oooooooooooooooooooooaadssssssssssssssssssrttttttttttnnnnnnnnnnnnnnnnnnnnnliiiiiiiiiiiiiiiiiiiceum                                ooaeeeeeeeeeeee                                                       yL"""""""""""""fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffgdddddddddddddddddhhhhhhhhhhhhhhhhhhpppppppppppppppp1tsnrrrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiluuuuuuuuuuuoaeeeeeeeeeeeec                                      oaemmmmmmmmmmmmmmmmmmmmm  tdn														sirrrrrrrrrrrrrrrrrruuuuuuuuuuuuuuuuuuulllllllllllloaeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmc            oaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeW;PF[[[[[[[[[[[[[[[[[[[[[[[jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj44444444444444444444444444'\NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNk=>]BGOOOOOOOOOOOOOOOOOOOOOOOOOOOOO!3
<A:E/222222222222222222222222IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx-.+++++++++++++++++++++++++++0000000000000000000000000R,Cv((((((((((((((((((((((((((((TM"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%$)wSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSyLbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbffffffffffffffffffffffffffftgggggggggggggggggnnnnnnnnnnnnnnnnhhhhhhhhhhhhhhdi	pppppppppsurrrrrrrrrrrrrrrrrrrrrmmmmmmmmcl            oooooooooooooooooooooaaeeeeeeeeeee                                ooooooooooooooonitttttttttdu111111111111smrccccccccccaeeeeeeeeeeeeeeeeee                                     oael                                 DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDy"""""""""""""""""""""""""""""""""ffffffffffffffffffffffffffffffffffffffffffffgi																									nuttttttttttttdm1hcsssssssssssrrrrrroaell