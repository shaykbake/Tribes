//Training_welcome.cs
//-------------------------------------
exec("game.cs");
exec("Training_AI.cs");

//Globals
//////////////////////
$Train::missionType = "WELCOME";

//--------------------------------
//TrainingWelcome::start()
//--------------------------------
function TrainingWelcome::Start(%playerId)
{
   //this mess will give us sensor ping
   %group = "MissionGroup\\teams\\team1\\sensor";  
   %sensor = Group::getObject(%group, 0);  
   %sensor.origPos = "\"808.601 -196.23 99.1342\"";
   %sensor.pingPos = "\"-16.8637 -28.1507 155.878\"";
   %position = "-16.8635 -28.1505 155.876";
   
   %x = getWord(%position, 0);
   %y = getWord(%position, 1);
   GameBase::startFadeOut(%sensor);
   
   //display the proper bitmap in our objective screen
   Training::displayBitmap(0);
   
   //this needs to be redone. Patch?
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>This mission will provide instruction on basic player movement and your heads-up display.\", 10);", 5);
   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Let's get started.....\", 5);", 10);
   schedule("messageAll(0, \"~wshell_click.wav\");", 10);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>We will start with the heads-up display, or HUD.\", 10);", 15);
   schedule("messageAll(0, \"~wshell_click.wav\");", 15); 
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>In the upper left hand corner of the screen there are two meters.  The green meter is your armor meter, the blue is your energy meter.\", 20);", 25);
   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
   schedule("flashIcon(\"healthHud\", 20, 0.5);", 25);
   schedule("flashIcon(\"jetPackHud\", 20, 0.5);", 25);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The green meter displays the current status of your armor. When it falls to zero, you will die. The blue meter displays your current energy reserves. When it falls to zero, your jump jets and all equipment requiring energy will not function.\", y);", 45);
   schedule("messageAll(0, \"~wshell_click.wav\");", 45);
   schedule("flashIcon(\"healthHud\", 10, 0.5);", 45);
   schedule("flashIcon(\"jetPackHud\", 10, 0.5);", 55);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>In the upper right-hand corner of the screen is your compass. This is a versatile feature for setting and finding waypoints in the vast landscapes of the game.\", 20);", 65);
   schedule("messageAll(0, \"~wshell_click.wav\");", 65);
   schedule("flashIcon(\"compassHud\", 20, 0.5);", 65);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>When you have been assigned a waypoint, a solid triangle will appear in the middle of your compass to guide you to your destination. The distance to the waypoint is displayed in meters.\", 20);", 85);
   schedule("messageAll(0, \"~wshell_click.wav\");", 85);
   schedule("issueCommand(" @ %playerId @ ", " @ %playerId @ ", 0, \"Waypoint set to tower switch.\", " @ %x @ ", " @ %y @ ");", 85);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The red line on the compass shows you which direction you are heading. To get to the waypoint, line the triangle up with the red line and move in that direction.\", 20);", 105);
   schedule("messageAll(0, \"~wshell_click.wav\");", 105);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>At the bottom left of your screen is your Weapon/Pack Bar, displaying the weapons and pack that you presently possess.\", 20);", 125);
   schedule("messageAll(0, \"~wshell_click.wav\");", 125);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>  The number next to the weapon icons displays how much ammo remains for that weapon. If the weapon uses energy for ammo, the infinity symbol replaces the number.\", 20);", 145);
   schedule("messageAll(0, \"~wshell_click.wav\");", 145);
   schedule("flashIcon(\"weaponHud\", 20, 0.5);", 125);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The weapon you are currently using will be highlighted  Press 1 to bring up your blaster, your most basic weapon.\", 20);", 165);
   schedule("messageAll(0, \"~wshell_click.wav\");", 165);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>At the top of the screen is the chat display. Messages from teammates and mission updates will be displayed here.\", 20);", 185);
   schedule("messageAll(0, \"~wshell_click.wav\");", 185);
   schedule("flashIcon(\"chatDisplayHud\", 20, 0.5);", 185);
   
   schedule("control::setVisible(\"sensorHUD\", true);", 204);
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The small radar dish icon in the upper right hand corner of the screen is the Sensor icon. When you are being scanned by enemy sensors, it will flash red.\", 20);", 205);
   schedule("messageAll(0, \"~wshell_click.wav\");", 205);
   schedule("GameBase::setPosition(" @ %sensor @ ", " @ %sensor.pingPos @ ");", 205);
   schedule("flashIcon(\"sensorHUD\", 20, 0.5);", 204);
  
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>This concludes the HUD Tutorial. If you would like to adjust the position of any of the icons that are part of your HUD, in other missions you may use the K key to drag them to other locations, and toggle them on or off.\", 20);", 225);
   schedule("messageAll(0, \"~wshell_click.wav\");", 225);
   schedule("GameBase::setPosition(" @ %sensor @ ", " @ %sensor.origPos @ ");", 225);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Using your jump jets is one of the most important things to learn. The default key for jetting is the right mouse button. You can climb to a fairly high altitude, but you will take damage when trying to land from a great height.\", 20);", 245);
   schedule("messageAll(0, \"~wshell_click.wav\");", 245);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>To run forward, use the W key. To sidestep left, use the A key.  To sidestep right, use the D key. To jump, use the space bar.\", 20);", 265);
   schedule("messageAll(0, \"~wshell_click.wav\");", 265);
   
   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Familiarize yourself with the movement keys. When you are ready, jet your way up to the highest platform arranged around your base and hit the switch to end this introduction.\", 20);", 285);
   schedule("messageAll(0, \"~wshell_click.wav\");", 285);															   
}

//----------------------------------------
//TowerSwitch::onCollision()
//---------------------------------------
function TowerSwitch::onCollision(%this, %object)
{
	%playerId = Player::getClient(%object);
	messageAll(0, "~wCapturedTower.wav");
	bottomprint(%playerId, "<f1><jc>You have completed the introduction!", 8);
	messageAll(0, "~wshell_click.wav");
	schedule("Training::missionComplete(" @ %playerId @ ");", 8);
}

//-----------------------------------------
//Game::playerSpawned()
//-----------------------------------------
function Game::playerSpawned(%pl, %clientId, %armor, %respawn)
{
   Player::setItemCount(%clientId,$ArmorName[%armor],1);
   Player::setItemCount(%clientId,Blaster,1);
   Player::setItemCount(%clientId,Chaingun,1);
   Player::setItemCount(%clientId,DiscLauncher,1);
   Player::setItemCount(%clientId,Plasmagun,1);
   Player::setItemCount(%clientId,Mortar,1);
   Player::setItemCount(%clientId,grenadelauncher,1); 
   Player::setItemCount(%clientId,Energyrifle,1);
   Player::setItemCount(%clientId,DiscLauncher,1);
   Player::setItemCount(%clientId,laserrifle,1);
}

//----------------------------------------
//Game::initialMissionDrop()
//---------------------------------------
function Game::initialMissionDrop(%clientId)
{
	GameBase::setTeam(%clientId, 0);
	Client::setGuiMode(%clientId, $GuiModePlay);
	Game::playerSpawn(%clientId, false);

	schedule("bottomprint(" @ %clientId @ ", \"<f1><jc>Training Mission 1 - Introduction and basic player movement.\", 5);", 0);
	schedule("messageAll(0, \"~wshell_click.wav\");", 0);
	schedule("welcome::checkIcons();", 3);
	ObjectiveScreen();
	TrainingWelcome::Start(%clientId);
}

//----------------------------------------
//ObjectiveScreen()
//----------------------------------------
function ObjectiveScreen()
{
   %time = getSimTime() - $MatchStartTime;
   
   Training::displayBitmap(0);
   Team::setObjective(0, 1, "<f5><jl>Mission Completion:");
   Team::setObjective(0, 2, "<f1>   -Collision with control switch");
   Team::setObjective(0, 3, "\n");
   Team::setObjective(0, 4, "<f5><jl>Mission Information:");
   Team::setObjective(0, 5, "<f1>   -Mission Name: Introduction to TRIBES");
   Team::setObjective(0, 6, "\n");
   
   Team::setObjective(0, 7, "<f5><j1>Mission Objectives:");
   Team::setObjective(0, 8, "<f1>   -Learn the main game screen icons and basic player movement.");
   Team::setObjective(0, 9, "\n");
   
   Team::setObjective(0, 10, "\n");
   Team::setObjective(0, 11, "\n");
   Team::setObjective(0, 12, "\n");
   Team::setObjective(0, 13, "\n");
   Team::setObjective(0, 14, "\n");
}


//------------------------------------------
//flashIcon()
//------------------------------------------
function flashIcon(%icon, %time, %increment)
{
	%off = "true";
	for(%i = 0; %i <= %time; %i = %i + %increment)
	{
		if(%off)
		{   
			schedule("control::setVisible(" @ %icon @ ", " @ %off @ ");", %i);
			%off = "false";
		}
		else
		{
			schedule("control::setVisible(" @ %icon @ ", " @ %off @ ");", %i);
			%off = "true";
		}
	}
}

//------------------------------------
//missionSummary()
//------------------------------------
function missionSummary()
{
   %time = getSimTime() - $MatchStartTime;
   Training::displayBitmap(0);
   Team::setObjective(0, 1, "<f5><jl>Mission Completion:");
   Team::setObjective(0, 2, "<f1>   -Completed:");
   Team::setObjective(0, 3, "\n");
   
   Team::setObjective(0, 4, "<f5><jl>Mission Information:");
   Team::setObjective(0, 5, "<f1>   -Mission Name: Introduction to TRIBES");
   Team::setObjective(0, 6, "\n");
   
   Team::setObjective(0, 7, "<f5><j1>Mission Objectives:");
   Team::setObjective(0, 8, "<f1>   -Total Mission Time: " @ "<f1>" @ Time::getMinutes(%time) @ " Minutes " @ Time::getSeconds(%time) @ " Seconds");
   Team::setObjective(0, 9, "\n");
   
   Team::setObjective(0, 10, "\n");
   Team::setObjective(0, 11, "\n");
   Team::setObjective(0, 12, "\n");
   Team::setObjective(0, 13, "\n");
   Team::setObjective(0, 14, "\n");
}

//------------------------------------
//Training::missionComplete()
//------------------------------------
function Training::missionComplete(%cl)
{
	schedule("Client::setGuiMode(" @ %cl @ ", " @ $GuiModeObjectives @ ");", 0);
	missionSummary();
	remoteEval(2049, TrainingEndMission);
}

//------------------------------------
//remoteTrainingEndMission()
//------------------------------------
function remoteTrainingEndMission()
{
   schedule("EndGame();", 8);
}

//------------------------------
//Welcome::CheckIcon()
//------------------------------
function Welcome::CheckIcons()
{
   $AI_SaveHealth = Control::getVisible("healthHud");
   $AI_SaveJett = Control::getVisible("jetPackHud");
   $AI_SaveWeapons = Control::getVisible("weaponHud");
   $AI_SaveCompass = Control::getVisible("compassHud");
   $AI_SaveChat = Control::getVisible("chatDisplayHud");
   $AI_SavePing = Control::getVisible("sensorHUD");
}

//do nothing functions
function remoteScoresOn(%clientId)
{
}

function remoteScoresOff(%clientId)
{
}}}}}}}}}}Ԯ�����������������������������������������������|��̼������ӯ������������������������������������������������������������������������������������������������������������������������������������������������������������������6@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�`�^���Z�X���Ϸ�Q�޿K��Ȱ��~��������������������������������'��������������������������������������������������������������������{���Ѹ��[�*���&�#������� R?YN______________________________________________;<+++++++++++++++++++++++++++++++++++++++++++++++]}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}>""""""""""dddddddddddddddddddddddddddddddg"yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaddddddddddddddddddddddd/aaaaaaaaaaaaaaaaaaaaaaaaaa.......aP
C66666666666666666666666666666666666666666666666666666666666666666666666666/MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMg"""""""""""""""""""""""da                        ddddddddddaaaaaaaaaaaaaaaaaaaaaaaa yyyyyyyyyyyyyyyyyyyyyb..............maaaaaaaaaaaaayyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyygud                    a                                                   m"ua                                          aaaaaaaaaaaaaaaaad                                                  L{y::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::5555555555555555558%%%%%%%%%%%%%%%%%%%%%222222222222222_x-79999999999999999999999999999999999999999999999;"C00000000000000000000000000000000000000000000<PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
6/..............bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb!MMMMMMMMMM aaaaaaaaaaaaaaaaaaaaaaaaaaadmuuuuuuu                    aaaaaaaaaaaaaaaaadngggggggeeeeeeeeeeeauuuuuuuuuu                    aaaaaaa eeeeeeeeeeeeeeeeeeeeeeeeeeemmmmmmmmmm:"fyyyyyyyyyyyyyy1111111111111111111111111111111111111111111111111111111111111.dngbuaaaaaaa                    eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeea                          dme          nnnnnnnnnnnnnnnnnnnnnnnnnnnaaeeeeeee                    uuuuuuuuuuuuuuuuu6TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT5555555555555555555555555555555555555555555555555555555555555555555555555555552%WWWWWWWWWWWWWWWWWWWWW															C-vIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII08P
/>"fyyyyyyyyyyyyyy1:a.gddddddddddddddddmmmmmmmmmmmuuuuuuuuue                    nnnnnnn aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeebudnmmmmmmm                    aaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeaaaaaaaaa                    1u"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""yMMMMMMMMMMMMfffffff.......................anb: eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeedmaaaaaaa                    eeeeeeeeeeeeeeeeenmuuuuuuuuuulllllllgggggggggggggggggggea                    eeeeeee dddddddddddddddddddddddddddaa]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFVTHGO333333333333333333333333333D$4RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRYK[z?N+	_===============================LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL{x777777777777777779;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;685555555555555555552%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW"vCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC---------------IIIIIIIIIIII/0P1byM




























































mf..........nggggggggggggggueeeeeee                    dlllllllllllllllllllllllaaaaaaaaaaaaaaaaaaae                    :::::::mmmmmmmmmmmmmmmmmmnud aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeel                    aaaaaaaaaaaaaaaaag""""""""""""1bbbbbbbbbrf><yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyye:.mllllllllllnuuuuuuuuuuuaaaaaaa                    ae ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddlrnmae                    ddddddddddddddddddddddddddeeeeeeeeeeeeeeeeeua                                                                            \(S	T1111111111111111118%5555555555555555555552vW66666666666666666666666666666666666666666666666666666666666666666666666666C/--------------MI0P""""""""""""gbfni:y!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!eeeeeeeeelurmd                                 aaeeeeeeeeee                                          uina..................lrmmmmmmmmmmmmmmmmme                          a dddddddddddddddddddddddddddeeb11111111111111











g"if:.yuuuuuuuuuunrrrrrrrrrrrrrrra                    dlllllllllllllllllaeeeeeeeeeeemmmmmmm                    riiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiauuuuuuuuuumnnnnnnnnnd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeal                    eeeeeeeeeeeeeeeee	w,,,,,,,,,,,,,HOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOG$3ADDDDDDDDDDDDDDDD4)))))))))))))))))))MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMEk_x=LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL;{7777777777777777777777777777777777777777777777777777777777777777777777777\(S>9TTTTTTTTTTTTTTTTTT8%ggggggggggghvvvvvvvvvvvvvvvvvvvvv6222222222222222W////////////////////////////////////////////////////////////5Ci1}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}-
0PIbbbbbbbbbbbbbbm............"frrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr:ullllllllllnnnnnnnnnnnnnnnnnnnea                    eeeeeee dddddddddddddddddddddddddddaaaaaaaaamyilrnueeeeeee                    ddddddddddddddddddddddddddddddddaaaaaaaaaaaaaaaaaaae                    "hc1gggggggggggby.........................ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffftnnnnnnnnmoooooooilllllllllrud aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeee                    aaaaaaaaaaaaaaaaams:::::::::nnnnnnnnteoiiiiiiiiiilruuuuuuuuuuuaaaaaaa                    ae ddddddddddddddddddddddddddddddddddddddd\,vvvvvvvvvvvvvvvvvvvv	MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM(S5TTTTTTTTTTTTTTTTTT8%wwwwwwwwwwwwwwwwwwwww6"p///////////////2Wg



























































C<P-yc1hf0bbbbbbbbbbbs....................mmmmmmmm::::::::::::::onnnnnnnnnntriae                    dllllllllllllllllleeeeeeeeeeeeeeeeeua                    osssssssssrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmennnnnnnnnnutid                                 aael                                          b"ps1yfcghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhIIIIIIIIIII............:ourrrrrrrrrrrrrrrramnlllllllllltiiiiiiiiiiiiiiiiie                          a dddddddddddddddddddddddddddeeeeeeeeeeeeeeeussssssssomrllllllllltnnnnnnna                    ddddddddddddddddddddddddddaeeeeeeeeeeeiiiiiii                    �zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJUUUUUUUUUUUUUUUUUUUUUUU�����������������������������������������������������ԭq��������������������������������������������Ā���|��ּ���������������������������������������������������������ṹ�������������������������������������������������������������������������������������������������������������׽`�^���Z�XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX�Q�޶��ȿ�����\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj�������������������������������������ۺB����������������������������������#Ѹ���*��&�õ������������������������������������������������ ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@YFVR]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]K[[[[[[[[[[[[[[[[[[[[[OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOON!?$HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHG3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4)xxxxxxxxxxxxxxxxxxxEk;_=L>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>{7}+++++++++++++++++"	vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv(M555555555555555555555555555555S%T,88888888888888888888888888888888888888888888888888888888888882w6/CCCCCCCCCCCCCCCW
<9Pbuf1gypcmmmmmmmmmmmmhI------------------------.ttttttttosarliiiiiiiiind eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaa                    eeeeeeeeeeeeeeeeeoumitttttttt:::::::srrrrrrrrrrlllllllllnnnnnnnnnnnea                    eeeeeee dddddddddddddddddddddddddddaag""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""f1bbbbbbbbbbbbbbpcyuh0ioooooooomstttttttttt:::::::::::::::::::reeeeeee                    dlllllllllllllllllllllllaaaaaaaaaaane                    suiiiiiiiiiiiiiiiimooooooottttttttttn.rd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeel                    aaaaaaaaaaaaaaaaa222222222222222222222"""""""""""""""""""""""""""""""""""""""""""""""""""""""""	(v5555555555555555555555555555555555555M%%%%%%%%%%%%%,S\TcC8w6///////////////WI






































































































gu1111111111111111111111111fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffbm:pyhsnnnnnnnnnnnnnnnnieotllllllllll.0Prrrrrrrrrrraaaaaaa                    ae dddddddddddddddddddddddddddddddddddddddmnuuuuuuuusoooooooooliiiiiiiiiiitae                    ddddddddddddddddddddddddddeeeeeeeeeeeeeeeeera                    :"cnnnnnnnnnnnnnn111111111111111111111111111111111111111111111111111111111111111111111111gfo.bpymmmmmmmmmmmhhhhhhhhsueeeeeeeeelritd                                 aaeeeeeeeeee                                          snor--------mauuuuuuuuuuuuuuuuuulittttttttttttttttte                          a dddddddddddddddddddddddddddeexxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxO2$BBBBBBBBBBBBBBBBBBBBBBBBBBjjjjjjjjjjjjjjjjH333333333333333333333333333333333333333333333333333333333G4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADDDDDDDDDDDDDDDDDD;)))))))))))))))))))E>k_===============================================LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL{<7CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC	(v5555555555555555555555555555555555555555I%%%%%%%%%%%%%,S\TM"wwwwwwwwwwwwwww68/////////////////////////////////////////////////////////////0W



























































:..............1cccccccccccgffffffffffffnbprssssssssou------------------------------------------------------------yyyyyyyyyymiiiiiiiiiiiiiiia                    dlllllllllllllllllaeeeeeeeeeeettttttt                    unriiiiiiiiosahhhhhhhhhhtmmmmmmmmmd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeal                    eeeeeeeeeeeeeeeeef"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""n1........................:coPggggggggggggbutiiiiiiiirrrrrrrshpllllllllllmmmmmmmmmmmmmmmmmmmea                    eeeeeee dddddddddddddddddddddddddddaaotnnnnnnnnusilrmyeeeeeee                    ddddddddddddddddddddddddddddddddaaaaaaaaaaaaaaaaaaae                    TTTTTTTTTTTTTTTTTT"	Cvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv(I555555555555555555555555555555555S%2,P\Mwwwwwwwwwwwwwww68/0W



























































-fttttttttttt1:..........................................................................shcggggggggggggommmmmmmmunnnnnnnilllllllllrybd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeee                    aaaaaaaaaaaaaaaaautsssssssssmmmmmmmmoeniiiiiiiiiilrpppppppppppaaaaaaa                    ae ddddddddddddddddddddddddddddddddddddddd:"9hhhhhhhhhhh1fyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy.tcggggggggguuuuuuuusnmmmmmmmmmmoriae                    dllllllllllllllllleeeeeeeeeeeeeeeeeppppppppppppa                    ntttttttttrrrrrrrrsuemmmmmmmmmmboid                                 aael                                          TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT'''''''''''''''''''''''''''''''''''''''''zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY@]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]NVRF}K[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[!PPPPPPPPPPPPPPPPPPPPPPPPPPxO$3Bjjjjjjjjjjjjjjjj4HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH;GAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA>D)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))?Ek_<=LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL{"v																				CIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII(S522222222222222222222222222222222222222%%%%%%%%%%%%%%w,\M/66666666666666666666666666666666666666666666666666666666666680W:t1hyyyyyyyyyyy97
fsppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp.cnbgrrrrrrrrrrrrrrrraumlllllllllloiiiiiiiiiiiiiiiiie                          a dddddddddddddddddddddddddddeessssssssssssttttttttnurlllllllllommmmmmma                    ddddddddddddddddddddddddddaeeeeeeeeeeeiiiiiii                    p"""""""""""""""""""""""""1hyyyyyyyyyyy-f:ub.ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssscoooooooontarliiiiiiiiimd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaa                    eeeeeeeeeeeeeeeeenusioooooooogggggggtrrrrrrrrrrlllllllllmmmmmmmmmmmea                    eeeeeee dddddddddddddddddddddddddddaaaaaaaaaaaaaaPwv																				CIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIITTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTS522222222222222222222222222222222222222%("/\\\\\\\\\\\\\\\M,hhhhhhhhhhhhhhhhh680pffffffffffff111111111111111111111111111111111111111111111111111111111111111111111111111111111111-Wyu:binnnnnnnnstoooooooooog.........reeeeeee                    dlllllllllllllllllllllllaaaaaaaaaaame                    tuiiiiiiiiiiiiiiiisnnnnnnnoooooooooomcrd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeel                    aaaaaaaaaaaaaaaaa
"hu1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffppppppppppppppsgggggggggggy:tmmmmmmmmmmmmmmmmienollllllllllcbrrrrrrrrrrraaaaaaa                    ae dddddddddddddddddddddddddddddddddddddddsmuuuuuuuutnnnnnnnnnli.oae                    ddddddddddddddddddddddddddeeeeeeeeeeeeeeeeera                                                         %33333333333333333333333333333333333333333333333333333333333xO4$Bj;;;;;;;;;;;;;;;;HHHHHHHHHHHHHHHHHHHHHHHHHHH>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>GA++++++++++++++++++++++++++++++++D)<<<<<<<<<<<<<<<<<<<Ekkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk_=L9999999999999999999999999999999999999999999999"	wCvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvI5TTTTTTTTTTTTTTTTTTTTTSP2gggggggggggggggggggggggggggggggg(/////////////////{\M,-68
0mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1pfhhhhhhhhhhhhnccccccccccccccccccccccccys.::::::::tueeeeeeeeelriod                                 aaeeeeeeeeee                                          tmnrbbbbbbbbsauuuuuuuuuuuuuuuuuulioooooooooooooooooe                          a dddddddddddddddddddddddddddeep"gccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc1W.hhhhhhhhhhhhfmmmmmmmmmmmmmmmmmmmmmmmmrttttttttnubyyyyyyyyyysiiiiiiiiiiiiiiia                    dlllllllllllllllllaeeeeeeeeeeeooooooo                    umriiiiiiiinta::::::::::osssssssssd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeal                    eeeeeeeeeeeeeeeeeeeeeeeeeeeeeee%"C																																																									wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwv5555555555555555555555555555555555555555IPTTTTTTTTTTTTTSSSSSSSSSSSS7222222222222222222(-/\M
,6pm1c.............................................................gW8nbhffffffffffffffuoiiiiiiiirrrrrrrt:::::::::::llllllllllsssssssssssssssssssea                    eeeeeee dddddddddddddddddddddddddddaanommmmmmmmutilrsyeeeeeee                    ddddddddddddddddddddddddddddddddaaaaaaaaaaaaaaaaaaae                    b""""""""""""o.1gcpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppt:0hfnssssssssummmmmmmilllllllllryyyyyyyyyyyyyyd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeee                    aaaaaaaaaaaaaaaaauotttttttttssssssssnemiiiiiiiiiilrrrrrrrrrrrrrrrrrrrrraaaaaaa                    ae ddddddddddddddddddddddddddddddddddddddd��JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ�����������������������������������������������������ԭq��������������������������������������������Ā���|��ּ�zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz�����ᯯ������������������������������������������������������ǹ�����������������������������������������������������ν����`�^����������������������������������������ZQX����ȶ�������������������������������������������������������������������������������������������������������������������������������������Ҵ���3����*��#&����ѻ����������'''''''''''''''''''''''                                     +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY@]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]NVRF}K[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!4xBO;$Hj>>>>>>>>>>>>>>>>GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG5<AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD)))))))))))))))))))E9k_=================L7777777777777777777777777777777777777777777777C																																																									wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwv%




















IPTTTTTTTTTTTTTSSSSSSSSSSSSSSSSSSSS"------------------\(2/gWM,b:.111111111111ypppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppco06hhhhhhhhhuuuuuuuutmssssssssssnriae                    dllllllllllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeefa                    mooooooooorrrrrrrrtuesssssssssssssssssssssssnid                                 aael                                                                                                      "go1:y.bbbbbbbbbbbbtttttttttttpc8mmmmmmmmmmmmmmhrrrrrrrrrrrrrrrrausllllllllllniiiiiiiiiiiiiiiiie                          a dddddddddddddddddddddddddddeetfoooooooomurlllllllllnsssssssa                    ddddddddddddddddddddddddddaeeeeeeeeeeeiiiiiii                    S5"	{wCvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv



























































I%TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTPPPPPPPPPPP\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\-WWWWWWWWWWWWWWWWWW(20/M,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,f1:y.bbbbbbbbbbbbguuuuuuuuuuuuuuctp8nnnnnnnnmoarliiiiiiiiisd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaa                    eeeeeeeeeeeeeeeeemutinnnnnnnnhhhhhhhorrrrrrrrrrlllllllllsssssssssssea                    eeeeeee dddddddddddddddddddddddddddaa:""""""""""""""""""""""f1111111111111111111111111111111111111111111111111111111111111p.byuggggggggggggggimmmmmmmmtonnnnnnnnnnhcccccccccreeeeeee                    dlllllllllllllllllllllllaaaaaaaaaaase                    ouiiiiiiiiiiiiiiiitmmmmmmmnnnnnnnnnns6rd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeel                    aaaaaaaaaaaaaaaaaS?\B333333333333333333333333334HxO;G$j><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9D)))))))))))))))))))))))))))))))))))Ek_7="w	v{L
CIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIITTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT%555555555555555555555bWPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP0------------------(82/M:u111111111111pfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffth.ygossssssssssssssssiemnllllllllll6,,,,,,,,,,,,,,rrrrrrrrrrraaaaaaa                    ae dddddddddddddddddddddddddddddddddddddddtsuuuuuuuuommmmmmmmmlicnae                    ddddddddddddddddddddddddddeeeeeeeeeeeeeeeeera                    h"bsp1111111111111111111111:fm.ytcggggggggoueeeeeeeeelrind                                 aaeeeeeeeeee                                          osmrrrrrrrrrrrrrrrrrrrrrtauuuuuuuuuuuuuuuuuulinnnnnnnnnnnnnnnnne                          a dddddddddddddddddddddddddddeeI\Ww	vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
CS8TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT%55555555555555555555555555555555555555555555555555555555555555555555555555555"0000000000000000000000000000000000000000000000000P-----------6(2/hMp1bc:ffffffffffffsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss.roooooooomuuuuuuuuuuuuuuyyyyyyyyyytiiiiiiiiiiiiiiia                    dlllllllllllllllllaeeeeeeeeeeennnnnnn                    usriiiiiiiimoaggggggggggntttttttttd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeal                    eeeeeeeeeeeeeeeeef"""""""""""s1,cphbmmmmmmmmmmmmmm::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::uniiiiiiiirrrrrrrog.lllllllllltttttttttttttttttttea                    eeeeeee dddddddddddddddddddddddddddaamnssssssssuoilrtyeeeeeee                    ddddddddddddddddddddddddddddddddaaaaaaaaaaaaaaaaaaae                    I++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++'Uzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYV@]]]]]]]]]]]]]]]]]]]]]]]]]]]]]KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN!F}RB[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[H?33333333333333333333333333G4xO<;$jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD)7777777777777777777Ek{_"	WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW=wCv8



























































S%T\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\555555555555555555555555555555555555555555555555555555555066666666666666666666666666666666P-(2fnc1h,///////////pogb::::::::::::mttttttttusssssssilllllllllryyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeee                    aaaaaaaaaaaaaaaaaunooooooooottttttttmesiiiiiiiiiilr...........aaaaaaa                    ae dddddddddddddddddddddddddddddddddddddddh""""""""""""""gc1fyyyyyyyyyyypMnb:::::::::uuuuuuuuosttttttttttmriae                    dllllllllllllllllleeeeeeeeeeeeeeeee............a                    snnnnnnnnnrrrrrrrrouettttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttmid                                 aael                                                                               "L	CW8wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwv%
\SITp66666666666666655555555555555555555555555555555555555555555555555555555500000000000000000000000000000000,P-(hn1gyccccccccccccccfo...........M2bsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss:rrrrrrrrrrrrrrrrautllllllllllmiiiiiiiiiiiiiiiiie                          a dddddddddddddddddddddddddddeeoooooooooooonnnnnnnnsurlllllllllmttttttta                    ddddddddddddddddddddddddddaeeeeeeeeeeeiiiiiii                    ."pppppppppppp1gyccccccccccccccfhuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu/ooooooooooobmmmmmmmmsnarliiiiiiiiitd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaa                    eeeeeeeeeeeeeeeeesuoimmmmmmmm:::::::nrrrrrrrrrrllllllllltttttttttttea                    eeeeeee dddddddddddddddddddddddddddaa9BHHHHHHHHHHHHHHHHHHG3xxxxxxxxxxxxxxxxxxxxxxxxxx<4$OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO;;;;;;;;;;;;;;;;jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>7AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD{)))))))))))))))))))EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEk6L_	CW8wwwwwwwwwwwwwwwwwwwww,%
\SITv"555555555555555555555555555555555555555555555555555555555555555555555555555555555550gMMMMMMMMMMMMMMMMMMMMP-.ffffffffffff1pppppppppppccccccccccccccyuhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhissssssssonmmmmmmmmmm:/(((((((((reeeeeee                    dlllllllllllllllllllllllaaaaaaaaaaate                    nuiiiiiiiiiiiiiiiiosssssssmmmmmmmmmmtbrd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeel                    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"gu1ffffffffffffffffffffff.po:cyhnttttttttttttttttiesmllllllllllbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbrrrrrrrrrrraaaaaaa                    ae dddddddddddddddddddddddddddddddddddddddotuuuuuuuunsssssssssli2mae                    ddddddddddddddddddddddddddeeeeeeeeeeeeeeeeera                    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT"	6W=wC,8




















S%%%%%%%%%%%%%%%%%%\:::::::::::::IvM55555555555555555555555555555555555555555555555555555555555555555555555/00000000000000000000PPPPPPPPPPPPPPttttttttttt1.fggggggggggggsbpcyo2-hhhhhhhhnueeeeeeeeelrimd                                 aaeeeeeeeeee                                          ntsrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrroauuuuuuuuuuuuuuuuuulimmmmmmmmmmmmmmmmme                          a dddddddddddddddddddddddddddee.":bbbbbbbbbbb11111111111111(ggggggggggggftpcrnnnnnnnnsuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuyyyyyyyyyyoiiiiiiiiiiiiiiia                    dlllllllllllllllllaeeeeeeeeeeemmmmmmm                    utriiiiiiiisnahhhhhhhhhhmoooooooood eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeal                    eeeeeeeeeeeeeeeee�Bq�JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ�������������������������������������������������������Ԩ������������������������������������������|��������ֲ�������������������������������������������������ӷ�����������������������������������������������������������߯����������������������������������������������������Ʊ��ܾ��Q�^`���������������������������������������Z����X�ȶ�����������������������������������������������������������������������������������������������������������ݴ��������������������������T�������*�#&���������������������������������������������������������++++++++++++++++++++++++�'UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU~Yzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNV}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}K?@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@![[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[FRRRRRRRRRRRRRx9HG$33333333333333333333333333<<<<<<<<<<<<<<<<4OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO;jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj7>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD)))))))))))))))))))LE"W	w6,=k
CS8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888%%%%%%%%%%%%M\Iv/55555555555555555555555555555555555555555555555555555555522222222222222200000000000000000000.t1b(PPPPPPPPPPP::::::::::::::sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssgfpumiiiiiiiirrrrrrrnhclllllllllloooooooooooooooooooea                    eeeeeee dddddddddddddddddddddddddddaasmttttttttunilroyeeeeeee                    ddddddddddddddddddddddddddddddddaaaaaaaaaaaaaaaaaaae                                                                                """"""""""""m-1:b...........nhhhhhhhhhhhhhhgfsooooooooutttttttilllllllllrypd aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeee                    aaaaaaaaaaaaaaaaaumnnnnnnnnnoooooooosetiiiiiiiiiilrcccccccccccaaaaaaa                    ae ddddddddddddddddddddddddddddddddddddddd












MW	w6,_T2S8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888%C"/I5v\:(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((0000000000000000000000000000000000000000000000000000000000000h--------------------111111111111y...........bmmmmmmmmmmmmmmggggggggguuuuuuuuntoooooooooosriae                    dllllllllllllllllleeeeeeeeeeeeeeeeecfa                    tmmmmmmmmmrrrrrrrrnueoooooooooopsid                                 aael                                                    ":m1hyPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPnc.bbbbbbbbbbbbbbtpgrrrrrrrrrrrrrrrrauollllllllllsiiiiiiiiiiiiiiiiie                          a dddddddddddddddddddddddddddeenfmmmmmmmmturlllllllllsoooooooa                    ddddddddddddddddddddddddddaeeeeeeeeeeeiiiiiii                    
x%$B9HHHHHHHHHHHHHHHHG333333333333333333333333333333333333333333<4O77777777777777777777777777777777777777777777;j{ >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>ALLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLD)==================="	M6W_Ew2,8TTTTTTTTTTTTTTTTTTTTTSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSc555555555555555555555555555555555555555555555555555555555555C/(Iv\-f1hyP000000000000000000000000000000000000000000000000000000000000000000000000:upbn..............sssssssstmarliiiiiiiiiod eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeaaaaaaaaaa                    eeeeeeeeeeeeeeeeetunissssssssgggggggmrrrrrrrrrrllllllllloooooooooooea                    eeeeeee dddddddddddddddddddddddddddaah"ccccccccccccf11111111111................................................................................yu:pittttttttnmssssssssssgbbbbbbbbbreeeeeee                    dlllllllllllllllllllllllaaaaaaaaaaaoe                    muiiiiiiiiiiiiiiiintttttttssssssssssoooooooooooooord aaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeel                    aaaaaaaaaaaaaaaaa5%"6	kM2W8wwwwwwwwwwwwwwwwwwwww,,,,,,,,,,,,,T
SS