//Training_retrieval.cs

$Train::missionType = "F&R";
exec("game.cs");
exec(Training_AI);

function Retrieval::init(%clientId)
{
   bottomprint(%clientId, "<jc><f1>Training Mission 7 - Find and Retrieve", 5);
   schedule("bottomprint(" @ %clientId @ ", \"<f1><jc>This mission will introduce you to the Find and Retrieve game scenario.\", 5);", 5);
   schedule("bottomprint(" @ %clientId @ ", \"<f1><jc>Bring up The Objectives screen for a gameplay description.\", 5);", 10);
   schedule("messageAll(0, \"~wshell_click.wav\");", 0);
   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
   schedule("messageAll(0, \"~wshell_click.wav\");", 10);
   %player = Client::getOwnedObject(%clientId);
   %player.hasFlag = false;
   $flagDropped = false;
   %player.flag	= "";
   $flagReturnTime = 30;
   %lineNum = 13;
   $capsToWin = 0;
   $captures = 0;
   $ourBase = "-125.978 -91.6377 172.689";
   $flagBase = "247.425 -284.296 211.108";
   
   %group = nameToID("MissionGroup\\Flags");
    
   %numObj = Group::objectCount(%group);
   
   for(%j = 0; %j < %numObj; %j++)
   { 
      %tempObj = Group::getObject(%group, %j);
      
      if(GameBase::getDataName(%tempObj) == flag)
      {
        %tempObj.lineNum = %lineNum++;
        %tempObj.isMounted = false;
        %tempObj.lost = false;
		%tempObj.conveyed = false;
        %tempObj.originalPos = GameBase::getPosition(%tempObj);
        $capsToWin++;
		retrieval::checkMissionObjectives(%clientId, %tempObj);
      }
   }
   schedule("retrieval::setWayPoint(" @ %tempObj @ ", " @ %clientId @ ", " @ true @ ");", 15);
}

function Game::initialMissionDrop(%clientId)
{
   GameBase::setTeam(%clientId, 0);
   Client::setGuiMode(%clientId, $GuiModePlay);
   Game::playerSpawn(%clientId, false);
   Retrieval::init(%clientId);
   Training::setupAI( %clientId );
}

///////////////////////////////////////
//Flag functions
///////////////////////////////////////
function FlagStand::onCollision(%this, %object)
{
   
   %standTeam = GameBase::getTeam(%this);
   %playerTeam = GameBase::getTeam(%object);
   %playerClient = Player::getClient(%object);
   
   
   if(getObjectType(%object) != "Player" || %playerTeam != %standTeam || %this.hasFlag)
      return;

   if(%object.hasFlag)
   {   
      // if we're here, we're carrying a flag, we've hit 
      // our flag stand, it doesn't have a flag.
      
      %flag = %object.flag;
      Item::hide(%object.flag, false);
      GameBase::setPosition(%object.flag, GameBase::getPosition(%this));
	   
      Player::setItemCount(%object, "Flag", 0);
      %this.hasFlag = true;
	  %object.hasFlag = false;
	  %object.flag.isMounted = true;
	  $captures++;
	  
	  if($captures != 3)
	  {  
	     bottomprint(%playerClient, "<jc><f1>You conveyed the " @ %object.flag.objective @ " to your base.", 5);
	  	 Training::moreAI($captures);
	  }
	  messageAll(%playerClient, "~wflagcapture.wav");
	  %object.flag = "";
	  %flag.conveyed = true;
	  
	  retrieval::checkMissionObjectives(%playerClient, %flag);
	  if($captures != 3)
	     retrieval::setWayPoint(%flag, %playerClient, false);
   }
}

function Flag::onCollision(%this, %object)
{
   if(getObjectType(%object) != "Player" || %object.hasFlag || %this.isMounted)
      return;

   %playerClient = Player::getclient(%object);
   %flagTeam = GameBase::getTeam(%this);
   
   Player::setItemCount(%object, "Flag", 1); 
   Player::mountItem(%object, "Flag", $FlagSlot, %flagTeam);
   Item::hide(%this, true);
   %object.flag = %this;
   %object.hasFlag = true;    
   
   if(!$flagDropped)
     bottomprint(%playerClient, "<jc><f1>You took the " @ %this.objective @ " !", 5);
   else
   {  
     bottomprint(%playerClient, "<jc><f1>You recovered the " @ %this.objective @ " !", 5);
	 %this.lost = "false";
   }
   messageall(%playerClient, "~wflag1.wav");
   retrieval::checkMissionObjectives(%playerClient, %this);
   retrieval::setWayPoint(%this, %playerClient, false);
}

function Flag::onDrop(%player, %type)
{
   %playerTeam = GameBase::getTeam(%player);
   %playerClient = Player::getClient(%player);
   %dropClientName = Client::getName(Player::getClient(%player));
   %flag = %player.flag;
   %player.flag = "";
   %player.hasFlag = false;
   %flag.lost = true;
   
   bottomprint(%playerClient, "<jc><f1>You dropped the " @ %flag.objective @ " !", 5);
   GameBase::throw(%flag, %player, 10, false);
   Item::hide(%flag, false);
   Player::setItemCount(%player, "Flag", 0);
   
   schedule("Retrieval::checkFlagReturn(" @ %flag @ ", " @ %playerClient @ ");", $flagReturnTime);
   retrieval::checkMissionObjectives(%playerClient, %flag);
   $flagDropped = true;
   retrieval::setWayPoint(%flag, %playerClient, false);
}

function Retrieval::checkFlagReturn(%this, %clientId)
{
   if(%this.lost)
   {
      bottomprint(%clientId, "<f1><jc>" @ %this.objective @ " was returned to its base.", 5);
      dbecho(2,"moving flag to " @ %this.originalPos);
      GameBase::startFadeOut(%this);
      GameBase::setPosition(%this, %this.originalPos);
	  GameBase::startFadeIn(%this);
      $flagDropped = false;
	  %this.lost = false;
	  retrieval::checkMissionObjectives(%clientId, %this);
	  retrieval::setWayPoint(%this, %clientId, false);
   }
}

function retrieval::setWayPoint(%flag, %cl, %init)
{
   %player = Client::getOwnedObject(%cl);
   %flagPos = GameBase::getPosition(%flag);
   %flagx = getWord(%flagpos, 0);
   %flagy = getWord(%flagpos, 1);
   
   %homebasePos = $ourBase;
   %homebasex = getWord(%homebasePos, 0);
   %homebasey = getWord(%homebasePos, 1);
   
   %flagbasePos = $flagBase;
   %flagbasex = getWord(%flagbasePos, 0);
   %flagbasey = getWord(%flagbasePos, 1);  

   
   if(%flag.lost)
   {
      schedule("bottomprint(" @ %cl @ ", \"<jc><f1>Waypoint set to " @ %flag.objective @ "\", 5);", 5);
	  issueCommand(%cl, %cl, 0, "Waypoint set to " @ %flag.objective, %flagx, %flagy);
   }
   else	if(%flag.conveyed || %init)
   {
      schedule("bottomprint(" @ %cl @ ", \"<jc><f1>Waypoint set to next objective\", 5);", 5);
	  issueCommand(%cl, %cl, 0, "Waypoint set to next objective", %flagbasex, %flagbasey);
   }
   else if(%player.hasFlag)
   {
      schedule("bottomprint(" @ %cl @ ", \"<jc><f1>Waypoint set back to your base\", 5);", 5);
	  issueCommand(%cl, %cl, 0, "Waypoint set to your base", %homebasex, %homebasey);
   }
}

function retrieval::checkMissionObjectives(%cl, %flag)
{
  if(retrieval::MissionObjectives( Client::getTeam(%cl), %cl, %flag ))
   {
      retrieval::MissionComplete( %cl );
   }
}

function retrieval::MissionObjectives( %teamId, %cl, %this )
{
   %enemyTeam = $enemyTeam[%teamId];
   %teamName = getTeamName(%teamId); 
   %player = Client::getOwnedObject(%cl);
   %enemyTeamName = getTeamName(%enemyTeam);
   %capsNeeded = $capstowin - $captures;
  
   if(%capsNeeded == 0)
   {
     return "True";
   }
   
   Training::displayBitmap(0);
   
   Team::setObjective(%teamId, 1, "<f5><jl>GamePlay Description:");
   Team::setObjective(0, 2, "<f1><jl>   In a Find and Retrieve mission, your team must find objectives placed in a");  
   Team::setObjective(0, 3, "<f1><jl>   mission and bring them back to your base. This is similar to CTF, but the");
   Team::setObjective(0, 4, "<f1><jl>   objectives are not owned by any one team in the beginning.  For every");
   Team::setObjective(0, 5, "<f1><jl>   objective you return to your base, your team scores points.");
   Team::setObjective(%teamId, 6, "\n");
   Team::setObjective(%teamId, 7, "<f5><jl>Mission Completion:"); 
   Team::setObjective(%teamId, 8, "<f1>   -Convey all objective flags to your base");
   Team::setObjective(%teamId, 9, "\n");
   Team::setObjective(%teamId, 10, "<f5>Mission Information:");
   Team::setObjective(%teamId, 11, "<f1>   -Mission Name: Find and Retrieve Training"); 
   Team::setObjective(%teamId, 12, "\n");
   Team::setObjective(%teamId, 13, "<f5><jl>Mission Objectives:");

   if(%this.conveyed)
   {
      %status = "<Bflag_atbase.bmp><F1>\n    " @ %this.objective @ " has been conveyed";
      
   }
   else
   {
      
      if(%this.lost)
      {
         %status = "<Bflag_notatbase.bmp><f1>\n    " @ %this.objective @ " was dropped in the field";
      }
      else if($captures == 0 && !%player.hasFlag)
      {
		 %status = "<Bflag_neutral.bmp><f1>\n    " @ %this.objective @ " has not been conveyed";
      }
      else if(%player.hasFlag)
      {
         %status = "<Bflag_atbase.bmp><f1>\n    Convey " @ %this.objective @ " to your base";
      }
	  else
	     %status = "<Bflag_neutral.bmp><f1>\n    " @ %this.objective @ " has not been conveyed";
   }
   
   if(%this.lineNum == 14)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 15)
      Team::setObjective(%teamId, %this.lineNum, %status);
   else if(%this.lineNum == 16)
      Team::setObjective(%teamId, %this.lineNum, %status);

   return "False";
}

function Retrieval::missionComplete(%cl)
{
  
  schedule("Client::setGuiMode(" @ %cl @ ", " @ $GuiModeObjectives @ ");", 8);
  missionSummary();
  remoteEval(2049, TrainingEndMission);
}

function remoteTrainingEndMission()
{
   schedule("EndGame();", 16);
}

function missionSummary()
{
   %time = getSimTime() - $MatchStartTime;
   
   Training::displayBitmap(0);
   
   Team::setObjective(0, 1, "<f5><jl>Mission Completion:");
   Team::setObjective(0, 2, "<f1><t>   -Completed:");
   Team::setObjective(0, 3, "\n");
   Team::setObjective(0, 4, "<f5><jl>Mission Information:");
   Team::setObjective(0, 5, "<f1><t>   -Mission Name: Find and Retrieve Training");
   Team::setObjective(0, 6, "\n");
   
   Team::setObjective(0, 7, "<f5><j1>Mission Summary:");
   
   Team::setObjective(0, 8, "<f1><t>   -Enemy Kills: " @ "<f1>" @ $AIKilled @ " out of " @ $numGuards);
   Team::setObjective(0, 9, "<f1><t>   -Total Mission Time: " @ "<f1>" @ Time::getMinutes(%time) @ " Minutes " @ Time::getSeconds(%time) @ " Seconds");
   Team::setObjective(0, 10, "");
   Team::setObjective(0, 11, "");
   Team::setObjective(0, 12, "");
   Team::setObjective(0, 13, "");
   Team::setObjective(0, 14, "");
   Team::setObjective(0, 15, "");
   Team::setObjective(0, 16, "");
   Team::setObjective(0, 17, "");
   Team::setObjective(0, 18, "");
   Team::setObjective(0, 19, "");
   Team::setObjective(0, 20, "");

}


function Training::MoreAI(%wave)
{
  if(%wave == 1)
    %group = nameToId("MissionGroup\\AIwave1");
  else if(%wave == 2)
    %group = nameToId("MissionGroup\\AIwave2");

  if(%group == -1)
     dbecho(2,"No AI exists...");  
   
  else 
  {  
     %clientId = Client::getFirst(); 
     %AIname = "guard" @ $numGuards + 1;
     createAI(%AIname, %group, larmor, $AI_Names[ floor(getRandom() * 10) ]);
     %aiId = AI::getId( %AIname );
     GameBase::setTeam(%aiId, 1);
     AI::setVar( %AIname,  iq,  70 );
     AI::setVar( %AIname,  attackMode, 0);
     AI::DirectiveTarget(%AIname, %clientId);
  }
  AI::callWithId(%AIname, Player::setItemCount, blaster, 1);
  AI::callWithId(%AIname, Player::mountItem, blaster, 0);
  AI::SetVar(%AIname, triggerPct, 0.04 );
  $numGuards++;
  
}

function remoteScoresOn(%clientId)
{
}

function remoteScoresOff(%clientId)
{
}
oo28ooGGGGGGGGGGGGGGGGGGGmoooooooooooml2ooooooooooooooooooo��������������������������������������������������������zع������������������������������������������������������������������������������������������������������۶��Ⱥ�����������������������������������������������������������������������������������������������������������������������������������������������������������������������``````````````````````````````````````````````````````^���Z�X�UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU��Q����L�J�H�ƻ�����?���������������������������������������������k�������������������������������������������������������������������#�ֽ@Y�� }}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}};>4=-vR&EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE$Cmmmmmmmmmmmmm2:8MG+ooooooooooollmmmmmmmmmmmmmmmmmmmmmmmmmmmoooooooooooooooooooooooooooooooooooooooooooooool2222222222222222222222222222ITTTTTTTTTTTTTTTTTTTTTTTTTTTT:mmmmmmmmmmmmmmmmmmmmmmmmmmmmmooooooooooooooooooooooooooooooossssssssssssssslllllllllllllllooooooooooommmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS7)%%%%%%%%%%%%%%%%%%%%%%%>421h=-------------------8vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv$GCMITTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTToooooooooomsssssssssssssssssssssssooooooooooll:::::::::::::::::::::::::::meeeeeeeeeeeeeeeoooooooooooooooooooseeeeeeeeeeeeeeeoo2hTTTTTTTTTTTTTTTTTTT.p:+I1111111111111llllllllllssssssssssssssseeeeeeeeeeeeeeeeeeeeeoooooooooomeeeeeeeeeeeeeeeeeeeeeeeeeeeeenssssssssssssssssssssssoooooooooomleeeeeeeeeeeeeeeeooooooooooooooooooooooooooooooooooooooooooooooooooooooo_WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWA0E{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{k!;R77777777777777777777777777777777777777777777777S>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>)%888888888888888888888884=G-vK&2"T$.h:::::::::::::::::::Ipppppppppppppnssssssssssssssss+Cm eeeeeeeeeeeeeeeooooooooooooooooooooooooool eeeeeeeeeeeeeeeoooooooooooooooonnnnnnnnnnn11111111111111111111111111111ls eeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooooooooom eeeeeeeeeeeeeeeeeeeeeeeee:"TTTTTTTTTTTTTTTT.h2nnnnnnnnnnnnnnnnnnnI1ppppppppppppppplllllllllllllllllooooooooooooooooommmmmmmmmmmmm         eeeeeeeeeeeeeeeeeeeeeooooooooooooooooosssssssss  Mlnmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeeeooooooooooooooooooooooooosssssssssssssssssssssss eeeeeeeeeeeeeeeeeeeeoooooooooooooooooooooooooooooooo)FFFFFFFFFFFFFFFFFFA077777777777777777777777777777777777777777777777v>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>S%888888888888888888888884"((((((((((((((=Gh+--------------------------------------:1111111111111111.Tl2222222222222222222mM$Isnnnnnnnnnnnnnnnnnnnnnnnnnnn eeeeeeeeeeeeeeeeeeeeoooooooooooooooooooooooooooooooooooooooooooo eeeeeeeeeeeeeeeeeeeeeeeeeeeeoolmistttttttttttttpppppppppppppppppppppppppppn eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooooo eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee.h("C1111111111111111:mT2sllllllllllllliiiiiiiiiiitttttttoooooooooooooooooooooooooooooooppppppppppppppppppp eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooooooooon         eesmmmmmmmmmmmmmrrrrrrrrrrrllllllllllllllliiiiiiiiiiiiiiiiiiiiooooooooooooooooonttttttttt  eeeeeeeeeeeeeeeeeeeeoooooooooooooooooooooooooIId	\bbbbbbbbbbbbbbbbb<66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666NxP/B3333333333333333333333333DO9YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||'@~[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]j}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}____________________________________WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWE;{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{k)ffffffffffffffffffKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK!0FFFFFFFFFFFFFFFFFFFFFFFFFFFFAv77777777777777777777777777777777777777777777777777777777777777777777777777777777%>>>>>>>>>>>>>>>>>>>>>>>S=8+44444444444444444444444444444444444444RGM--------------.h("C1111111111111111:T2psmmmmmmmmmmmmmrrrrrrrrrrrlllllllllllllllin eeeeeeeeeeeeeeeeeeeeoooooooooooooooooooooooooooooooot eeeeeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooooooooooooooooooomarsllllllllllllliiiiiiiiiiiiiiiiiittttttttttttttt eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeoooooooooooooooooon eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee2Idddddddddddddd.h("rrrrrrrrrrrr:1$$$$$$$$$$$$$$$$imaaaaaaaaaaaaaaaaaaaTosllllllllttttttttttttt                  nnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeee                ooooooooooooooooooooooooooooooooooooooooooooooeeiraaaaaaaaaaaasmtpnl                ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooeo                                                    Mggggggggggggggggggggggggggggggggw	\b)ffffffffffffffffffffffffffffffffff0FFFFFFFFFFFFFFFFFFFFFFFFFFFF(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((v%777777777777777777777777777777777777777777=>+S&8A4id2.ICGGGGGGGGGGGGGGs$-h":::::::::::::::::::1naaaaaaaaaaaarrrrrrrrmtooooooooooooooopppppppppppppppppppppppppeeeeeeeeeeel                                     oooooooooooooooooeeeeeeeeeeeee                                           sssssssssssssssnaiiiiiiirmmmmmmmmmmmmmmmmmmteo                                 TTTTTTTTTTTTTTTTeeeeeeee               oooooooooooooooooooooooooolld.c(2I""""""""""""""""""""""""""""""""hp::::::::::::sssssssssssssssnairmmmmmmmmmmmttttttttttttteeeeeeee               ooooooooooooooooooooooooooooooooooooooooT1111111eo                                    nlmsssssssssssssssssssssssssssssssssaiiiiiiitroooooooooooooooooooooooooooooooooooeeeeee                                         ooooooooooooooooooooooeeeeeeeeeeeeeeee                                      3333333333333333333333333DO95555555555555555555555555555555555555555555555555555555555555y,,,,,,,,,,,,,,,,,,,,,,<<<<<<<<<<<<<<<<<<<<<<<<<<<6NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPxB////////////////////////////////////////////////////////////////////////////////////////_;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWE
{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{kM$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$w	\b)ffffffffffffffffffffffffffffffffff0FFFFFFFFFFFFFFFFFFFFFFFFFFFFgv%"u=======================++++++++++++++++++++&!>ASC874n(.Gcd222222222222222pIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIThtmsllllllllllllllllllllaaaaaaaaaaaaaaaaaaaaaaa:iiiiiiiiiiiiirrrrrrreoooo                                          eeeeeeeee            ooooooooooooooooooooooooooooootttttttttttttttsnnnnnnnnnnnnm1lllllllllllllaaaaaaaaaaaiiiiiiiieeeeeeeee                      ooooooooooooooooooooooooooooooooorrrrrrreeeeo                p"t-(d.uccccccccccccT2IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIsnnnnnnnnnnnnnnnnnnnnnnm1hhhhhhhhhhhhhhhhhhhlllllllllllllllloraaaaaaeeeeeeeeeeee                                oiiiiiiiiiiiiiiiieeeeeeeeennnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnst               mmmmmmmmr::::::::::::::::::illlllllllleooooooooooooooooooooooooooooooooa eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeoo)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))y,v$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$w	\bMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0FFFFFFFFFFFFFFFFFFFFFFFFFFFFgfp+=RRRRRRRRRRRRRRRRRRRRRRR%%%%%%%%%%%%%%%%%%%%d7>SC8T-4(""""""""""""""""uc.n2IIIIIIIIIII11111111111111ssssssssssssssssssssssssssssssssssssssrtimmmmmmmmmmmmmmmmma::::::::::::::::::: eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeo                  lllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeissssssssssssnnnnnnnnnnnnnnnnnnnnr atttttttttooooooooooooooooooooolmmmmmmmmmmmmee                ooooooooooooooooooooooooooooooohhhhhhhhhcddddddddddddddd(TTTTTTTTTTTTTTTTGp""""""""""""1u.2:Iaisssssssssssennnnnnnnnnnnnnnnnnnnlro                     hhhhhhhhhhhhhhttttttttttttttttttttttoooooooooooooooooem                                     aaaaaaaaaaaasssssssssssssssnillllllllllllllllllllllllllllllllllllllllloooooooooooooooooemr                                             eo                     tttttttttttttttt�9�Vq���������������������������������������������������������عz�������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������`���^��XZ�UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU��Q����L���HJ?�������*���y�������������������������������������������������������������������#ֽ���� ~Y||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[@j}K]3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDgggggggggggggggggggggggggggO5555555555555555555555P<6NBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBx////////////////////////////////////////////////////////////////////////////////////////////////_;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;WE
)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))&{ccccccccccccccccccccccccccccccccv	$bwA\\\\\\\\\\\\\\\\\MFFFFFFFFFFFFFFFFFF,01Rkkkkkkkkkkkkkkkkkkkkkkkkkkkkf+7=======================%>S-Caaaaaaaaaaaaaaaa(pTdG8n:"u.h2222222222222222222Isssssssssssssssssssssssssssssssssilemmmmmmmmmmm               ooooooooooooooooooooooooootttttttttttttreeeeeeee               ooooooooooooooooooooooooooooooooooooooooooooooonmmmmmmmmmmmmmmsarilllllllllllllllllllllllllllllttttttteo                                                 ooooooooooooooooooooooeeeeee                            p1::::::::::::::::(chd4TTTTTTTTTTTTTTT"ummmmmmmmmmmmmmmmmmm.snrrrrrrrrrrrrrr2laaaaaaaaaaaiiiiiiiiiiiiiioooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeee                        ttttttteoooo                         rmmmmmmmmmmmsnnnnnnnnnnnnnnnnnnnnnnIltaiiiiiiiiiiiiieeeeeeeee            ooooooooooooooooooooooooooooooooooooooooooooooooeeeeeeeee                      ooooooooo!g)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))p																																bvA$$$$$$$$$$$$$$$$$wF\,Myyyyyyyyyyyyyyyyyy40000000000000000000000000000f+7=======================%>S-CGr(:hhhhhhhhhhhhhhhh1cnnnnnnnnnnnnnnnnnnndT""""""""""""""utttttttttttsmmmmmmmmmmmmmmmmmmmmmmmmI............laiiiiiiiiiiiiiiiiiiiiiieeeeo                                                   oooooooooooooeeeeeeeeeeee  tnsrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrma222222222222222222222222222222222222loooooooooooooooooooooooeeeeeeeeeeeeeeeeee iiiiiiiiiiiiiiiiiiiiiiiiieoooooooooooooooooooooooooooooooooopth(1:8888888888888888888888888888888888888888888cdTI"asrnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnim2uuuuuuuuuuuuuuuuuuuu eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooollllllll eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrriastonnnnnnnnnnnllllllllllllm.                                  eeeeeeeeeeeeeeee oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee9D3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333)P56666666666666666666666B<<<<<<<<<<<<<<<<<<<<<<<<NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN////////////////////////////////////////Oxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_&;WE!
{Rg4																																bvA$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$%F\,Myyyyyyyyyyyyyyyyyywwwwwwwwwwwwwwwwwww++++++++++++++++++++++++++++=f071SSSSSSSSSSSSSSSSSSSSSSSC>>>>>>>>>>>>>>h(pI8----------------:rcdi2Tsssssssssssssssnaltmmmmmmmmmmm ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooe."                                                 nimsssssssssssssssroalutttttttttttttttttttttttttttttttteeeeeeee                                     oooooooooooooooooooooeeeeeeee                                               1n((((((((((((((Ihhhhhhhhhhhhhhhhhhhppppppppppppppp2G:c.duTmsiiiiiiiraaaaaaaaaaaalttttttttttteo                                           eeeeeee                     oooooooooooooooooooooooooooooooooooooooo"""""""""""""""snrmmmmmmmmmmmmitaeeeeeee             lllllllllooooooooooooooooooooooooooooooooooooooooooooooooooooooooeo                                                                     )kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk4v	$b%A\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\MFg,2=yw+SSSSSSSSSSSSSSSSSSSSSSSSSSSSf0C7777777777777777777777788888888888888888888"((((((((((((((Ihhhhhhhhhhhhhhhhhhhp1r.:ucG>dtsnnnnnnnnnnnnnnnnnnnnnmmmmmmmmmmmmmmmmmmmmmmiaaaaaaaaaaaaaoooooooooooooooooeeeeee                                  loooooooooooooooooeeeeeeeeeeeeeeee         nrrrrrrrrrrrtsTTTTTTTTTTTTTTTTTTTTTTTmlllllllllllliaaaaaaaaaaaaaaeoooo                                        eeeeeeeeeeeee            ooooooooooooooooooooooooooooooooooooooooooo2p"((((((((((((((((uhhhhhhhhhhhhhhhhhhhIn1...........-:srrrrrrrrrrrrrrrtlTcimmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeeeeeee                      ooooooooooooooooooooooooooaaaaaaaaaaaaaaeeeeo                                        isrnnnnnnnnntladmmmmmmmmmmmmmmmmmmmmmmmmmmmmoooooooooooooeeeeeeeeeeee                                    oooooooooooooooooooooooeeeeeeeee)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|||||||||||||||||||||||||||||||||||||YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY''''''''''''''''''''''''''K[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[j}@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@]99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999933333333333333333333333333333333333333333333333333333333333333333D=66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666PPPPPPPPPPPPPPPPPPPPPPPP5555555555555555555555B/<NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNO&xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx!_;WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW{EEEEEEEEEEEEEEvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv$4%	\bMAgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggk
FFFFFFFFFFFFFFFFFFFS,ywC++++++++++++++++++++++++++++f8077777777777777777777777G(pu"2222222222222222r--------------------hI1T.aisssssssssss nttttttttttttld:mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeooooooooooooooooooooooooo                    eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooarsssssssssssssssniiiiiiiiiiiiiiiiiiiiiictttttttttt                    leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ommmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeee>>>>>>>>>>>>>>>>>>>au(2pppppppppppppp"nTTTTTTTTTTTTTTTThId1c.sssssssssssssssr iiiiiiiiiiiimmmmmmmmmmmtttttttttttttttttttttoooooooooooooooooooooooooooooooooooooooee llllllllloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooonm:saerillllllllllllllllllllllto                                                 oeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                     \==================================Svvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv$4%	)8MAgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggRFb>ywC++++++++++++++++++++++++++++f,2G7-----------------------0Tu(((((((((((((((((((dddddddddddddd"pppppppppppppppppppppppppppppphmcIsnr:1laaaaaaaaaaaioeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                eeeeeeeto                                           rmmmmmmmmmmmsnnnnnnnnnnnnnnne.ltaiiiiiiiiiiiii               ooooooooooooooooooooooooooooooooooooooooeeeeeeeeeeee               ooooooooooooooooooooooooooooooooo"2r(Tduuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuunccccccccccccccpppppppppppppppp:htttttttttttsmmmmmmmmmmmmmmmmmmmmmm.IIIIIIIIIIIIlaiiiiiiieo                                                 ooooooooooooooooooooooeeeeee                            tnsrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrma11111111111111ooooooooooooolllllllllleeeeeeeeeeeeeeee                        iiiiiiieoooo                                          3333333333333333333333333966666666666666666666666666666666666666666FFFFFFFFFFFFFFFFFFFFFFFFDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD/P55555555555555555555555555555555555555555555555555555555555B<N&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&!Oxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx{{{{{{{{{{{{{{{{{{{{{_;\=kW""""""""""""""""""""""""""""""""S4v	$8%A)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))MMMMMMMMMMMMMMMMMgcwREb>fyC+----------------------------,G07td((((((((((((((((((((((((((((((((((((((((((T2uuuuuuuuuuuuuuu::::::::::::::::::::::::::::::::p................asrnnnnnnnnnnnnnnnnnnnnnnnnnnnnnim1hhhhhhhhhhhhheeeeeeeee            oooooooooooooooooooooooooooooooooooooleeeeeeeee                      ooooooooorrrrrrrrrrrrrrriasttttttttttnnnnnnnnnnnllllllllllllmIIIIIIIIIIIIIIIIIIIIIIeeeeo                                                   oooooooooooooeeeeeeeeeeee  c:d(".2uTrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrri1psssssssssssssssnaltmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmoooooooooooooooooooooooeeeeeeeeeeeeeeeeee IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIeoooooooooooooooonimsssssssssssssssrrrrrrrrrralhtttttttttttttttttttttttttttttt eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooo eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeewF\=S4v	$8%A)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))MMMMMMMMMMMMMMMMMggggggggggggggggggufbC>-y,+00000000000000000000000000000000000000000000000G
7n(:.dc"""""""""""""""12TTTTTTTTTTTTTTTTTTTIIIIIIIIIIIIIIhpmsioraaaaaaaaaaaalttttttttttt                                  eeeeeeeeeeeeeeee oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeesnrmmmmmmmmmmmmita ooooooooooooooooooooolllllllllllllllllllllllllllllllllllllllllllllloeeeeeeeeeee                                                 1uuuuuuuuuuuuuuuu(:.dc"""""""""""""""""""""""rIThhhhhhhhhhhhhhhhhhh22222222222222tsnnnnnnnnnnnnnnnommmmmmmmmmmmmmmmmmmmmmiaaaaaaaaaaaaaaaaaaaaaaeeeeeeee                                     olllllllllleeeeeeee                                nrrrrrrrrrrrtspppppppppppppppppppppmlllllllllllliaeo                                           eeeeeee                     oooooooooooooooooooooooooooooooooooooooo��Vq��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������ó��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������`�����ڿX^�������������������������������������������������������������Z�Uݴ�QL���H�?��J޻��*�����z�����������������������������������������������������������������������������������������#���� �����������������������������������~!'|YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYK}[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[j@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]9666666666666666666666666666666666666666663\/////////////////////////////////////////////////////////////////////////////////////////5555555555555555555555555555555555555555555555555555555555555555P<<<<<<<<<<<<<<<<<<<<<<&BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBNDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD${{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{Oxkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk_wFR;gS4v	=,%A)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))MMMMMMMMMMMMMMMMM81Cf-bbbbbbbbbbbbbbbbbb>::::::::::::::::::::y+0
WWWWWWWWWWWWWWWWWWWWWWWWWWWW""""""""""""""""(uhdc.nnnnnnnnnnnnnnnnnnnnnnnGIIIIIIIIIII2Tsrrrrrrrrrrrrrrrtlpppppppppppppppppppimeeeeeee                                ooooooooooooooooooooooooooooooooooooooooooooooaeo                                                            isrnnnnnnntlaaaaaaaaaaaaaammmmmmmmmmmmmoooooooooooooooooeeeeee                                             oooooooooooooooooeeeeeeeeeeeeeeee         c:::::::::::::::("hhhhhhhhhhhhhhhh1ur2d.7pIaisssssssssssssssssssnttttttttttttllllllllllllllTmmmmmmmmmmmmmmeoooo                                        eeeeeeeeeeeee            ooooooooooooooooooooooooooooooarsssssssssssssssniiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiitttttttttttttttteeeeeeeeeeeeel                      oooooooooooooooooooooooooommmmmmmmmmmmmmeeeeo                                $wFccccccccccccccccccccccccccccccccg4	S,vA=============================================================%\)2-M8CCCCCCCCCCCCCCCCCCCCfbbbbbbbbbbbbbbbbbbE>y+++++++++++++++++++++++0ah(1"::::::::::::::::npud..............7777777777777777777777777777777777777777777777Isssssssssssssssrrrrrrrrriiiiiiiiiiiimmmmmmmmmmmttttttttttttttttttttttttttttoooooooooooooeeeeeeeeeeee          lllllllllllllllloooooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeenmTsa rilllllllllllllllllllllltttttttttttttttttttttttttttttttttteooooooooooooooooooooooooo                    eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeoo12ph(cccccccccccccc::::::::::::::::"""""""""""""""udmmmmmmmmmmmmmmmmmmm.snrTGlaaaaaaaaaaaiiiiiiiiii                               eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee otttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeermmmmmmmmmmmsnnnnnnnnnnnnnnn Iltaiiiiiiiiiiiiiiiiiiiiioooooooooooooooooooooooooooooooooooooooee                    oooooooooooooooooooooooooooooooooooooooooooooow!9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999-563/<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<PPPPPPPPPPPPPPPPPPPPPP&{BNDkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkORxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx$
_144444444444444444444444444444444	g,ASSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSv\=F%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%)M8E;Cfbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb>y7+r(pppppppppppppph2cnnnnnnnnnnnnnnnnnnn:"uTdtttttttttttsmeeeeeeeeeeeeeeeI............laio                                                 oeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                     tnsrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmaG0oeeeeeeeeeeeeeeeeeeeeeellllllll                                eeeeeeeio                                                                            tttttttttttttt(2p1hhhhhhhhhhhhhhhTc:"Iuasrneeeeeeeeeeeeeeeeeeeeeeimmmmmmmmmmmmmmmmmmmmmmmmmmmmddddddddddddd               ooooooooooooooooooooooooooooooooooooooooel               ooooooooooooooooooooooooooooooooorrrrrrrrrrrrrrriasttttttttnnnnnnnnnnnllllllllllllm.......eo                                                 ooooooooooooooooooooooeeeeee                            A-----------------$$$$$$$$$$$$$$$$$$$$44444444444444444444444444444444	g,wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwv\=F%SSSSSSSSSSSSSSSSSSSWMf8)C27bbbbbbbbbbbbbbbbbb>GyTTTTTTTTTTTTTT((((((((((((((((I1hprc:iiiiiiiiiiiiiiiiiiiiiiiiiiii+"sssssssssssssssnaltmmmmmmmmmmmmmmmmmmmmmmmmoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeee                        .uuuuuuueoooo                         nimsssssssssssssssrrrrrrrraldttttttttttttttttttttttteeeeeeeee            ooooooooooooooooooooooooooooooooooooooooooooooooeeeeeeeee                      oooooooooh2n(TIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII01pc.:d"msiiiiiiiiiiraaaaaaaaaaaaltttttttttttttttttttttttttttttttteeeeo                                                   oooooooooooooeeeeeeeeeeee  uuuuuuuuuuuuuuusnrmmmmmmmmmmmmitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaloooooooooooooooooooooooeeeeeeeeeeeeeeeeee                                   eoooooooooooooooooooooooooooooooo''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~}YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@j9]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]!555555555555555555555555%<<<<<<<<<<<<<<<<<<<<<<<<<63333333333333333333333333333333////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{PPPPPPPPPPPPPPPPPPPPPPk&BNRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
OxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxA-EEEEEEEEEEEEEEEEEEEEEhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhg4																							,vw=============================================================$\0FSW_Mf8)C7bbbbbbbbbbbbbbbbbb>Gyyyyyyyyyyyyyyyyyyyyyyyyyyyyu(TIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII2r.pdc1:tsnnnnnnnnnnnnnnnnnnnnnnnnmmmmmmmmmmmmmmmmmmmmmmiaaaaaaaaaaaaaaaaaaaa eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooollllllll eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeenrrrrrrrrrrrts"ooooooooooooooomllllllllllllia                                  eeeeeeeeeeeeeeee oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooeeThhhhhhhhhhhhhhhhu(+ddddddddddddddddddddddddddddddddIn2...........1psrrrrrrrrrrrrrrrtl"cim ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooea                                                                         isrnotla:mmmmmmmmmmmmmmmmmmmmmmeeeeeeee                                     oooooooooooooooooooooeeeeeeee                                0%A-Tgggggggggggggggggggggggggggggggg4v	=,$wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwM\FSC;f8>)7byyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy((((((((((((((((duh+Gr11111111111111I2".aisssssssssssssssssnttttttttttttl:pmeo                                           eeeeeee                     ooooooooooooooooooooooooooooooooooooooooarsssssssssssssssniiiiiiiiiiiiiiiiiiiiiicteeeeeee             llllllllloooooooooooooooooooooooooooooooooooooooooooooomeo                                    1111111111111111111ad(hhhhhhhhhhhhhhhhTun"""""""""""""""""""""""""""""""""""""""""I:2c.sssssssssssssssrrrrrrriiiiiiiiiiiimmmmmmmmmmmtttttttttttttoooooooooooooooooeeeeee                                  loooooooooooooooooeeeeeeeeeeeeeeee                       nmpsaaaaaaaaarilllllllllllllllllllllltttttttttttttteoooo                                        eeeeeeeeeeeee            ooooooooooooooooooooooooooooooR99999999999999999999999999999999999999999!555555555555555555555555<AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA66666666666666666666666666666666666666666666666666666663{/PPPPPPPPPPPPPPPPPPPPPPPPPPPkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB&v
NDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEOx0%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWMgggggggggggggggggggggggggggggggg4->=,$wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww	1CFfS\;;;;;;;;;;;;;;;;;;;;;hy8)7+b"d(((((((((((((((((((:TuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuumcIsnrp2laaaaaaaaaaaiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeee                      ooooooooooooooooooooooooootttttttttttttteeeeo                rmmmmmmmmmmmsnnnnnnnnnnnnnnnnnnnnnnn.ltaiiiiiiiiiiiiiiiiiiiiiiiiiiiioooooooooooooeeeeeeeeeeee                                    oooooooooooooooooooooooeeeeeeeeeuhr(":d1111111111111111111ncTTTTTTTTTTTTTTTTGpppppppppppppptttttttttttsm               .IIIIIIIIIIIIlaiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieooooooooooooooooooooooooo                    eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeootnsrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrma2222222222                    leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee oiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeev0%uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuMMMMMMMMMMMMMMMMMMMMg4>>>>>>>>>>>>>>>>>>>>>>>,-w=A$cfffffffffffffffff	CyFS\+_8))))))))))))))))))))))))))))7t:(1"hdddddddddddddddpppppppppppppppppppTTTTTTTTTTTTTTTT.Gbasrn                      im2222222222222222222222222222222222oooooooooooooooooooooooooooooooooooooooee llllllllloooooooooooooooooooooooooooooooooooooooooooooorrrrrrrrrrrrrrriastennnnnnnnnnnllllllllllllmIo                                                 oeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                     1cp:(u.hd"rrrrrrrrrrrrrrrrrrrTi2222222222222222sssssssssssssssnaltmmmmmmmmmmmoeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                eeeeeeeIIIIIIIIIIIIIIIIIIo                                           nimsssssssssssssssreallllllllllllllttttttttttttttttttttttt               ooooooooooooooooooooooooooooooooooooooooeeeeeeeeeeee               ooooooooooooooooooooooooooooooooo�������������������������V���q�������������������������������������������܆��؂����������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������`��������������������������������������������������������ķX^�������������������������������������������������������������Z��ݴU?L�Q�H��*�J���ƻ����0�z������������������������������������������������������������������������������������������������������������ #�������~���������������������������������������������'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''K}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[9@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@!jRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRfffffffffffffffffffffffffffffffffffffffffffffffffffffff]5<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<P63{B///////////////////////////k


















































































E&NDWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOv;x1111111111111111111111111111111111111111111111111114M>g,wwwwwwwwwwwwwwwwwwwwwwwA-%=dy$$$$$$$$$$$$$$$$$	+CFSSSSSSSSSSSSSSSSSSSSSSSSSSSS\____________________________________8G)n(p.:cuuuuuuuuuuuuuuu2h"""""""""""""""""""ITTTTTTTTTTTTTTTTTTTTTTTTTTTTTmsiiiiiiiiraaaaaaaaaaaalttttttttttttttttteo                                                 ooooooooooooooooooooooeeeeee                                             777777777777777snrmmmmmmmmmmmmitaaaaaaaaaaaaaaooooooooooooolllllllllleeeeeeeeeeeeeeee                                        eoooo                         2db(p.:cu1rI""""""""""""""""""""""""""""""""hTtsnnnnnnnnnnnnnnnnnnnnnnmmmmmmmmmmmmmmmmmmmmmmiaaaaaaaaaaaaaeeeeeeeee            oooooooooooooooooooooooooooooooooooooleeeeeeeee                      ooooooooonrrrrrrrrrrrtsssssssssssssssssssssssssssssssssssssssmlllllllllllliaaaaaaaaaaaaaaaaaaaaaaeeeeo                                                   oooooooooooooeeeeeeeeeeee  ,fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffvyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy4M>g0000000000000000000000000000wwwwwwwwwwwwwwwwwwwwwwwA-%=2+++++++++++++++++F	$CpGS\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\8ub)(dddddddddddddd:c.n1IIIIIIIIIIIh"srrrrrrrrrrrrrrrtllllllllllllllllllllllllllllllllllimm