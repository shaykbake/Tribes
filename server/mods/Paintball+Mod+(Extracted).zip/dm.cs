exec("game.cs");
$MaxNumKills = 15;
//Deathmatch mission script -Aug. 25 1998

//calc scores upon fraging
function Game::clientKilled(%playerId, %killerId)
{
   if($teamplay)
   {
      if(%killerId == -1 || %playerId == -1)
      {
         return;
      }
      %kteam = Client::getTeam(%killerId);
      %pteam = Client::getTeam(%playerId);
      
      if(%kteam == %pteam)
         $teamScore[%kteam] = $teamScore[%kteam] - 1;
      else
         $teamScore[%kteam] = $teamScore[%kteam] - 1;
      
      DMTEAM::checkMissionObjectives();
   }
   else
      DM::checkMissionObjectives(%killerId);
   
}

function Game::playerSpawned(%pl, %clientId, %armor)
{	  
   // use this client's skin preference
   Client::setSkin(%clientId, $Client::info[%clientId, 0]);

   //spawn with only blaster and health kit
   Player::setItemCount(%clientId,$ArmorName[%armor],1);
   Player::setItemCount(%clientId,Blaster,1);
   Player::setItemCount(%clientId,RepairKit,1);
	Player::useItem(%pl,Blaster);
   
   if($teamplay)
   {
      DMTEAM::checkMissionObjectives();
      DMTEAM::echoScores();
   }
}

//Player has a total of 10 seconds per life allowed outside designated mission area.
//After a player expends this 10 sec, the player is remotely killed.
//-lesson to be learned= stay in the mission area!
function Player::leaveMissionArea(%player)
{
   %cl = Player::getClient(%player);
	Client::sendMessage(%cl,1,"You have left the mission area.");
	%player.outArea=1;
	alertPlayer(%player, 3);
}

//checking for timeout of dieSeqCount
function Player::checkLMATimeout(%player, %seqCount)
{
   echo("checking player timeout " @ %player @ " " @ %seqCount);
   if(%player.dieSeqCount == %seqCount)
      remoteKill(Player::getClient(%player));
}

//called if player leaves mission area
function Player::enterMissionArea(%player)
{
   %player.outArea="";
   %player.dieSeqCount = 0;
   %player.timeLeft = %player.timeLeft - (getSimTime() - %player.leaveTime);
}
  
function alertPlayer(%player, %count)
{
	if(%player.outArea == 1) {
		%clientId = Player::getClient(%player);
	  	Client::sendMessage(%clientId,1,"~wLeftMissionArea.wav");
		if(%count > 1)
		   schedule("alertPlayer(" @ %player @ ", " @ %count - 1 @ ");",1.5,%clientId);
		else 
	   	schedule("leaveMissionAreaDamage(" @ %clientId @ ");",1,%clientId);
	}
}

function leaveMissionAreaDamage(%client)
{
	%player = Client::getOwnedObject(%client);
	if(%player.outArea == 1) {
		if(!Player::isDead(%player)) {
		  	Player::setDamageFlash(%client,0.1);
			GameBase::setDamageLevel(%player,GameBase::getDamageLevel(%player) + 0.05);
	   	schedule("leaveMissionAreaDamage(" @ %client @ ");",1);
		}
		else { 
			playNextAnim(%client);	
			Client::onKilled(%client, %client);
		}
	}
}

function Game::checkTimeLimit()
{
   // if no timeLimit set or timeLimit set to 0,
   // just reschedule the check for a minute hence
   $timeLimitReached = false;

   if(!$Server::timeLimit)
   {
      schedule("Game::checkTimeLimit();", 60);
      return;
   }
   %curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
   if(%curTimeLeft <= 0)
   {
      $timeLimitReached = true;
      $timeReached = 1;
		DM::missionObjectives();
		Server::nextMission();
	}
   else
   {
      schedule("Game::checkTimeLimit();", 20);
      UpdateClientTimes(%curTimeLeft);
   }
}

function Vote::changeMission()
{
	$timeLimitReached = true;
   $timeReached = 1;
	DM::missionObjectives();
}
  
//---------------------------------------------------------------------------------------
//
//Free for all Deathmatch function definitions
//
//---------------------------------------------------------------------------------------
function DM::checkMissionObjectives(%playerId) 
{
   if(DM::missionObjectives(%playerId)) 
      schedule("nextMission();", 0);
	if($DMScoreLimit > 0)
		if((Player::getClient(%playerId)).scoreKills >= $DMScoreLimit) {
	      $timeLimitReached = true;
   	   $timeReached = 1;
			DM::missionObjectives();
			Server::nextMission();
		}
}

function DM::missionObjectives()
{
	%numClients = getNumClients();
	for(%i = 0 ; %i < %numClients ; %i++) 
		%clientList[%i] = getClientByIndex(%i);
	%doIt = 1;
	while(%doIt == 1) {
		%doIt = "";
		for(%i= 0 ; %i < %numClients; %i++) {
			if((%clientList[%i]).ratio < (%clientList[%i+1]).ratio) {
				%hold = %clientList[%i];
				%clientList[%i] = %clientList[%i+1];
				%clientList[%i+1]	= %hold;
				%doIt=1;
			}
		}
	}
   if(!$Server::timeLimit)
      %str = "<f1>   - No time limit on the game.";
   else if($timeLimitReached)
      %str = "<f1>   - Time limit reached.";
   else
      %str = "<f1>   - Time remaining: " @ floor($Server::timeLimit - (getSimTime() - $missionStartTime) / 60) @ " minutes.";
	for(%l = -1; %l < 1 ; %l++) {		
		%lineNum = 0;
		if($timeReached == "") {
	 	  	Team::setObjective(%l, %lineNum, "<jc><B0,0:deathmatch1.bmp><B0,0:deathmatch2.bmp>");
	  		Team::setObjective(%l, %lineNum++, "<f5>Mission Information:");
			Team::setObjective(%l, %lineNum++, "<f1>   - Mission Name: " @ $missionName); 
	      Team::setObjective(%l, %lineNum++, %str);
	      Team::setObjective(%l, %lineNum++, " ");
	 	  	Team::setObjective(%l, %lineNum++, "<f5>Mission Objectives:");
	 	  	Team::setObjective(%l, %lineNum++, "<f1>   -Kill all other players!");
	 	  	Team::setObjective(%l, %lineNum++, "<f1>   -Stay alive!");
	 	  	Team::setObjective(%l, %lineNum++, "<f1>   -To have the highest Efficiency!");
	 	  	Team::setObjective(%l, %lineNum++, "<f1>   	 -Efficiency is calculated once (Kills + Deaths) is greater than 4");
	 	  	Team::setObjective(%l, %lineNum++, " ");
	 	  	Team::setObjective(%l, %lineNum++, "<f1>Remember to stay within the mission area, which is defined by the extents of your commander screen map."	@ 
	 	                                 " If you go outside of the mission area you will have 3 seconds to get back into the mission area, or you'll start taking damage!");
	 	  	Team::setObjective(%l, %lineNum++, " ");
	 	  	Team::setObjective(%l, %lineNum++, " ");
		  	Team::setObjective(%l, %lineNum++, "<f5>TOP PLAYERS ARE: " );
	 	  	Team::setObjective(%l, %lineNum++, " ");
	 	  	Team::setObjective(%l, %lineNum++, "<f1>Player Name<L30>Kills<L50>Deaths<L70>Efficiency");
	   }
	   else {
			Team::setObjective(%l, %lineNum++, "<f5>Mission Summary:");
	 	  	Team::setObjective(%l, %lineNum++, " " );
	 	  	Team::setObjective(%l, %lineNum++, "<f1>     - The Best Player(s): " );
			%i=0;
			%TopRatio="";
			while(%i < %numClients && %clientList[%i].ratio != 0 && (%TopRatio == "" || (%TopRatio ==  (%clientList[%i+1]).ratio && %TopRatio != 0) )) {
	 	  		Team::setObjective(%l, %lineNum++, "<L14><f5><Bskull_big.bmp>\n" @ Client::getName(%clientList[%i]) @ "<f1> with a ratio of <f5>" @ (%clientList[%i]).ratio @ ".0%");
				%TopRatio = (%clientList[%i]).ratio;
				%i++;
			}
			if(%i == 0) {
	 	  		Team::setObjective(%l, %lineNum++, "<L14><f1>NONE with a ratio greater than 0.0%");
			}
			Team::setObjective(%l, %lineNum++, " ");
	 	  	Team::setObjective(%l, %lineNum++, " ");
			Team::setObjective(%l, %lineNum++, "<f5>TOP PLAYERS ARE: " );
	 	  	Team::setObjective(%l, %lineNum++, " ");
			Team::setObjective(%l, %lineNum++, "<f1>Player Name<L30>Kills<L50>Deaths<L70>Efficiency");
		}
	   //print out top 5 scores
		%index = 0;
		while(%index < %numClients && %clientList[%index].ratio != 0 && (%index < 5 || (%clientList[%index].ratio == %lastRatio && %lastRatio != 0))) {
	  		%client = getClientByIndex(%count);
	  	   Team::setObjective(%l, %lineNum++,"<Bskull_small.bmp>" @ Client::getName(%clientList[%index]) @ " <L31>" @ (%clientList[%index]).scoreKills @ "<L53>" @ (%clientList[%index]).scoreDeaths @ "<L72>" @ (%clientList[%index]).ratio @ ".0%");
			%lastRatio = (%clientList[%index]).ratio;
			%index++;
		}  
		for(%s = %lineNum+1; %s < 30 ;%s++)
			Team::setObjective(%l, %s, " ");
	}
	$timeReached="";
}

//-----------------------------------------------------------------
//
//Team Deathmatch Function definitions
// 
//-----------------------------------------------------------------
function DMTEAM::echoScores()
{   
	 %score = getTeamName(0) @ ": " @ $teamScore[0];
	 
	 for(%i = 1; %i < $numTeams; %i = %i + 1)
        %score = %score @ ", " @ getTeamName(%i) @ ": " @ $teamScore[%i];
     
     MessageAll(0, %score);
     schedule("DMTEAM::echoScores();", 40);
}

function DMTEAM::checkMissionObjectives()
{
   for(%p = 0; %p < $numTeams; %p = %p + 1) 
   {
	  if(DMTEAM::teamMissionObjectives(%p))
	     schedule("Server::nextMission();", 0);
   }
}

function DMTEAM::teamMissionObjectives(%teamId)
{
   %numHighs = 0;
   %teamName = getTeamName(%teamId);
   %teamScore = $teamScore[%teamId];
   %highScore = 0;
  
   for(%t = 0; %t < $numTeams; %t = %t + 1)
   {
	   if(%teamScore > $teamScore[%t]) 
	   {
	      %highScore = %teamScore;
		  %numHighs = %numHighs + 1;
	   }
	   else if($teamScore[%t] > %highScore)
	   {
		  %highScore = $teamScore[%t];
		  %numHighs = %numHighs + 1;
	   }
   }

   if(%highScore == $ScoreLimit)
   {
       for(%r = 0; %r < $numTeams; %r = %r + 1)
       {
		  if(%teamScore == %highScore)
             Team::setObjective(%teamId, 2, "~f0Your team is victorious!");
          else if((%teamScore == %highScore) && (%numHighs > 1)) 
             Team::setObjective(%teamId, 2, "~f0Your team ended up tied for the lead!");
          else
             Team::setObjective(%teamId, 2, "~f0Your team lost!"); 
       }

       Team::setObjective(%teamId, 3, "\n");
       //print out all team scores
	   %lnum = 4;
	   for(%q = 0; %q < $numTeams; %q = %q + 1) 
	   {
       	  Team::setObjective(%teamId, %lnum, getTeamName(%q) @ ": " @ $teamScore[%q]);
		  %lnum = %lnum + 1;
       }
       return "True"; //change mission
   }
  
   Team::setObjective(%teamId, 3, "\n");
   Team::setObjective(%teamId, 4, "Mission Status:"); 													    
   
   
   if((%teamScore == %highScore) && (%highScore == 0))
      Team::setObjective(%teamId, 5, "~f0All teams tied at 0.");
   else if((%teamScore == %highScore) && (%numHighs > 1)) 
      Team::setObjective(%teamId, 5, "~f0Your team is Tied for the lead!");
   else	if((%teamScore == %highScore) && (%numHighs == 1))
      Team::setObjective(%teamId, 5, "~f0Your team is winning.");
   else
      Team::setObjective(%teamId, 5, "~f0Your team is losing.");
   
   
   Team::setObjective(%teamId, 6, "\n");
   Team::setObjective(%teamId, 7, "You must:");
   Team::setObjective(%teamId, 8, "-Kill all players on all other teams.");
   Team::setObjective(%teamId, 9, "-Stay alive!");
   Team::setObjective(%teamId, 10, "\n");
   Team::setObjective(%teamId, 11, "Remember to stay within the mission area, which is defined by the extents of your commander screen map."	@
                                  " If you go outside of the mission area you will have 10 seconds to get back into the mission area, or you will be killed!");
     							  
   Team::setObjective(%teamId, 12, "\n");
       //print out team scores
	   %lnum = 14;
	   Team::setObjective(%teamId, 13, "Team Scores");
	   for(%g = 0; %g < $numTeams; %g = %g + 1) 
	   {
       	  Team::setObjective(%teamId, %lnum, getTeamName(%g) @ ": " @ $teamScore[%g]);
		  %lnum = %lnum + 1;
       }

   return "False";
}												
function getEfficiencyRatio(%clientId)
{
	if((%clientId.scoreKills + %clientId.scoreDeaths) > 4) {
		%ratio = floor((%clientId.scoreKills/(%clientId.scoreKills + %clientId.scoreDeaths))*100);		
		return %ratio;
	}
	return "0";
}

function Game::refreshClientScore(%clientId)
{
	%clientId.ratio = getEfficiencyRatio(%clientId);
   if($teamplay)
      Client::setScore(%clientId, "%n\t%t\t" @ %clientId.score  @ "\t%p\t%l", %clientId.score);
   else
      Client::setScore(%clientId, "%n\t " @ %clientId.scoreKills @ "\t  " @ %clientId.scoreDeaths @ "\t  " @ %clientId.ratio @ ".0%\t%p\t %l", %clientId.ratio);
	DM::missionObjectives();
}


function Mission::init()
{
   setClientScoreHeading("Player Name\t\x78Team\t\xC8Score");

   $numTeams = getNumTeams();
   for(%i = 0; %i < $numTeams; %i++)
      $teamScore[%i] = 0;

   if($teamplay = !($numTeams == 1))
   {
      setTeamScoreHeading("Team Name\t\xC8Score");
      setClientScoreHeading("Player Name\t\x78Team\t\xC8Score");
   }
   else
   {
      $SensorNetworkEnabled = false;
      setTeamScoreHeading("");
      setClientScoreHeading("Player Name\t\x55Kills\t\x75Deaths\t\xA5Efficiency\t\xE3Ping\t\xFFPL");
   }
   $dieSeqCount = 0;
   //setup ai if any
   AI::setupAI();
	DM::missionObjectives();
}
��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������ӆ����������������zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz��������������������������������������������������������������������,,,,,,,,,,,,,,,,,)))))))//////////////////.............................vvvvvvvvvvvvvvvvvvvvvvvvvvvv�������������������������������������������������������������������������������������,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,llllllllllllllllllllllll)))))))))))))))))))))))))))))))))))))))))))hhhhhhhhhhhhhhhhhhhhh.lllllllllllllllllllllllllllllllllllllllllllll)/////////////////,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,lllllllllllllllll,====================<|||||||||||||||||||||||||||||||||]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]O7lllllllllllllllllllllEEEEEEEEEEEEEEEEEEEEEEEEEEEEEv))))))))))))))))))))))`�@h................................................................................................rlllllllllllllllllllllllllllllllllllllllllllllllllll////////////////////////eh"(/))))))))))))))))),,,,,,,,,,,rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeellllllllllllllllllllllllllllllllllll.eeeeeeeeeeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee-IM===================="gN+<TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEEEEEEEEEvvvvvvvvvvvvvvvvvvvvvvhl(/errrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeee.)))))))))))))))))))))))))r,leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee8g000000.p"%,(/heeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeelllllllllllllllllllllllllllllllllllol)eeeeeeeeeeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrreeeeeeeeeeee,$$$$$$$$$$$$$$[wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww\x&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&!222222222222222222222222222222222222222*K}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}666666666666666666666666666666666666666666~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~C''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''GO|]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]kI�HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHv-M====================N+<.TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTEg8777777777777777777777777777770p""""""""""""""""nl/%eroooooooooooooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeee)(((((((((((((((((((((((((lrnhhhhhhhhhhheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeoooooooooooooooooooooeeeeeeeh.,111111gggggggggggggggggggggg0p"/%)elrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrronnnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooo(lllllllllllreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeennnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeIw$MMMMMMMMMMMMMMMMMMMMMkkkkkkkkkkkkkk+v-SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSN=h<T,@@@@@@@@@@@@@@@@@@@@@@g.01""""""""""""""""""""""E%peo(///////////////////////////////////nlllllllllllreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeennnnnnnnnnnooooooooo r)eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee llllllllllllllllllllleeeeeeeeeeeeeehgffffffffffffffff,"d.000000(11111111111111111111111111111%%%%%%%%%%%aernnnnnnnnn                    looooooooooo)peeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee            ///////////ar nleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee:bLFFFFFFFFFFFFFFFFFFFFFFFF\[PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP2xq!;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;B4
OC]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]|88888888888888888888888888888888Iw$MMMMMMMMMMMMMMMMMMMMMkkkkkkkkkkkkkk+v-SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSNNNNNNNNNNNNNNNNNNNNNNNNm@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@<<<<<<<<<<<<<<<<<<<<<<T.gfh================="d,,,,,,/(10a%))))))))nnnnnnnnnnn orrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     llllllleaaaaaantoplllllllllllllllllllllllllllllllllllllllllllllllllll           r eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeennnnnnnnnnnnnnnn													.m ////////////gf%E"d1h,((((((oaltttttttttrp0eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee           eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeonnnnnnliraaaaaaaaaaaaaaaa           tttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     )))))))gAAAAAAAAAAAAAAAAAAAAAAAAAAAyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyybbbbbbbbbbbbbbbbbbbbbbbbbbbbb5:IL$>lSwMMMMMMMMMMMMMMMMMMMMM77777777777777+v=kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk	N-.<<<<<<<<<<<<<<<<<<<<<<////////////////////////////me,,,,,,,,,,,,f%oET"p1hddddddrnnnnnnnnnnni)(aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           t eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee srllllllllllllllllo0nnnnnnnnntieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee aeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee.	/ggggggggggggggggu,,,,,,,,,,,,,fmmmmmmm))))))))))))%%%%%%%%%%%%%%%%%r"ps1hhhhhh0dltoooooooooooooooo annnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     iiiiiiies((((((((((((((((traliooooooooooooooooooooooooooooooooooooooooo           n eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee+����������������������������������������������������������������������������������������������������������������������������^���Z�XW���������ݰJر�������?��̸��й����������ͽ��R�#���Q��{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{���UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU Y99999999999999999999999999999999999VVVVVVVVVVVVVVVVVVVVVVVVVVD�__________________________________________________________j����������������������������������������������������������������������������������������ӆ������������������������������������������������������������z��������������������������������������������������������������****************************************`�&6666666666666666666666666666666666666666666K}''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''~��������������������������������������������������������������������������������������������������������������������������������������������3\FP2[qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx!)ccccccccccccccccccccccccccccccccccccccccccccccccccGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGB4@OC]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]




























































|8by555555555555555555IIIIIIIIIIIIIIIIIIIIIIIIIIIII$:SLM>77777777777777777777777777777777wAAAAAAAAAAAAAAAAAAAAA============================vtttttttttt.<k////////////////////NNNNNNNNNNNNNNNN	,gfuE------------- 0mmmmmmmmmmmm%("p1shhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhaaaaaaaaaaairrrrrrrrrnleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeestaaaaaaaaaaaaaaaidnnnnnnnnnnnnnnnnnnnnnnnnnn orrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     llllllli////////////////),cf	.g0uuuuuuuuuuuuuuuuuuuuuuuuespma%(h"ttttttnnnnnnnnnnod1lllllllllllllllllllllllllllllllllllllllllllllllllll           r eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ianssssssotllllllllllllllllllrTeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee           eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeepppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppb+555555555555555555555555555Iy$$$$$$$$$$$$$$$$$$SSSSSSSSSSSSSSSSSSSSSSSSSSSSSM::::::::::::::::::::::::::::::::::LA>=wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<vooooooooooooooooooooooooooooooook,NEf).c0												g/uuuuuuuihhhhhhhhhhhhhnm%d(aaaaaalsrtttttttttttttttt                                       eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     T-"""""""eonliiiiiiraaaaaaaaaaas1ttttttttttttttttttttttttttttttttttttttttt                     eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeer,fp................0))))))))))))c/	hg odulllllllllllllmmmmmmmmmmmmmmmmmmmmmm%nnnnnnnnnnnnnnnni1(aaaaaaaaaaaaaaaaaaseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerllllllllllloooooo"nnnnnnnnnniiiiiiiiiiiiiiii taaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssR\DP32Fq;[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[Hxdddddddddddddddddddddddddddddd!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!B7@OCb]45
|I+$$$$$$$$$$$$$$$$$$$$$$$$$$$SyMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM88888888888888888888888888888A:=LLLLLLLLLLLLLLL><wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww"TvkNfp................0))))))))))))c/	hg,errrrrrrrrrrrrrrrrrrrrrEEEEEEEEEEEEEEEEEEEEEEE1mu%lllllllllllllllotnsiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii           a eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ((((((((((((((((((((rrrrrrtlsoooooooooaneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeet"pddddddddddddddddf).c0												g///////(h,----------------------11111111111muuuuuusrallllllllllllllll iooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     nnnnnnneeeeeeeeeeeeeeeeeeeestttttta%irnlllllllllllllllllllllllllllllllllllllllll           o eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee(5IIIIIIIIIIIIIIIII$bS+MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMyAAAAAAAAAAAAAAAAAA===========================================:<LLLLLLLLLLLLLLLLLLLL>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>wTTTTTTTTTTTTTTTTTTTTTappppppppppppppppppppppppppppppppppppppppppppppppppvk)dcf	.g0""""""""""""                       /sh,m-NNNNNNNNNNNNNNNitn%111111111oreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeasiiiiiiiiiiiiiiiinnnnnnnnnnotttttttttttttttt luuuuuuuuuuuuuuuuuuuueeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     rrrrrrrnnnnnnnnnnnnnnnn)(cp	dgf".............0eammmmmmmmmmmmi/h%,ssssssooooooooooollllllllllrttttttttttttttttttttttttttttttttttttttttt           uE eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee nioaaaaaalsrrrrrrrrrrrrrrrrrrr1111111111eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj{{{{{{{{{{{{{{{{{{{{{{{{{{9K********************************************************************************************************************6666666666666666666666666666666666666666666&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&'''''''''''''''''''''''''''''''''''''''''''''}}}}}}}}}}}}}}}}}}}}}}}}~���������������������������������������������������������������������������������������������������\\\\\\\\\\\\\\\\\\\PR2Dq3;FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[m]x!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!7@OICB$4
SSSSSSSSSSSSSSSSSMbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb|+AAAAAAAAAAAAAAAAAAAAAAAAAAA=yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::LT>5wl)---------------------ccccccccccccccv	(gp"dddddddddddddffffffffffffffff.......n%0oooooooooooo/uhiiiiiira1,ssssssssssssssss tttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                    elornnnnnnEkitaaaaaaaaaasssssssssssssssssssssssssssssssssssssssss                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeNmc)	(gp"dddddddddddddffffffffffffffff.% luuuuuuuuuuuur1/0hooooootnnnnnnnnnniiiiiiiiiiiiiiiiiiiaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,rtlllllllllllllllooooooooooonnnnnnnnnnnnnnnn siiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     aaaaaaa.$SSSSSSSSSSSSSSSSSSSSSSMI88888888888888888Ab=+++++++++++++++++++++++++++++++++++++++++<yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyT:5L->>>>>>>>>>mEw))))))))))))))))))))))))))))))))))(cp	dgf"Nvvvvvvvvvvvvve,,,,,,,,,,,,,,,,%utttttttttttt1r/0000000000000000lsoannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn           i eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee rtttttttttttttttttttttttttshalllllllllioeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee neeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeees)(.pmdcf	kg,"""""""rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr%/uttttttaaaaaaaaaaih1111111111111111 nlllllllllllllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     oooooooesssssssssssarrrrrritnnnnnnnnnno00000000000000000000000000000000000000000           l eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeE\\\\\\\\\\\\\\\\\\\\\\\PPPPPPPPPPPPPPPPPPPPPPPP2222222222222222222qR;DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD3GFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF][[[[[[[[[[[[CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCx!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!7@SOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOMB48





















AI===============================b<++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++yTTTTTTTTTTTTTTTTTT55555555555555555555555555555-:$Li(N>pwwwwwwwwwwwwwwwwwwwwwd.fmkkkkkkkkkkkkkkc,	)g s/"aaaaaaaaaaaaaaaaaaaaaaaaaaaah%%%%%%%%%%%%%%%%nrotttttttttlllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee 0ueeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeianssssssooooooooooolrrrrrrrrrrrrrrrr 1tttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                    opddddddddddddf(v.,m)c/	eihgn"""""""""""""0000000000000000aaaaaals1%%%%%%%%%%%%%%%%%%%%rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr           t eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee onliiiiiiuaaaaaaaaaasssssssssttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee reeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeehM|EAS====================================I<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb+TTTTTTTTTTTTTTTTTTTTTTTTTTT5y------------------$$$$$$$$$$$$$$$$$$$$$$$$$$$$$N:ukL>wddddddddddddf(vvvvvvvvvvvvvvvvvvvvv.,m)c/	pppppppo0"l1111111111111ggggggggggggggggnnnnnnnnnnnnnnnitaaaaaaaaaaaaaaaa rsssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                     e%llllllllllooooootnriiiiiiiiiiiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           s eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeetuuuuuuuuuuuuh(d.fmmmmmmmmmmmmmmc,	) %/p0000000000"1lllllllllllllggggggrooooooooooonnnnnnnnnsieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee aeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeellllllllllrtttttttttttttttttttttttttttttttsoooooooooooooooo annnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     iiiiiiikkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk�������������������������������������������������������������������������������������������������������������������������������������UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU��__________________________________________________________��V�����������������������������������������������������������������������������������z�ӆ����ۀ�����������������������������������������������������Á������������������������������������������������������������������������������������`��YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY{jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjK*9999999999999999999999999999999999999999999999999999999999999999999999999999999999999966666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666'&\}~PH��22222222222222222222222qqqqqqqqqqqqqqqqqqqqqqqq;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;RGGGGGGGGGGGGGGGGGGGGGGGGGGGGDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD3]FC%O[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[x888888888888888888888888888888888888888888888888888888888888888887|!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!BA4@=EEEEEEEEEEEEEEES<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIITb5+---------------------------$yNNNNNNNNNNNNNNNNNNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMv:(L>.hmdcf														wu,el")r/ppppppppppppp000000000000000staaaaaaaaaaaaaaaa1iooooooooooooooooooooooooooooooooooooooooo           n eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee           rsllllllaaaaaaaaaaitttttttttngeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeea(.%mmmmmmmmmmmmch	duf""""""""""""""""""""""""""""""""""""""""""""""""",s)////////////////prrrrrrilnnnnnnnnnnnnnnnnnnnnnnnnn otttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     g0000000easiiiiiiiiiiiiiiiinrol11111111111111111111111111111111111111111111111111           t eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeA=kkkkkkkkkkkkkkk
<EEEEEEEEEEEEEEEEEEEESSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSTI55555555555555555-b$+NNNNNNNNNNNNNNNNNNNNNNNNNNNMyvvvvvvvvvvvvvvvvvvn..........................................m:Lc%												uh"d(f aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa>i,)g/ssssssooooooooooo1prrrrrrrrrtleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee          eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeenioaaaaaa0stttttttttttttttttttttttttt          rrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     lllllll0000000000000m.c%												uh"d(ffffffffffffffffeng,o1)w/iiiiiitaaaaaaaaaaslllllllllllllllllllllllllllllllllllllllllllllllllll           r eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee potnnnnnnnnnnnnnnnilaaaaaaaaarseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee           eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee2Pq\;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;R]DC3OFf|[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[488888888888888888888888888888888888888888888888888888888888888888=7xxxxxxxxxxxxxxx!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!<kkkkkkkkkkkkkkkkkkkk
BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBETS5555555555555555555555-I$$$$$$$$$$$$$$$$$NbM+vvvvvvvvvvvvvvvvvvvvvvvvvvvAyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy.............................:%mmmmmmmmmmmmch	du0"""""""p((((((((((((((((gt,1o)wLLLLLLlnriiiiiiiiiiiiiiii           aaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     ssssssseotlllllllllllllllr///////////nsiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii           a eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeer.%ffffffffffffffffffffffffhmdc0	pu o,"l(((((((((((((((()gttttttttttttttttttttttttts/111111111aneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerllllllllllloooooostaaaaaaaaaaaaaaaaaaaaaaaaa i>>>>>>>>>>>>>>>>>>>>eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     nnnnnnn,,,,,,,,,,,,,,,<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<=============================================================kT@5E-S$$$$$$$$$$$$$$$$$$$$$$NIMMMMMMMMMMMMMMMMMvbA+++++++++++++++++++++++++++++++++++++++++++++++s%wyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhfddddddddddddd0mpc.	er)uuuuuuuuuuu"(////////////////llllllaoitnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn           >:g eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee sssssssssssarrrrrrilnooooooooo1teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee          eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiih,d%0fppppppppppppp.m)cccccccs/	au"L((((((((((((((((nr1111111111111111llllllllllllllll          ooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     ttttttteianssssssggggggggggggggggggggrtlllllllllllllllllllllllllllllllllllllllll           o eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeewwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{***********************************************************************************************Y6666666666666666666666666666666666666666666Kj''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''9HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH2&}qG~;PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\���������������������������������������������������������������������������]]]]]]]]]]]]]]]]]]]CROD|3/7F[
488888888888888888888888888888888<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<x!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!T=5k-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@$ENSMMMMMMMMMMMMMMMMMMMMMMvIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbbbbbbbbbbbbbbb+g>>>>>>>>>>>>>>>>>>>>>>>>>>>yyyyyyyyyyyyyyyyyyh,d%0fppppppppppppp.m)cccccccccccc iLLLLLLLLLLLLLLLLLLLLLLLLLLLLLun1"	(aaaaaaaaaaaaaaastttttttttttttttttttoreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeennnnnnnnnniiiiiitaossssssssssssssss lllllllllllllllllllllllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     rrrrrrrtg,/%hfddddddddddddd0mpc.eeeeeeeeeeeeeeee))))))))))))::::::::::u1n"						oilarsssssssssssssssssssssssssssssssssssssssss                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee nnnnnnnnnnottttttl(riiiiiiiiiiiiiiiiiiiaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeewT<55555555555555-=$kNBMEvSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII>bl,L+%%%%%%%%%%%%%%%%%%%%%%%%%%%yf/////////////hmdc0gpppppppnu.o))))))))))))"::::::::::::::::::::::::::::::::rttttttttttt(1111111111111111 siiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     aaaaaaaelornnnnnnnnnnnnnnnnnnnnnnnnnsta																																									           i eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee%ffffffffffffffffffffffffffff,m/chgdu0 l"pr.)((((((((((((oooooosnaaaaaaaaaaaaaaaaaaiteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee 																													eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeersllllllaoinnnnnnnnnnnnnnnn 11111111111111111111111111111eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     tttttttL;qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq2222222222222222222222222222PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP\]]]]]]]]]]]]]]]]]]]]]]]CCCCCCCCCCCCCCCCCCCCCCCCOOOOOOOOOOOOOOOOOOO|R7D""""""""""""""""""""""""""""""""""3F@
488888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888[TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTx5w-<$$$$$$$$$$$$$$N=MkvB!AEEEEEEEEEEEEEEEEEEEEESSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS>IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIaf:bbbbbbbbbbbbb+++++++++++++++++++++++++++mmmmmmmmmmmmmmmmc,g/uh%deeeeeeeeeee(0sp.	)rrrrrril111111111111otnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn                     eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee asiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiyrtlllllllllllllllllloeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee neeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"""""""""""""fmmmmmmmmmmmmmmmmc,g/uh%d(((((((a	pi1.0)ssssssttttttttttttttttttttrrrrrrrrrrrrrrrr nlllllllllllllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     oooooooeeeeeeeeeeeeitaaaaaaaaaaaaaaasnnnnnnnnnnnorrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr           l eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeedT5L-------------------------------------------------------------$wN<MMMMMMMMMMMMMMv=AkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkE>SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS:IIIIIIIIII"""""""""""""""""""""""""""""""""""""""""""""fb++++++++++++++++++++++++++++,m/chggggggggggggggggggggggggggggggggggggggggggggu            %(	tp1i.000000naosssssssssllllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee reeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeitnnnnnnnnnnnnnnno)laaaaaaaaaaaaaaaa rsssssssssssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                     offffffffffffffffd,"/////////////hmyccccccccccccgeipun%(.	ttttttllllllllllr)11111111111aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           s eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee onliiiiiirtttttttttttttttttttttttttttts0eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee aeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee������?��������������������������������������������������������������������������������������������������������������������^���Z�XW�������˺�ݰJر���������̸��й����������ͽ��������������������������������������#�����Q������                                                                           �������������������������������������������������������������������������������������������������UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU��_���������������������������������������V��������������������������������������������������������������������������������������������������������������������������������������Í���z�Ӽ����ۀ������������������������������������������������������`����������������������������������������������������������������������������������������������������������������������{KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK*******************************************************************Y66666666666666666666666666666666666666666666666666666666666666666666666666666666666666j'GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG9H;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;&&&&&&&&&&&&&&&&&&&&&&&&&&&&}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~2]PC\OOOOOOOOOOOOOOOOOOOOOOO||||||||||||||||||||||||7777777777777777777qRppppppppppppppppppppppppppppppppD3FB@
458-[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[$LNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNMwv<AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA===============k>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>xxxxxxxxxxxxxxxxxxxxE:STTTTTTTTTTTTTTTTTTTTTTrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrI,,,,,,,,,,,,,,,,,b/dh"y++++++++++++++++++++++++mfccccccco.glu%)(nnnnnnnnnnnnnnnnistttttttttttttttt aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     0							erllllllllllloooooosnai1ttttttttttttttttttttttttttttttttttttttttt                     eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeees,/phhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhdddddddddddd"fffffffffffff.m r)cccccccccccgu0%llllllao1(nnnnnnnnnnnnnnnnnnieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeesssssssssssarrrrrr	lllllllllloooooooooooooooo tnnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     iiiiiii)-$$$$$$$$$$$$$$$$$$$$$$$$$$$$$N5MLvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvAwwwwwwwwwwwwwwwwwwwww<<<<<<<<<<<<<<<<<<<<<<<<<<<<>====================k:!TEEEEEEEEEEEEEEEEEES	yyyyyyyyyyyyyyyyyyyyyyIIIIIIIIIIIIIIIII/phhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhbdddddddddddd"fffffffffffff.m,es0ga1uc%%%%%%%%%%%%%%%%%%%%%%%%%rtliooooooooooooooooooooooooooooooooooooooooo           n eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee (aaaaaaaaaasssssstttttttttttirrrrrrrrrnleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee oeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeet	p))))))))))))))))/dh"++++++++++++++++++++++++mfffffff(.,0000000000g1auccccccisnnnnnnnnnnnnnnnnnnnnnnnnnn orrrrrrrrrrrrrrrrrrrreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     llllllleaaaaaaaaaaittttttn%oslllllllllllllllllllllllllllllllllllllllllllllllllll           r eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy;]�C2OP|\77777777777777777777777qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq(8RD333333333333333333333333333333333333333B@
$4FN[MMMMMMMMMMMMMMMMMMMMMMMMMMMMMv5ALLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLw><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<:=Tkkkkkkkkkkkkkkkkkk!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-EnpppppppppppppppppppppppppppSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSId)"/////////////hm+++++++++++++++++												 agfi.,u000000000000000otl%111111111rseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee           eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeenioaaaaaallllllllllrtttttttttttttttt           cccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     ssssssslllllllllllllllld("ppppppppppppp)m/	hgbenuuuuuuuuuuuuof.%,iiiiiiraaaaaaaaaaaaaaaaaaaasttttttttttttttttttttttttttttttttttttttttt           c0 eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee lornnnnnnnnnnnnnnnnisaaaaaaaaa1111111111eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeuNMyv$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA555555555555555L>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>w:<TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT=-kkkkkkkkkkkkkkkkkkkkkkkkkkkxxxxxxxxxxxd+E"SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS(mp	)g////////////////hhhhhhhl%bIrrrrrrrrrrrrfc.oooooosn1,iiiiiiiiiiiiiiii taaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                    eeeeeeeeeeersllllll0otnnnnnnnnnniiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii           a eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0u"ddddddddddddd(mp	)g////////////////h%           ccccccccccccs1fffffffffffffffff.rrrrrrtlllllllllloooooooooaneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,stttttttttttttttttttttttttrallllllllllllllll iooooooooooooooooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     nnnnnnn+KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{*********************************************************GY666666666666666666666666666666666666666666666666666666666666666666666666666j'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''9HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH~&]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]C;O�}|27Pq\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\888888888888888888888888h4444444444444444444RD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!B@M
3vFAyyyyyyyyyyyyyyyyyyyyy$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$>55555555555555555555L:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::Twwwwwwwwwwwwwwwwww<----------------------------------------=Nkkkkkkkkkkubx[dES("ppppppppppppp)m/	0ge,,,,,,,,,,,,,,,,%ctttttttttttt1sfffffffffffffffffffffffffffffffffffffffffffaaaaaaaaaaairnlllllllllllllllllllllllllllllllllllllllll           o eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee staaaaaaaaaaaaaaai.nnnnnnnnnnnnnnnnnnnoreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeid(hpu)"/////////////0m,							ssssssssssssgaaaaaaaaaaaaaaaa%fcttttttnnnnnnnnnno.1111111111111111 lllllllllllllllllllllllllllllleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                     rrrrrrreianssssssotllllllllllrIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeevA+++++++++++++++++++++MMMMMMMMMMMMMMMy>$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$:5TLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL-wwwwwwwwwwwwwwwwwwwwwwwwwww<NNNNNNNNNNNNNNb=o(((((((((((((((((kpppppppppppppppppppppppppppppppE)h/u0",,,,,,,,,,,,,dm if	ngggggggggggggggg.%aaaaaalsrtttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee ISceeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeonliiiiiiraaaaaaaaaaassssssssssssssss 1tttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                    rp))))))))))))/(0h,ud"fffffffffffffeo.ml	gggggggggggggggggggggggggggggggggggggnnnnnnnnnnnnnnnni1%aa