focusServer
setcat missionName $1 ".mis"
loadMission $missionName
focusClient
                                                 5�nEm�w�a