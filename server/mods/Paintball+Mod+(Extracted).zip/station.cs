//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

// List of all items available to buy from inventory station
$InvList[Blaster] = 0;
$InvList[Chaingun] = 0;
$InvList[Disclauncher] = 0;
$InvList[GrenadeLauncher] = 0;
$InvList[Mortar] = 0;
$InvList[PlasmaGun] = 0;
$InvList[LaserRifle] = 0;
$InvList[EnergyRifle] = 0;
$InvList[TargetingLaser] = 0;
$InvList[MineAmmo] = 0;
$InvList[Grenade] = 1;
$InvList[Beacon] = 0;
$InvList[AngelClip] = 0;
$InvList[AutoCockerClip] = 0;
$InvList[SypderClip] = 0;
$InvList[TipmannSClip] = 0;
$InvList[DragunClip] = 0;
$InvList[DeltaClip] = 0;

$InvList[BulletAmmo] = 0;
$InvList[PlasmaAmmo] = 0;
$InvList[DiscAmmo] = 0;
$InvList[GrenadeAmmo] = 0;
$InvList[MortarAmmo] = 0;
  
$InvList[EnergyPack] = 0;
$InvList[RepairPack] = 0;
$InvList[ShieldPack] = 0;
$InvList[SensorJammerPack] = 0;
$InvList[MotionSensorPack] = 0;
$InvList[PulseSensorPack] = 0;
$InvList[DeployableSensorJammerPack] = 0;
$InvList[CameraPack] = 0;
$InvList[TurretPack] = 0;
$InvList[AmmoPack] = 0;
$InvList[RepairKit] = 0;
$InvList[DeployableInvPack] = 0;
$InvList[DeployableAmmoPack] = 0;

//----------------------------------------------------------------------------

// List of all items available to buy from Remote Station
$RemoteInvList[Blaster] = 1;
$RemoteInvList[Chaingun] = 1;
$RemoteInvList[Disclauncher] = 1;
$RemoteInvList[GrenadeLauncher] = 1;
$RemoteInvList[Mortar] = 1;
$RemoteInvList[PlasmaGun] = 1;
$RemoteInvList[LaserRifle] = 1;
$RemoteInvList[EnergyRifle] = 1;
$RemoteInvList[TargetingLaser] = 1;
$RemoteInvList[MineAmmo] = 1;
$RemoteInvList[Grenade] = 1;
$RemoteInvList[Beacon] = 1;

$RemoteInvList[BulletAmmo] = 1;
$RemoteInvList[PlasmaAmmo] = 1;
$RemoteInvList[DiscAmmo] = 1;
$RemoteInvList[GrenadeAmmo] = 1;
$RemoteInvList[MortarAmmo] = 1;
  
$RemoteInvList[EnergyPack] = 1;
$RemoteInvList[RepairPack] = 1;
$RemoteInvList[ShieldPack] = 0;
$RemoteInvList[SensorJammerPack] = 1;
$RemoteInvList[MotionSensorPack] = 1;
$RemoteInvList[PulseSensorPack] = 1;
$RemoteInvList[DeployableSensorJammerPack] = 1;
$RemoteInvList[CameraPack] = 1;
$RemoteInvList[TurretPack] = 1;
$RemoteInvList[AmmoPack] = 1;
$RemoteInvList[RepairKit] = 1;

//----------------------------------------------------------------------------

// List of all items available to buy from Vehicle station
$VehicleInvList[ScoutVehicle] = 1;
$VehicleInvList[LAPCVehicle] = 1;
$VehicleInvList[HAPCVehicle] = 1;

//----------------------------------------------------------------------------

$DataBlockName[ScoutVehicle] = Scout;
$DataBlockName[LAPCVehicle] = LAPC;
$DataBlockName[HAPCVehicle] = HAPC;

$VehicleToItem[Scout] = ScoutVehicle;
$VehicleToItem[LAPC] = LAPCVehicle;
$VehicleToItem[HAPC] = HAPCVehicle;


//----------------------------------------------------------------------------
// Default station animations

function Station::onActivate(%this)
{
	//echo("Activate " @ %this);
	%obj = Station::getTarget(%this);
	if (%obj != -1) {
		GameBase::playSequence(%this,1,"activate");
		GameBase::setSequenceDirection(%this,1,1);
		%this.lastPlayer = %obj;
	}
	else 
		GameBase::setActive(%this,false);
}

function Station::onDeactivate(%this)
{
	//echo("Dectivate " @ %this);
	GameBase::stopSequence(%this,2);
	GameBase::setSequenceDirection(%this,1,0);
}

function Station::onEndSequence(%this,%thread)
{
	//echo("End sequence " @ %this);
 	if (%thread == 1 && GameBase::isActive(%this)) {
		GameBase::playSequence(%this,2,"use");
		return true;
	}
	%client = %this.target;
	if(%client == "") {
		%player = Station::getTarget(%this);
		%client = Player::getClient(%player);
	}
	if(%client != "") {
		if(Client::getGuiMode(%client) != 1)
			Client::setGuiMode(%client,1);
		
		%team = Client::getTeam(%client);
		if($TeamEnergy[%team] != "Infinite") {
			if(%this.clTeamEnergy != %client.TeamEnergy) {
				if(%client.teamEnergy < 0)
					Client::sendMessage(%client,0,"Your total mission purchases have come to " @ (%client.teamEnergy * -1) @ ".");
				else
					Client::sendMessage(%client,0,"You have increased the Team Energy by " @ %client.teamEnergy @ ".");
			}
			if((%client.teamEnergy -%client.EnergyWarning < $TeammateSpending) && ($TeammateSpending != 0) && !$TeamEnergyCheat) {
				TeamMessages(0, %team, "Teammate " @ Client::getName(%client) @ " has spent " @ (%client.teamEnergy *-1) @ " of the TeamEnergy"); 
				%client.EnergyWarning = %client.teamEnergy;
			}
			if($TeamEnergy[%team] < $WarnEnergyLow)  
				TeamMessages(0, %team, "TeamEnergy Low: " @ $TeamEnergy[%team]); 
		}
	}
	if(%this.target != "") {
		(Client::getOwnedObject(%this.target)).Station = "";
		%this.target = "";
	}
	if(GameBase::getDataName(%this) == VehicleStation && %this.vehiclePad.busy < getSimTime())
		VehiclePad::checkSeq(%this.vehiclePad, %this);
	%this.clTeamEnergy = "";
	return false;
}

function Station::onPower(%this,%power,%generator)
{
	if (%power) {
		GameBase::playSequence(%this,0,"power");
		GameBase::playSequence(%this,1);
	}
	else {
		GameBase::stopSequence(%this,0);
		GameBase::pauseSequence(%this,1);
		GameBase::pauseSequence(%this,2);
		Station::checkTarget(%this);
	}
}

function Station::onEnabled(%this)
{
	if (GameBase::isPowered(%this)) {		
		GameBase::playSequence(%this,0,"power");
		GameBase::playSequence(%this,1);
	}
}

function Station::checkTarget(%this)
{
	if(%this.target) {
		Client::setGuiMode(%this.target,1);
		GameBase::setActive(%this,false);
	}
}

function Station::onDisabled(%this)
{
	Station::weaponCheck(%this);
	GameBase::stopSequence(%this,0);
	GameBase::setSequenceDirection(%this,1,0);
	GameBase::pauseSequence(%this,1);
	GameBase::stopSequence(%this,2);
	Station::checkTarget(%this);
}

function Station::onDestroyed(%this)
{
	Station::weaponCheck(%this);
	StaticShape::objectiveDestroyed(%this);
	GameBase::stopSequence(%this,0);
	GameBase::stopSequence(%this,1);
	GameBase::stopSequence(%this,2);
	Station::checkTarget(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.40, 
		0.1, 250, 100); 
}

function Station::weaponCheck(%this)
{
	if(%this.lastPlayer != "") {
		%player = %this.lastPlayer;
		%player.Station = "";
		if(Player::getMountedItem(%player,$WeaponSlot) == -1){
			if(%player.lastWeapon != "") {
				Player::useItem(%player,%player.lastWeapon);		 	
				%player.lastWeapon = "";
	  		}
		}											
	 	%this.lastPlayer = "";
  	}
}

function Station::getTarget(%this)
{
	if(GameBase::getLOSInfo(%this,1.5,"0 0 3.14")) {
	  	// GetLOSInfo sets the following globals:
	  	// 	los::position
	  	// 	los::normal
	  	// 	los::object
	  	%obj = getObjectType($los::object);
		dbecho(3, "STATION: LOS got " @ %obj);
	  	if (%obj == "Player") {
         if( Player::isAiControlled( $los::object ) != "True" ) {
			   return $los::object;
         }
		}
	}
	dbecho(3, "STATION: LOS Got None");
	return -1;
}	

function Station::onCollision(%this, %object)
{
	if(%this.target == ""){
		dbecho(3, "STATION: Collision (" @ %this @ "," @ %object @ ")");
		%obj = getObjectType(%object);
		if (%obj == "Player" && isPlayerBusy(%object) == 0) {
  		 	%client = Player::getClient(%object);
 			if(GameBase::getTeam(%object) == GameBase::getTeam(%this) || GameBase::getTeam(%this) == -1) {
				if (GameBase::getDamageState(%this) == "Enabled") {
					if (GameBase::isPowered(%this)) { 
						if(%this.enterTime == "")
							%this.enterTime = getSimTime();
						GameBase::setActive(%this,true);
					}
					else 
						Client::sendMessage(%client,0,"Unit is not powered");
				}
				else 
					Client::sendMessage(%client,0,"Unit is disabled");
			}
			else if(Station::getTarget(%this) == %object)
   	   {
				%curTime = getSimTime();
				if(%curTime - %object.stationDeniedStamp > 3.5 && GameBase::getDamageState(%this) == "Enabled") {
					Client::clearItemShopping(%client);
					Station::onDeactivate(%this);
					Station::onEndSequence(%this,1);
					if(Client::getGuiMode(%client) != 1)
						Client::setGuiMode(%client,1);
					%object.stationDeniedStamp = %curTime;
					Client::sendMessage(%client,0,"--ACCESS DENIED-- Wrong Team ~waccess_denied.wav");
				}
			}
		}
	}
}

function Station::itemsToResupply(%player)
{
	%cnt = 0;
	%cnt = %cnt + AmmoStation::resupply(%player,"",RepairPatch,1);
	%cnt = %cnt + AmmoStation::resupply(%player,"",Grenade,2);
	%cnt = %cnt + AmmoStation::resupply(%player,"",RepairKit,1);
	%cnt = %cnt + AmmoStation::resupply(%player,ChainGun,BulletAmmo,20);
	%cnt = %cnt + AmmoStation::resupply(%player,PlasmaGun,PlasmaAmmo,5);
	%cnt = %cnt + AmmoStation::resupply(%player,GrenadeLauncher,GrenadeAmmo,2);
	%cnt = %cnt + AmmoStation::resupply(%player,DiscLauncher,DiscAmmo,2);
	%cnt = %cnt + AmmoStation::resupply(%player,Mortar,MortarAmmo,2);
	%cnt = %cnt + AmmoStation::resupply(%player,Angel,AngelAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,Dragun,DragunAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,AutoCocker,AutoCockerAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,Spyder,SpyderAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,TipmannS,TipmannSAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,Mongoose,MongooseAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,Inferno,InfernoAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,Psycho,PsychoAmmo,200);
	%cnt = %cnt + AmmoStation::resupply(%player,Delta,DeltaAmmo,10);
	%cnt = %cnt + AmmoStation::resupply(%player,Spyder,SpyderClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,Angel,AngelClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,AutoCocker,AutoCockerClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,Dragun,DragunClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,Mongoose,MongooseClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,Psycho,PsychoClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,Inferno,InfernoClip,1);
	%cnt = %cnt + AmmoStation::resupply(%player,Delta,DeltaClip,1);
	return %cnt;
}

//----------------------------------------------------------------------------
// Deployable stations

function DeployableStation::onActivate(%this)
{
	//echo("Activate " @ %this);
	%obj = Station::getTarget(%this);
	if (%obj != -1) {
		GameBase::playSequence(%this,1,"activate");
		GameBase::setSequenceDirection(%this,1,1);
	}
	else 
		GameBase::setActive(%this,false);
}


function DeployableStation::onEndSequence(%this,%thread)
{
   if(!%thread) {
		%this.deployed = 1;
		GameBase::playSequence(%this,2,"power");
	}
}

function DeployableStation::deploy(%this)
{
	GameBase::playSequence(%this,0,"deploy");
}

function DeployableStation::onDeactivate(%this)
{
	//echo("Dectivate " @ %this);
	GameBase::stopSequence(%this,1);
}

function DeployableStation::onEnabled(%this)
{
	GameBase::playSequence(%this,2,"power");
}

function DeployableStation::onDisabled(%this)
{
	GameBase::stopSequence(%this,2);
	GameBase::stopSequence(%this,1);
	Station::checkTarget(%this);
}

function DeployableStation::onDestroyed(%this)
{
	DeployableStation::onDisabled(%this);
	%stationName = GameBase::getDataName(%this);

	if(%stationName == DeployableInvStation) 
    	$TeamItemCount[GameBase::getTeam(%this) @ "DeployableInvPack"]--;
	else if( %stationName == DeployableAmmoStation) 
	  	$TeamItemCount[GameBase::getTeam(%this) @ "DeployableAmmoPack"]--;
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.30, 
		0.1, 200, 100); 
	Station::weaponCheck(%this);
}

function DeployableStation::onCollision(%this, %object)
{
	//echo("Collision (" @ %this @ ",	" @ %object @ ")");
	%obj = getObjectType(%object);
	if (%obj == "Player" && isPlayerBusy(%object) == 0) {
  	 	%client = Player::getClient(%object);
		if(GameBase::getTeam(%object) == GameBase::getTeam(%this) || GameBase::getTeam(%this) == -1) {
			if (GameBase::getDamageState(%this) == "Enabled") {
				if(%this.enterTime == "") 
					%this.enterTime = getSimTime();
				GameBase::setActive(%this,true);
			}
			else 
				Client::sendMessage(%client,0,"Unit is disabled");
		}
      else if(Station::getTarget(%this) == %object) {
			%curTime = getSimTime();
			if(%curTime - %object.stationDeniedStamp > 3.5 && GameBase::getDamageState(%this) == "Enabled") {
				%object.stationDeniedStamp = %curTime;
				Client::sendMessage(%client,0,"--ACCESS DENIED-- Wrong Team ~waccess_denied.wav");
			}
		}
	}
}

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

StaticShapeData AmmoStation
{
   description = "Ammo Supply Unit";
	shapeFile = "ammounit";
	className = "Station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateAmmoStation };
	sequenceSound[1] = { "power", SoundAmmoStationPower };
	sequenceSound[2] = { "use", SoundUseAmmoStation };
	maxDamage = 1.0;
	debrisId = flashDebrisLarge;
	mapFilter = 4;
	mapIcon = "M_station";
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 16;
   explosionId = flashExpLarge;
};

function AmmoStation::onEndSequence(%this,%thread)
{
	//echo("End Seq ",%thread);
	%player = Station::getTarget(%this);
	if(%this.clTeamEnergy == "")
		%this.clTeamEnergy = (Player::getClient(%player)).TeamEnergy;
	if (Station::onEndSequence(%this,%thread)) {    
		%weapon = Player::getMountedItem(%player,$WeaponSlot);
		if(%weapon != -1) {
			%player.lastWeapon = %weapon;
			Player::unMountItem(%player,$WeaponSlot);
		}
		AmmoStation::onResupply(%this);
	}
}									
											
function AmmoStation::onResupply(%this)
{
	if (GameBase::isActive(%this)) {
		%player = Station::getTarget(%this);
		if (%player != -1 && %this.lastPlayer == %player) {
			// Hardcoded here for the ammo types
			%cnt = Station::itemsToResupply(%player);
			if(getSimTime() - %this.enterTime > 11)
				%cnt = 0;
			if (%cnt != 0) {
				%player.waitThrowTime = getSimTime();
				schedule("AmmoStation::onResupply(" @ %this @ ");",0.5,%this);
				return;
			}
			%player.Station = "";
			%client = Player::getClient(%player);
			%this.target = "";
			Client::sendMessage(%client,0,"Resupply Complete");
			Client::setInventoryText(%client, "<f1><jc>TEAM ENERGY: " @ $TeamEnergy[Client::getTeam(%client)]);

			if(Player::getMountedItem(%player,$WeaponSlot) == -1){
				if(%player.lastWeapon != "") {
					Player::useItem(%player,%player.lastWeapon);		 	
					%player.lastWeapon = "";
	  			}
			}			
		}
		else if(%this.target != "") {
			%player = Client::getOwnedObject(%this.target);
			%player.Station = "";
			if(Player::getMountedItem(%player,$WeaponSlot) == -1){
				if(%player.lastWeapon != "") {
					Player::useItem(%player,%player.lastWeapon);		 	
					%player.lastWeapon = "";
	  			}
			}		
			%this.target = "";
		}
		else {
			%this.lastPlayer.Station = "";
			if(Player::getMountedItem(%this.lastPlayer,$WeaponSlot) == -1){
				if(%this.lastPlayer.lastWeapon != "") {
					Player::useItem(%this.lastPlayer,%this.lastPlayer.lastWeapon);		 	
					%this.lastPlayer.lastWeapon = "";
	  			}
			}
			%this.target = "";
		}
		GameBase::setActive(%this,false);
		%this.enterTime="";
	}
}
		 											
function AmmoStation::resupply(%player,%weapon,%item,%delta)
{
	%delta = checkResources(%player,%item,%delta,1);		
	if(%delta > 0) {						
		if(%item == RepairPatch) {
			teamEnergyBuySell(%player,%item.price * %delta * -1);
			GameBase::repairDamage(%player,0.06);
		 	return %delta;
		}
		else if (%item == MineAmmo || %item == Grenade || %item == RepairKit) {
			teamEnergyBuySell(%player,%item.price * %delta * -1);
			Player::incItemCount(%player,%item,%delta);
		 	return %delta;
		}
		else if (Player::getItemCount(%player,%weapon)) {
			teamEnergyBuySell(%player,%item.price * %delta * -1);
			Player::incItemCount(%player,%item,%delta);
		 	return %delta;
		}
	}
	return 0;
}

//----------------------------------------------------------------------------
StaticShapeData DeployableAmmoStation
{
   description = "Remote Ammo Unit";
	shapeFile = "ammounit_remote";
   validateShape = true;
   validateMaterials = true;
	className = "DeployableStation";
	maxDamage = 0.25;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	sequenceSound[1] = { "use", SoundUseAmmoStation };
	sequenceSound[2] = { "power", SoundAmmoStationPower };

	visibleToSensor = true;
	shadowDetailMask = 4;
	castLOS = true;
	supression = false;
	supressable = false;
	mapFilter = 4;
	mapIcon = "M_station";
	debrisId = flashDebrisSmall;
	damageSkinData = "objectDamageSkins";
   explosionId = flashExpMedium;
};


function DeployableAmmoStation::onAdd(%this)
{
	schedule("DeployableStation::deploy(" @ %this @ ");",1,%this);
	if (GameBase::getMapName(%this) == "") 
		GameBase::setMapName (%this, "R-Ammo Station");
	%this.Energy = $RemoteAmmoEnergy;
}

function DeployableAmmoStation::onActivate(%this)
{
	if(%this.deployed == 1) {
		GameBase::playSequence(%this,1,"use");
		//echo("Activate " @ %this);
		schedule("AmmoStation::onResupply(" @ %this @ ");",0.5,%this);
		%this.lastPlayer = Station::getTarget(%this);
		%player = %this.lastPlayer; 
		%player.Station = %this;
		%this.target = Player::getClient(Station::getTarget(%this));
		%weapon = Player::getMountedItem(%player,$WeaponSlot);
		if(%weapon != -1) {
			%player.lastWeapon = %weapon;
			Player::unMountItem(%player,$WeaponSlot);
		}
	}
	else 
		GameBase::setActive(%this,false);	
}


//----------------------------------------------------------------------------

StaticShapeData DeployableInvStation
{
	description = "Remote Inv Unit";
	shapeFile = "invent_remote";
   validateShape = true;
   validateMaterials = true;
	className = "DeployableStation";
	maxDamage = 0.25;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	sequenceSound[1] = { "use", SoundUseAmmoStation };
	sequenceSound[2] = { "power", SoundInventoryStationPower };			
	visibleToSensor = true;
	shadowDetailMask = 4;
	castLOS = true;
	supression = false;
	supressable = false;
	mapFilter = 4;
	mapIcon = "M_station";
	debrisId = flashDebrisMedium;
	damageSkinData = "objectDamageSkins";
   explosionId = flashExpSmall;
//	triggerRadius = 1.5;
};


function DeployableInvStation::onAdd(%this)
{
	schedule("DeployableStation::deploy(" @ %this @ ");",1,%this);
	if (GameBase::getMapName(%this) == "") 
		GameBase::setMapName (%this, "R-Inv Station");
	%this.Energy = $RemoteInvEnergy;
}

function DeployableInvStation::onActivate(%this)
{
	if(%this.deployed == 1) {
		GameBase::playSequence(%this,1,"use");
		//echo("Activate " @ %this);
 		InventoryStation::onResupply(%this,"RemoteInvList");
		%this.lastPlayer = Station::getTarget(%this);
	}
	else
		GameBase::setActive(%this,false);
}


//----------------------------------------------------------------------------

StaticShapeData InventoryStation
{
   description = "Station Supply Unit";
	shapeFile = "inventory_sta";
	className = "Station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateInventoryStation };
	sequenceSound[1] = { "power", SoundInventoryStationPower };
	sequenceSound[2] = { "use", SoundUseInventoryStation };
	maxDamage = 999999999999999999.0;
	debrisId = flashDebrisLarge;
	mapFilter = 4;
	mapIcon = "M_station";
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 16;
	triggerRadius = 1.5;
   explosionId = flashExpLarge;
};

function InventoryStation::onEndSequence(%this,%thread)
{
	//echo("End Seq ",%thread);
	if (Station::onEndSequence(%this,%thread)) 
		InventoryStation::onResupply(%this,"InvList");
}

function InventoryStation::onResupply(%this,%InvShopList)
{
	dbecho(3, "STATION::Resupply");
	if (GameBase::isActive(%this)) {
		%player = Station::getTarget(%this);
		if (%player != -1 && %this.lastPlayer == %player) {
			%client = Player::getClient(%player);
			if (%this.target != %client) {
				%player.Station = %this;
				setupShoppingList(%client,%this,%InvShopList);
				updateBuyingList(%client);
				%this.target = %client;
				%this.clTeamEnergy = %client.TeamEnergy;
            if(!%client.noEnterInventory)
   				Client::setGuiMode(%client,$GuiModeInventory);
				Client::sendMessage(%client,0,"Station Access On");
				%player.ResupplyFlag = 1;
				%weapon = Player::getMountedItem(%player,$WeaponSlot);
				if(%weapon != -1) {
					%player.lastWeapon = %weapon;
					Player::unMountItem(%player,$WeaponSlot);
				}
			}
			%player.waitThrowTime = getSimTime();
			schedule("InventoryStation::onResupply(" @ %this @ ");",0.5,%this);
			if(%player.ResupplyFlag) 
			   %player.ResupplyFlag = resupply(%this);
			return;
		}
		GameBase::setActive(%this,false);
	}
	if (%this.target != "") {	   
		%player = Client::getOwnedObject(%this.target);
		Client::clearItemShopping(%this.target);
		Client::sendMessage(%this.target,0,"Station Access Off");
		Station::onEndSequence(%this);
		if(GameBase::getDataName(%player.Station) == DeployableInvStation) {
			Client::setInventoryText(%this.target, "<f1><jc>TEAM ENERGY: " @ $TeamEnergy[Client::getTeam(%this.target)]);
			if(Client::getGuiMode(%this.target) != 1)
				Client::setGuiMode(%this.target,1);
			%player.Station = "";
  			%this.target = "";
		}
		if(Player::getMountedItem(%player,$WeaponSlot) == -1){
			if(%player.lastWeapon != "") {
				Player::useItem(%player,%player.lastWeapon);		 	
				%player.lastWeapon = "";
	  		}
		}
	}
	%this.enterTime="";
}


function resupply(%this)
{
	if (GameBase::isActive(%this)) {
		%player = Station::getTarget(%this);
		if (%player != -1) {
			// Hardcoded here for the ammo types
			%cnt = Station::itemsToResupply(%player);
			if(getSimTime() - %this.enterTime > 11)
				%cnt = 0;
			%client = Player::getClient(%player);
			if (%cnt != 0) {
				updateBuyingList(%client);
				return 1;
			}
			Client::sendMessage(%client,0,"Resupply Complete");
			return 0;
		}
	}
	return 0;
}


//----------------------------------------------------------------------------
function setupShoppingList(%client,%station,%ListType)
{
	%max = getNumItems();
	if(%ListType == "InvList") {
		for (%i = 0; %i < %max; %i = %i + 1) {
			%item = getItemData(%i);
			if($InvList[%item] != "" && $InvList[%item] && !%station.dontSell[%item]) 
				Client::setItemShopping(%client, %item);
			else if(%item.className == Armor && !%station.dontSell[%item])  
				Client::setItemShopping(%client, %item);
		}
	}
	else if(%ListType == "RemoteInvList") {
		for (%i = 0; %i < %max; %i = %i + 1) {
			%item = getItemData(%i);
			if($RemoteInvList[%item] != "" && $RemoteInvList[%item] && !%station.dontSell[%item]) 
				Client::setItemShopping(%client, %item);
	   }
	}
	else {
		for (%i = 0; %i < %max; %i = %i + 1) {						
			%item = getItemData(%i);
			if($VehicleInvList[%item] != "" && $VehicleInvList[%item] && !%station.dontSell[%item]) 
				Client::setItemShopping(%client, %item);
		}
	}
}

function updateBuyingList(%client)
{
   Client::clearItemBuying(%client);
	%station = (Client::getOwnedObject(%client)).Station;
	%stationName = GameBase::getDataName(%station); 
	if(%stationName == DeployableInvStation || %stationName == DeployableAmmoStation) {
		%energy = %station.Energy;
   	Client::setInventoryText(%client, "<f1><jc>STATION ENERGY: " @ %energy );
	}
   else {
		%energy = $TeamEnergy[Client::getTeam(%client)];
		Client::setInventoryText(%client, "<f1><jc>TEAM ENERGY: " @ %energy);
	}
	%armor = Player::getArmor(%client);
	%max = getNumItems();
	for (%i = 0; %i < %max; %i++) {
		%item = getItemData(%i);
      if(!%item.showInventory)
         continue;
		if($ItemMax[%armor, %item] != "" && Client::isItemShoppingOn(%client,%i)) {
			%extraAmmo = 0;
			if(Player::getMountedItem(%client,$BackpackSlot) == ammopack)
				%extraAmmo = $AmmoPackMax[%item];
			if($ItemMax[%armor, %item] + %extraAmmo > Player::getItemCount(%client,%item))	{
				if(%energy >= %item.price ) {
					if(%item.className == Weapon) {
						if(Player::getItemClassCount(%client,"Weapon") < $MaxWeapons[%armor])					
							Client::setItemBuying(%client, %item);
					}
					else { 
						if($TeamItemMax[%item] != "") {						
							if($TeamItemCount[GameBase::getTeam(%client) @ %item] < $TeamItemMax[%item])
								Client::setItemBuying(%client, %item);
						}
						else
							Client::setItemBuying(%client, %item);
					}
				}
		   }
		}
		else if(%item.className == Armor && %item != $ArmorName[%armor] && Client::isItemShoppingOn(%client,%i)) 
			Client::setItemBuying(%client, %item);
		else if(%item.className == Vehicle && $TeamItemCount[client::getTeam(%client) @ %item] < $TeamItemMax[%item] && Client::isItemShoppingOn(%client,%i))
			Client::setItemBuying(%client, %item);
	}
}

//----------------------------------------------------------------------------
StaticShapeData CommandStation
{
   description = "Command Station";
	shapeFile = "cmdpnl";
	className = "Station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateCommandStation };
	sequenceSound[1] = { "power", SoundCommandStationPower };
	sequenceSound[2] = { "use", SoundUseCommandStation };
	maxDamage = 1.0;
	debrisId = flashDebrisMedium;
	mapFilter = 4;
	mapIcon = "M_station";
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 16;
	triggerRadius = 1.5;
   explosionId = flashExpLarge;
};

function CommandStation::onEndSequence(%this,%thread)
{
	//echo("End Seq ",%thread);
	(Client::getOwnedObject(%this.target)).Station = "";
	%this.target = "";
	if (Station::onEndSequence(%this,%thread)) 
		CommandStation::onResupply(%this);
}

function CommandStation::onResupply(%this)
{
	if (GameBase::isActive(%this)) {
		%player = Station::getTarget(%this);
		if (%player != -1 && %this.lastPlayer == %player) {
			%client = Player::getClient(%player);
			if (%this.target != %client) {
				%this.target = %client;
				%player.CommandTag = 1;
				Client::setGuiMode(%client,2);
				Client::sendMessage(%client,0,"Command Access On");
				%player.station = %this;
			}
			schedule("CommandStation::onResupply(" @ %this @ ");",0.5,%this);
			return;
		}
		GameBase::setActive(%this,false);
	}
	if (%this.target) {
		Client::sendMessage(%this.target,0,"Command Access Off");
		(Client::getOwnedObject(%this.target)).CommandTag = "";
		checkControlUnmount(%this.target);
	}
	(Client::getOwnedObject(%this.target)).Station = "";
	%this.target = "";
}


//----------------------------------------------------------------------------
StaticShapeData VehicleStation
{
   description = "Station Vehicle Unit";
	shapeFile = "vehi_pur_pnl";
	className = "Station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateInventoryStation };
	sequenceSound[1] = { "power", SoundInventoryStationPower };
	sequenceSound[2] = { "use", SoundUseInventoryStation };
//   explosionId = DebrisExp;
	maxDamage = 1.0;
	debrisId = flashDebrisLarge;
	mapFilter = 4;
	mapIcon = "M_station";
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 16;
	triggerRadius = 1.5;
   explosionId = flashExpLarge;
};

function VehicleStation::onEndSequence(%this,%thread)
{
	//echo("End Seq ",%thread);
	if (Station::onEndSequence(%this,%thread)) 
		VehicleStation::onBuyingVechicle(%this);
}

function VehicleStation::onBuyingVechicle(%this)
{
	if (GameBase::isActive(%this)) {
		%player = Station::getTarget(%this);
		if (%player != -1 && %this.lastPlayer == %player) {
			%client = Player::getClient(%player);
			if (%this.target != %client) {
				setupShoppingList(%client,%this,"VehicleInvList");
				updateBuyingList(%client);
				%this.target = %client;
				%this.clTeamEnergy = %client.TeamEnergy;
				Client::setGuiMode(%client,4);
				Client::sendMessage(%client,0,"Station Access On");
				%player.Station = %this;
			 	%numItems = Group::objectCount(GetGroup(%this));
				for(%i = 0 ; %i<%numItems ; %i++) { 
					%obj = Group::getObject(GetGroup(%this), %i);
					%name = GameBase::getDataName(%obj); 
					if(%name == VehiclePad) { 
						%this.vehiclePad = %obj;
						GameBase::setActive(%this.vehiclePad,true);
						%i = %numItems;
					}
				}
			}
			schedule("VehicleStation::onBuyingVechicle(" @ %this @ ");",0.5,%this);
			return;
		}
		GameBase::setActive(%this,false);
	}
	if (%this.target) {	   
		Client::clearItemShopping(%this.target);
		Client::sendMessage(%this.target,0,"Station Access Off");
		Station::onEndSequence(%this);
	}
}


function VehicleStation::checkBuying(%client,%item)
{
	%player = Client::getOwnedObject(%client);
	%obj = %player.Station.vehiclePad;
	if(GameBase::isPowered(%obj) && GameBase::getDamageState(%obj) == "Enabled") {
		%markerPos = GameBase::getPosition(%obj);
  		%set = newObject("set",SimSet);
		%mask = $VehicleObjectType | $SimPlayerObjectType | $ItemObjectType;
		%objInWay = containerBoxFillSet(%set,%mask,%markerPos,6,5,14,1);
		%station = %player.Station;
		if(%objInWay == 1) {
			%object = Group::getObject(%set, 0);	
			%sName = GameBase::getDataName(%object);
			if(%sName.className == Vehicle) {
				if(GameBase::getControlClient(%object) == -1) {
					if(%station.fadeOut == "") {
						if(%item != $VehicleToItem[%sname]) {
							%object.fading = 1;
							%station.fadeOut=1;
							teamEnergyBuySell(%player,$VehicleToItem[%sName].price);
							$TeamItemCount[Client::getTeam(%client) @ ($VehicleToItem[%sName])]--;
							GameBase::startFadeOut(%object);
							schedule("deleteObject(" @ %object @ ");",2.5,%object);
							schedule(%object @ ".fading = \"\";",2.5,%object);
							schedule(%station @ ".fadeOut = \"\";",2.5,%station);
							%objInWay--;
						}
						else
							return 2;
					}
					else {
						Client::SendMessage(%client,0,"ERROR - Vehicle creation pad busy"); 
						return 0;
					}
				}
				else { 
					Client::SendMessage(%client,0,"ERROR - Vehicle in creation area is mounted");
					return 0;
				}
			} 
		}
		if(!%objInWay) {
			if (checkResources(%player,%item,1)) {
	    		%vehicle = newObject("",flier,$DataBlockName[%item],true);
				Gamebase::setMapName(%vehicle,%item.description);
            %vehicle.clLastMount = %client;
				addToSet("MissionCleanup", %vehicle);
			  	%vehicle.fading = 1;
				GameBase::setTeam(%vehicle,Client::getTeam(%client));
				if(%object.fading) { 
					schedule("GameBase::startFadeIn(" @ %vehicle @ ");",2.5,%vehicle);
					schedule("GameBase::setPosition(" @ %vehicle @ ",\"" @ %markerPos @ "\");",2.5,%vehicle);
					schedule("GameBase::setRotation(" @ %vehicle @ ",\"" @ GameBase::getRotation(%obj) @ "\");",2.5,%vehicle);
					schedule(%vehicle @ ".fading = \"\"; VehiclePad::checkSeq(" @ %obj @ "," @ %player.Station @ ");",5,%vehicle);
					%obj.busy = getSimTime() + 5;
				}
				else {
					GameBase::startFadeIn(%vehicle);
					GameBase::setPosition(%vehicle,%markerPos);
					GameBase::setRotation(%vehicle,GameBase::getRotation(%obj));
				 	schedule(%vehicle @ ".fading = \"\"; VehiclePad::checkSeq(" @ %obj @ "," @ %player.Station @ ");",3,%vehicle);
					%obj.busy = getSimTime() + 3;
				}
				deleteObject(%set);
				$TeamItemCount[Client::getTeam(%client) @ %item]++;
				return 1;
			}
		}
		else
			Client::SendMessage(%client,0,"ERROR - Object in vehicle creation area");
		deleteObject(%set);
	}	
	else
		Client::SendMessage(%client,0,"ERROR - Vehicle Pad Disabled");

	return 0;
}


StaticShapeData VehiclePad
{
   description = "Vehicle Pad";
	shapeFile = "vehi_pur_poles";
	className = "Station";
	visibleToSensor = true;
	sequenceSound[0] = { "activate", SoundActivateInventoryStation };
	sequenceSound[1] = { "power", SoundInventoryStationPower };
	sequenceSound[2] = { "use", SoundUseInventoryStation };
	maxDamage = 1.0;
	debrisId = flashDebrisLarge;
	mapFilter = 4;
	mapIcon = "M_station";
   explosionId = flashExpLarge;
	damageSkinData = "objectDamageSkins";
};



function VehiclePad::onActivate(%this)
{
	GameBase::playSequence(%this,1,"use");
}

function VehiclePad::onDeactivate(%this)
{
	GameBase::stopSequence(%this,1);
}

function VehiclePad::onEnabled(%this)
{
}

function VehiclePad::onAdd(%this)
{
}

function VehiclePad::onCollision(%this, %object)
{
}

function VehiclePad::onPower(%this,%power,%generator)
{
	if(!%power)
		GameBase::setActive(%this,false);
}

function VehiclePad::checkSeq(%this, %station)
{
	if(%station.target == "")
		GameBase::setActive(%this,false);
}
		���������������������������������������������������������������������������������|���zòѵ��ʰ�ŭ���߷���͹���`�^���Z�X������Q�������������������������������������������������������������������?�����87�������������������������������������������������������������������ܾ���'�����������O��#�޼�����������������������������������������������������������������������������������������������������������YYYYYYYYYYYHKv9�� �G]]]]]]]]]]]P222222222224*VbbbbbbbbbbbLTTTTTTTTTTT																																					ppppppppppppppppppppppppppppppppppppppppvI0PO/GL]2UUUUUUUUUUU	hhhhhhhhhhhhhhhhhhhhhhhhhhhhhpTTTTTTTTTTTTTTTTTTTTTTTTllllllllll           lc00000000000000000000																					 pTbbbbbbbbbbbbbbbbbbbbbbbbbbbbb                                              lcp                     hhhhhhhhhhhLLLLLLLLLLLLLL3333333333333333333333333333333333333333333333333333333333||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||Pkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk:vI4< 0O/	2GhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhTlccccccccccccccccccccccccccccc ppppppppppppppppppppppppppppppppppb]l                     cccccccccccpt	0h1 eccccccccccccccccccccc..............UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU          ellllllllllllllllllllllllllllllllltclp eeeeeeeeeeeTeeeeeeeeee           @PkkkkkkkkkkkkkkkkkkkkkkkkR:vILO/2lh																					0Gb1eeeeeeeeeeeeeet T.cccccccccccccccccccc          eppppppppppppppppppppppppppppppllllllllllddddddddddddddpt eeeeeeeeeeeceeeeeeeeee                              hp]]]]]]]]]]]]]]]]]]]]]T0	1eld ccccccccccccccccccccccccccccccccc          etttttttttttcpppppppppp.ltd eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                A\FFFFFFFFFFFFFFFFFFFFFFFFFFFFF=;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&YHjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj5555555555555555555555555555555555555555555555555K*********************************************************************************3|||||||||||||||||||||||||||||||||||44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444cvvvvvvvvvvvvvvvvvvvvvvvvvvvUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU@</kkkkkkkkkkkkkkkkkkkkkkkkRLP:ItTGOh]2																					ep.0              llllllllllllllllllll          eddddddddddddddddddddddddttttttttttcpd1 eeeeeeeeeeeleeeeeeeeee                        nTTTTTTTTTTTTTTTTTTTTd																			Sh.betc lpppppppppppppppppppp          e1111111111111111111111111111111lnnnnnnnnnnnnnnnnnnnnnnndt0c eeeeeeeeeeepeeeeeeeeee           SmgvA$$$$$$$$$$$$$$$$$$$$$$$$$$/////////////////////////////////////////////////////////////////////////////////////////LknTGR	P:]IIIIIIIIIIIIIIIIIIII0000000000000000000h.bO1leeeeeeeeeeeeeed ptttttttttttttttttttttttt          ecccccccccccccccpnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnllllllllllllllcd              eeeeeeeeeeettttttttttttttt         n	TS0mc22222222222222222222222222222222222222hpppppppppppppppppppppppppppppp.llllll etttttttttttttttttttttttttttt dddddddddddddddddddddddeec1ntp dllllllllllllllllllllllllllllllll               eeeeeeeeeeeeeeeeeeeeeeeeeeeeP(wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwN;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_____________________________+++++++++++++++++++++++++++++++++++++5|=433333333333333333333333333333333333333333333333333333333333333333333333333333333332VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUvA$$$$$$$$$$$$$$$$$$$$$$$$$$//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////LkGRg1b]	TS0m:Idddddddddddddddddddddddddddddddddddddddcccccccccccccccccccchhhhhhhhhhnttttttttttttttp              eeeeeeeeeeelllllllllllllll                      dscccccccccc.nnnnnn elttttttttttttttt          ppppppppppppppppppppppeeSSSSSSSSSSSSSSSSSSSSS	T111111111111110mssssssssssssssssssssO...................dlc          pnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeee tttttttttttttttllllllllllllssssssssssssssssssssssshhhhhhhhhpdtceeeeeeeeeeeeee                   nnnnnnnnnnnnnnneeeeeeeeeR(w2000000000000000APPPPPPPPPPPPPPPPPPPPPPPPPPvvvvvvvvvvvvvvvvvvvvvvvvvvv$</kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL:GTgbS	p.1mmmmmmmmmmmmmmmmmmmml sssssssssssssssssssssssthO]]]]]]eeeeeeeeendddddddddddddddeeeeeeeeeec                              psssssssssssstlnnnnnnnnnnnnnneeeeeeeeeeccccccccccccccccccccccccccccccccc                                eddddddddddddddd.....................0TsssssssssssrrrrrrrrrrrrrrrSnh	1mpppppppppppppppppppppt cldddddddddddddddddddddddddddddddddddee                                                                             rcnnnnnnnnnnnsepppppppppppppppppppppdtttttttttttttt Illllllllllllllllllllllllllllllllllllllllllllleeeeeeeeeeeeee  |>66666666666666666666666666666666666666666qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq9\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\FY&jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjH***********************************************@KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKNwEEEEEEEEEEEEEEEEEEEEEEE%yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy_;+<5=43333333333333333333333333333333333333333333333333333333333333333333333333333333333VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU(RgAPPPPPPPPPPPPPPPPPPPPPPPPPPvvvvvvvvvvvvvvvvvvvvvvvvvvv$20000000000000000000000k::::::::::::::::::::::::/Lh.....................OGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGSTc	11111111111rpndsIbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmttttttttttttttteeeeeeeeeeeeeeeeee      eeeeeeeeelllllllllllllllpppppppppppppppppppppppppppppprccccccccccndeeeeeeeeeeeeeesllllllllllll                              eeeeeeeeeettttttttttttttt         ],h.....................0000000000000000000ro	SSSSSSSSSSSSSSSTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT11111111111pppppppppcnnnnnnnnnnldddddd etsssssssssssssss                                          eeeeeeeeeeeeeeerrrrrrrrrrrocmlptn                     ddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee sssssssssssssss/CwEEEEEEEEEEEEEEEEEEEEEEE%y--------------------------------------(0"PgvA$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$:2Rkkkkkkkkkkkkkk,IIIIIIIIIIIIIIIIIIIIIIII.LO]Ghccccccccccccccccccccccccccccccccccccccccccccccccccccc																				StttttttttttorrrrrrrrrrmTllllllllllllllllllllpsneeeeeeeeeeeeee                   dddddddddddddddeeeeeeeeeocccccccccccctttttttttttttttttttttttt r1111111111slllllleeeeeeeeedpppppppppppppppeeeeeeeeeen                              .,,,,,,,,,,,,,,,0"bbbbbbbbbbbbbbbbbbbbhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhoiiiiiiiiiiiim											crtssssssssssssssd1Seeeeeeeeeenlllllllllllllll                                epppppppppppppppriiiiiiiiiiiidddddddddddcoooooooooots nnnnnnnnnnnnnnpTTTTTTTTTTTTTTTTTTTTTTee          lllllllllllllllllllllllllllllllvvvvvvvvvvvvvvvvvvB>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>|||||||||||||||||||||||||||||||||||||N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;<_=+35.///////////////////////////////4wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwCyEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~UP-%((((((((((((((((((((((((((((((((((((((((((gA$RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR:L2kI]]]]]]]]]]]]]]]]]]]]]]]]i""""""""""""""""""""""""""""""""""0,bOc1hhhhhhhhhhhhhhhhhhhmrnddddddddddddddddddddddeottttttttttpssssssssssssss lllllllllllllllllllllllllllllllllllllllllllllT	eeeeeeeeeeeeee  cniiiiiiiiiiirodpppppppppppplttttttttttttttttttSssssssssssssssseeeeeeeeeeeeeeeeee      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee111111111111111111111nnnnnnnnnnnnnnnnnnnn",,,,,,,,,,,,,,,.0oTGhhhhhhhhhhhhhhhhhhhclllllllllllriiiiiiiiiidpeSmmmmmmmmmmmmmmmmmmmmmmmmmt                              eeeeeeeeeesssssssssssssss         rno	lllllllllllcccccccccidddddddddddddddddddddddpppppp essssssssssssssssssssssssss          tttttttttttttttttttttteeeeeeeey))))))))))))))))))))))/vwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwCCCCCCCCCCCCCCCCCCCCCCCCCCCCLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLP-%(E1RAAAAAAAAAAAAAAAAAAAAAAAAAAA$gggggggggggggggggggggggggg,]:2kbITTTTTTTTTTTTTTTTTTTT"""""""""""""""""""""S.000000000000000nGGGGGGGGGGGGGGGGGGGGGGGGh																			rrrrrrrrrrroillllllllllllllcsd          tpppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                      nmrrrrrrrrrrroillllllllllllllcsdteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee            eeeeeeepppppp                                         ",0TTTTTTTTTTTTTTTTTTTT1	S.....................nnnnnnnnnnnnnnnOrrrrrrrrrrrromhlllllllllllciddddddddddddddeeeeeeeps                                      etttttttttttttttttttttttttttttttttttttttttttt  ronllllllllllllcccccccccccccccccccdddddddddddpiettttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssss;;;;;;;;;;;;;;;;;;;;;;;;;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx!{
}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}6\WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYjFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF&***********************************************************@HyffffffffffffffffffffffffffffffffffBBBBBBBBBBBBBBBBBBBBBBBBBBBBB>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV|<N==========================================================CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC_+333333333333333333333333333333333333335444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444))))))))))))))))))))))(vwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww////////////////////////////L]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]KP-%%%%%%%%%%%%%%%%%ER"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""gggggggggggggggggggggggggggA$$$$$$$$$$$$$$$$$$$$bbbbbbbbbbbbbbbbbbbbbbbbbb:2Gk.0T,m	S1ooooooooooooooooooooooooooooooooooolrcnddddddddddddpppppppppppppppppppOIttttttttttteeeeeeeee                        siiiiiiiiiiiie                                                               lcodrpnttttttttttttshe                                                                     eeeeeeeeeeeeeeeeeeeeeeeeeeeee                iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii."TTTTTTTTTTTTTTTTTTTTm0S,,,,,,,,,,,,,,,,,,,,,																			1lcodrpnttttttttttttshhhhhhhhhhhhhhhhhhhhhhhhhhhheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee            eeeeeeeeeeeeeeeeeeeeee                                         loircnddddddddddddppppppppppppppppppppppppteeeeeeeeeeeeeeeees                                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                             yfCM))))))))))))))))))))))(Ewwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww/vL]:P-%%%%%%%%%%%%%%%%%URg................bAAAAAAAAAAAAAAAAAAAAAAAAAAA$mOOOOOOOOOOOOOOOOOOOOOOOOOO2GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGTTTTTTTTTTTTTTTTTTTT"hS,0o																			rlniiiiiiiiiiiicccccccccccccccccccccccck1dddddddddddpeeeeeeeeeeeeeetttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            sssssssssssssssssssssssssssssssssssssssssrnoooooooooooollllllllllllllliiiiiiiiiiiccccccccccccccdeeeeeeeee                        sppppppppppppeeeeeeeeee             tttttttttttttttttttttttttttttttttttttttttttttttttttttttm................,,,,,,,,,,,,,,,,,,,,,TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTIhS"n0												rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisceeeeeeeeee        tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                ppnnnnnnnnnnnnr1ooooooooooolllllllllllllliscttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                                                                                   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxBBBBBBBBBBBBBBBBBBBBBBBBBBBBB>[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[;|<N========================================================================================_++++++++++++++++++++++D444444444444444444444444444444444444443555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555yfLM)C(EwwwwwwwwwwwwwwwwwwR/vvvvvvvvvvvvvvvvvvvvvvv]:P-22222222222222222UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU%gbAAAAAAAAAAAAAAAAAAAAAAAAAAA.$OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOTmmmmmmmmmmmmmmmm,SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSIGGGGGGGGGGGGGGGh"0narpooooooooooool1	iiiiiiiiiiiccccccccccccccccccccdseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoalpiiiiiiiiiiiicccccccccccccccccccdddddddddddttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeu.............................................................Tmmmmmmmmmmmmmmmmmmmm"SSSSSSSSSSSSSSSSSSSSS,rkkkkkkkkkkkkkkko1hlniacpddddddddddddttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloircndatpssssssssssss                     																																																											eeeeeeeee                                                       LRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRyfDM)2(EwwwwwwwwwwwwwwwwwwC/v$]:P-----------------------------------------------------------------------------------uuuuuuuuuuuuuAg%bmIIIIIIIIIIIIIIIIIIIIIIIIIIIOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOT.1"SSSSSSSSSSSSSSSSSSSSl,kkkkkkkkkkkkkkkkkkkkkkkkkkiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicodrtnsaaaaaaaaaaaaaappppppppeeeeeeeee                                                        eeeeeeeeee             	hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhcidltosrrrrrrrrrrrrrrnnnnnnnnnnnaeeeeeeeeee        0pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                                  mmmmmmmmmmmmmmmmmmmmmuTTTTTTTTTTTTTTTT1111111111111111111111111111111111111111111111111111111111111S.,""""""""""""""""""""""""""""""""""""""	Gcidltosrrrrrrrrrrrrrrnnnnnnnnnnna0000000000000000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       iiiiiiiiiiiilcodrtnsaaaaaaaaaaaaaaaaaaaapppppppppppeeeeeeeeee                                    hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhheeeeeeeeeeeeeeee  �j����������������������������������������������z�ʲ������������߷���Ϳ����`^�ҫZ��X�����Q��������������������������������������������������������������?�������7���8��J���������������������������������������������������������������������������������������������ܾ��'���#������� ��{qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq}!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\6666666666666666666666666666666666666666666YW9999999999999999999999999999999999999999999999U********************************************************FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFV&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxBBBBBBBBBBBBBBBBBBBBBBBBBBBBB>[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[HMN||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<_=44444444444444444444444444444443+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++;5/RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRyfDLLLLLLLLLLLLLLLLL2(EwwwwwwwwwwwwwwwwwwC)O$]:P-----------------------vvvvvvvvvvvvvvvvvvvvv%AIggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggb1111111111111mkkkkkkkkkkkkkkkkkkkkkkkkkkk,TTTTTTTTTTTTTTTTu	S.............................................................i"""""""""""""""""""l00000000000000000000oooooooooooorcndatpshGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinnnnnnnnnnnnacpdddddddddddddddttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeeeeeeeeeeeeeeee1111111111111m.,TTTTTTTTTTTTTTTTTTTTT0	Suooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo"rhhhhhhhhhhhhhhhhhhhnlaipppppppppppppppppppppppppppppppppppppppppppppcccccccccccd                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnraoplllllllllllllllllllllllllliiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeee                        sddddddddddddeeeeeeeeee             ttttttttttttttttttttttttttttttttttttDC/RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRyfMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM2(EwwwwwwwwwwwwwwwwwwLkO$]:P-)))))))))))))I%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%AvgTTTTTTTTTTTTTTTT1GbS.,mh0																					nuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuaaaaaaaaaaaaaaa"prrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisssssssssssseeeeeeeeee        tccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                ddanprrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllissssssssssssttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       ,TTTTTTTTTTTTTTTT1	S...........................h0mdddddddddddddddddddddunnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnraopllllllllllllllllllll"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnodlaippppppppppppppppppppppppppppppcccccccccccttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeKUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxBBBBBBBBBBBBBBBBBBBBBBBBBBBBB>[ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffN_|4<3======================================================================;++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++C/RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRyD---------------------------------------2(EwMGkO$]:PLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL5Iv%)A.,TTTTTTTTTTTTTTTTTTTTTTTTTTg0	S111111111111111111111111bbbbbbbbbbbbbbbhhhhhhhhhhhhhrmmmmmmmmmmmmmmmmmmmmmooooooooooooooooooooulniddddddddddddacpttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirrrrrrrrrrrrncdtasp                     """""""""""""""""""""""""""""""""""""""""""""""""""""""""""eeeeeeeee                                                       S.,Th0																																																																											1lllllllllllllmiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiocrtnsddddddddddddddaaaaaaaaeeeeeeeee                                  ppppppppppppeeeeeeeeee             "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuicltosrrrrrrrrrrrrrrnnnnnnnnnnndeeeeeeeeee                                                                    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                pp/yyyyyyyyyyyyyyyyyyCfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffRw-----------------------DO(E2PGkMv]:$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ILS%),,,,,,,,,,,,,,,,,,,,,,,,Ah.	TTTTTTTTTTTTTTTTTTTT00000000000000000000000000000000000000000000000000000000000000000000ggggggggggggggggggg1"mmmmmmmmmmmmicltosrrrrrrrrrrrrrrnnnnnnnnnnndddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                       ipllllllllllllocrtnsddddddddddddddddddddaaaaaaaaaaaeeeeeeeeee                                    uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuueeeeeeeeeeeeeeee                     ,Shhhhhhhhhhhhh	T.""""""""""""""""""""""""""""""0ibbbbbbbbbbbbbbbbbbblllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1oprrrrrrrrrrrrncdtasummmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinpddddddddddddacccccccccccccccccccccttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee>}{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{\!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!





















































































Y6j*WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVF~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&K@HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxBBBBBBBBBBBBBBBBBBBBBBBBBBBBBUUUUUUUUUUUUUUUUUUUUUUUUUUUU__________________________________________________________4N3||||||||||||||||||||||||||||||||||||||||<;============================================================[+EyyyyyyyyyyyyyyyyyyCffffffffffffffffffffffffffffffffffffff/:w-----------------------DO(RRRRRRRRRRRRRRRRRRRRRRRRPGkMv]2SIIIIIIIIIIIIIIIIIIIIIIIIII%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%$LTTTTTTTTTTTTTTTTTTTT,,,,,,,,,,,,,,,,,,,,,,,,,,,))))))))))))))))))))))))))))	hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh""""""""""""""".o0bAruuuuuuuuuuuuuuuuuuunldiappppppppppppppppppppp1111111111111111111111c                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrdoalmiiiiiiiiiiippppppppppppppppppppppppppppppppeeeeeeeee                        scccccccccccceeeeeeeeee             tttttttttttttttttttttttttttttttttttt	TTTTTTTTTTTTTTTTTTTT,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Suuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"hn.0dddddddddddddddddddddgarmmmmmmmmmmmmmmmmmmmooooooooooollllllllllllllispeeeeeeeeee        tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeee                ccdnar1ooooooooooollllllllllllllispttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                                            (EyyyyyyyyyyyyyyyyyyCffffffffffffffffffffffffffffffffffffffffffff]:w-----------------------DO//////////////////////////////////////////////////PGkMvRRRRRRRRRRRRRRRRRRRR%I$$$$$$$$$$$$$$$$$$$$$$$$$$25555555555555	TbL"""""""""""""""""""""""""""""",,,,,,,,,,,,,,,,,,,,,uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuSch.nm0rdoal1g)iiiiiiiiiiipppppppppppppppppppppppppppppppseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnocldiappppppppppppppppppppppppppppppppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee	TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT""""""""""""""""""""""""""""""""""mmmmmmmmmmmmmmmmmmmmmu,rSho1.lnicpddddddddddddattttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirpnnnnnnnnnnnnctdsa                     AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeeeeeeeee                                                                                                                                        >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB4_3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333N;||||||||||||||||||||||||||||||<[=UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUO(EyyyyyyyyyyyyyyyyyyCffffffffffffffffffffffv]:w-----------------------DDDDDDDDDDDDDDDDDDDDDDDDDDDDbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbPGkM/	$%2IRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRg5+uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"T1mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmml,Siiiiiiiiiiiiiiiiiiihpoooooooooooortnsccccccccccccccddddddddeeeeeeeee                                  aaaaaaaaaaaaeeeeeeeeee             AL....................................piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnceeeeeeeeee        0dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aaaaaaaaaaaaaaaaaaaaaaaaaaaauuuuuuuuuuuuuuuu"	111111111111111111111111111111111111111111111111111111111111111111111111111111111T,mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm)Spiiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnc0hhhhhhhhhhhhhhhhhhhhhhheeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                       ialpoooooooooooortnsccccccccccccccccccccdddddddddddeeeeeeeeee                                    ....................................eeeeeeeeeeeeeeee  fDO(EyyyyyyyyyyyyyyyyyyCCCCCCCCCCCCCCCCCMv]:w--------------------------------------------gbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbPGkkkkkkkkkkkkkkkkkkkkkkkkkkkku2$R%/I111111111111111111111111111AAAAAAAAAAAAAAAAAAAAAAAAAA,"																))))))))))))))))))))))))))))))))))))))))))))))))))))))))))TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTimmmmmmmmmmmmmmmmmmml00000000000000000000oarpnnnnnnnnnnnnctds.SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinacpddddddddddddhttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee	111111111111111111111111111T,"u0LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooomr...................nlcidahhhhhhhhhhhhhhhhhhhhpppppppppppppppppppppp                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrcodlSiiiiiiiiiiiaaaaaaaaaaaaaappppppppeeeeeeeee                        ssssssssssssssssssssssseeeeeeeeee             ttttttttttttttttttttttttttttttttttttB}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!Y
jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj*6V5~9WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWKFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>@HHHHHHHHHHHHHHHHHHHHHHHHHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxC34444444444444444444444444444444444444444_;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;N[|U<<<<<<<<<<<<<<<<<<<<<<<<<<<<<=======================DO(EyyyyyyyyyyyyyyyyyyfkMv]:w-----------------AgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbPGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGR2/$$$$$$$$$$$$$$$$$$$$$$$$$$$$%"	1)IIIIIIIIIIIIIIIIIIIIIT,,,,,,,,,,,,,,,.0LLLLLLLLLLLLLLLLLLLLLLLLLLunnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnchmdrSSSSSSSSSSSSSSSSSSSooooooooooollllllllllllllisaeeeeeeeeee        tpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                      cndrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisattttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       ,"	1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111TTTTTTTTTTTTTh.00000000000000000000000000uuuuuuuuuuuuuuuunSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSrcodllllllllllllllllllllmiiiiiiiiiiiaaaaaaaaaaaaaaaaaaaapseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoooooooooooolcidaaaaaaaaaaaaaaaaaaapppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee-----------------------DO(EyCGkMv]:wf)AgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbPPPPPPPPPPPPPPPPP	/RRRRRRRRRRRRRRRRRRRRRRRRRRRR2222222222222222222222$T,"L%0+IIIIIIIIIIIIIIIIIIIII1Sh.............rrrrrrrrrrrrrrruooooooooooooooooooooooooooooooooooolniiiiiiiiiiiiacpdttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloiranpppppppppppptcsd                     mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeee                                                                           T,".00000000000000000000000000																				Sh1llllllllllllllllllllllllllliiiiiiiiiiiiiiiiiiiuaoprtnssssssssssssssssssssssssscccccccceeeeeeeee                                  ddddddddddddeeeeeeeeee             mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmaipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnneeeeeeeeee                                                                    ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                ddddddddddddddddddddddddddddddddddd555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>34444444444444444444444444444444444444444_;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;DU[[[[[[[[[[[[[[[[[[[[[[[[[[[[[|N<y----------------------------------------M(EOwGkCg]:vP)AfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffbL/RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR2222222222222222222222,+=$.TTTTTTTTTTTTTTTTTTTTTTTTTT%""""""""""""""""""""0h													SSSSSSSSSSSSSSSSSSS1mmmmmmmmmmmmmmmaipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnuuuuuuuuuuuuuuuuuuuuuuueeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       idlaoprtnsssssssssssssssssssssssssssssssccccccccccceeeeeeeeee                                                                                      eeeeeeeeeeeeeeee                     ,,,,,,,,,,,,,,,,,,,,,.............I"Tmh	0iSSSSSSSSSSSSSSSSSSSlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1odranpppppppppppptcsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssseeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinddddddddddddacputtttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeE:y----------------------------------------M(DDDDDDDDDDDDDDDDDDDDDDDDwGkCg]OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOP)AffffffffffffffffffffffffffffffffffffffffffffffffffffffvvvvvvvvvvvvvvvvvvvvvRL2/bbbbbbbbbbbbbbbbb"""""""""""""""""""",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,													I$.............................................................mhTo0Srrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnllllllllllllicdu1aaaaaaaaaaap                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrrrrrrrrrrrrocllllllllllllllliiiiiiiiiiiddddddddddddddaaaaaaaaeeeeeeeee                        sppppppppppppeeeeeeeeee             tttttttttttttttttttttttttttttttttttt%"""""""""""""""""""",h																																																																																																												m.nT000000000000uScrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisdeeeeeeeeee        taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                pppppppppppppncr1ooooooooooollllllllllllllisdttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                                                          \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}{YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYj!*
VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV6+KWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&@xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx(44444444444444444444444444444444444444_3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333U;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;N[>|]:y----------------------------------------MEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEwGkCgDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD<P)AffffffffffffffffffffffffffffOOOOOOOOOOOOOOOOOOOO2RbLv/////////////%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%I"mh	,uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuup.Tnnnnnnnnnnnnnnn0rrrrrrrrrrrrocl1Siiiiiiiiiiiddddddddddddddddddddaseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnopllllllllllllicdddddddddddddddddddaaaaaaaaaaattttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee																																$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$mh"""""""""""""""uuuuuuuuuuuuuuuu,rrrrrrrrrrrrrrrrrrrrr.o1Tlnipddddddddddddacttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirdnapttttttttttttsc                     SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeee                                                       Mg]:y----------------------------------------(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((wGkCE%%%%%%%%%%%%%%%%%%%%%%%%%%=P)AfDDDDDDDDDDDDDDDDDDDDb2vROLh																																		////////////////////////////////////////////////////////////////////////////m$$$$$$$$$$$$$$$$$111111111111111u"l,,,,,,,,,,,,,,,,,,,,,iiiiiiiiiiiiiiiiiii.doartnsppppppppppppppppppppppppppppppppeeeeeeeee                                  cccccccccccceeeeeeeeee             STTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTdialtosrrrrrrrrrrrrrrnnnnnnnnnnnpeeeeeeeeee        0000000000000000000000000000000000000000000000000000000000000000000000eeeeeeeeeeeeee                cccccccccccccchhhhhhhhhhhhhhhh	mmmmmmmmmmmmmmmmmmmm1111111111111111111111111111111111111111111111111111111111111uI,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"SSSSSSSSSSSSSSSSSSSSSdialtosrrrrrrrrrrrrrrnnnnnnnnnnnp0.......................eeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                       icldoartnspppppppppppppppppppppppppppppppppppppppppeeeeeeeeee                                    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTeeeeeeeeeeeeeeee                                ++++++++++++++++++++++++++++++++++555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444U33333333333333333333333333333333333333333333333333333333333333333333N;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>[Cg]:y-----------------------MfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffwGk((((((((((((((((((((((%%%%%%%%%%%%%%%%%%%%%%%%%%=|P)AEEEEEEEEEEEEEEEEvbO2DR1111111111111h$L,mmmmmmmmmmmmmmmmmmmm	SuI/////////////////////////////////////////////////////////////iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiil0"ocrdnapttttttttttttsTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrincpdddddddddddda.ttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeeeeeeeeeeeeeeeeeeee1111111111111hhhhhhhhhhhhhhhhh,mmmmmmmmmmmmmmmm0Su	ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooorTTTTTTTTTTTTTTTTTTTnlpiiiiiiiiiiiic."ddddddddddda                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrpoooooooooooollllllllllllllllllllliiiiiiiiiiiccccccccccccccddddddddeeeeeeeee                        saaaaaaaaaaaaeeeeeeeeee             ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttkCg]:y------------------AfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffwGM$$$$$$$$$$$$$$$$$$$$$$%%%%%%%%%%%%%%%%%%%%%%%%%%<P)(((((((((((((OvDbE2mmmmmmmmmmmmmmmmmmmm1IRuuuuuuuuuuuuuuuuuL,hT0SSSSSSSSSSSSSSSSn																																																													p..........................rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisceeeeeeeeee        tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aapnnnnnnnnnnnnr"ooooooooooolllllllllllllliscttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                       ,mmmmmmmmmmmmmmmmmmmm1Su/////////////.T0haaaaaaaaaaaaaaaa	nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnrpooooooooooool"""""""""""""""iiiiiiiiiiiccccccccccccccccccccdseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoalpiiiiiiiiiiiicccccccccccccccccccdddddddddddttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee�K�����������������������������������������z、��ƴ�ʲ�̭�����ݽ�������^���Z�`��ҫ���X��������Q������������������������������������������������������������?������7����8��J��x�������������������������������������������������������������ܾ��'���#� ��������\Y}j{**************************************************V!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq~











































===============================================6WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF++++++++++++++++++++++++++++++++++555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&----------------------------------------------------------_U444444444444444444444444444444444444444444444444444444444444444444N3>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;GkCg]:yyyyyyyyyyyyyyyyyyyyyyy)AfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffwwwwwwwwwwwwwwwwwwI$$$$$$$$$$$$$$$$$$$$$$%%%%%%%%%%%%%%%%%%%%%%%%%%<[PMMMMMMMMMMMMMMMMMMMMDOEv(b/2RRRRRRRRRRRRRRRRRm,0Su111111111111111111111.TTTTTTTTTTTTTrhhhhhhhhhhhhhhhho"	lniacpddddddddddddttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloircndatpssssssssssss                                                                                             eeeeeeeee                                                       uuuuuuuuuuuuuuuuuuuuLmT0S,""""""""""""""""""""".1lllllllllllllhiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicodrtnsaaaaaaaaaaaaaappppppppeeeeeeeee                                                        eeeeeeeeee                           																																				cidltosrrrrrrrrrrrrrrnnnnnnnnnnnaeeeeeeeeee                                                                    pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                      CyGk-f]:gw)AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPI$$$$$$$$$$$$$$$$$$EEEEEEEEEEEEEEEEEEEEEEEEEE|%/DOMuv(Lb2RTTTTTTTTTTTTTTTTTTTTSm"0.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,111111111111111hcidltosrrrrrrrrrrrrrrnnnnnnnnnnnaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       iiiiiiiiiiiilcodrtnsaaaaaaaaaaaaaaaaaaaapppppppppppeeeeeeeeee                                    																																				eeeeeeeeeeeeeeee  "uuuuuuuuuuuuuuuuuTTTTTTTTTTTTTSmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm.,0iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiilllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1oooooooooooorcndatps	hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhheeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinnnnnnnnnnnnacpddddddddddddddddttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee<===============================++++++++++++++++++++++++++++++++++555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBx:UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU_N4>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>33333333333333333333333333333333333333333333333333333333333333333333333@;;;;;;;;;;;;;;;;;;;;;;;;yGk-f]C|||||||||||||||||||||||||||||||||||||w)AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgLPI$$$$$$$$$$$$$$$$$$EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE/DOMv(%m"ub2,,,,,,,,,,,,,STTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT....................o000000000000000000000r																			nlaippppppppppppppppppppppppppp1cccccccccccd                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnraoplhiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeee                        sddddddddddddeeeeeeeeee             ttttttttttttttttttttttttttttttttttttSm"u.,,,,,,,,,,,,,R																																																																											Tnnnnnnnnnnnnnnnnnnnn0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaprhhhhhhhhhhhhhhhhhhhooooooooooollllllllllllllisssssssssssseeeeeeeeee        tccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                ddanpr1ooooooooooollllllllllllllissssssssssssttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]yGk-f::::::::::::::::::::::::::[w)AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC(LPI$$$$$$$$$$$$$$$$$$Eg"DDDDDDDDDDDDDDDDDM////////////////////////////OOOOOOOOOOOOOSmbvvvvvvvvvvvvvvv.,uuuuuuuuuuuuuuuu																																																													R%dTTTTTTTTTTTTTTTTTTTTnh0raopl111111111111111111111iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnodlaippppppppppppppppppppppppppppppcccccccccccttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,,,,,,,,,,,,,Smmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm."hhhhhhhhhhhhhhhh	ur2To11111111111111111111lniddddddddddddacpttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirrrrrrrrrrrrncdtasp                                                                                                   eeeeeeeee                                                                                                                                                                          Y\jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj*}V{KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!9||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||6HWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW<===============================++++++++++++++++++++++++++++++++++555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555B&FfffffffffffffffffffffffffffffUNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>_________________________444444444444444444444444444444444444444444444444444444444444444444444@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@3xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxyGk-]EEEEEEEEEEEEEEEEEEEEEEEEEE[;w)AAAAAAAAAAAAAAAAAAAAAAA:b(LPI$$$$$$$$$$$$$$$$$$CSMDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDg/.,,,,,,,,,,,,,RO																																																																											m1hhhhhhhhhhhhhhhh"lu2viiiiiiiiiiiiiiiiiiiTTTTTTTTTTTTocrtnsddddddddddddddaaaaaaaaeeeeeeeee                                  ppppppppppppeeeeeeeeee                                                                                                  icltosrrrrrrrrrrrrrrnnnnnnnnnnndeeeeeeeeee        0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                pppppppppppppp.	,,,,,,,,,,,,,,,S1111111111111111111111111111111111111111111111111111111111111111111111111111muhhhhhhhhhhhhhhhhhhh"""""""""""""""""""""%%%%%%%%%%%%icltosrrrrrrrrrrrrrrnnnnnnnnnnnd0TTTTTTTTTTTTTTTTTTTTTTTeeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                       ipllllllllllllocrtnsddddddddddddddddddddaaaaaaaaaaaeeeeeeeeee                                                                                          eeeeeeeeeeeeeeee  ---------------------------------------------------------------------------------------------yGkffffffffffffffffffEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEw)A]Rb(LPI$:																												MgDCCCCCCCCCCCCCCCCC1111111111111.2/uuuuuuuuuuuuuuuS,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmihhhhhhhhhhhhhhhhhhhl0"oprrrrrrrrrrrrncdtassssssssssssssssssss%OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinpddddddddddddacTttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeS1111111111111.muuuuuuuuuuuuuuu	000000000000000000000000000000000000,ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooohrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnldiapT""""""""""""""""""""""c                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrdoalviiiiiiiiiiippppppppppppppppppppppppppppppppeeeeeeeee                        scccccccccccceeeeeeeeee             tttttttttttttttttttttttttttttttttttt[|<===============================++++++++++++++++++++++++++++++++++555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555BkNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU___________________________________________________________4xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyG-$$$$$$$$$$$$$$$$$$EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEw)f2Rb(LPI]]]]]]]]]]]]]ggggggggggggggggggggggggggggCM:DDDDDDDDDDDDDDDS1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%mu....................000000000000000000000	n,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,dTharv///////////////////ooooooooooollllllllllllllispeeeeeeeeee        tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeee                ccdnar"ooooooooooollllllllllllllispttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                       uuuuuuuuuuuuuuuS111111111111111111111111111111111111mmmmmmmmmmmmmTTTTTTTTTTTTTTTTTTTT0.c	,nOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOrdoal"hiiiiiiiiiiipppppppppppppppppppppppppppppppseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnocldiappppppppppppppppppppppppppppppppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeG)AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAykI$$$$$$$$$$$$$$$$$$EEEEEEEEEEEEEEEEEEEEEEEEEE;w-%2Rb(LPfSCg::::::::::::::::::::::::::::]MmuuuuuuuuuuuuuuuvD0000000000000000000000000000000000001OOOOOOOOOOOOOOOOOTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTr.	o",lnicpddddddddddddattttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirpnnnnnnnnnnnnctdsa                     hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhheeeeeeeee                                                                      muuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu000000000000000000000S"/T1lllllllllllll.iiiiiiiiiiiiiiiiiii	poooooooooooortnsccccccccccccccddddddddeeeeeeeee                                  aaaaaaaaaaaaeeeeeeeeee             h,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnceeeeeeeeee                                                                    dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa<jY*\VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVK}
{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!H9qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq6&WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW[|@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@++++++++++++++++++++++++++++++++++5555555555555555555555555555555555555555555555555555555555555555555555555555555555=====================================NNNNNNNNNNNNNNNNNNNNNNNNNNNNN>UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUBBBBBBBBBBBBBBBBBBBBBBBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4______________________________________y)AGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGwI$kRRRRRRRRRRRRRRRRRRRRRRRRRR;3EP%2-:(LbvCgfffffffffffffffffffffffffffffffffffffffffff]uOMMMMMMMMMMMMMMMMMMMMmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm"0TSSSSSSSSSSSSS/DDDDDDDDDDDDDDDDDDD1h.piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc																							eeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                       ialpoooooooooooortnsccccccccccccccccccccdddddddddddeeeeeeeeee                                    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,eeeeeeeeeeeeeeee  "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuumhTS0iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiilllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1oarpnnnnnnnnnnnnctds,.............................................................eeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinacpdddddddddddd	ttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeey)AGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGLwI$kRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRROP%2-:(EEEEEEEEEEEEEEEEgvvvvvvvvvvvvvvvvvvvvvvvvvvvvCbfffffffffffffff"u/]SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSShTmo00000000000000000Mr,,,,,,,,,,,,,,,,,,,nlcida	1pppppppppppppppppppppp                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrcodl.iiiiiiiiiiiaaaaaaaaaaaaaappppppppeeeeeeeee                        ssssssssssssssssssssssseeeeeeeeee             tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt"uTSSSSSSSSSSSSSSSSSSSSSSSSSSSS,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,hhhhhhhhhhhhhhhhhhhhnm0c	Ddr...................ooooooooooollllllllllllllisaeeeeeeeeee        tpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                      cndr1ooooooooooollllllllllllllisattttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<++++++++++++++++++++++++++++++++++5555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555UNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxB_________________________________________________=444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444y)AGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG(LwI$kRRRRRRRRRRRRRRRRRRRRRRR/OP%2-::::::::::::::::::::::""""""""""""""""""""""""""""gbvECCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCfhTSu	,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,mn.0rcodl1D]iiiiiiiiiiiaaaaaaaaaaaaaaaaaaaapseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoooooooooooolcidaaaaaaaaaaaaaaaaaaapppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSShT".	,urrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrro1mlniiiiiiiiiiiiacpdttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloiranpppppppppppptcsd                     MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMeeeeeeeee                                                                        RRRRRRRRRRRRRRRRRRRRRRRRRR3y)AGGGGGGGGGGGGGGGGGGGGGGGGGGG:(LwI$kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk/OP%2-------------------------------------------bbbbbbbbbbbbbbbbbbbbbbbbbbbbEggggggggggggggggggggggvTSSSSSSSSSSSSSDC,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,hhhhhhhhhhhhhhh1.	"luuuuuuuuuuuuuuuuiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiaoprtnssssssssssssssssssssssssscccccccceeeeeeeee                                  ddddddddddddeeeeeeeeee             Mfmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmaipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnneeeeeeeeee        0ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                ddddddddddddddT,Shhhhhhhhhhhhhhhhhhhhh1111111111111111111111111111111111111111111111111111111111111															u..................."]]]]]]]]]]]]]]]]aipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnn000000000000000000000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       idlaoprtnsssssssssssssssssssssssssssssssccccccccccceeeeeeeeee                                    mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeee                                                 jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj*******************************************VYK\














































































}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}{HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH&!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@6W;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<++++++++++++++++++++++++++++++++++55555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555GUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUxNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>_________________________=BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBkRRRRRRRRRRRRRRRRRRRRRRRRRR34y)AAAAAAAAAAAAAAAAAA-:(LwI$$$$$$$$$$$$$$$$$$$$$$$$$$$DDDDDDDDDDDDDDDDD/OP%222222222222222222222222,Ebbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbg1111111111111TMvuhhhhhhhhhhhhhhhhhhhhhS]C																																																																											i...................l0"odranpppppppppppptcsmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinddddddddddddacppppppppppppppppppppttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeeeeeeeeeeeeeeeeeeeee1111111111111TTTTTTTTTTTTTTTuh,0f	Sooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo.rmmmmmmmmmmmmmmmmmmmnllllllllllllicdddddddddddddddddddd"aaaaaaaaaaap                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrrrrrrrrrrrroclllllllllllllllliiiiiiiiiiiddddddddddddddaaaaaaaaeeeeeeeee                        sppppppppppppeeeeeeeeee             ttttttttttttttttttttttttttttttttttttA$kRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRy)G2-:(LwIIIIIIIIIIIIIIIIIIMDDDDDDDDDDDDDDDDD/OP%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%EEEEEEEEEEEEEEEEEEEEEEEbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhhhhhhhhhhhhhhhhhhhhh1]g															uTm0fv,nSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS.crrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisdeeeeeeeeee        taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                pppppppppppppncr"ooooooooooollllllllllllllisdttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                       uhhhhhhhhhhhhhhhhhhhhh1C																																														m0Tp,Snnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnrrrrrrrrrrrrocl".iiiiiiiiiiiddddddddddddddddddddaseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnopllllllllllllicdddddddddddddddddddaaaaaaaaaaattttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee3333333333333333333333333333333333333333;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<++++++++++++++++++++++++++++++++++5))))))))))))))))))))))))))))))))))))))))))))))))))))))))))Uxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_N=>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>BI$kRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRFyA%2-:(LwG]MDDDDDDDDDDDDDDDDD/OPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPEEEEEEEEEEEEEEEEEEEEEEEEEEEbbbbbbbbbbbbbbbuhffffffffffffffffffffffffffff0Cg	11111111111111111111111111111111111mmmmmmmmmmmmmrT,o"Slnipddddddddddddacttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirdnapttttttttttttsc                     ...........................................................eeeeeeeee                                                       															uhm0vvvvvvvvvvvvvvvvvvvvv"""""""""""""""""""""""""""""""""""1lllllllllllllTiiiiiiiiiiiiiiiiiii,doartnsppppppppppppppppppppppppppppppppeeeeeeeee                                  cccccccccccceeeeeeeeee             .SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSdialtosrrrrrrrrrrrrrrnnnnnnnnnnnpeeeeeeeeee                                                                                                                                         eeeeeeeeeeeeee                cckyI$)--------------------------4Rw%2AD(L:P]MGGGGGGGGGGGGGGGGGGGGGGGG/OOOOOOOOOOOOOOOOOfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff	EEEEEEEEEEEEEEEEEEEEEEEEEEEuCbmmmmmmmmmmmmmmmvvvvvvvvvvvvvvvvvvvvvvvvvvvvh"00000000000000000000000000000000000000000000000000000000000000000000000000000000000001.Tdialtosrrrrrrrrrrrrrrnnnnnnnnnnnppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp,,,,,,,,,,,,,,,,,,,,,,,eeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                       icldoartnspppppppppppppppppppppppppppppppppppppppppeeeeeeeeee                                    SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeeeeeeeeee  "u	mmmmmmmmmmmmmghhhhhhhhhhhhhhh........................................0iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiilllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1ocrdnapttttttttttttsSTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrincpdddddddddddda,ttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee�&������������������������������������������zㅲ�с��ʴ�̭ï�����ݹ���`^���Z��X���������������������������������������������������������������������Q������?����8�7�����۸J������������������������������������������������������������������������������������������������ܾ��'���# ����������������������������������������������������������j**************************************************************************************************************VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK
YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\H}999999999999999999999999999999999999999999{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~63333333333333333333333333333333333333333;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<+++++++++++++++++++++++++++++++++++++++++++++++++W4444444444444444444444444444444444444444444444444444444444Uxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_N=>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>B5LyI$)--------------------------kOw%2AD(RCP]MGGGGGGGGGGGGGGGGGGGGGGGG/:																						fEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEh"uvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvgbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm..................................o0000000000000000rSSSSSSSSSSSSSSSSSSSnlpiiiiiiiiiiiic,1ddddddddddda                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrpoooooooooooolTiiiiiiiiiiiccccccccccccccddddddddeeeeeeeee                        saaaaaaaaaaaaeeeeeeeeee             ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttth"uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu	SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS.mnnnnnnnnnnnnnnn0p,,,,,,,,,,,,,,,,,,,,,,,,,,,rTTTTTTTTTTTTTTTTTTTooooooooooollllllllllllllisceeeeeeeeee        tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aapnnnnnnnnnnnnr1ooooooooooolllllllllllllliscttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                                                (LyI$)-FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF/Ow%2ADkvCP]MGGGGGGGGGGGGGGGGGGGGGGGGR"EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEf:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::gh........................................u,SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS	ammmmmmmmmmmmmmmnT0rpooooooooooool1111111111111111iiiiiiiiiiiccccccccccccccccccccdseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoalpiiiiiiiiiiiicccccccccccccccccccdddddddddddttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb....................hT,Sur	mo111111111111111lniacpddddddddddddttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloircndatpssssssssssss                                                                                              eeeeeeeee                                                       BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB3333333333333333333333333333333333333333;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<+-U44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444xNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>_________________________====================================================================D(LyI$)))))))))))))))))))))))))))))))))))))))))))))))))/Ow%2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvCP]MGk"""""""""""""""""E::::::::::::::::::::::RffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS.bbbbbbbbbbbbbbbbbb1T,hlu	iiiiiiiiiiiiiiiiiiimcodrtnsaaaaaaaaaaaaaappppppppeeeeeeeee                                                        eeeeeeeeee                                                                             cidltosrrrrrrrrrrrrrrnnnnnnnnnnnaeeeeeeeeee        0pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                                                     SSSSSSSSSSSSSSSSSSSSS."1111111111111111111111111111111111111111111111111111111111111,guTTTTTTTTTTTTTTTTTTThhhhhhhhhhhhhhhh	cidltosrrrrrrrrrrrrrrnnnnnnnnnnna0mmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       iiiiiiiiiiiilcodrtnsaaaaaaaaaaaaaaaaaaaapppppppppppeeeeeeeeee                                                                                     eeeeeeeeeeeeeeee  )AD(LyI$-GGGGGGGGGGGGGGGGGGGGGGGG/Ow%2222222222222222222222222222222222222222222222222222222222222222222222222222222vCP]M5S:::::::::::::::::REkkkkkkkkkkkkkkkkkkkkkk11111111111111111111111111111111bfu."""""""""""""""""""""""""""""""""""",gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggiTTTTTTTTTTTTTTTTTTTl0hoooooooooooorcndatpsssssssssssssss																																																													eeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinnnnnnnnnnnnacpdmttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee"1111111111111111111111111111111111111111111111111u.S0000000000000000,,,,,,,,,,,,,,,,,,,,,oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooTrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnlaippppppppppppmhcccccccccccd                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnraopl	iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeee                        sddddddddddddeeeeeeeeee             ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttV*Kj










































































































































































YH\&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&@}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq6WFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3333333333333333333333333333333333333333;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<B$$$$$$$$$$$$$$$$$$$$$$$$$$$$$UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU4NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_+=2AD(LyI)MGGGGGGGGGGGGGGGGGGGGGGGG/Ow%-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbvCP]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]R:kkkkkkkkkkkkkkkkk55555555555555555555555555555555555E."1gggggggggggggggggggggg,,,,,,,,,,,,,,,,,,fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu0000000000000000SnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnamTpr																			ooooooooooollllllllllllllisssssssssssseeeeeeeeee        tccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                ddanprhooooooooooollllllllllllllissssssssssssttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       u."1111111111111111,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,mmmmmmmmmmmmmmm00000000000000000000dSSSSSSSSSSSSSSSSSSSSSn																																																													raoplhTiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnodlaippppppppppppppppppppppppppppppcccccccccccttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeI%2AD(Ly$]MGGGGGGGGGGGGGGGGGGGGGGGG/Ow)gbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbvCP-"kRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE.u0000000000000000,1	mmmmmmmmmmmmmmmmmmmmmmmmmmmrrrrrrrrrrrrrrrrrrrrSohhhhhhhhhhhhhhhhhhhhhlniddddddddddddacpttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirrrrrrrrrrrrncdtasp                     TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTeeeeeeeee                                                       ,"f...............0000000000000000uh	m1lllllllllllllllllllllllllllllllliiiiiiiiiiiiiiiiiiiSSSSSSSSSSSSocrtnsddddddddddddddaaaaaaaaeeeeeeeee                                  ppppppppppppeeeeeeeeee             TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTicltosrrrrrrrrrrrrrrnnnnnnnnnnndeeeeeeeeee                                                                    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|<355555555555555555555555555555UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU4NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA++++++++++++++++++++++++++++++++++++x_y%2IG(LDw]M$$$$$$$$$$$$$$$$$$$$$$$$$$$/OOOOOOOOOOOOOOOOOOOOOOOOPgb))))))))))))))))))))))))))))))))))))))))))))))))=vCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCkR-,::::::::::::::::::::::::::fffffffffffffffffEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"""""""""""""""".h0muuuuuuuuuuuuu																			1TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTicltosrrrrrrrrrrrrrrnnnnnnnnnnndddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                       ipllllllllllllocrtnsddddddddddddddddddddaaaaaaaaaaaeeeeeeeeee                                                                                           eeeeeeeeeeeeeeee  h,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,."Tmu0i																			lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1oprrrrrrrrrrrrncdtasssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssseeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinpddddddddddddacSttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeLOy%2IG(ACw]M$$$$$$$$$$$$$$$$$$$$$$$$$$$/DfPgb)))))))))))))))))))))))))))))))))))vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvkR-:::::::::::::::::::::::::::::::::::::::::::::::::::::.h,,,,,,,,,,,,,,,,,EuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuTm"o0	rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnldiapS1111111111111111111111c                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrdoalllllllllllllllllllliiiiiiiiiiippppppppppppppppppppppppppppppppeeeeeeeee                        scccccccccccceeeeeeeeee             ttttttttttttttttttttttttttttttttttttttttttttttttttt.h,muuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuTTTTTTTTTTTTTTTn"0dS	arrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllispeeeeeeeeee        tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeee                ccdnar1ooooooooooollllllllllllllispttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                       <999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVK~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
***********************************************jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH&Y@\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq}{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!6666666666666666666666666666666666666666666666666W>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[||||||||||||||||||||||||||||||||||||||(U544444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444N+Bxxxxxxxxxxxxxxxxxxxxxxxxx333333333333333333333333333333333333/Oy%2IGLvCw]M$$$$$$$$$$$$$$$$$$$$$$$$$$$AAAAAAAAAAAAAAAAAAAAAAAAAAfPgb)))))))))))))))))))))))))))))))))))_Dhkkkkkkkkkkkkkkkkkk----------------------------------------------RRRRRRRRRRRRRRRRRRRRRRRRRRRR.................:Tmu,SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSccccccccccccccc"nnnnnnnnnnnnnnnnnnnn0rdoal1	iiiiiiiiiiipppppppppppppppppppppppppppppppseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnocldiappppppppppppppppppppppppppppppppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeuuuuuuuuuuuuuuuuuuuuuuuuuuuu.............................................................TmhhhhhhhhhhhhhhhhhhhhSSSSSSSSSSSSSSSSSSSSS,rEEEEEEEEEEEEEEEo1"lnicpddddddddddddattttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirpnnnnnnnnnnnnctdsa                     																																																											eeeeeeeee                                                       GGGGGGGGGGGGGGGGGGGGGGGGGGG/Oy%2I(=vCw]M$LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLfPgb)AAAAAAAAAAAAAAAA-kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkDDDDDDDDDDDDDDDDDDDDDDDmuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRT.11111111111111111111Shl,E:iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiipoooooooooooortnsccccccccccccccddddddddeeeeeeeee                                  aaaaaaaaaaaaeeeeeeeeee             	""""""""""""""""""""""""""""""""""""piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnceeeeeeeeee        0dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aaaaaaaaaaaaaammmmmmmmmmmmmmmmmmmmmuTTTTTTTTTTTTTTTT1111111111111111111111111111111111111111111111111111111111111S.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,h																												piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnc0000000000000000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                       ialpoooooooooooortnsccccccccccccccccccccdddddddddddeeeeeeeeee                                    """"""""""""""""""""""""""""""""""""eeeeeeeeeeeeeeee                                                                                                                                                <F>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[|I4UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU55555555555555555555555555555555555555555555555555555555555555+++++++++++++++++++++++++++++++++++++xN3BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB$$$$$$$$$$$$$$$$$$$$$$$$$$$/Oy%2G)====================================vCw]M(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((fPgbLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL-DkAAAAAAAAAAAAAAAAAA1111111111111mEEEEEEEEEEEEEEEEEEEEEEE,TTTTTTTTTTTTTTTTu	S.............................................................iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiil0hoarpnnnnnnnnnnnnctds""""""""""""""""""""""""""""RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRReeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinacpddddddddddddddddddddddddddttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeeeeeeeeeeeeeeee1111111111111m.,TTTTTTTTTTTTTTTTTTTTT0	Suoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooor"""""""""""""""""""nlcidaaaaaaaaaaaaaaahpppppppppppppppppppppp                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrcodl:iiiiiiiiiiiaaaaaaaaaaaaaappppppppeeeeeeeee                        ssssssssssssssssssssssseeeeeeeeee             tttttttttttttttttttttttttttttttttttt2M$$$$$$$$$$$$$$$$$$$$$$$$$$$/Oy%Ib)_vCw]GEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEfPg(((((((((((((DDDDDDDDDDDDDDDDDDDDDDDDA-LkTTTTTTTTTTTTTTTT111111111111111111111111111111111111111111111S.,m"0																					nuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuccccccccccccccccccccccccccccccccccdr:::::::::::::::::::::::::::::::::::::::::ooooooooooollllllllllllllisaeeeeeeeeee        tpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                      cndrhooooooooooollllllllllllllisattttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       ,TTTTTTTTTTTTTTTT1	S..........................."0mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmunRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRrcodlhhhhhhhhhhhhhhhhhhhhiiiiiiiiiiiaaaaaaaaaaaaaaaaaaaapseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoooooooooooolcidaaaaaaaaaaaaaaaaaaapppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee[
KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV*Hj&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY\=}{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!<FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6666666666666666666666666666666666666666666666666666666666666666666666666666666666666666;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%4444444444444444444444444444444444U+5xxxxxxxxxxxxxxxxxxxxxxxxxxxxx33333333333333333333333333333333333333333333333333333333333333333333333333N|B]M$$$$$$$$$$$$$$$$$$$$$$$$$$$/Oy2gb)_________________________vCwIIIIIIIIIIIIIIIIIIIIIIIIIIIIEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEfPGGGGGGGGGGGGGGGGADLLLLLLLLLLLLLLLLLLLLLLLL(-.,T:k0	S1RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"""""""""""""rmmmmmmmmmmmmmmmmmmmmmohulniiiiiiiiiiiiacpdttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloiranpppppppppppptcsd                                                                                                  eeeeeeeee                                                       S.,T"0																hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh1lllllllllllllmiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiaoprtnssssssssssssssssssssssssscccccccceeeeeeeee                                  ddddddddddddeeeeeeeeee                                uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuaipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnneeeeeeeeee                                                                    ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                dd$y]M%)/OOOOOOOOOOOOOOOOOOOOOOOOOOOwgb2222222222222222222222vCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCPPPPPPPPPPPPPPPPPPPPPPPPPPPPEILLLLLLLLLLLLLLLLLLLLLLLLLLfffffffffffffffff:ADGSSSSSSSSSSSSSSSSSSSSSSSS(,R-".	Th0000000000000000000000000000000000000000000000000000000000000000kkkkkkkkkkkkkkkkkkk11111111111111111111maipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnneeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       idlaoprtnsssssssssssssssssssssssssssssssccccccccccceeeeeeeeee                                    uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuueeeeeeeeeeeeeeee  h,S"""""""""""""	T.................................................0iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiilllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1odranpppppppppppptcsummmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinddddddddddddacpppppppppppppppppppppttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee_===============================================================================================================================================<[WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+4xU3555555555555555555555555555555555555555555555555555555555555555555|||||||||||||||||||||||||||||||||||||>NCy]M%)/$fwgb2222222222222222222222vvvvvvvvvvvvvvvvvvvvvvvvvvvRPPPPPPPPPPPPPPPPPPPPPPPPPPPPEILLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLBSD::::::::::::::::::::::::AAAAAAAAAAAAAAAAAGTh,,,,,,,,,,,,,,,,,,,,,,,((((((((((((((((((((((((((((	"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""".o000000000000000000-ruuuuuuuuuuuuuuuuuuunllllllllllllicddddddddddddddddddddd1aaaaaaaaaaap                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrrrrrrrrrrrroclmiiiiiiiiiiiddddddddddddddaaaaaaaaeeeeeeeee                        sppppppppppppeeeeeeeeee             tttttttttttttttttttttttttttttttttttt	Th,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Suuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"n.00000000000000000000000000000000kcrmmmmmmmmmmmmmmmmmmmooooooooooollllllllllllllisdeeeeeeeeee        taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                pppppppppppppncr1ooooooooooollllllllllllllisdttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                       /vCy]M%)OOOOOOOOOOOOOOOOOOOOOOOOOOfwgb2222222222222222222222$$$$$$$$$$$$$$$$$$$$$$$RPPPPPPPPPPPPPPPPPPPPPPPPPPPPEILLLLLLLLLLLLLLLLLLLLLLLLLLLhhhhhhhhhhhhhhhhhhhhhhhhDDDDDDDDDDDDDDDDD:::::::::::::::::::::::::AAAAAAAAAAAAA	TTTTTTTTTTTTTTTTTTGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG,,,,,,,,,,,,,,,,,,,,,uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuSp".nm0rrrrrrrrrrrrocl1k(iiiiiiiiiiiddddddddddddddddddddaseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnopllllllllllllicdddddddddddddddddddaaaaaaaaaaattttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee	TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTThmmmmmmmmmmmmmmmmmmmmmu,rS"o1.lnipddddddddddddacttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirdnapttttttttttttsc                     -----------------------------------------------------------eeeeeeeee                                                       ������������������������������������������z�ʲ��������̴�������������`^�ҫZ��X���������������������������������������������������������������������?��Q����7����8�J����۸�;������������������������������������������������������������������'��� ���#���~��9


















































�����������������������������������������������KHV&*@jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\}F{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!_===============================================================================================================================================<[WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW6666666666666666666666666666666666666666)++++++++++++++++++++++++++++++++++xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx344444444444444444444444444444444444444U|5>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>vCy]M%/LLLLLLLLLLLLLLLLLLLLLLLLLLfwgb2OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOORPPPPPPPPPPPPPPPPPPPPPPPPPPPPEI$																																																																NDDDDDDDDDDDDDDDDDDDDDDDDDDD::::::::::::::::::::::::::::::::::::::::::kAuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuT1mmmmmmmmmmmmmmmmmmmmmhl,Siiiiiiiiiiiiiiiiiii"doartnsppppppppppppppppppppppppppppppppeeeeeeeee                                  cccccccccccceeeeeeeeee             -G....................................dialtosrrrrrrrrrrrrrrnnnnnnnnnnnpeeeeeeeeee        0000000000000000000000000000000000000000000000000000000000000000000000eeeeeeeeeeeeee                ccccccccccccccccccccccccccccuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu	111111111111111111111111111111111111111111111111111111111111111111111111111111111T,mmmmmmmmmmmmmmmmmmmh(Sdialtosrrrrrrrrrrrrrrnnnnnnnnnnnp0"""""""""""""""""""""""eeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                       icldoartnspppppppppppppppppppppppppppppppppppppppppeeeeeeeeee                                    ....................................eeeeeeeeeeeeeeee  %2222222222222222222222vCy]M)ILLLLLLLLLLLLLLLLLLLLLLLLLLfwgb/kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkRPPPPPPPPPPPPPPPPPPPPPPPPPPPPEOuBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB$D111111111111111111111111111-:,,,,,,,,,,,,,,,,,,,,																(AAAAAAAAAAAAAAAAAAAAATTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTimmmmmmmmmmmmmmmmmmml0hocrdnaptttttttttttts.SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrincpdddddddddddda"ttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                ee	111111111111111111111111111T,,,,,,,,,,,,,,,,,,,,u0GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooomr...................nlpiiiiiiiiiiiic"hddddddddddda                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrpoooooooooooolSiiiiiiiiiiiccccccccccccccddddddddeeeeeeeee                        saaaaaaaaaaaaeeeeeeeeee             ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt_===============================================================================================================================================<[;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;Mx+33333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333|4>UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU55555555555555555555555555555555555555555555555555555555555555555555b2222222222222222222222vCy]%EILLLLLLLLLLLLLLLLLLLLLLLLLLfwg)-kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkRPPPPPPPPPPPPPPPPPPPPPPPPPPPP///////////////////////////////////////BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB$$$$$$$$$$$$$$$$$OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO	1(DDDDDDDDDDDDDDDDDDDDDT,,,,,,,,,,,,,,,.0G:unnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnp"mmmmmmmmmmmmrSSSSSSSSSSSSSSSSSSSooooooooooollllllllllllllisceeeeeeeeee        tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aapnnnnnnnnnnnnrhooooooooooolllllllllllllliscttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                       ,,,,,,,,,,,,,,,,,,,,	1AAAAAAAAAAAAAAAAAAAAATTTTTTTTTTTTT".000000000000000auuuuuuuuuuuuuuuunSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSrpoooooooooooolhmiiiiiiiiiiiccccccccccccccccccccdseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoalpiiiiiiiiiiiicccccccccccccccccccdddddddddddttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee]gb2222222222222222222222vCyMMMMMMMMMMMMMMMMMMMMMMMMMMMMEILLLLLLLLLLLLLLLLLLLLLLLLLLfw%(-kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkRP)	$$$$$$$$$$$$$$$$$$$$$$$$$$$ON/////////////////T,,,,,,,,,,,,,,,,,,,,GGGGGGGGGGGGGGGGGGGGGGGG0ADDDDDDDDDDDDDDDDDDDDD1S".............rrrrrrrrrrrrrrruohhhhhhhhhhhhhhhhlniacpddddddddddddttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloircndatpssssssssssss                     mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmeeeeeeeee                                                                           T,,,,,,,,,,,,,,,,,,,,.0:	hS"1llllllllllllllllllllllllllliiiiiiiiiiiiiiiiiiiucodrtnsaaaaaaaaaaaaaappppppppeeeeeeeee                                                        eeeeeeeeee             mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmcidltosrrrrrrrrrrrrrrnnnnnnnnnnnaeeeeeeeeee                                                                    pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                                                                                                                 _HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH&K@VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV*jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj









































;FY\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\W}{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{!|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<[=Bx+333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333222222222222222222222222222222>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>U45ygb]IvCCCCCCCCCCCCCCCCCCCCCCwwwwwwwwwwwwwwwwwwwwwwwwwwwwEMkkkkkkkkkkkkkkkkkkkkkkkkkkfLP(-%OOOOOOOOOOOOOOOOOOOOOOORRRRRRRRRRRRRRRRRRG$$$$$$$$$$$$$$$$$$$$$$$$$$$)))))))))))))))))))))NNNNNNNNNNNNNNNNNNNNNNNNNNNNN/,AAAAAAAAAAAAAAAAA.T:::::::::::::::::::::::::::::::::::::::::::h0"													SSSSSSSSSSSSSSSSSSS1mmmmmmmmmmmmmmmcidltosrrrrrrrrrrrrrrnnnnnnnnnnnaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaauuuuuuuuuuuuuuuuuuuuuuueeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                       iiiiiiiiiiiilcodrtnsaaaaaaaaaaaaaaaaaaaapppppppppppeeeeeeeeee                                                                                      eeeeeeeeeeeeeeee  h,,,,,,,,,,,,,,,,,,,,,.............DDDDDDDDDDDDDDDDDDDDTm"	0iSSSSSSSSSSSSSSSSSSSlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1oooooooooooorcndatpsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssseeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinnnnnnnnnnnnacpduttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeCfygb]Iv2RwwwwwwwwwwwwwwwwwwwwwwwwwwwwEMkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkAP(-%OOOOOOOOOOOOOOOOOOOOOOOLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG$$$$$$$$$$$$$$$$$$))))))))))))))))))))h,:/													DDDDDDDDDDDDDDDDD.............................................................m"To0Srrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnlaippppppppppppu1cccccccccccd                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnraopllllllllllllllliiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicccccccceeeeeeeee                        sddddddddddddeeeeeeeeee             tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttth,"																																																																																																												m.nT0auSprrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllisssssssssssseeeeeeeeee        tccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                ddanpr1ooooooooooollllllllllllllissssssssssssttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  ceeeeeeeeeeeeeee                                       N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||<[v+BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333364>=UUUUUUUUUUUUUUUUUUUUUUUUUUfygb]ICCCCCCCCCCCCCCCCCCCCCCCRwwwwwwwwwwwwwwwwwwwwwwwwwwwwEMk2:AP(-%OOOOOOOOOOOOOOOOOOOOOOhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh55555555555555555555555555555555555555555555GL$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$)/DDDDDDDDDDDDDDDDDDDDm"	,uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuud.Tnnnnnnnnnnnnnnn0raopl1Siiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiicseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnodlaippppppppppppppppppppppppppppppcccccccccccttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee													hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhm""""""""""""""""""""""""""""""""""uuuuuuuuuuuuuuuu,rrrrrrrrrrrrrrrrrrrrr.o1Tlniddddddddddddacpttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirrrrrrrrrrrrncdtasp                     SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSeeeeeeeee                                                       Ikkkkkkkkkkkkkkkkkkkkkkkkkkfygb]vOOOOOOOOOOOOOOOOOOOOOOORwwwwwwwwwwwwwwwwwwwwwwwwwwwwEMCCCCCCCCCCCCCCCCCCCCCCCC:AP(-%2hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG"													/$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$mmmmmmmmmmmmmmmmm)111111111111111uuuuuuuuuuuuuuuuuuuul,,,,,,,,,,,,,,,,,,,,,iiiiiiiiiiiiiiiiiii............ocrtnsddddddddddddddaaaaaaaaeeeeeeeee                                  ppppppppppppeeeeeeeeee             STTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTicltosrrrrrrrrrrrrrrnnnnnnnnnnndeeeeeeeeee        0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeeeeeeeeee                pppppppppppppp""""""""""""""""	mh1111111111111111111111111111111111111111111111111111111111111uD,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSicltosrrrrrrrrrrrrrrnnnnnnnnnnnd0.......................eeeeeeeeeeeeeeeeeeeeeeeeee                  aeeeeeeeeeeeeeee                                       ipllllllllllllocrtnsddddddddddddddddddddaaaaaaaaaaaeeeeeeeeee                                    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTeeeeeeeeeeeeeeee  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<~999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@KVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV*
jFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWY\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\}{N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]++++++++++++++++++++++++++++++++++++++++++++++++++++++++++BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx344444444444444444444444444444444444444=6![>MkkkkkkkkkkkkkkkkkkkkkkkkkkfygbI%OOOOOOOOOOOOOOOOOOOOOOORwwwwwwwwwwwwwwwwwwwwwwwwwwwwEv////////////////////////:AP(-CCCCCCCCCCCCCCCCLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLU2222222222222222222222222221111111111111"""""""""""""""""G,mh	SuD$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiil00000000000000000000oprrrrrrrrrrrrncdtasTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTeeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinpddddddddddddac.ttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeh1111111111111"),mmmmmmmmmmmmmmmm0Su	ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooorTTTTTTTTTTTTTTTTTTTnldiap.........................................c                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrdoallllllllllllllllllllliiiiiiiiiiippppppppppppppppppppppppppppppppeeeeeeeee                        scccccccccccceeeeeeeeee             ttttttttttttttttttttttttttttttttttttbEMkkkkkkkkkkkkkkkkkkkkkkkkkkfyg]-%OOOOOOOOOOOOOOOOOOOOOOORwwwwwwwwwwwwwwwwwwwwwwwwwwwwIIIIIIIIIIIIIIIII////////////////////////:AP(vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvL222222222222222222C5mh1DDDDDDDDDDDDDDDDDDDDDDDDDDDu)G,"T0SSSSSSSSSSSSSSSSn																																																													d...............arrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllispeeeeeeeeee        tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeee                ccdnarrrrrrrrrrrrrrrrrrrrooooooooooollllllllllllllispttttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                             eeeeeeeeeeeeeee                                       ,mh1Su$$$$$$$$$$$$$.T0"cccccccccccccccc	nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnrdoalllllllllllllllllllllllllllllllllliiiiiiiiiiipppppppppppppppppppppppppppppppseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnocldiappppppppppppppppppppppppppppppppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeN;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg++++++++++++++++++++++++++++++++++++++++B4x=3[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<EMkkkkkkkkkkkkkkkkkkkkkkkkkkfyb(-%OOOOOOOOOOOOOOOOOOOOOOORw]DDDDDDDDDDDDDDDDD////////////////////////:APIh2222222222222222222222CLvvvvvvvvvvvvvvvvvv$5>>>>>>>>>>>>>>>>>>>>>>>>>>>)m,0Su111111111111111111111.TTTTTTTTTTTTTr""""""""""""""""oooooooooooooooooooo	lnicpddddddddddddattttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloirpnnnnnnnnnnnnctdsa                                                                                             eeeeeeeee                                                       uhGmT0S,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.1lllllllllllll"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiipoooooooooooortnsccccccccccccccddddddddeeeeeeeee                                  aaaaaaaaaaaaeeeeeeeeee                           																																				piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnnceeeeeeeeee                                                                    dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeeeeeeeeeeeeee                aaMyyyyyyyyyyyyyyyyyyyyyyyyyyyyEg%%%%%%%%%%%%%%%%%%%%%%%%%%fkw(-b///////////////////////ROPDDDDDDDDDDDDDDDDD]C:AAAAAAAAAAAAAAAAAAAAAAAA$2222222222222222222222IuLvGGGGGGGGGGGGGGGGGGUUUUUUUUUUUUUUUUUUUUUUUUUUUThSmmmmmmmmmmmmmmmmmmmm0.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,111111111111111"piiiiiiiiiiiiltosrrrrrrrrrrrrrrnnnnnnnnnnncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeeeeeeeeeeeeeee                  deeeeeeeeeeeeeee                                       ialpoooooooooooortnsccccccccccccccccccccdddddddddddeeeeeeeeee                                    																																				eeeeeeeeeeeeeeee                     u)TTTTTTTTTTTTTSmhhhhhhhhhhhhhhh.,0iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiilllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll1oarpnnnnnnnnnnnnctds	"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""eeeeeeeeeeeeeeeeeeee                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeolrinacpdddddddddddddddddddddddddddttttttttt                 seeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee&H@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@K
VF*Wj5555555555555555555555555555555555555555555555555555555555555555555555555555555555555555qYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||6{fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff4+=B[x<33333333333333333333333333333333333333333333333333333333333333333333RyyyyyyyyyyyyyyyyyyyyyyyyyyyyEg%%%%%%%%%%%%%%%%%%%%%%%%%%MAw(-b///////////////////////kGPDDDDDDDDDDDDDDDDD]C:O)$2222222222222222222222ILvvvvvvvvvvvvvvvvvvvvvvvvmmmmmmmmmmmmmmmmmmmmuuuuuuuuuuuuuuuuuuUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU,,,,,,,,,,,,,STTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT.ho000000000000000000000r																			nlcidaaaaaaaaaaaaaaaa1pppppppppppppppppppppp                     ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeee            ssssssssssssssssssssssssssssssssssnrcodl"iiiiiiiiiiiaaaaaaaaaaaaaappppppppeeeeeeeee                        ssssssssssssssssssssssseeeeeeeeee             ttttttttttttttttttttttttttttttttttttSmmmmmmmmmmmmmmmmmmmmu.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,																																																																											Tnh0ccccccccccccccccccccccccccccccccccccdr"""""""""""""""""""ooooooooooollllllllllllllisaeeeeeeeeee        tpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeeeeeeeeeeeeee                                      cndr1ooooooooooollllllllllllllisattttttttttttttttttttttteeeeeeeeeeeeeeeeeeeeeeeeee                  peeeeeeeeeeeeeee                                                                                      RyyyyyyyyyyyyyyyyyyyyyyyyyyyyEg%f:Aw(-b/MvGPDDDDDDDDDDDDDDDDD]Ckkkkkkkkkkkkkkkkkkkk2)I$OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOSmmmmmmmmmmmmmmmmmmLLLLLLLLLLLLLLL.,uuuuuuuuuuuuuuuu																																																																																																																									Thn"0rcodl111111111111111111111iiiiiiiiiiiaaaaaaaaaaaaaaaaaaaapseeeeeeeeee                                    tttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeee  rnoooooooooooolcidaaaaaaaaaaaaaaaaaaapppppppppppttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeeeeeeeeeeeeee       sssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,,,,,,,,,,,,,Smmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm....................""""""""""""""""	ur>To1hlniiiiiiiiiiiiacpdttttttttttttttttttt000000000       ssssssssssseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee                                                                eeloiranpppppppppppptcsd                                                                                                   eeeeeeeee                                                       U55555555555555555555555555555555555555555555555555555555555555555N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%4444444444444444444444444444444444444444444444444444444444==================================[+<BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx3///////////////////////RyyyyyyyyyyyyyyyyyyyyyyyyyyyyEggggggggggggggggggggggggggC:Aw(-bffffffffffffffffffvGPDDDDDDDDDDDDDDDDD]MSI2O)k$.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,																																																																											m1"""""""""""""""""""""""""""""""""""lu>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>LiiiiiiiiiiiiiiiiiiiTaoprtnssssssssssssssssssssssssscccccccceeeeeeeee                                  ddddddddddddeeeeeeeeee                                 hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhaipltosrrrrrrrrrrrrrrnnnnnnnnnnnnnnnnnnnnnneeeeeeeeee        0ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccceeeeeeeeeeeeee                dddddddddddddd.	,,