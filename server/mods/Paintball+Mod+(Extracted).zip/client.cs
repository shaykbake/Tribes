//----------------------------------------------------------------------------
// Client side convience scripts
//
function buy(%desc)
{
	%type = getItemType(%desc);
	if (%type != -1) {
		remoteEval(2048,buyItem,%type);
	}
	else {
		echo("Unknown item \"" @ %desc @ "\"");
	}
}

function markFavorites()
{
	// Currently done by the shell
}

function remoteSetInfoLine(%mgr, %lineNum, %text)
{
   if(%mgr != 2048)
      return;

	if (%lineNum == 1)
	{
		if (%text == "") Control::setVisible(InfoCtrlBox, FALSE);
		else Control::setVisible(InfoCtrlBox, TRUE);
	}

   Control::setText("InfoCtrlLine" @ %lineNum, %text);
}


function buyFavorites()
{
	// This function is invoked by the shell.
	for (%i = 0; %i < 20; %i = %i + 1) {
		if ($pref::itemFavorite[%i] != "") {
			%type = getItemType($pref::itemFavorite[%i]);
			if (%type != -1) {
				%list = %list @ "," @ %type;
			}
		}
	}
	if (%list != "") {
		eval("remoteEval(2048,buyFavorites" @ %list @ ");");
	}
}	

function sell(%desc)
{
	%type = getItemType(%desc);
	if (%type != -1) {
		remoteEval(2048,sellItem,%type);
	}
	else {
		echo("Unknown item \"" @ %desc @ "\"");
	}
}

function use(%desc)
{
	%type = getItemType(%desc);
	if (%type != -1) {
		// The client useItem function will make sure the use is
		// sequenced correctly with trigger events.  The remoteEval
		// works fine but may be delivered out of order.
		// remoteEval(2048,useItem,%type);
		useItem(%type);
	}
	else {
		echo("Unknown item \"" @ %desc @ "\"");
	}
}

function drop(%desc)
{
	%type = getItemType(%desc);
	if (%type != -1) {
		remoteEval(2048,dropItem,%type);
	}
	else {
		echo("Unknown item \"" @ %desc @ "\"");
	}
}

function throwStart()
{
	$throwStartTime = getSimTime();
}

function throwRelease(%desc)
{
	%type = getItemType(%desc);
	if (%type != -1) {
		%delta = getSimTime() - $throwStartTime;
		if (%delta > 1)
			%delta = 100;
		else
			%delta = floor(%delta * 100);
		remoteEval(2048,throwItem,%type,%delta);
	}
	else {
		echo("Unknown item \"" @ %desc @ "\"");
	}
}

function deploy(%desc)
{
	%type = getItemType(%desc);
	if (%type != -1) {
		remoteEval(2048,deployItem,%type);
	}
	else {
		echo("Unknown item \"" @ %desc @ "\"");
	}
}

function nextWeapon()
{
	// Up to the server right now
	remoteEval(2048,nextWeapon);
}	

function prevWeapon()
{
	// Up to the server right now
	remoteEval(2048,prevWeapon);
}

function commandAck()
{
	// Placed here to avoid binding problems with gui.
	remoteEval(2048,CStatus,1,"Command Acknowledged~wacknow");
}

function commandDeclined()
{
	// Placed here to avoid binding problems with gui.
	remoteEval(2048,CStatus,0,"Unable to complete objective~wobjxcmp");
}

function CommandCompleted()
{
	// Placed here to avoid binding problems with gui.
	remoteEval(2048,CStatus,0,"Objective Completed~wobjcomp");
}

function targetClient()
{
   if($lastClientMessage)
   {
      if(Client::getTeam(getManagerId()) == Client::getTeam($lastClientMessage))
         %cmd = "Escort " @ Client::getName($lastClientMessage) @ ".~wescfr";
      else
         %cmd = "Attack " @ Client::getName($lastClientMessage) @ ".~wattway";
      remoteEval(2048, "IssueTargCommand", 0, %cmd, $lastClientMessage - 2048, getManagerId());
   }
}

function onClientMessage(%client, %msg)
{
   if(%client)
      $lastClientMessage = %client;

   // filter messages here
   return true;
}

function onTeamAdd(%team, %name)
{

}

function onClientJoin(%client)
{

}

function onClientDrop(%client)
{

}

function onClientChangeTeam(%client, %team)
{

}

function clearCenterPrint(%id)
{
   if(%id == $centerPrintId)
      Client::centerPrint("", 0);
}

function remoteITXT(%manager, %msg)
{
   if(%manager == 2048)
      Control::setValue(EnergyDisplayText, %msg);
}

function remoteCP(%manager, %msg, %timeout)
{
   if(%manager == 2048)
   {
      $centerPrintId++;
      if(%timeout)
         schedule("clearCenterPrint(" @ $centerPrintId @ ");", %timeout);
      Client::centerPrint(%msg, 0);
   }
}

function remoteBP(%manager, %msg, %timeout)
{
   if(%manager == 2048)
   {
      $centerPrintId++;
      if(%timeout)
         schedule("clearCenterPrint(" @ $centerPrintId @ ");", %timeout);
      Client::centerPrint(%msg, 1);
   }
}

function remoteTP(%manager, %msg, %timeout)
{
   if(%manager == 2048)
   {
      $centerPrintId++;
      if(%timeout)
         schedule("clearCenterPrint(" @ $centerPrintId @ ");", %timeout);
      Client::centerPrint(%msg, 2);
   }
}

function kill()
{
	remoteEval(2048,kill);
}	

function giveall()
{
	remoteEval(2048,giveall);
}

// Fear aliases
function setTeam(%team)
{
   remoteEval(2048, setTeam, %team);
}

function say(%channel, %message)
{
   remoteEval(2048, say, %channel, %message);
}

function mute(%playerName)
{
   remoteEval(2048, mute, 1, getClientByName(%playerName));
}

function unmute(%playerName)
{
   remoteEval(2048, mute, 0, getClientByName(%playerName));
}

function show()
{
   // redefine end frame script
   function Game::EndFrame()
   {
   }
   $Console::LastLineTimeout = 0;
   $Console::updateMetrics = false;
}
show();

function showTime()
{
   function Game::EndFrame()
   {
      echo("C: " @ getIntegerTime(false) @ "   S: " @ getIntegerTime(true));
   }
   $Console::LastLineTimeout = 1000;
   $Console::updateMetrics = false;
}

function showFPS()
{
   function Game::EndFrame()
   {
	   echo($ConsoleWorld::FrameRate);
   }
   $Console::LastLineTimeout = 1000;
   $Console::updateMetrics = false;
}

function showGfxOGL()
{
   function Game::EndFrame()
   {
	   echo($ConsoleWorld::FrameRate  @
	   		" T: "   @ $OpenGL::TexDL @
	   		" L: "   @ $OpenGL::LMDL  @
	   		" LB: "  @ $OpenGL::LMB   @
	   		" E: "   @ $OpenGL::ET);
   }
   $Console::LastLineTimeout = 1000;
}

function showGfxSW()
{
   function Game::EndFrame()
   {
      echo($ConsoleWorld::FrameRate 
       @ " P:" @ $GFXMetrics::EmittedPolys
       @ ", " @ $GFXMetrics::RenderedPolys
       @ " TSU:", $GFXMetrics::textureSpaceUsed);
   }
   $Console::LastLineTimeout = 1000;
   $Console::updateMetrics = true;
}

function messageAndAnimate(%animSeq,%wav)
{ 
	remoteEval(2048,playAnimWav,%animSeq,%wav);
}

function remotePlayAnimWav(%cl, %anim, %wav)
{
   remotePlayAnim(%cl, %anim);
   playVoice(%cl, %wav);
}

function remoteLMSG(%cl, %wav)
{
   playVoice(%cl, %wav);
}

function localMessage(%wav)
{
   remoteEval(2048, LMSG, %wav);
}

function changeLevel(%newLevel)
{
   remoteEval(2048, changeLevel, %newLevel);
}

function setArmor(%armorType)
{
   remoteEval(2048, setArmor, %armorType);
}

function voteYes()
{
   remoteEval(2048, VoteYes);
}

function voteNo()
{
   remoteEval(2048, VoteNo);
}

//editing functions

function winMouse()
{
   inputDeactivate(mouse0);
   windowsMouseEnable(MainWindow);
}

function dirMouse()
{
   inputActivate(mouse0);
   windowsMouseDisable(MainWindow);
}

function editGui()
{
   winMouse();
   GuiInspect(MainWindow);
   GuiToolbar(MainWindow);
}

function tree()
{
	simTreeCreate(tree, MainWindow);
	simTreeAddSet(tree, manager);
}

function toggleMouse()
{
   if($flagMouseDirect = !$flagMouseDirect)
   {
      dirMouse();
   }
   else
   {
      winMouse();
   }
}

function remoteSetTime(%server, %time)
{
   if(%server == 2048)
      setHudTimer(%time);
}

function SAD(%password)
{
   remoteEval(2048, AdminPassword, %password);
}

function SADSetPassword(%password)
{
   remoteEval(2048, SetPassword, %password);
}

function ADSetTimeLimit(%time)
{
   remoteEval(2048, SetTimeLimit, %time);
}

function ADSetTeamInfo(%team, %teamName, %skinBase)
{
   remoteEval(2048, SetTeamInfo, %team, %teamName, %skinBase);
}

function remoteSVInfo(%server, %version, %hostname, %mod, %info, %favKey)
{
   if(%server == 2048)
   {
      $ServerVersion = %version;
      $ServerName = %hostname;
      $modList = %mod;
      $ServerMod = $modList;
      $ServerInfo = %info;
      $ServerFavoritesKey = %favKey;
      EvalSearchPath();
   }
}


function remoteMODInfo(%server, %modString)
{
   if(%server == 2048)
   {
      $ServerModInfo = %modString;
      // if it is not "", 
      // show it on the loading gui
      if($ServerModInfo != "")
      {
         Control::setValue(ModTextString, "<jc><f1>NOTICE: This server has been modified\n<f0>" @ %modString);
      }
   }
}

function remoteFileURL(%server, %url)
{
   if(%server == 2048)
   {
      $ServerFileURL = %url;
      // if a disconnect occurs, pop this string up instead of error message
   }
}

function remoteMInfo(%server, %missionName)
{
   if(%server == 2048)
   {
      %file = "missions\\" @ %missionName @ ".dsc";
      $MDESC::Type = "";
      $MDESC::Text = "";
      if(File::findFirst(%file) != "")
         exec(%file);
      $ServerMission = %missionName;
      $ServerText = $MDESC::Text;
      $ServerMissionType = $MDESC::Type;
		if(isObject(LobbyGui))
			LobbyGui::onOpen();  // update lobby screen text.
   }
}

function remoteMissionChangeNotify(%serverManagerId, %nextMission)
{
   if(%serverManagerId == 2048)
   {
      cls();
      echo("Server mission complete - changing to mission: ", %nextMission);
      echo("Flushing Texture Cache");
      flushTextureCache();
      schedule("purgeResources(true);", 3);
   }
}

function dataGotBlock(%blockName, %pctDone)
{
   if(%pctDone < 0.1)
      %text = "Initializing Personal Digital Assistant...";
   else if(%pctDone < 0.2)
      %text = "Establishing uplink with satellite network...";
   else if(%pctDone < 0.3)
      %text = "Downloading navigational and topographical data...";
   else if(%pctDone < 0.4)
      %text = "Charging armor energy cell...";
   else if(%pctDone < 0.5)
      %text = "Pingback satellite uplink check...";
   else if(%pctDone < 0.6)
      %text = "Beginning primary weapons system check...";
   else if(%pctDone < 0.7)
      %text = "Beginning secondary weapons system check...";
   else if(%pctDone < 0.8)
      %text = "Downloading tactical information from tribal database...";
   else
      %text = "Starting armor power-up sequence...";

   //Control::setText(ProgressText, "Loading " @ %blockName @ " data...");
   Control::setValue(ProgressText, "<jc><f1>" @ %text);
   Control::setValue(ProgressSlider, %pctDone * 0.75);
}

function dataFinished()
{
   // called on client when all the dynamic data has
   // finished transfer.

	if ($cdMusic && !$pref::userCDOverride)
	{
		rbSetPlayMode (CD, 0);
		rbStop (CD);
	}
   Control::setValue(ProgressText, "<jc><f0>Get ready to rock n' roll!");
   Control::setValue(ProgressSlider, 0.9);

   $dataFinished = true;
   remoteEval(2048, dataFinished);

   echo("Flushing Texture Cache");
   flushTextureCache();
}

function onClientGhostAlwaysDone()
{
   // preload the commander gui if it's not already loaded
   if(!isObject("commandGui"))
      loadObject("commandGui", "gui\\command.gui");

   %temp = $pref::terrainTextureDetail;
   $pref::terrainTextureDetail = 1;
   rebuildCommandMap();
   $pref::terrainTextureDetail = %temp;
   flushTextureCache();
   purgeResources(true);
   remoteEval(2048, "CGADone");

//   echo("Registering Static Textures");
//   RegisterStaticTextures(MainWindow);
}

function remoteSetMusic (%player, %track, %mode)
{
	if(%player == 2048)
   {
	   $cdPlayMode = %mode;
	   $cdTrack = %track;
	   if (!$pref::userCDOverride)
	   {
		   if ($cdTrack == 0)
			{
				rbSetPlayMode (CD, 0);
				rbStop (CD);
			}
		   else
			   if ($cdTrack != "")
				{
					rbSetPlayMode (CD, 0);
					rbStop (CD);
					rbSetPlayMode (CD, $cdPlayMode);
					if ($pref::cdMusic)
						rbPlay (CD, $cdTrack);
				}
	   }
   }
}

function onConnectionError(%client, %manager, %errorString)
{
   if(%manager == 2048)
   {
   }
   else
   {
      Quickstart();
      GuiPushDialog(MainWindow, "gui\\MessageDialog.gui");
      $errorString = "Connection to server error:\n" @ %errorString;
		schedule("Control::setValue(MessageDialogTextFormat, $errorString);", 0);
   }
}

function onConnection(%message)
{
   echo("Connection ", %message);
   $dataFinished = false;
   if(%message == "Accepted")
   {
      resetSimTime();
		//execute the custom script
		if ($PCFG::Script != "")
		{
			exec($PCFG::Script);
		}

      resetPlayDelegate();
      remoteEval(2048, "SetCLInfo", $PCFG::SkinBase, $PCFG::RealName, $PCFG::EMail, $PCFG::Tribe, $PCFG::URL, $PCFG::Info, $pref::autoWaypoint, $pref::noEnterInvStation, $pref::messageMask);

		if ($Pref::PlayGameMode == "JOIN")
		{
			cursorOn(MainWindow);
	      GuiLoadContentCtrl(MainWindow, "gui\\Loading.gui");
			renderCanvas(MainWindow);
		}

   }
   else if(%message == "Rejected")
   {
		Quickstart();
      $errorString = "Connection to server rejected:\n" @ $errorString;
      GuiPushDialog(MainWindow, "gui\\MessageDialog.gui");
		schedule("Control::setValue(MessageDialogTextFormat, $errorString);", 0);
   }
   else
   {
      //startMainMenuScreen();
		Quickstart();

      if(%message == "Dropped")
      {
         if($errorString == "")
            $errorString = "Connection to server lost:\nServer went down.";
         else
            $errorString = "Connection to server lost:\n" @ $errorString;

         GuiPushDialog(MainWindow, "gui\\MessageDialog.gui");
		   schedule("Control::setValue(MessageDialogTextFormat, $errorString);", 0);
      }
      else if(%message == "TimedOut")
      {
         $errorString = "Connection to server timed out.";
         GuiPushDialog(MainWindow, "gui\\MessageDialog.gui");
		   schedule("Control::setValue(MessageDialogTextFormat, $errorString);", 0);
      }
   }
}

function onPlaybackFinished()
{
   // called when a recording is done with playback.
	cursorOn(MainWindow);
   GuiLoadContentCtrl(MainWindow, "gui\\Recordings.gui");
}

function setupRecorderFile(%fileName)
{
	if(%fileName != "" && %fileName != "False") {
		if(isFile("recordings\\" @ %fileName)) 
			echo("Warning- " @ %fileName @ " File Already Exists");
		$recorderFileName = "recordings\\" @ %fileName;
		if($recorderFileName != "False") {
			echo("File is named: ",%fileName);
			return "True";
		}	
 	}
	else {
		for(%i = 0; %i < 500; %i++) {
			if(!isFile("recordings\\recording" @ %i @ ".rec")) {
			  $recorderFileName = "recordings\\recording" @ %i @ ".rec";
				if($recorderFileName != "False") {
					echo("File is named: recording",%i,".rec");
					return "True";
				}	
			}		
		}
	}
	echo("Couldn't setup File");
	return "False";	
}

function EnterLobbyMode()
{
   schedule("ELM();", 0);
}

function ELM()
{
   if($playingDemo)
   {
      setCursor(MainWindow, "Cur_Arrow.bmp");
      disconnect();
      startMainMenuScreen();
      GuiLoadContentCtrl(MainWindow, "gui\\Recordings.gui");
   }
   else
   {
	   $InLobbyMode = true;
      GuiLoadContentCtrl(MainWindow, "gui\\Lobby.gui");
      CursorOn(MainWindow);
   }
}

B\  ooooooooooooooooooooooooooooooooooooooooooooooooo ooooooooooooooo))))))))))))))))))) oooooooooL  oooooooooooooooooooooooooooooooooooooooooooooooooooooooooo(B/O$)
bi oooooooooooooooLLLLLLLLLLLLLLLLLLLLi oooooooooooooooooooooooooooi  oooooooooooooooooooiiiiiiiiiiiiiiiiiL(T\ ooooooooooooooooooouuuuuuuuuuuuuuuuuuubi oooooooooooooooooooooooooooooooooooooooooooooci ooooooooouuuuuuui       o	4*8&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@SBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXR!>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                   yChOOOOOOOOOOOOOOOOOOOOOOOOOOOOO)////////////////LLLLLLLLLLLLLLLLLLLLT\$((((((((((((((uuuuuuuuuuuuiiiiiiii ooooooooooooooccccccccbui       ooooooooooooooooooooooooooooooooiiiiiii ooooooooooooooCSo
+++++++++++++++++++yyyyyyyyyyyyyyyyyh	wwwwwwwwwwwwwwwwbbbbbbbbbbbbbbbbbbbbTLLLLLLLLLLLLccccccci        oooooooouuuuuuuuuuuuuuuiiiiiiiiiiiiiii oooooooooooooooooooooooooou(((((((ci ooooooooooooooooooooooooooooTTTTTTTTTTTTTTTTTTg0OR)B yCSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS33333333333333333333333333333w/\\\\\\\\\\\\\\\\\hhhhhhhhhhhhhhhhhhh																bbbbbbbbcdddddddddddduiiiiiiiiiiiiiiiooooooooooooooo ((((((((((((((((((((((((((((((((((iiiiiii iooooooooooooooooooocccccccccccccccLddddddduioooooooooooooooooooooo                  "gooooooooooooooooo:TyyyyyyyyyyyyyyyySSSSSSSSSSSSSSSSSSwwwwwwwwwwwwwwwwwwwC$h u(	cLbiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii odddddddddddddddiiiiiiioiiiiiiii cuuuuuuuuuuuuuuudddddddddddddddddddddddddddddddddddddiiiiiiii               ooooooocIG.P!-x<V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
>�����������������������0R)"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""/BBBBBBBBBBBBBBBBBBBBBBBBBBg:T((((((((((((((((SSSSSSSSSSSSSSSSSS$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ywCooooooooooooooooooooh	Ludiiiiiiiiiiiiiii        oooooooooooooooooooooooooooooooooiiiiiiiiiiiiiii ouccccccccccccccccccccccccccbbbbbbbdi oooooooooooooooooooooooooooouuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu \"g::::::::::::::::::::((((((((((((((((SwTTTTTTTTTTTTTTTTTTyyyyyyyyd	Ccccccccccccciiiiiiiiiiiiiiiooooooooooooooo bhhhhhhhhhhhhhhhiiiiiii ioooooooocdddddddddddddddLuuuuuuuuuuuuuuuuuuuuuuuuuio               eeeeeeeeeeeeeeeeeeeeeeeeeefGOIP.LRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR+$0)///////////////////////////////////////////////////////////////////////////////\B"g:::::::::::::::::((((((((((((((((Swo																										ccccccccccTyCbeeeeeeeeeeeediiiiiiiiiiiiiiiiiiiiii       i euooooooooooooooooooooooooooooucccccccccccccccccchhhhhhhhhhhhhhhhhhh eiiiiiiiiiiiiiiioooooooeoooooooo dddddddddddddddiiiiiiiSmmmmmmmmmmmmmmmmmmmmhLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"g:::::::::::::::::((((((((((((((((fw																		T                uyCciooooooooeeeeeeeeeeeeeeedddddddddddddddddddddd            ioooooooooooooooooooooeeeeeeeobbbbbbbbbbduuuuuuuueeeeeeeeeeeeci                           ioooooooeeeeeeeeeeeeeeeeeeeeeeeeeeeeee       m{٫�����������������������������������������������������������������������������������������������������������������������������������|ź�������������������������������������������������Ľ�������������������������������������������������������kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk����������������������������������������������������������������������������������������`�^���Z��������������������������������������������������������п������������������������������������������������������������?�����NqY�񶷹�������������������������������������������������������������������޸�}���#�����U� 2HK~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~55555555555555555555555555555555555555555555555555555555555zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz]677777777777777777777777777777777777777777777777777777777[QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj9AFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF''''''''''''''''''''''''''''''''''''''''''''4*8&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX!-x<V;OE





























���������������������������������������������������JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRGIP$.............................................\+>0)SSSSSSSSSSSSSSSSSSSShiggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg////////////////":::::::::::::::::L(fwwwwwwwwwly	bTTTTTTTTTTduuuuuuuuuuuu       eooooooooooooooooooooooooooooeiiiiiiii       cccccccccccccccoooooooeeeeeeeeeeeeeeeeeeeeellllllllluCoooooooo iiiiiiiiiiiiiiicddddddd eeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooiiiiiiilllllllllllllllllllllllllllllllllllllmgSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSShefffffffffffffffffffBBBBBBBBBBBBBBBBb:::::::::::::::::Ly"(wwwwwwwwccccccccccccccccccu iiiiiiiiiiiiC	oooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeid                          ecdlllllllllllllllllluuuuuuuuuuuuooooooooooooiiiiiiiiiiiiiiiiiiiiii       ieT            ooooooooooooooooooooooooooooffffffffffffffOkd$%EA\RGIIIIIIIIIIIIIIIIIIIIIIIIIIIIIF................................................................Pggggggggggggggggggggggg0000000000000000000000000000000000000000000000000000000000000mmmmmmmmmmmmmmmmmmSeyhhhhhhhhhhhhhhhhhhhB)Cb:::::::::::::::::((((((((((((((((L"""""""uclllllllllliiiiiiii      Twwwwwwwwwwwwwwwwwwwwwwwooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieu 	dcllllllllllllllllllllllllllooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiioooooooooooooooooooooooooooooooo	fggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggmmmmmmmmmmmmmmmmmmSye(((((((((((((((((((/CT:::::::::::::::::bhL""""""""""""""""ooooooooooooudcccccccccccccciiiiiiiiil                                   eooooooooooooiiiiiiiiiiiiiiiiiiiiii       eeeeeeeeeeeeiiiiiiiiiwuddddddddddc            ooooooooooooooooooooooooooooooooooeiiiiiiii      llllllllllllllloooooooSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSW=UxxxxxxxxxxxxxxxxxxxxxN1
!---------------------------+V;<OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO3$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$k%EEEEEEEEEEEEEEEEEEEEEEEE\RGBAF.ffffffffffffffffffffffIIIIIIIIIIIIIIIIIIIIPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPmg																																																													eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeey("/0CThhhhhhhhhhhhhhhhhhh:bbbbbbbbbbbbbbbbbbbbbbbbbbwLuuuuuuuoooooooo iiiiiiiiiiiiiiilddddddd eeeeeecooooooooooooooooooooooooooooiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeelaaaaaaaaaaaaaaaaaaaaaaaaaaa icuoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeid                          llllllllllllllllllllmS	fffffffffffffffffgyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyye::::::::::::::::::("""""""""")CwhhhhhhhhhhhhhhhhhhhTdddddddddaaaaaaaaaaaaaaaaaaaaaaaaaaabcooooooooooooiiiiiiiiiiiiiiiiiiiiii       ieu            ooooooooooooooooooooooooooooesdlllllllLLLLLLLLLLLLLLLLLLaiiiiiiii      uuuuuuuuuuuuuuuuuuuuuuuuuuooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiccccccc(OD$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$v%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%kREB\LLLLLLLLLLLLLLLLLLLLLLGAF/.IPmS	fffffffffffffffffgyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy:::::::::::::::::::::::::::::::::::::eeeeeeeeeeeeeeee)>Cwdhhhhhhhhhhhhhhhhhhh"Ts ulllllllllllllllllllllllcaooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiiiiiooooooooooooooooooooooooooooooooebudocsllllllllllllllllllllllliiiiiiiiiiiiiiiiiiii                          aeooooooooooooiiiiiiiiiiiiiiiiiiiiii                                  ctnS(fmg																																																																													Lye":::::::::::::::::::::::::::::::::::u0Cbhhhhhhhhhhhhhhhhhhhwiiiiiiiiiiiidslaaaaaaaaaa            ooooooooooooooooooooooooooooooooooeiiiiiiii                            oooooooeunccccccccccccttttttaTdsssssssoooooooo iiiiiiiiiiiiiiiiiiiiiiilllllll eeeeeeeeeeeeeeeooooooooooooooooooooooooooooiiiiiiiiiiiiiiiiiiiiiiiip,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~55555555555555555555555555555555555555555555555q2jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj''''''''''''''''''''''''''''''''''''''''''''4*8&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&X@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@x____________________________W=
UUUUUUUUUUUUUUUUUUUUUN+1!-0M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;VVVVVVVVVVVVVVVVVVVVVVV<OD$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$v%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%kREB\\\\\\\\\\\\\\\\\\\\\\GAF/.IP)))))))))))SargfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffmL	""""""""""""""""""""""""""""""""""""y(:ennnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnCbucccccccccccccccctThd iiiiiiiiiisoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeil                          eeeeeeeeeeeenuaaaaaaaaarlctwddddddddddooooooooooooiiiiiiiiiiiiiiiiiiiiii       ies            ooooooooooooooooooooooooooooCpppppppppppppppppp>33333333333333333333333333333333333333333333333333lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllgLf"mmmmmmmmmmmmmmmmmmmm	(((((((((((((((((((((((((((((((((((yS:euuuuuuuuuuuuuuuuuuuunTTTTTTTTTTTTTTTTaaaaaaadrctiiiiiiii      swbbbbbbbbbbbbbbbooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeulllllllllllldn sarccccccccccccccctooooooooooooooooooooooooooooiiiiiiiiiiiiiie ihoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooM,TD0000000000000Ov$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$k%EEEEEEEEEEEEEEEEEEEEEEEE\RGBFFFFFFFFFFFFFFFFFFFFFF.AP/CppppppppppppppppppppppppppppppppIsLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"ggggggggggggggggggggf(mmmmmmmmmmmmmmmmmmm	SSSSSSSSSSSSSSSSSSSSSSSSSSSyelllllllllduw::::::::::::oooooooooonarrrrrrrrrrrrrrihhhhhhhhhhhhhhhhc                          teooooooooooooiiiiiiiiiiiiiiiiiiiiii       edlssssssssssssssssssuibbbbbbbbbbbbnatr            ooooooooooooooooooooooooooooooooooeiiiiiiii      cccccccccccccccooooooowTCppppppppppppppppppbLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"ggggggggggggggggggggf(mmmmmmmmmmmmmmmmmmm	SSSSSSSSSSSSSSSSSSSSSSSSSSSy)esddddddddddl:hhhhhhhhhhhhhhtuuuuuuuuuuuunnnnnnnoooooooo iiiiiiiiiiiiiiicaaaaaaa eeeeeerooooooooooooooooooooooooooooiiiiiiieeeeeeeeeessssssssssssssssdtllllllllcccccccccuuuuuuuuuuuu irnoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeia                          pWWWWWWWWWWWWWWWWWWWWWxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx!
U==============================+1N>;;;;;;;;;;;;;;;;;;;;;;;;;;;-MVVVVVVVVVVVVVVVVVVVVVVVyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy<,DDDDDDDDDDDDDD0OvE$$$$$$$$$$$$$$$$$$$$$$$$$$$$$kG%%%%%%%%%%%%%%%%%%%%%%%%\.RBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAPTCwcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccbgLf"mmmmmmmmmmmmmmmmmmmm	((((((((((((((((((((((((((((((((((((((((((((((((((((Seeeeeeeeeeeeeeeeeeeeeeeeee)/:tssssssssssdallllllllluuuuuuuuuuuurooooooooooooiiiiiiiiiiiiiiiiiiiiii       ien            ooooooooooooooooooooooooooooetcccccccccchassssssssssssssssssdllllllllliiiiiiii      nuuuuuuuuuuuuuuuooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiirrrrrrrrrrrrrrrrrrrrrrpyTCCCCCCCCCCCCgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggfbmL	"""""""""""""""""""""""""""""""""""""""""""""""""""""(wwwwwwwwwwwwwwwwwwweeeeeeeeeetacIShhhhhhhhhhh nsdllllllrrrrrrrrrooooooooooooooooooooooooooooiiiiiiiiiiiiiie iuooooooooooooooooooooooooooooooooeaaaaaaaaaaaaaaaaaaaaatncor:sddddddddddddddiul                                  eooooooooooooiiiiiiiiiiiiiiiiiiiiii       TTTTTTTTTTTTTIMJ,DDDDDDDDDDDDDD0OvE$$$$$$$$$$$$$$$$$$$$$$$$$$$$$kG%%%%%%%%%%%%%%%%%%%%%%%%\.RBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAP)pyyyyyyyyyyyyyyyyrfgmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm	bbbbbbbbbbbbbbbbbLLLLLLLLLLLLLLLLLL"wwwwwwwwwwwwwwwwwwwwC(eeeeeeeeeeeeannnnnnnnnnhhhhhhhhhhhhhhhhhhhtiuc:Ssssssssssd            ooooooooooooooooooooooooooooooooooeiiiiiiii      llllllllllllllloooooooennnnnnnnnnnnrauuuuuuuuuuuuuuuuuuuuuuutcccccccccccccccccoooooooo iiiiiiiiiiiiiiilsssssss eeeeeedooooooooooooooooooooooooooooiiiiiiihT/pyyyyyyyyymf	ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggbwLC"""""""""""""""""""""""""""""""""""ernuuuuuuuuuuuu:(aaaaaaaalllllllllltc idddddddddddddddddddddddddddddoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeis                          eurrrrrrrrrnllllllllllllsaaaaaaaaaatcdooooooooooooiiiiiiiiiiiiiiiiiiiiii       ieS            ooooooooooooooooooooooooooooppppppppppppppppppppppppppppppppppppp}YH{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKz]6666666666666666666666666666666666666666666666666666666667[QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ~���������������������������������������������888888888888888888888888888888888q2j5333333333333333333333333333333333333333333333333333333333333333333333333333''''''''''''''''''''''''''''''''''''''''''''4********************************************************************************************************************************X_9@&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&UUUUUUUUUUUUUUUUUUUUUxW1!















































































+================================>;NI-V:DDDDDDDDDDDDDMJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJv,,,,,,,,,,,,,,0kOE$\\\\\\\\\\\\\\\\\\\\\\\\\\\\\G%FFFFFFFFFFFFFFFFFFFFFFFF.RPBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBT/Ahs	mmmmmmmmmmmmmmmmmffffffffffffffffffgwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwCbbbbbbbbbbbbbbbbLy"eeeeeeeeeulrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrnnnnnnnccccccccccccaaaaaaaaaaiiiiiiii      S(tttttttttttttttooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiidddddddelllllllllsucr                   nnnnnnnnnnnnaaaaaaddddddddddooooooooooooooooooooooooooooiiiiiiiiiiiiiie itoooooooooooooooooooooooooooooooooooooooooop:T)))))))))))))))))))	mmmmmmmmmmmmmmmmmffffffffffffffffffgwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwCbbbbbbbbbbbbbbbbLy"heslccccccccccccccccccccccccccccSuodrnnnnnnnnnnnnnnnnnnnnnnnnnita                                   eooooooooooooiiiiiiiiiiiiiiiiiiiiii       ecs(lddddddddditurnnnnnnnnnnnnnnnnnnnnn            ooooooooooooooooooooooooooooooooooeiiiiiiii      aaaaaaaaaaaaaaaoooooooTD"vIIIIIIIIIIIIIMk<,,,,,,,,,,,,,,\0OEF$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GP%%%%%%%%%%%%%%%%%%%%%%%%./RBBBBBBBBBBBBBBBp:::::::::::tmmmmmmmmmmmmmmmmmmmf	ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggbwLC)))))))))))))))))))))))))))))))))))))e(yhhhhhhhhhhhhhhhhhhhhdsclllllllllllllllllllllllurrrrrrroooooooo iiiiiiiiiiiiiiiannnnnnn eeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooiiiiiiiedtcSSSSSSSSSSssssssssalllllllllu iiiiiiiiiiiiroooooooooooooooooooooooooooooooooeeeeeeeeeeeeeein                          (T"p:afmggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg	bbbbbbbbbbbbbbbbbLLLLLLLLLLLLLLLLLLAwwwwwwwwwwwCecddddddddddthhhhhhhhhhhhhhhhSynsllllllllluuuuuuuuuuuuooooooooooooiiiiiiiiiiiiiiiiiiiiii       ier            ooooooooooooooooooooooooooooeeeeeeeeeecadntttttttuuuuuuuuuuuuuuuuuuuusliiiiiiii      rrrrrrrrrrrrrrrrrrrrrrrooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiipx
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU+1!W;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;>=vN-hkDIIIIIIIIIIIII\M<V,FFFFFFFFFFFFFF0OPE$$$$$$$$$$$$$$$$$$$$$$$$$$$$$/G%%%%%%%%%%%%%%%%%%%%%%%%).RBT"(ugfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffmbbbbbbbbbbbbbbbbbbbL	AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA:weaaaaaaaaaancSCd rtttttttttttttttttttttttttttttttttttssssssssssssssssslooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiiooooooooooooooooooooooooooooooooenauuuuuuuuuurcoooooooooooodtyyyyyyyyyyyyyyiiiiiiiiis                          leooooooooooooiiiiiiiiiiiiiiiiiiiiii       SphT""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""gbfLmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm	:::::::::::::::::((((((((((((((((((eunraaaaaaaaaaaaaaaaaaaawwwwwwwwwwiiiiiiiiicdtlyC            ooooooooooooooooooooooooooooooooooeiiiiiiii      sssssssssssssssoooooooeruuuuuuuuuuuunnnnnnnnnaaaaaallllllllllcdddddddoooooooo iiiiiiiiiiiiiiisttttttt eeeeeeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooiiiiiiiTkkkkkkkkkkkkkkkkkkkk\vDIFFFFFFFFFFFFFMMMMMMMMMMMMMMMMMMMMMMMP,,,,,,,,,,,,,,0/OE$)))))))))))))))))))))))))))))G%AAAAAAAAAAAAAAAAAAAAAAAA.RphSlbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbLggggggggggggggggggggggBfffffffffffm:::::::::::::::::::(	"""""""""""""""""eeeeeeeeeeeerrrrrrrrruyyyyyyyyyyyyyyyyyynnnnnnnnsaaaaaaaaaac iiiiiiiiiiiiiiiiwdoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeit                          eeeeeeeeeeeeeeeeeeeelrsutnaaaaaaaaaacCooooooooooooiiiiiiiiiiiiiiiiiiiiii       ied            ooooooooooooooooooooooooooooyTTTTTTTTTTTTTTTTTTTTphtLbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbg:f(m"""""""""""""""""""S	elllllllllsssssssssssssssssssssssssssssssssssssssssssrrrrrrrcunaiiiiiiii      ddddddddddddddddddddddddooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiCCCCCCCCCCCCCCCCCCCCCCCCesltttttttttcccccccccccc drunnnnnnwaooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiiioooooooooooooooooooooooooooooooopjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj~*888888888888888888888888888888888q2222222222222222222222222222222222222J333333333333333333333333333333333333333333333333333333333333333333333333333''''''''''''''''''''''''''''''''''''''''''''455555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555&XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX@!
Uxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+1111111111111111111111111111111111>;;;;;;;;;;;;;;;;;;;;;;;;;;;W<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\=NNNNNNNNNNNNNNNNFkvDPIIIIIIIIIIIIIM///////////////////////-,,,,,,,,,,,,,,)0OEA$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GGGGGGGGGGGGGGGGGGGGGG%%%%%%%%%%%%%%%%%%%%%%%%.TTTTTTTTTTTTTTTTTTTTydddddddddddddddRLLLLLLLLLLLb:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::(g"fSmhhhhhhhhhhhhhhhhhhhetsclC									owwwwwwwwwwwwwwwwwwwwwwwwwwwwruuuuuuuuuuuuuuiiiiiiiiiin                          aeooooooooooooiiiiiiiiiiiiiiiiiiiiii       ectdssssssssssssssssssliiiiiiiiiiiiiiiiiiiiiiiiiiiiirau            ooooooooooooooooooooooooooooooooooeiiiiiiii      nnnnnnnnnnnnnnnoooooooCppppppppppppppppTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTB:L(b"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""Sghfymedcccccccccccccccccccccccccccccccccccc	wtssssssalllllllllllllllllllllllllloooooooo iiiiiiiiiiiiiiinrrrrrrr eeeeeeuooooooooooooooooooooooooooooiiiiiiieeeeeeeeeedtcaaaaaaaaaaaaaaaaaaaaaaaanslllllllll iuuuuuuuuuuuuoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeir                          TFFFFFFFFFFFFFFFFFFP\kv/DIIIIIIIIIIIII)MV,AAAAAAAAAAAAAA0OOOOOOOOOOOOOOOOOOOOOOE$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$G%%%%%%%%%%%%%%%%%%%%%%%%ppppppppppppppppCn:::::::::::(B."LSbhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhyggggggggggggggggggggfettttttttttad	mcrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrsllllllllluooooooooooooiiiiiiiiiiiiiiiiiiiiii       ieeeeeeeeeeee            ooooooooooooooooooooooooooooeatnnnnnnnnnnrdddddddddddddddcwsiiiiiiii                 lllllllllllllllooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiuuuuuuu	TTTTTTTTTTTTTTTTTTpppppppppppppppppppppppp(:"""""""""""SRhLybbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbCgenartttttttttttttttttffffffffff            dcwmmmmmmusooooooooooooooooooooooooooooiiiiiiiiiiiiiie ilooooooooooooooooooooooooooooooooernnnnnnnnnaaaaaaaaaaaatouuuuuuuuuudccccccccccccccilllllllllllllllllll                          seooooooooooooiiiiiiiiiiiiiiiiiiiiii       pU1!











































































+xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx>;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<WPPPPPPPPPPPPPPPPPPPPPPPPP=================/F\k)vDIAAAAAAAAAAAAAMVNNNNNNNNNNNNNNNNNNNNNN,,,,,,,,,,,,,,000000000000000OE$BBBBBBBBBBBBBBBBBBBBBBBBBBBBBG%TTTTTTTTTTTTTTTTTT	u"(S:hhhhhhhhhhhyRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRLCbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbeeeeeeeeerrrrrrrrrrrrnwgailttttttttttdsc            ooooooooooooooooooooooooooooooooooeiiiiiiii                        fffffffffffffffoooooooeeeeeeeeeeeeeeeeeeeeurlnnnnnnsattttttttttttttttoooooooo iiiiiiiiiiiiiiimddddddd eeeeeecooooooooooooooooooooooooooooiiiiiiiwpppppppppppppppppTTTTTTTTTTTTTTTTTTsS"h(y::::::::::::::::::::::::::::::C................L	beuuuuuuuuuuuulllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllrrrrrrrrmgnat iccccccccccoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeid                          elussssssssssssfffffffffdrnatcooooooooooooiiiiiiiiiiiiiiiiiiiiii       ieeeeeeeeee            ooooooooooooooooooooooooooooT///////////////////)PF\AkvDDDDDDDDDDDDDDDDDDDDDDIIIIIIIIIIIIIMMMMMMMMMMMMMMM-,,,,,,,,,,,,,,B0OER$$$$$$$$$$$$$$$$$$$$$$$$$$$$$GpppppppppppppppppwdhSy""""""""""""""""""""(C::::::::::::::::::::::::::	.%%%%%%%%%%%%%%%%%%Leslfbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbmuuuuuuuuuuuuuuuuuutttttttttrniiiiiiii               aaaaaaaaaaaaaaaooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiicccccccedsultg                             rrrrrrcnooooooooooooooooooooooooooooiiiiiiiiiiiiiie iaoooooooooooooooooooooooooooooooofTTTTTTTTTTTTTTTTTTTppppppppppppppppppppppppppyhhhhhhhhhhhhhhhhhhhhSC""""""""""""""""(	::::::::::::::::::::::::::::wwwwwwwwwwwwwwwwwwwwwwwweudtsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssLlocgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbiar                          neooooooooooooiiiiiiiiiiiiiiiiiiiiii       etuuuuuuuuuudcsialmmmmmmmmmmmmnnnnnnnnn            ooooooooooooooooooooooooooooooooooeiiiiiiii      rrrrrrrrrrrrrrrooooooo)p�٫��������������՛������������������������������������������������������������������������������������������������������������������������������������������������ź�������������������������������������������������Ľ��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������`�^��Z����������������������������������������������������|���п������������������������������������������������������������?������������������������������������������������������������������������������#��������������������������������� }�H�22222222222222222222222222222222222222222222222222222222222Y{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKz]�64jjjjjjjjjjjjjjjjjjjjjjjjjj_[Q7*888888888888888888888888888888888888888888888888888888888888888888888888~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~J33333333333333333333333333333333333
q''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''&5+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX1;UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU@!xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV><WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWA/PFFFFFFFFFFFFFFFFFFFFFF\kvvvvvvvvvvvvvvvDIIIIIIIIIIIIIBM-=,RRRRRRRRRRRRRR0O.E$$$$$$$$$$$$$$$$$$$$$$$$$$$$$TTTTTTTTTTTTTTTTTTTfaaaaaaaaaaaaaaaaaaaayChhhhhhhhhhhhhhhhS	""""""""""""""""""(w:::::::::::::::::::::::::::eeeeeeeeeetcuggggggggggggggggggggggggGddddddnslmLLLLLLLoooooooo iiiiiiiiiiiiiiirrrrrrrrrrrrrrrrrr eeeeeeeeeeeeeeooooooooooooooooooooooooooooiiiiiiieccccccccccatnuuuuuuuurdsl iiiiiiiiiboooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeiiiiiiiiiiii                          gpppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppTTTTTTTTTTTTTTTTTTTrCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCy	hhhhhhhhhhhhhhhhhhSw"""""""""""""""""(f:eacnnnnnnnnnnmmmmmmmmmmmttttttttttttudslllllllllooooooooooooiiiiiiiiiiiiiiiiiiiiii       ieb%            ooooooooooooooooooooooooooooenarcccccccccccccccccccccccccccltudiiiiiiii      Lsssssssssssssssooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiTAmmmmmmmmmmmmmmmmmmmmmm)/PPPPPPPPPPPPPPPF\kBvDIRRRRRRRRRRRRRMN.,,,,,,,,,,,,,,000000000000000000000000OE$pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppgllllllllllllllllC																																					ywhhhhhhhhhhhhhhhhhSf"""""""""""""""""""(ernnnnnnnnnnnnab:c LLLLLLLLLLLLLLLLLLLLtuuuuuuuuuuuuuudooooooooooooooooooooooooooooiiiiiiiiiiiiiie isooooooooooooooooooooooooooooooooeeeeeeeeeeeerln%%%%%%%%%%%%%%%%%%%%%%%%%%%%%aoooooooooccccccccccttttttttttttttisu                          deooooooooooooiiiiiiiiiiiiiiiiiiiiii       bTmppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp																																	CwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwyfhhhhhhhhhhhhhhhhhhhSg"ellllllllllllG(:Lrnisaccccccccccdt            ooooooooooooooooooooooooooooooooooeiiiiiiii      uuuuuuuuuuuuuuuoooooooeeeeeeeeelrrrrrrrrrrrrssssssssssssssssdnacccccccoooooooo iiiiiiiiiiiiiiiuuuuuuuuuuuuuuuu eeeeeetooooooooooooooooooooooooooooiiiiiiip;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;+1
VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUUUUUUUUUUUUUUUUUUUUUUUUUxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx!----------------------------------------------------------------------------------------------------------><GA)/PPPPPPPPPPPPPPPF\kBvDIRRRRRRRRRRRRRMNW.,,,,,,,,,,,,,,000000000000000000000000OE$%Tmbdddddddddddddddddd	wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwCffffffffffffffffffffffffffffffffffffffyghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhSerrrrrrrrrsl:"""""""""""""""""""uuuuuuuuuuu(na itcoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeiiiiiiiiii                          esrdddddddddulllllllllllllllllllllLnatooooooooooooiiiiiiiiiiiiiiiiiiiiii       iec            oooooooooooooooooooooooooooo:pppppppppppppppppppppppppppppTmmmmmmmmmmwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww	ffffffffffffffffffffffffffffffffffCggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggybhedsurrrrrrrrrrrSSSSSSSSSSSSSSSallllllllllllL"iiiiiiii      cnnnnnnnnnnnnnnnooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiittttttteuddddddddddsar ccccccccclllllllllllllllllt(ooooooooooooooooooooooooooooiiiiiiiiiiiiiie inooooooooooooooooooooooooooooooooTGGGGGGGGGGGPPPPPPPPPPPPPPPPPPPPPPA)k///////////////FI\Bv=DRRRRRRRRRRRRR0M.,$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$OpppppppppppppppppppppppppppppE:cccccccccccccccccwffffffffffffffffffffffffffffffffffff	ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggCbbbbbbbbbbbbbbbbbbbbmyeeeeeeeeeeuadLhsotrrrrrrrrrllllllllllllllinnnnnnnnnnnn                          (Seooooooooooooiiiiiiiiiiiiiiiiiiiiii       eaaaaaaaaaacutdinsrrrrrrrrr"l            ooooooooooooooooooooooooooooooooooeiiiiiiii                               oooooooLTTTTTTTTTTTp%nfffffffffffffffffffffffffffffffffffwgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg	bbbbbbbbbbbbbbbbmC::::::::::::::::::::ecatttttttttt(yuuuuuu"hdsrrrrrrroooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii eeeeeelooooooooooooooooooooooooooooiiiiiiietcnaSSSSSSSSSSSSSSSSSSSSSSSSSSSSuds ilroooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeiiiiiiiii                          pppppppppppppppppppppppppppppppppppppp4jjjjjjjjjjjjjjjjjjjjjjjjjj9999999999999999999999999999999*8888888888888888888888888888888888888888888888888888888888888888888888882222222222222222222222222222222222222222222222222222222222222222J33333333333333333333333333333333333q'~11111111111111111111111111111111111111111&X5555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555+;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;VVVVVVVVVVVVVVVVVVVVV














































xUN----------------------------------!PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP>(kGGGGGGGGGGGGGGGGGGGGGGAI)///////////////=<F\B0vDR$$$$$$$$$$$$$M.............................,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,TTTTTTTTTTTLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLfgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggwbbbbbbbbbbbbbbbbbbm	::::::::::::::::%OCentSSSSSSSSSSSSSSSSSSSSy"caaaaaaaaaaaaaaaaaaudslooooooooooooiiiiiiiiiiiiiiiiiiiiii       ier            ooooooooooooooooooooooooooooeeeeeeeeeeeencttttttttthhhhhhhsaaaaaaaaaauiiiiiiii      rdddddddddddddddooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiilllllllSp(TTTTTTTTTTTsgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggfbbbbbbbbbbbbbbbbbmw::::::::::::::::::E	LLLLLLLLLLLLLLLLeccccccccccccccccccccnyCt rhhhhhhhhhhhhhhhhhhhhaaaaaaaaaaaaaaaluooooooooooooooooooooooooooooiiiiiiiiiiiiiie idooooooooooooooooooooooooooooooooeeeeeeeeecssssssssssssrnolt"aaaaaaaaaaaaaaidddddddddd                          ueooooooooooooiiiiiiiiiiiiiiiiiiiiii       TkyIPGGGGGGGGGGGGGGGGGGGGGGWA)/000000000000000F\$BvDDDDDDDDDDDDDDDDDDDDDDDDDDDDDRRRRRRRRRRRRRM%.,,,,,,,,,,,,,,p(Slllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllgbbbbbbbbbbbbbbbbbbbmf:::::::::::::::::EEEEEEEEEEEEEEEEEEEEEEEEwLLLLLLLLLLLLLLLLLLLLLLLLLLLL	esssssssssrchhhhhhhhhhhhhhhhhhhhhhhhhhhidnt"Cua            ooooooooooooooooooooooooooooooooooeiiiiiiii                             oooooooersllllllllldccccccuuuuuuuuuuuuntttttttoooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii eeeeeeaooooooooooooooooooooooooooooiiiiiiihTyp(ubbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbmg:::::::::::::::::::OfLLLLLLLLLLLLLLLLLLLLLLLLLLLwSSSSSSSSSSSSSSSSSSelrds"																									ccccccccccccn iatoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii                          edlurrrrrrrrrrsCCCCCCCCCccccccccccccnaooooooooooooiiiiiiiiiiiiiiiiiiiiii       iet            oooooooooooooooooooooooooooop+++++++++++++++++++++++++++++++++++++++++++++++@1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxV;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
=N-UI!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"W>kPG0000000000000000000000A)$///////////////FFFFFFFFFFFFFFFFFFFFFFFFFFFFF\Bv%DRRRRRRRRRRRRREM.,TyhCbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbmg:::::::::::::::::::OOOOOOOOOOOOOOfLLLLLLLLLLLLLLLLLLLLLLLLLLLwSSSSSSSSSSSSSSSSSS(euddddddddddl																				rrrrrrrnsssssssssciiiiiiii      ttttttttttttttttttttttttttooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiaaaaaaaeeeeeeeeeeuuuuuuuuuuuuuuuudnl trssssssssssssssacooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiiiiiooooooooooooooooooooooooooooooooooooooooooooooooop"TytttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttCgbbbbbbbbbbbbbbbbbbbmf::::::::::::::::::::::::::::::::::::::::wLhhhhhhhhhhheeeeeeeeeeeeeeeeS(	nuuuuuuuuuudoalrssssssssssssssiiiiiiiiiiiiiiiiiiii                          ceooooooooooooiiiiiiiiiiiiiiiiiiiiii       entttttttttttttttttttttttttttttauiiiiiiiiiiiidlrcs            ooooooooooooooooooooooooooooooooooeiiiiiiii                            oooooooT<<<<<<<<<<<<<<<<0IkP$GGGGGGGGGGGGGGGGGGGGGGAAAAAAAAAAAAAAAAAAAAAAAAAAAAA)///////////////%F\BEvDROOOOOOOOOOOOOM.p"""""""""""""""""""""""""""""gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggCfbbbbbbbbbbbbbbbbbmw:hhhhhhhhhhhhhhhhhhhhhhhh,yLeeeeeeeeeenat((((((((((((((((((((((((((((((SSSSSScudllllllloooooooo iiiiiiiiiiiiiiiiiiiiiiirrrrrrr eeeeeesooooooooooooooooooooooooooooiiiiiiieaaaaaaaaaaaaaaaaaaaaanctttttttttttttttt	ud isloooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeir                          (TTTTTTTTTTTTTTTTp"""""""""""""""""""""""""""gfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffCwbhmy:::::::::::::::::::::::::::::::eeeeeeeeeeeeacccccccccccccccccccccccccccccLnrt											udsooooooooooooiiiiiiiiiiiiiiiiiiiiii       iel            ooooooooooooooooooooooooooooeccccccccccccccccccccarrrrrrrrrrrrrrrrdntSiiiiiiii      luuuuuuuuuuuuuuuooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiissssssspjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjH{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}YKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK������������������������������������������������������������������������������������������������������zQ]6______________________________________444444444444444444444444444444444444444444444444444['97777777777777777777777777777777*888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888J33333333333333333333333333333333333q2@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&X55555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555~VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV+++++++++++++++++++++++++xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx1--------------------------------------------------------;W=N
0U!!!!!!!!!!!!!!!!!!!!$<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<IkkkkkkkkkkkkkkkkkkkkkkkkkkkkkPGGGGGGGGGGGGGGGGGGGGGG%A)/EEEEEEEEEEEEEEEF\OBvDDDDDDDDDDDDDDDDDDDDDDDDRRRRRRRRRRRRRMTTTTTTTTTTTTTTTT(dfffffffffffffffffffffffffffffffffffgwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwhCybbbbbbbbbbbbbbbbbbm":eeeeeeeeecrrrrrrrrrrrr														.a llllllllllnttttttsSLooooooooooooooooooooooooooooiiiiiiiiiiiiiie iuooooooooooooooooooooooooooooooooerrrrrrrrrdcllllllllllllosaaaaaaaaaannnnnnnnnnnnnniut                                    eooooooooooooiiiiiiiiiiiiiiiiiiiiii       	ppppppppppppppppppppTTTTTTTTTTTTTTTTsssssssssssssssssfwwwwwwwwwwwwwwwwwwwhgyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyC"b(medrlllllllllS:ciuuuuuuuuuuuuaaaaaaaaaaaaaaaaaaaa,n            ooooooooooooooooooooooooooooooooooeiiiiiiii      tttttttttttttttoooooooeldsruuuuuuuuuuuuuuLccccccccccccaaaaaaaoooooooo iiiiiiiiiiiiiiitttttttttttttttt eeeeeenooooooooooooooooooooooooooooiiiiiiiT$SSSSSSSSSSSSSSSSSSSSSSSSSSSSS0>I%kPGEEEEEEEEEEEEEEEEEEEEEEA)O///////////////FFFFFFFFFFFFFFFFFFFFFFFF\BvvvvvvvvvvvvvvDRRRRRRRRRRRRRpppppppppppppppppppp	LLLLLLLLLLLLLLLLLfwwwwwwwwwwwwwwwwwwwhgyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyC"b(mmmmmmmmmmmmmmmmeslud:::::::::::rrrrrrrrtttttttttcccccccccccc inaoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeiiiiiiiiii                          eus,Mltddddddddddrrrrrrrrrccccccccccccnooooooooooooiiiiiiiiiiiiiiiiiiiiii       iea            oooooooooooooooooooooooooooomTSpppppppppppppppppppppppppppppfLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLgwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwhCybbbbbbbbbbbbbbbbbb	"e.((((((((((((((((:tsulllllllllllllllllldrrrrrrrrriiiiiiii      acccccccccccccccooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiinnnnnnnettttttttttuuuuuuuuuuuuuuuuuuuuuus aldrrrrrrnnnnnnnnnooooooooooooooooooooooooooooiiiiiiiiiiiiiie icooooooooooooooooooooooooooooooooppppppppppppppppppppppppppppppppppppppppppppppppppppppppppVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVx+N----------------------------------1<W=;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
U.$0>!I%kPGEEEEEEEEEEEEEEEEEEEEEEA)O///////////////FFFFFFFFFFFFFFFFFFFFFFFF\BvvvvvvvvvvvvvvDRRRRRRRRRRRRR,TSmaaaaaaaaaaaaaaaaaaafgLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLCwbh	yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyeutttttttttttttttttttttttttttttttttttt"""""""""""(onslddddddddddddddicr                                  eooooooooooooiiiiiiiiiiiiiiiiiiiiii       eeeeeeeeeeeeuatnnnnnnnnnnic:sllllllllld            ooooooooooooooooooooooooooooooooooeiiiiiiii      rrrrrrrrrrrrrrroooooooooooooooooooooopMTScgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggfCLbbbbbbbbbbbbbbbbb	wwwwwwwwwwwwwwwwwwwwhmyeaaaaaaaaaaaanuuuuuuuuuuuuuuuuuuuuuuuuuuuuttttttttttttttttttttttt:"sssssssoooooooo iiiiiiiiiiiiiiirlllllll eeeeeedooooooooooooooooooooooooooooiiiiiiienaccccccccccccccccccccuuuuuuuurtttttttttt( idsoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeil                          T...........IIIIIIIIIIIIIIIIIIIIIIIIIIIII$0GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG%k)PEEEEEEEEEEEEEEEEEEEEEEFAO/vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\\\\\\\\\\\\\BBBBBBBBBBBBBBDpMRRRRRRRRRRRRRRRRrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrgCCCCCCCCCCCCCCCCCCCbf	LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLmwShecnnnnnnnnna:yyyyyyyyyyyylutttttttttt((((((((((((((((((dooooooooooooiiiiiiiiiiiiiiiiiiiiii       ies            ooooooooooooooooooooooooooooeeeeeeeeecrnlaaaaaaa""""""""""""utiiiiiiii      ssssssssssssssssssssssssooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiddddddd:TTTTTTTTTTTp,"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""gCCCCCCCCCCCCCCCCCCCbf	LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLmwShhhhhhhhhhhhhhhherrrrrrrrrlcy(n saaaaaaaaaaaauuuuuudtooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiiiooooooooooooooooooooooooooooooooelrrrrrrrrrrrrrrrrrrrrrrrrrrscodnaaaaaaaaaaaaaaaaaaaaaaaaaiiiiiiiiiiu                          teooooooooooooiiiiiiiiiiiiiiiiiiiiii       pppppppppppppppppppppppppppppppppppppppp4q'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''*888888888888888888888888888888888jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjJ33333333333333333333333333333333333333333333333333333333333333333333333333333333&@555555555555555555555555555555555555555552XxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV=N-+><W1I;
hG.............................$)000000000000000000000000000000U%FkPEvvvvvvvvvvvvvvvvvvvvvvAOOOOOOOOOOOOO//////////////////////////////////////M\BBBBBBBBBBBBBBTTTTTTTTTTT:dg"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""fCLbbbbbbbbbbbbbbbbb	wwwwwwwwwwwwwwwwwwww,DmeeeeeeeeeeeeeeeeeeSSSSSSSSSSSSSSSSysrllllllllliiiiiiiiiicnatttttttttttt            ooooooooooooooooooooooooooooooooooeiiiiiiii      uuuuuuuuuuuuuuuoooooooesdl((((((((((rrrrrrtttttttttcnnnnnnnoooooooo iiiiiiiiiiiiiiiuaaaaaaa eeeeeeeeeeeeeeeeeooooooooooooooooooooooooooooiiiiiiiiiiiiiiiiiiiiiiiiphTTTTTTTTTTTtttttttttttttttttttgf"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLCwbR	::::::::::::::::::::elssssssssssddddddddddddddddm(SSSSSSSSurrrrrrrrrc iiiiiiiiiiiinoooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeia                          eeeeeeeeeeltsudayrrrrrrrrrccccccccccccooooooooooooiiiiiiiiiiiiiiiiiiiiii       ien            ooooooooooooooooooooooooooooTGGGGGGGGGGGGGGGG)I.............................F$0!v%kPPPPPPPPPPPPPEEEEEEEEEEEEEEEEEEEEEEAMO///////////////,,,,,,,,,,,,,,,,,,,,,,,,\BphhhhhhhhhhhhhhhhhhafffffffffffffffffffLggggggggggggggggg"wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwRRRRRRRRRRRRRRC:bbbbbbbbbbb	ettttttttttul((((((((((((((((((((ssssssscdymriiiiiiii      nnnnnnnnnnnnnnnnnnnnnnnooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieutaaaaaaaaaacl nsdSSSSSSSSSSSSSSSSSrooooooooooooooooooooooooooooiiiiiiiiiiiiiie iiiiiiiiioooooooooooooooooooooooooooooooo(TTTTTTTTTTTTTTTTphnLfffffffffffffffffffffffffffffffffffwgD":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::CCCCCCCCCCCCCCCCCCbeaucty										oooooooooooolsddddddddddddddiiiiiiiiiSSSSSSSSSSSSSSSSSSSS                          reooooooooooooiiiiiiiiiiiiiiiiiiiiii       ecanuuuuuuuuuuuutiiiiiiiiiiiiiiiiiilsrd            ooooooooooooooooooooooooooooooooooeiiiiiiii      mmmmmmmmmmmmmmmooooooopVVVVVVVVVVVVVVVVVVVVVVVVVxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx----------------------------------------------------------------------------------W=N~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~><+)1;yFGI.vvvvvvvvvvvvvvvvvvvvvvvvvvvvv$0000000000000!
%kMPEEEEEEEEEEEEEEEEEEEEEE,AO/RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR\TTTTTTTTTTTTTTTT(((((((((((((((((((((((((LwfDBBBBBBBBBBBBBBBBBBB:ggggggggggg""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""hCenccccccccccccaSbuuuuuurttttttttttllllllloooooooo iiiiiiiiiiiiiiim	sssssss eeeeeedooooooooooooooooooooooooooooiiiiiiieeeeeeeeeeeennnnnnnnncraaaaaaaaaaaaaaaaaaaaaaaaaaautttttttttt idloooooooooooooooooooooooooooooooooeeeeeeeeeeeeeeis                          SpyTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTLwffffffffffffffffffffffffffffffff:ggggggggggg""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""hC(eeeeeeeeeeeeeeeeeeeernbmcsauttttttttttdooooooooooooiiiiiiiiiiiiiiiiiiiiii       iel            ooooooooooooooooooooooooooooerrrrrrrrr												snnnnnnnnnnnnnnnncauiiiiiiii      ltttttttttttttttooooooooooooeeeeeeeoooooooo iiiiiiiiiiiiiiidddddddTFCv)GIIIIIIIIIIIII.............................$M0U