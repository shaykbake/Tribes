$PlayerAnim::Crouching = 25;
$PlayerAnim::DieChest = 26;
$PlayerAnim::DieHead = 27;
$PlayerAnim::DieGrabBack = 28;
$PlayerAnim::DieRightSide = 29;
$PlayerAnim::DieLeftSide = 30;
$PlayerAnim::DieLegLeft = 31;
$PlayerAnim::DieLegRight = 32;
$PlayerAnim::DieBlownBack = 33;
$PlayerAnim::DieSpin = 34;
$PlayerAnim::DieForward = 35;
$PlayerAnim::DieForwardKneel = 36;
$PlayerAnim::DieBack = 37;

//----------------------------------------------------------------------------
$CorpseTimeoutValue = 1;
//----------------------------------------------------------------------------

// Player & Armor data block callbacks

function Player::onAdd(%this)
{
	GameBase::setRechargeRate(%this,8);
}

function Player::onRemove(%this)
{
	// Drop anything left at the players pos
	for (%i = 0; %i < 8; %i = %i + 1) {
		%type = Player::getMountedItem(%this,%i);
		if (%type != -1) {
			// Note: Player::dropItem ius not called here.
			%item = newObject("","Item",%type,1,false);
         schedule("Item::Pop(" @ %item @ ");", $ItemPopTime, %item);

         addToSet("MissionCleanup", %item);
			GameBase::setPosition(%item,GameBase::getPosition(%this));
		}
	}
}

function Player::onNoAmmo(%player,%imageSlot,%itemType)
{
	%clip = $Clip[%itemType];
	if(%clip != "") {
		%clipCount = Player::getItemCount(%player,%clip);
		if(%clipCount > 0)
			Player::useItem(%player,%clip);
		else
			bottomprint(Player::getClient(%player), "<jc><f0>Out Of Paintballs!", 2);
	}
}

function Player::onKilled(%this)
{
	%cl = GameBase::getOwnerClient(%this);
	%cl.dead = 1;
	if($AutoRespawn > 0)
		schedule("Game::autoRespawn(" @ %cl @ ");",$AutoRespawn,%cl);
	if(%this.outArea==1)	
		leaveMissionAreaDamage(%cl);
	Player::setDamageFlash(%this,0.75);
	for (%i = 0; %i < 8; %i = %i + 1) {
		%type = Player::getMountedItem(%this,%i);
		if (%type != -1) {
			if (%i != $WeaponSlot || !Player::isTriggered(%this,%i) || getRandom() > "0.2") 
				Player::dropItem(%this,%type);
		}
	}

   if(%cl != -1)
   {
		if(%this.vehicle != "")	{
			if(%this.driver != "") {
				%this.driver = "";
        	 	Client::setControlObject(Player::getClient(%this), %this);
        	 	Player::setMountObject(%this, -1, 0);
			}
			else {
				%this.vehicle.Seat[%this.vehicleSlot-2] = "";
				%this.vehicleSlot = "";
			}
			%this.vehicle = "";		
		}
      schedule("GameBase::startFadeOut(" @ %this @ ");", $CorpseTimeoutValue, %this);
      Client::setOwnedObject(%cl, -1);
      Client::setControlObject(%cl, Client::getObserverCamera(%cl));
      Observer::setOrbitObject(%cl, %this, 5, 5, 5);
      schedule("deleteObject(" @ %this @ ");", $CorpseTimeoutValue + 2.5, %this);
      %cl.observerMode = "dead";
      %cl.dieTime = getSimTime();
   }
}

function Player::onDamage(%this,%type,%value,%pos,%vec,%mom,%vertPos,%quadrant,%object)
{
	if (Player::isExposed(%this)) {
      %damagedClient = Player::getClient(%this);
      %shooterClient = %object;

		Player::applyImpulse(%this,%mom);
		if($teamplay && %damagedClient != %shooterClient && Client::getTeam(%damagedClient) == Client::getTeam(%shooterClient) ) {
			if (%shooterClient != -1) {
				%curTime = getSimTime();
			   if ((%curTime - %this.DamageTime > 3.5 || %this.LastHarm != %shooterClient) && %damagedClient != %shooterClient && $Server::TeamDamageScale > 0) {
					if(%type != $MineDamageType) {
						Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ "!");
						Client::sendMessage(%damagedClient,0,"You took Friendly Fire from " @ Client::getName(%shooterClient) @ "!");
					}
					else {
						Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ " with your mine!");
						Client::sendMessage(%damagedClient,0,"You just stepped on Teamate " @ Client::getName(%shooterClient) @ "'s mine!");
					}
					%this.LastHarm = %shooterClient;
					%this.DamageStamp = %curTime;
				}
			}
			%friendFire = $Server::TeamDamageScale;
		}
		else if(%type == $ImpactDamageType && Client::getTeam(%object.clLastMount) == Client::getTeam(%damagedClient)) 
			%friendFire = $Server::TeamDamageScale;
		else  
			%friendFire = 1.0;	

		if (!Player::isDead(%this)) {
			%armor = Player::getArmor(%this);
			//More damage applyed to head shots
			if(%vertPos == "head" && %type == $LaserDamageType) {
				if(%armor == "harmor") { 
					if(%quadrant == "middle_back" || %quadrant == "middle_front" || %quadrant == "middle_middle") {
						%value += (%value * 0.3);
					}
				}
				else {
					%value += (%value * 0.3);
				}
			}
			//If Shield Pack is on
			if (%type != -1 && %this.shieldStrength) {
				%energy = GameBase::getEnergy(%this);
				%strength = %this.shieldStrength;
				if (%type == $ShrapnelDamageType || %type == $MortarDamageType)
					%strength *= 0.75;
				%absorb = %energy * %strength;
				if (%value < %absorb) {
					GameBase::setEnergy(%this,%energy - ((%value / %strength)*%friendFire));
					%thisPos = getBoxCenter(%this);
					%offsetZ =((getWord(%pos,2))-(getWord(%thisPos,2)));
					GameBase::activateShield(%this,%vec,%offsetZ);
					%value = 0;
				}
				else {
					GameBase::setEnergy(%this,0);
					%value = %value - %absorb;
				}
			}
  			if (%value) {
				%value = $DamageScale[%armor, %type] * %value * %friendFire;
            %dlevel = GameBase::getDamageLevel(%this) + %value;
            %spillOver = %dlevel - %armor.maxDamage;
				GameBase::setDamageLevel(%this,%dlevel);
				%flash = Player::getDamageFlash(%this) + %value * 2;
				if (%flash > 0.75) 
					%flash = 0.75;
				Player::setDamageFlash(%this,%flash);
				//If player not dead then play a random hurt sound
				if(!Player::isDead(%this)) { 
					if(%damagedClient.lastDamage < getSimTime()) {
						%sound = radnomItems(3,injure1,injure2,injure3);
						playVoice(%damagedClient,%sound);
						%damagedClient.lastdamage = getSimTime() + 1.5;
					}
				}
				else {
               if(%spillOver > 0.5 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType|| %type == $MissileDamageType)) {
		 				Player::trigger(%this, $WeaponSlot, false);
						%weaponType = Player::getMountedItem(%this,$WeaponSlot);
						if(%weaponType != -1)
							Player::dropItem(%this,%weaponType);
                	Player::blowUp(%this);
					}
					else
					{
						if ((%value > 0.40 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType || %type == $MissileDamageType )) || (Player::getLastContactCount(%this) > 6) ) {
					  		if(%quadrant == "front_left" || %quadrant == "front_right") 
								%curDie = $PlayerAnim::DieBlownBack;
							else
								%curDie = $PlayerAnim::DieForward;
						}
						else if( Player::isCrouching(%this) ) 
							%curDie = $PlayerAnim::Crouching;							
						else if(%vertPos=="head") {
							if(%quadrant == "front_left" ||	%quadrant == "front_right"	) 
								%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieBack);
						  	else 
								%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieForward);
						}
						else if (%vertPos == "torso") {
							if(%quadrant == "front_left" ) 
								%curDie = radnomItems(3, $PlayerAnim::DieLeftSide, $PlayerAnim::DieChest, $PlayerAnim::DieForwardKneel);
							else if(%quadrant == "front_right") 
								%curDie = radnomItems(3, $PlayerAnim::DieChest, $PlayerAnim::DieRightSide, $PlayerAnim::DieSpin);
							else if(%quadrant == "back_left" ) 
								%curDie = radnomItems(4, $PlayerAnim::DieLeftSide, $PlayerAnim::DieGrabBack, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
							else if(%quadrant == "back_right") 
								%curDie = radnomItems(4, $PlayerAnim::DieGrabBack, $PlayerAnim::DieRightSide, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
						}
						else if (%vertPos == "legs") {
							if(%quadrant == "front_left" ||	%quadrant == "back_left") 
								%curDie = $PlayerAnim::DieLegLeft;
							if(%quadrant == "front_right" ||	%quadrant == "back_right") 
								%curDie = $PlayerAnim::DieLegRight;
						}
						Player::setAnimation(%this, %curDie);
					}
					if(%type == $ImpactDamageType && %object.clLastMount != "")  
						%shooterClient = %object.clLastMount;
					Client::onKilled(%damagedClient,%shooterClient, %type);
				}
			}
		}
	}
}

function radnomItems(%num, %an0, %an1, %an2, %an3, %an4, %an5, %an6)
{
	return %an[floor(getRandom() * (%num - 0.01))];
}

function Player::onCollision(%this,%object)
{
	if (Player::isDead(%this)) {
		if (getObjectType(%object) == "Player") {
			// Transfer all our items to the player
			%sound = false;
			%max = getNumItems();
			for (%i = 0; %i < %max; %i = %i + 1) {
				%count = Player::getItemCount(%this,%i);
				if (%count) {
					%delta = Item::giveItem(%object,getItemData(%i),%count);
					if (%delta > 0) {
						Player::decItemCount(%this,%i,%delta);
						%sound = true;
					}
				}
			}
			if (%sound) {
				// Play pickup if we gave him anything
				playSound(SoundPickupItem,GameBase::getPosition(%this));
			}
		}
	}
}

function Player::getHeatFactor(%this)
{
	// Hack to avoid turret turret not tracking vehicles.
	// Assumes that if we are not in the player we are
	// controlling a vechicle, which is not always correct
	// but should be OK for now.
	%client = Player::getClient(%this);
	if (Client::getControlObject(%client) != %this)
		return 1.0;

   %time = getIntegerTime(true) >> 5;
   %lastTime = Player::lastJetTime(%this) >> 10;

   if ((%lastTime + 1.5) < %time) {
      return 0.0;
   } else {
      %diff = %time - %lastTime;
      %heat = 1.0 - (%diff / 1.5);
      return %heat;
   }
}

function Player::jump(%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   if(%cl != -1)
   {
      %vehicle = Player::getMountObject (%this);
		%this.lastMount = %vehicle;
		%this.newMountTime = getSimTime() + 3.0;
		Player::setMountObject(%this, %vehicle, 0);
		Player::setMountObject(%this, -1, 0);
		Player::applyImpulse(%pl,%mom);
		playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
   }
}


//----------------------------------------------------------------------------

function remoteKill(%client)
{
   if(!$matchStarted)
      return;

   %player = Client::getOwnedObject(%client);
   if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player))
   {
		playNextAnim(%client);
	   Player::kill(%client);
	   Client::onKilled(%client,%client);
   }
}

$animNumber = 25;	 
function playNextAnim(%client)
{
	if($animNumber > 36) 
		$animNumber = 25;		
	Player::setAnimation(%client,$animNumber++);
}
function Client::takeControl(%clientId, %objectId)
{
   // remote control
   if(%objectId == -1)
   {
      //echo("objectId = " @ %objectId);
      return;
   }

	%pl = Client::getOwnedObject(%clientId);
	// If mounted to a vehicle then can't mount any other objects
	if(%pl.driver != "" || %pl.vehicleSlot != "")
		return;

   if(GameBase::getTeam(%objectId) != Client::getTeam(%clientId))
   {
      //echo(GameBase::getTeam(%objectId) @ " " @ Client::getTeam(%clientId));
      return;
   }
   if(GameBase::getControlClient(%objectId) != -1)
   {
      echo("Ctrl Client = " @ GameBase::getControlClient(%objectId));
      return;
   }
	%name = GameBase::getDataName(%objectId);
	if(%name != CameraTurret && %name != DeployableTurret)
   {
	   if(!GameBase::isPowered(%objectId)) 
		{
	      // echo("Turret " @ %objectId @ " not powered.");
	      return;
		}
   }
   if(!(Client::getOwnedObject(%clientId)).CommandTag && GameBase::getDataName(%objectId) != CameraTurret &&
      !$TestCheats) {
		Client::SendMessage(%clientId,0,"Must be at a Command Station to control turrets");
   		return;
   }
   if(GameBase::getDamageState(%objectId) == "Enabled") {
   	Client::setControlObject(%clientId, %objectId);
   	Client::setGuiMode(%clientId, $GuiModePlay);
	}
}

function remoteCmdrMountObject(%clientId, %objectIdx)
{
   Client::takeControl(%clientId, getObjectByTargetIndex(%objectIdx));
}

function checkControlUnmount(%clientId)
{
   %ownedObject = Client::getOwnedObject(%clientId);
   %ctrlObject = Client::getControlObject(%clientId);
   if(%ownedObject != %ctrlObject)
   {
      if(%ownedObject == -1 || %ctrlObject == -1)
         return;
      if(getObjectType(%ownedObject) == "Player" && Player::getMountObject(%ownedObject) == %ctrlObject)
         return;
      Client::setControlObject(%clientId, %ownedObject);
   }
}












































































a>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>RaaaaaaaaOOOOOOOAbbbbbbbaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbbbbCgaaaaaaaaaaaaaaaaaaaaaaaaaaaaao!!!!!!!aaaaaaaaaaaaaaaaooooooommHM]6+<-------------------------------------------------------------G@@@@@@@@@@@@@@@@@@@@@�[bSCO>>>>>>>aaaaaaaaaaaaaaaoooooooo!RRRRRRRRRRRRRRRRRaaaaaaaaaaaaaaaaaaaaaaaaaaaaaogggggggaaaaaaaaaaaaaaaaooooooommbCCCCCCCCCCCCCCCCCCCCASSSSSSSaaaaaaaaaaaaaaaoooooooog(aaaaaaaaaaaaaaaaaaaaaaaaaaaaaoooooooooooooooooooooooaaaaaaaaaaaaaaaaooooooomm3)))))))))))))))))))))))))))))))))))))))))))-------------------------------------------------------------!MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMOC"A>bgggggggggggggggggggg       aaaaaaaaaaaaaaaooooooooooooooooooSSSSSSS aaaaaaaaaaaaaaaaaaaaaaaooooooo(d       aaaaaaaaaaaaaaaaommmmmmm  ggggggggggggggg)C(Rb"aaaaaaaaaaaaaaaooooooommmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmd       aaaaaaaaaaaaaaaoodmmmmmmm aaaaaaaaaaaaaaaaaaaaaaaoooooooS       aaaaaaaaaaaaaaaaaaaaaaaaaaaaallllllll�V|||||||||||||||||||||||||||||||||||||||||_}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}'777777777777777777777777777777777UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU*KLH]6++++++++++++++++++++++++++++++++G@<vT21333333333333333333333)f!-----------------------------------------------------------------------------------bgggggggggggggggAMdC(((((((((((((((oSRO""""""""""""""""""""""""""         aaaaaaaaaaaaaaaooooooommld              aaaaaaaaaaaaaaaoooooooooooooooooo              aaaaaaaaaaaaaaaaaaaaaaaC%)b"""""""""""""""fgl(Sooooooooooooooooo>mmmmmmm              aaaaaaaaaaoooooood                                        laaaaaaaaaaaaaaaodsssssss         eaaaaaaaaaooooooooooooooooooooommy/222222222222222222[v!T13AAAAAAAAAAAAAAAAAAAAA-----------------------C.)RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"%fb(((((((((((((((((((((((((((((((ggggggggggggggggggggSld        eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoos        eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaamllllllllllllos>M        eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaod                            ee"()C....................fb%lllllllllllllllllllllllllllllllsmaaaaaaaaaodddddddddddd                                   eaaaaaaaaaoOggggggggggggggggggggg        sldnnnnnnnneaaaaaaaaaoooooooooooooooooooooSmmmmmmmmmmmm              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooHNB
















































;j[PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP*KLLLLLLLLLLLLLLLLLLLLLLLLLLL]6++++++++++++++++++++++++++++++++G@-y/222222222222222222=v!(hA1T33333333333333333333>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>R"""""""""""""""C.)sfbdOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO%SSSSSSSSSSSSSSSSSlllllllllllln              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaom              eeeeeeeeeeeeeeeeeeeeeaadggggggggggggggggggggggsssssssssoml                                  eeaaaaaaaaaon                                                       ((((((((((((((((((((f,"hS.)CgM%bbbbbbbbbbbbdmmmmmmmmmmmeaaaaaaaaaons                                        eaaaaaaaaaolllllllllllllllllllll             mmmmmmmmmmmmmmmmmnddddddddddddddeaaaaaaaaaooooooooooooooooooooollllllllllls              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooooooo$<-y/////////////>2=v!A1T((((((((((((((((((((((((((((((((((((3OOOOOOOOOOOOOOOOOOOOO""""""""""""""""""""""""""""""""""f),hS%.CgmmmmmmmmmmnnnnnnnnnnnnlllllllllllllllllMRsd              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooo              eeeeeeeeeeeeeeeeeeeeeaamntllllllllllssssssssssssssssssssooooooooooob                                  eeaaaaaaaaaod                                         """""""""""""""""""""""""")((((((((((((((((((((((((((((((((((%f,hhhhhhhhhhhhhhhhhS.Cnrlmstttttttttttttttttttteaaaaaaaaaodddddddddddd                                        eaaaaaaaaaobggggggggggggggggggggg  lnsrrrrrrrrrrrmdtttttttttttttteaaaaaaaaaoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoo��������������������������������������������������~���zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz����������������������������������������������������F���������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������`�^�\���X������Q�������ccccccccccccccccccccccccccccccc��Ͽ�������������������������������������������������������������������������������������������������������?ڻ칹��������������������������������������������������Ķ�����������������#����D5��q4444444444444444444444444444444444444444444444444444444444444444 ZYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999{JWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW&xkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk8VEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE��������������������������������������}|'___________________________________________________________________HN+





















B;j[PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP7777777777777777777777777777777777777777777777777777777777777777777777777777777*KL>>>>>>>>>>>>>>>>:::::::::::::::::::::::::::]G666666666666666666$<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<y/-2=v!!!!!!!!!!!!!!A1OTM333333333333333"""""""""""""),((((((((((((((((((((%.fhhhhhhhhhhhhhhhhhlisbSSSSSSSSSSSndrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrCmmmmmmmmmmmmtttttt              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaasssssssssssidlgnnnnnnnnnnnnrrrrrrrrroooooooooommmmmm                                  eeaaaaaaaaaotttttt                                                     cpppppppppppppppppppppppppppppppppp""""""""""""""h,()R.f%%%%%%%%%%%%%%%%%%%%%%%%%%%bdsgSiiiiiiiiiiiillllllllllneaaaaaaaaaotrrrrrr                                        eaaaaaaaaaommmmmmmmmmmmmmmmmmmmmmmmmm  dCCCCCCCCCCCCCCCCCCCCCCssssssssssitlllllllllllllleaaaaaaaaaomnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn              eaaaaaaaaaooooooooooooooooooooorr$>>>>>>>>>>>>>>>>:/000000000000000000wvvvvvvvvvvvvvvvvvvvvvvvy@O2=-------------------------------------------------------------A1!cTMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"phhhhhhhhhhhhhhh((((((((((((((R3,f))))))))))))))))).g%dCbbbbbbbbbbbbbbbbbbbbbbssssssssssitlmmmmmm              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoonnnnnn              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadddddddddddrsSiiiiiiiiiiiillllllllllontttttt              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaommmmmm                                  eehcuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"ppppppppppppppppppppppppppppp((((((((((((((((((((((((((((Cf),,,,,,,,,,,.gsdirlS%nnnnnnnnnnnnaaaaaaaaaommmmmmmmmmmmmmm                                         eaaaaaaaaaotttttt                                 siiiiiiiiiiildnrmbbbbbbbbeaaaaaaaaaottttttttttttttttttttttttttttttttttttt               eaaaaaaaaaooooooooooooooooooooooooooooooooooooooooKxkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkD5IFHN+





















/																			;Pjjjjjjjjjjjjjjjjjjjjjjjjj[[[[[[[[[[[[[[[[[[[[[[[[[[UBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBOG*LLLLLLLLLLLLLLLLLLLLLLLLLLL$>>>>>>>>>>>>>>>>:<]TTTTTTTTTTTTTTTTTTwvvvvvvvvvvvvvvvvvvvvvvvy@60uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu=1-2AphcR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!M"""""""""""""""""""")))))))))))))))))(((((((((((((SCfffffffffffffffi,.lsnnnnnnnnnnnmdtr              eaaaaaaaaaoooooooooooooooooooooooooooooobggggggggggggggggg              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoolnimsttttttttttttttttttttddddddddddddrrrrrr              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaao%%%%%%              eeeeeeeeeeeeeeeeeeeeeaa"phc((((((((((((((3uf))))))))))))))))))))))))))))))))))))bSCCCCCCCCCCCCCnnnnnnnnnnnnnnn,mltiiiiiiiiiisssssssssssssssssssssssssssssso%.dddddd                                  eeaaaaaaaaaorrrrrr                                         mtnnnnnnnnnnlllllllllllligseaaaaaaaaaorrrrrrrrrrrrrrrr                                        eaaaaaaaaaodddddddddddddddddddddddddd                                 OOOOOOOOOOOOOOOOOOO/$>>>>>>>>>>>>>>>>:RTTTTTTTTTTTTTTTTTTwvvvvvvvvvvvvvvvvvvvvvvvy	h11111111111111111111111111111111111111111111111111111111111112=0-3A!!!!!!!!!!!!!!!!!!!!!p"""""""""""""""""((((((((((((((cCf)u%bSSSSSSSSSSSSSSSSSSSSttttttttttttttttttttttttttttttttttttmmmmmmmmmmmmng,lriiiiiiiiiiiiiieaaaaaaaaaodsssssssssssssssssssssssssssssss              eaaaaaaaaaooooooooooooooooooooooooooooooooooooooooottttttttttmmmmmmmmmmmmn.lridddddd              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoossssss              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahMp)))))))))))))))))("SCfcg%buttttttttttttttttttttttttttttttttmmmmmmmmmmmnnnnnnnnnnlllllllllllli...............osrrrrrr              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaodddddd                                  eemntllllllllllliiiiiiiiiissssssssssssaaaaaaaaaod,,,,,,                                         eaaaaaaaaaorrrrrr                                 












































W444444444444444444444444444444444444444444444444V&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&8}E<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<�|'KxkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkD5IFHN+++++++++++++++++++++++++++++++++++++++________________P;;;;;;;;;;;;;;;;;;;;;;;;;;jB[GUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUULLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL*yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy]@@@@@@@@@@@@@@@@@@@/$>O3RTTTTTTTTTTTTTTTTTTwvvvvvvvvvvvvvvvvvvvvvvv:M11111111111111111111111111111111111111111111111111111111111112=0-	((((((((((((((hA!f)))))))))))))))))pbSC".g%cnuuuuuuuuuuuuuuuuuuuulmitsssssssssssdddddddddddddddddeaaaaaaaaaorrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr               eaaaaaaaaao,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,linsmdtrrrrrrrrrrr              eaaaaaaaaaoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoooooooooooooooooo((((((((((((((hCf)))))))))))))))))))))%bSp,.g"icusldnrmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmttttttttttttttttttttttttttt              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaasdirlllllllllllllnnnnnnnnnnnnmmmmmmmmmooooooooootttttt                                  eeaaaaaaaaaoooooooooooooooo                                                               yyyyyyyyyyyyyyyy6666666666666666666/$>-3RTTTTTTTTTTTTTTTTTTwvOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOM=1:2)))))))))))))))))(A0SCfhg%bbbbbbbbbbbbbbbbbbbbb															,.pd"crsssssssssssssuiiiiiiiiiiiillllllllllneaaaaaaaaaooooooooooommmmmm                                        eaaaaaaaaaotttttttttttttttttttttttttt  rrrrrrrrrrrrrrrrrrrrddddddddddddssssssssssiiiiiiiiiiilllllllllllllleaaaaaaaaaotnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn              eaaaaaaaaaooooooooooooooooooooomm()SSSSSSSSSSSSSSSSSffffffffffffffgCbhhhhhhhhhhhhhhh%.!",,,,,,,,,,,,,prrrrrrrrrrrrrrrrrrrrcddddddddddddssssssssssiiiiiiiiiiiltttttt              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoonnnnnn              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaardmsuiiiiiiiiiiiillllllllllonnnnnnnnnnnnnnnn              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaotttttt                                  eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee<KxkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkD5IFHN+$$$$$$$$$$$$$$$$$$$$$$$$$PPPPPPPPPPPPPPPPPPPPPPPPPPB;GjL[[[[[[[[[[[[[[[[[[[[[[7





























vvvvvvvvvvvvvvvvvvvvvvvyyyyyyyyyyyyyyyy6***************************]///////////////////A-3RTTTTTTTTTTTTTTTTTTw>S=============================================================:MO1g()))))))))))))))))))))222222222222222ffffffffffffffffffffffffffffff"bhCCCCCCCCCCCCCCCCCCCC.!0%d,,,,,,,,,,,,,srimlupnnnnnnnnnnnnaaaaaaaaaottttttttttttttt                                         eaaaaaaaaaoooooooooooooooo                                 sidlrnmtcccccccceaaaaaaaaaooooooooooooooooooooooooooooooooooooooooooooooo               eaaaaaaaaaooooooooooooooooooooooooooooooooooooooooooooooooooooog()hhhhhhhhhhhhhhhfS	"bbbbbbbbbbbbbbbbbuuuuuuuuuuuuuuuuuuuu.Ci%,lsndtrrrrrrrrrrrm              eaaaaaaaaaooooooooooooooooooooooooooooooccccccccccccccccccccccccccccc              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoolnitsssssssssssddddddddddrrrrrrrrrrrrmmmmmm              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaopppppp              eeeeeeeeeeeeeeeeeeeeeaawvvvvvvvvvvvvvvvvvvvvvvvyyyyyyyyyyyyyyyy$@/////////////////////A-3RTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT(:=OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO>Mffffffffffffffg!1bhhhhhhhhhhhhhhh).	2"ScuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuunC%tllllllllllliiiiiiiiiissssssssssssdddddddddop,rrrrrr                                  eeaaaaaaaaaommmmmm                                         tttttttttttnnnnnnnnnnlllllllllllliiiiiiiiiiiiiseaaaaaaaaaomdddddd                                        eaaaaaaaaaorrrrrrrrrrrrrrrrrrrrrrrrrr                ffffffffffffffg"bh((((((((((((((((((((.0)pcuSSSSSSSSSSSSSSSSSSSSSSSSSSSCCCCCCCCCCttttttttttttnnnnnnnnnnnnn%lmiiiiiiiiiiiiiieaaaaaaaaaorsssssssssssssssssssssssssssssss              eaaaaaaaaaooooooooooooooooooooodddddddddddddddddddddttttttttttttn,lmirrrrrr              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoossssss              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqZY99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999{4�JVWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW}&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&8666666666666666666666666666666666666666E������������������������������������||||||||||||||||||||||||||||||||<KxkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkD5IFHU'@@@@@@@@@@@@@@@@@@@@@@@@@PPPPPPPPPPPPPPPPPPPPPPPPPPB;GjL[[[[[[[[[[[[[[[[[[[[[[7_





























++++++++++++++++++wvvvvvvvvvvvvvvvvvvvvvvvyyyyyyyyyyyyyyyy$***************************!!!!!!!!!!!!!!!!!!!!!A-3RT//////////////O:>===============================================================================hhhhhhhhhhhhhhhf	M01"bguuuuuuuuuuuuuuuuuuuu.(((((((((((((pc)))))))))))SSSSSSSSSSSSSSSSStdnnnnnnnnnnlllllllllllli,Cosmmmmmm              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaorrrrrr                                  eetnnnnnnnnnnnldiiiiiiiiiissssssssssssaaaaaaaaaor%%%%%%                                         eaaaaaaaaaommmmmm                                 bhhhhhhhhhhhhhhhf.2""""""""""""""cuuuuuuuuuuuuuuuuuuuug,,,,,,,,,,,,,p(n)Sltiiiiiiiiiiisdrrrrrrrrrrrrrrrrreaaaaaaaaaommmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm               eaaaaaaaaao%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%linstrrrrrrrrrrrmd              eaaaaaaaaaoooooooooooooooooooooCCCCCCCCCCCCCCCCCCCCCCCCCC              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooTTTTTTTTTTTTTTTTTTwvvvvvvvvvvvvvvvvvvvvvvvyyyyyyyyyyyyyyyy$	!!!!!!!!!!!!!!!!!!!!!A-3R]]]]]]]]]]]]]]]>OOOOOOOOOOOOOOOOOOO:/="bh00000000000000000000000000000000000000000000000000000000000000000000000000000000.2Mfpcuuuuuuuuuuuuuu%,,,,,,,,,,,,,gi()slrnmtCSSSSSSSSSSSSSSSSSSSSSSdddddd              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaasrimlllllllllllllllllnnnnnnnnnnnntttttttttooooooooooooooooooooooooo                                  eeaaaaaaaaaodddddd                                         1"bhuuuuuuuuuuuuuuuuuuuu...........................pcfC%,,,,,,,,,,,,,,rg(msssssssssssssssss)iiiiiiiiiiiillllllllllneaaaaaaaaaodtttttt                                        eaaaaaaaaaoooooooooooooooooooooooooooooooooooo  mSrrrrrrrrrrrrssssssssssidlllllllllllllleaaaaaaaaaooooooooooonnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn              eaaaaaaaaaooooooooooooooooooooottH66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;D5IFkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk@@@@@@@@@@@@@@@@@@@@@@@@@PPPPPPPPPPPPPPPPPPPPPPPPPPBNw[jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjLGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGTTTTTTTTTTTTTTTTTT*










































yvR	!$$$$$$$$$$$$$$$$$$$-3A0>O]+1/=:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb2u".hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhcccccccccccccccCp,fg%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%mS(rrrrrrrrrrrrssssssssssidllllllllllllllll              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoonnnnnn              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaamrts)iiiiiiiiiiiillllllllllondddddd              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaoooooooooooooooo                                  eeeeeeeeeeeeeebMuC.h"gccccccccccccccccccccccccccccccccccS,fpr%%%%%%%%%%%%%%%%%smitl))))))))))))))nnnnnnnnnnnnaaaaaaaaaooooooooooooooooooooooooo                                         eaaaaaaaaaodddddd                                 sirlmnttttttttttt((((((((eaaaaaaaaaoddddddddddddddddddddddddddddddddddddd               eaaaaaaaaaoooooooooooooooooooooooooooooooooooooooo3333333333333333TTTTTTTTTTTTTTTTTTwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwy=R	!$$$$$$$$$$$$$$$$$$$-vM0>OOOOOOOOOOOOOOOOOOOOOOOOOOO1/Ahhhhhhhhhhhhhb:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::C.ufgc")S,,,,,,,,,,,,,,,,,,,,ip%lsnrrrrrrrrrrrmdt              eaaaaaaaaaoooooooooooooooooooooooooooooo(((((((((((((((((((((((((((((((((              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoolniiiiiiiiiiisdrrrrrrrrrrmmmmmmmmmmmmtttttt              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaa.hhhhhhhhhhhhhbcccccccccccccccC2,fgu()S"nnnnnnnnnnnnnnnnnnnnpppppppppppldiiiiiiiiiissssssssssssrrrrrrrrroooooooooooooo%mmmmmm                                  eeaaaaaaaaaotttttt                                                   dnnnnnnnnnnlllllllllllliiiiiiiiiiiiiiiiiseaaaaaaaaaotrrrrrr                                        eaaaaaaaaaommmmmmmmmmmmmmmmmmmmmmmmmm  FV4444444444444444444444444444444444444444444444444444444444444444444444444444444444444}WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW&*U8EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEH66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;D5I7|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||@BP['NGjkL-3333333333333333TTTTTTTTTTTTTTTTTTwwwwwwwwwwwwwwwwwwwww]]]]]]]]]]]]]]]]]]]]]]/=R	!$$$$$$$$$$$$$$$$$$$yyyyyyyyyyyyy>MMMMMMMMMMMMMMMMMMMMMMMMMMM
0vOC.h:1gcccccccccccccccbS,f2AAAAAAAAAAAAAA()ud""""""""""""""""""""""""""""""""""""""""""""""""""nnnnnnnnnnnnnnnnnpltiiiiiiiiiiiiiieaaaaaaaaaomsssssssssssssssssssssssssssssss              eaaaaaaaaaooooooooooooooooooooorrdddddddddddddddddddddddddddddddn%ltimmmmmm              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoossssss              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaC.hfgccccccccccccc)S,bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((du"""""""""""rnnnnnnnnnnlllllllllllli%%%%%%%%%%%%%%%%%%%%ostttttt              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaommmmmm                                  eeeeeeeeeeeendlriiiiiiiiiissssssssssssaaaaaaaaaompppppp                                         eaaaaaaaaaotttttt                                                   -3333333333333333TTTTTTTTTTTTTTTTTTwwwwwwwwwwwwwwwwwwwww:/=R	!$$$$$$$$$$$$$$$$$$$$$$$.+>vMy0cccccccccccccccC2O,fgh()SSSSSSSSSSSSS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%bnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn1ulllllllllllidsrmmmmmmmmmmmmmmmmmeaaaaaaaaaottttttttttttttttttttttttttttttttttttt               eaaaaaaaaaop"""""""""""""""""""""""""""""""linsssssssssssmdtr              eaaaaaaaaaooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoogcccccccccccccccCS,f..............()hp%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ibAslmnttttttttttttttttttttttttttttttuddddddddddddrrrrrr              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaasmitl"nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnoooooooooodddddd                                  eeaaaaaaaaaorrrrrr                                         ]*H66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;D5IwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB[@_PGkNFj$$$$$$$$$$$$$$$$$$$-3333333333333333TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTL2:/=R	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!v++++++++++++++++++++++y>>>>>>>>>>>>>>>>>>>>>>>Mfgccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc0)S,CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC(....................p%hmmmmmmmmmmmmmbts"AOiiiiiiiiiiiillllllllllneaaaaaaaaaorrrrrrrrrrrrrrrr                                        eaaaaaaaaaodddddddddddddddddddddddddd  tummmmmmmmmmmmssssssssssirlllllllllllllleaaaaaaaaaodnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn              eaaaaaaaaaooooooooooooooooooooooooooooooooooooooooocf)g,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,S(CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC%.............p"htubmmmmmmmmmmmmssssssssssirldddddd              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoonnnnnn              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatmmmmmmmmmmms1iiiiiiiiiiiillllllllllonrrrrrr              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaodddddd                                  ee!$$$$$$$$$$$$$$$$$$$-3333333333333333TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT2:/=R	w)yvvvvvvvvvvvvvvvvvvvvvvv




















>>>>>>>>>>>>>>>>>cfAMMMMMMMMMMMMMMMMMMMM,,,,,,,,,,,,,,,ggggggggggggg(CSu%..............mp"stiiiiiiiiiiil10hnnnnnnnnnnnnaaaaaaaaaoddddddddddddddd                                         eaaaaaaaaaorrrrrr                                 simltnnnnnnnnnnndbbbbbbbbeaaaaaaaaaorrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr               eaaaaaaaaaoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooocfCCCCCCCCCCCCCCCCCCCC,).............(gOu%Siiiiiiiiiiiiiiplsnmdtrrrrrrrrrrr              eaaaaaaaaaoooooooooooooooooooooooooooooob"""""""""""""""""              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoolnidsrmmmmmmmmmmttttttttttttttttttttttttttt              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaohhhhhh              eeeeeeeeeeeeeeeeeeeeeaa�U����������������������������������������������򁀂���~����������������������������������������������������������z����������������������������������������������־���������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������``````````````````````````````````````````````��\^��X������Q�������������������������������������������������������?Ͽ¹�������������������������������������������������������Ļ�ڳ���������������������������������������������������5#���������������������������������������������������������������������� ��Y��qVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ999999999999999999999999999999999999999999999999999999999999}4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444W�{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{7&8E]*H66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDJTBBBBBBBBBBBBBBBBBBBBBBBBBB[[[[[[[[[[[[[[[[[[[[[[[[[_||||||||||||||||||||||||||||||G@kPFIN	!$$$$$$$$$$$$$$$$$$$-3333333333333333+jAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2:/=RRRRRRRRRRRRRRRRRRcccccccccccccccccccccccyyyyyyyyyyyyyyyyyyyyyvw
L,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1>(CCCCCCCCCCCCCCCCCCCCf%.............)bOMugnSSSSSSSSSSSSSSdlriiiiiiiiiissssssssssssmmmmmmmmmohptttttt                                  eeaaaaaaaaaoooooooooooooooo                                         drnnnnnnnnnnlllllllllllli"seaaaaaaaaaooooooooooommmmmm                                        eaaaaaaaaaotttttttttttttttttttttttttt                     ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,(Ccu%.fhb0)rgSSSSSSSSSSddddddddddddn""""""""""""""llllllllllliiiiiiiiiiiiiieaaaaaaaaaotsssssssssssssssssssssssssssssss              eaaaaaaaaaooooooooooooooooooooommrrrrrrrrrrddddddddddddnplllllllllllitttttt              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoossssss              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaR	!$$$$$$$$$$$$$$$$$$$-33333333333333331AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2:/=TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTwyyyyyyyyyyyyyyyyyyvCCCCCCCCCCCCCCCCCCCC,OOOOOOOOOOOOOOOOOOOOOO.............(((((((((((((((((0>u%c"hbfr)gdmnnnnnnnnnnllllllllllllipSossssssssssssssss              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaotttttt                                  eednrlmiiiiiiiiiissssssssssssaaaaaaaaaottttttttttttttttttt                                         eaaaaaaaaaoooooooooooooooo                                 (CCCCCCCCCCCCCCCCCCCC,%...........................bMuuuuuuuuuuuuuuuuup"hcnf)ldirsmttttttttttttttttteaaaaaaaaaooooooooooooooooooooooooooooooooooooooooooooooo               eaaaaaaaaaooooooooooooooggggggggggggggggggggggggggggggglinsdtrrrrrrrrrrrm              eaaaaaaaaaoooooooooooooooooooooSSSSSSSSSSSSSSSSSSSSSSSSSS              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoo+++++++++++++++++++++++++++]*H66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;D3[B''''''''''''''''''''''''''GGGGGGGGGGGGGGGGGGGGGGGGGkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkF@IP5=R	!$$$$$$$$$$$$$$$$$$$-
NO1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2:///////////////////////////////////wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwTyyyyyyyyyyyyy(C0vu%.,hbMMMMMMMMMMMMMMMMMMMMMMjjjjjjjjjjjjjjjjjjjjjjjjjjjjp"""""""""""""""""icfsltnnnnnnnnnnndS)rrrrrrrrrrrrmmmmmm              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaastiiiiiiiiiiilgnnnnnnnnnnnndddddddddoooooooooorrrrrr                                  eeaaaaaaaaaommmmmm                                         .............(C>u%%%%%%%%%%%%%%%%%%%%"hb,SSSSSSSSSSSSSSppppppppppppppptttttttttttttttttcccccccccccsgfiiiiiiiiiiiillllllllllneaaaaaaaaaomdddddd                                        eaaaaaaaaaorrrrrrrrrrrrrrrrrrrrrrrrrr            )ttttttttttttssssssssssimlllllllllllllleaaaaaaaaaornnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn              eaaaaaaaaaooooooooooooooooooooodd-=R	A$$$$$$$$$$$$$$$$$$$!/O13333333333333333332:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::0wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww.......................T(My>vvvvvvvvvvvvv%C"ubbbbbbbbbbbbbbbbbbbbShp,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,ggggggggggggggggggggggggg)cttttttttttttssssssssssimlrrrrrr              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoonnnnnn              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatdsfiiiiiiiiiiiillllllllllonmmmmmm              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaorrrrrr                                  ee"(.LS%CCCCCCCCCCCCCCCCCCCCCCCCCCCCCbbbbbbbbbbbbbbbbbbbbu)p,httttttttttttttgsssssssssssidlfffffffffffffffnnnnnnnnnnnnaaaaaaaaaorrrrrrrrrrrrrrr                                         eaaaaaaaaaommmmmm                                 sitlllllllllllndrcccccccceaaaaaaaaaommmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm               eaaaaaaaaaooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV4UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU7W

















































































&8+++++++++++++++++++++++++++]*H66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;_EEEEEEEEEEEEEEEEEEE''''''''''''''''''''''''''''''''''''[GBkkkkkkkkkkkkkkkkkkkkkkkkkkFFFFFFFFFFFFFFFFFFFFFFFFFIIIIIIIIIIIIIIIIIIIIIIIIIIIIII5@DP:-=R	A$$$$$$$$$$$$$$$$$$$$$$M/O13333333333333333332!.....................00000000000000000000000wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwC"(>TTTTTTTTTTTTTTTTTTTTS%LNy,,,,,,,,,,,,,,,,,bbbbbbbbbbbbbf)puihhhhhhhhhhhhhhlsntrrrrrrrrrrrmd              eaaaaaaaaaoooooooooooooooooooooooooooooocggggggggggggggggg              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoolnirsmtttttttttttttttttttttttttttttttdddddd              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoooooooooooooooooooo              eeeeeeeeeeeeeeeeeeeeeaa%C"(bbbbbbbbbbbbbbbbbbbbS.p,,,,,,,,,,,,,,,,,vcf)))))))))))))nuhrlmiiiiiiiiiisssssssssssstttttttttooooooooooooooooooooooooooooooooooooooooooo                                  eeaaaaaaaaaodddddd                                         rmnnnnnnnnnnlllllllllllligseaaaaaaaaaodtttttt                                        eaaaaaaaaaoooooooooooooooooooooooooooooooooooo  2:-=R	A$>M/O1333333333333333333333333333333333333"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""0!wS%Cjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjbbbbbbbbbbbbbbbbbbbb()p,...............cfvTmmmmmmmmmmmmmuuuuuuuuuurrrrrrrrrrrrnghldiiiiiiiiiiiiiieaaaaaaaaaooooooooooosssssssssssssssssssssssssssssss              eaaaaaaaaaooooooooooooooooooooottmmmmmmmmmmrrrrrrrrrrrrnnnnnnnnnnnnnnldiiiiiiiiiiiiiiii              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoossssss              eaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaS%C,,,,,,,,,,,,,,,,,b"f)p(gggggggggggggggc.myyyyyyyyyyyyyrtnnnnnnnnnnlllllllllllliiiiiiiiiiiiiiuosdddddd              eeeeeeeeeeeeeeeeeeeeeaaaaaaaaaaoooooooooooooooo                                  eernmltiiiiiiiiiissssssssssssaaaaaaaaaooooooooooohhhhhh                                         eaaaaaaaaaodddddd                                                      
+++++++++++++++++++++++++++]*H66666666666666666666666666666666<Kx;;;;;;;;;;;;;;;;;;;;;;;;;;;;AG|k[FBIIIIIIIIIIIIIIIIIIIIIIIIII5555555555555555555555555DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD@@@@@@@@@@@@@@@@@@2:-=R	LPj>M/O13$%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0bbbbbbbbbbbbbbbbbbbbSvwp,,,,,,,,,,,,,,,,,Ccf)""""""""""""""ggggggggggggggg(n.yyyyyyyyyyyyyyyylrimsttttttttttttttttttttttttttteaaaaaaaaaoddddddddddddd