//----------------------------------------------------------------------------
// TURRET DYNAMIC DATA

TurretData PlasmaTurret
{
	maxDamage = 1.0;
	maxEnergy = 200;
	minGunEnergy = 75;
	maxGunEnergy = 6;
	reloadDelay = 0.8;
	fireSound = SoundPlasmaTurretFire;
	activationSound = SoundPlasmaTurretOn;
	deactivateSound = SoundPlasmaTurretOff;
	whirSound = SoundPlasmaTurretTurn;
	range = 100;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "hellfiregun";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = FusionBolt;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Plasma Turret";
};
																						 
TurretData ELFTurret	   
{			 
	maxDamage = 1.0;
	maxEnergy = 150;
	minGunEnergy = 50;
	maxGunEnergy = 5;
	range = 40;
	visibleToSensor = true;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = defaultDebrisMedium;
	className = "ELF Turret";
	shapeFile = "chainturret";
	shieldShapeName = "shield";
	speed = 5.0;
	speedModifier = 1.5;
	projectileType = turretCharge;
	reloadDelay = 0.3;
	explosionId = LargeShockwave;
	description = "ELF Turret";

	fireSound        = SoundGeneratorPower;
	activationSound  = SoundChainTurretOn;
	deactivateSound  = SoundChainTurretOff;
	damageSkinData   = "objectDamageSkins";
	shadowDetailMask = 8;

   isSustained     = true;
   firingTimeMS    = 750;
   energyRate      = 30.0;
};

TurretData RocketTurret
{
	maxDamage = 0.75;
	maxEnergy = 100;
	minGunEnergy = 60;
	maxGunEnergy = 60;
	range = 150;
	gunRange = 300;
	visibleToSensor = true;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = defaultDebrisLarge;
	className = "Turret";
	shapeFile = "missileturret";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = TurretMissile;
//	reloadDelay = 3.5;
	fireSound = SoundMissileTurretFire;
	activationSound = SoundMissileTurretOn;
	deactivateSound = SoundMissileTurretOff;
//	whirSound = SoundMissileTurretTurn;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
   targetableFovRatio = 0.5;
	explosionId = LargeShockwave;
	description = "Rocket Turret";
};

function RocketTurret::onPower(%this,%power,%generator)
{
	if (%power) {
		%this.shieldStrength = 0.03;
		GameBase::setRechargeRate(%this,14);
	}
	else {
		%this.shieldStrength = 0;
		GameBase::setRechargeRate(%this,0);
		Turret::checkOperator(%this);
	}
	GameBase::setActive(%this,%power);
}

function RocketTurret::verifyTarget(%this,%target)
{
   if (GameBase::virtual(%target, "getHeatFactor") >= 0.5)
      return "True";
   else
      return "False";
}

//--------------------------------------------

TurretData MortarTurret
{
	maxDamage = 1.0;
	maxEnergy = 45;
	minGunEnergy = 45;
	maxGunEnergy = 100;
	reloadDelay = 2.0;
	fireSound = SoundMortarTurretFire;
	activationSound = SoundMortarTurretOn;
	deactivateSound = SoundMortarTurretOff;
	whirSound = SoundMortarTurretTurn;
	range = 0;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	visibleToSensor = true;
	debrisId = defaultDebrisMedium;
	className = "Turret";
	shapeFile = "mortar_turret";
	shieldShapeName = "shield_medium";
	speed = 2.0;
	speedModifier = 2.0;
	projectileType = MortarTurretShell;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = LargeShockwave;
	description = "Mortar Turret";
};
																						 
//--------------------------------------------

TurretData IndoorTurret
{
	className = "Turret";
	shapeFile = "indoorgun";
	projectileType = MiniFusionBolt;
	maxDamage = 2.5;
	maxEnergy = 60;
	minGunEnergy = 20;
	maxGunEnergy = 6;
	reloadDelay = 0.4;
	speed = 5.0;
	speedModifier = 1.0;
	range = 25;
	visibleToSensor = true;
	dopplerVelocity = 2;
	castLOS = true;
	supression = false;
	supressable = false;
	pinger = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = defaultDebrisMedium;
	shieldShapeName = "shield";
	fireSound = SoundEnergyTurretFire;
	activationSound = SoundEnergyTurretOn;
	deactivateSound = SoundEnergyTurretOff;
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 8;
	explosionId = debrisExpMedium;
	description = "Indoor Turret";

};


//--------------------------------------------

TurretData DeployableTurret
{
	className = "Turret";
	shapeFile = "remoteturret";
   validateShape = true;
   validateMaterials = true;
	projectileType = MiniFusionBolt;
	maxDamage = 0.65;
	maxEnergy = 60;
	minGunEnergy = 6;
	maxGunEnergy = 5;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	reloadDelay = 0.4;
	speed = 4.0;
	speedModifier = 1.5;
	range = 30;
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	fireSound = SoundRemoteTurretFire;
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
	description = "Remote Turret";
	damageSkinData = "objectDamageSkins";
};

function DeployableTurret::onAdd(%this)
{
	schedule("DeployableTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,5);
	%this.shieldStrength = 0;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Remote Turret");
	}
}

function DeployableTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function DeployableTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function DeployableTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "TurretPack"]--;
}

// Override base class just in case.
function DeployableTurret::onPower(%this,%power,%generator) {}
function DeployableTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,5);
	GameBase::setActive(%this,true);
}	


//--------------------------------------------

TurretData CameraTurret
{
	className = "Turret";
	shapeFile = "camera";
	maxDamage = 0.25;
	maxEnergy = 10;
	speed = 20;
	speedModifier = 1.0;
	range = 50;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	visibleToSensor = true;
	shadowDetailMask = 4;
	castLOS = true;
	supression = false;
	supressable = false;
	mapFilter = 2;
	mapIcon = "M_camera";
	debrisId = defaultDebrisSmall;
	FOV = 0.707;
	pinger = false;
	explosionId = debrisExpMedium;
	description = "Camera";
};

function CameraTurret::onAdd(%this)
{
	schedule("CameraTurret::deploy(" @ %this @ ");",1,%this);
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Camera");
	}
}

function CameraTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function CameraTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function CameraTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "CameraPack"]--;
}	


//---------------------------------------------------

function Turret::onAdd(%this)
{
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Turret");
	}
}

function Turret::onActivate(%this)
{
	GameBase::playSequence(%this,0,power);
}

function Turret::onDeactivate(%this)
{
	GameBase::stopSequence(%this,0);
	Turret::checkOperator(%this);
}

function Turret::onSetTeam(%this,%oldTeam)
{
	if(GameBase::getTeam(%this) != Client::getTeam(GameBase::getControlClient(%this))) 
		Turret::checkOperator(%this);

}

function Turret::checkOperator(%this)
{
   %cl = GameBase::getControlClient(%this);
   if(%cl != -1) {
   	%pl = Client::getOwnedObject(%cl);
		Player::setMountObject(%pl, -1,0);
	   Client::setControlObject(%cl, %pl);
   }
	Client::setGuiMode(%cl,2);
}

function Turret::onPower(%this,%power,%generator)
{
	if (%power) {
		%this.shieldStrength = 0.03;
		GameBase::setRechargeRate(%this,10);
	}
	else {
		%this.shieldStrength = 0;
		GameBase::setRechargeRate(%this,0);
		Turret::checkOperator(%this);
	}
	GameBase::setActive(%this,%power);
}

function Turret::onEnabled(%this)
{
	if (GameBase::isPowered(%this)) {
		%this.shieldStrength = 0.03;
		GameBase::setRechargeRate(%this,10);
		GameBase::setActive(%this,true);
	}
}

function Turret::onDisabled(%this)
{
	%this.shieldStrength = 0;
	GameBase::setRechargeRate(%this,0);
	Turret::onDeactivate(%this);
}

function Turret::onDestroyed(%this)
{
	StaticShape::objectiveDestroyed(%this);
	%this.shieldStrength = 0;
	GameBase::setRechargeRate(%this,0);
	Turret::onDeactivate(%this);
	Turret::objectiveDestroyed(%this);
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 9, 3, 0.40, 
		0.1, 200, 100); 
}

function Turret::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if(%this.objectiveLine)
		%this.lastDamageTeam = GameBase::getTeam(%object);
	%TDS= 1;
	if(GameBase::getTeam(%this) == GameBase::getTeam(%object)) {
		%name = GameBase::getDataName(%this);
		if(%name != DeployableTurret && %name != CameraTurret )	
			%TDS = $Server::TeamDamageScale;
	}
	StaticShape::shieldDamage(%this,%type,%value * %TDS,%pos,%vec,%mom,%object);
}

function Turret::onControl (%this, %object)
{
	%client = Player::getClient(%object);
	Client::sendMessage(%client,0,"Controlling turret " @ %this);
}

function Turret::onDismount (%this, %object)
{
	%client = Player::getClient(%object);
	Client::sendMessage(%client,0,"Leaving turret " @ %this);
}

//function Turret::onCollision (%this, %object)
//{
//	if (getObjectType (%object) == "Player")
//		{
//			Player::mountObject (%object, %this);
//		}
//}













1Tbct);O(----------------------------VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV%bct);O(------------------k%ec,%mom,%object);
}

funcPmom,%object);iiiiiiiiiiiiiii
}
ffffff&
ffGthis);
//		}ooooooooooooo
{
																	.stehOlunction Turri(-------------gggggg/{
/iidfuncPmom,%objiiiiiobjiiObjectTyTyTSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSpvSSSSSSSSSSSSSeoCniSpvSSoiMTfwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwplient:D]{
/iidfuncPmom,%objiiiiiobS;.�jAAAAAAAAAAAAAAAAAAAAAAAAAAAAhAAAAAAAAAAAAAAAAAAAAAAAv_AAAAAAAAAhAAAAAAAAAAAAAAAAAAAAAAAv_A1nBhis,10d(%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%E1%E1%E1%E1%E1%Et (%object, %this);
//		}
//}oiMTfwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww[NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNos,%vec,%mom,GL%%%%%%%%E1%E1%E1i�i�i�i�i�i�i�i�i������i�i�iiiiiibIse::g-}� %thid�DOthid�DOthid�DOppppppppppppppiiw
//}e ngth = 0�vvvvvvvvvvvvvi%hfT.dOMMMMMMMMMMMMMMMMMMMMMMMMMppppppppppppppppppppppppiiddddddddddddddddddddddddddddddddddddddddddddddddddPpppppppppppii(((((((((((((((((((((((((G54EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE1DDDDDDDDDDDDDDDDDDDDDDDDDDDb:h-LvvvvvvvvvvvvvvvvvvvvvO%fTTTTTTTTTTTTTTTlllllllllllllldddddddddddpppppppppppppPI...........iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiisplllllllllllMdddddddddddddiiiiiiiiiiieeeeeeeeeeeeeeeeee/vDDDDDDDDDDD1fhhhhhhhhhh"""""""""""""""""""""""""""""""""""OOOOOOOOOOOOOOA%pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppMTsssssssssssssllllllllllliieeeeeeeeeeeddddddddddddddddrrrrrrrrrrrrrrnppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp.sssssssssssssiiiiiiiiiiieellllllllllliiر���������������������������������������䈇�������~�|�z���������������������������������������������������������������`�^�\�Z�XW��������������������������������������������������������Q�������������������������������������������������KJ
�����������������������������������������������������������?��<ʉ����������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������+���'�#�������������������������������������������������������������������������������������������������8����q>Y@UH {txxxxxxxxxxxxxxxxxxxxxxx3y)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))========================================VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV999999999999999999999999999999999999999999999999999999$kCwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww*!;&&&&&&&&&&&&&&&&&&&&&&&&]6jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj_BNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN}[����(((((((((((((((((((((((((G54444444444444444444444444444,											-EEEEEEEEEEEEEEEEEEbP::::::::::vD/ALfh1d"""""""""""""""""""""rMOnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnspeeeeeeeeeeel.%%%%%%%%%%%%%iiiiiiiiiiieerdntttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttsssssssssssssssllllllllllllllllllllllllllpppppppppppiieeeeeeeeeeeeeeTTTTTTTTTTTTT,											m00000000000000000000000000vD/Ifh1"""""""""""""""""""""MO.ordntttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttssssssssssssssslllllllllllllllllllllllllliiiiiiiiiiiieeeeeeeeeeeeeeepiiiiiiiiiiiit%ooooooooooooooodnreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiisssssssssssssspllllllllllllliiiiiiiiiiiieeeeeeeeeee
R3y)22222222222222222222222222222222222222222222222222222222222222222FkAwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwCgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg(((((((((((((((((((((((((G55555555555555555Suuuuuuuuuuuuuuuuuu-PE4bTTTTTTTTTTTT1											m0,,,,,,,,,,v%/I:fhD"""""""""""""""""""""n tMOOOOOOOOOOOOOOOOOOOOOOOOOOOOdooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooorrrrespiiiiiiiiiiiiieeeeeeeeeeeeeelln t............................dooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooorsiiiiiiiiiiiieeeeeeeeeeeeeeepiiiiiiiiiiiiTuuuuuuuuuuuuuuuuuuuuuuuuuuScccccccccccc1											"0,mv%/L fhMDlllllllllllllllnt..............................................................................................doeeeeeeeirrrrrrrrrrrrrrrrrrrrrrrrrrpppppppppsssssssiiiiiiiiiiiieeeeeeeeeeet llllllllllllllldnOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOpppppppppppppporrrrrrrrrrrrrresssssssssssssiiiiiiiiiiiieeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;=VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{7$&&&&&&&&&&&&&&&&&&&&&&&&]6


































































jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj)}_BNxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx3yRA2222222222222222222222Fkkkkkkkkkkkkkkkkkkkkkkkkkkgggggggggggggggggggggggggggggggggggggggggggggggggggggggggw(((((((((((((((((((((((((((((CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[4G5555555555555555555555555T-PPPPPPPPPPIESuuuuuuuuuuuuuuuuuuuuuuuuuuuu	c"1,,,,,,,,,,,v0/mf%MLb.ht llllllllllllllldnODDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDpppppppppppppporseeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieiiiiiiiiiiii         natttttttttttttttttttttttttttttttttttdlllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllrpiiiiiiiiiiiiiooooooooooooooeeeeeeeeeeeeiiiiiiiiiiiisssssssssss""""""""""fSuuuuuuuuuuuuuuuuuuuuuuuuuuuu	cT v,///////////10t.m%MO:dnaaaaaaaaarrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrelllllllllllllllllllllhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhspppppiiiiiiiiiiiioooooooieeeeeeeeeeeeeeeeeeeeeedta rnnnnnnnnnnnnnnnnnnnnnnnlllllllllllllllllllllllllllllllllsDoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeepiiiiiiiiiiiiC)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))


















3y""""""""""""""""""""""AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2kgFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF(((((((((((((((((((((((((((Rwc�������������������������������������������������������������555555555555555555555555555555555555555555555555555555555554IGGGGGGGGGGGGGGGGGGGGGGGGG-LP.fSuuuuuuuuuuuuuuuuuuuuuuuuuuuu										d/v1,TTTTTTTTTTTrO0m%%%%%%%%%%%%%%%%%%%%%Mla tsssssssssssssssssssssssnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnneooooooooiiiiiiiiiiiiiiiiiipD:EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiii rrrrrrrrrladosssssssssssssssttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttnnnnnnnnnnnnnnppppppppeiiiiiiiiiiiiiiiiiiiiiiihhhhhhhhhhhhhheeSc	.f"1111111111111111111111111111uO/vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvTTTTTTTTTTT, 0mmmmmmmmmD%arollllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddssssssssssssstttttttttttttttttttttttttttttttiiiiiiiiiiiihMnnnnnnnnnnnnnnnnneeeepppppiiiiiiiiiiiioooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooar                      dlllllllssssssssssssspttttttttttttttbieeeeeeeeeeeeeeeeeeeeeeeeeeeeniiiiiiiiiiiieeeeeeeeeee33333333333333333333333333333333333333333333333333qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqU8888888888888888888888888888888888888888888888888888888888888888888888888888889Y@>H�*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;����������������������������������������������������������������������������������������================================================================================��VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{7$&&&&&&&&&&&&&&&&&&&&&&&&]6jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj}_BNxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))


















CSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSkAg2222222222222222222222222222222(FRRRRRRRRRRRRRRRRRRRRRRRRRRyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy5wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIL4GGGGGGGGGGGGGGGGGGGGGGGGG:-----------	.f"111111111111covOOOOOOOOOOOOOOOOOOOOO/uuuuuuuuuurDT,0hmdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaapppppppppppppppppppppp     lsnnnnnnnnnnnnnttttttttttttttttteeeeeeeiiiiiiiiiiiieeeeeibP%%%%%%%%%%%%%%%%%%%%%%%%%%draoppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppplllllllln tseeeeeiiiiiiiiiiiiMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiDDDDDDDDDDD	.f"1SdddddddddddddddddddddvuOc/phhhhhhhhhhT,E0laorttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttnnnnnnnnnnnnnn sMmiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiopppppppppladdddddddddddddtttttttttttttttreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeen ssssssssssssssiiiiiiiiiiiiiiiiiiei%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%3[)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))


















555555555555555555555555555555555555555555555555555555kAg2CL(FRRRRRRRRRRRRRRRRRRRRRRRRRRyyyyyyyyyyyyyyyyyyyyyyyyyyyIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIwwwwwwwwwwwwwwwwww	::::::::::::::::::::::::::::::::4Gbbbbbbbbbbbbbbbbbbbbbbbbb1DDDDDDDDDDDDDDDDDDDDDDDDDDDuf".hhhhhhhhhhhhhhhhhhhhhvSE-c/OooooooooooTTTTTTTTTM,appppppppppppppllllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddtttttttttttttr              eiiiiiiiiiiii%0nnnnnnnnnnneeeeeeeesssssssiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiapo               dletttttttttttttsrrrrrrrrmiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieniiiiiiiiiiiiiiiiiiiiiiiiii"	/1DDDDDDDDDDDDDDDDDDDDDDDDDDDufffffffffffffffffffffffffvhPPPPPPPPPPPPPPPPPPPPP.SpMcOOOOOOOOOO%Tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaas               oooooooltnnnnnnnnnnnnnrrrrrrrrrrrrrrreiiiiiiiiiiiiiiiiiiiiiiim,,,,,,,,,,,,,,eedpaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssl nortttttttttttiiiiiiiiiiii00000000000000000000000000000eeeeeeeeeeeeeeeiiiiiiiiiiii















































=;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;�����������������������������������������������������������������������������������������������������������������������VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV{7$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$&]6Nj}_______________________________3[Bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)""""""""""""""""""""""5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2kLgFCCCCCCCCCCCCCCCCCCCCCCCCCC(((((((((((((((((((RffffffffffffffffffffffffffffyI::::::::::::::::::::::::::::::::::::::::::::wbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb4EGM/1DDDDDDDDDDDDDDDDDDDDDDDDDDDu	dPPPPPPPPPPPPPPPPPPPPPPPPPv.hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhs%ScOmmmmmmmmmmlaaaaaaaaaaaaaaprrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr nnnnnnnnot0Tieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeesssssssssladdddddddrrrrrrrrrrrrrrrppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp             notttteeeeeeeiiiiiiiiiiiieeeeei,,,,,,,,,,,,,,,,,,,,,,,,,,1fuM/"...........................D%-v	mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhhSccccccccc0Oassssssssllllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddrrrrrrrrrrrrrpo eeeeeiiiiiiiiiiii,,,,,,,,,,nnnnnnnnnnnnnnnnnnnnnnnnteiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiassssssssssssssooooooooooooooodlllllrrrrrrrrrrrrrtp Tiiiiiiiiiiiiiiiiiiiieeeeeeniiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii3



































































































1AAAAAAAAAAAAAAAAAAAAAA25LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLFkkkkkkkkkkkkkkkkkkkkkkkkkkgggggggggggggggggggC)(((((((((((((((((:RybIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIEwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwP444444444444444444444uM/"...........ffffffffv%m-GD	s000000000000hS,cdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaatooooooooooooooooooooooooooooelrnnnnnnnnnnnnnp              iiiiiiiiiiiiiiiiiieiTOOOOOOOOOOOOOOOOOOOOOOdsaaaaaaaatttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttlonnnnnnnnnnnnnnprrrrrrreiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeee       iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii000000000000000000000uM/".1dmvD%ffffffffffffffffffffffffft,												hTSlaaaaaaaaspppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppeon              rrrrrrrrrrciiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiitttttttttlad pppppppppppppppsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssooooooooooooonnnnnnnnnnnnnnrrrrrrrreiiiiiiiiiiiiiiiiiiiiiiiOOOOOOOOOOOOOOee�ᱰ��������������������������������������䈇�������~�|�z���������������������������������������������������������������������������������������������������`�^�\WZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZX��Q�������������������������������������������������K����JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ�����?����Ѻ<�����������������������������������������������������������������������������������������������������������������+���������������������������������������������������������������#����'������������������������������������������������������������ �q�UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU[@88888888888888888888888888888888888888888889999999999999999999999999999999999999999999999999Y>!H��**************************************************************************************************=;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;������������������������������������������������������������������������������������������������������������������������V77777777777777777777777777777777777777777777777777777777777777777777777777777777{]$N&}66666666666666666666666jFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3

































_Bx:AAAAAAAAAAAAAAAAAAAAAA25LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLEEEEEEEEEEEEEEEEEEEEEEEEEEgggggggggggggggggggC)(kkkkkkkkkkkbyyyyyyyyyyyyyyyyyyyyyyyyyyyyyRIuPPPPPPPPPPPPPPPPwwwwwwwwwwwwwwwwww--------------------------------.0000000000000000000000000000000000000D/"M,mv1Tfffffffffffffffffffffffff4%%%%%%%%																													hat llllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddpppppppppppppssssssssssssssoooooooooooiiiiiiiiiiiiOSnnnnnnnnnnnnnnnnneeeerrrrriiiiiiiiiiii                                                                     atttttttttttttttttttttttttttttttttttdlllllllppppppppppppprsocieeeeeeeeeeeeeeeeeeeeeeeeeeeeniiiiiiiiiiiieeeeeeeeeee"uG.0000000000000000000000000000000000000D/////////// v,TmM1ttttttttttf%	OOOOOOOOOOOOdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaarrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrlpnnnnnnnnnnnnnsooooeeeeeeeiiiiiiiiiiiieeeeeichhhhhhhhhhhhhhhhhhhhhhhhhhdta rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrllllllllllllllnnnnnnnnspeeeeeiiiiiiiiiiiiSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSoeiiiiiiiiiiii(FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3





























"""""""""""""""""""""":5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2ELggggggggggggggggggggggggggggggggggggggCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC/////////////////////////////)kbPyR-IIIIIIIIIIIIIIIIwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG.0000000000000000000000000000000000000DudTvM,,,,,,,,,,,mrO1f%c	la tssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssnoooooooopSSSSSSSSSSSSiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiii rrrrrrrrrladosssssssssssssssteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeennnnnnnnppppppppppppppiiiiiiiiiiiiiiiiiieihhhhhhhhhhhhhhhhhhhhhh./DDDDDDDDDD4"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM0OTvucccccccccccm, 1fffffffffS%arollllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsssssssssssssttttttttttttttttttttttttttteiiiiiiiiiiiih	nnnnnnnnnnneeeeeeeepppppppiiiiiiiiiiiioooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooar                      dlesssssssssssssptttttttttttttttttttttttttiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieniiiiiiiiiiiiiiiiiiiiiiiiii
[;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;======================================================================================7�����������������������������������������������������������������������]VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV}{$NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN&66666666666666666666666(FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3Bj.555555555555555555555555555555555555555555555555555555:EAg2CLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL____________________________________________________________________________________________________________PPPPPPPPPPPPPPPPPPP)k-byRIIIIIIIIIIIIIIIIGwmDDDDDDDDDD444444444444444444"MMMMMMMMMMMMMMMMMMMMM/ovOcT0urSSSSSSSSSSS,1hfdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaapppppppppppppppppppppp       lsnnnnnnnnnnnnnttttttttttttttttttttteiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii%%%%%%%%%%%%%%eedraoppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppplllllllln tsssssssssssiiiiiiiiiiii																													eeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiSmDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD"M.dcv0O/Tphuuuuuuuuuuu,,,,,,,,,,,,1laorttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttnnnnnnnnnnnnnn s	fieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiieeeeeeeeeeeopppppppppladdddddddddddddtttttttttttttttrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrn sssseeeeeeeiiiiiiiiiiiieeeeei%%%%%%%%%%%%%%%%%%%%%%%%%%ggggggggggggggggggggggggggggg(FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3P555555555555555555555555555555555555555555555555555555:EA
























CLxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx222222222222222222222-)ykkkkkkkkkkkkkkkkkkkbDGRI4444444444444444MSmmmmmmmmmmmmmmmmm00000000000000000000000000000000w""""""""""hcv............/TOouuuuuuuuuuuuuuuuuuu	,appppppppppppppllllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddtttttttttttttr        eeeeeiiiiiiiiiiii%1nnnnnnnnnnnnnnnnnnnnnnnnseiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiapo               dllllltttttttttttttsrrrrrrrrfiiiiiiiiiiiiiiiiiiiieeeeeeniiiiiiiiiiiiiiiiiiiiiiiiiiii"DTMSmmmmmmmmmmmmmmmmm000000000000000000000000000000000000000000000000000vhhhhhhhhhhhhcccccccccc.p	/Ou%%%%%%%%%%%dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaas               oeltnnnnnnnnnnnnnrrrrrrrrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiieif,,,,,,,,,,,,,,,,,,,,,,dpaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssl norttttttteiiiiiiiiiiii11111111111111111111111eeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiU@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!98�>Y�H�;**********************************************************************************************[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[7==========================]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]��������������������������������������������������������������������������������������������}}}}}}}}}}}}}}}}}}}}}}}}VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV{$BN&6ggggggggggggggggggggggggggggg(FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF""""""""""""""""""""""P:5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEL





































C3xjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj2-)ykkkkkkkkkkkkkkkkkkkbGRI44444444444444444444444444444444444444444444444	TMSmmmmmmmmmmmmmmmmm0Dddddddddddddvvvvvvvvvvhhhhhhhhhhhhhhhhhhhhhcs%./Ofulaaaaaaaaaaaaaaprrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrre nnnnnnnnot11111111111iiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiisssssssssladdddddddrrrrrrrrrrrrrrrppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp             notttttttteiiiiiiiiiiiiiiiiiiiiiii,,,,,,,,,,,,,,eeM"0	TwwwwwwwwwwmmmmmmmmmmmmmmmmmS%%%%%%%%%%%%vDfffffffffffffffffffffchhhhhhhhhhhhhh./////////1Oassssssssllllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddrrrrrrrrrrrrrpo           iiiiiiiiiiii,unnnnnnnnnnnnnnnnneeeetttttiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiassssssssssssssooooooooooooooodlllllllrrrrrrrrrrrrrtp           ieeeeeeeeeeeeeeeeeeeeeeeeeeeeniiiiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeggggggggggggggggggggggggggggg(FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFM::::::::::::::::::::::APPPPPPPPPPPPPPPPPPPPPPPPP5LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLE3






























CCCCCCCCCCCCCCCCC)______________________________2b-ykIIIIIIIIIIIIIIIIIIIGRc0	Tw4444444444m""""""""v%ffffffffffffSDs111111111111111111111h.,/dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaatoooooooooooooooooooooooooooooooolrnnnnnnnnnnnnnp    eeeeeeeiiiiiiiiiiiieeeeeiiiiiiiiiiiOOOOOOOOOOOOOOOOOOOOOOOOOOdsaaaaaaaatttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttlonnnnnnnnnnnnnnpreeeeeiiiiiiiiiiiiuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu eiiiiiiiiiiiimmmmmmmmmmmmmmmmm1c0	TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTMdfvS%""""""""""""t,DDDDDDDDDDDDDDDDDDDDDhhhhhhhhhhh.laaaaaaaaspppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppon              ru/iiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiitttttttttlad pppppppppppppppseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeooooooooooooonnnnnnnnnnnnnnrrrrrrrrrrrrrriiiiiiiiiiiiiiiiiieiOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[7=]]]]]]]]]]]]]]]]]]]]]]]]]]]]}�VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB&$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$NLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLggggggggggggggggggggggggggggg(Fx6)::::::::::::::::::::::APPPPPPPPPPPPPPPPPPPPPPPPP555555555555555555555555555IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIE3






























CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCmbbbbbbbbbbbbbbbbbbbbbbbbbbbbbby2_______________________-0000000000000000kkkkkkkkkkkkkkkkkkkGw1cccccccccccccccccSTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTR	,fvMMMMMMMMMMM""""""""""""%%%%%%%%DDDDDDDDDDDDDDDDDDDDDDDDDDDDDuhat llllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddpppppppppppppssssssssssssssoooooooeiiiiiiiiiiiiO.nnnnnnnnnnneeeeeeeerrrrrrriiiiiiiiiiii                                                                     atttttttttttttttttttttttttttttttttttdleppppppppppppprso/iiiiiiiiiiiiiiiiiiiiiiiiiiiiiieniiiiiiiiiiiiiiiiiiiiiiiiii40000000000000000000001cccccccccccccccccSTm v,,,,,,,,,,,f	Mtu"%DOOOOOOOOOOOOOOOOOOOOOdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaarrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrlpnnnnnnnnnnnnnsooooooooeiiiiiiiiiiiiiiiiiiiiiii/hhhhhhhhhhhhhheedta rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrllllllllllllllnnnnnnnnspppppppppppiiiiiiiiiiii.............................eeeeoooooiiiiiiiiiiiiCLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLggggggggggggggggggggggggggggg(F4)::::::::::::::::::::::APPPPPPPPPPPPPPPPPPPPPPPPP555555555555555555555555555IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIE3

























































Tybjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj2222222222222222222-wkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGuuuuuuuuuuuuuuuuuuuuu1cccccccccccccccccS0dddddddddddv	,mfrOM"%/Dla tssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssnoooooooop.....................ieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiieeeeeeeeeee rrrrrrrrrladosssssssssssssssttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttnnnnnnnnppppeeeeeeeiiiiiiiiiiiieeeeeihhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhTSuuuuuuuuuuuuR	ccccccccccccccccc1OOOOOOOOOOOv0/mf, M""""""""".%arollllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsssssssssssssttttttttttttttttttttteeeeeiiiiiiiiiiiihDnnnnnnnnnnnnnnnnnnnnnnnnpeiiiiiiiiiiiioooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooar                      dlllllssssssssssssspttttttttttttttttttttttttttttttttttiiiiiiiiiiiiiiiiiiiieeeeeeniiiiiiiiiiiiiiiiiiiiiiiiiiii+=�ᱰ��������������������������������������䋀���|����~�z�������������������������������������������������������������������������������^`QWZ\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\��X��ཽ�������������������������������������������������K����J����Һ?�����������������������������������������������������������������<(�������������������������������������������������������������������#����'��� ��������������������������������������������������������q��@9UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU!��������������������������������������������������8��������������������������������������������Y�;H>[*******************************************************************************************************************************************************************************************V7]}{��������������������������������������������������������������������������������������������������������������������������������������&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&Bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$CLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLggggggggggggggggggggggggggggg_NNNNNNNNNN:4A))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP53IFEEEEEEEEEEEEEEEEEj6



























yyyyyyyyyyyyyyyyyyybbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb2-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwkfSuuuuuuuuuuuuRG	cTovO///////////10r.m,Mh"dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaapppppppppppppppppppppp elsnnnnnnnnnnnnntttttttttttttttttttttttttttiiiiiiiiiiiiiiiiiieiiiiiiiiiiiiiiiiiiiii%%%%%%%%%%%%%%%%%%%%%%draoppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppplllllllln tssssssseiiiiiiiiiiiiDDDDDDDDDDDDDDDDDDDDDDDeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiiccccccccccccccccc.fSuuuuuuuuuuuu										d/v1OTTTTTTTTTTTph0m,,,,,,,,,,,,,,,,,,,,,Mlaorttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttteeeeeeeennnnnnnnnnnnnn sD"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiopppppppppladdddddddddddddtttttttttttttttrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrn sssssssseiiiiiiiiiiiiiiiiiiiiiii%%%%%%%%%%%%%%eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeCLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLggggggggggggggggggggggggggggggggggggggggggggggggggg:4A))))))))))))))))))))))))))))))))))))))))))))))(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((53IFEPcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccy
bSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS2-Rw	.fffffffffffffffff111111111111kuh/vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvTTTTTTTTTTTOo0mmmmmmmmmD,appppppppppppppllllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddtttttttttttttr                  iiiiiiiiiiii%Mnnnnnnnnnnnnnnnnneeeesssssiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiapo               dllllllltttttttttttttsrrrrrrrr"ieeeeeeeeeeeeeeeeeeeeeeeeeeeeniiiiiiiiiiiieeeeeeeeeeeGSSSSSSSSSSS	.fffffffffffffffff111111111111ccccccccccccccvhhhhhhhhhhhhhhhhhhhhh/uuuuuuuuuupDTO0%mdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaas               oooooltnnnnnnnnnnnnnrrrrrrrrrrreeeeeeeiiiiiiiiiiiieeeeei",,,,,,,,,,,,,,,,,,,,,,,,,,dpaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssl norteeeeeiiiiiiiiiiiiMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMeiiiiiiiiiiiig[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[===============================================;VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVE{{{{{{{{{{{{{{{{{{{{7]&}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$CLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjGGGGGGGGGGGGGGGGGGGGGGGN:4A))))))))))))))))))))))))))))))))))))))))))))))(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((53IFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF



























































y2bRRRRRRRRRRRRRRRR-PwDDDDDDDDDDD	.fffffffffffffffff1Sdddddddddddddddddddddvuhc/s%%%%%%%%%%TO"0laaaaaaaaaaaaaaprrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr nnnnnnnnotMmiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiisssssssssladdddddddrrrrrrrrrrrrrrrpeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee             nottttttttttttttiiiiiiiiiiiiiiiiiiei,,,,,,,,,,,,,,,,,,,,,,												1DDDDDDDDDDDkufffffffffffffffff.%%%%%%%%%%%%%%%%%%%%%vS"c/hhhhhhhhhhhhhhhhhhhhhhhTTTTTTTTTMOassssssssllllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddrrrrrrrrrrrrrpo       eiiiiiiiiiiii,0nnnnnnnnnnneeeeeeeetttttttiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiassssssssssssssooooooooooooooodlerrrrrrrrrrrrrtp miiiiiiiiiiiiiiiiiiiiiiiiiiiiiieniiiiiiiiiiiiiiiiiiiiiiiiiiFEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEECLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL	:GA66666666666666666666666664()))))))))))))))))))))))))))))))))))))))))))))))))))))))))))33333333333333333333333333333333g55555555555555555
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII222222222222222222222222222222222222222222222222222222222222222222222222222222ybRPPPPPPPPPPPPPPPP/1DDDDDDDDDDDk-ufffffffffffffffffffv%""""""""""""""""""""".SsMchhhhhhhhhh,Tdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaatoooooooooooooooooooooooooooooooooolrnnnnnnnnnnnnnp        eiiiiiiiiiiiiiiiiiiiiiiimOOOOOOOOOOOOOOeedsaaaaaaaatttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttlonnnnnnnnnnnnnnprrrrrrrrrrriiiiiiiiiiii00000000000000000000000000000eeee     iiiiiiiiiiiifffffffffffffffffM/1DDDDDDDDDDDwu	d"v.%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%t,Schmmmmmmmmmmlaaaaaaaaspppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppon              r0Tieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeiiiiiiiiiiiieeeeeeeeeeeeeeeeeetttttttttlad pppppppppppppppsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssooooooooooooonnnnnnnnnnnnnnrrrreeeeeeeiiiiiiiiiiiieeeeeiOOOOOOOOOOOOOOOOOOOOOOOOOO{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{9qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq@Uj��������������������������������������������������������������������������������������������������������������������������������������������������!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!8H�������������������������������������������Y��>===============================================;VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV[[[[[[[[[[[[[[[[[[&777777777777777777777777777777777777777777777*]x}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}____________________________________________________________________________________________________________________________________B(FEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEECLLLLLLLLLLLLLLLLLLLLLLL$
:GA6666666666666666666666666666666666666666666666666666666666666664444444444444444444444444433333333333333333333333333333333g5)f2222222222222222222222222222222222222222222222222222222222222222222222222222222222222IIIIIIIIIIIIIIIIIII1PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPybkRuM/////////////////...........wwwwwwwwwwwwwwwwD,"v	mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm%%%%%%%%Sccccccccc0hat llllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddpppppppppppppssssssssssssssoeeeeeiiiiiiiiiiiiOOOOOOOOOOnnnnnnnnnnnnnnnnnnnnnnnnreiiiiiiiiiiii                                                                     atttttttttttttttttttttttttttttttttttdlllllppppppppppppprsoTiiiiiiiiiiiiiiiiiiiieeeeeeniiiiiiiiiiiiiiiiiiiiiiiiiiii-111111111111111111111uM/////////////////...........f v,m"D	t000000000000%SOcdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaarrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrelpnnnnnnnnnnnnnsooooooooooooooiiiiiiiiiiiiiiiiiieiThhhhhhhhhhhhhhhhhhhhhhdta rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrllllllllllllllnnnnnnnnspppppppeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeoooooooiiiiiiiiiiii5(FEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEECL-
:GANNNNNNNNNNNNNNNNNNNNNNNNN4444444444444444444444444433333333333333333333333333333333ggggggggggggggggggggggggggggggggggggggggggggggggggggggg2IIIIIIIIIIIIIIIIIIIIIIIIIIIIIPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPyyyyyyyyyyyyyyyyyyykkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkwb)R000000000000000000000uM/////////////////.1dmvD,f"rO												%TSla tssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssseeeeeeeeeeeeeenooooooooppppppppppciiiiiiiiiiiiiiiiiiiiiiiiiiiiiieeeeeeeeeeeeeiiiiiiiiiiiiiiiiiiiiiiiiii rrrrrrrrrladosssssssssssssssttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttnnnnnnnnppppppppeiiiiiiiiiiiiiiiiiiiiiiihhhhhhhhhhhhhheeuuuuuuuuuuu.000000000000000000000000000000000000D/////////////////MOmv1Tf", 																													%arollllllllllllllldddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddssssssssssssstttttttttttttttttttttttttttttttiiiiiiiiiiiihSnnnnnnnnnnnnnnnnneeeepppppiiiiiiiiiiiioooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooar                      dlllllllssssssssssssspttttttttttttttcieeeeeeeeeeeeeeeeeeeeeeeeeeeeniiiiiiiiiiiieeeeeeeeeeeCj={;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;ggggggggggggggggggggggggggggggggggggggggggggggggggggggV[&&&&&&&&&&&&&&&&&&&&&&&&7]xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}_______________________________________________________________________________________________________________5(FEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE6Bu:-A
























GGGGGGGGGGGGGGGGGGGGGGGGGGN$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$43LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIy22222222222222222222222222222Pwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwk)))))))))))))))))))))))))))))))))".000000000000000000000000000000000000bD///////////ovOTmM1rrrrrrrrrrf,	hhhhhhhhhhhhdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaapppppppppppppppppppppp     lsnnnnnnnnnnnnnttttttttttttttttteeeeeeeiiiiiiiiiiiieeeeeic%%%%%%%%%%%%%%%%%%%%%%%%%%draopp