//====================================------------------
// Energy Damage FX
//====================================------------------
function Hylight::onEnergy(%client, %player)
{
	Armor::onEnergy(%client, %player);
}
//============-----
function HyMedium::onEnergy(%client, %player)
{
	Armor::onEnergy(%client, %player);
}
//============-----
function HyHeavy::onEnergy(%client, %player)
{
	Armor::onEnergy(%client, %player);
}
//============-----
function Cylight::onEnergy(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyMedium::onEnergy(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyHeavy::onEnergy(%client, %player)
{
	//No Effect On Cybrids
}
//====================================------------------
// Fusion Damage FX
//====================================------------------
function Hylight::onFusion(%client, %player)
{
	Armor::onFusion(%client, %player);
}
//============-----
function HyMedium::onFusion(%client, %player)
{
	Armor::onFusion(%client, %player);
}
//============-----
function HyHeavy::onFusion(%client, %player)
{
	Armor::onFusion(%client, %player);
}
//============-----
function Cylight::onFusion(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyMedium::onFusion(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyHeavy::onFusion(%client, %player)
{
	//No Effect On Cybrids
}
//====================================------------------
// Pulse Damage FX
//====================================------------------
function Hylight::onPulse(%client, %player)
{
	Armor::onPulse(%client, %player);
}
//============-----
function HyMedium::onPulse(%client, %player)
{
	Armor::onPulse(%client, %player);
}
//============-----
function HyHeavy::onPulse(%client, %player)
{
	Armor::onPulse(%client, %player);
}
//============-----
function Cylight::onPulse(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyMedium::onPulse(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyHeavy::onPulse(%client, %player)
{
	//No Effect On Cybrids
}
//====================================------------------
// Radiation Damage FX
//====================================------------------
function Hylight::onRadiation(%client, %player)
{
	Armor::onRadiation(%client, %player);
}
//============-----
function HyMedium::onRadiation(%client, %player)
{
	Armor::onRadiation(%client, %player);
}
//============-----
function HyHeavy::onRadiation(%client, %player)
{
	Armor::onRadiation(%client, %player);
}
//============-----
function Cylight::onRadiation(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyMedium::onRadiation(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyHeavy::onRadiation(%client, %player)
{
	//No Effect On Cybrids
}
//====================================------------------
// AntiMatter Damage FX
//====================================------------------
function Hylight::onAntiMatter(%client, %player)
{
	Armor::onAntiMatter(%client, %player);
}
//============-----
function HyMedium::onAntiMatter(%client, %player)
{
	Armor::onAntiMatter(%client, %player);
}
//============-----
function HyHeavy::onAntiMatter(%client, %player)
{
	Armor::onAntiMatter(%client, %player);
}
//============-----
function Cylight::onAntiMatter(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyMedium::onAntiMatter(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyHeavy::onAntiMatter(%client, %player)
{
	//No Effect On Cybrids
}
//====================================------------------
// ION Damage FX
//====================================------------------
function Hylight::onION(%client, %player)
{
	Armor::onION(%client, %player);
}
//============-----
function HyMedium::onION(%client, %player)
{
	Armor::onION(%client, %player);
}
//============-----
function HyHeavy::onION(%client, %player)
{
	Armor::onION(%client, %player);
}
//============-----
function Cylight::onION(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyMedium::onION(%client, %player)
{
	//No Effect On Cybrids
}
//============-----
function CyHeavy::onION(%client, %player)
{
	//No Effect On Cybrids
}
//====================================------------------
// Bullet Damage FX
//====================================------------------
function Hylight::onBullet(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function HyMedium::onBullet(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function HyHeavy::onBullet(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function Cylight::onBullet(%client, %player)
{
	Armor::onBullet(%client, %player);
}
//============-----
function CyMedium::onBullet(%client, %player)
{
	Armor::onBullet(%client, %player);
}
//============-----
function CyHeavy::onBullet(%client, %player)
{
	Armor::onBullet(%client, %player);
}
//====================================------------------
// Fire Damage FX
//====================================------------------
function Hylight::onFire(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function HyMedium::onFire(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function HyHeavy::onFire(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function Cylight::onFire(%client, %player)
{
	Armor::onFire(%client, %player);
}
//============-----
function CyMedium::onFire(%client, %player)
{
	Armor::onFire(%client, %player);
}
//============-----
function CyHeavy::onFire(%client, %player)
{
	Armor::onFire(%client, %player);
}
//====================================------------------
// EMP Damage FX
//====================================------------------
function Hylight::onEMP(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function HyMedium::onEMP(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function HyHeavy::onEMP(%client, %player)
{
	//No Effect On Hybrids
}
//============-----
function Cylight::onEMP(%client, %player)
{
	Armor::onEMP(%client, %player);
}
//============-----
function CyMedium::onEMP(%client, %player)
{
	Armor::onEMP(%client, %player);
}
//============-----
function CyHeavy::onEMP(%client, %player)
{
	Armor::onEMP(%client, %player);
}