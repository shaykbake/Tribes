// =================================================================
//  U L T R A   R E N E G A D E S   V X  E L I T E     
// =================================================================
// Copyright � 2005 Armageddon. List of credits in credits.txt

$pref::ShadowDetailMask = 7;
$pref::packetRate = 10;
$pref::packetSize = 200;
$pref::packetFrame = 96;
$pref::shadowDetailMask = 0;
$pref::shadowDetailScale = 0;
$pref::mapFilter = 15;
$pref::mapNames = true;
$pref::mapSensorRange = true;
$pref::mapSensorTranslucent = false;
$pref::PlayerZoomSpeed = 0.01;
$pref::PlayerFov = 90;
$Console::History = 45;
$pref::ConnectionGoodPing = 250;
$pref::ConnectionPoorPing = 350;
$pref::maxConcurrentPings = 10;
$pref::pingTimeoutTime = 900;
$pref::pingRetryCount = 4;
$pref::maxConcurrentRequests = 6;
$pref::requestTimeoutTime = 900;
$pref::requestRetryCount = 2;
$pref::quickStart = false;
$pref::lastTrainingMission = "1_Welcome";
$pref::autoWaypoint = true;
$pref::helpPopups = true;
$pref::VideoFullScreen = True;
$pref::resolveHostnames = True;
$pref::noIpx = false;
$pref::lanOnly = false;
$pref::noEnterInvStation = false;
$pref::messageMask = -1;
$pref::filterBadWords = true;