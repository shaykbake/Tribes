// =================================================================
//  U L T R A   R E N E G A D E S   V X  E L I T E     
// =================================================================
// Copyright � 2005 Armageddon. List of credits in credits.txt

focusServer
setcat missionName $1 ".mis"
loadMission $missionName
focusClient
