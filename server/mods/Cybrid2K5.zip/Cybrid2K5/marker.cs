// =================================================================
//  U L T R A   R E N E G A D E S   V X  E L I T E     
// =================================================================
// Copyright � 2005 Armageddon. List of credits in credits.txt

MarkerData DropPointMarker {
	shapeFile = "endarrow";
};
MarkerData PathMarker {
	shapeFile = "dirArrows";
};
MarkerData MapMarker {
   description = "Map Legend";
	visibleToSensor = true;
	mapFilter = 8;
	mapIcon = "M_marker";
	shapeFile = "dirArrows";
};

