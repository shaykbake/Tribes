// =================================================================
//  U L T R A   R E N E G A D E S   V X  E L I T E     
// =================================================================
// Copyright � 2005 Armageddon. List of credits in credits.txt

StaticShapeData Example
{
   shapeFile = "radar";
   shadowDetailLevel = 0;
   ambientSoundId = IDSFX_GENERATOR;
   maxDamage = 2.0;
};

function Example::onAdd(%this)
{
  //
}

function Example::onRemove(%this)
{
   //
}

function Example::onEnabled(%this)
{
   //
}

function Example::onDisabled(%this)
{
   //
}

function Example::onDestroyed(%this)
{
   //
}

function Example::onPower(%this, %newState, %generator)
{
   //
}

function Example::onCollision(%this, %object)
{
   //
}

function Example::onAttack(%this, %object)
{
   //
}

