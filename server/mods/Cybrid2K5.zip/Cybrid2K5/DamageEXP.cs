//====================================------------------
// Energy Damage FX
//====================================------------------
ExplosionData EnergyFX1Exp
{
   shapeName = "enex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// Fusion Damage FX
//====================================------------------
ExplosionData FusionFX1Exp
{
   shapeName = "fusionex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};

ExplosionData FusionFX2Exp
{
   shapeName = "plasmabolt.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// Pulse Damage FX
//====================================------------------
ExplosionData PulseFX1Exp
{
   shapeName = "shockwave_large.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};

ExplosionData PulseFX2Exp
{
   shapeName = "paint.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// Radiation Damage FX
//====================================------------------
ExplosionData RadiationFX1Exp
{
   shapeName = "shockwave_large.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};

ExplosionData RadiationFX2Exp
{
   shapeName = "mortartrail.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// AntiMatter Damage FX
//====================================------------------
ExplosionData AntiMatterFX1Exp
{
   shapeName = "shield_large.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};

ExplosionData AntiMatterFX2Exp
{
   shapeName = "plasmaex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// ION Damage FX
//====================================------------------
ExplosionData IONFX1Exp
{
   shapeName = "shotgunex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};

ExplosionData IONFX2Exp
{
   shapeName = "enex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// Bullet Damage FX
//====================================------------------
ExplosionData BulletFX1Exp
{
   shapeName = "shotgunex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// Fire Damage FX
//====================================------------------
ExplosionData FireFX1Exp
{
   shapeName = "plasmabolt.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};

ExplosionData FireFX2Exp
{
   shapeName = "smoke.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};
//====================================------------------
// EMP Damage FX
//====================================------------------
ExplosionData EMPFX1Exp
{
   shapeName = "fusionex.dts";
   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 1.0;

   lightRange = 0;
   timeScale = 10;

   timeZero = 0.100;
   timeOne  = 0.900;

   colors[0]  = { 0.0, 0.0, 50.0 };
   colors[1]  = { 0.0, 0.0, 50.0 };
   colors[2]  = { 0.0, 0.0, 50.0 };
   radFactors = { 0.0, 0.0, 2.0 };

   shiftPosition = True;
};