// This is a MiniMod Plugin.
// This is the Arbitor Box from the Ideal mod. Ported by Dewy.
//

$ItemMax[larmor, ArbitorBoxPack] = 0;
$ItemMax[sarmor, ArbitorBoxPack] = 0;
$ItemMax[barmor, ArbitorBoxPack] = 0;
$ItemMax[harmor, ArbitorBoxPack] = 1;
$ItemMax[darmor, ArbitorBoxPack] = 1;
$ItemMax[tarmor, ArbitorBoxPack] = 0;
$ItemMax[lfemale, ArbitorBoxPack] = 0;
$ItemMax[sfemale, ArbitorBoxPack] = 0;
$ItemMax[bfemale, ArbitorBoxPack] = 0;
$ItemMax[spyarmor, ArbitorBoxPack] = 0;
$ItemMax[spyfemale, ArbitorBoxPack] = 0;
$ItemMax[scvarmor, ArbitorBoxPack] = 1;
