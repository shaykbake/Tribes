//This is a MiniMod Plugin...
//This is the SeedPack from the Ideal mod. Ported by Dewy.

$InvList[TreePack] = 1;
$RemoteInvList[TreePack] = 1;
