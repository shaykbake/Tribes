// This is a MiniMod Plugin.
// This plugin is the "Obelisk Of Light" (And Power source) from the Ideal mod. Ported by Dewy.
//

SoundData SoundBuzz
{
   wavFileName = "targetlaser.wav";
   profile = Profile3dMediumLoop;
};
