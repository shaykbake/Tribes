// This is a MiniMod Plugin.
// This plugin is the Chaingun Turret from the Bitchin mod. Ported by Dewy.
//
// Note: You may wish to add Armor types here. If you don't your new armors may not be supported.
//	   It should support Renegades, Insomniax, and Base as well as many others.
//	   I did list as many as I could think of for the sake of compatiblity. Please don't
//	   holler if I missed some. I'm only human. :P

$ItemMax[larmor, ChaingunTurretPack] = 0;
$ItemMax[marmor, ChaingunTurretPack] = 1;
$ItemMax[harmor, ChaingunTurretPack] = 1;
$ItemMax[lfemale, ChaingunTurretPack] = 0;
$ItemMax[mfemale, ChaingunTurretPack] = 1;
$ItemMax[sarmor, ChaingunTurretPack] = 0;
$ItemMax[darmor, ChaingunTurretPack] = 1;
$ItemMax[sfemale, ChaingunTurretPack] = 0;
$ItemMax[bfemale, ChaingunTurretPack] = 0;
$ItemMax[spyarmor, ChaingunTurretPack] = 0;
$ItemMax[spyfemale, ChaingunTurretPack] = 0;
$ItemMax[earmor, ChaingunTurretPack] = 1;
$ItemMax[efemale, ChaingunTurretPack] = 1;
$ItemMax[aarmor, ChaingunTurretPack] = 0;
$ItemMax[tarmor, ChaingunTurretPack] = 1;
$ItemMax[scvarmor, ChaingunTurretPack] = 1;
