// This is a MiniMod Plugin.
// This plugin is the "Obelisk Of Light" (And Power source) from the Ideal mod. Ported by Dewy.
//
// Note: You may wish to add Armor types here. If you don't your new armors may not be supported.
//	   It should support Renegades, Insomniax, and Base as well as many others.
//	   I did list as many as I could think of for the sake of compatiblity. Please don't
//	   holler if I missed some. I'm only human. :P

$ItemMax[harmor, ObeliskPowerPack] = 1;
$ItemMax[larmor, ObeliskPowerPack] = 0;
$ItemMax[marmor, ObeliskPowerPack] = 0;
$ItemMax[earmor, ObeliskPowerPack] = 1;
$ItemMax[sarmor, ObeliskPowerPack] = 0;
$ItemMax[barmor, ObeliskPowerPack] = 0;
$ItemMax[scvarmor, ObeliskPowerPack] = 1;
$ItemMax[darmor, ObeliskPowerPack] = 1;
$ItemMax[lfemale, ObeliskPowerPack] = 0;
$ItemMax[mfemale, ObeliskPowerPack] = 0;
$ItemMax[efemale, ObeliskPowerPack] = 1;
$ItemMax[bfemale, ObeliskPowerPack] = 0;
$ItemMax[sfemale, ObeliskPowerPack] = 0;
$ItemMax[spyfemale, ObeliskPowerPack] = 0;
$ItemMax[spyarmor, ObeliskPowerPack] = 0;

$ItemMax[harmor, ObeliskPack] = 1;
$ItemMax[larmor, ObeliskPack] = 0;
$ItemMax[marmor, ObeliskPack] = 0;
$ItemMax[earmor, ObeliskPack] = 1;
$ItemMax[sarmor, ObeliskPack] = 0;
$ItemMax[barmor, ObeliskPack] = 0;
$ItemMax[scvarmor, ObeliskPack] = 1;
$ItemMax[darmor, ObeliskPack] = 1;
$ItemMax[lfemale, ObeliskPack] = 0;
$ItemMax[mfemale, ObeliskPack] = 0;
$ItemMax[efemale, ObeliskPack] = 1;
$ItemMax[bfemale, ObeliskPack] = 0;
$ItemMax[sfemale, ObeliskPack] = 0;
$ItemMax[spyfemale, ObeliskPack] = 0;
$ItemMax[spyarmor, ObeliskPack] = 0;

