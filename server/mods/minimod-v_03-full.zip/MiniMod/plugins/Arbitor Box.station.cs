// This is a MiniMod Plugin.
// This is the Arbitor Box from the Ideal mod. Ported by Dewy.
//

$InvList[ArbitorBoxPack] = 1;
$RemoteInvList[ArbitorBoxPack] = 0;
