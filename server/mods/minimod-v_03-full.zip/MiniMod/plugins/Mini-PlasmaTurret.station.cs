// This is a MiniMod Plugin.
// This is the Mini-Plasma turret created/ported by Dewy.

$InvList[PlasmaPack] = 1;   //Mini-Plasma Turret
$RemoteInvList[PlasmaPack] = 1;   //Mini-Plasma Turret
