//This is a MiniMod Plugin...
//This is the SeedPack from the Ideal mod. Ported by Dewy.

$InvList[FlameTurretPack] = 1;
$RemoteInvList[FlameTurretPack] = 1;
