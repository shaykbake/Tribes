//This is a MiniMod Plugin...
//This is the Flame Turret from the Ideal mod. Ported by Dewy.

$DamageScale[larmor, $FlameDamageType] = 0.9;
$DamageScale[marmor, $FlameDamageType] = 1.0;
$DamageScale[harmor, $FlameDamageType] = 1.1;
$DamageScale[lfemale, $FlameDamageType] = 0.9;
$DamageScale[mfemale, $FlameDamageType] = 1.0;
$DamageScale[sarmor, $FlameDamageType] = 1.4;
$DamageScale[aarmor, $FlameDamageType] = 1.0;
$DamageScale[tarmor, $FlameDamageType] = 1.3;
$DamageScale[scvarmor, $FlameDamageType] = 1.0;
$DamageScale[barmor, $FlameDamageType] = 1.0;
$DamageScale[bfemale, $FlameDamageType] = 1.0;
$DamageScale[darmor, $FlameDamageType] = 1.0;
$DamageScale[varmor, $FlameDamageType] = 1.0;
$DamageScale[vfemale, $FlameDamageType] = 1.0;


$ItemMax[larmor, FlameTurretPack] = 0;
$ItemMax[marmor, FlameTurretPack] = 0;
$ItemMax[harmor, FlameTurretPack] = 1;
$ItemMax[lfemale, FlameTurretPack] = 0;
$ItemMax[mfemale, FlameTurretPack] = 0;
$ItemMax[sarmor, FlameTurretPack] = 0;
$ItemMax[aarmor, FlameTurretPack] = 0;
$ItemMax[tarmor, FlameTurretPack] = 0;
$ItemMax[barmor, FlameTurretPack] = 0;
$ItemMax[darmor, FlameTurretPack] = 1;
$ItemMax[spyarmor, FlameTurretPack] = 0;
$ItemMax[spyfemale, FlameTurretPack] = 0;
$ItemMax[bfemale, FlameTurretPack] = 0;
$ItemMax[varmor, FlameTurretPack] = 0;
$ItemMax[vfemale, FlameTurretPack] = 0;
