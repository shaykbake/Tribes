//This is a MiniMod Plugin...
//This is the SeedPack from the Ideal mod. Ported by Dewy.

SoundData SoundFlameTurret
{
   wavFileName = "flyer_fly.wav";
   profile = Profile3dMedium;
};
