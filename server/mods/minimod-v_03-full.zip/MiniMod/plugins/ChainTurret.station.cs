// This is a MiniMod Plugin.
// This plugin is the Chaingun Turret from the Bitchin mod. Ported by Dewy.

$InvList[ChaingunTurretPack] = 1; //Chaingun Turret
$RemoteInvList[ChaingunTurretPack] = 1; //Chaingun Turret
