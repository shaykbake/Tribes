// This is a MiniMod Plugin.
// This plugin is the "Obelisk Of Light" (And Power source) from the Ideal mod. Ported by Dewy.
//

$InvList[ObeliskPowerPack] = 1;
$InvList[ObeliskPack] = 1;
$RemoteInvList[ObeliskPowerPack] = 0;
$RemoteInvList[ObeliskPack] = 0;
