// This is a MiniMod Plugin.
// This is the Mini-Plasma turret created/ported by Dewy.

$ItemMax[larmor, PlasmaPack] = 0;
$ItemMax[marmor, PlasmaPack] = 1;
$ItemMax[harmor, PlasmaPack] = 1;
$ItemMax[lfemale, PlasmaPack] = 0;
$ItemMax[mefemale, PlasmaPack] = 1;
$ItemMax[sarmor, PlasmaPack] = 0;
$ItemMax[sfemale, PlasmaPack] = 0;
$ItemMax[barmor, PlasmaPack] = 1;
$ItemMax[bfemale, PlasmaPack] = 1;
$ItemMax[earmor, PlasmaPack] = 1;
$ItemMax[efemale, PlasmaPack] = 1;
$ItemMax[darmor, PlasmaPack] = 1;
$ItemMax[spyarmor, PlasmaPack] = 0;
$ItemMax[spyfemale, PlasmaPack] = 0;

