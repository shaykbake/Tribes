//This is a MiniMod plugin...
//This is a modified Laser Pack from the ol' Renegades 1.2 mod. Ported and reworked by Dewy

$ItemMax[tarmor, ShockPack] = 1;
$ItemMax[larmor, ShockPack] = 1;
$ItemMax[marmor, ShockPack] = 1;
$ItemMax[harmor, ShockPack] = 1;
$ItemMax[lfemale, ShockPack] = 1;
$ItemMax[mfemale, ShockPack] = 1;
$ItemMax[sarmor, ShockPack] = 0;
$ItemMax[sfemale, ShockPack] = 0;
$ItemMax[barmor, ShockPack] = 1;
$ItemMax[darmor, ShockPack] = 1;
$ItemMax[bfemale, ShockPack] = 1;
$ItemMax[spyarmor, ShockPack] = 1;
$ItemMax[spyfemale, ShockPack] = 1;
$ItemMax[earmor, ShockPack] = 1;
$ItemMax[efemale, ShockPack] = 1;
