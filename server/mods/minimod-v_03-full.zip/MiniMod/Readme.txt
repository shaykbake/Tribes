Installation:

Extract to your " Dynamix\Tribes\ " directory.


To use as a base server:

execute: " Tribe.exe -mod MiniMod "



To use with another mod:

execute: " Tribe.exe -mod FOO -mod MiniMod "

"FOO" being the name of your other mod.


Thats it.

Have fun,
	Dewy.