echo(">> ");
echo(">> RENEGADES");
echo(">> ");