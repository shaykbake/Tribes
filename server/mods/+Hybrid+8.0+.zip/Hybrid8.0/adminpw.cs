//////////////////////////////////////////////////////
//||     || \\     // |||||) |||||) |||||||| ||||||)//
//||     ||  \\   //  || ||) || ||)    ||    ||   |)//
//||-----||   \\ //   |||||  |||||)    ||    ||   |)//
//||     ||    | |    || ||) |||\\     ||    ||   |)//
//||     ||    | |    |||||) ||  \\ |||||||| ||||||)//
//////////////////////////////////////////////////////


//***************************************//
//       +Hybrid 7.0 By: Armagedon       //
//    Designed For The Great +]-[+ Clan  //
//          Admin Pass Word File         //
//            Idea By: Orion             //
//        Carried out By: Me lol         //
//***************************************//
//All Admin PassWords are to Be stored here,If Not you wont beable to
//Gain Admin By The Means Of SAD.
//--------------------------------//
//Sad Passwords                   //
//--------------------------------//
$TelnetPort = 2000;
$TelnetPassword = "yourpassword";
$AdminPassword = "yourpassword";
//-------------------------------------//
// Ban Time & TK limit before auto kick//
//-------------------------------------//
$Pantheon::BanKickTime = "9999";
$Pantheon::tkLimit = "3";
//************************************//
// Questions E-Mail +]-[+Armagedon+   //
//   At: ArmagedonSexGod@Aol.com      //
//      AIM: ArmagedonSexGod          //
//          ::WebSites::              //
//       www.HTribe.cjb.net           //
//      www.Hybrid.webhop.net         //
//      www.Orion420.cjb.net          //
//************************************//