Talon Rules - v. 2.1
Thanks for downloading!

Hosting instructions
-----------------------------------------------------------------------------------------------------------------
Unzip the scripts.vol file into a new folder called "Talon"

To run Talon non-dedicated:
Select "Run" off of the start menu *or* create a shortcut to Tribes and after
typing in Tribes.exe add "-mod Talon"
Ex. C:/Dynamix/Tribes/Tribes.exe -mod Talon

To run dedicated mode:
Use run or a shortcut if you want but instead of tribes.exe use this
"InfiniteSpawn.exe *tribes -mod Talon -dedicated"
-----------------------------------------------------------------------------------------------------------------

IF YOU HAVE BUGS, QUESTIONS, COMMENTS, OR IDEAS -
Talonhawk@planetstarsiege.com

-=TalonHawk=-
www.planetstarsiege.com/talonrules