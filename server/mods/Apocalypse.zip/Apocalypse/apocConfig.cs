//                              Custom Server Settings:
//===========================================================================================
// Melee Settings.
$Apocalypse::SlugFest = false;

// Module Settings.
$Apocalypse::Modules = false;

// Allow Custom Skins.
$Apocalypse::customSkins = true;

// Allow Voting Admin.
$Apocalypse::VoteAdmin = true;

// Allow Voting To Kick.
$Apocalypse::VoteKick = true;

// Kick/Ban Times:
$Apocalypse::KickTime = 180;
$Apocalypse::BanTime = 1800;

// Cheats:(admins only cheats)
$Apocalypse::CheatsForAdmins = true;

// SuperAdmin Passwords:
$Apocalypse::Super[0] = "";
$Apocalypse::Super[1] = "";
$Apocalypse::Super[2] = "";
$Apocalypse::Super[3] = "";
$Apocalypse::Super[4] = "";
$Apocalypse::Super[5] = "";


// PublicAdmin Passwords:
$Apocalypse::Public[0] = "";
$Apocalypse::Public[1] = "";
$Apocalypse::Public[2] = "";
$Apocalypse::Public[3] = "";
$Apocalypse::Public[4] = "";
$Apocalypse::Public[5] = "";

//Number of tries a player has to attempt admin passwords -1 ie 2 = 3 tries
$StrikeLimit = 2;

// Allow Public Admins To Kick.
$Apocalypse::PublicKick = true;

// Allow Public Admins To Change Mission.
$Apocalypse::PublicChngMission = true;

// Allow Public Admins To View\Change Server Options.
$Apocalypse::PublicSvrOpts = false;

// Allow Public Admins To Enable\Disable Weapon Modules.
$Apocalypse::PublicEDWepMode = true;
//===========================================================================================

//                             General Server Settings:
//===========================================================================================
// Server Name, Shown In The Servers List.
$Server::HostName = "Apocalypse Server";

// Port Of Server, Usually 28001.
$Server::Port = "28001";

// Allow People To Connect To Your Server(true = yes | false = no).
$Server::HostPublicGame = true;

// Maximum Allowed Players.
$Server::MaxPlayers = "8";

// Leave Blank Unless You Want People To Enter A Password To Join Your Server.
$Server::Password = "";

// Set This To The Mission You Would Like The Server To Start On(Check Spelling).
$pref::LastMission = "Raindance";

// When You Highlight A Server, Then Click Info..You'll See This Screen.
$Server::Info = "Apocalypse server setup\nAdmin: Unknown\nEmail: Unknown";

// Message To Display When You First Join The Server(After The Loading Screen).
$Server::JoinMOTD = "<jc><f1>Email mod suggestions to TheDrunk007@yahoo.com";

// Port for telnet connections.
$TelnetPort = "";

// Password for telnet connections.
$TelnetPassword = "";

// Packet rate for client connections(recommended for cable)
$pref::PacketRate = 30;

// Packet size for client connections(recommended for cable)
$pref::PacketSize = 500;

// Minimum Allowed Votes To Succeed.
$Server::MinVotes = "2";

// ??
$Server::MinVotesPct = "0.5";

// Minimum Allowed Time To Vote.
$Server::MinVoteTime = "45";

// This Is The Delay Time After You Are Killed B4 You Can Spawn.
$Server::respawnTime = "2";

// Team Damage: (1 = on | 0 = off).
$Server::TeamDamageScale = "0";

// Mission time limit in minutes.
$Server::TimeLimit       = 30;

// Warmup Time B4 Match Starts.
$Server::WarmupTime      = 15;

// Start In Tournament Mode(true = yes | false = no).
$Server::TourneyMode = "false";

// ??
$Server::VoteAdminWinMargin = "0.66";

// ??
$Server::VoteFailTime = "30";

// ??
$Server::VoteWinMargin = "0.55";

// Overall Time For Vote.
$Server::VotingTime = "20";

// Time B4 Match Starts On Each New Mission.
$Server::warmupTime = "20";

// Auto-Set Teams When People Connect Or Let Them Pick(true = auto-assign | false = don't).
$Server::AutoAssignTeams = "true";


// Team Names & Team Skins:
$Server::teamName0 = "MHunters";
$Server::teamSkin0 = "blue";

$Server::teamName1 = "Mavericks";
$Server::teamSkin1 = "purple";

$Server::teamName2 = "Reploids";
$Server::teamSkin2 = "base";

$Server::teamName3 = "Repliforce";
$Server::teamSkin3 = "green";

$Server::teamName4 = "Apocalypse";
$Server::teamSkin4 = "beagle";

$Server::teamName5 = "Annihilation";
$Server::teamSkin5 = "dsword";

$Server::teamName6 = "Havoc";
$Server::teamSkin6 = "swolf";

$Server::teamName7 = "Chaos";
$Server::teamSkin7 = "cphoenix";
