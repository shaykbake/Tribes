Apocalypse Mod by ProtoManX
Credits: these are people that provide code for my mod
-Ice(Devastor Mod): biggest contributer to my mod
-Creeperman: created Homing and Tractor code
-Nicodemus: used foundation mod as base for mine(it is base w/ files seperated)
-Thanx to who ever made the
 -Armor specific inventory
 -Placment of forcefields for Jail Mine
