function Center(%player)
{
	%pos = 205 + getRandom()*300 @ " " @ 114 + getRandom()*300 @ " " @ 300;
	gamebase::setposition(%player,%pos);
	item::Setvelocity(%player,"0 0 0");
   		item::giveitem(%player, Parachute, 1);
		Player::mountItem(%player,Parachute,$BackpackSlot);
		Player::trigger(%player,$BackpackSlot,true);
		$ParaActivated[%player] = 1;
		schedule("doparaOne("@%player@");",1);
	player::Setarmor(%player,sarmor);
	player::Setitemcount(%player,psg1,1);
	player::Setitemcount(%player,psg1clip,10);
	player::Setitemcount(%player,law,1);
	player::Setitemcount(%player,lawammo,1);

}


function Extermination::SpawnAIs(%team, %numAIs)
{
      	%tempSet = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\AI");
      
	%numPts = Group::objectCount(%set);
	for(%x=0;%x < %numAIs;%x++)
	{

      		%tempItem = Group::getObject(%tempSet, %x);
      		%aiName = Object::getName(%tempItem);
      		%set = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\AI\\" @ %aiName);
		
		if(String::findSubStr(%aiName, "Sniper") >= 0)
		{
			if(String::findSubStr(%aiName, "PSG1") >= 0)
				%name = Extermination::spawnSniper(%team, %set, 1,%aiName); //Team,Waypoint set, weponloadtyep
			else if(String::findSubStr(%aiName, "FiftyCal") >= 0)
				%name = Extermination::spawnSniper(%team, %set, 2,%aiName); //Team,Waypoint set, weponloadtyep
		} else if(String::findSubStr(%aiName, "Infantry") >= 0)
		{
			if(String::findSubStr(%aiName, "M16") >= 0)
				%name = Extermination::spawnInfantry(%team, %set, 1,%aiName);
			else if(String::findSubStr(%aiName, "SAW") >= 0)
				%name = Extermination::spawnInfantry(%team, %set, 2,%aiName);
			else if(String::findSubStr(%aiName, "ShotGun") >= 0)
				%name = Extermination::spawnInfantry(%team, %set, 3,%aiName);
			else if(String::findSubStr(%aiName, "LAW") >= 0)
				%name = Extermination::spawnInfantry(%team, %set, 4,%aiName);
		} else if(String::findSubStr(%aiName, "Specops") >= 0)
		{
			%name = Extermination::spawnSpecops(%team, %set, 1,%aiName);
		} else if(String::findSubStr(%aiName, "Commander") >= 0)
		{
			%name = Extermination::spawnCommander(%team,%set,1);
		}

		if(String::findSubStr(%aiName, "Loop") >= 0)
		{	
			AI::setVar( %Name,  pathType, 0); // circular
			Extermination::keepMoving(%Name);

		} else if(String::findSubStr(%aiName, "Patrol") >= 0)
		{
			AI::setVar( %Name,  pathType, 2); // two way
			Extermination::keepMoving(%Name);
		} else
		{
			AI::setVar( %Name,  pathType, 1); // one way
		}

		%player = Client::getOwnedObject(AI::getId(%Name));
		if(String::findSubStr(%aiName, "Elite") >= 0)
		{	
  			AI::SetVar(%aiName, triggerPct, 1 );

			$Veteran::Kills[%player,Knife] = 10;
			$Veteran::Kills[%player,Pistol] = 10;
			$Veteran::Kills[%player,M16] = 10;
			$Veteran::Kills[%player,SAW] = 10;
			$Veteran::Kills[%player,MP5] = 10;
			$Veteran::Kills[%player,PSG1] = 10;
			$Veteran::Kills[%player,Robar] = 10;
			$Veteran::Kills[%player,Shotgun] = 10;
			$Veteran::Kills[%player,Law] = 10;
			
		} else if(String::findSubStr(%aiName, "Vet") >= 0)
		{
  			AI::SetVar(%aiName, triggerPct, 0.5 );

			$Veteran::Kills[%player,Knife] = 3;
			$Veteran::Kills[%player,Pistol] = 3;
			$Veteran::Kills[%player,M16] = 3;
			$Veteran::Kills[%player,SAW] = 3;
			$Veteran::Kills[%player,MP5] = 3;
			$Veteran::Kills[%player,PSG1] = 3;
			$Veteran::Kills[%player,Robar] = 3;
			$Veteran::Kills[%player,Shotgun] = 3;
			$Veteran::Kills[%player,Law] = 3;
			
		} else
		{
 			AI::SetVar(%aiName, triggerPct, 0.1 );
		}
	}
}

function Extermination::keepMoving(%aiName)
{
	%aiId = AI::getId(%aiName);
	if(%aiName == "Commander225")
	%vel = item::GetVelocity(%aiId);
	if(getword(%vel,0) < 0.0001 && getword(%vel,0) > -0.0001 && getword(%vel,1) < 0.0001 && getword(%vel,1) > -0.0001 && getword(%vel,2) < 0.0001 && getword(%vel,2) > -0.0001)
		%vel = "0 0 0";
	if(%vel == "0 0 0" && %aiId)
	{

		Player::applyImpulse(%aiId,50*getRandom() - 50*getRandom()+50@" "@50*getRandom() - 50*getRandom()+50@" "@50*getRandom() - 50*getRandom()+50);
	}
	Schedule("Extermination::keepMoving("@%aiName@");",getRandom()*30);
}

function Extermination::spawnSniper(%team, %set, %type,%oldName)
{
	%aiName = "Sniper" @ $numAI;
	if(String::findSubStr(%oldName, "Elite") >= 0)
		%aiName = "Elite"@%aiName;
	else if(String::findSubStr(%oldName, "Vet") >= 0)
		%aiName = "Vet"@%aiName;
	$numAI++;
	createAI(%aiName, %set, "sarmor", %aiName);
	%aiId = AI::getId(%aiName);
	GameBase::setTeam(%aiId, %team);
	AI::setVar( %aiName,  iq,  150 );
	schedule("Extermination::SniperWeapons"@%type@"(" @ %aiName @ ");", 1);
	return %aiName;
}


function Extermination::spawnInfantry(%team, %set, %type,%oldName)
{
	%aiName = "Infantry" @ $numAI;
	if(String::findSubStr(%oldName, "Elite") >= 0)
		%aiName = "Elite"@%aiName;
	else if(String::findSubStr(%oldName, "Vet") >= 0)
		%aiName = "Vet"@%aiName;
	$numAI++;
	createAI(%aiName, %set, "iarmor", %aiName);
	%aiId = AI::getId(%aiName);
	GameBase::setTeam(%aiId, %team);
	AI::setVar( %aiName,  iq,  150 );
	schedule("Extermination::InfantryWeapons"@%type@"(" @ %aiName @ ");", 1);
	return %aiName;
}


function Extermination::spawnSpecops(%team, %set, %type,%oldName)
{
	%aiName = "Specops" @ $numAI;
	if(String::findSubStr(%oldName, "Elite") >= 0)
		%aiName = "Elite"@%aiName;
	else if(String::findSubStr(%oldName, "Vet") >= 0)
		%aiName = "Vet"@%aiName;
	$numAI++;
	createAI(%aiName, %set, "carmor", %aiName);
	%aiId = AI::getId(%aiName);
	GameBase::setTeam(%aiId, %team);
	AI::setVar( %aiName,  iq,  150 );
	schedule("Extermination::SpecopsWeapons"@%type@"(" @ %aiName @ ");", 1);
	return %aiName;
}

function Extermination::spawnPilot(%team, %set, %type,%oldName)
{
	%aiName = "Pilot" @ $numAI;
	if(String::findSubStr(%oldName, "Elite") >= 0)
		%aiName = "Elite"@%aiName;
	else if(String::findSubStr(%oldName, "Vet") >= 0)
		%aiName = "Vet"@%aiName;
	$numAI++;
	

	Ai::spawn(%aiName, larmor, %pos, "0 0 0");
	%aiId = AI::getId(%aiName);
	GameBase::setTeam(%aiId, %team);
	AI::setVar( %aiName,  iq,  150 );
	schedule("Extermination::PilotWeapons"@%type@"(" @ %aiName @ ");", 1);
	return %aiName;
}


function Extermination::spawnCommander(%team, %set, %type)
{
	%aiName = "Commander" @ $numAI;
	$numAI++;
	createAI(%aiName, %set, "larmor", %aiName);
	%aiId = AI::getId(%aiName);
	$Extermination::Commander[%ainame] = true;
	GameBase::setTeam(%aiId, %team);
	AI::setVar( %aiName,  iq,  150 );
	schedule("Extermination::CommanderWeapons"@%type@"(" @ %aiName @ ");", 1);
	return %aiName;
}

function Extermination::SniperWeapons1(%aiName)
{
   %aiId = AI::getId(%aiName);

   dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,sarmor);
   Player::setItemCount(%aiId, PSG1, 1);
   Player::setItemCount(%aiId, PSG1Ammo, 5);
   Player::setItemCount(%aiId, PSG1Clip, 10);
   Player::mountItem(%aiId, PSG1, 0);

//   AI::SetVar(%aiName, triggerPct, 0.9 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}


function Extermination::SniperWeapons2(%aiName)
{
   %aiId = AI::getId(%aiName);

   dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,sarmor);
   Player::setItemCount(%aiId, FiftyCal, 1);
   Player::setItemCount(%aiId, FiftyCalAmmo, 5);
   Player::setItemCount(%aiId, FiftyCalClip, 10);
   Player::mountItem(%aiId, FiftyCal, 0);

//   AI::SetVar(%aiName, triggerPct, 0.1 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}


function spawnAis(%num)
{
	for(%i = 0; %i<%num;%i++)
	{
		%base = "205 114 127";
		%pos = 205 + getRandom()*300 @ " " @ 114 + getRandom()*300 @ " " @ 300;
		%ai = spawnTarget2(1,%player,vector::add(%pos,"1 "@%i*10@" 0"));
		
		player::setAnimation(%ai,42);
   		item::giveitem(%ai, Parachute, 1);
		Player::mountItem(%ai,Parachute,$BackpackSlot);
		Player::trigger(%ai,$BackpackSlot,true);
		$ParaActivated[%ai] = 1;
		schedule("doparaOne("@%ai@");",1);
	}
}

function spawnAIOn(%player)
{
	%pos = gamebase::Getposition(%player);
		%ai = spawnTarget2(1,%player,vector::add(%pos,"0 0 300"));



	
		player::setAnimation(%ai,42);
   		item::giveitem(%ai, Parachute, 1);
		Player::mountItem(%ai,Parachute,$BackpackSlot);
		Player::trigger(%ai,$BackpackSlot,true);
		$ParaActivated[%ai] = 1;
		schedule("doparaOne("@%ai@");",1);
		%player = Client::getOwnedObject(%ai);

			$Veteran::Kills[%player,Knife] = 10;
			$Veteran::Kills[%player,Pistol] = 10;
			$Veteran::Kills[%player,M16] = 10;
			$Veteran::Kills[%player,SAW] = 10;
			$Veteran::Kills[%player,MP5] = 10;
			$Veteran::Kills[%player,PSG1] = 10;
			$Veteran::Kills[%player,Robar] = 10;
			$Veteran::Kills[%player,Shotgun] = 10;
			$Veteran::Kills[%player,Law] = 10;

}

function spawnAIAt(%pos,%team,%type)
{
	%set = -1;
	%oldName = "Pilot"@ $NumAI;
	$numAI++;
	%ainame = Extermination::spawnPilot(%team, %set, 1, %oldName);
	%aiId = AI::getId(%aiName);
	GameBase::setTeam(%aiId, %team);
	AI::setVar( %aiName,  iq,  100 );
	AI::setVar( %aiName,  attackMode, 0);
	AI::setVar( %aiName,  pathType, 1);
   	AI::SetVar(%aiName, triggerPct, 1 );
	gamebase::setposition(%aiId,%pos);
	
	%ai = %aiid;
	//if(%type == Pilot)

	item::giveitem(%ai, Parachute, 1);
	Player::mountItem(%ai,Parachute,$BackpackSlot);
	//%player = Client::getOwnedObject(%ai);
	return %ainame;
}

function Extermination::SpecopsWeapons1(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,carmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::setItemCount(%aiId, mp5, 1);
	Player::setItemCount(%aiId, mp5Ammo, 30);
	Player::setItemCount(%aiId, mp5Clip, 3);
	Player::mountItem(%aiId, mp5, 0);

//   AI::SetVar(%aiName, triggerPct, 0.9 );
   AI::setVar(%aiName, attackMode, 0);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}


function Extermination::InfantryWeapons1(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,iarmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::setItemCount(%aiId, OICW, 1);
	Player::setItemCount(%aiId, OICWAmmo, 30);
	Player::setItemCount(%aiId, OICWClip, 4);
	Player::mountItem(%aiId, OICW, 0);

//   AI::SetVar(%aiName, triggerPct, 0.5 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}

function Extermination::InfantryWeapons2(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,iarmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::setItemCount(%aiId, SAW, 1);
	Player::setItemCount(%aiId, SAWAmmo, 200);
	Player::setItemCount(%aiId, SAWClip, 1);
	Player::mountItem(%aiId, SAW, 0);

//   AI::SetVar(%aiName, triggerPct, 0.9 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}

function Extermination::InfantryWeapons3(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,iarmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::setItemCount(%aiId, AutoShotgun, 1);
	Player::setItemCount(%aiId, AutoShotgunAmmo, 7);
	Player::setItemCount(%aiId, AutoShotgunClip, 10);
	Player::mountItem(%aiId, AutoShotGun, 0);

//   AI::SetVar(%aiName, triggerPct, 0.7 );
   AI::setVar(%aiName, attackMode, 0);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}


function Extermination::InfantryWeapons4(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,iarmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::setItemCount(%aiId, LAW, 1);
	Player::setItemCount(%aiId, LAWAmmo, 1);
	Player::mountItem(%aiId, LAW, 0);

//   AI::SetVar(%aiName, triggerPct, 0.1 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}


function Extermination::PilotWeapons1(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,larmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::mountItem(%aiId, SOCOM, 0);
//   AI::SetVar(%aiName, triggerPct, 0.9 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}

function Extermination::CommanderWeapons1(%aiName)
{
	%aiId = AI::getId(%aiName);

    dbecho(2, "giving normal weapon select...");
	player::Setarmor(%aiId,larmor);
    Player::setItemCount(%aiId, SOCOM, 1);
	Player::setItemCount(%aiId, SOCOMAmmo, 12);
	Player::setItemCount(%aiId, SOCOMClip, 3);

	Player::mountItem(%aiId, SOCOM, 0);
//   AI::SetVar(%aiName, triggerPct, 0.9 );
   AI::setVar(%aiName, attackMode, 1);
//   AI::setVar( %aiName,  pathType, 1);
   AI::setAutomaticTargets( %aiName );
   //ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}

function Extermination::playerSpawned(%pl, %clientId, %armor)
{
	%clientId.spawn= 1;
	%max = getNumItems();

	if($Extermination::CurSpawn[%clientId] == "medic")
	{
		%spawnlist[0] = MedicArmor;
		%spawnlist[1] = Knife;
		%spawnlist[2] = SOCOM;
		%spawnlist[3] = MP5;
		%spawnlist[4] = RepairKit;
		%spawnlist[5] = Grenade;
		%spawnlist[6] = MedicPack;
	} else if($Extermination::CurSpawn[%clientId] == "ammo")
	{
		
		%spawnlist[0] = ArtilleryArmor;
		%spawnlist[1] = Knife;
		%spawnlist[2] = SOCOM;
		%spawnlist[3] = oicw;
		%spawnlist[4] = RepairKit;
		%spawnlist[5] = Grenade;
	} else
	{

		%spawnlist[0] = $spawnBuyList[0];
		%spawnlist[1] = $spawnBuyList[1];
		%spawnlist[2] = $spawnBuyList[2];
		%spawnlist[3] = $spawnBuyList[3];
		%spawnlist[4] = $spawnBuyList[4];
		%spawnlist[5] = $spawnBuyList[5];
		%spawnlist[6] = $spawnBuyList[6];
	}

   for(%i = 0; (%item = %spawnlist[%i]) != ""; %i++)
   {
	   // DELTAFORCE
	   if($Game::missionType == "Assassination") {
		   if($Hunted == %clientId) {
			   if (%i == 2) %i++;
		   }
	   }
	   // END DELTAFORCE
		buyItem(%clientId,%item);	
		if(%item.className == Weapon) 
			%clientId.spawnWeapon = %item;
	}
	if($Extermination::CurSpawn[%clientId] == "ammo")
	{
		player::setitemcount(%clientId,OICWClip,6);
		player::setitemcount(%clientId,SOCOMClip,6);
	}
	%clientId.spawn= "";
	$Reloading[%clientId] = 0;
	%clientid.inVehicle = false;
	if(%clientId.spawnWeapon != "") {
		Player::useItem(%pl,%clientId.spawnWeapon);
   	%clientId.spawnWeapon="";
	}
} 


function Player::leaveMissionArea(%player)
{
   	%cl = Player::getClient(%player);
	if($Game::missionType == "Extermination" && !Player::isAiControlled(%player))
	{
		playSound(ricochet1,gamebase::Getposition(%player));
		Client::sendMessage(Player::getClient(%player),1,"An enemy sharp shooter spotted you. Sorry.");
		GameBase::applyDamage(%player,$LaserDamageType, 100.0,vector::add(GameBase::getPosition(%player),"0 0 3"),"0 0 0","0 0 0",2048);
	}
}


function alertPlayer(%player, %count)
{
	if(%player.outArea == 1) {
		%clientId = Player::getClient(%player);
	  	Client::sendMessage(%clientId,1,"~wLeftMissionArea.wav");
		if(%count > 1)
		   schedule("alertPlayer(" @ %player @ ", " @ %count - 1 @ ");",1.5,%clientId);
		else 
	   	schedule("leaveMissionAreaDamage(" @ %clientId @ ");",1,%clientId);
	}
}


function leaveMissionAreaDamage(%client)
{
	%player = Client::getOwnedObject(%client);
	if(%player.outArea == 1) {
		if(!Player::isDead(%player)) {
		  	Player::setDamageFlash(%client,0.1);
			GameBase::setDamageLevel(%player,GameBase::getDamageLevel(%player) + 0.1);
	   	schedule("leaveMissionAreaDamage(" @ %client @ ");",1);
		}
		else { 
			playNextAnim(%client);	
			Client::onKilled(%client, %client);
		}
	}
}



function Trigger::oncollision(%this, %object){
	if(Object::Getname(%this) == "Extermination")
	{
		GroupTrigger::onContact(%this,%object);
	}
}

function GroupTrigger::oncollision(%this, %object){
	if(Object::Getname(%this) == "Extermination")
	{
		GroupTrigger::onContact(%this,%object);
	}
}

function GroupTrigger::onContact(%this, %object)
{
	if(Object::Getname(%this) == "Extermination" && $Game::missionType == "Extermination" && !Player::isAiControlled(%object))
	{
		playSound(ricochet1,gamebase::Getposition(%object));
		Client::sendMessage(Player::getClient(%object),1,"An enemy sharp shooter spotted you. Sorry.");
		GameBase::applyDamage(%object,$LaserDamageType, 100.0,vector::add(GameBase::getPosition(%object),"0 0 3"),"0 0 0","0 0 0",2048);
	}
}	
