//  Set up the 3Space default properties...
//

// setMaterialProperty (TYPE,     FRICTION, ELASTICITY);
   setMaterialProperty (Default     ,  10.0      , 1.0 );
   setMaterialProperty (Concrete    ,  10.3      , 0.8 );
   setMaterialProperty (Carpet      ,  20.0      , 0.4 );
   setMaterialProperty (Metal       ,  1.6      , 1.4 );
   setMaterialProperty (Glass       ,  1.5      , 1.6 );
   setMaterialProperty (Plastic     ,  10.0      , 1.0 );
   setMaterialProperty (Wood        ,  10.3      , 0.75);
   setMaterialProperty (Marble      ,  10.0      , 1.2 );
   setMaterialProperty (Snow        ,  1.5      , 0.4 );
   setMaterialProperty (Ice         ,  1.2      , 1.2 );
   setMaterialProperty (Sand        ,  2.0      , 0.2 );
   setMaterialProperty (Mud         ,  10.5      , 0.2 );
   setMaterialProperty (Stone       ,  10.0      , 1.3 );
   setMaterialProperty (SoftEarth   ,  10.4      , 0.6 );
   setMaterialProperty (PackedEarth ,  10.0      , 0.9 );

