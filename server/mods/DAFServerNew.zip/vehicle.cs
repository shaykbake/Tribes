//---------------------------------------------------------------------------------
// Vehicle crash messages - %1 = killer's name, %2 = pilot's name
//       %3 = killer's gender pronoun (his/her), %4 = pilot's gender pronoun
//---------------------------------------------------------------------------------

$crashMsg[Fighter2, 0]		= "%1 shot %2's Tomcat out of the sky.";
$crashMsg[Fighter2, 1]		= "%1 got the tongue of %2's Tomcat.";
$crashMsg[Fighter2, 2]		= "%1 doesn't think %2's fighter is all that superior.";
$crashMsg[Fighter2, 3]		= "%2's Tomcat wasnt fast enough to outmanuver %1.";

$crashMsg[Fighter, 0]		= "%1 shot %2's Falcon out of the sky.";
$crashMsg[Fighter, 1]		= "%1 clipped the wings of %2's Falcon.";
$crashMsg[Fighter, 2]		= "%2 should have brought a Tomcat to face %1.";
$crashMsg[Fighter, 3]		= "%2's strike fighter was taken down by %1.";

$crashMsg[Warthog, 0]		= "%1 shot %2's Warthog out of the sky.";
$crashMsg[Warthog, 1]		= "%1 cooks up %2's Warthog with a bit of BBQ sauce.";
$crashMsg[Warthog, 2]		= "%1 is showered with pieces of %2's Warthog.";
$crashMsg[Warthog, 3]		= "On %1's request, %2 flew %3 low altitude bomber a bit TOO low.";

$crashMsg[MoveWarthog, 0]	= "%1 shot %2's Warthog out of the sky.";
$crashMsg[MoveWarthog, 1]	= "%1 cooks up %2's Warthog with a bit of BBQ sauce.";
$crashMsg[MoveWarthog, 2]	= "%1 is showered with pieces of %2's Warthog.";
$crashMsg[MoveWarthog, 3]	= "On %1's request, %2 flew %3 low altitude bomber a bit TOO low.";

$crashMsg[Hercules, 0]		= "%1 shot %2's Hercules out of the sky.";
$crashMsg[Hercules, 1]		= "The strength of %2's Herclues failed when faced with %1.";
$crashMsg[Hercules, 2]		= "%1 declares %2's flight canceled much to the dismay of %2's passengers.";
$crashMsg[Hercules, 3]		= "%1 forces %2's cargo plane to take an emergency \"landing.\"";

$crashMsg[Gunship, 0]		= "%1 shot %2's Gunship out of the sky.";
$crashMsg[Gunship, 1]		= "%2's Gunship just didn't have enough guns to defeat %1.";
$crashMsg[Gunship, 2]		= "%1 brings %2's Gunship to a sudden end.";
$crashMsg[Gunship, 3]		= "%2's ground plans were cut short by %1's air plans.";

$crashMsg[Bomber, 0]		= "%1 shot %2's Bomber out of the sky.";
$crashMsg[Bomber, 1]		= "%1 finds that %2's Bomber is less effective when in many pieces.";
$crashMsg[Bomber, 2]		= "%2 didn't fly high enough to avoid %1.";
$crashMsg[Bomber, 3]		= "%1 shows %2 how vulnerable his Bomber really is.";


$crashMsg[Apache, 0]		= "%1 shot %2's Apache out of the sky.";
$crashMsg[Apache, 1]		= "%1 decides to play Cowboys and Indians with %2's Apache";
$crashMsg[Apache, 2]		= "%1 puts the rotary on %2's Apache on hold.";
$crashMsg[Apache, 3]		= "%2's Apache wasn't manuverable enough to face %1.";

$crashMsg[Hind, 0]		= "%1 shot %2's Hind out of the sky.";
$crashMsg[Hind, 1]		= "%1's hatred burns red for %2's Hind.";
$crashMsg[Hind, 2]		= "%2's Russian influence wasn't enough to prevent destruction by %1.";
$crashMsg[Hind, 3]		= "%1 was as deadly to %2's Hind as it was to infantry.";

$crashMsg[Blackhawk, 0]		= "%1 shot %2's Blackhawk out of the sky.";
$crashMsg[Blackhawk, 1]		= "%1 REALLY likes the movie \"Blackhawk Down\" much to %2's dismay";
$crashMsg[Blackhawk, 2]		= "%1 clips the wings of %2's Blackhawk.";
$crashMsg[Blackhawk, 3]		= "%1 order's %2's passengers to abandon ship.";


$crashMsg[Humvee, 0]        = "%2's HMMWV got taken to the trash heap by %1.";
$crashMsg[Humvee, 1]        = "%1 wrecked %2's HMMWV permanently.";
$crashMsg[Humvee, 2]        = "%1 trashed %2's HMMWV.";
$crashMsg[Humvee, 3]        = "%2's HMMWV was scattered by %1.";

$crashMsg[Abrams, 0]        = "%1 blew %2's M1A1 Abrams to pieces.";
$crashMsg[Abrams, 1]        = "%2's M1A1 Abrams was shredded by %1.";
$crashMsg[Abrams, 2]        = "%1 retired %2's M1A1 Abrams.";
$crashMsg[Abrams, 3]        = "%2's M1A1 Abrams was reduced to scrap by %1.";

$crashMsg[Bradley, 0]       = "%2's M113 Bradley was derailed by %1.";
$crashMsg[Bradley, 1]       = "%1 nailed %2's M113 Bradley's weak spot.";
$crashMsg[Bradley, 2]       = "%2's M113 Bradley should've avoided %1.";
$crashMsg[Bradley, 3]       = "%1 found %2's M113 Bradley to be quite explosive.";

$crashMsg[LineBacker, 0]    = "%2's M6 Bradley LB was stopped cold by %1.";
$crashMsg[LineBacker, 1]    = "%1 crushed %2's M6 Bradley LB.";
$crashMsg[LineBacker, 2]    = "%2's M6 Bradley lost a fight to %1.";
$crashMsg[LineBacker, 3]    = "%1 made sure that %2's M6 Bradley LB would never ride again.";

$crashMsg[MLRS, 0]      = "%1 smashed up %2's MLRS SPLL.";
$crashMsg[MLRS, 1]      = "%2's MLRS SPLL was turned to junk by %1.";
$crashMsg[MLRS, 2]      = "%1 desicrated %2's MLRS SPLL.";
$crashMsg[MLRS, 3]      = "%2's MLRS SPLL found %1 a bit too late.";

$crashMsg[MineLayer, 0]      = "%1 blew up %2's Cargo.";
$crashMsg[MineLayer, 1]      = "%2's Cargo was hijacked, and destroyed by %1.";
$crashMsg[MineLayer, 2]      = "%1 sabatoged %2's Volcano.";
$crashMsg[MineLayer, 3]      = "%2's Volcano spontaniously combusted. %1 helped a bit.";





$Vmodule[1] = "AIM-9 Sidewinder"; 
$Vmodule[2] = "AIM-54 Phoenix";
$Vmodule[3] = "AGM-114 Hellfire"; 
$Vmodule[4] = "AGM-64 Maverick"; 
$Vmodule[5] = "AGM-88 HARM";
$Vmodule[6] = "Mk-82 500Lb Bomb"; 
$Vmodule[7] = "Mk-84 2000Lb Bomb"; 
$Vmodule[8] = "CBU-59 APAM Bomb"; 
$Vmodule[9] = "CBU-89 Gator Mine Bomb"; 
$Vmodule[10] = "CBU-87 Cluster Bomb"; 
$Vmodule[11] = "BLU-113 Penetrator Bomb"; 
$Vmodule[12] = "M-10 Smoke Tank"; 
$Vmodule[13] = "M-10 Tear Gas Tank"; 
$Vmodule[14] = "Mk-77 Incendiary Bomb"; 
$Vmodule[15] = "Mk-53 Hydrogen Bomb";
$Vmodule[16] = "ALQ-131 EMC Pod"; 
$Vmodule[17] = "Mk-82 500Lb Bombs [4]"; 
$Vmodule[18] = "Mk-84 2000Lb Bomb [2]"; 
$Vmodule[19] = "BLU-82B Daisy Cutter Bomb"; 
$Vmodule[20] = "Supply Crate"; 
$Vmodule[21] = "2.75inch Hydra-70"; 
$Vmodule[22] = "UPK-23-250 23mm Gun Pod"; 
$Vmodule[23] = "GUV YaKB 12.7mm Gun Pod"; 

$ModuleToWeapon[SideWinderModule] = SidewinderRocket;
$ModuleToWeapon[PhoenixModule] = PhoenixRocket;
$ModuleToWeapon[HellfireModule] = ApacheRocket;
$ModuleToWeapon[HydraModule] = HydraRocket;
$ModuleToWeapon[UPKGunPodModule] = TwentyFivemmBullet;
$ModuleToWeapon[GUVGunPodModule] = SAWBullet;
$ModuleToWeapon[MaverickModule] = MavMiss;
$ModuleToWeapon[HARMModule] = HARMRocket;
$ModuleToWeapon[Mk82Module] = BigBomb;
$ModuleToWeapon[Mk84Module] = BombShell;
$ModuleToWeapon[APClusterModule] = APClusterBomb;
$ModuleToWeapon[MineClusterModule] = MineClusterBomb;
$ModuleToWeapon[BombletClusterModule] = BombletClusterBomb;
$ModuleToWeapon[BunkerBusterModule] = BunkerBusterBomb;
$ModuleToWeapon[TankSmokeModule] = TankSmoke;
$ModuleToWeapon[TankNerveGasModule] = TankNerveGas;
$ModuleToWeapon[IncendiaryNapalmModule] = NapalmBomb;
$ModuleToWeapon[NuclearModule] = NukeShell;
$ModuleToWeapon[EMCModule] = EMCContainer;
$ModuleToWeapon[Mk82PackageModule] = BigBomb;
$ModuleToWeapon[Mk84PackageModule] = BombShell;
$ModuleToWeapon[DaisyCutterModule] = DaisyShell;
$ModuleToWeapon[SupplyCrateModule] = SupplyDrop;


$WeaponToNumber[SidewinderRocket] = 1;
$WeaponToNumber[PhoenixRocket] = 2;
$WeaponToNumber[ApacheRocket] = 3;
$WeaponToNumber[MavMiss] = 4;
$WeaponToNumber[HARMRocket] = 5;
$WeaponToNumber[BigBomb] = 6;
$WeaponToNumber[BombShell] = 7;
$WeaponToNumber[APClusterBomb] = 8;
$WeaponToNumber[MineClusterBomb] = 9;
$WeaponToNumber[BombletClusterBomb] = 10;
$WeaponToNumber[BunkerBusterBomb] = 11;
$WeaponToNumber[TankSmoke] = 12;
$WeaponToNumber[TankNerveGas] = 13;
$WeaponToNumber[NapalmBomb] = 14;
$WeaponToNumber[NukeShell] = 15;
$WeaponToNumber[EMCContainer] = 16;
//$WeaponToNumber[BigBomb] = 17; // Just fucks things up and were decrementing normaly anyway so....
//$WeaponToNumber[BombShell] = 18;
$WeaponToNumber[DaisyShell] = 19;
$WeaponToNumber[SupplyDrop] = 20;
$WeaponToNumber[HydraRocket] = 21;
$WeaponToNumber[TwentyFivemmBullet] = 22;
$WeaponToNumber[SAWBullet] = 23;


$NumberOfMiss[1] = 1;
$NumberOfMiss[2] = 6;
$NumberOfMiss[3] = 4;
$NumberOfMiss[4] = 1;
$NumberOfMiss[5] = 1;
$NumberOfMiss[6] = 1;
$NumberOfMiss[7] = 1;
$NumberOfMiss[8] = 1;
$NumberOfMiss[9] = 1;
$NumberOfMiss[10] = 1;
$NumberOfMiss[11] = 1;
$NumberOfMiss[12] = 50;
$NumberOfMiss[13] = 50;
$NumberOfMiss[14] = 1;
$NumberOfMiss[15] = 1;
$NumberOfMiss[16] = 1;
$NumberOfMiss[17] = 4;
$NumberOfMiss[18] = 2;
$NumberOfMiss[19] = 1;
$NumberOfMiss[20] = 1;
$NumberOfMiss[21] = 19;
$NumberOfMiss[22] = 250;
$NumberOfMiss[23] = 750;


$VmoduleHP[1] = 1;
$VmoduleHP[2] = 1;
$VmoduleHP[3] = 1;
$VmoduleHP[4] = 1;
$VmoduleHP[5] = 1;
$VmoduleHP[6] = 2;
$VmoduleHP[7] = 3;
$VmoduleHP[8] = 1;
$VmoduleHP[9] = 1;
$VmoduleHP[10] = 1;
$VmoduleHP[11] = 1;
$VmoduleHP[12] = 2;
$VmoduleHP[13] = 2;
$VmoduleHP[14] = 3;
$VmoduleHP[15] = -1;
$VmoduleHP[16] = 1;
$VmoduleHP[17] = -1;
$VmoduleHP[18] = -1;
$VmoduleHP[19] = -1;
$VmoduleHP[20] = -1;
$VmoduleHP[21] = 1;
$VmoduleHP[22] = 1;
$VmoduleHP[23] = 1;

$VmoduleBB[1] = -1;
$VmoduleBB[2] = -1;
$VmoduleBB[3] = -1;
$VmoduleBB[4] = -1;
$VmoduleBB[5] = -1;
$VmoduleBB[6] = 1;
$VmoduleBB[7] = 2;
$VmoduleBB[8] = -1;
$VmoduleBB[9] = -1;
$VmoduleBB[10] = -1;
$VmoduleBB[11] = -1;
$VmoduleBB[12] = -1;
$VmoduleBB[13] = -1;
$VmoduleBB[14] = -1;
$VmoduleBB[15] = 54;
$VmoduleBB[16] = -1;
$VmoduleBB[17] = 4;
$VmoduleBB[18] = 4;
$VmoduleBB[19] = 1; // Herc only however.
$VmoduleBB[20] = 1; // Herc only however.
$VmoduleBB[21] = -1;
$VmoduleBB[22] = -1;
$VmoduleBB[23] = -1;


$VehicleCounterMeasures[Hercules] = 0;
$VehicleCounterMeasures[Bomber] = 60;
$VehicleCounterMeasures[Hind] = 30;
$VehicleCounterMeasures[Apache] = 30;
$VehicleCounterMeasures[Fighter2] = 60;
$VehicleCounterMeasures[Fighter] = 60;
$VehicleCounterMeasures[Warthog] = 60;
$VehicleCounterMeasures[MoveWarthog] = 60;
$VehicleCounterMeasures[Blackhawk] = 30;
$VehicleCounterMeasures[Gunship] = 60;

$VehicleCounterMeasures[Humvee] = 0;
$VehicleCounterMeasures[Abrams] = 0;
$VehicleCounterMeasures[Bradley] = 0;
$VehicleCounterMeasures[Linebacker] = 0;
$VehicleCounterMeasures[MineLayer] = 0;
$VehicleCounterMeasures[MLRS] = 0;


// DELTA FORCE VEHICLES
// ---------------------------------------------

//----------------------------------------------------------------------------
//fighter, F-16
//----------------------------------------------------------------------------

FlierData Fighter
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 100.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 5.0;
   maxPitch = 100.0; //(5) This way we can do many loops in the air without rewinding
   maxSpeed = 75;
   minSpeed = 0;
	lift = 20.0;
	maxAlt = 450;
	maxVertical = 20;
	maxDamage = 3.8;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.5;

	groundDamageScale = 1.0;

	//projectileType = FighterBullet;
	reloadDelay = 0.1;
	repairRate = 0;
	fireSound = shockExplosion;
	damageSound = SoundTankCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 22;
	description = "F-16 Falcon";
};

//----------------------------------------------------------------------------
//DiveBomber Stuka
//----------------------------------------------------------------------------

//FlierData DiveBomber
//{
//	explosionId = flashExpLarge;
//	debrisId = flashDebrisLarge;
//	className = "Vehicle";
//   shapeFile = "flyer";
//   shieldShapeName = "shield_medium";
//   mass = 8.0;
//   drag = 0.5;
//   density = 1.2;
//   maxBank = 6.5;
//   maxPitch = 100.0; //6.5
//  maxSpeed = 60;
//   minSpeed = 0;
//	lift = 20;
//	maxAlt = 300;
//	maxVertical = 20;
//	maxDamage = 3.0;
//	damageLevel = {1.0, 1.0};
//	maxEnergy = 100;
//	accel = 0.4;
//
//	groundDamageScale = 1.0;
//
//	//projectileType = BombShell;
//	reloadDelay = 5.0;
//	repairRate = 0;
//	fireSound = SoundDryFire;
//	damageSound = SoundTankCrash;
//	ramDamage = 1.5;
//	ramDamageType = -1;
//	mapFilter = 2;
//	mapIcon = "M_vehicle";
//	visibleToSensor = true;
//	shadowDetailMask = 2;
//
//	mountSound = SoundFlyerMount;
//	dismountSound = SoundFlyerDismount;
//	idleSound = SoundDiscSpin;
//	moveSound = SoundFlyerActive;
//
//	visibleDriver = false;
//	driverPose = 22;
//	description = "JU87B-1 Sturzkampfflugzeus";
//};

//----------------------------------------------------------------------------
//fighter2, F-14
//----------------------------------------------------------------------------

FlierData Fighter2
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 100.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 100.0;
   maxPitch = 100.0;//6
   maxSpeed = 80;
   minSpeed = 0;
	lift = 20.0;
	maxAlt = 450;
	maxVertical = 20;
	maxDamage = 3.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.5;

	groundDamageScale = 1.0;

	//projectileType = FighterBullet;
	reloadDelay = 0.1;
	repairRate = 0;
	fireSound = shockExplosion;
	damageSound = SoundTankCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 22;
	description = "F-14A Tomcat";
};

FlierData Apache
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.5;
   maxPitch = 0.5;
   maxSpeed = 45;
   minSpeed = -2;
	lift = 0.75;
	maxAlt = 300;
	maxVertical = 10;
	maxDamage = 2.0;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.4;

	groundDamageScale = 1.0;

	//projectileType = ApacheRocket;
	reloadDelay = 0.5;
	repairRate = 0;
	fireSound = SoundFireFlierRocket;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = False;
	driverPose = 22;
	description = "Apache";
};

FlierData Hind
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_medium";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.5;
   maxPitch = 0.5;
   maxSpeed = 30;
   minSpeed = -1;
	lift = 1.24;
	maxAlt =300;
	maxVertical = 10;
	maxDamage = 5.0;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.1;

	groundDamageScale = 0.5;

	//projectileType = ApacheRocket;
	reloadDelay = 0.5;
	repairRate = 0;
	fireSound = SoundFireFlierRocket;
	damageSound = SoundFlierCrash;
	ramDamage = 8.0;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "Mi-24 Hind";
};

function Hind::onFire(%this) 
{
	Vehicle::onFire(%this);
}

FlierData Bomber
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
     mass = 500.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.5;
   maxSpeed = 30;
   minSpeed = 0;
	lift = 20.0;
	maxAlt = 500;
	maxVertical = 20;
	maxDamage = 15.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.20;

	groundDamageScale = 1.0;

	//projectileType = BombShell;
	reloadRate = 0;
	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundDryFire;
	reloadDelay = 0.3;
	damageSound = SoundTankCrash;
	visibleToSensor = False;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = False;
	driverPose = 23;
	description = "B-52 Stratofortress";
};

FlierData Hercules
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
     mass = 500.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.5;
   maxSpeed = 30;
   minSpeed = 0;
	lift = 20.0;
	maxAlt = 500;
	maxVertical = 20;
	maxDamage = 15.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.20;

	groundDamageScale = 1.0;

	//projectileType = BombShell;
	//reloadRate = 0;
	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	//fireSound = SoundFireMortar;
	reloadDelay = 0.3;
	damageSound = SoundTankCrash;
	visibleToSensor = True;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = False;
	driverPose = 23;
	description = "C-130 Hercules";
};

FlierData Gunship
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
     mass = 500.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.5;
   maxSpeed = 30;
   minSpeed = 0;
	lift = 20.0;
	maxAlt = 500;
	maxVertical = 20;
	maxDamage = 15.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.20;

	groundDamageScale = 1.0;

	//projectileType = BombShell;
	//reloadRate = 0;
	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	//fireSound = SoundFireMortar;
	reloadDelay = 0.3;
	damageSound = SoundTankCrash;
	visibleToSensor = True;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = False;
	driverPose = 23;
	description = "AC-130U Gunship";
};

function Gunship::onAdd(%this) 
{
	$VehicleAmmo[%this, TwentyFivemmgun] = 1000;
	$VehicleAmmo[%this, AbramsGun] = 30;
	$VehicleAmmo[%this, Fortymmgun] = 500;
	$PassengerSlot[%this, 2] = 0;
	$PassengerSlot[%this, 3] = 0;
	$PassengerSlot[%this, 4] = 0;
	$PassengerSlot[%this, 5] = 0;
	Vehicle::onAdd(%this);
}

FlierData Warthog
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
     mass = 100.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 100;//2.7;
   maxPitch = 100;//5.7;
   maxSpeed = 55;
   minSpeed = 0;
	lift = 20.0;
	maxAlt = 250;
	maxVertical = 20;
	maxDamage = 7.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.30;

	groundDamageScale = 1.0;

	//projectileType = WarthogBullet;
	//reloadDelay = 0.5;
	//reloadRate = 0;
	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	//fireSound = SoundFireMortar;
	//reloadDelay = 0.3;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = False;
	driverPose = 23;
	description = "A-10 Warthog";
};
function Warthog::onFire(%this)
{
	Vehicle::onFire(%this);
}
FlierData MoveWarthog
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 0.0;
   drag = 0.5;
   density = 1.2;
   maxBank = 100;//0.70;           //maxBank = 0.25;
   maxPitch = 100;//0.70;          //maxPitch = 0.25;
   maxSpeed = 55;            //maxSpeed = 45;
   minSpeed = 55;
	lift = 0.75;
	maxAlt = 250;
	maxVertical = 20;
	maxDamage = 7.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.30;   //accel = 0.25;

	groundDamageScale = 1.0;

	//projectileType = WarthogBullet;
	//reloadDelay = 0.5;
	//reloadRate = 0;
	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	//fireSound = SoundFireMortar;
	//reloadDelay = 0.15;            //reloadDelay = 0.3;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundDiscSpin;
	moveSound = SoundFlyerActive;

	visibleDriver = False;
	driverPose = 23;
	description = "A-10 Warthog";
};

function MoveWarthog::onFire(%this)
{
	Vehicle::onFire(%this);
}

FlierData TOWMissile
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "rocket";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.5;
   maxPitch = 0.5;
   maxSpeed = 60;
   minSpeed = 60;
	lift = 0.75;
	maxAlt = 200;
	maxVertical = 10;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 2.0;

	groundDamageScale = 5.0;

	reloadDelay = 0.0;
	repairRate = 0;
	damageSound = SoundFlierCrash;
	ramDamage = 3.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "TOW";
};

function OutOfCable(%this) 
{
	%cl = GameBase::getControlClient(%this);
	Vehicle::dismount(%this, "0 0 0");
	//remoteEval(%cl, BP, "<jc><f0>TOW Missile is out of cable", 4);
	bottomprint(%cl, "<jc><f0>TOW Missile is out of cable", 4);
}

function TOWMissile::onAdd(%this) 
{
	GameBase::setRechargeRate(%this, -25); // TOW lives for 4 seconds
	schedule("OutOfCable("@%this@");", 4, %this);
	schedule("$TOWDetEnable["@%this@"] = 1;", 0.5, %this);
}

function TOWMissile::onFire(%this)
{
	if ($TOWDetEnable[%this] == 1) {
		%cl = GameBase::getControlClient(%this);
		Vehicle::dismount(%this, "0 0 0");
		//remoteEval(%cl, BP, "<jc><f0>TOW Missile Remotely Detonated", 4);
		bottomprint(%cl, "<jc><f0>TOW Missile Remotely Detonated", 4);
		$TOWDetEnable[%this] = 0;
	}
}

FlierData Blackhawk
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 30;
   minSpeed = -1;
	lift = 0.5;
	maxAlt = 300;
	maxVertical = 6;
	maxDamage = 7.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "Blackhawk";
};

function Blackhawk::onAdd(%this) 
{
	$VehicleAmmo[%this, Minigun] = 400;
	$PassengerSlot[%this, 2] = 0;
	$PassengerSlot[%this, 3] = 0;
	Vehicle::onAdd(%this);
}

FlierData Humvee
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.3;
   maxSpeed = 30;
   minSpeed = -10;
	//lift = 26.0;
	lift = 2.0;
	maxAlt = 10;
	maxVertical = 6;
	maxDamage = 2.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundGeneratorPower;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "HMMWV";
};

function Humvee::onAdd(%this) 
{
	$VehicleAmmo[%this, TOW] = 8;
	$VehicleAmmo[%this, AutoGrenLauncher] = 50;
	$PassengerSlot[%this, 2] = 0;
	$PassengerSlot[%this, 3] = 0;
	Vehicle::onAdd(%this);
}

FlierData Abrams
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.3;
   maxSpeed = 20;
   minSpeed = -10;
	//lift = 26.0;
	lift = 2.0;
	maxAlt = 10;
	maxVertical = 6;
	maxDamage = 6.5;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundGeneratorPower;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "M1A1 Abrams";
};

function Abrams::onAdd(%this) 
{
	$VehicleAmmo[%this, AbramsGun] = 30;
	$VehicleAmmo[%this, Minigun] = 400;
	$PassengerSlot[%this, 2] = 0;
	$PassengerSlot[%this, 3] = 0;
	Vehicle::onAdd(%this);
}

FlierData Bradley
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 20;								   
   minSpeed = -10;
	//lift = 26.0;
	lift = 2.0;
	maxAlt = 10;
	maxVertical = 6;
	maxDamage = 6.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.125;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundGeneratorPower;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "M113 Bradley";
};
function Bradley::onAdd(%this) 
{
	$VehicleAmmo[%this, TwentyFivemmgun] = 300;
	$VehicleAmmo[%this, TOW] = 2;
	$VehicleAmmo[%this, MiniGun] = 700;
	$PassengerSlot[%this, 2] = 0;
	$PassengerSlot[%this, 3] = 0;
	$PassengerSlot[%this, 4] = 0;
	Vehicle::onAdd(%this);
}

FlierData LineBacker
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 20;								   
   minSpeed = -10;
	//lift = 26.0;
	lift = 2.0;
	maxAlt = 10;
	maxVertical = 6;
	maxDamage = 6.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.125;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundGeneratorPower;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "M6 Bradley LB";
};
function LineBacker::onAdd(%this) 
{
	$VehicleAmmo[%this, StingerLauncherGun] = 10;
	$VehicleAmmo[%this, TwentyFivemmgun] = 600;
	$VehicleAmmo[%this, MiniGun] = 1000;
	$PassengerSlot[%this, 2] = 0;
	$PassengerSlot[%this, 3] = 0;
	$PassengerSlot[%this, 4] = 0;
	Vehicle::onAdd(%this);
}

FlierData MLRS
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 20;								   
   minSpeed = -10;
	//lift = 26.0;
	lift = 2.0;
	maxAlt = 10;
	maxVertical = 6;
	maxDamage = 5.5;
	damageLevel = {1.0, 1.0};
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.125;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundGeneratorPower;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "MLRS SPLL";
};
function MLRS::onAdd(%this) 
{
	$VehicleAmmo[%this, MLRSLauncher] = 12;
	$PassengerSlot[%this, 2] = 0;
	Vehicle::onAdd(%this);
}

FlierData MineLayer
{
	explosionId = flashExpLarge;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.3;
   maxSpeed = 25;
   minSpeed = -10;
	//lift = 26.0;
	lift = 2.0;
	maxAlt = 10;
	maxVertical = 6;
	maxDamage = 2.0;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 100;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundGeneratorPower;
	moveSound = SoundFlyerActive;

	visibleDriver = false;
	driverPose = 23;
	description = "M548A3";
};

$DamageScale[Fighter, $ImpactDamageType] = 5.0;
$DamageScale[Fighter, $BulletDamageType] = 0.9;
$DamageScale[Fighter, $PlasmaDamageType] = 1.0;
$DamageScale[Fighter, $EnergyDamageType] = 1.0;
$DamageScale[Fighter, $ExplosionDamageType] = 1.0;
$DamageScale[Fighter, $ShrapnelDamageType] = 1.0;
$DamageScale[Fighter, $DebrisDamageType] = 1.0;
$DamageScale[Fighter, $MissileDamageType] = 2.0;
$DamageScale[Fighter, $LaserDamageType] = 1.0;
$DamageScale[Fighter, $MortarDamageType] = 1.0;
$DamageScale[Fighter, $BlasterDamageType] = 1.0;
$DamageScale[Fighter, $ElectricityDamageType] = 0.01;
$DamageScale[Fighter, $MineDamageType]        = 1.0;
$DamageScale[Fighter, $BleedDamageType] = 0.0;
$DamageScale[Fighter, $GrenadeDamageType] = 0.5;
$DamageScale[Fighter, $PoisonDamageType] = 0.0;
$DamageScale[Fighter, $SmokeDamageType] = 0.0;
$DamageScale[Fighter, $StabDamageType] = 0.0;

//$DamageScale[DiveBomber, $ImpactDamageType] = 5.0;
//$DamageScale[DiveBomber, $BulletDamageType] = 1.0;
//$DamageScale[DiveBomber, $PlasmaDamageType] = 1.0;
//$DamageScale[DiveBomber, $EnergyDamageType] = 1.0;
//$DamageScale[DiveBomber, $ExplosionDamageType] = 1.0;
//$DamageScale[DiveBomber, $ShrapnelDamageType] = 1.0;
//$DamageScale[DiveBomber, $DebrisDamageType] = 1.0;
//$DamageScale[DiveBomber, $MissileDamageType] = 2.3;
//$DamageScale[DiveBomber, $LaserDamageType] = 1.0;
//$DamageScale[DiveBomber, $MortarDamageType] = 1.0;
//$DamageScale[DiveBomber, $BlasterDamageType] = 1.0;
//$DamageScale[DiveBomber, $ElectricityDamageType] = 0.01;
//$DamageScale[DiveBomber, $MineDamageType]        = 1.0;
//$DamageScale[DiveBomber, $BleedDamageType] = 0.0;
//$DamageScale[DiveBomber, $GrenadeDamageType] = 0.5;

$DamageScale[Fighter2, $ImpactDamageType] = 5.0;
$DamageScale[Fighter2, $BulletDamageType] = 0.8;
$DamageScale[Fighter2, $PlasmaDamageType] = 1.0;
$DamageScale[Fighter2, $EnergyDamageType] = 1.0;
$DamageScale[Fighter2, $ExplosionDamageType] = 1.0;
$DamageScale[Fighter2, $ShrapnelDamageType] = 1.0;
$DamageScale[Fighter2, $DebrisDamageType] = 1.0;
$DamageScale[Fighter2, $MissileDamageType] = 2.0;
$DamageScale[Fighter2, $LaserDamageType] = 1.0;
$DamageScale[Fighter2, $MortarDamageType] = 1.0;
$DamageScale[Fighter2, $BlasterDamageType] = 1.0;
$DamageScale[Fighter2, $ElectricityDamageType] = 0.01;
$DamageScale[Fighter2, $MineDamageType]        = 1.0;
$DamageScale[Fighter2, $BleedDamageType] = 0.0;
$DamageScale[Fighter2, $GrenadeDamageType] = 0.5;
$DamageScale[Fighter2, $PoisonDamageType] = 0.0;
$DamageScale[Fighter2, $SmokeDamageType] = 0.0;
$DamageScale[Fighter2, $StabDamageType] = 0.0;

$DamageScale[Apache, $ImpactDamageType] = 5.0;
$DamageScale[Apache, $BulletDamageType] = 0.3;
$DamageScale[Apache, $PlasmaDamageType] = 0.05;
$DamageScale[Apache, $EnergyDamageType] = 1.0;
$DamageScale[Apache, $ExplosionDamageType] = 1.0;
$DamageScale[Apache, $ShrapnelDamageType] = 1.0;
$DamageScale[Apache, $DebrisDamageType] = 1.0;
$DamageScale[Apache, $MissileDamageType] = 1.8;
$DamageScale[Apache, $LaserDamageType] = 0.5;
$DamageScale[Apache, $MortarDamageType] = 1.0;
$DamageScale[Apache, $BlasterDamageType] = 0.5;
$DamageScale[Apache, $ElectricityDamageType] = 1.0;
$DamageScale[Apache, $MineDamageType]        = 1.0;
$DamageScale[Apache, $ChargeDamageType]      = 1.0;
$DamageScale[Apache, $AirstrikeDamageType]   = 1.0;
$DamageScale[Apache, $BleedDamageType] = 0.0;
$DamageScale[Apache, $GrenadeDamageType] = 0.5;
$DamageScale[Apache, $PoisonDamageType] = 0.0;
$DamageScale[Apache, $SmokeDamageType] = 0.0;
$DamageScale[Apache, $StabDamageType] = 0.0;

$DamageScale[Hind, $ImpactDamageType] = 3.0;
$DamageScale[Hind, $BulletDamageType] = 0.05;
$DamageScale[Hind, $PlasmaDamageType] = 1.0;
$DamageScale[Hind, $EnergyDamageType] = 1.0;
$DamageScale[Hind, $ExplosionDamageType] = 1.0;
$DamageScale[Hind, $ShrapnelDamageType] = 0.3;
$DamageScale[Hind, $DebrisDamageType] = 0.5;
$DamageScale[Hind, $MissileDamageType] = 1.6;
$DamageScale[Hind, $LaserDamageType] = 0.5;
$DamageScale[Hind, $MortarDamageType] = 1.0;
$DamageScale[Hind, $BlasterDamageType] = 0.5;
$DamageScale[Hind, $ElectricityDamageType] = 1.0;
$DamageScale[Hind, $MineDamageType]        = 1.0;
$DamageScale[Hind, $ChargeDamageType]      = 1.0;
$DamageScale[Hind, $AirstrikeDamageType]   = 1.0;
$DamageScale[Hind, $BleedDamageType] = 0.0;
$DamageScale[Hind, $GrenadeDamageType] = 0.5;
$DamageScale[Hind, $PoisonDamageType] = 0.0;
$DamageScale[Hind, $SmokeDamageType] = 0.0;
$DamageScale[Hind, $StabDamageType] = 0.0;

$DamageScale[Bomber, $ImpactDamageType] = 10.0;
$DamageScale[Bomber, $BulletDamageType] = 0.5;
$DamageScale[Bomber, $PlasmaDamageType] = 1.0;
$DamageScale[Bomber, $EnergyDamageType] = 1.0;
$DamageScale[Bomber, $ExplosionDamageType] = 0.7;
$DamageScale[Bomber, $ShrapnelDamageType] = 0.6;
$DamageScale[Bomber, $DebrisDamageType] = 0.7;
$DamageScale[Bomber, $MissileDamageType] = 2.0;
$DamageScale[Bomber, $LaserDamageType] = 0.3;
$DamageScale[Bomber, $MortarDamageType] = 1.0;
$DamageScale[Bomber, $BlasterDamageType] = 0.5;
$DamageScale[Bomber, $ElectricityDamageType] = 1.0;
$DamageScale[Bomber, $MineDamageType]        = 1.0;
$DamageScale[Bomber, $ChargeDamageType] = 1.0;
$DamageScale[Bomber, $AirstrikeDamageType]   = 1.0;
$DamageScale[Bomber, $BleedDamageType] = 0.0;
$DamageScale[Bomber, $GrenadeDamageType] = 0.5;
$DamageScale[Bomber, $PoisonDamageType] = 0.0;
$DamageScale[Bomber, $SmokeDamageType] = 0.0;
$DamageScale[Bomber, $StabDamageType] = 0.0;

$DamageScale[Hercules, $ImpactDamageType] = 10.0;
$DamageScale[Hercules, $BulletDamageType] = 0.5;
$DamageScale[Hercules, $PlasmaDamageType] = 1.0;
$DamageScale[Hercules, $EnergyDamageType] = 1.0;
$DamageScale[Hercules, $ExplosionDamageType] = 0.7;
$DamageScale[Hercules, $ShrapnelDamageType] = 0.6;
$DamageScale[Hercules, $DebrisDamageType] = 0.7;
$DamageScale[Hercules, $MissileDamageType] = 2.0;
$DamageScale[Hercules, $LaserDamageType] = 0.3;
$DamageScale[Hercules, $MortarDamageType] = 1.0;
$DamageScale[Hercules, $BlasterDamageType] = 0.5;
$DamageScale[Hercules, $ElectricityDamageType] = 1.0;
$DamageScale[Hercules, $MineDamageType]        = 1.0;
$DamageScale[Hercules, $ChargeDamageType] = 1.0;
$DamageScale[Hercules, $AirstrikeDamageType]   = 1.0;
$DamageScale[Hercules, $BleedDamageType] = 0.0;
$DamageScale[Hercules, $GrenadeDamageType] = 0.5;
$DamageScale[Hercules, $PoisonDamageType] = 0.0;
$DamageScale[Hercules, $SmokeDamageType] = 0.0;
$DamageScale[Hercules, $StabDamageType] = 0.0;

$DamageScale[Gunship, $ImpactDamageType] = 10.0;
$DamageScale[Gunship, $BulletDamageType] = 0.5;
$DamageScale[Gunship, $PlasmaDamageType] = 1.0;
$DamageScale[Gunship, $EnergyDamageType] = 1.0;
$DamageScale[Gunship, $ExplosionDamageType] = 0.7;
$DamageScale[Gunship, $ShrapnelDamageType] = 0.6;
$DamageScale[Gunship, $DebrisDamageType] = 0.7;
$DamageScale[Gunship, $MissileDamageType] = 2.0;
$DamageScale[Gunship, $LaserDamageType] = 0.3;
$DamageScale[Gunship, $MortarDamageType] = 1.0;
$DamageScale[Gunship, $BlasterDamageType] = 0.5;
$DamageScale[Gunship, $ElectricityDamageType] = 1.0;
$DamageScale[Gunship, $MineDamageType]        = 1.0;
$DamageScale[Gunship, $ChargeDamageType] = 1.0;
$DamageScale[Gunship, $AirstrikeDamageType]   = 1.0;
$DamageScale[Gunship, $BleedDamageType] = 0.0;
$DamageScale[Gunship, $GrenadeDamageType] = 0.5;
$DamageScale[Gunship, $PoisonDamageType] = 0.0;
$DamageScale[Gunship, $SmokeDamageType] = 0.0;
$DamageScale[Gunship, $StabDamageType] = 0.0;

$DamageScale[Warthog, $ImpactDamageType] = 10.0;
$DamageScale[Warthog, $BulletDamageType] = 0.7;
$DamageScale[Warthog, $PlasmaDamageType] = 1.0;
$DamageScale[Warthog, $EnergyDamageType] = 1.0;
$DamageScale[Warthog, $ExplosionDamageType] = 0.7;
$DamageScale[Warthog, $ShrapnelDamageType] = 0.6;
$DamageScale[Warthog, $DebrisDamageType] = 0.7;
$DamageScale[Warthog, $MissileDamageType] = 2.0;
$DamageScale[Warthog, $LaserDamageType] = 0.3;
$DamageScale[Warthog, $MortarDamageType] = 1.0;
$DamageScale[Warthog, $BlasterDamageType] = 0.5;
$DamageScale[Warthog, $ElectricityDamageType] = 1.0;
$DamageScale[Warthog, $MineDamageType]        = 1.0;
$DamageScale[Warthog, $ChargeDamageType] = 1.0;
$DamageScale[Warthog, $AirstrikeDamageType]   = 1.0;
$DamageScale[Warthog, $BleedDamageType] = 0.0;
$DamageScale[Warthog, $GrenadeDamageType] = 0.5;
$DamageScale[Warthog, $PoisonDamageType] = 0.0;
$DamageScale[Warthog, $SmokeDamageType] = 0.0;
$DamageScale[Warthog, $StabDamageType] = 0.0;

$DamageScale[MoveWarthog, $ImpactDamageType] = 10.0;
$DamageScale[MoveWarthog, $BulletDamageType] = 0.7;
$DamageScale[MoveWarthog, $PlasmaDamageType] = 1.0;
$DamageScale[MoveWarthog, $EnergyDamageType] = 1.0;
$DamageScale[MoveWarthog, $ExplosionDamageType] = 0.7;
$DamageScale[MoveWarthog, $ShrapnelDamageType] = 0.6;
$DamageScale[MoveWarthog, $DebrisDamageType] = 0.7;
$DamageScale[MoveWarthog, $MissileDamageType] = 2.0;
$DamageScale[MoveWarthog, $LaserDamageType] = 0.3;
$DamageScale[MoveWarthog, $MortarDamageType] = 1.0;
$DamageScale[MoveWarthog, $BlasterDamageType] = 0.5;
$DamageScale[MoveWarthog, $ElectricityDamageType] = 1.0;
$DamageScale[MoveWarthog, $MineDamageType]        = 1.0;
$DamageScale[MoveWarthog, $ChargeDamageType] = 1.0;
$DamageScale[MoveWarthog, $AirstrikeDamageType]   = 1.0;
$DamageScale[MoveWarthog, $BleedDamageType] = 0.0;
$DamageScale[MoveWarthog, $GrenadeDamageType] = 0.5;
$DamageScale[MoveWarthog, $PoisonDamageType] = 0.0;
$DamageScale[MoveWarthog, $SmokeDamageType] = 0.0;
$DamageScale[MoveWarthog, $StabDamageType] = 0.0;

$DamageScale[TOWMissile, $ImpactDamageType] = 10.0;
$DamageScale[TOWMissile, $BulletDamageType] = 0.6;
$DamageScale[TOWMissile, $PlasmaDamageType] = 1.0;
$DamageScale[TOWMissile, $EnergyDamageType] = 1.0;
$DamageScale[TOWMissile, $ExplosionDamageType] = 1.0;
$DamageScale[TOWMissile, $ShrapnelDamageType] = 1.0;
$DamageScale[TOWMissile, $DebrisDamageType] = 1.0;
$DamageScale[TOWMissile, $MissileDamageType] = 1.0;
$DamageScale[TOWMissile, $LaserDamageType] = 1.0;
$DamageScale[TOWMissile, $MortarDamageType] = 1.0;
$DamageScale[TOWMissile, $BlasterDamageType] = 0.5;
$DamageScale[TOWMissile, $ElectricityDamageType] = 1.0;
$DamageScale[TOWMissile, $MineDamageType]        = 1.0;
$DamageScale[TOWMissile, $ChargeDamageType]      = 1.0;
$DamageScale[TOWMissile, $AirstrikeDamageType]   = 1.0;
$DamageScale[TOWMissile, $BleedDamageType] = 0.0;
$DamageScale[TOWMissile, $GrenadeDamageType] = 1.0;
$DamageScale[TOWMissile, $PoisonDamageType] = 0.0;
$DamageScale[TOWMissile, $SmokeDamageType] = 0.0;
$DamageScale[TOWMissile, $StabDamageType] = 0.0;

$DamageScale[Blackhawk, $ImpactDamageType] = 5.0;
$DamageScale[Blackhawk, $BulletDamageType] = 0.1;
$DamageScale[Blackhawk, $PlasmaDamageType] = 1.0;
$DamageScale[Blackhawk, $EnergyDamageType] = 1.0;
$DamageScale[Blackhawk, $ExplosionDamageType] = 1.0;
$DamageScale[Blackhawk, $ShrapnelDamageType] = 1.0;
$DamageScale[Blackhawk, $DebrisDamageType] = 1.0;
$DamageScale[Blackhawk, $MissileDamageType] = 1.5;
$DamageScale[Blackhawk, $LaserDamageType] = 0.5;
$DamageScale[Blackhawk, $MortarDamageType] = 1.0;
$DamageScale[Blackhawk, $BlasterDamageType] = 0.5;
$DamageScale[Blackhawk, $ElectricityDamageType] = 1.0;
$DamageScale[Blackhawk, $MineDamageType]        = 1.0;
$DamageScale[Blackhawk, $ChargeDamageType] = 1.0;
$DamageScale[Blackhawk, $AirstrikeDamageType]   = 1.0;
$DamageScale[Blackhawk, $BleedDamageType] = 0.0;
$DamageScale[Blackhawk, $GrenadeDamageType] = 0.5;
$DamageScale[Blackhawk, $PoisonDamageType] = 0.0;
$DamageScale[Blackhawk, $SmokeDamageType] = 0.0;
$DamageScale[Blackhawk, $StabDamageType] = 0.0;

$DamageScale[Humvee, $ImpactDamageType] = 0.0;
$DamageScale[Humvee, $BulletDamageType] = 0.2;
$DamageScale[Humvee, $PlasmaDamageType] = 0.5;
$DamageScale[Humvee, $EnergyDamageType] = 1.0;
$DamageScale[Humvee, $ExplosionDamageType] = 0.8;
$DamageScale[Humvee, $ShrapnelDamageType] = 0.8;
$DamageScale[Humvee, $DebrisDamageType] = 0.7;
$DamageScale[Humvee, $MissileDamageType] = 3.0;
$DamageScale[Humvee, $LaserDamageType] = 0.0;
$DamageScale[Humvee, $MortarDamageType] = 0.8;
$DamageScale[Humvee, $BlasterDamageType] = 0.5;
$DamageScale[Humvee, $ElectricityDamageType] = 1.0;
$DamageScale[Humvee, $MineDamageType]        = 0.8;
$DamageScale[Humvee, $ChargeDamageType]       = 1.0;
$DamageScale[Humvee, $AirstrikeDamageType]   = 1.0;
$DamageScale[Humvee, $BleedDamageType] = 0.0;
$DamageScale[Humvee, $GrenadeDamageType] = 0.5;
$DamageScale[Humvee, $PoisonDamageType] = 0.0;
$DamageScale[Humvee, $SmokeDamageType] = 0.0;
$DamageScale[Humvee, $StabDamageType] = 0.0;

$DamageScale[Abrams, $ImpactDamageType] = 0.0;
$DamageScale[Abrams, $BulletDamageType] = 0.2;
$DamageScale[Abrams, $PlasmaDamageType] = 0.5;
$DamageScale[Abrams, $EnergyDamageType] = 1.0;
$DamageScale[Abrams, $ExplosionDamageType] = 0.8;
$DamageScale[Abrams, $ShrapnelDamageType] = 0.8;
$DamageScale[Abrams, $DebrisDamageType] = 0.7;
$DamageScale[Abrams, $MissileDamageType] = 2.0;
$DamageScale[Abrams, $LaserDamageType] = 0.0;
$DamageScale[Abrams, $MortarDamageType] = 0.8;
$DamageScale[Abrams, $BlasterDamageType] = 0.5;
$DamageScale[Abrams, $ElectricityDamageType] = 1.0;
$DamageScale[Abrams, $MineDamageType]        = 0.7;
$DamageScale[Abrams, $ChargeDamageType]       = 0.8;
$DamageScale[Abrams, $AirstrikeDamageType]   = 0.5;
$DamageScale[Abrams, $BleedDamageType] = 0.0;
$DamageScale[Abrams, $GrenadeDamageType] = 0.5;
$DamageScale[Abrams, $PoisonDamageType] = 0.0;
$DamageScale[Abrams, $SmokeDamageType] = 0.0;
$DamageScale[Abrams, $StabDamageType] = 0.0;

$DamageScale[Bradley, $ImpactDamageType] = 0.0;
$DamageScale[Bradley, $BulletDamageType] = 0.2;
$DamageScale[Bradley, $PlasmaDamageType] = 0.5;
$DamageScale[Bradley, $EnergyDamageType] = 1.0;
$DamageScale[Bradley, $ExplosionDamageType] = 0.8;
$DamageScale[Bradley, $ShrapnelDamageType] = 0.8;
$DamageScale[Bradley, $DebrisDamageType] = 0.7;
$DamageScale[Bradley, $MissileDamageType] = 2.0;
$DamageScale[Bradley, $LaserDamageType] = 0.0;
$DamageScale[Bradley, $MortarDamageType] = 0.8;
$DamageScale[Bradley, $BlasterDamageType] = 0.5;
$DamageScale[Bradley, $ElectricityDamageType] = 1.0;
$DamageScale[Bradley, $MineDamageType]        = 0.7;
$DamageScale[Bradley, $ChargeDamageType]      = 0.8;
$DamageScale[Bradley, $AirstrikeDamageType]   = 0.5;
$DamageScale[Bradley, $BleedDamageType] = 0.0;
$DamageScale[Bradley, $GrenadeDamageType] = 0.5;
$DamageScale[Bradley, $PoisonDamageType] = 0.0;
$DamageScale[Bradley, $SmokeDamageType] = 0.0;
$DamageScale[Bradley, $StabDamageType] = 0.0;

$DamageScale[LineBacker, $ImpactDamageType] = 0.0;
$DamageScale[LineBacker, $BulletDamageType] = 0.2;
$DamageScale[LineBacker, $PlasmaDamageType] = 0.5;
$DamageScale[LineBacker, $EnergyDamageType] = 1.0;
$DamageScale[LineBacker, $ExplosionDamageType] = 0.8;
$DamageScale[LineBacker, $ShrapnelDamageType] = 0.8;
$DamageScale[LineBacker, $DebrisDamageType] = 0.7;
$DamageScale[LineBacker, $MissileDamageType] = 2.0;
$DamageScale[LineBacker, $LaserDamageType] = 0.0;
$DamageScale[LineBacker, $MortarDamageType] = 0.8;
$DamageScale[LineBacker, $BlasterDamageType] = 0.5;
$DamageScale[LineBacker, $ElectricityDamageType] = 1.0;
$DamageScale[LineBacker, $MineDamageType]        = 0.7;
$DamageScale[LineBacker, $ChargeDamageType]      = 0.8;
$DamageScale[LineBacker, $AirstrikeDamageType]   = 0.5;
$DamageScale[LineBacker, $BleedDamageType] = 0.0;
$DamageScale[LineBacker, $GrenadeDamageType] = 0.5;
$DamageScale[LineBacker, $PoisonDamageType] = 0.0;
$DamageScale[LineBacker, $SmokeDamageType] = 0.0;
$DamageScale[LineBacker, $StabDamageType] = 0.0;

$DamageScale[MLRS, $ImpactDamageType] = 0.0;
$DamageScale[MLRS, $BulletDamageType] = 0.2;
$DamageScale[MLRS, $PlasmaDamageType] = 0.5;
$DamageScale[MLRS, $EnergyDamageType] = 1.0;
$DamageScale[MLRS, $ExplosionDamageType] = 0.8;
$DamageScale[MLRS, $ShrapnelDamageType] = 0.8;
$DamageScale[MLRS, $DebrisDamageType] = 0.7;
$DamageScale[MLRS, $MissileDamageType] = 2.0;
$DamageScale[MLRS, $LaserDamageType] = 0.0;
$DamageScale[MLRS, $MortarDamageType] = 0.8;
$DamageScale[MLRS, $BlasterDamageType] = 0.5;
$DamageScale[MLRS, $ElectricityDamageType] = 1.0;
$DamageScale[MLRS, $MineDamageType]        = 0.7;
$DamageScale[MLRS, $ChargeDamageType]      = 0.8;
$DamageScale[MLRS, $AirstrikeDamageType]   = 0.5;
$DamageScale[MLRS, $BleedDamageType] = 0.0;
$DamageScale[MLRS, $GrenadeDamageType] = 0.5;
$DamageScale[MLRS, $PoisonDamageType] = 0.0;
$DamageScale[MLRS, $SmokeDamageType] = 0.0;
$DamageScale[MLRS, $StabDamageType] = 0.0;

$DamageScale[MineLayer, $ImpactDamageType] = 0.0;
$DamageScale[MineLayer, $BulletDamageType] = 0.2;
$DamageScale[MineLayer, $PlasmaDamageType] = 0.5;
$DamageScale[MineLayer, $EnergyDamageType] = 1.0;
$DamageScale[MineLayer, $ExplosionDamageType] = 0.8;
$DamageScale[MineLayer, $ShrapnelDamageType] = 0.8;
$DamageScale[MineLayer, $DebrisDamageType] = 0.7;
$DamageScale[MineLayer, $MissileDamageType] = 3.0;
$DamageScale[MineLayer, $LaserDamageType] = 0.0;
$DamageScale[MineLayer, $MortarDamageType] = 0.8;
$DamageScale[MineLayer, $BlasterDamageType] = 0.5;
$DamageScale[MineLayer, $ElectricityDamageType] = 1.0;
$DamageScale[MineLayer, $MineDamageType]        = 0.8;
$DamageScale[MineLayer, $ChargeDamageType]       = 1.0;
$DamageScale[MineLayer, $AirstrikeDamageType]   = 1.0;
$DamageScale[MineLayer, $BleedDamageType] = 0.0;
$DamageScale[MineLayer, $GrenadeDamageType] = 0.5;
$DamageScale[MineLayer, $PoisonDamageType] = 0.0;
$DamageScale[MineLayer, $SmokeDamageType] = 0.0;
$DamageScale[MineLayer, $StabDamageType] = 0.0;

$VehicleAmmoType[Humvee, 2] = TOWAmmo;
$VehicleAmmoType[Humvee, 3] = AutoGrenAmmo;

$VehicleAmmoType[Abrams, 2] = AbramsAmmo;
$VehicleAmmoType[Abrams, 3] = MinigunAmmo;

$VehicleAmmoType[Gunship, 4] = AbramsAmmo;
$VehicleAmmoType[Gunship, 5] = FortymmAmmo;
$VehicleAmmoType[Gunship, 2] = TwentyFivemmAmmo;
$VehicleAmmoType[Gunship, 3] = TwentyFivemmAmmo;

$VehicleAmmoType[Blackhawk, 2] = MinigunAmmo;
$VehicleAmmoType[Blackhawk, 3] = MinigunAmmo;

$VehicleAmmoType[Bradley, 2] = TOWAmmo;
$VehicleAmmoType[Bradley, 3] = TwentyFivemmAmmo;
$VehicleAmmoType[Bradley, 4] = Minigunammo;

$VehicleAmmoType[LineBacker, 2] = StingerLauncherAmmo;
$VehicleAmmoType[LineBacker, 3] = TwentyFivemmAmmo;
$VehicleAmmoType[LineBacker, 4] = Minigunammo;

$VehicleAmmoType[MLRS, 2] = MLRSAmmo;

$VehicleReloadRate[TOWAmmo] = 2;
$VehicleReloadRate[AutoGrenAmmo] = 10;
$VehicleReloadRate[AbramsAmmo] = 8;
$VehicleReloadRate[MinigunAmmo] = 80;
$VehicleReloadRate[TwentyFivemmAmmo] = 70;
$VehicleReloadRate[FortymmAmmo] = 50;
$VehicleReloadRate[StingerLauncherAmmo] = 2;
$VehicleReloadRate[MLRSAmmo] = 1;

$VehicleAmmoMax[Humvee, TOWAmmo] = 8;
$VehicleAmmoMax[Humvee, AutoGrenAmmo] = 50;

$VehicleAmmoMax[Abrams, AbramsAmmo] = 30;
$VehicleAmmoMax[Abrams, MinigunAmmo] = 400;

$VehicleAmmoMax[Gunship, AbramsAmmo] = 30;
$VehicleAmmoMax[Gunship, FortymmAmmo] = 300;
$VehicleAmmoMax[Gunship, TwentyFivemmAmmo] = 700;

$VehicleAmmoMax[Blackhawk, MinigunAmmo] = 400;

$VehicleAmmoMax[Bradley, TOWAmmo] = 2;
$VehicleAmmoMax[Bradley, MinigunAmmo] = 700;
$VehicleAmmoMax[Bradley, TwentyFivemmAmmo] = 500;

$VehicleAmmoMax[LineBacker, StingerLauncherAmmo] = 10;
$VehicleAmmoMax[LineBacker, MinigunAmmo] = 1000;
$VehicleAmmoMax[LineBacker, TwentyFivemmAmmo] = 700;

$VehicleAmmoMax[MLRS, MLRSAmmo] = 12;

// ------ Vehicle weapons ------

// MineLayer
$VehicleHPSpace[MineLayer] = 0.1; //Doesnt matter.
$VehicleSWType[MineLayer] = false;

$VehiclePrimaryGuns[MineLayer] = 1;
$VehicleWeapon[MineLayer, 0] = Volcano;
$VehicleWeaponAmmoMax[MineLayer, Volcano] = 10;
$VehicleWeapFireDelay[MineLayer, Volcano] = 1.00;


// WARTHOG
$VehicleHPSpace[MoveWarthog] = 0.8;
$VehicleSWType[MoveWarthog] = false;

$BombBay[MoveWarthog] = 0;
$VehicleMaxHardPoints[MoveWarthog] = 11;
$VehiclePrimaryGuns[MoveWarthog] = 1;
$VehicleWeapon[MoveWarthog, 0] = WarthogBullet;
//$VehicleWeapon[MoveWarthog, 1] = ApacheRocket;
//$VehicleWeapon[MoveWarthog, 2] = BigBomb;

$VehicleWeaponAmmoMax[MoveWarthog, WarthogBullet] = 1100;
$VehicleWeaponAmmoMax[MoveWarthog, SidewinderRocket] = 11;
$VehicleWeaponAmmoMax[MoveWarthog, ApacheRocket] = 44;
$VehicleWeaponAmmoMax[MoveWarthog, MavMiss] = 11;
$VehicleWeaponAmmoMax[MoveWarthog, HydraRocket] = 209;
$VehicleWeaponAmmoMax[MoveWarthog, BigBomb] = 5;
$VehicleWeaponAmmoMax[MoveWarthog, BombShell] = 3;
$VehicleWeaponAmmoMax[MoveWarthog, APClusterBomb] = 11;
$VehicleWeaponAmmoMax[MoveWarthog, MineClusterBomb] = 11;
$VehicleWeaponAmmoMax[MoveWarthog, BombletClusterBomb] = 11;
$VehicleWeaponAmmoMax[MoveWarthog, BunkerBusterBomb] = 11;
$VehicleWeaponAmmoMax[MoveWarthog, TankSmoke] = 250;
$VehicleWeaponAmmoMax[MoveWarthog, TankNerveGas] = 250;
$VehicleWeaponAmmoMax[MoveWarthog, NapalmBomb] = 3;
$VehicleWeaponAmmoMax[MoveWarthog, EMCContainer] = 1;
//leave on, and list all available weaponry. must fix reloader pack. must make move warthog switch ALL variables over, or delete it.

$VehicleWeapFireDelay[MoveWarthog, WarthogBullet] = 0.0333;
$VehicleWeapFireDelay[MoveWarthog, StingerMissile] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, ApacheRocket] = 0.5; 
$VehicleWeapFireDelay[MoveWarthog, MavMiss] = 1.5;
$VehicleWeapFireDelay[MoveWarthog, HydraRocket] = 0.1;
$VehicleWeapFireDelay[MoveWarthog, BigBomb] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, BombShell] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, APClusterBomb] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, MineClusterBomb] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, BombletClusterBomb] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, BunkerBusterBomb] = 1.0;
$VehicleWeapFireDelay[MoveWarthog, TankSmoke] = 0.3;
$VehicleWeapFireDelay[MoveWarthog, TankNerveGas] = 0.3;
$VehicleWeapFireDelay[MoveWarthog, NapalmBomb] = 1.5;
$VehicleWeapFireDelay[MoveWarthog, EMCContainer] = 1.0;

$VehicleHPSpace[Warthog] = 0.8;
$VehicleSWType[Warthog] = false;

$BombBay[Warthog] = 0;
$VehicleMaxHardPoints[Warthog] = 11;
$VehiclePrimaryGuns[Warthog] = 1;
$VehicleWeapon[Warthog, 0] = WarthogBullet;
//$VehicleWeapon[Warthog, 1] = ApacheRocket;
//$VehicleWeapon[Warthog, 2] = BigBomb;

$VehicleWeaponAmmoMax[Warthog, WarthogBullet] = 1100;
$VehicleWeaponAmmoMax[Warthog, SidewinderRocket] = 11;
$VehicleWeaponAmmoMax[Warthog, ApacheRocket] = 44;
$VehicleWeaponAmmoMax[Warthog, MavMiss] = 11;
$VehicleWeaponAmmoMax[Warthog, HydraRocket] = 209;
$VehicleWeaponAmmoMax[Warthog, BigBomb] = 5;
$VehicleWeaponAmmoMax[Warthog, BombShell] = 3;
$VehicleWeaponAmmoMax[Warthog, APClusterBomb] = 11;
$VehicleWeaponAmmoMax[Warthog, MineClusterBomb] = 11;
$VehicleWeaponAmmoMax[Warthog, BombletClusterBomb] = 11;
$VehicleWeaponAmmoMax[Warthog, BunkerBusterBomb] = 11;
$VehicleWeaponAmmoMax[Warthog, TankSmoke] = 250;
$VehicleWeaponAmmoMax[Warthog, TankNerveGas] = 250;
$VehicleWeaponAmmoMax[Warthog, NapalmBomb] = 3;
$VehicleWeaponAmmoMax[Warthog, EMCContainer] = 1;

$VehicleWeapFireDelay[Warthog, WarthogBullet] = 0.0333;
$VehicleWeapFireDelay[Warthog, StingerMissile] = 1.0;
$VehicleWeapFireDelay[Warthog, ApacheRocket] = 0.7; 
$VehicleWeapFireDelay[Warthog, MavMiss] = 2.0;
$VehicleWeapFireDelay[Warthog, HydraRocket] = 0.1;
$VehicleWeapFireDelay[Warthog, BigBomb] = 1.0;
$VehicleWeapFireDelay[Warthog, BombShell] = 1.0;
$VehicleWeapFireDelay[Warthog, APClusterBomb] = 1.0;
$VehicleWeapFireDelay[Warthog, MineClusterBomb] = 1.0;
$VehicleWeapFireDelay[Warthog, BombletClusterBomb] = 1.0;
$VehicleWeapFireDelay[Warthog, BunkerBusterBomb] = 1.0;
$VehicleWeapFireDelay[Warthog, TankSmoke] = 0.3;
$VehicleWeapFireDelay[Warthog, TankNerveGas] = 0.3;
$VehicleWeapFireDelay[Warthog, NapalmBomb] = 1.5;
$VehicleWeapFireDelay[Warthog, EMCContainer] = 1.0;

// FIGHTER
$VehicleHPSpace[fighter] = 0.9;
$VehicleSWType[fighter] = true;

$BombBay[Fighter] = 0;
$VehicleMaxHardPoints[Fighter] = 7;
$VehiclePrimaryGuns[Fighter] = 1;
$VehicleWeapon[Fighter, 0] = NATOBullet;
//$VehicleWeapon[Fighter, 1] = MavMiss;
//$VehicleWeapon[Fighter, 2] = StingerMissile;

$VehicleWeaponAmmoMax[Fighter, NATOBullet] = 511;
$VehicleWeaponAmmoMax[Fighter, SidewinderRocket] = 7;
$VehicleWeaponAmmoMax[Fighter, MavMiss] = 7;
$VehicleWeaponAmmoMax[Fighter, HARMRocket] = 7;
$VehicleWeaponAmmoMax[Fighter, BigBomb] = 3;
$VehicleWeaponAmmoMax[Fighter, BombShell] = 2;
$VehicleWeaponAmmoMax[Fighter, APClusterBomb] = 7;
$VehicleWeaponAmmoMax[Fighter, MineClusterBomb] = 7;
$VehicleWeaponAmmoMax[Fighter, BombletClusterBomb] = 7;
$VehicleWeaponAmmoMax[Fighter, BunkerBusterBomb] = 7;
$VehicleWeaponAmmoMax[Fighter, TankSmoke] = 150;
$VehicleWeaponAmmoMax[Fighter, TankNerveGas] = 150;
$VehicleWeaponAmmoMax[Fighter, NapalmBomb] = 2;
$VehicleWeaponAmmoMax[Fighter, EMCContainer] = 1;

$VehicleWeapFireDelay[Fighter, NATOBullet] = 0.05;
$VehicleWeapFireDelay[Fighter, SidewinderRocket] = 1.0;
$VehicleWeapFireDelay[Fighter, MavMiss] = 2.0;
$VehicleWeapFireDelay[Fighter, HARMRocket] = 1.0;
$VehicleWeapFireDelay[Fighter, BigBomb] = 1.0;
$VehicleWeapFireDelay[Fighter, BombShell] = 1.0;
$VehicleWeapFireDelay[Fighter, APClusterBomb] = 1.0;
$VehicleWeapFireDelay[Fighter, MineClusterBomb] = 1.0;
$VehicleWeapFireDelay[Fighter, BombletClusterBomb] = 1.0;
$VehicleWeapFireDelay[Fighter, BunkerBusterBomb] = 1.0;
$VehicleWeapFireDelay[Fighter, TankSmoke] = 0.05;
$VehicleWeapFireDelay[Fighter, TankNerveGas] = 0.05;
$VehicleWeapFireDelay[Fighter, NapalmBomb] = 1.5;
$VehicleWeapFireDelay[Fighter, EMCContainer] = 1.0;


// DIVEBOMBER
//$VehiclePrimaryGuns[DiveBomber] = 2;
//$VehicleWeapon[DiveBomber, 0] = NATOBullet;
//$VehicleWeapon[DiveBomber, 1] = BombShell;

//$VehicleWeaponAmmoMax[DiveBomber, SAWBullet] = 200;
//$VehicleWeaponAmmoMax[DiveBomber, BombShell] = 1;

//$VehicleWeapFireDelay[DiveBomber, SAWBullet] = 0.05;
//$VehicleWeapFireDelay[DiveBomber, BombShell] = 3;

// FIGHTER2
$VehicleHPSpace[fighter2] = 0.9;
$VehicleSWType[fighter2] = true;

$BombBay[Fighter2] = 0;
$VehicleMaxHardPoints[Fighter2] = 6;
$VehiclePrimaryGuns[Fighter2] = 1;
$VehicleWeapon[Fighter2, 0] = NATOBullet;
//$VehicleWeapon[Fighter2, 1] = PhoenixRocket;
//$VehicleWeapon[Fighter2, 2] = StingerMissile;

$VehicleWeaponAmmoMax[Fighter2, NATOBullet] = 511;
$VehicleWeaponAmmoMax[Fighter2, SidewinderRocket] = 4;
$VehicleWeaponAmmoMax[Fighter2, PhoenixRocket] = 6;
$VehicleWeaponAmmoMax[Fighter2, BigBomb] = 3;
$VehicleWeaponAmmoMax[Fighter2, BombShell] = 2;
$VehicleWeaponAmmoMax[Fighter2, BombletClusterBomb] = 6;
$VehicleWeaponAmmoMax[Fighter2, EMCContainer] = 1;

$VehicleWeapFireDelay[Fighter2, NATOBullet] = 0.02;
$VehicleWeapFireDelay[Fighter2, SidewinderRocket] = 1.0;
$VehicleWeapFireDelay[Fighter2, PhoenixRocket] = 1.0;
$VehicleWeapFireDelay[Fighter2, BigBomb] = 1.0;
$VehicleWeapFireDelay[Fighter2, BombShell] = 1.0;
$VehicleWeapFireDelay[Fighter2, BombletClusterBomb] = 1.0;
$VehicleWeapFireDelay[Fighter2, EMCContainer] = 1.0;

// APACHE
$BombBay[Apache] = 0;
$VehicleHPSpace[apache] = 0.9;
$VehicleSWType[apache] = false;

$VehicleMaxHardPoints[Apache] = 4; // Apache has 4 "all purpose" (can only use 
	//Hellfire or hydra racks) HPs, but has 2 additional sidewinder only HPs.
$VehiclePrimaryGuns[Apache] = 1;
$VehicleWeapon[Apache, 0] = WarthogBullet;
//$VehicleWeapon[Apache, 1] = ApacheRocket;
//$VehicleWeapon[Apache, 2] = StingerMissile;

$VehicleWeaponAmmoMax[Apache, WarthogBullet] = 1200;
$VehicleWeaponAmmoMax[Apache, SidewinderRocket] = 2;
$VehicleWeaponAmmoMax[Apache, ApacheRocket] = 16;
$VehicleWeaponAmmoMax[Apache, HydraRocket] = 76;
$VehicleWeaponAmmoMax[Apache, EMCContainer] = 1;

$VehicleWeapFireDelay[Apache, WarthogBullet] = 0.0909;
$VehicleWeapFireDelay[Apache, ApacheRocket] = 0.7;
$VehicleWeapFireDelay[Apache, HydraRocket] = 0.1;
$VehicleWeapFireDelay[Apache, SidewinderRocket] = 1.0;
$VehicleWeapFireDelay[Apache, EMCContainer] = 1.0;

// HIND
$VehicleHPSpace[hind] = 1.5;
$VehicleSWType[hind] = false;

$BombBay[Hind] = 0;
$VehicleMaxHardPoints[Hind] = 6;
$VehiclePrimaryGuns[Hind] = 1;
$VehicleWeapon[Hind, 0] = WarthogBullet;
//$VehicleWeapon[Hind, 1] = ApacheRocket;
//$VehicleWeapon[Hind, 2] = StingerMissile;

$VehicleWeaponAmmoMax[Hind, WarthogBullet] = 750;
$VehicleWeaponAmmoMax[Hind, SidewinderRocket] = 6;
$VehicleWeaponAmmoMax[Hind, ApacheRocket] = 24;
$VehicleWeaponAmmoMax[Hind, TwentyFivemmBullet] = 1500;
$VehicleWeaponAmmoMax[Hind, SAWBullet] = 4500;
$VehicleWeaponAmmoMax[Hind, BigBomb] = 3;
$VehicleWeaponAmmoMax[Hind, APClusterBomb] = 6;
$VehicleWeaponAmmoMax[Hind, MineClusterBomb] = 6;
$VehicleWeaponAmmoMax[Hind, BombletClusterBomb] = 6;
$VehicleWeaponAmmoMax[Hind, BunkerBusterBomb] = 6;
$VehicleWeaponAmmoMax[Hind, TankSmoke] = 150;
$VehicleWeaponAmmoMax[Hind, TankNerveGas] = 150;
$VehicleWeaponAmmoMax[Hind, NapalmBomb] = 2;
$VehicleWeaponAmmoMax[Hind, EMCContainer] = 1;

$VehicleWeapFireDelay[Hind, WarthogBullet] = 0.03;
$VehicleWeapFireDelay[Hind, SidewinderRocket] = 1.0;
$VehicleWeapFireDelay[Hind, ApacheRocket] = 0.9;
$VehicleWeapFireDelay[Hind, TwentyFivemmBullet] = 0.02;
$VehicleWeapFireDelay[Hind, SAWBullet] = 0.015;
$VehicleWeapFireDelay[Hind, BigBomb] = 1.0;
$VehicleWeapFireDelay[Hind, APClusterBomb] = 1.0;
$VehicleWeapFireDelay[Hind, MineClusterBomb] = 1.0;
$VehicleWeapFireDelay[Hind, BombletClusterBomb] = 1.0;
$VehicleWeapFireDelay[Hind, BunkerBusterBomb] = 1.0;
$VehicleWeapFireDelay[Hind, TankSmoke] = 0.3;
$VehicleWeapFireDelay[Hind, TankNerveGas] = 0.3;
$VehicleWeapFireDelay[Hind, NapalmBomb] = 1.5;
$VehicleWeapFireDelay[Hind, EMCContainer] = 1.0;

// Bomber
$VehicleHPSpace[Bomber] = 1.5; // doesnt matter
$VehicleSWType[Bomber] = false;

$BombBay[Bomber] = 1;
$BombBayMax[Bomber] = 54;
$VehicleMaxHardPoints[Bomber] = 0;
$VehiclePrimaryGuns[Bomber] = 0;
//$VehicleWeapon[Bomber, 0] = BombShell;

$VehicleWeaponAmmoMax[Bomber, BigBomb] = 54;
$VehicleWeaponAmmoMax[Bomber, BombShell] = 27;
$VehicleWeaponAmmoMax[Bomber, NukeShell] = 1;

$VehicleWeapFireDelay[Bomber, BigBomb] = 0.3;
$VehicleWeapFireDelay[Bomber, BombShell] = 0.3;
$VehicleWeapFireDelay[Bomber, NukeShell] = 1.0;

// Hercules (special)
$VehicleHPSpace[Hercules] = 1.5; // doesnt matter
$VehicleSWType[Hercules] = false;

$BombBay[Hercules] = 1;
$BombBayMax[Hercules] = 4;
$VehicleMaxHardPoints[Hercules] = 0;
$VehiclePrimaryGuns[Hercules] = 0;
//$VehicleWeapon[Hercules, 0] = DaisyShell;

$VehicleWeaponAmmoMax[Hercules, DaisyShell] = 4;
$VehicleWeaponAmmoMax[Hercules, SupplyDrop] = 4;

$VehicleWeapFireDelay[Hercules, DaisyShell] = 2.0;
$VehicleWeapFireDelay[Hercules, SupplyDrop] = 2.0;

// GENERAL WEAP DESCRIPTIONS

$WeaponDesc[NATOBullet] = "20mm Chain Gun";
$WeaponDesc[SAWBullet] = "12.7mm Chain Gun";
$WeaponDesc[TwentyFivemmBullet] = "23mm Chain Gun";
$WeaponDesc[WarthogBullet] = "30mm Cannon";
$WeaponDesc[Volcano] = "Volcano Mining System";

$WeaponDesc[SidewinderRocket] = "AIM-9J Sidewinder Missile";
$WeaponDesc[PhoenixRocket] = "AIM-54 Phoenix Missile";
$WeaponDesc[ApacheRocket] = "AGM-114 Hellfire Missile";
$WeaponDesc[HydraRocket] = "2.75inch Hydra-70";
$WeaponDesc[MavMiss] = "AGM-65 Maverick Missile";
$WeaponDesc[HARMRocket] = "AGM-88 HARM Missile";

$WeaponDesc[BigBomb] = "Mk82 500Lb Bomb";
$WeaponDesc[BombShell] = "Mk84 2000Lb Bomb";
$WeaponDesc[APClusterBomb] = "CBU-59 APAM Bomb";
$WeaponDesc[MineClusterBomb] = "CBU-89 Gator Mine Bomb";
$WeaponDesc[BombletClusterBomb] = "CBU-87 Cluster Bomb";
$WeaponDesc[BunkerBusterBomb] = "BLU-113 Penetrator Bomb";
$WeaponDesc[TankSmoke] = "M-10 Smoke Tank";
$WeaponDesc[TankNerveGas] = "M-10 Tear Gas Tank";
$WeaponDesc[NapalmBomb] = "Mk-77 Incendiary Bomb";

$WeaponDesc[NukeShell] = "Mk-53 Hydrogen Bomb";
$WeaponDesc[DaisyShell] = "BLU-82B Daisy Cutter Bomb";

$WeaponDesc[SupplyDrop] = "Standard Supply Crate";
$WeaponDesc[EMCContainer] = "ALQ-131 EMC Pod";

$WeaponReloadRate[NATOBullet] = 14;
$WeaponReloadRate[WarthogBullet] = 17;
$WeaponReloadRate[Volcano] = 5;
// Only the bullets are relevent now.
//$WeaponReloadRate[ApacheRocket] = 5;
//$WeaponReloadRate[PhoenixRocket] = 5;
//$WeaponReloadRate[StingerMissile] = 5;
//$WeaponReloadRate[BigBomb] = 1;
//$WeaponReloadRate[BombShell] = 1;
//$WeaponReloadRate[MavMiss] = 3;


// OutDated: no need for any of this code (requiresLock part) because, we dont work that way anymore. Leaving it in because it wont hurt anything.

$WeaponRequiresLock[SAWBullet] = False;
$WeaponRequiresLock[NATOBullet] = False;
$WeaponRequiresLock[TwentyFivemmBullet] = False;
$WeaponRequiresLock[WarthogBullet] = False;
$WeaponRequiresLock[Volcano] = False;

$WeaponRequiresLock[SidewinderRocket] = True;
$WeaponRequiresLock[PhoenixRocket] = True;
$WeaponRequiresLock[ApacheRocket] = False;
$WeaponRequiresLock[HydraRocket] = False;
$WeaponRequiresLock[MavMiss] = False;
$WeaponRequiresLock[HARMRocket] = True;

$WeaponRequiresLock[BigBomb] = False;
$WeaponRequiresLock[BombShell] = False;
$WeaponRequiresLock[APClusterBomb] = False;
$WeaponRequiresLock[MineClusterBomb] = False;
$WeaponRequiresLock[BombletClusterBomb] = False;
$WeaponRequiresLock[BunkerBusterBomb] = False;
$WeaponRequiresLock[TankSmoke] = False;
$WeaponRequiresLock[TankNerveGas] = False;
$WeaponRequiresLock[NapalmBomb] = False;

$WeaponRequiresLock[NukeShell] = False;
$WeaponRequiresLock[DaisyShell] = False;

$WeaponRequiresLock[SupplyDrop] = False;
$WeaponRequiresLock[EMCContainer] = False;


$WeaponFreeFall[SAWBullet] = False;
$WeaponFreeFall[NATOBullet] = False;
$WeaponFreeFall[TwentyFivemmBullet] = False;
$WeaponFreeFall[WarthogBullet] = False;
$WeaponFreeFall[Volcano] = False;

$WeaponFreeFall[SidewinderRocket] = False;
$WeaponFreeFall[PhoenixRocket] = False;
$WeaponFreeFall[ApacheRocket] = False;
$WeaponFreeFall[HydraRocket] = False;
$WeaponFreeFall[MavMiss] = False;
$WeaponFreeFall[HARMRocket] = False;

$WeaponFreeFall[BigBomb] = True;
$WeaponFreeFall[BombShell] = True;
$WeaponFreeFall[APClusterBomb] = True;
$WeaponFreeFall[MineClusterBomb] = True;
$WeaponFreeFall[BombletClusterBomb] = True;
$WeaponFreeFall[BunkerBusterBomb] = True;
$WeaponFreeFall[TankSmoke] = True;
$WeaponFreeFall[TankNerveGas] = True;
$WeaponFreeFall[NapalmBomb] = True;

$WeaponFreeFall[NukeShell] = True;
$WeaponFreeFall[DaisyShell] = True;

$WeaponFreeFall[SupplyDrop] = True;
$WeaponFreeFall[EMCContainer] = True;


$WeaponSound[NATOBullet] = shockExplosion;
$WeaponSound[SAWBullet] = shockExplosion;
$WeaponSound[TwentyFivemmBullet] = shockExplosion;
$WeaponSound[WarthogBullet] = shockExplosion;
$WeaponSound[Volcano] = SoundDryFire;

$WeaponSound[SidewinderRocket] = SoundFireFlierRocket;
$WeaponSound[PhoenixRocket] = SoundFireFlierRocket;
$WeaponSound[ApacheRocket] = SoundFireFlierRocket;
$WeaponSound[HydraRocket] = SoundFireFlierRocket;
$WeaponSound[MavMiss] = SoundFireFlierRocket;
$WeaponSound[HARMRocket] = SoundFireFlierRocket;

$WeaponSound[BigBomb] = SoundDryFire;
$WeaponSound[BombShell] = SoundDryFire;
$WeaponSound[APClusterBomb] = SoundDryFire;
$WeaponSound[MineClusterBomb] = SoundDryFire;
$WeaponSound[BombletClusterBomb] = SoundDryFire;
$WeaponSound[BunkerBusterBomb] = SoundDryFire;
$WeaponSound[TankSmoke] = SoundDryFire;
$WeaponSound[TankNerveGas] = SoundDryFire;
$WeaponSound[NapalmBomb] = SoundDryFire;

$WeaponSound[NukeShell] = SoundDryFire;
$WeaponSound[DaisyShell] = SoundDryFire;

$WeaponSound[SupplyDrop] = SoundDryFire;
$WeaponSound[EMCContainer] = SoundDryFire;


//-Modes that use Lock On
//::WingMount	= Mounted on the wings and alternate sides
//::Laser	= Mounted on the Nose, Laser fire
//::NoseFire	= Mounted on the Nose normal fire
//::BombA	= Fire from center of the vehicle and drops down
//::BombB	= Fire from center of the vehicle and uses path
//::LockOnA	= Requires a Lock On
//::LockOnB	= Lock On supported but not required
//::LockOnC	= Lock On supported but not required bomb fall mode
//::Deflect	= Deflects and shields against all attacks for a limited time
//::Shield	= Shields against as long as it is activated, disables firing ability
//::Detonate	= Detonates current vehicle
//::Spike	= Sequential projectiles spawned to form a sphere
//::DropA	= Pickup vehicle/Drop vehicle.
//::DropB	= Drop infantry. Infantry cannot voluntarilly jump from this vehicle.




// END DELTA FORCE VEHICLES
// --------------------------------------------------

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

function Vehicle::onFire(%this)
{

//for(%x = -1; %x < 8; %x++){
//	echo($Vehicleownedweapon[%this,%x]);
//	echo($VehicleWeaponAmmo[%this, $Vehicleownedweapon[%this,%x]]);
//	
//}
	%name = GameBase::getDataName(%this);
	%weapNum = $VehicleGuns[%this];
	%player = GameBase::getControlClient(%this);
	if(%name == Apache)
		%hp = $VehicleMaxHardPoints[%name]+2;
	else
		%hp = $VehicleMaxHardPoints[%name];
	if(%weapNum > 0)
	{
		if($VehicleCanFire[%this])
		{
			%weapName = $VehicleOwnedWeapon[%this,$VehicleCurWeapon[%this]];
			%oldweap = %weapname;
							
			//echo(%weapName@" " @$VehicleWeaponAmmo[%this,%weapName]);
			if($VehicleWeaponAmmo[%this, %weapName] > 0 && %player.hflink != 2)
			{
				$weapPName[%this] = $WeaponDesc[$VehicleOwnedWeapon[%this,$VehicleCurWeapon[%this]]];
				// Fire the gun
				%weaponNum = $VehicleWeapToFire[%this,%weapname];
				%wasat = %weaponNum;
				%vel = Item::getVelocity(%this);
				%playerVel = %vel;
				%rot = GameBase::getRotation(%this);                             
				%pos = getBoxCenter(%this);

				%pos = GetOffSetRot("0 2.5 -.3",%Rot,%Pos);

				
				// Pirmary weapon, or a non-hardpoint Put on nose.
				%transorg = GameBase::getMuzzleTransform(%this);
				%transform = getword(%transorg,0)@" "@getword(%transorg,1)@" "@getword(%transorg,2)@" "@
						getword(%transorg,3)@" "@getword(%transorg,4)@" "@getword(%transorg,5)@" ";
				if(%player.hflink == 0 || $BombBay[%name])
				{
					if($VehicleWeapon[%name,0] != %weapName && !$BombBay[%name])
					{

						
						//Move to next HP position to fire.
						%weaponNum = %weaponNum+1; 
						if(%weaponNum == %hp)
							 %weaponNum = 0;
						while($VehicleHPList[%this,%weaponNum] != %Weapname && %weaponNum != %wasat)
						{
							%weaponNum = %weaponNum+1; 
							if(%weaponNum == %hp)
								 %weaponNum = 0;
						}
						$VehicleWeapToFire[%this,%weapName] = %weaponNum;					

						// If we have an odd number of hardpoints.
						if((%hp%2) == 1)
							%mod = 1; //Move things by 1
						else
							%mod = 2; //Else move things up 2				
		
						// If were sweep winged, give us a sweep
						if($VehicleSWType[%name])
							%pos = GetOffSetRot("0 "@ -0.1*floor((%weaponNum+%mod)/2) @" 0",%Rot,%Pos);		

						// Calculate our launch position
						%pos = GetOffSetRot(
							pow(-1,(%mod+%weaponNum))*$VehicleHPSpace[%name]*floor((%weaponNum+%mod)/2) @" 0 0",%Rot,%Pos);	
					}
					%transform = %transform @ %Rot @" "@ %pos;
				
					if($WeaponRequiresLock[%weapName]) //Really only applies to sidewinders right now. If more locking missiles are added, this will need to be modified
					{
					   if($LockingMode[%player] == 0) {
						GameBase::getLOSInfo(%this, 1000);
						if(%weapName == HARMRocket)// if HARMRocket, just spawn rocket for newlocking code. If not, then normal vehicle lock.
						{
							Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
						}
						else if (%weapName == SidewinderRocket && (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship)){
							%projectile = Projectile::spawnProjectile(SidewinderMissile, %transform, %this, %playerVel, $los::object);
							BottomPrint(%player, "<jc>Lock Achieved", 3);
							warningMessage(GameBase::getControlClient($los::object), %projectile);
						}
						else if (%weapName == PhoenixRocket && (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship)){
							%projectile = Projectile::spawnProjectile(PhoenixMissile, %transform, %this, %playerVel, $los::object);
							BottomPrint(%player, "<jc>Lock Achieved", 3);
							warningMessage(GameBase::getControlClient($los::object), %projectile);
						}
						else 
						{
							Bottomprint(%player, "<jc>Weapon Lock Not Achieved", 3);
							return;
						}
					   } else {
						%projectile = Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
					   	%projectile.owner = %this;	
					   }
					} else if($WeaponFreeFall[%weapName])
					{
						if(%weapName == EMCContainer){
							CenterPrint(GameBase::getControlClient(%this), "EMC Jettisoned", 3);
							Player::setSensorSupression(%this,0);
							Player::setSensorSupression(%player,0);
							%this.EMC = false;
						} else Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);

					// Old and unused
					} else if (%weapName == PhoenixRocket)
					{
					   if($LockingMode[%player] == 0){
						GameBase::getLOSInfo(%this, 1000);
						if (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship){
							%projectile = Projectile::spawnProjectile(PhoenixMissile, %transform, %this, %playerVel, $los::object);
							BottomPrint(%player, "<jc>Lock Achieved", 3);
							warningMessage(GameBase::getControlClient($los::object), %projectile);
						}
						else 
						{
							%projectile = Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
					   		%projectile.owner = %this;	
					   	}
					   } else {
						Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
					   }
					} else if(%weapName == volcano) {
						VolcanicEruption(%this, %player);
			
					} else Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);

					GameBase::playSound(%this, $WeaponSound[%weapName], 3);
	
					// Set up fire delay until next shot
					$VehicleCanFire[%this] = False;
					%delay = $VehicleWeapFireDelay[%name, %weapName];
					schedule("$VehicleCanFire["@%this@"] = True;", %delay, %this);  		
	
					// Decrement ammo count
					$VehicleWeaponAmmo[%this, %weapName]--;
						

					// Decrease Hard Point count, or count down to doing so, if neccessary.	
					if( $VehicleCurWeapon[%this] <= %hp  && ($BombBay[%name] == 0)) 
					{
						%notdone = $VModuleHP[$WeaponToNumber[%weapname]];
						for(%i = %weaponNum; %i < %hp  && %NotDone;%i++)
						{
							if($VehicleHPList[%this,%i] == %weapName) {
								%NotDone--;
								$VehicleHPAmmoLeft[%this,%i]--;
							}
						}

						if( $VehicleHPAmmoLeft[%this,%weaponNum] < 1 )
						{	
							$VehicleHP[%this] = $VehicleHP[%this] - $VmoduleHP[$WeaponToNumber[%weapName]];
							
							%notdone = $VModuleHP[$WeaponToNumber[%weapname]];
							for(%i = %weaponNum; %i < $vehicleMaxHardPoints[%name] && %NotDone;%i++)
							{
								if($VehicleHPList[%this,%i] == %weapName) {
									%NotDone--;
									$VehicleHPList[%this,%i] = "";
								}
							}
							
						
	
							if(%weapName == TankSmoke)
							{
								Projectile::spawnProjectile(Tank, %transform, %this, %playerVel);
								CenterPrint(GameBase::getControlClient(%this), "Smoke Tank Jettisoned", 3);					
		
							} else if(%weapName == TankNerveGas)
							{
								Projectile::spawnProjectile(Tank, %transform, %this, %playerVel);
								CenterPrint(GameBase::getControlClient(%this), "Nerve Gas Tank Jettisoned", 3);
							}
						}
						if(%weapName == SideWinderRocket && %name == Apache){
							$VehicleSWHP[%this] = $VehicleSWHP[%this] - $VmoduleHP[$WeaponToNumber[%weapName]];
						}
					}
					
					// Decrease number of weapons ($VehicleGuns[]) and switch weapons if out of ammo. Have to pack the list of weapons too.. grrr...
					if($VehicleWeaponAmmo[%this, %weapName] == 0 && $VehicleCurWeapon[%this] >= $VehiclePrimaryGuns[%name]){
						%weaponToRemove = -1;
						for(%i = $VehiclePrimaryGuns[%name]; %i <= $VehicleGuns[%this]; %i++)
						{
							if($VehicleOwnedWeapon[%this, %i] == %weapName)
								%weaponToRemove = %i;
		
						}
						if(%weaponToRemove == -1)
							echo("ERROR: Weapon to remove on the vehicle not found, but out of ammo!!");					
						else{
							for(%i = %weaponToRemove; %i < $VehicleGuns[%this]; %i++)
							{
								$VehicleOwnedWeapon[%this, %i] = $VehicleOwnedWeapon[%this, %i+1];
							}
							$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = Null;
						}
						$VehicleCurWeapon[%this] = $VehicleGuns[%this];
						$VehicleGuns[%this]--;
						//remoteNextWeapon(%this);
					
					}

				} else if(%player.hflink == 1){
					for(%x = -1; %x < 12;%x++)
						$HPToFire[%this,%x] = "";
					$WorseDelay[%this] = 1000;
					if(%weapName == SAWBullet || %weapName == NATOBullet 
					   || %weapName == WarthogBullet || %weapName == TwentyFivemmBullet)
					{
						if(($VehicleWeapon[%name,0] == NATOBullet ||	
						   $VehicleWeapon[%name,0] == WarthogBullet) &&
						   $VehicleWeaponAmmo[%this, %weapName] > 0) 
							$HPToFire[%this,-1] = true;
						%weaponNewNum = 0;
						%wasat = %WeaponNewNum;
						if($VehicleHPList[%this,%weaponNewNum] == SAWBullet || $VehicleHPList[%this,%weaponNewNum] == TwentyFivemmBullet)
							$HPToFire[%this,%weaponNewNum] = true;

						%WeaponNewNum++;
						if(%weaponNewNum >= %hp)
							%weaponNewNum = 0;
						while(%weaponNewNum != %wasat)
						{
							if($VehicleHPList[%this,%weaponNewNum] == SAWBullet || $VehicleHPList[%this,%weaponNewNum] == TwentyFivemmBullet)
								$HPToFire[%this,%weaponNewNum] = true;
							%weaponNewNum = %weaponNewNum+1; 
							if(%weaponNewNum >= %hp)
								 %weaponNewNum = 0;
						}
					} else {
						%weaponNewNum = 0;
						%wasat = %WeaponNewNum;
						if($VehicleHPList[%this,%weaponNewNum] == %weapName)
							$HPToFire[%this,%weaponNewNum] = true;

						%WeaponNewNum++;
						if(%weaponNewNum >= %hp)
							%weaponNewNum = 0;
						while(%weaponNewNum != %wasat)
						{
							if($VehicleHPList[%this,%weaponNewNum] == %weapName)
								$HPToFire[%this,%weaponNewNum] = true;
							%weaponNewNum = %weaponNewNum+1;
							if(%weaponNewNum >= %hp)
								 %weaponNewNum = 0;
						}							
					}
					%fireThis = -1;
					while(%fireThis != %hp)
					{
//echo("START");
//echo(%firethis);
//echo($VehicleHPList[%this,%firethis]);
//echo($VehicleHPAmmoLeft[%this,%firethis]);
						if($HPToFire[%this,%fireThis])
						{
							%pos = getBoxCenter(%this);

							%pos = GetOffSetRot("0 2.5 -.3",%Rot,%Pos);
							%transform = getword(%transorg,0)@" "@getword(%transorg,1)@" "@getword(%transorg,2)@" "@
								getword(%transorg,3)@" "@getword(%transorg,4)@" "@getword(%transorg,5)@" ";
							if(%fireThis != -1)
							{
								// If we have an odd number of hardpoints.
								if((%hp%2) == 1)
									%mod = 1; //Move things by 1
								else
									%mod = 2; //Else move things up 2				
			
								// If were sweep winged, give us a sweep
								if($VehicleSWType[%name])
									%pos = GetOffSetRot("0 "@ -0.1*floor((%fireThis+%mod)/2) @" 0",%Rot,%Pos);		
								// Calculate our launch position
								%pos = GetOffSetRot(
								pow(-1,(%mod+%fireThis))*$VehicleHPSpace[%name]*floor((%fireThis+%mod)/2) @" 0 0",%Rot,%Pos);	
							}
							%transform = %transform @ %Rot @" "@ %pos;
						
							if(%fireThis == -1)
								%weapname = $VehicleWeapon[%name,0];
							else
								%weapname = $VehicleHPList[%this,%fireThis];

							if($WeaponRequiresLock[%weapName]) //Really only applies to sidewinders right now. If more locking missiles are added, this will need to be modified
							{
							   if($LockingMode[%player] == 0) {
								GameBase::getLOSInfo(%this, 1000);
								if(%weapName == HARMRocket)// if HARMRocket, just spawn rocket for newlocking code. If not, then normal vehicle lock.
								{
									Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
								}
								else if (%weapName == SidewinderRocket && (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship)){
									%projectile = Projectile::spawnProjectile(SidewinderMissile, %transform, %this, %playerVel, $los::object);
									BottomPrint(%player, "<jc>Lock Achieved", 3);
									warningMessage(GameBase::getControlClient($los::object), %projectile);
								}
								else if (%weapName == PhoenixRocket && (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship)){
									%projectile = Projectile::spawnProjectile(PhoenixMissile, %transform, %this, %playerVel, $los::object);
									BottomPrint(%player, "<jc>Lock Achieved", 3);
									warningMessage(GameBase::getControlClient($los::object), %projectile);
								}
								else 
								{
									Bottomprint(%player, "<jc>Weapon Lock Not Achieved", 3);
									return;
								}
							   } else {
								%projectile = Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							   	%projectile.owner = %this;	
							   }
							} else if($WeaponFreeFall[%weapName])
							{
								if(%weapName == EMCContainer){
									CenterPrint(GameBase::getControlClient(%this), "EMC Jettisoned", 3);
									Player::setSensorSupression(%this,0);
									Player::setSensorSupression(%player,0);
									%this.EMC = false;
									
								
								} else Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);


							// Old and unused
							} else if (%weapName == PhoenixRocket)
							{
							   if($LockingMode[%player] == 0){
								GameBase::getLOSInfo(%this, 1000);
								if (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship){
									%projectile = Projectile::spawnProjectile(PhoenixMissile, %transform, %this, %playerVel, $los::object);
									BottomPrint(%player, "<jc>Lock Achieved", 3);
									warningMessage(GameBase::getControlClient($los::object), %projectile);
								}
								else 
								{
									%projectile = Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							   		%projectile.owner = %this;	
							   	}
							   } else {
								Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							   }
							} else if(%weapName == volcano) {
								VolcanicEruption(%this, %player);
					
							} else Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							GameBase::playSound(%this, $WeaponSound[%weapName], 3);
			
							// Set up fire delay until next shot
							$VehicleCanFire[%this] = False;
							if($VehicleWeapFireDelay[%name, %weapName] < $WorseDelay[%this])
								$WorseDelay[%this] = $VehicleWeapFireDelay[%name, %weapName];
			
							// Decrement ammo count
							$VehicleWeaponAmmo[%this, %weapName]--;
										

							// Decrease Hard Point count, or count down to doing so, if neccessary.	
//echo("FT2 " @%firethis);
							if( %fireThis != -1 && ($BombBay[%name] == 0)) 
							{
								%notdone = $VModuleHP[$WeaponToNumber[%weapname]];
//echo("ND" @%notDone);
//echo("ONE: " @%i@", "@$VehicleMaxHardPoints[%name]@", "@%notdone);
								for(%i = %firethis; %i < %hp  && %NotDone;%i++)
								{
//echo(%i@", "@$VehicleMaxHardPoints[%name]@", "@%notdone);
//echo($VehicleHPList[%this,%i]@", "@%weapname);
									if($VehicleHPList[%this,%i] == %weapName) {
										%NotDone--;
										$VehicleHPAmmoLeft[%this,%i]--;
									}
								}

							
								if( $VehicleHPAmmoLeft[%this,%firethis] < 1 )
								{	
									$VehicleHP[%this] = $VehicleHP[%this] - $VmoduleHP[$WeaponToNumber[%weapName]];
									
									%notdone = $VModuleHP[$WeaponToNumber[%weapname]];
									for(%i = %firethis; %i < %hp  && %NotDone;%i++)
									{
										if($VehicleHPList[%this,%i] == %weapName) {
											%NotDone--;
											$VehicleHPList[%this,%i] = "";
										}
									}

									if(%weapName == TankSmoke)
									{
										Projectile::spawnProjectile(Tank, %transform, %this, %playerVel);
										CenterPrint(GameBase::getControlClient(%this), "Smoke Tank Jettisoned", 3);					
				
									} else if(%weapName == TankNerveGas)
									{
										Projectile::spawnProjectile(Tank, %transform, %this, %playerVel);
										CenterPrint(GameBase::getControlClient(%this), "Nerve Gas Tank Jettisoned", 3);
									}
								}
								if(%weapName == SideWinderRocket && %name == Apache){
									$VehicleSWHP[%this] = $VehicleSWHP[%this] - $VmoduleHP[$WeaponToNumber[%weapName]];
								}
							}
							
							// Decrease number of weapons ($VehicleGuns[]) and switch weapons if out of ammo. Have to pack the list of weapons too.. grrr...
							if($VehicleWeaponAmmo[%this, %weapName] == 0 && %fireThis != -1){
								%weaponToRemove = -1;
								for(%i = $VehiclePrimaryGuns[%name]; %i <= $VehicleGuns[%this]; %i++)
								{
									if($VehicleOwnedWeapon[%this, %i] == %weapName)
										%weaponToRemove = %i;
				
								}
								if(%weaponToRemove == -1)
									echo("ERROR: Weapon to remove on the vehicle not found, but out of ammo!!");					
								else{
									for(%i = %weaponToRemove; %i < $VehicleGuns[%this]; %i++)
									{
										$VehicleOwnedWeapon[%this, %i] = $VehicleOwnedWeapon[%this, %i+1];
									}
									$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = Null;
								}
								$VehicleCurWeapon[%this] = $VehicleGuns[%this];
								$VehicleGuns[%this]--;
								//remoteNextWeapon(%this);
					
							}
						}

						%fireThis++;
					}
					%delay = $WorseDelay[%this];
					schedule("$VehicleCanFire["@%this@"] = True;", %delay, %this);  		

				} 		
				//Decrease BombBay Count.
				if($VehicleCurWeapon[%this] >= $VehiclePrimaryGuns[%name] && $BombBay[%name] == 1)
				{
					$VehicleBB[%this] = $VehicleBB[%this] - $VmoduleBB[$WeaponToNumber[%weapName]];
					if(%name == Hercules)
						%this.openSeats++;
				

				}				

				%weapName = %oldWeap;
				%enerLevel = $VehicleWeaponAmmo[%this, %weapName] / $VehicleWeaponAmmoMax[%name, %weapName] * 100;
				GameBase::setEnergy(%this, %enerLevel);
				
				
				
			} else if(%player.hflink == 2){

					// Set energy to reflect ammo level
					// Fire the gun
				
				$weapPName[%this] = $WeaponDesc[$VehicleOwnedWeapon[%this,$VehicleCurWeapon[%this]]];
				// Fire the gun
				%weaponNum = $VehicleWeapToFire[%this,%weapname];
				%wasat = %weaponNum;
				%vel = Item::getVelocity(%this);
				%playerVel = %vel;
				%rot = GameBase::getRotation(%this);                             
				%pos = getBoxCenter(%this);		
				%pos = GetOffSetRot("0 2.5 -.3",%Rot,%Pos);	
						
				// Pirmary weapon, or a non-hardpoint Put on nose.
				%transorg = GameBase::getMuzzleTransform(%this);
				%transform = getword(%transorg,0)@" "@getword(%transorg,1)@" "@getword(%transorg,2)@" "@
						getword(%transorg,3)@" "@getword(%transorg,4)@" "@getword(%transorg,5)@" ";
					%oldweap = $LastOn[%this];

					$WorseDelay[%this] = 1000;
					%fireThis = -1;
					while(%fireThis != %hp)
					{
//echo("START");
//echo(%firethis);
//echo($VehicleHPList[%this,%firethis]);
//echo($VehicleHPAmmoLeft[%this,%firethis]);
						if($HPToFire[%this,%fireThis])
						{
							%pos = getBoxCenter(%this);

							%pos = GetOffSetRot("0 2.5 -.3",%Rot,%Pos);
							%transform = getword(%transorg,0)@" "@getword(%transorg,1)@" "@getword(%transorg,2)@" "@
								getword(%transorg,3)@" "@getword(%transorg,4)@" "@getword(%transorg,5)@" ";
							if(%fireThis != -1)
							{
								// If we have an odd number of hardpoints.
								if((%hp%2) == 1)
									%mod = 1; //Move things by 1
								else
									%mod = 2; //Else move things up 2				
			
								// If were sweep winged, give us a sweep
								if($VehicleSWType[%name])
									%pos = GetOffSetRot("0 "@ -0.1*floor((%fireThis+%mod)/2) @" 0",%Rot,%Pos);		
								// Calculate our launch position
								%pos = GetOffSetRot(
								pow(-1,(%mod+%fireThis))*$VehicleHPSpace[%name]*floor((%fireThis+%mod)/2) @" 0 0",%Rot,%Pos);	
							}
							%transform = %transform @ %Rot @" "@ %pos;
						
							if(%fireThis == -1)
								%weapname = $VehicleWeapon[%name,0];
							else
								%weapname = $VehicleHPList[%this,%fireThis];

							if($WeaponRequiresLock[%weapName]) //Really only applies to sidewinders right now. If more locking missiles are added, this will need to be modified
							{
							   if($LockingMode[%player] == 0) {
								GameBase::getLOSInfo(%this, 1000);
								if(%weapName == HARMRocket)// if HARMRocket, just spawn rocket for newlocking code. If not, then normal vehicle lock.
								{
									Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
								}
								else if (%weapName == SidewinderRocket && (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship)){
									%projectile = Projectile::spawnProjectile(SidewinderMissile, %transform, %this, %playerVel, $los::object);
									BottomPrint(%player, "<jc>Lock Achieved", 3);
									warningMessage(GameBase::getControlClient($los::object), %projectile);
								}
								else if (%weapName == PhoenixRocket && (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship)){
									%projectile = Projectile::spawnProjectile(PhoenixMissile, %transform, %this, %playerVel, $los::object);
									BottomPrint(%player, "<jc>Lock Achieved", 3);
									warningMessage(GameBase::getControlClient($los::object), %projectile);
								}
								else 
								{
									Bottomprint(%player, "<jc>Weapon Lock Not Achieved", 3);
									return;
								}
							   } else {
								%projectile = Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							   	%projectile.owner = %this;	
							   }
							} else if($WeaponFreeFall[%weapName])
							{
								if(%weapName == EMCContainer){
									CenterPrint(GameBase::getControlClient(%this), "EMC Jettisoned", 3);
									Player::setSensorSupression(%this,0);
									Player::setSensorSupression(%player,0);
									%this.EMC = false;
								} else Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
	
								// old and unused
							} else if (%weapName == PhoenixRocket)
							{
							   if($LockingMode[%player] == 0){
								GameBase::getLOSInfo(%this, 1000);
								if (GameBase::getDataName($los::object) == Fighter || GameBase::getDataName($los::object) == DiveBomber || GameBase::getDataName($los::object) == Fighter2 || GameBase::getDataName($los::object) == Apache || GameBase::getDataName($los::object) == Blackhawk || GameBase::getDataName($los::object) == Warthog || GameBase::getDataName($los::object) == MoveWarthog || GameBase::getDataName($los::object) == Hind || GameBase::getDataName($los::object) == Bomber || GameBase::getDataName($los::object) == Hercules || GameBase::getDataName($los::object) == Gunship){
									%projectile = Projectile::spawnProjectile(PhoenixMissile, %transform, %this, %playerVel, $los::object);
									BottomPrint(%player, "<jc>Lock Achieved", 3);
									warningMessage(GameBase::getControlClient($los::object), %projectile);
								}
								else 
								{
									%projectile = Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							   		%projectile.owner = %this;	
							   	}
							   } else {
								Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							   }
							} else if(%weapName == volcano) {
								VolcanicEruption(%this, %player);
					
							} else Projectile::spawnProjectile(%weapName, %transform, %this, %playerVel);
							GameBase::playSound(%this, $WeaponSound[%weapName], 3);
			
							// Set up fire delay until next shot
							$VehicleCanFire[%this] = False;
							if($VehicleWeapFireDelay[%name, %weapName] < $WorseDelay[%this])
								$WorseDelay[%this] = $VehicleWeapFireDelay[%name, %weapName];
			
							// Decrement ammo count
							$VehicleWeaponAmmo[%this, %weapName]--;
										

							// Decrease Hard Point count, or count down to doing so, if neccessary.	
//echo("FT2 " @%firethis);
							if( %fireThis != -1 && ($BombBay[%name] == 0)) 
							{
								%notdone = $VModuleHP[$WeaponToNumber[%weapname]];
//echo("ND" @%notDone);
//echo("ONE: " @%i@", "@$VehicleMaxHardPoints[%name]@", "@%notdone);
								for(%i = %firethis; %i < %hp && %NotDone;%i++)
								{
//echo(%i@", "@$VehicleMaxHardPoints[%name]@", "@%notdone);
//echo($VehicleHPList[%this,%i]@", "@%weapname);
									if($VehicleHPList[%this,%i] == %weapName) {
										%NotDone--;
										$VehicleHPAmmoLeft[%this,%i]--;
									}
								}

							
								if( $VehicleHPAmmoLeft[%this,%firethis] < 1 )
								{	
									$VehicleHP[%this] = $VehicleHP[%this] - $VmoduleHP[$WeaponToNumber[%weapName]];
									
									%notdone = $VModuleHP[$WeaponToNumber[%weapname]];
									for(%i = %firethis; %i < %hp && %NotDone;%i++)
									{
										if($VehicleHPList[%this,%i] == %weapName) {
											%NotDone--;
											$VehicleHPList[%this,%i] = "";
											$HPToFire[%this,%i] = "";
										}
									}

									if(%weapName == TankSmoke)
									{
										Projectile::spawnProjectile(Tank, %transform, %this, %playerVel);
										CenterPrint(GameBase::getControlClient(%this), "Smoke Tank Jettisoned", 3);					
				
									} else if(%weapName == TankNerveGas)
									{
										Projectile::spawnProjectile(Tank, %transform, %this, %playerVel);
										CenterPrint(GameBase::getControlClient(%this), "Nerve Gas Tank Jettisoned", 3);
									}
								}
								if(%weapName == SideWinderRocket && %name == Apache){
									$VehicleSWHP[%this] = $VehicleSWHP[%this] - $VmoduleHP[$WeaponToNumber[%weapName]];
								}
							} else if(%fireThis == -1)
							{
								if($VehicleWeaponAmmo[%this, $VehicleWeapon[%name,0]] <= 0)	
									$HPToFire[%this,%fireThis] = "";

							}
							
							// Decrease number of weapons ($VehicleGuns[]) and switch weapons if out of ammo. Have to pack the list of weapons too.. grrr...
							if($VehicleWeaponAmmo[%this, %weapName] == 0 && %fireThis != -1){
								%weaponToRemove = -1;
								for(%i = $VehiclePrimaryGuns[%name]; %i <= $VehicleGuns[%this]; %i++)
								{
									if($VehicleOwnedWeapon[%this, %i] == %weapName)
										%weaponToRemove = %i;
				
								}
								if(%weaponToRemove == -1)
									echo("ERROR: Weapon to remove on the vehicle not found, but out of ammo!!");					
								else{
									for(%i = %weaponToRemove; %i < $VehicleGuns[%this]; %i++)
									{
										$VehicleOwnedWeapon[%this, %i] = $VehicleOwnedWeapon[%this, %i+1];
									}
									$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = Null;
								}
								$VehicleCurWeapon[%this] = $VehicleGuns[%this];
								$VehicleGuns[%this]--;
								//remoteNextWeapon(%this);
					
							}
						}

						%fireThis++;
					}
					%delay = $WorseDelay[%this];
					schedule("$VehicleCanFire["@%this@"] = True;", %delay, %this);
				//Decrease BombBay Count.
				if($VehicleCurWeapon[%this] >= $VehiclePrimaryGuns[%name] && $BombBay[%name] == 1)
				{
					$VehicleBB[%this] = $VehicleBB[%this] - $VmoduleBB[$WeaponToNumber[%weapName]];
					if(%name == Hercules)
						%this.openSeats++;
				

				}				

				%weapName = %oldWeap;
				%enerLevel = $VehicleWeaponAmmo[%this, %weapName] / $VehicleWeaponAmmoMax[%name, %weapName] * 100;
				GameBase::setEnergy(%this, %enerLevel);
 		

			} else {
				Bottomprint(%player, "<jc>" @ $weapPName[%this] @ " is out of ammo", 3);
			}
		}
	} 
}

function RemoteselectFireGroup(%client,%value)
{
//echo(%value);
	%player = Client::getOwnedObject(%client);
	if(%player.isgrappling)
	{
		Swing(%player, %value);
		return;
	}
	%this = %player.vehicle;
	%name =  GameBase::getDataName(%this);
//echo(%this@" "@ %name);
	if(%client.hflink != 2)
 	{
		Bottomprint(%client,"<jc>You must be set to selected firelinking.",5);
		return;	
	}
	if(%this == "" || %name == Linebacker || %name == Blackhawk || %name == Bomber || %name == Gunship || %name == Hercules 
		|| %name == Abrams || %name == TOWMissile || %name == Bradley || %name == MineLayer || %name == Humvee || %name == MLRS)
	{
		Bottomprint(%client,"<jc>You must be in a vehicle with hard points to select firelinking.",5);
		return;	
	}

	if(%value == "Clear")
	{
		for(%x = -1;%x < 11;%x++)
			$HPToFire[%this,%x] = "";	
		Bottomprint(%client,"<jc>Fire-linked selections cleared.",5);
			GameBase::setEnergy(%this, 0);
			$LastOn[%this] = "";

	} else if(%value != -1 && $VehicleHPList[%this,%value] == ""){
		Bottomprint(%client,"<jc>There is no weapon loaded at that hardpoint.",5);
		return;	
		
	} else if(%value == -1){
		if($VehicleWeaponAmmo[%this, $VehicleWeapon[%name,0]] <= 0)
		{
			$HPToFire[%this,%value] = "";
			Bottomprint(%client,"<jc>"@$WeaponDesc[$VehicleWeapon[%name,0]]@" out of ammo. Selection refused.",5);
		} else if($HPToFire[%this,%value]) {
			$HPToFire[%this,%value] = "";
			Bottomprint(%client,"<jc>"@$WeaponDesc[$VehicleWeapon[%name,0]]@" deselected.",5);
			GameBase::setEnergy(%this, 0);
			$LastOn[%this] = "";
		} else {
			$HPToFire[%this,%value] = true;
			Bottomprint(%client,"<jc>"@$WeaponDesc[$VehicleWeapon[%name,0]]@" selected to fire.",5);
			$LastOn[%this] = $VehicleWeapon[%name,0];
			%enerLevel = $VehicleWeaponAmmo[%this, $VehicleWeapon[%name,0]] / $VehicleWeaponAmmoMax[%name, $VehicleWeapon[%name,0]] * 100;
			GameBase::setEnergy(%this, %enerLevel);
		}
	} else {
		if($HPToFire[%this,%value]) {
			$HPToFire[%this,%value] = "";
			Bottomprint(%client,"<jc>"@$WeaponDesc[$VehicleHPList[%this,%value]]@" deselected.",5);
			GameBase::setEnergy(%this, 0);
			$LastOn[%this] = "";
		} else {
			$HPToFire[%this,%value] = true;
			Bottomprint(%client,"<jc>"@$WeaponDesc[$VehicleHPList[%this,%value]]@" selected to fire.",5);
			$LastOn[%this] = $VehicleHPList[%this,%value];
			%enerLevel = $VehicleWeaponAmmo[%this, $VehicleHPList[%this,%value]] / $VehicleWeaponAmmoMax[%name, $VehicleHPList[%this,%value]] * 100;
			GameBase::setEnergy(%this, %enerLevel);
		}
	}
}

// Should keep the vehicles relatively close to the ground...hopefully
function hugGround(%this) 
{
	GameBase::getLOSInfo(%this, 500, "-1.57 0 0");
	%posZ = getWord($los::position, 2) + 2.0;
	%curPos = GameBase::getPosition(%this);
	%posX = getWord(%curPos, 0);
	%posY = getWord(%curPos, 1);
	%curPos = ""@%posX@" "@%posY@" "@%posZ@"";	
	if(GameBase::testPosition(%this, %curPos)) GameBase::setPosition(%this, %curPos);
	schedule("hugGround("@%this@");", 2, %this);
}

// To keap planes "bouncing" themselves to death on the runway.
function landingGear(%vehicle, %clientId, %changeZRot, %changeYRot)
{
	%refHeight = "-1.575 0 0";
	%vehicleData = GameBase::getDataName(%vehicle);
	
	// Get the current speed of the vehicle from the velocity vectors
	%velocI = Item::getVelocity(%vehicle); 
	%xvelocI = getword(%velocI, 0);
	%yvelocI = getword(%velocI, 1);
	%zvelocI = getword(%velocI, 2);
	%speedI = sqrt(%xvelocI*%xvelocI + %yvelocI*%yvelocI + %zvelocI*%zvelocI);
	
	if($SFdrivingAPC[%clientId])  
	{
		
		if(GameBase::getLOSInfo(%vehicle,20,%refHeight))
		{
			%VgroundPos = $los::position;
			%VvehiclePos = GameBase::getPosition(%vehicle);
			%VvehicleZ = getword(%VvehiclePos, 2);
			%Vgroundz = getword(%VgroundPos, 2);
			%Vheight = %VvehicleZ - %VgroundZ;
		}
	
		if(%Vheight <= 2.51 && %speedI < %vehicleData.maxspeed *0.9 ) // if they are off the ground, or they are going more then half speed, remove landing gear
		{
			
			%refX1 = "-0.393 0 0";
			%refX2 = "-0.393 0 1.571";
			%refX3 = "-0.786 0 0";
			%refX4 = "-0.786 0 1.571";
	
			%refY2 = "-0.393 0 0.786";
			%refY1 = "-0.393 0 -0.786";
			%refY4 = "-0.786 0 0.786";
			%refY3 = "-0.786 0 -0.786";
			
			%refHeight = "-1.575 0 0";			

			//Temp set Rotations
			%OldRot = GameBase::getRotation(%vehicle);
			%NewXRot = getword(%OldRot, 0);
			%NewYRot = getword(%OldRot, 1);
			%changeInZ = %changeYRot - %NewYRot;
			%changeInZ = %changeInZ * 3;
			//if(($modVal % 5) == 0) 
			//	echo(%changeInZ);
			//$modVal++;
			%NewZRot = %changeZRot + %changeInZ;
			
			// Front Middle Position
			//----------------------
			if(GameBase::getLOSInfo(%vehicle,20,%refX1))
				%frontMiddlePos = $los::position;
			else
				if(GameBase::getLOSInfo(%vehicle,1000,%refX3))
					%frontMiddlePos = $los::position;
				else
					%frontMiddlePos = "0 0 0";
			
			// Rear Middle Position
			//-----------------------
			if(GameBase::getLOSInfo(%vehicle,20,%refX2))
				%rearMiddlePos = $los::position;
			else
				if(GameBase::getLOSInfo(%vehicle,1000,%refX4))
					%rearMiddlePos = $los::position;
				else
					%rearMiddlePos = "0 0 0";			

			// Left Middle Position
			//------------------------
			if(GameBase::getLOSInfo(%vehicle,20,%refY1))
				%leftMiddlePos = $los::position;
			else
				if(GameBase::getLOSInfo(%vehicle,1000,%refY3))
					%leftMiddlePos = $los::position;
				else
					%leftMiddlePos = "0 0 0";			

			// Right Middle Position
			//------------------------
			if(GameBase::getLOSInfo(%vehicle,20,%refY2))
				%rightMiddlePos = $los::position;
			else
				if(GameBase::getLOSInfo(%vehicle,1000,%refY4))
					%rightMiddlePos = $los::position;
				else
					%rightMiddlePos = "0 0 0";		

			//-------------------
			// X Rotation Stuff
			//-------------------
			// Rear Position
			%rMidX = getword(%rearMiddlePos, 0);
			%rMidY = getword(%rearMiddlePos, 1);
			%rMidZ = getword(%rearMiddlePos, 2);
			// Front Position
			%fMidX = getword(%frontMiddlePos , 0);
			%fMidY = getword(%frontMiddlePos , 1);
			%fMidZ = getword(%frontMiddlePos , 2);
			// X Distance
			%rpos = %rMidX@" "@%rMidY@" 0";
			%fpos = %fMidX@" "@%fMidY@" 0";
			// Find average of both rotations
			// Total Distance
			%totDist = Vector::getDistance(%rpos, %fpos);
			%zDistance = %fMidZ - %rMidZ;
			if(%totDist != 0)
		    	if( %zDistance != 0 )
				{
					%OppAdd = %zDistance/%totDist;
					%NewXRot = inverseTan(%OppAdd);
				}		

			//-------------------
			// Y Rotation Stuff
			//-------------------
			// Right Side Position
			%rsMidX = getword(%rightMiddlePos, 0);
			%rsMidY = getword(%rightMiddlePos, 1);
			%rsMidZ = getword(%rightMiddlePos, 2);
			// Left Side Position
			%lsMidX = getword(%leftMiddlePos , 0);
			%lsMidY = getword(%leftMiddlePos , 1);
			%lsMidZ = getword(%leftMiddlePos , 2);
			// Y Distance
			%rsPos = %rsMidX@" "@%rsMidY@" 0";
			%lsPos = %lsMidX@" "@%lsMidY@" 0";
			// Total Distance
			%totDist = Vector::getDistance(%rsPos, %lsPos);
			%zDistance = %lsMidZ - %rsMidZ;
			if(%totDist != 0)
				if( %zDistance != 0 )
				{
					%OppAdd = %zDistance/%totDist;
					%NewYRot = inverseTan(%OppAdd);
				}		

			//-------------------
			// Height Stuff
			//-------------------
			if(GameBase::getLOSInfo(%vehicle,20,%refHeight))
			{
				%groundPos = $los::position;
				%vehiclePos = GameBase::getPosition(%vehicle);
				%vehicleX = getword(%vehiclePos, 0);
				%vehicleY = getword(%vehiclePos, 1);
				%vehicleZ = getword(%vehiclePos, 2);
				%groundz = getword(%groundPos, 2);
				%height = %vehicleZ - %groundZ;
				if(%height <= 2.51)
				{
					%newpos = %vehicleX @ " " @ %vehicleY @ " " @ (%groundZ + 2.5);
					GameBase::setPosition(%vehicle,%newpos);
				}
			}	

			//-------------------
			// Set Rotation Stuff
			//-------------------
			// New Rotation
			%NewRot = %NewXRot@" "@%NewYRot@" "@%NewZRot;
			//GameBase::setRotation(%vehicle,%NewRot);
		
			schedule("landingGear("@%vehicle@","@%clientId@","@%NewZRot@","@%NewYRot@");",0.02, %vehicle);
		} else 	
		{
			schedule("landingGear("@%vehicle@","@%clientId@","@%changeZRot@","@%changeYRot@");",0.02, %vehicle);
			
		}

	} 
}

function Vehicle::onAdd(%this)
{
	%this.dead = false;
	%this.shieldStrength = 0.0;
	%name = GameBase::getDataName(%this);
	GameBase::setRechargeRate(%this, 0);
	GameBase::setMapName (%this, "Vehicle");
	if (%name == Abrams || %name == Bradley || %name == Humvee || %name == LineBacker || %name == MLRS || %name == MineLayer) {
		if($Server::FuzzyPhysics)
			schedule("hugGround("@%this@");", 2, %this);
	}
	
	
	$VehicleGuns[%this] = 0;
	$VehicleHP[%this] = 0;
	if(%name == Apache)
		$VehicleSWHP[%this] = 0; // Used only for apache.
	if($BombBay[%name] == 1)
		$VehicleBB[%this] = 0;
	
	if(%name == Hercules)
		%this.openSeats = 4;

	$VehicleCurWeapon[%this] = 0;
	for(%i = 0; %i < $VehiclePrimaryGuns[%name]; %i++)
	{
		%weapName = $VehicleWeapon[%name, %i];
		$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmoMax[%name, %weapName];
		$VehicleOwnedWeapon[%this, %i] = %weapName;
		$VehicleGuns[%this]++;
	
	}
	$VehicleCanFire[%this] = True;
	$VehicleCounterMeasuresCur[%this] = $VehicleCounterMeasures[%name];
	$Smoking[%this] = 0;
	$Flamming[%this] = 0;
	$Plummeting[%this] = 0;

}

function LoadModule(%this, %object)
{

}


//Adds whitespace to the end of a message. The total message length returned will be equal to %number

function AddWhiteSpaceBefore(%message,%number)
{
	%num = 0;
	for(%x = 0; %x < 100; %x++)
	{
		if(string::getsubstr(%message,%x,1) == "")
		{
			%num = %x;			
			break;
		}
	}
	for(%x = %number - %num ;%x > 0 ; %x--)
	{
		%message = " "@ %message;
	
	}
	return %message;	
}


//Adds whitespace to the end of a message. The total message length returned will be equal to %number

function AddWhiteSpaceAfter(%message,%number)
{
	%num = 0;
	for(%x = 0; %x < 100; %x++)
	{
		if(string::getsubstr(%message,%x,1) == "")
		{
			%num = %x;			
			break;
		}
	}
	for(%x = %number - %num ;%x > 0 ; %x--)
	{
		%message = %message @ " ";
	
	}
	return %message;	
}

function CheckHardpoints(%client)
{
	%vehicle = client::getcontrolobject(%client);
	%name = gamebase::Getdataname(%vehicle);
	echo(%Vehicle);
	echo(%name);
	%buff = "";
	for(%i = 0; %i < $VehiclePrimaryGuns[%name]; %i++)
		%buff = %buff @ $VehicleWeapon[%name,%i] @ " ";
	echo("Primary: " @%buff);
	%cur = 0;
	if($vehicleMaxHardPoints[%name]%2 == 0)
		echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur]@AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++],14),52));
	else
		echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur],52));

	echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++],30),60));
	echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++],46),70));
	echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++],30),60));
	echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++],30),60));
	echo(AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPList[%vehicle,%cur++],30),60));

	%cur = 0;
	if($vehicleMaxHardPoints[%name]%2 == 0)
		echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur]@AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++],14),52));
	else
		echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur],52));

	echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++],30),60));
	echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++],46),68));
	echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++],30),60));
	echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++],30),60));
	echo(AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++]@AddWhiteSpaceBefore($VehicleHPAmmoLeft[%vehicle,%cur++],30),60));
}

//====================================================================
//:::::::::::::::::::::Vehicle::OnCollision:::::::::::::::::::::::::::
//:::::::::::::::::::::REWRITTEN ON 3/22/02:::::::::::::::::::::::::::
//====================================================================


function Vehicle::onCollision (%this, %object)
{
//======================================Variables==========================================

	%client = Player::getClient(%object);
	%objType = getObjectType(%object);
	%armor = Player::getArmor(%object);
	%vname = GameBase::getDataName(%this);
	%module = $Vmodule[%this.module];
	%NextAvailableHP = 0;

//======================================BooleanChecks======================================
	
	%isPlayer = %objType == "Player";
	%isEngineer = %armor == "earmor" || %armor == "efemale" || %armor == "earmor2" || %armor == "efemale2" || %armor == "earmor3" || %armor == "efemale3";
	%isArtillery = %armor == "aarmor" || %armor == "afemale" || %armor == "aarmor2" || %armor == "afemale2" || %armor == "aarmor3" || %armor == "afemale3";
	%isPilot = %armor == "larmor" || %armor == "lfemale" || %armor == "larmor2" || %armor == "lfemale2" || %armor == "larmor3" || %armor == "lfemale3";
	%isOnePersonCraft = %vname == Fighter || %vname == Fighter2 || %vname == DiveBomber || %vname == Warthog || %vname == MoveWarthog || %vname == Bomber || %vname == Apache  || %vname == Scout;
	%isJet = %vname == Fighter || %vname == Fighter2 || %vname == DiveBomber || %vname == Bomber || %vname == Warthog || %vname == MoveWarthog || %vname == Gunship || %vname == Hercules;
	%isTank = %vName == Abrams || %vName == Bradley || %vname == Humvee || %vname == LineBacker || %vname == MLRS || %vname == MineLayer;
	%hasPilotWeapon = %vName == Warthog || %vName == MoveWarthog || %vName == Fighter || %vName == DiveBomber || %vName == Fighter2 || %vName == Apache || %vName == Hind || %vName == Bomber || %vName == Hercules;
	%canLoad = %isPlayer && %isEngineer;

//======================================TOWHandling========================================

	
	if(%vname == TOWMissile)
	{
		Vehicle::onDismount(%this, "0 0 0");
		return;
	}

//======================================ModuleLoading======================================

	if(%canLoad)
	{

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Fighter

		if (%vname == "Fighter")
		{
			if (Player::getItemCount(%object, SideWinderModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[1])))
			{
				Client::sendMessage(%client,0,"SideWinder Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,SideWinderModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[1];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SidewinderRocket){
						%weaponFound = %i;	
					}	

				}
				%NotDone = $VmoduleHP[1];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = SidewinderRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				}else{
					%weapName = SidewinderRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
				}
				
				return;
			}
			else if (Player::getItemCount(%object, MaverickModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[4])))
			{
				Client::sendMessage(%client,0,"Maverick Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,MaverickModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[4];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == MavMiss){
						%weaponFound = %i;	
					}			

				}
				%NotDone = $VmoduleHP[4];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = MavMiss;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = MavMiss;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, HARMModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[5])))
			{
				Client::sendMessage(%client,0,"HARM Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,HARMModule, 0);	
			
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[5];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == HARMRocket){
						%weaponFound = %i;	
					}
			
				}
				%NotDone = $VmoduleHP[5];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = HARMRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = HARMRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
				
				}
				
				return;
			}
			else if (Player::getItemCount(%object, Mk82Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[6])))
			{
				Client::sendMessage(%client,0,"Mk82 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk82Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[6];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BigBomb){
						%weaponFound = %i;	
					}	
	
				}
				%NotDone = $VmoduleHP[6];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BigBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BigBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, Mk84Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[7])))
			{
				Client::sendMessage(%client,0,"Mk84 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk84Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[7];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombShell){
						%weaponFound = %i;	
					}	

				}
				%NotDone = $VmoduleHP[7];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombShell;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, APClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[8])))
			{
				Client::sendMessage(%client,0,"APAM Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,APClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[8];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == APClusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[8];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = APClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = APClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, MineClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[9])))
			{
				Client::sendMessage(%client,0,"Gater Mine Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client, MineClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[9];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == MineClusterBomb){
						%weaponFound = %i;	
					}	
	
				}
				%NotDone = $VmoduleHP[9];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = MineClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = MineClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BombletClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[10])))
			{
				Client::sendMessage(%client,0,"Cluster Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BombletClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[10];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombletClusterBomb){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[10];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombletClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombletClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BunkerBusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[11])))
			{
				Client::sendMessage(%client,0,"Penetrator Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BunkerBusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[11];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BunkerBusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[11];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BunkerBusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BunkerBusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, TankSmokeModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[12])))
			{
				Client::sendMessage(%client,0,"Smoke Tank Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,TankSmokeModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[12];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TankSmoke){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[12];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TankSmoke;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 50;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 50;
				
				}else{
					%weapName = TankSmoke;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 50;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, TankNerveGasModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[13])))
			{
				Client::sendMessage(%client,0,"Nerve Gas Tank Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,TankNerveGasModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[13];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TankNerveGas){
						%weaponFound = %i;	
					}		
	
				}
				%NotDone = $VmoduleHP[13];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TankNerveGas;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 50;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 50;
				
				}else{
					%weapName = TankNerveGas;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 50;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, IncendiaryNapamModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[14])))
			{
				Client::sendMessage(%client,0,"Napalm Fire Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,IncendiaryNapamModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[14];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == NapalmBomb){
						%weaponFound = %i;	
					}

				}
				%NotDone = $VmoduleHP[14];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = NapalmBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = NapalmBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, EMCModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[16])))
			{
				
				
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == EMCContainer){
						%weaponFound = %i;	
					}		

				}
				if(%weaponFound != -1){
					Client::SendMessage(%client,0,"Erm, two EMCs are not gonna help you. So lets not bother.");
				}else{
					%NotDone = $VmoduleHP[16];
					for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
					{
						if($VehicleHPList[%this,%i] == "") {
							$VehicleHPList[%this,%i] = EMCContainer;
							%NotDone--;
							$VehicleHPAmmoLeft[%this,%i] = 1;
						}
					}
					Client::sendMessage(%client,0,"EMC Pod Loaded.");
					playSound(SoundDryFire,GameBase::getPosition(%this));
					Player::setItemCount(%client,EMCModule, 0);	
					$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[16];
					Player::setSensorSupression(%this,20);
					%weapName = EMCContainer;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					%this.EMC = true;
				}
				
				return;
			}
		}

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Fighter2

		else if (%vname == "Fighter2")
		{
			if (Player::getItemCount(%object, SideWinderModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[1])))
			{
				Client::sendMessage(%client,0,"SideWinder Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,SideWinderModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[1];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SidewinderRocket){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[1];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = SidewinderRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = SidewinderRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, PhoenixModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[2])))
			{
				Client::sendMessage(%client,0,"Phoenix Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,PhoenixModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[2];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == PhoenixRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[2];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = PhoenixRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 1;
				
				}else{
					%weapName = PhoenixRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, Mk82Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[6])))
			{
				Client::sendMessage(%client,0,"Mk82 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk82Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[6];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BigBomb){
						%weaponFound = %i;	
					}		
	
				}
				%NotDone = $VmoduleHP[6];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BigBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BigBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, Mk84Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[7])))
			{
				Client::sendMessage(%client,0,"Mk84 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk84Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[7];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombShell){
						%weaponFound = %i;	
					}	

				}
				%NotDone = $VmoduleHP[7];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombShell;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BombletClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[10])))
			{
				Client::sendMessage(%client,0,"Cluster Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BombletClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[10];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombletClusterBomb){
						%weaponFound = %i;	
					}	
	
				}
				%NotDone = $VmoduleHP[10];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombletClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombletClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, EMCModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[16])))
			{
				
				
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == EMCContainer){
						%weaponFound = %i;	
					}	
	
				}
				if(%weaponFound != -1){
					Client::SendMessage(%client,0,"Erm, two EMCs are not gonna help you. So lets not bother.");
				}else{
					%NotDone = $VmoduleHP[16];
					for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
					{
						if($VehicleHPList[%this,%i] == "") {
							$VehicleHPList[%this,%i] = EMCContainer;
							%NotDone--;
							$VehicleHPAmmoLeft[%this,%i] = 1;
						}
					}
					Client::sendMessage(%client,0,"EMC Pod Loaded.");
					playSound(SoundDryFire,GameBase::getPosition(%this));
					Player::setItemCount(%client,EMCModule, 0);	
					$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[16];
					Player::setSensorSupression(%this,20);
					%weapName = EMCContainer;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					%this.EMC = true;
				}
				
				return;
			}
		}	
	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Warthog		

		else if (%vname == "Warthog")
		{
			if (Player::getItemCount(%object, SideWinderModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[1])))
			{
				Client::sendMessage(%client,0,"SideWinder Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,SideWinderModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[1];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SidewinderRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[1];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = SidewinderRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = SidewinderRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, HellfireModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[3])))
			{
				Client::sendMessage(%client,0,"Hellfire Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,HellfireModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[3];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == ApacheRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[3];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = ApacheRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 4;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 4;
				
				}else{
					%weapName = ApacheRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 4;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, HydraModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[21])))
			{
				Client::sendMessage(%client,0,"Hydra Rockets Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,HydraModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[21];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == HydraRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[21];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = HydraRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 19;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 19;
				
				}else{
					%weapName = HydraRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 19;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, MaverickModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[4])))
			{
				Client::sendMessage(%client,0,"Maverick Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,MaverickModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[4];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == MavMiss){
						%weaponFound = %i;	
					}			

				}
				%NotDone = $VmoduleHP[4];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = MavMiss;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = MavMiss;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, Mk82Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[6])))
			{
				Client::sendMessage(%client,0,"Mk82 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk82Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[6];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BigBomb){
						%weaponFound = %i;	
					}		

				}	
				%NotDone = $VmoduleHP[6];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BigBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BigBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, Mk84Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[7])))
			{
				Client::sendMessage(%client,0,"Mk84 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk84Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[7];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombShell){
						%weaponFound = %i;	
					}			

				}
				%NotDone = $VmoduleHP[7];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombShell;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, APClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[8])))
			{
				Client::sendMessage(%client,0,"APAM Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,APClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[8];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == APClusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[8];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = APClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = APClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, MineClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[9])))
			{
				Client::sendMessage(%client,0,"Gater Mine Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client, MineClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[9];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == MineClusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[9];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = MineClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = MineClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BombletClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[10])))	
			{
				Client::sendMessage(%client,0,"Cluster Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BombletClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[10];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombletClusterBomb){
						%weaponFound = %i;	
					}			

				}
				%NotDone = $VmoduleHP[10];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombletClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombletClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BunkerBusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[11])))
			{
				Client::sendMessage(%client,0,"Penetrator Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BunkerBusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[11];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BunkerBusterBomb){
						%weaponFound = %i;	
					}

				}
				%NotDone = $VmoduleHP[11];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BunkerBusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BunkerBusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, TankSmokeModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[12])))
			{
				Client::sendMessage(%client,0,"Smoke Tank Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,TankSmokeModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[12];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TankSmoke){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[12];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TankSmoke;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 50;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 50;
				
				}else{
					%weapName = TankSmoke;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 50;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, TankNerveGasModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[13])))
			{
				Client::sendMessage(%client,0,"Nerve Gas Tank Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,TankNerveGasModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[13];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TankNerveGas){
						%weaponFound = %i;	
					}		
	
				}
				%NotDone = $VmoduleHP[13];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TankNerveGas;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 50;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 50;
				
				}else{
					%weapName = TankNerveGas;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 50;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, IncendiaryNapamModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[14])))
			{
				Client::sendMessage(%client,0,"Napalm Fire Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,IncendiaryNapamModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[14];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == NapalmBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[14];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = NapalmBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = NapalmBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, EMCModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[16])))
			{
				
				
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == EMCContainer){
						%weaponFound = %i;	
					}		
	
				}
				if(%weaponFound != -1){
					Client::SendMessage(%client,0,"Erm, two EMCs are not gonna help you. So lets not bother.");
				}else{
					%NotDone = $VmoduleHP[16];
					for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
					{
						if($VehicleHPList[%this,%i] == "") {
							$VehicleHPList[%this,%i] = EMCContainer;
							%NotDone--;
							$VehicleHPAmmoLeft[%this,%i] = 1;
						}
					}
					Client::sendMessage(%client,0,"EMC Pod Loaded.");
					playSound(SoundDryFire,GameBase::getPosition(%this));
					Player::setItemCount(%client,EMCModule, 0);	
					$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[16];
					Player::setSensorSupression(%this,20);
					%weapName = EMCContainer;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					%this.EMC = true;
				}
				
				return;
			}
		}
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Hind		

		else if (%vname == "Hind")
		{

			if (Player::getItemCount(%object, SideWinderModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[1])))
			{
				Client::sendMessage(%client,0,"SideWinder Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,SideWinderModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[1];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SidewinderRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[1];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = SidewinderRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = SidewinderRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, HellfireModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[3])))
			{
				Client::sendMessage(%client,0,"Hellfire Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,HellfireModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[3];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == ApacheRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[3];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = ApacheRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 4;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 4;
				
				}else{
					%weapName = ApacheRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 4;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, UPKGunPodModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[22])))
			{
				Client::sendMessage(%client,0,"UPK Gun Pod Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,UPKGunPodModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[22];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TwentyFivemmBullet){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[22];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TwentyFivemmBullet;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 250;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 250;
				
				}else{
					%weapName = TwentyFivemmBullet;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 250;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, GUVGunPodModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[23])))
			{
				Client::sendMessage(%client,0,"GUV Gun Pod Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,GUVGunPodModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[23];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SAWBullet){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[23];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = SAWBullet;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 750;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 750;
				
				}else{
					%weapName = SAWBullet;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 750;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, Mk82Module) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[6])))
			{
				Client::sendMessage(%client,0,"Mk82 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk82Module, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[6];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BigBomb){
						%weaponFound = %i;	
					}			

				}
				%NotDone = $VmoduleHP[6];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BigBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BigBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, APClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[8])))
			{
				Client::sendMessage(%client,0,"APAM Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,APClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[8];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == APClusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[8];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = APClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = APClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, MineClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[9])))
			{
				Client::sendMessage(%client,0,"Gater Mine Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client, MineClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[9];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == MineClusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[9];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = MineClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = MineClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BombletClusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[10])))
			{
				Client::sendMessage(%client,0,"Cluster Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BombletClusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[10];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombletClusterBomb){
						%weaponFound = %i;	
					}		

				}
				%NotDone = $VmoduleHP[10];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BombletClusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombletClusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, BunkerBusterModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[11])))
			{
				Client::sendMessage(%client,0,"Penetrator Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,BunkerBusterModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[11];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BunkerBusterBomb){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[11];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = BunkerBusterBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BunkerBusterBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, TankSmokeModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[12])))
			{
				Client::sendMessage(%client,0,"Smoke Tank Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,TankSmokeModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[12];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TankSmoke){
						%weaponFound = %i;	
					}	
	
				}
				%NotDone = $VmoduleHP[12];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TankSmoke;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 50;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 50;
				
				}else{
					%weapName = TankSmoke;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 50;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, TankNerveGasModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[13])))
			{
				Client::sendMessage(%client,0,"Nerve Gas Tank Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,TankNerveGasModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[13];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == TankNerveGas){
						%weaponFound = %i;	
					}		
	
				}
				%NotDone = $VmoduleHP[13];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = TankNerveGas;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 50;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 50;
				
				}else{
					%weapName = TankNerveGas;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 50;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, IncendiaryNapamModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[14])))
			{
				Client::sendMessage(%client,0,"Napalm Fire Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,IncendiaryNapamModule, 0);	
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[14];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == NapalmBomb){
						%weaponFound = %i;	
					}			

				}
				%NotDone = $VmoduleHP[14];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = NapalmBomb;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 1;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = NapalmBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, EMCModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[16])))
			{
				
				
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == EMCContainer){
						%weaponFound = %i;	
					}
	
				}
				if(%weaponFound != -1){
					Client::SendMessage(%client,0,"Erm, two EMCs are not gonna help you. So lets not bother.");
				}else{
					%NotDone = $VmoduleHP[16];
					for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
					{
						if($VehicleHPList[%this,%i] == "") {
							$VehicleHPList[%this,%i] = EMCContainer;
							%NotDone--;
							$VehicleHPAmmoLeft[%this,%i] = 1;
						}
					}
					Client::sendMessage(%client,0,"EMC Pod Loaded.");
					playSound(SoundDryFire,GameBase::getPosition(%this));
					Player::setItemCount(%client,EMCModule, 0);	
					$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[16];
					Player::setSensorSupression(%this,20);
					%weapName = EMCContainer;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					%this.EMC = true;
				}
				
				return;
			}
		}	
	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Apache				

		else if (%vname == "Apache")
		{
			//Only 2 slots for sidewinders on apache!
//			if (Player::getItemCount(%object, SideWinderModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[1])))
			if (Player::getItemCount(%object, SideWinderModule) && (2 >= ($VehicleSWHP[%this] + $VmoduleHP[1])))
			{
				Client::sendMessage(%client,0,"SideWinder Missile Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,SideWinderModule, 0);
				
				$VehicleSWHP[%this] = $VehicleSWHP[%this] + $VmoduleHP[1];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SidewinderRocket){
						%weaponFound = %i;	
					}
	
				}
				if($VehicleHPList[%this,4] == "") {
					$VehicleHPList[%this,4] = SidewinderRocket;
					$VehicleHPAmmoLeft[%this,4] = 1;
				} else {
					$VehicleHPList[%this,5] = SidewinderRocket;
					$VehicleHPAmmoLeft[%this,5] = 1;
				}

				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = SidewinderRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, HellfireModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[3])))
			{
				Client::sendMessage(%client,0,"Hellfire Rockets Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,HellfireModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[3];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == ApacheRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[3];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = ApacheRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 4;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 4;
				
				}else{
					%weapName = ApacheRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 4;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, HydraModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[21])))
			{
				Client::sendMessage(%client,0,"Hydra Rockets Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,HydraModule, 0);
				
				$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[21];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == HydraRocket){
						%weaponFound = %i;	
					}
	
				}
				%NotDone = $VmoduleHP[21];
				for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
				{
					if($VehicleHPList[%this,%i] == "") {
						$VehicleHPList[%this,%i] = HydraRocket;
						%NotDone--;
						$VehicleHPAmmoLeft[%this,%i] = 19;
					}
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName] = $VehicleWeaponAmmo[%this, %weapName] + 19;
				
				}else{
					%weapName = HydraRocket;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 19;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, EMCModule) && ($VehicleMaxHardPoints[%vname] >= ($VehicleHP[%this] + $VmoduleHP[16])))
			{
				
				
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == EMCContainer){
						%weaponFound = %i;	
					}
	
				}
				if(%weaponFound != -1){
					Client::SendMessage(%client,0,"Erm, two EMCs are not gonna help you. So lets not bother.");
				}else{
					%NotDone = $VmoduleHP[16];
					for(%i = 0; %i < $vehicleMaxHardPoints[%vname] && %NotDone;%i++)
					{
						if($VehicleHPList[%this,%i] == "") {
							$VehicleHPList[%this,%i] = EMCContainer;
							%NotDone--;
							$VehicleHPAmmoLeft[%this,%i] = 1;
						}
					}
					Client::sendMessage(%client,0,"EMC Pod Loaded.");
					playSound(SoundDryFire,GameBase::getPosition(%this));
					Player::setItemCount(%client,EMCModule, 0);	
					$VehicleHP[%this] = $VehicleHP[%this] + $VmoduleHP[16];
					Player::setSensorSupression(%this,20);
					%weapName = EMCContainer;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					$VehicleWeapToFire[%this,%weapname] = -1;
					%this.EMC = true;
				}
				
				return;
			}
		}	
	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Bomber

		else if (%vname == "Bomber")
		{
			if (Player::getItemCount(%object, Mk82Module) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[6])))
			{
				Client::sendMessage(%client,0,"Mk82 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk82Module, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[6];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BigBomb){
						%weaponFound = %i;	
					}	
	
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BigBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
				
				return;
			}		
			else if (Player::getItemCount(%object, Mk84Module) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[7])))
			{
				Client::sendMessage(%client,0,"Mk84 Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk84Module, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[7];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombShell){
						%weaponFound = %i;	
					}		

				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = BombShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
			
				return;
			}
			else if (Player::getItemCount(%object, Mk82PackageModule) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[17])))
			{
				Client::sendMessage(%client,0,"Mk82 Bombs Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk82PackageModule, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[17];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BigBomb){
						%weaponFound = %i;	
					}

				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 4;
				
				}else{
					%weapName = BigBomb;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 4;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, Mk84PackageModule) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[18])))
			{
				Client::sendMessage(%client,0,"Mk84 Bombs Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,Mk84PackageModule, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[18];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == BombShell){
						%weaponFound = %i;	
					}		

				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]= $VehicleWeaponAmmo[%this, %weapName] + 2;
				
				}else{
					%weapName = BombShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 2;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
				
				return;
			}
			else if (Player::getItemCount(%object, NuclearModule) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[15])))
			{
				Client::sendMessage(%client,0,"Hydrogen Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,NuclearModule, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[15];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == NukeShell){
						%weaponFound = %i;	
					}	
	
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = NukeShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
			
				return;
			}		
			
		}

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Loading Hercules

		else if (%vname == "Hercules")
		{
			if (Player::getItemCount(%object, DaisyCutterModule) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[19])) && %this.openSeats > 0)
			{
				Client::sendMessage(%client,0,"Daisy Cutter Bomb Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,DaisyCutterModule, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[19];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == DaisyShell){
						%weaponFound = %i;	
					}	
	
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = DaisyShell;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
				%this.openSeats--;
				return;
			}
			else if (Player::getItemCount(%object, SupplyCrateModule) && ($BombBayMax[%vname] >= ($VehicleBB[%this] + $VmoduleBB[20])) && %this.openSeats > 0)
			{
				Client::sendMessage(%client,0,"Supply Crate Loaded.");
				playSound(SoundDryFire,GameBase::getPosition(%this));
				Player::setItemCount(%client,SupplyCrateModule, 0);	
				
				$VehicleBB[%this] = $VehicleBB[%this] + $VmoduleBB[20];
				%weaponFound = -1;
				for(%i = 0; %i < $VehicleGuns[%this] && %weaponFound == -1; %i++)
				{
					if($VehicleOwnedWeapon[%this, %i] == SupplyDrop){
						%weaponFound = %i;	
					}	
	
				}
				if(%weaponFound != -1){
					%weapName = $VehicleOwnedWeapon[%this, %weaponFound];
					$VehicleWeaponAmmo[%this, %weapName]++;
				
				}else{
					%weapName = SupplyDrop;
					$VehicleOwnedWeapon[%this, $VehicleGuns[%this]] = %weapName;
					$VehicleWeaponAmmo[%this, %weapName] = 1;
					$VehicleGuns[%this] = $VehicleGuns[%this] + 1;
					
				}
				%this.openSeats--;
				return;
			}		
		}
	}

//======================================DamageCheck========================================

	if(GameBase::getDamageLevel(%this) > (GameBase::getDataName(%this)).maxDamage || %this.dead)
	{
		return;
	}
	
//======================================PlayerCheck========================================

	// if we're not a player or we already are in a vehicle.
	if(!%isPlayer || %object.vehicle != "") 
		return;
	
//======================================RemountDelayCheck==================================

	if(getSimTime() <= %object.newMountTime && %object.lastMount == %this)
		return;

//======================================FadingCheck========================================
	if(%this.fading != "")
		return;

//======================================AICheck============================================
		
//	if(Player::isAiControlled(%object))
//        	return;
               

//======================================OnePersonCraft=====================================
	if(%isOnePersonCraft)
	{
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Is Pilot?
		if(!%isPilot)
		{
			Client::sendMessage(%client,0,"You must be a pilot to control the vehicles.~wError_Message.wav");
			return;
		}
				
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Is Piloted?
		if(GameBase::getControlClient(%this) != -1)
		{
			Client::sendMessage(%client,0,"This Vehicle is already occupied.~wError_Message.wav");
			return;
		}	

		if(!Vehicle::canMount(%this, %object))
		{
			Client::sendMessage(%client,0,"This Vehicle is already occupied.~wError_Message.wav");
			return;
		}


		//*************************************************************** Yay! Give our client the boat!

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Remember the client's weapon
		%weapon = Player::getMountedItem(%object,$WeaponSlot);
		if(%weapon != -1) {
			%object.lastWeapon = %weapon;
			Player::unMountItem(%object,$WeaponSlot);
		}

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Set our client in control
		Player::setMountObject(%object, %this, 1);
		Client::setControlObject(%client, %this);
		%object.driver = 1;
        	%object.vehicle = %this;
		%this.clLastMount = %client;
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Tell the client that they're flying a vehicle, and to activate jets.
		remoteEval(%client,ActivateJets);
	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Play fun mounting sound!
		playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ EMC?
		if(%this.EMC == true)
			Player::setSensorSupression(%client,20);
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Donno what or why but... what will it hurt...
		$SFdrivingAPC[%client] = 1;


		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were a jet, give it landing gear
		if (%isJet) 
		{
			%tRot = GameBase::getRotation(%this);
			landingGear(%this, %client, getWord(%tRot, 2), getWord(%tRot, 1));
		}

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were a tank, and we got our REAL tank code on, stick it to the ground (If were a jet, we cant be a tank so why bother checking?)
		else if(%isTank && !$Server::FuzzyPhysics)
		{
			%tRot = GameBase::getRotation(%this);
			vehicleHover(%this, %client, getWord(%tRot, 2), getWord(%tRot, 1));
		}
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If our vehicle has a pilot weapon, hand it over.
		if(%hasPilotWeapon)
		{
			%weapName = $VehicleWeapon[%vName, $VehicleCurWeapon[%this]];
			%newEner = $VehicleWeaponAmmo[%this, %weapName] / $VehicleWeaponAmmoMax[%vName, %weapName] * 100;
			GameBase::setEnergy(%this, %newEner);
		}
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If we got here, just break out for safty reasons.
		return;
	}

//======================================NotAOnePersonCraft=================================

	else if(!%isOnePersonCraft)
	{
	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Is Pilot?
		if(%isPilot && GameBase::getControlClient(%this) == -1 && Vehicle::canMount(%this, %object))
		{
			//*************************************************************** Yay! Give our client the boat!

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Remember the client's weapon
			%weapon = Player::getMountedItem(%object,$WeaponSlot);
			if(%weapon != -1) {
				%object.lastWeapon = %weapon;
				Player::unMountItem(%object,$WeaponSlot);
			}		

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Set our client in control
			Player::setMountObject(%object, %this, 1);
			Client::setControlObject(%client, %this);
			%object.driver = 1;
       		 	%object.vehicle = %this;
			%this.clLastMount = %client;
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Tell the client that they're flying a vehicle, and to activate jets.
			remoteEval(%client,ActivateJets);
	
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Play fun mounting sound!
			playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ EMC?
			if(%this.EMC == true)
				Player::setSensorSupression(%client,20);
		
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Donno what or why but... what will it hurt...
			$SFdrivingAPC[%client] = 1;


			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were a jet, give it landing gear
			if (%isJet) 
			{
				%tRot = GameBase::getRotation(%this);
				landingGear(%this, %client, getWord(%tRot, 2), getWord(%tRot, 1));
			}

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were a tank, and we got our REAL tank code on, stick it to the ground (If were a jet, we cant be a tank so why bother checking?)
			else if(%isTank && !$Server::FuzzyPhysics)
			{
				%tRot = GameBase::getRotation(%this);
				vehicleHover(%this, %client, getWord(%tRot, 2), getWord(%tRot, 1));
			}
		
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If our vehicle has a pilot weapon, hand it over.
			if(%hasPilotWeapon)
			{
				%weapName = $VehicleWeapon[%vName, $VehicleCurWeapon[%this]];
				%newEner = $VehicleWeaponAmmo[%this, %weapName] / $VehicleWeaponAmmoMax[%vName, %weapName] * 100;
				GameBase::setEnergy(%this, %newEner);
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If we got here, just break out for safty reasons.
			return;
		}

		//*********************************************************************** If were here, we can't pilot it. Check to see if we can ride.

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If theres no driver, dont go in!
		if(GameBase::getControlClient(%this) == -1)
		{
			Client::sendMessage(Player::getClient(%object),0,"Vehicle must be piloted to enter!~wError_Message.wav");
			return;		
		
		}
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If the driver is an enemy, you dont go in!	
		if(GameBase::getTeam(GameBase::getControlClient(%this)) != gamebase::GetTeam(%object))
		{
			Client::sendMessage(Player::getClient(%object),0,"You can't enter a vehicle piloted by an enemy! They won't let you in!~wError_Message.wav");
			return;		
		
		}
		



		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Get a position to ride in.		
		%mountSlot = Vehicle::findEmptySeat(%this,%client, %isArtillery, %isEngineer);

		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If we have a position, put em in their position
		if(%mountSlot)
		{
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Take away their weapon while riding
			%weapon = Player::getMountedItem(%object,$WeaponSlot);

			if(%weapon != -1) {
				%object.lastWeapon = %weapon;
				Player::unMountItem(%object,$WeaponSlot);
			}		

			
			//*************************************************************** Assign proper weapons to the rider.

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in a blackhawk,
			if(%vname == Blackhawk)
			{
				Player::setItemCount(%client,MinigunAmmo,$VehicleAmmo[%this, Minigun]);
				Player::setItemCount(%client,Minigun,1);
				Player::useItem(%client,Minigun);
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in an abrams,
			else if(%vname == Abrams)
			{
				if (%mountSlot == 2) {
					Player::setItemCount(%client,AbramsAmmo,$VehicleAmmo[%this, AbramsGun]);
					Player::setItemCount(%client,AbramsGun,1);
					Player::useItem(%client,AbramsGun);
				} else if(%mountSlot == 3){
					Player::setItemCount(%client,MinigunAmmo,$VehicleAmmo[%this, Minigun]);
					Player::setItemCount(%client,Minigun,1);
					Player::useItem(%client,Minigun);
				} 
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in a gunship,
			else if(%vname == Gunship)
			{
				if (%mountSlot == 4) {
					Player::setItemCount(%client,AbramsAmmo,$VehicleAmmo[%this, AbramsGun]);
					Player::setItemCount(%client,AbramsGun,1);
					Player::useItem(%client,AbramsGun);
				} else if (%mountSlot == 5) {
					Player::setItemCount(%client,FortymmAmmo,$VehicleAmmo[%this, Fortymmgun]);
					Player::setItemCount(%client,FortymmGun,1);
					Player::useItem(%client,FortymmGun);
				} else if (%mountSlot == 2 || %mountSlot == 3){
					Player::setItemCount(%client,TwentyFivemmAmmo,$VehicleAmmo[%this, TwentyFivemmgun]);
					Player::setItemCount(%client,TwentyFivemmgun,1);
					Player::useItem(%client,TwentyFivemmgun);
				}
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in a humvee,
			else if(%vname == Humvee)
			{
				if (%mountSlot == 2) {
					Player::setItemCount(%client,TOWAmmo,$VehicleAmmo[%this, TOW]);
					Player::setItemCount(%client,TOW,1);
					Player::useItem(%client,TOW);
				} else if (%mountSlot == 3){
					Player::setItemCount(%client,AutoGrenAmmo,$VehicleAmmo[%this, AutoGrenLauncher]);
					Player::setItemCount(%client,AutoGrenLauncher,1);
					Player::useItem(%client,AutoGrenLauncher);
				}
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in a bradley,
			else if(%vname == Bradley)
			{
				if (%mountSlot == 2) {
					Player::setItemCount(%client,TOWAmmo,$VehicleAmmo[%this, TOW]);
					Player::setItemCount(%client,TOW,1);
					Player::useItem(%client,TOW);
				} else if (%mountSlot == 3){
					Player::setItemCount(%client,TwentyFivemmAmmo,$VehicleAmmo[%this, TwentyFivemmGun]);
					Player::setItemCount(%client,TwentyFivemmGun,1);
					Player::useItem(%client,TwentyFivemmGun);
				} else if (%mountSlot == 4){
					Player::setItemCount(%client,MinigunAmmo,$VehicleAmmo[%this, Minigun]);
					Player::setItemCount(%client,Minigun,1);
					Player::useItem(%client,Minigun);
				}
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in a linebacker,
			else if(%vname == LineBacker)
			{
				if (%mountSlot == 2) {
					Player::setItemCount(%client,StingerLauncherAmmo,$VehicleAmmo[%this, StingerLauncherGun]);
					Player::setItemCount(%client,StingerLauncherGun,1);
					Player::useItem(%client,StingerLauncherGun);
				} else if (%mountSlot == 3){
					Player::setItemCount(%client,TwentyFivemmAmmo,$VehicleAmmo[%this, TwentyFivemmGun]);
					Player::setItemCount(%client,TwentyFivemmGun,1);
					Player::useItem(%client,TwentyFivemmGun);
				} else if (%mountSlot == 4){
					Player::setItemCount(%client,MinigunAmmo,$VehicleAmmo[%this, Minigun]);
					Player::setItemCount(%client,Minigun,1);
					Player::useItem(%client,Minigun);
				}
			}
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If were in an mlrs,
			else if(%vname == MLRS)
			{
				if (%mountSlot == 2) {
					Player::setItemCount(%client,MLRSAmmo,$VehicleAmmo[%this, MLRSLauncher]);
					Player::setItemCount(%client,MLRSLauncher,1);
					Player::useItem(%client,MLRSLauncher);
				}
			}
			else if(%vname == Hercules)
				%this.openSeats--;
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ So the client knows where they are sitting...
			%object.vehicleSlot = %mountSlot;
	
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ So the client knows where they are sitting...
			%client.inVehicle = true;
			

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ So the client knows WHICH vehicle they are in...
			%object.vehicle = %this;

			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Put our client in the boat.
			Player::setMountObject(%object, %this, %mountSlot);
		
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Play fun sound!
			playSound (%vname.mountSound, GameBase::getPosition(%this));
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Remember which slot has who.
			$PassengerSlot[%this, %mountSlot] = %client;
			
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ To be on the safe side.	
			return;
		}
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ If we didn't find a mount slot, and arn't in pilot, and there is no pilot, then assume they want to pilot, and need the armor.	
		else if(!%isPilot && GameBase::getControlClient(%this) == -1)
			Client::sendMessage(Player::getClient(%object),0,"You must be a pilot to control the vehicles.~wError_Message.wav");
	}
}



//====================================================================
//:::::::::::::::::::::Vehicle::findEmptySeat:::::::::::::::::::::::::
//:::::::::::::::::::::MODIFIED ON 3/22/02::::::::::::::::::::::::::::
//====================================================================

function Vehicle::findEmptySeat(%this,%client, %isArtillery, %isEngineer)
{
	%dataName = GameBase::getDataName(%this);

	if(%dataName == Bradley || %dataName == Gunship)
		%numSlots = 4;
	else if(%dataName == Warthog || %dataName == MoveWarthog || %dataName == Bomber || %dataName == MineLayer)
		%numSlots = 0;
	else if(%dataName == LineBacker)
		%numSlots = 3;
	else if(%dataName == Hercules)
		%numSlots = %this.openSeats;
	else
		%numSlots = 2;
	
	%checkCount = 0;
	%count = 0;
	%guard = 0;
	for(%i=0;%i<%numSlots;%i++){
		%guard = %i;
		%cansit = true;
		if(!%isArtillery)
		{
			if(%dataName == Abrams || %dataName == Gunship)
			{
				%cansit = false;
			}
			else if(%dataName == Bradley || %dataName == LineBacker)
			{
				if(%guard == 0 || %guard == 1)
					%cansit = false;
			}
			else if(%dataName == Humvee)
			{
				if(%guard == 0)
					%cansit = false;	
			}
			else if(%dataName == MLRS)
			{
				if(%guard == 0)
					%cansit = false;
				else if(%guard == 1 && !%isEngineer)
					%cansit = false;
			}
		}
		if(%this.Seat[%i] == "")
		{
			%checkCount++;
			if(%canSit)
			{
				%slotPos[%count] = Vehicle::getMountPoint(%this,%i+2);
				%slotVal[%count] = %i+2;
				%lastEmpty = %i+2;
				%count++;


			}
		}	
	}
	if(%count == 1) {
		%this.Seat[%lastEmpty-2] = %client;
		return %lastEmpty;
	}
	else if (%count > 1)	{
		%freeSlot = %slotVal[getClosestPosition(%count,GameBase::getPosition(%client),%slotPos[0],%slotPos[1],%slotPos[2],%slotPos[3])];
		%this.Seat[%freeSlot-2] = %client;
		return %freeSlot;
	}
	else
	{
		if(%checkCount != %count)
			Client::sendMessage(%client,0,"Cannot ride in that armor.~wError_Message.wav");	
		return "False";
	}
}

function getClosestPosition(%num,%playerPos,%slotPos0,%slotPos1,%slotPos2,%slotPos3)
{
	%playerX = getWord(%playerPos,0);
	%playerY = getWord(%playerPos,1);
	for(%i = 0 ;%i<%num;%i++) {
		%x = (getWord(%slotPos[%i],0)) - %playerX;
		%y = (getWord(%slotPos[%i],1)) - %playerY;
		if(%x < 0)
			%x *= -1;
		if(%y < 0)
			%y *= -1;
		%newDistance = sqrt((%x*%x)+(%y*%y));
		if(%newDistance < %distance || %distance == "") {
	  		%distance = %newDistance;			
			%closePos = %i;	
		}
	}		
	return %closePos;
}

function Vehicle::passengerJump(%this,%passenger,%mom)
{
	%armor = Player::getArmor(%passenger);
	if(GameBase::getDataName(%this) == Hercules && (%armor == "larmor" || %armor == "lfemale" || %armor == "sarmor" || %armor == "sfemale" || %armor == "carmor" || %armor == "cfemale" || %armor == "parmor" || %armor == "pfemale" || %armor == "larmor2" || %armor == "lfemale2" || %armor == "sarmor2" || %armor == "sfemale2" || %armor == "carmor2" || %armor == "cfemale2" || %armor == "parmor2" || %armor == "pfemale2" || %armor == "larmor3" || %armor == "lfemale3" || %armor == "sarmor3" || %armor == "sfemale3" || %armor == "carmor3" || %armor == "cfemale3" || %armor == "parmor3" || %armor == "pfemale3" || %armor == "aarmor" || %armor == "afemale" || %armor == "aarmor2" || %armor == "afemale2" || %armor == "aarmor3" || %armor == "afemale3")) {
		%height = 5;
		%velocity = 100;
		%zVec = 100;
	}
	else if(GameBase::getDataName(%this) == Hercules && (%armor == "marmor" || %armor == "mfemale" || %armor == "iarmor" || %armor == "ifemale"  || %armor == "garmor" || %armor == "gfemale" || %armor == "earmor" || %armor == "efemale" || %armor == "marmor2" || %armor == "mfemale2" || %armor == "iarmor2" || %armor == "ifemale2"  || %armor == "garmor2" || %armor == "gfemale2" || %armor == "earmor2" || %armor == "efemale2" || %armor == "marmor3" || %armor == "mfemale3" || %armor == "iarmor3" || %armor == "ifemale3"  || %armor == "garmor3" || %armor == "gfemale3" || %armor == "earmor3" || %armor == "efemale3")) {
		%height = 5;
		%velocity = 140;
		%zVec = 110;
	}
	else if(GameBase::getDataName(%this) == Hercules && (%armor == "harmor" || %armor == "aarmor")) {
		%height = 5;
		%velocity = 190;
		%zVec = 113;
	}
	else if((%armor == "larmor" || %armor == "lfemale" || %armor == "sarmor" || %armor == "sfemale" || %armor == "carmor" || %armor == "cfemale" || %armor == "parmor" || %armor == "pfemale" || %armor == "larmor2" || %armor == "lfemale2" || %armor == "sarmor2" || %armor == "sfemale2" || %armor == "carmor2" || %armor == "cfemale2" || %armor == "parmor2" || %armor == "pfemale2" || %armor == "larmor3" || %armor == "lfemale3" || %armor == "sarmor3" || %armor == "sfemale3" || %armor == "carmor3" || %armor == "cfemale3" || %armor == "parmor3" || %armor == "pfemale3"|| %armor == "aarmor" || %armor == "afemale" || %armor == "aarmor2" || %armor == "afemale2" || %armor == "aarmor3" || %armor == "afemale3")) {
		%height = 5;
		%velocity = 70;
		%zVec = 70;
	}
	else if((%armor == "marmor" || %armor == "mfemale" || %armor == "iarmor" || %armor == "ifemale"  || %armor == "garmor" || %armor == "gfemale" || %armor == "earmor" || %armor == "efemale" || %armor == "marmor2" || %armor == "mfemale2" || %armor == "iarmor2" || %armor == "ifemale2"  || %armor == "garmor2" || %armor == "gfemale2" || %armor == "earmor2" || %armor == "efemale2" || %armor == "marmor3" || %armor == "mfemale3" || %armor == "iarmor3" || %armor == "ifemale3"  || %armor == "garmor3" || %armor == "gfemale3" || %armor == "earmor3" || %armor == "efemale3")) {
		%height = 5;
		%velocity = 100;
		%zVec = 100;
	}
	else if((%armor == "harmor" || %armor == "aarmor")) {
		%height = 5;
		%velocity = 140;
		%zVec = 110;
	}

	%pos = GameBase::getPosition(%passenger);
	%posX = getWord(%pos,0);
	%posY	= getWord(%pos,1);
	%posZ	= getWord(%pos,2);
	%off = vector::getrotation(vector::sub(%pos, gamebase::getposition(%this)));

	if(GameBase::testPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height))) {	
		%client = Player::getClient(%passenger);
		%passenger.nolanddam=true;
                schedule(%passenger@".nolanddam=false;",2);
		//DELTAFORCE
		if(%mom=="Grapple")
		{
			if(GameBase::getDataName(%this) == BlackHawk)
				if(vector::getdistance("0 0 0", getword(item::getvelocity(%this), 0)@" "@getword(item::getvelocity(%this), 1)@" 0")<=2)	
					if(GameBase::testPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ - %height))&&!gamebase::getlosinfo(%this, 3, "-1.5707 0 0")) 
						%grappling=1;
					else
						Client::sendMessage(Player::getClient(%passenger),0,"Can not grapple - Vehicle too close to the ground.~wError_Message.wav");
				else
					Client::sendMessage(Player::getClient(%passenger),0,"Can not grapple - Vehicle moveing to fast.~wError_Message.wav");
			else
				Client::sendMessage(Player::getClient(%passenger),0,"Can not grapple - Vehicle does not allow it.~wError_Message.wav");
			if(!%grappling)
				return;
		}
		if(GameBase::getDataName(%this) == Humvee) {
			if(%passenger.vehicleSlot == 2) {
				$VehicleAmmo[%this, TOW] = Player::getItemCount(%client, TOWAmmo);
			} else if(%passenger.vehicleSlot == 3) {
				$VehicleAmmo[%this, AutoGrenLauncher] = Player::getItemCount(%client, AutoGrenAmmo);
			}
		} else if(GameBase::getDataName(%this) == Abrams) {
			if(%passenger.vehicleSlot == 2) {
				$VehicleAmmo[%this, AbramsGun] = Player::getItemCount(%client, AbramsAmmo);
			} else if(%passenger.vehicleSlot == 3) {
				$VehicleAmmo[%this, Minigun] = Player::getItemCount(%client, MinigunAmmo);
			}
		} else if(GameBase::getDataName(%this) == Gunship) {
			if(%passenger.vehicleSlot == 2 || %passenger.vehicleSlot == 3) {
				$VehicleAmmo[%this, TwentyFivemmgun] = Player::getItemCount(%client, TwentyFivemmAmmo);
			} else if(%passenger.vehicleSlot == 4) {
				$VehicleAmmo[%this, AbramsGun] = Player::getItemCount(%client, AbramsAmmo);
			} else if(%passenger.vehicleSlot == 5) {
				$VehicleAmmo[%this, Fortymmgun] = Player::getItemCount(%client, FortymmAmmo);
			}
		} else if(GameBase::getDataName(%this) == BlackHawk) {
			if(%passenger.vehicleSlot == 2 || %passenger.vehicleSlot == 3)
				$VehicleAmmo[%this, Minigun] = Player::getItemCount(%client, MinigunAmmo);
		} else if(GameBase::getDataName(%this) == Bradley) {
			if(%passenger.vehicleSlot == 3) {
				$VehicleAmmo[%this, TwentyFivemmgun] = Player::getItemCount(%client, TwentyFivemmAmmo);
			} else if(%passenger.vehicleSlot == 2) {
				$VehicleAmmo[%this, TOW] = Player::getItemCount(%client, TOWAmmo);
			} else if(%passenger.vehicleSlot == 4) {
				$VehicleAmmo[%this, Minigun] = Player::getItemCount(%client, MinigunAmmo);
			}
		
		} else if(GameBase::getDataName(%this) == LineBacker) {
			if(%passenger.vehicleSlot == 3) {
				$VehicleAmmo[%this, TwentyFivemmgun] = Player::getItemCount(%client, TwentyFivemmAmmo);
			} else if(%passenger.vehicleSlot == 2) {
				$VehicleAmmo[%this, StingerLauncherGun] = Player::getItemCount(%client, StingerLauncherAmmo);
			} else if(%passenger.vehicleSlot == 4) {
				$VehicleAmmo[%this, Minigun] = Player::getItemCount(%client, MinigunAmmo);
			}
		
		} else if(GameBase::getDataName(%this) == MLRS) {
			if(%passenger.vehicleSlot == 2) {
				$VehicleAmmo[%this, MLRSLauncher] = Player::getItemCount(%client, MLRSAmmo);
			}
		} else if (GameBase::getDataName(%this) == Hercules)
			%this.openSeats++;
	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Tell the client that they aren't flying a vehicle, and to deactivate jets.
		remoteEval(%client,DeactivateJets);
		$PassengerSlot[%this, %passenger.vehicleSlot] = 0;
		// END DELTAFORCE
		%this.Seat[%passenger.vehicleSlot-2] = "";
		%passenger.vehicleSlot = "";
	 	%passenger.vehicle= "";
		%client.inVehicle = false;
		Player::setMountObject(%passenger, -1, 0);
		%rotZ = getWord(GameBase::getRotation(%passenger),2);
		GameBase::setRotation(%passenger, "0 0 " @ %rotZ);
		GameBase::setPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height));
		%jumpDir = Vector::getFromRot(GameBase::getRotation(%passenger),%velocity,%zVec);
		Player::applyImpulse(%passenger,%jumpDir);
		schedule("Player::applyimpulse("@%passenger@",\"0 0 50\");",1.8);
		if(%passenger.lastWeapon != "") {
				Player::useItem(%passenger,%passenger.lastWeapon);		 	
				%passenger.lastWeapon = "";
      		}
			
	}
	else
		Client::sendMessage(Player::getClient(%passenger),0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
	
	// DELTA FORCE
	Player::setItemCount(%passenger,Minigun,0);
	Player::setItemCount(%passenger,MinigunAmmo,0);
	Player::setItemCount(%passenger,TwentyFivemmgun,0);
	Player::setItemCount(%passenger,TwentyFivemmAmmo,0);
	Player::setItemCount(%passenger,Fortymmgun,0);
	Player::setItemCount(%passenger,FortymmAmmo,0);
	Player::setItemCount(%passenger,AbramsGun,0);
	Player::setItemCount(%passenger,AbramsAmmo,0);
	Player::setItemCount(%passenger,TOW,0);
	Player::setItemCount(%passenger,TOWAmmo,0);
	Player::setItemCount(%passenger,AutoGrenLauncher,0);
	Player::setItemCount(%passenger,AutoGrenAmmo,0);
	Player::setItemCount(%passenger,MLRSLauncher,0);
	Player::setItemCount(%passenger,MLRSAmmo,0);
	Player::setItemCount(%passenger,StingerLauncherGun,0);
	Player::setItemCount(%passenger,StingerLauncherAmmo,0);
	Player::useItem(%passenger, %passenger.lastWeapon);
	if(%grappling)
		StartGrappleFromChopper(%passenger, %this, %off);
	// END DELTA FORCE
}

function Vehicle::jump(%this,%mom)
{
   if(GameBase::getDataName(%this) == TOWMissile) 
   {
	%cl = GameBase::getControlClient(%this);
	//remoteEval(%cl, BP, "<jc><f0>TOW Missile Remotely Detonated", 4);
	bottomprint(%cl, "<jc><f0>TOW Missile Remotely Detonated", 4);
   }
   Vehicle::dismount(%this,%mom);
}

function Vehicle::dismount(%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   if(GameBase::getDataName(%this) == TOWMissile) {
	if(%cl != -1) Client::setControlObject(%cl, Client::getOwnedObject(%cl));
	GameBase::setDamageLevel(%this, 0.1);
	return;
   }
   if(%cl != -1)
   {
      %pl = Client::getOwnedObject(%cl);
      if(getObjectType(%pl) == "Player")
      {
	   // dismount the player	  
		if(GameBase::testPosition(%pl, Vehicle::getMountPoint(%this,0))) 
		{
			$SFdrivingAPC[%cl] = 0;
			%pl.lastMount = %this;
			%pl.newMountTime = getSimTime() + 3.0;
			//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Tell the client that they aren't flying a vehicle, and to deactivate jets.
			remoteEval(%cl,DeactivateJets);
		
			Player::setMountObject(%pl, %this, 0);
        		Player::setMountObject(%pl, -1, 0);
			%rot = GameBase::getRotation(%this);
			%rotZ = getWord(%rot,2);
			GameBase::setRotation(%pl, "0 0 " @ %rotZ);
			Player::applyImpulse(%pl,%mom);
			schedule("Player::applyimpulse("@%pl@",\"0 0 50\");",0.8);
        		Client::setControlObject(%cl, %pl);
			//if(GameBase::getDataName(%this) == Warthog) {
			//	%this.minSpeed = 0;
			//}
			playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
			if(%this.EMC == true)
				Player::setSensorSupression(%cl,0);
			if(%pl.lastWeapon != "") {
				Player::useItem(%pl,%pl.lastWeapon);		 	
				%pl.lastWeapon = "";
      			}
			%pl.driver = "";
			%pl.vehicle = "";
			// DELTAFORCE
			//if(GameBase::getDataName(%this) == MoveWarthog) {
			//	%pos = GameBase::getPosition(%this);
			//	%rot = GameBase::getRotation(%this);
			//	%dam = GameBase::getDamageLevel(%this);
			//	%hTeam = GameBase::getTeam(%this);
			//	for(%i = 0; %i < $VehiclePrimaryGuns[MoveWarthog]; %i++)
			//	{
			//		%weapName = $VehicleWeapon[MoveWarthog, %i];
			//		$ammoTemp[%i] = $VehicleWeaponAmmo[%this, %weapName];
			//	}
			//	%zPos = getWord(%pos, 2);
			//	%zPos -= 1000;
			//	GameBase::setPosition(%this, getWord(%pos, 0) @ " " @ getWord(%pos, 1) @ " " @ %zPos);
			//	schedule("deleteObject("@%this@");", 0.05);
			//	%hog = newObject("","Flier","Warthog", true);
			//	addToSet("MissionCleanup", %hog);
			//	GameBase::setPosition(%hog, %pos);
			//	GameBase::setRotation(%hog, %rot);
			//	GameBase::setDamageLevel(%hog, %dam);
			//	GameBase::setTeam(%hog, %hTeam);
			//	for(%i = 0; %i < $VehiclePrimaryGuns[Warthog]; %i++)
			//	{
			//		%weapName = $VehicleWeapon[Warthog, %i];
			//		$VehicleWeaponAmmo[%hog, %weapName] = $ammoTemp[%i];
			//		$ammoTemp[%i] = 0;
			//	}
			//}
			// END DELTAFORCE
			Player::setItemCount(%pl,Minigun,0);
			Player::setItemCount(%pl,MinigunAmmo,0);
			Player::setItemCount(%pl,TwentyFivemmgun,0);
			Player::setItemCount(%pl,TwentyFivemmAmmo,0);
			Player::setItemCount(%pl,Fortymmgun,0);
			Player::setItemCount(%pl,FortymmAmmo,0);
			Player::setItemCount(%pl,AbramsGun,0);
			Player::setItemCount(%pl,AbramsAmmo,0);
			Player::setItemCount(%pl,TOW,0);
			Player::setItemCount(%pl,TOWAmmo,0);
			Player::setItemCount(%pl,AutoGrenLauncher,0);
			Player::setItemCount(%pl,AutoGrenAmmo,0);
			Player::setItemCount(%pl,MLRSLauncher,0);
			Player::setItemCount(%pl,MLRSAmmo,0);
			Player::setItemCount(%pl,StingerLauncherGun,0);
			Player::setItemCount(%pl,StingerLauncherAmmo,0);
			
		} else Client::sendMessage(%cl,0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
	}	
   }
}

function Vehicle::onDestroyed (%this,%mom)
{
	%this.dead = true;
//	if($testcheats || $servercheats)
	$TeamItemCount[GameBase::getTeam(%this) @ $VehicleToItem[GameBase::getDataName(%this)]]--;

 	%cl = GameBase::getControlClient(%this);
	%pl = Client::getOwnedObject(%cl);
	if(GameBase::getDataName(%this) == TOWMissile) {
		Client::setControlObject(%cl, %pl);
		calcRadiusDamage(%this, $MissileDamageType, 100, 0.05, 25, 13, 2, 0.55, 0.1, 225, 100);
		return;
	}
	if(%this.EMC == true)
		Player::setSensorSupression(%pl,0);
	%this.EMC = false;
	if(%pl != -1) {
	   Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Tell the client that they aren't flying a vehicle, and to deactivate jets.
	remoteEval(%cl,DeactivateJets);
	distributePoints(%this, %this.clLastMount, %this.LastDamageObject);
	$SFdrivingAPC[%cl] = 0;
		if(%pl.lastWeapon != "") {
			Player::useItem(%pl,%pl.lastWeapon);		 	
			%pl.lastWeapon = "";
		}
		%pl.driver = "";
	   %pl.vehicle= "";
	}
	for(%i = 0 ; %i < 4 ; %i++)
		if(%this.Seat[%i] != "") {
			%pl = Client::getOwnedObject(%this.Seat[%i]);
		   Player::setMountObject(%pl, -1, 0);
	  	 	Client::setControlObject(%this.Seat[%i], %pl);
			%pl.vehicleSlot = "";
			%pl.inVehicle = false;
		   %pl.vehicle= "";
			// DELTA FORCE
			Player::setItemCount(%pl,Minigun,0);
			Player::setItemCount(%pl,MinigunAmmo,0);
			Player::setItemCount(%pl,TwentyFivemmgun,0);
			Player::setItemCount(%pl,TwentyFivemmAmmo,0);
			Player::setItemCount(%pl,Fortymmgun,0);
			Player::setItemCount(%pl,FortymmAmmo,0);
			Player::setItemCount(%pl,AbramsGun,0);
			Player::setItemCount(%pl,AbramsAmmo,0);
			Player::setItemCount(%pl,TOW,0);
			Player::setItemCount(%pl,TOWAmmo,0);
			Player::setItemCount(%pl,AutoGrenLauncher,0);
			Player::setItemCount(%pl,AutoGrenAmmo,0);
			Player::setItemCount(%pl,MLRSLauncher,0);
			Player::setItemCount(%pl,MLRSAmmo,0);
			Player::setItemCount(%pl,StingerLauncherGun,0);
			Player::setItemCount(%pl,StingerLauncherAmmo,0);
			Player::useItem(%pl, %pl.lastWeapon);
		
			// END DELTA FORCE			
		}
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.55, 
		0.1, 225, 100); 
	$Smoking[%this] = 0;
	$Flamming[%this] = 0;
	$Plummeting[%this] = 0;
	
	if($Tournymode) {
		%vname = GameBase::getDataName(%this);
		%isJet = %vname == Fighter || %vname == Fighter2 || %vname == DiveBomber || %vname == Bomber || %vname == Warthog || %vname == MoveWarthog || %vname == Gunship || %vname == Hercules;
		%isTank = %vName == Abrams || %vName == Bradley || %vname == Humvee || %vname == LineBacker || %vname == MLRS || %vname == MineLayer;
		if( %isjet )
			$TeamOwnedJet[%team]--;
		else if( %istank )
			$TeamOwnedTank[%team]--;
		else 
			$TeamOwnedChopper[%team]--;
		Export( "TeamOwned*", "config\\VehicleLeft.cs", False );
	
			

	}
		
}

function distributePoints(%this, %pilot, %killer)
{
	if(%pilot == -1 || !%pilot || %killer == -1 || !%killer || %pilot == %killer)
		return;
	if($NoVehicleTK && GameBase::getTeam(%pilot) == GameBase::getTeam(%killer))
		return;
	%vehicleType = GameBase::getDataName(%this);
	if(!String::ICompare(Client::getGender(%pilot), "Male"))
 	{
 		%pilotGender = "his";
	}	
	else
	{
		%pilotGender = "her";
	}
	if(!String::ICompare(Client::getGender(%killer), "Male"))
 	{
 		%killerGender = "his";
	}	
	else
	{
		%killerGender = "her";
	}
	%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
	%victimName = Client::getName(%pilot);
	%obitMsg = sprintf($crashMsg[%vehicleType, %ridx], Client::getName(%killer),
		%victimName, %killerGender, %pilotGender);
        messageAll(0, %obitMsg, $DeathMessageMask);
	%pilot.score--;
	%killer.score++;
	Game::refreshClientScore(%killer);
        Game::refreshClientScore(%pilot);
	
}


function getTargetDown(%player)
{
	%cl = GameBase::getControlClient(%player);
	%pl = Client::getOwnedObject(%cl);
	if(GameBase::getLOSInfo(%pl,2.5,"-1.570796327 0 0")){
	echo($los::object);
	echo(GameBase::getDataName($los::object));
	echo(GameBase::getDataName($los::object) != "False");
	}

}


function Vehicle::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
	%type = Veteran::getRealDamageType(%type);
	%value *= $damageScale[GameBase::getDataName(%this), %type];
	%vname = GameBase::getDataName(%this);
	%isJet = %vname == Fighter || %vname == Fighter2 || %vname == DiveBomber || %vname == Bomber || %vname == Warthog || %vname == MoveWarthog || %vname == Gunship || %vname == Hercules;
	
//echo("Type: " @ %type);
	if(%isJet && %type == $ImpactDamageType)
	{
//echo("Sure");

//		%set = newObject("set",SimSet); // make new box for testing.

//		if(containerBoxFillSet(%set,$SimInteriorObjectType,gamebase::getposition(%this),0,0,2,0))
//		{
		if(GameBase::getLOSInfo(%this,3.0,"-1.570796327 0 0")){
//echo($los::target);

		if(GameBase::getDataName($los::object) == "False"){

//echo("ya");

			%rotX = getword(GameBase::getRotation(%vehicle),0);
//echo(%rotX);
			if(%rotX < 0.2 && %rotX > -0.02)
			{
//echo("uhhuh");
				%velocI = Item::getVelocity(%this); 
				%xvelocI = getword(%velocI, 0);
				%yvelocI = getword(%velocI, 1);
				%zvelocI = getword(%velocI, 2);
				%speedI = sqrt(%xvelocI*%xvelocI + %yvelocI*%yvelocI + %zvelocI*%zvelocI);
//echo(%speedI @ " "  @ %vname.maxspeed * 0.75);		
				if( %speedI < %vname.maxspeed *0.75){
//echo("No damage");
					return;
				}
			}
		}
		}
	}
		
	StaticShape::onDamage(%this,%type,%value,%pos,%vec,%mom,%object);
	
}

function Vehicle::getHeatFactor(%this)
{
	// Not getting called right now because turrets don't track
	// vehicles.  A hack has been placed in Player::getHeatFactor.
   return 1.0;
}

//-Height to float off ground
$GroundFloat = 2.1;
//-Our gravity constant for how fast out vehicles fall.
$GravConst = -21;
//-How often to have this loop.
$TimeSkip = 0.01;
//-The buffer for how much our rot can be off from the terrain's.
// Should smooth the ride out a little.
$RotOffset = 0.01;

function VehicleHover(%veh,%client)
{
	//Make sure client exists and is the guy controling the car.
	if(%client < 1 || %client == "")
		%client = GameBase::getControlClient(%veh);

	//If we got a driver, arn't being carried and have something under us.
	if(GameBase::getControlClient(%veh) == %client && GameBase::getLOSInfo(%veh,5000,"-1.570796327 0 0")) {
		//Get the position and rotation of the ground
		%groundRot = $los::normal;
		%groundPos = $los::position;

		//get the position and rotation of the vehicle.
		%rot0 = GameBase::getRotation(%veh);
		%pos0 = GameBase::getPosition(%veh);

		//Take care of ground. If were higher, then fall and such.
		%NewPos = getWord(%pos0,0)@" "@getWord(%pos0,1)@" "@getWord(%groundPos,2)+$GroundFloat;
		if(%ZDist > $GroundFloat + 0.9) {
			%displacement = %veh.lastVel*$TimeSkip + 0.5*$GravConst*($TimeSkip*$TimeSkip);
			%veh.lastVel = sqrt( %veh.lastVel*%veh.lastVel + 2*$GravConst*%displacement);
			if(%displacement < 0 )
				%veh.lastVel = %veh.lastVel*-1;
				
			if( (%ZDist-%displacement) > $GroundFloat ){
				%NewPos = getWord(%NewPos,0)@" "@getWord(%NewPos,1)@" "@getWord(%veh.lastPos,2)+%displacement;
			}
		} else {
			%veh.lastVel = getword(Item::getVelocity(%veh),2);
		}

		//Keep rotation constant if were not in the "air"


		//if(%ZDist >  $GroundFloat + 0.9)
		//	%NewRot = %veh.lastRot;
		

		//Set all our things.

		GameBase::setPosition(%veh,%newPos);
		%veh.lastPos = %newPos;

		// Only set rot if its to much.
		//Smooth out the rotation settings a tad.
		%RotDifference0 = (getword(%groundRot, 0) - getword(%rot0, 0));
		if(%ZDist >  $GroundFloat + 0.9)
			GameBase::setRotation(%veh,%veh.lastRot);
		else if( %rotDifference0 > $RotOffset || %rotDifference0 < -1*$RotOffset) {
			%RotDifference0 = getword(%groundRot, 0);
			
			// only for going forwards.
			if(getword(%veh.lastRot, 0) > %RotDifference0)
				%RotDifference0 = -1*%RotDifference0;
			%NewRot = %rotDifference0@" "@getWord(GameBase::getRotation(%veh),1)@" "@getWord(GameBase::getRotation(%veh),2);
			GameBase::setRotation(%veh,%NewRot);
			%veh.lastRot = %newRot;
		
		} else			
			%veh.lastRot = %rot0;


	}
		schedule("VehicleHover("@%veh@","@%client@");",$TimeSkip,%veh);

}


// Thanks to Hosed for use of this code...
function vehicleHoverOLD(%vehicle, %clientId, %changeZRot, %changeYRot)
{
	// Global var. True if driving vehicle. False if not. 
	if($SFdrivingAPC[%clientId])  
	{
		%refX1 = "-0.393 0 0";
		%refX2 = "-0.393 0 1.571";
		%refX3 = "-0.786 0 0";
		%refX4 = "-0.786 0 1.571";

		%refY2 = "-0.393 0 0.786";
		%refY1 = "-0.393 0 -0.786";
		%refY4 = "-0.786 0 0.786";
		%refY3 = "-0.786 0 -0.786";
		
		%refHeight = "-1.575 0 0";

		//Temp set Rotations
		%OldRot = GameBase::getRotation(%vehicle);
		%NewXRot = getword(%OldRot, 0);
		%NewYRot = getword(%OldRot, 1);
		%changeInZ = %changeYRot - %NewYRot;
		%changeInZ = %changeInZ * 3;
		//if(($modVal % 5) == 0) 
		//	echo(%changeInZ);
		//$modVal++;
		%NewZRot = %changeZRot + %changeInZ;
		
		// Front Middle Position
		//----------------------
		if(GameBase::getLOSInfo(%vehicle,20,%refX1))
			%frontMiddlePos = $los::position;
		else
			if(GameBase::getLOSInfo(%vehicle,1000,%refX3))
				%frontMiddlePos = $los::position;
			else
				%frontMiddlePos = "0 0 0";
		
		// Rear Middle Position
		//-----------------------
		if(GameBase::getLOSInfo(%vehicle,20,%refX2))
			%rearMiddlePos = $los::position;
		else
			if(GameBase::getLOSInfo(%vehicle,1000,%refX4))
				%rearMiddlePos = $los::position;
			else
				%rearMiddlePos = "0 0 0";

		// Left Middle Position
		//------------------------
		if(GameBase::getLOSInfo(%vehicle,20,%refY1))
			%leftMiddlePos = $los::position;
		else
			if(GameBase::getLOSInfo(%vehicle,1000,%refY3))
				%leftMiddlePos = $los::position;
			else
				%leftMiddlePos = "0 0 0";

		// Right Middle Position
		//------------------------
		if(GameBase::getLOSInfo(%vehicle,20,%refY2))
			%rightMiddlePos = $los::position;
		else
			if(GameBase::getLOSInfo(%vehicle,1000,%refY4))
				%rightMiddlePos = $los::position;
			else
				%rightMiddlePos = "0 0 0";

		//-------------------
		// X Rotation Stuff
		//-------------------
		// Rear Position
		%rMidX = getword(%rearMiddlePos, 0);
		%rMidY = getword(%rearMiddlePos, 1);
		%rMidZ = getword(%rearMiddlePos, 2);
		// Front Position
		%fMidX = getword(%frontMiddlePos , 0);
		%fMidY = getword(%frontMiddlePos , 1);
		%fMidZ = getword(%frontMiddlePos , 2);
		// X Distance
		%rpos = %rMidX@" "@%rMidY@" 0";
		%fpos = %fMidX@" "@%fMidY@" 0";
		// Find average of both rotations
		// Total Distance
		%totDist = Vector::getDistance(%rpos, %fpos);
		%zDistance = %fMidZ - %rMidZ;
		if(%totDist != 0)
	    	if( %zDistance != 0 )
			{
				%OppAdd = %zDistance/%totDist;
				%NewXRot = inverseTan(%OppAdd);
			}

		//-------------------
		// Y Rotation Stuff
		//-------------------
		// Right Side Position
		%rsMidX = getword(%rightMiddlePos, 0);
		%rsMidY = getword(%rightMiddlePos, 1);
		%rsMidZ = getword(%rightMiddlePos, 2);
		// Left Side Position
		%lsMidX = getword(%leftMiddlePos , 0);
		%lsMidY = getword(%leftMiddlePos , 1);
		%lsMidZ = getword(%leftMiddlePos , 2);
		// Y Distance
		%rsPos = %rsMidX@" "@%rsMidY@" 0";
		%lsPos = %lsMidX@" "@%lsMidY@" 0";
		// Total Distance
		%totDist = Vector::getDistance(%rsPos, %lsPos);
		%zDistance = %lsMidZ - %rsMidZ;
		if(%totDist != 0)
			if( %zDistance != 0 )
			{
				%OppAdd = %zDistance/%totDist;
				%NewYRot = inverseTan(%OppAdd);
			}

		//-------------------
		// Height Stuff
		//-------------------
		if(GameBase::getLOSInfo(%vehicle,20,%refHeight))
		{
			%groundPos = $los::position;
			%vehiclePos = GameBase::getPosition(%vehicle);
			%vehicleX = getword(%vehiclePos, 0);
			%vehicleY = getword(%vehiclePos, 1);
			%vehicleZ = getword(%vehiclePos, 2);
			%groundz = getword(%groundPos, 2);
			%height = %vehicleZ - %groundZ;
			if(%height >= 1.99 || %height <= 2.01)
			{
				%newpos = %vehicleX @ " " @ %vehicleY @ " " @ (%groundZ + 2.0);
				GameBase::setPosition(%vehicle,%newpos);
			}
		}

		//-------------------
		// Set Rotation Stuff
		//-------------------
		// New Rotation
		%NewRot = %NewXRot@" "@%NewYRot@" "@%NewZRot;
		GameBase::setRotation(%vehicle,%NewRot);

		schedule("vehicleHover("@%vehicle@","@%clientId@","@%NewZRot@","@%NewYRot@");",0.05, %vehicle);
	}
}

function inverseTan(%x)
{
	%theta = %x - ((%x*%x*%x)/3) + ((%x*%x*%x*%x*%x)/5);
	return %theta;
}

//$Roll = 0.196349540875; //- 1/32 Roll
$Roll = 0.008; //- 1/48 Roll
//$Roll = 0.0981747704375; //- 1/64 Roll
function Vehicle::BarrelRoll(%this)
{
	%client = GameBase::getControlClient(%this);
	%player = Client::getOwnedObject(%client);
	%data = GameBase::getDataName(%this);
	%speed = sqrt(pow(getword(Item::getVelocity(%this),0),2) + pow(getword(Item::getVelocity(%this),1),2) + pow(getword(Item::getVelocity(%this),2),2));
	if(%data != Fighter && %data != Fighter2 && %data != Warthog && %data != MoveWarthog)
		return;
	if(%speed <= %data.maxSpeed*4/5) {
		Client::sendMessage(%client,0,"You must Accelerate more before you can Barrel Roll~wError_Message.wav");
		return;
	}
	if(getWord(GameBase::getRotation(%this),1) >= 0)
		Vehicle::RollLeft(%this);
	else
		Vehicle::RollRight(%this);
	%this.lastRoll = getSimTime();
}

function Vehicle::RollLeft(%this)
{
	%rot = GameBase::getRotation(%this);
	%NewRot = Vector::Add(%rot,"0 "@$Roll@" 0");
	GameBase::setRotation(%this,%NewRot);
	if(%this.rolling == 1)
		schedule("Vehicle::RollLeft("@%this@");",0.001,%this);
}

function Vehicle::RollRight(%this)
{
	%rot = GameBase::getRotation(%this);
	%NewRot = Vector::Sub(%rot,"0 "@$Roll@" 0");
	GameBase::setRotation(%this,%NewRot);
	if(%this.rolling == 1)
		schedule("Vehicle::RollRight("@%this@");",0.001,%this);
}

function Vehicle::EndRoll(%this)
{
	%this.rolling = "";
}

function GetOffSetRot2(%offset,%rot,%pos)
{
	%x = getWord(%offset,0);
	%y = getWord(%offset,1);
	%z = getWord(%offset,2);
	%posA = Vector::add(%pos,Vector::getFromRot(Vector::Add(%rot,"0 0 -1.570796327"),%x));
	%posB = Vector::add(%posA,Vector::getFromRot(%rot,%y));
	%posC = Vector::add(%posB,Vector::getFromRot(Vector::Add(%rot,"1.570796327 0 0"),%z));
}

function GetOffSetRot(%offset,%rot,%pos)
{
	%x = getWord(%offset,0);
	%y = getWord(%offset,1);
	%z = getWord(%offset,2);
	%posA = Vector::add(%pos,Vector::getFromRot(Vector::Add("0 "@getword(%rot,1)@" "@getword(%rot,2),"0 0 -1.570796327"),%x));
	%posB = Vector::add(%posA,Vector::getFromRot(getword(%rot,0)@" 0 "@getword(%rot,2),%y));
	%posC = Vector::add(%posB,Vector::getFromRot(Vector::Add(getword(%rot,0)@" "@getword(%rot,1)@" 0","1.570796327 0 0"),%z));
	return %posC;
}

function GetOffSetRot3(%offset,%rot,%pos)
{
	%k = Vector::getFromRot(%rot);
	%padd = getword (%k, 0) @ " -10 " @ getword (%k, 1);
	%pos = Vector::add(%pos, %padd);
	


}

function RemoteGetAltitude(%client)
{
	if(%client.justCalledGetAlt)
		return;

	%client.justCalledGetAlt = true;
	schedule(%client@".justcalledGetAlt = false;",0.5);
	%toReturn = 0;
	%vehicle = client::getcontrolobject(%client);
	%down = "-1.575 0 0";
	if(GameBase::getLOSInfo(%vehicle,5000,%down))
	{
		%pos = $LOS::Position;
		%toReturn = getword(gamebase::Getposition(%vehicle),2) - getWord(%pos,2);
	}
	remoteeval(%client,returnAltitude,floor(%toReturn));
}
