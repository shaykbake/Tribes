//=============================================================================
//
//						BWADMIN IP BANLIST
//
//=============================================================================
//
//	To use this list simply enable the list in your ServerConfig.cs file and
//	then add the ip data as below:
//
//	BWAdmin::AddIPBan("38.32.*.*");
//
//	Where * is a wildcard that means any number.
//
//

BWAdmin::AddIPBan("38.32.*.*");
BWAdmin::AddIPBan("151.200.*.*");
