$bwadmin::MaxBanStrings = 3;

$bwadmin::NameBanString[1,string] = "KINDS";
$bwadmin::NameBanString[1,message] = "Buggar off you TKing SOB";
$bwadmin::NameBanString[1,bantime] = 3000;

$bwadmin::NameBanString[2,string] = "LDR{TAS}Elvis";
$bwadmin::NameBanString[2,message] = "Buggar off you TKing SOB";
$bwadmin::NameBanString[2,bantime] = 3000;

$bwadmin::NameBanString[3,string] = "{TAS}PiNkBunnY";
$bwadmin::NameBanString[3,message] = "You steal my name....Your not welcome here...FUCK OFF";
$bwadmin::NameBanString[3,bantime] = 3000;

$bwadmin::NameBanString[4,string] = "<KM>Annihilator";
$bwadmin::NameBanString[4,message] = "You steal my name....Your not welcome here...FUCK OFF";
$bwadmin::NameBanString[4,bantime] = 3000;

$bwadmin::NameBanString[4,string] = "LDR{TAS}HOLLOW";
$bwadmin::NameBanString[4,message] = "You steal my name....Your not welcome here...FUCK OFF";
$bwadmin::NameBanString[4,bantime] = 3000;


//$bwadmin::NameBanString[1,string] = "";
//$bwadmin::NameBanString[1,message] = "The  clan has been banned from this server";
//$bwadmin::NameBanString[1,bantime] = 1800;
//
//$bwadmin::NameBanString[2,string] = "";
//$bwadmin::NameBanString[2,message] = "The  clan has been banned from this server";
//$bwadmin::NameBanString[2,bantime] = 1800;
//
//$bwadmin::NameBanString[3,string] = "";
//$bwadmin::NameBanString[3,message] = "The  clan has been banned from this server";
//$bwadmin::NameBanString[3,bantime] = 1800;
//
//$bwadmin::NameBanString[4,string] = "";
//$bwadmin::NameBanString[4,message] = "The zX clan has been banned from this server";
//$bwadmin::NameBanString[4,bantime] = 1800;

