=====================
CiSYGY Server Mod PR1
=====================

NOTE: neither Sundiata nor CiSYGY will be held responsible for any damage caused by this software, etc, etc.  It's been fairly well-tested, but bugs may still be present.

NOTE TO SERVER ADMINS:  If you wish to run this mod on your server, please name the mod directory "CiSYGY" (caps on all but the 'i') and include one of the following lines of text in your MOTD:


-----
Running CiSYGY PR1 by Sundiata (cisygy.frags.com)
-----
Running CiSYGY mod (PR1) by Sundiata (cisygy.frags.com)
-----
Running CiSYGY Server Mod (PR1) by Sundiata (cisygy.frags.com)
-----


NOTE TO SCRIPTERS:  Feel free to modify the CiSYGY Server Mod PR1 as you see fit; if you do modify this mod, however, you MUST include the following lines of text in any and all copies of your modified mod:

-----
This mod is based on the CiSYGY Server Mod PR1, created by Sundiata (alm_darbyt@carleton.edu)
-----

Also, please send me a copy of any changes you make--I'm always curious to see what other people want!

If you have any questions about this mod, contact Sundiata at alm_darbyt@carleton.edu.  If you encounter anyone using this mod w/o giving credit where credit is due, please let me know.  Thanks!

Sundiata of CiSYGY
http://cisygy.frags.com