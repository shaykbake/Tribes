
function throwMine(%desc)
{
	%delta = getSimTime() - $throwStartTime;
	if (%delta > 1)
		%delta = 100;
	else
		%delta = floor(%delta * 100);
	remoteEval(2048,throwItem,%desc,%delta);
}

EditActionMap("playmap.sae");

bindCommand(keyboard0, make, "g", TO, "useItem(getMountedItem(4));");
bindCommand(keyboard0, make, "e", TO, "throwStart();");
bindCommand(keyboard0, break, "e", TO, "throwMine(getMountedItem(5));");

