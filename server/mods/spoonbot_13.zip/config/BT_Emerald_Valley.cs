$BotTree::T_Count = "1";
$BotTree::T_Count_Calc = "0";
$BotTree::T_Pos0 = "57.7959 346.406 76.0745";
$BotTree::T_Version = "2";
