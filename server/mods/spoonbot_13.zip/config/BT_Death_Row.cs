$BotTree::T_Count = "1";
$BotTree::T_Count_Calc = "0";
$BotTree::T_Pos0 = "85.4779 -30.7171 154.001";
$BotTree::T_Version = "2";
