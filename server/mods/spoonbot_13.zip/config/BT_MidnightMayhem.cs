$BotTree::T_Count = "1";
$BotTree::T_Count_Calc = "0";
$BotTree::T_Pos0 = "0 0 0";
$BotTree::T_Version = "2";
