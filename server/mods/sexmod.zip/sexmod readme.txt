//=======================================================
// Sex Mod By Plasmatic
// Copyright Oct, 2001.  By Steve Madden
// n3ppvw@home.com or ziptiezmail@netscape.net
// icq# 77161332
//=======================================================
// Extract files to C:\Dynamix\TRIBES directory. 
// -The file that contains the BASE folder.
//=======================================================
//
// Usage- For non dedicated servers- 
// Not recomended for network servers, great for practice, or small LAN games.
// Right click on tribes.exe in C:\Dynamix\TRIBES and create shortcut.
// Right click your new shortcut and add " -mod sex" to the target line.
// Hit apply, and ok. Double click to run.
// Rename and drag to desktop for ease of use.
// You will be admin automatically with this setup.
//
//=======================================================
//
// Sex Mod is not a copy-cat mod, and is not based on 
// any other mod besides base mod that ships with tribes ;)
// Sex Mod is based on an idea from [KmA] Jumper, Thanks BRO!
// Pay him a visit at Jumpers Place. Long live [KmA] -Kiss My Ass!
// Special thanks to Sevnn and Scavenger of the Annihilation mod 
// And all the others that helped me hunt down bugs.
//
//=======================================================
// edit adminuserslist.cs in config to your liking.
//=======================================================
// ALL connecting players are logged in connect.log in config directory.
//=======================================================
//
// Server will automatically admin local clients
// -ip address 192.168.0.1 and 192.168.0.2 on your local network
// If you have a router or if server is set up as a dhcp server this should work.
// If not, admin yourself with adminuserslist.cs
// Your connecting ip address will be in connect.log after you join server. 
//
//=======================================================
// Known issues.
// Players hogging control of Rocket turrets at command stations can cause server lag.
// Only after there are ALOT of rockets in air.
// Players farming pencil turrets will lag the same way.
// Firing plasma turrets will have the same effect, but not so pronounced.
// Rock launcher no longer lags in this manner as it does NO damage to players.
// Most lag issues will arise from servers connection, not actual server lag.
// Contact me if you have questions.
//=======================================================


Whats new in version 2.0

In no particular order...

Sex mod is mapper friendly now, send any maps to n3ppvw@home.com.
Changed rock trails -looks more like a meteor now.
fixed optical rocket pack, players can not tk with it now, added smoke puff trail.
Changed Cherry gun to shotgun fire blaster bolts, very evil. More powerfull in builder.
Changed UFO launcher to shotgun fire Discs.
Players now spawn with:
	Cherry, UFO, Rocklauncher, Orgasm, Health kits, beacons and turret.
Players in DM spawn with:
	UFO, Needle, Rocklauncher, inventory pack, and 10 health kits.
Ctrl- K now does damage to surrounding items/ players.
Server configurable options in sex.cs:
	Voteing builder mode can be turned off by server owner.
	Reset builder, fair teams, no kill, and base damage on new map. 
	Admin votes can be weighted now, in server setup- sex.cs
fixed possess bug
fixed freeze bug
$testcheats and giveall(); now work properly, and will disable on map switch.
Added new weapons: 
	Agedon gun- fires projectile that splits into grenades.
	Blue sex- fires blue mines shot gun style that explode on contact.
	Magic Miner -lobs shell that splits into firey mines that deploy.
Added Hellfire pack- poops disc mines from the rear of player

As a side note, none of these weapons can be used to tk unless TD is on, even the mine launcher, something I have not seen in other mods.


// Oct 2001, Plasmatic aka Steve.
