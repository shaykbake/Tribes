Drop all these files into your C:\Dynamix\TRIBES\base\missions folder

I would like to thank Jumper from Jumpers Place, and all the [KmA] that play there for their input and help on these maps.

These maps are all server side. No need to install them to play. 
All maps copyright 1999, 2000 ^^Plasmatic^^, coding by ^^Plasmatic^^

These Maps will be running on my server- A HOLE! and Jumpers server- Jumpers Place. If you have any questions or comments, feel free to stop by, or email me at -ZiptiezMail@netscape.net

Drop by the ())_Crayons_))> site for a mapping tutorial I wrote.
http://www.crayons.f2s.com/information/tips/MapMaking1.html

Enjoy,
[KmA]^Plasmatic^ 