$ConnectLog = true; // export name+ ip of all players that connect
// 	1 = Yes you are using the list.
//	0 = No you are NOT using the list.
$UserList::Activated = 1;

// How many Users In your list?
$UserList::MaxUsers = 19;

//The Actual User.
//$UserList::User[1] = "<UserNumber> <UserName> <UserPassword> <AccessLevel> <IP Masks>";
//
//<UserNumber> 	= What is this users Usernumber. 
//
//<UserName> 	= What is this Users Regular Name. 
//		  (HAS TO BE ONE WORD - NO Spaces)
//
//<UserPassword> 	= What this user's SAD() Password is. 
//		  (HAS TO BE ONE WORD - NO Spaces)
//
//<AccessLevel> 	= What Access do they have. Choices are:
//		  God           - Auto-God Admin status
//		  SuperAdmin 	- Super Admin. (duh).
//		  PublicAdmin 	- Public Admin. Uses Current Public admin Lockouts. 
//		  AutoSuper 	- Super Admin w/ Auto Admin. 
//		  AutoPublic 	- Public Admin, same as above w Auto Admin. 
//
//<IP Masks> 	= What IP or IPs you want to list for that user. you can list
//		  as many IPs as you want. the only wildcard accepted is * 
//		  For Example:
//			User's actual IP = 209.14.25.25
//			Successful IP Mask = 209.14.*.*
//		  When using the * that will allow any number for that part of the IP. 
//		  Please be aware of the consequences of using wildcards and autoadmin. 
//		  You may give a whole ISP control of your server, or even the whole Planet. 
//
//Example

$UserList::User[1] = "1 .:(A):.Armagedon 123 God 172.*.*.*";
$UserList::User[2] = "2 >SeX<_StrydeR> 123 God 63.205.*.*";
$UserList::User[3] = "3 >SeX<_SniperX15 123 God 172.*.*.*";
$UserList::User[4] = "4 >SeX<_xevilbabez 123 God 63.*.*.*";
$UserList::User[5] = "5 >SeX<_HyBriD 123 God 172.*.*.*";
$UserList::User[6] = "6 .:(A):.SykoSnipr 123 AutoPublic 208.*.*.*";
$UserList::User[7] = "7 >SeX<_Orgasm 123 God 192.168.*.*";
$UserList::User[8] = "8 >SeX<_StrydeR> 123 God 12.119.120.*";
$UserList::User[9] = "9 >SeX<_Varsity 123 AutoPublic 194.110.*.*";
$UserList::User[10] = "10 >SeX<_^Lil^Bit 123 God 24.158.*.*";
$UserList::User[11] = "11 .:(A):.B_Pimpin 123 God 172.*.*.*";
$UserList::User[12] = "12 .:(A):.Stingray 123 God 64.80.*.*";
$UserList::User[13] = "13 >SeX<_Jugsmear 123 God 254.123.*.*";
$UserList::User[14] = "14 .:(A):.Orion 123 God 172.*.*.*";
$UserList::User[15] = "15 Spawne32 123 God 209.*.*.*";
$UserList::User[16] = "16 .:(A):.*BO* 123 AutoPublic 65.29.94.103";
$UserList::User[17] = "17 .:(A):.BludStain 123 AutoPublic 4.54.235.*";
$UserList::User[18] = "18 .:(A):.Vorter_X_ 123 God 63.*.*.*";
$UserList::User[19] = "19 .:(|A|):.WhIzAtIt 123 God 63.*.*.*";

