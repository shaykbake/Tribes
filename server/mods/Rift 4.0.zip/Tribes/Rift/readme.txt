----------------------------------------------------------------
Name: ISN Rift
Version: 4.0a 'beta'
Date: 25-10-2000

URL: http://www.tribes-universe.com/isn/

Purpose: To create a mod in which EVERYTHING REQUIRES ENERGY.


Development Team:

	Original Concept 
	 (TF)Ryath

	Mod Code
	  Lead Code - Dynamix Team
	  Initial Code - (TF)Ryath, (TF)SlayerMonk
	  

ALL CLIENT PACK INFORMATION OR PIECES HAVE BEEN TAKEN FROM TAC AND OTHERS BUT THAT WILL CHANGE. TAC PEOPLE HAVE BEEN RECONISED FOR SKILLS BELOW:
	
               Mapping
	  Lead Mapper - [TPG]SaNTa[DTM]

	  Additional Maps - [EL]Orange[TPG] & [DH]RogueQD[TPG] & Potato

	Skins
	  [TPG]SMedly[DTM]

	Sounds
	  [TPG]SaNTa[DTM]



Contact: isn@tribes-universe.com


Thanks: The development team would like to thank Dynamix for the use 
	of plus base as our admin base.  

	Also many thanks to all the people who helped beta
	test this mod and found all the little bugs that we missed. 
	This new version has been a LONG time in coming but we 
	think you will all be very happy with the results

ISN Rift began from Dynamix Plus MOD version 1.1 for Tribes v. 1.11 and higher
(C) 2000 Dynamix, Inc.
					  
Rebalanced Tribes gameplay MOD

Features:

Reduced (capped) ski velocities
Increased chaingun spread
Temporary respawn invulnerability (controlled by $Server::respawnInvulnerableTime)
Temporary respawn no weapon
Longer range on mortar, ELF and repair pack
Mines take more damage to destroy before deployed
Shields on vehicle pads
Faster and tougher medium armor
Faster and tougher vehicles
ELF spam fix
Flag return fixes
Team player count added to tab score list

ISN Modifications ISN Rift MOD version 4 WEAPONS BETA 1.1 for Tribes v. 1.11 and higher.
(C) 2000 ISN Modifications Inc.

Energy Based Tribes gameplay MOD

Feature Weapons: (all base weapons included)

Energy Launcher
Light/ Heavy Flamer
Rocket Launcher
Equilizer
Vulcan
Bolt Rifle
Shock Cannon
Multi-Plasma
Fusion Launcher
Grav-Gun
Disruptor Cannon
Devistator Launcher
EMP Pulse Cannon
EMP Mortar
EMP Thrower

Feature Packs: (all base packs except Ammo pack, Deploy Ammo Station  

Warp Pack
Scout Pack
Flight Pack
Cloak Pack
Swap Pack
Sniper Stealth Pack
Combat Pack
Energizer Pack
EMP Pulse Pack
Engineer Power Pack


Feature Deployables: (all base turrets)

Ambusher Turret
AD Plasma Turret
Laser Turret
Flame Turret
Repulse Turret
Shockwave Turret (with EMP)
Burster Turret

Feature Tools: (all base tools)

Engineer Repair Gun
Drain Gun
Rupture Device
Dissasemble Gun
Targeter Turret (auto)



AND MUCH MUCH MORE...................


---------------------------------------------------------------
------------  INSTALLING & UNINSTALLING RIFT -------------------
---------------------------------------------------------------
Client Install: NONE. 

New Server Install: 
	1. Unzip into default Tribes Dir.
	   (where tribes.exe resides - UNZIP WITH PATH INFORMATION)
	This means:

	When installed The Files Should be here: 
		Tribes\ISNRift\scripts\scripts.vol (this beta the files are not zipped into a vol file)
		Tribes\ISNRift\missions\*.dsc
		Tribes\ISNRift\missions\*.mis

	NOTE: If these files are not in these folders...put them there.

	      
	
	2. Command line to run the mod.
	   (A command line is what you use to start the game.
	    for windows its called a shortcut. It's what you 
	    double click on to run the game.)

	   Just add "-mod ISNRift" to your current Server Command Line.
	   For Example:
		Running Normally. 
			tribes.exe
		Running this Mod.
			tribes.exe -mod ISNRIft

	   If you have a custom Server Config then add the +exec Parameter
	   BEFORE The -mod parameter. 	
	   For Example:
		Running Normally. 
			tribes.exe +exec MyConfig.cs
		Running this Mod.
			tribes.exe +exec MyConfig.cs -mod ISNRift

	   If your runing dedicated and have a special server config. 
	   I suggest you use infinitespawn. (get it at tribesplayers.com)
	   For Example:
		Running Normally. 
			infinitespawn *tribes +exec MyConfig -dedicated
		Running this Mod.
			infinitespawn *tribes +exec MyConfig -mod ISNRift -dedicated


Uninstalling:

	Delete the Tribes\ISNRIft Directory and everything in it. 
	All files are listed above. 
	THIS MOD DOES NOT CHANGE ANYTHING IN TRIBES\BASE.


----------------------------------------------------------------
-----------------------  DISCLAIMER  ---------------------------
----------------------------------------------------------------
    We are not responsible for any damage this game 
    modification may cause you or anything having to do 
    with you. If you lose your job because you play this
    game nite and day, it is purely your responsibility.
    I also am not responsible for any hardware failures 
    or software problems that may arise in TRIBES. For 
    problems of that nature contact the game manufacturer.
    If you believe this modification has problems please 
    report them to me so that I may look into it. 
    I am not responsible for any bugs or problems caused
    from copying this code into another mod. I do not claim
    to support any other mod using my code. If they have
    problems, bother them, not me. 
		- ISN RIFT Development Team
----------------------------------------------------------------


