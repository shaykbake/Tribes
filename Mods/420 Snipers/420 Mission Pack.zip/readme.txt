This is the 420 mission pack 
it consists of all the maps running on the 4:20ville servers 
all you have to do is unzip the missions folder into your 
dynamix\tribes\base\missions dir 

and these are only server side maps 
