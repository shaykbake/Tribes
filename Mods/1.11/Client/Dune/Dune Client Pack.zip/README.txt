DUNE ClientPack 


This installation is for the DUNE Clientpack, for use with the DUNE Tribes mod.

What it will do:
-Provide custom skins for each of the armors in the mod.
-Provide custom skins for some of the buildings in the mod. All logos are changed.
-Macro the J button (or whatever you change it to) to toggle between Single-Fire, or Full-Auto mode 
  with the Semi-Automatic Rifle
-Macro the N button to "the Unarmed attack" feature, unique for each armor.
 +Soldier: % chance to trip the opponent. Attacker will fall down for the same amount of time.
 +Trooper/Sardaukar: Grab the opponent, immobilizing them. Release will throw the opponent. 
   If grabbed, use the "Block" button to try and get out (Press it a lot)
 +Bashar/Burseg: Use shagwire to garrote the target. You must aim at the back of their head 
   for it to work. Again, if grabbed, use the "Block" button to try and get out.
 +Fremen: Throw sand into your enemy's eyes. Burseg, Ixian and BT soldiers are all immune to this attack.
   If the enemy is blocking, this will cause them to fall down as a "Tackle redirect" instead of sandthrow.
 +Fedaykin: Disarm the enemy, no matter what weapon they're using. If you can, you will then wield
   that weapon. If the enemy is blocking, this will cause them to fall down as a "Tackle redirect" instead
   of disarm.
 +Face Dancer: Snap the enemy's neck, killing them silently and instantly. You much attack from behind.
-Macro the L button to the "Climb" feature. If you can see the top of a ledge next to you, aim at that
  ledge, remove your weapon, and press the button. You will climb up and onto the obstacle.
-Macro the , button to disable/enable weapon looping.
-Macro the 1, 2, 3, 4, 5, 6, 7, 8, 9 buttons above the normal keys, to enter different weapon types,
  for the weapon looping. Weapon Looping is explained below.
-Provide a box on the HUD that tells you how many of what types of clips you are carrying. This can
  be disabled in the DuneChangeables.cs file.
-Provide a new "V-Menu" quick chat list, chuck full of unique DUNE-like sayings. The Vmenu will change
  when your armor, and/or team changes, so each armor/team combination has a list of vmenu macros that
  are unique to them.


Basically, this is meant for use with the DUNE mod. Hopefully, it will make for a much more enjoyable game.


Instructions for installation:
-Download the file.
-Extract the files in the downloaded zip, into a temporary folder.
-Open the "config" directory, and move it's contents into your corresponding "../tribes/config/"
	directory. If you already have an "AutoExec.cs" file, you will have to add anything that is
	new or different in this one, to the old one. 
-Open DuneChangeables.cs in notepad, and follow the header directions to make sure your controls are binding to
	the controls you want them bound to, as opposed to the default setup.
-Move the "DUNE" directory into your "../tribes/" directory.
-Move the CONTENTS of the "base/skins" directory into your "../tribes/base/skins/" directory.
-Connect to a DUNE server and start playing!


Weapon Looping
Weapon looping is a feature that allows you to have more control over what weapons you're using and when
you use them. There are 9 different weapon loops that you can enter, each with a different purpose
for fighting. When you press one of the keys to enter a loop, you will equip the best weapon for that type.
Every time you switch weapons using the normal switch weapon button, it will only switch to those weapons of
the same type. To get to a different type, you must select that new type. This helps cut down on mistakes in
battle. For instance, if you're fighting melee, and you get disarmed, switch weapons, and accidentally pull out
a non-melee weapon. This of course can kill you because of the delay, or because it's a projectile weapon that
you fired inside your shield, or because it's a lasgun you fired inside your shield. With weapon looping, if you're
fighting melee, and have the melee weapon loop selected, it will rotate only between melee weapons, removing risk.
Additionally, every time you select a new weapon loop, it will select the "best" weapon in that loop that you are
carrying. So if you are disarmed during a fight, you can just reselect the melee loop, and pull out the next best
weapon you're carrying, instead of hunting it down using the normal switch weapon.
Of course, some people might not want weapon looping on, or there may come the occasion that you want it temporarily
disabled. To do this, simply press the "," button. It will toggle between turning Weapon Looping on and off.
Whenever you log on, weapon looping will automatically turn on. To have it start as automatically disabled, you'll
need to change the appropriate text in the "DuneChangeables.cs" file.
These loops are described below, with their corresponding keys:
1 - No weapon. This will remove any weapon you are currently using. *Note* it does not actually change
	which weapon loop you are currently in. It just puts away whatever weapon you're currently using.
2 - Melee. This will enter you into the melee weapon loop, and equip the best melee weapon at your disposal.
	If you have no melee weapons, then neither your weapon is changed, nor the weapon loop that you're currently in.
	Melee weapons include, in order of preference: Crysknife, Saber, Rapier, Kindjal, Sliptip, Knife2, Knife, Stunner.
3 - Projectile. This will enter you into the projectile weapon loop, and equip the best projectile weapon at your disposal.
	If you have no projectile weapons, then neither your weapon is changed, nor the weapon loop that you're currently in.
	Projectile weapons include, in order of preference: MountedArtillaryGun (on Trackers), MountedMachineGun (on trackers), 
	MGun2(AI specific weapon), MGun (heavy machine gun), SniperRifle, Flamethrower, Rifle (full auto), Rifle2 (single fire),
	Pistol, Maula, RLauncher (rocket launcher), Stunner.
4 - Lasgun. This will enter you into the lasgun weapon loop, and equip the best lasgun weapon at your disposal.
	If you have no lasgun weapons, then neither your weapon is changed, nor the weapon loop that you're currently in.
	Lasgun weapons include, in order of preference: HeavyLas, RifleLas, SmallLas, Cutteray.
5 - AntiAircraft. This will enter you into the anti-aircraft weapon loop, and equip the best anti-aircraft weapon at your disposal.
	If you have no anti-aircraft weapons, then neither your weapon is changed, nor the weapon loop that you're currently in.
	anti-aircraft weapons include, in order of preference: Piller (of fire), RLauncher (rocket launcher), 
	MountedMachineGun (on Trackers), MGun2 (AI specific weapon), MGun (Heavy machine gun), Rifle (full-auto), Rifle2 (single fire),
	RifleLas, Pistol.
6 - AntiGroundCar. This will enter you into the anti-ground-car weapon loop, and equip the best anti-ground-car weapon at your disposal.
	If you have no anti-ground-car weapons, then neither your weapon is changed, nor the weapon loop that you're currently in.
	anti-ground-car weapons include, in order of preference: MountedArtillaryGun (on Trackers), RLauncher (rocket launcher), 
	HeavyLas, RifleLas, MountedMachineGun (on Trackers), MGun2 (AI specific weapon), MGun (Heavy machine gun), Rifle (full-auto), 
	Rifle2 (single fire), SmallLas, Pistol, Cutteray.
7 - Throwing. This will enter you into the throwing weapon loop, and equip the best throwing weapon at your disposal.
	If you have no throwing weapons, then neither your weapon is changed, nor the weapon loop that you're currently in.
	Throwing weapons include, in order of preference: Kinfe, Knife2, Crysknife, SlipTip, Kindjal, Saber, Rapier.
8 - No Ammo. This will enter you into the "No Ammo" weapon loop, and equip the first non-melee weapon that is out of ammo.
	If you have no weapons that are out of ammo, then neither your weapon is changed, nor the weapon loop that you're currently in.
	The No Ammo weapons include any weapon that uses ammo (non-melee, non-mounted), that you have in your posession.
9 - Tool. This will enter you into the tool weapon loop, and equip the best tool "weapon" at your disposal.
	If you have no tool "weapons", then neither your weapon is changed, nor the weapon loop that you're currently in.
	Tool "weapons" include, in order of preference: Cutteray.



Disclaimer of use.
Everything contained in these zip files are either my intellectual property or the intellectual property
of the corresponding author, Diddily. Any claims otherwise are made illegally and subject to copywrite laws. 
You are free to use all or parts of the code, pictures, or other parts of the files for your own uses, as long
as credit is given to the original authors.
By using these files, you know and understand this. 

Made by Jesus 06/14/04
Assisted by Diddily

Questions can be sent to Deathknight@hush.com or posted on the forum at www.jmods.bravepages.com