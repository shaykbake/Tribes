
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Set these values to whatever values you want
//| the buttons mapped to.
//|
//|	For the inputs, it will be "mouse0" for
//|	the mouse, and "keyboard0" for the keyboard.
//|
//|	For the others, it will be whatever button
//|	on those devices you use for that.
//|
//|	If you use a shift, alt or control button
//|	for these normally, then you got more work
//|	ahead of you. This wont support them naturally.
//|	If you know how to fix it for yourself, do so.
//|	If not, you CAN contact me and i should be
//|	able to help (although it wont be pretty).
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

$DUNE_Weapons = "keyboard0";
$DUNE_Nothing = "1";
$DUNE_Melee = "2";
$DUNE_Projectile = "3";
$DUNE_Lasgun = "4";
$DUNE_AA = "5";
$DUNE_AT = "6";
$DUNE_Throwing = "7";
$DUNE_NoAmmo = "8";
$DUNE_Tool = "9";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| This will toggle your semi-auto rifle between
//|	single fire and full auto mode.
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$DUNE_SingleFire_or_FullAuto_Input = "keyboard0";
$DUNE_SingleFire_or_FullAuto = "j";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| This will preform an unarmed attack.
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$DUNE_UnarmedAttack_Input = "keyboard0";
$DUNE_UnarmedAttack = "n";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| This will climb you over and onto an exposed ledge.
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$DUNE_Climb_Input = "keyboard0";
$DUNE_Climb = "l";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| This will activate, or deactivate, weapon looping
//|	(Weapon looping is explained in the README.txt)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$DUNE_ToggleWeaponLoop_Input = "keyboard0";
$DUNE_ToggleWeaponLoop = ",";



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| Set this to false if you don't want to use weapon looping
//|
//| WL requires the variables immediately above.
//|
//| Basically, it sets you into a "loop" of same type weapons. To get to another weapon
//|    type, you need to enter the proper loop for that.
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$DUNE_WeaponLoop = true;


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| If you do NOT want the Clip box hud, then flip the boolean
//| below to false.
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$Dune_Activate_ClipBox = true; // Turn this line to "$Dune_Activate_clipBox = false;" if you don't want the box.

