
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Dont change anything below here unless you know
//| What your doing.
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//Reset our keymapping.

EditActionMap("playMap.sae");	
bindCommand(keyboard0, make, "1", TO, "use(\"Blaster\");");
bindCommand(keyboard0, make, "2", TO, "use(\"Plasma Gun\");");
bindCommand(keyboard0, make, "3", TO, "use(\"Chaingun\");");
bindCommand(keyboard0, make, "4", TO, "use(\"Disc Launcher\");");
bindCommand(keyboard0, make, "5", TO, "use(\"Grenade Launcher\");");
bindCommand(keyboard0, make, "6", TO, "use(\"Laser Rifle\");");
bindCommand(keyboard0, make, "7", TO, "use(\"ELF gun\");");
bindCommand(keyboard0, make, "8", TO, "use(\"Mortar\");");
bindCommand(keyboard0, make, "9", TO, "use(\"Targeting Laser\");");


function Dune_KillAll()
{
%ngs = nameToId("NamedGuiSet\\PlayGUI");
%len = Group::objectCount(%ngs);
for(%i = 0; %i < %len; %i++)
  {
  %obj = Group::getObject(%ngs, %i);
  %objectName=Object::getName(%obj);
  if(String::findSubStr(%objectName, "Clip_") != -1)
    deleteObject(%obj);
  }
%ngs = nameToId("NamedGuiSet");
%len = Group::objectCount(%ngs);
for(%i = 0; %i < %len; %i++)
  {
  %obj = Group::getObject(%ngs, %i);
  %objectName=Object::getName(%obj);
  if(String::findSubStr(%objectName, "Clip_") != -1)
    deleteObject(%obj);
  }
}


schedule("Dune_KillAll();",10);

//Reset any functions we changed.

