
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Dont change anything below here unless you know
//| What your doing.
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

EditActionMap("playMap.sae");

//Our nothing function. It does.. nothing.

function nothing() {}

bindCommand($DUNE_Weapons, make, $DUNE_Nothing, TO, "DUNE_use(\"nothing\");");
bindCommand($DUNE_Weapons, make, $DUNE_Melee, TO, "DUNE_use(\"melee\");");
bindCommand($DUNE_Weapons, make, $DUNE_Projectile, TO, "DUNE_use(\"projectile\");");
bindCommand($DUNE_Weapons, make, $DUNE_Lasgun, TO, "DUNE_use(\"lasgun\");");
bindCommand($DUNE_Weapons, make, $DUNE_AA, TO, "DUNE_use(\"aa\");");
bindCommand($DUNE_Weapons, make, $DUNE_AT, TO, "DUNE_use(\"at\");");
bindCommand($DUNE_Weapons, make, $DUNE_Throwing, TO, "DUNE_use(\"throwing\");");
bindCommand($DUNE_Weapons, make, $DUNE_Tool, TO, "DUNE_use(\"tool\");");

bindCommand($DUNE_SingleFire_or_FullAuto_Input, make, $DUNE_SingleFire_or_FullAuto, TO, "remoteeval(2048,riflesingleonoff);");

bindCommand($DUNE_UnarmedAttack_Input, make, $DUNE_UnarmedAttack, TO, "remoteEval(2048,unarmedAttackbegin);");
bindCommand($DUNE_UnarmedAttack_Input, break, $DUNE_UnarmedAttack, TO, "remoteEval(2048,unarmedAttackend);");

bindCommand($DUNE_Climb_Input, make, $DUNE_Climb, TO, "remoteeval(2048,climb);");

bindCommand($DUNE_ToggleWeaponLoop_Input, make, $DUNE_ToggleWeaponLoop, TO, "DUNE_ToggleWeaponLooping();");


function DUNE_use(%type)
{
	remoteeval(2048,useItemType,%type);
}

function DUNE_ToggleWeaponLooping()
{
	if($DUNE_WeaponLoop == true)
		$DUNE_WeaponLoop = false;
	else
		$DUNE_WeaponLoop = true;

	remoteeval(2048,setWeaponLoop,$DUNE_WeaponLoop);
}

function remoteSetTeam(%client,%team)
{
	$CurTeam = %team;
	exec(Vmenu);
}

function remoteSetArmor(%client,%armor)
{
	$CurArmor = %armor;
	exec(Vmenu);
}


$Dune_Res["600x480"] = 260;
$Dune_Res["800x600"] = 345;
$Dune_Res["1024x768"] = 485;
$Dune_Res["1280x1024"] = 670;
$Dune_Res["1600x1400"] = 870;

function DUNE_SetUpHud()
{
	Dune_KillHud();

	// Going to do this nice and inefficiently :)
	%pistol = getItemCount("Pistol Clip");
	%maula = getItemCount("Maula Clip");
	%stunner = getItemCount("Stunner Clip");
	%rifle = getItemCount("Rifle Clip");
	%Mgun = getItemCount("Machine Gun belt");	
	%sniper = getItemCount("Sniper Clip");
	%cutteray = getItemCount("Cutteray Cell");
	%smalllas = getItemCount("Small Lasgun Cell");
	%riflelas = getItemCount("Rifle Lasgun Cell");
	%heavyLas = getItemCount("Heavy Lasgun Cell");
	%rlauncher = getItemCount("Rockets");
	
	if($Dune_Res[$pref::VideoFullScreenRes] == "")
		%Res = 345;
	else
		%Res = $Dune_Res[$pref::VideoFullScreenRes];
	$Dune_Hud_Clip_Container = newObject("Clip_Container", FearGui::FearGuiMenu, 70, %res, 100, 150); // XLoc, YLoc, Width, Height
	$Dune_Hud_Header = newObject("Clip_Header", FearGuiFormattedText, 75, %res, 1000, 1000);

	addToSet(PlayGui, $Dune_Hud_Clip_Container);
	addToSet(PlayGui, $Dune_Hud_Header);

	$Dune_Text_Header = "<f2>Clips<L14>#";
	$Dune_Text_Pistol =	"\\nPistol<L15><f1>"@%pistol;
	$Dune_Text_Maula =	"\\nMaula<L15><f1>"@%maula;
	$Dune_Text_Stunner = 	"\\nStunner<L15><f1>"@%stunner;
	$Dune_Text_Rifle =	"\\nRifle<L15><f1>"@%Rifle;
	$Dune_Text_MGun =	"\\nMGun<L15><f1>"@%Mgun;
	$Dune_Text_Sniper =	"\\nSniper<L15><f1>"@%sniper;
	$Dune_Text_Cutteray =	"\\nCutteray<L15><f1>"@%Cutteray;
	$Dune_Text_SmallLas =	"\\nSmallLas<L15><f1>"@%smalllas;
	$Dune_Text_RifleLas =	"\\nRifleLas<L15><f1>"@%riflelas;
	$Dune_Text_HeavyLas =	"\\nHeavyLas<L15><f1>"@%heavyLas;
	$Dune_Text_RLauncher =	"\\nRLauncher<L15><f1>"@%rlauncher;

	Control::setValue("Clip_Header", $Dune_Text_Header);

	if($Dune_Updating != true)
		Dune_Update();
}

function Dune_Update()
{
	$Dune_Updating = true;			
	%pistol = getItemCount("Pistol Clip");
	%maula = getItemCount("Maula Clip");
	%stunner = getItemCount("Stunner Clip");
	%rifle = getItemCount("Rifle Clip");
	%Mgun = getItemCount("Machine Gun belt");	
	%sniper = getItemCount("Sniper Clip");
	%cutteray = getItemCount("Cutteray Cell");
	%smalllas = getItemCount("Small Lasgun Cell");
	%riflelas = getItemCount("Rifle Lasgun Cell");
	%heavyLas = getItemCount("Heavy Lasgun Cell");
	%rlauncher = getItemCount("Rockets");
	
	%num=0;

	$Dune_Text_Header = "<f2>Clips\t\t\t\t#";
	$Dune_Text_Pistol =	"\n<f0>Pistol\t\t\t<f1>"@%pistol;
	$Dune_Text_Maula =	"\n<f0>Maula\t\t\t<f1>"@%maula;
	$Dune_Text_Stunner = 	"\n<f0>Stunner\t\t<f1>"@%stunner;
	$Dune_Text_Rifle =	"\n<f0>Rifle\t\t\t\t<f1>"@%Rifle;
	$Dune_Text_MGun =	"\n<f0>MGun\t\t\t<f1>"@%Mgun;
	$Dune_Text_Sniper =	"\n<f0>Sniper\t\t\t<f1>"@%sniper;
	$Dune_Text_Cutteray =	"\n<f0>Cutteray\t\t<f1>"@%Cutteray;
	$Dune_Text_SmallLas =	"\n<f0>SmallLas\t\t<f1>"@%smalllas;
	$Dune_Text_RifleLas =	"\n<f0>RifleLas\t\t<f1>"@%riflelas;
	$Dune_Text_HeavyLas =	"\n<f0>HeavyLas\t\t<f1>"@%heavyLas;
	$Dune_Text_RLauncher =	"\n<f0>RLauncher\t<f1>"@%rlauncher;


	%CurText = $Dune_Text_Header;
	%num+=%Amt;

	if(%pistol)
	{
		%CurText = %CurText @ $Dune_Text_Pistol;
		%num+=%Amt;
	}		
	if(%maula)
	{
		%CurText = %CurText @ $Dune_Text_Maula;
		%num+=%Amt;
	}		
	if(%stunner)
	{
		%CurText = %CurText @ $Dune_Text_Stunner;
		%num+=%Amt;
	}		
	if(%rifle)
	{
		%CurText = %CurText @ $Dune_Text_Rifle;
		%num+=%Amt;
	}		
	if(%mgun)
	{
		%CurText = %CurText @ $Dune_Text_Mgun;
		%num+=%Amt;
	}		
	if(%sniper)
	{
		%CurText = %CurText @ $Dune_Text_Sniper;
		%num+=%Amt;
	}		
	if(%cutteray)
	{
		%CurText = %CurText @ $Dune_Text_Cutteray;
		%num+=%Amt;
	}		
	if(%smalllas)
	{
		%CurText = %CurText @ $Dune_Text_SmallLas;
		%num+=%Amt;
	}		
	if(%riflelas)
	{
		%CurText = %CurText @ $Dune_Text_RifleLas;
		%num+=%Amt;
	}		
	if(%heavylas)
	{
		%CurText = %CurText @ $Dune_Text_HeavyLas;
		%num+=%Amt;
	}		
	if(%rlauncher)
	{
		%CurText = %CurText @ $Dune_Text_RLauncher;
		%num+=%Amt;
	}		
	
	$Dune_Cur_Text = %curText;
	Control::setValue("Clip_Header", $Dune_Cur_Text);
	Control::SetVisible("Clip_Header",true);
	schedule("Dune_Update();",1);
}

function Dune_KillHud()
{
	deleteObject($Dune_Hud_Clip_Container);
	deleteObject($Dune_Hud_Header);
	dune_killall();
}


function Dune_KillAll()
{
%ngs = nameToId("NamedGuiSet\\PlayGUI");
%len = Group::objectCount(%ngs);
for(%i = 0; %i < %len; %i++)
  {
  %obj = Group::getObject(%ngs, %i);
  %objectName=Object::getName(%obj);
  if(String::findSubStr(%objectName, "Clip_") != -1)
    deleteObject(%obj);
  }
%ngs = nameToId("NamedGuiSet");
%len = Group::objectCount(%ngs);
for(%i = 0; %i < %len; %i++)
  {
  %obj = Group::getObject(%ngs, %i);
  %objectName=Object::getName(%obj);
  if(String::findSubStr(%objectName, "Clip_") != -1)
    deleteObject(%obj);
  }
}

if($Dune_Activate_ClipBox)
	schedule("dune_Setuphud();",10);
