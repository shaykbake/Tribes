These maps were made to be used with the DUNE mod. Use with any other mod may require adjustments.

INSTALATION:

If you have installed the client pack for DUNE, 
then simply place these maps in the tribes/DUNE/Missions folder, and you should be ready to go.

If you have not installed the client pack for DUNE, then go to www.jmods.bravepages.com and dl
the most recent client pack, and follow the second set of instalation instructions.

If you have not installed the client pack for DUNE, and don't want to, but wish to play the new missions on DUNE servers,
then make a new folder in your tribes root directory called DUNE, make a subfolder in it called Missions, and 
place these missions into it. 

For all other use, such as use with another mod, besides changes that may need to be done to the maps
to fit the mod, it should be sufficient to place these in the tribes/base/missions directory.

Use of the files contained this this zip are for the unlimited use of any who download it provided they retain original conception, creation
and all other due credit to me, the maker, Your Lord and Savior, Jesus. (This includes any heavily modified versions)


ENJOY!