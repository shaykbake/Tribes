Server::SetTeams("HA","HH");
