         DeltaForce v1.0
A Server-Side Modification for Starsiege: Tribes
==================================================

Contents:

I.   What is DeltaForce?
II.  Running DeltaForce on your Server
III. FAQ
IV.  Credits
V.   About the Team
VI.  Disclaimer

==================================================

I.     What is DeltaForce?

    DeltaForce is a server-side modification for the multiplayer game Starsiege: Tribes. When a modification is server-side, that means that the players themselves don't have to download anything; only the server admins who want to run the mod on their server are required to do this.

    The mod itself is a departure from the usual Tribes fare. While there are some notable exceptions, most of the other server-side modifications focus on creating bigger and better weapons. I set out to create a mod that not only adds some fresh elements to Tribes play, but also adds a dash of realism. I have not only added all new weapons and vehicles based on real-world equivalents, but I have also made many changes to basic Tribes gameplay. The jet pack has been entirely eliminated, keeping with my objective to make a somewhat realistic infantry combat game. Certain vehicles now have turrets which passengers can mount, encouraging teamwork between vehicle teams. In addition, there are several vehicles can only travel on the ground. Finally, most weapons can kill in only one or two hits, which requires players to be a little more cautious.

Here's a brief description of the various aspects of the DeltaForce mod:

 - Armor Classes -

Army Engineer - The backbone of any platoon, these hard working grunts build the static defenses and logistical infrastructure of the army. No team is complete without a squad of skilled engineers. 

Artillery - While many might say that this weak, fast unit avoided front-line duty by opting for the artillery corps, every grunt will grudgingly admit that the fire support he provides is an essential part of every assault. He is the only class able to control the Howitzer.

Infantry - Your typical grunt. He has an average amount of body armor, runs at an average speed and is able to be outfitted with a number of different primary weapons, making this class the most versatile. 

Medic - The kinder, gentler side of an infantry platoon. However, while the medic's fighting abilities are limited, more than one veteran owes his life to a valiant combat doc.

Pilot - While this class is considered the maverick of the platoon, no soldier would want to go into battle without experienced Pilots at the controls of the air support or in the driver's seat of the mechanized units. This is the only class that can control vehicles.

Sniper - The enigmatic sniper is essential to the success of any platoon. This is the only class able to mount the two types of sniper rifles of the game. He is lightly armored, but fairly quick. 

SpecOps - Members of the elite SpecOps force attached to a platoon are considered the best of the best. Experts at infiltration and sabotage, they carry silenced weapons and have access to the special weaponry, such as airstrike packs and explosive charges. 

 - Weapons - 

SOCOM Pistol - The preferred sidearm of many special forces units. It has high stopping power, but a low fire rate and ammo capacity, making it more of a weapon of last resort. 

OICW Rifle - The OICW is a standard assault rifle. It has good stopping power and a fairly high fire rate, combined with good accuracy at both short and medium ranges. 

M249 SAW - The M249 SAW is an infantry support light machine gun. It isn't as accurate as the OICW and its bullets don't have quite the stopping power, but it does have an insanely fast fire rate. 

Silenced MP5 - The MP5 is a sub-machine gun designed for use in close quarters. It is somewhat inaccurate at any range beyond short, but it is completely silenced, allowing a commando to kill without alerting nearby enemies to his presence. It can be set to either fire single shots or three-shot bursts.

SPAS-12 Automatic Shotgun - The SPAS-12 is an automatic shotgun. It can be loaded with either flechette or slug rounds, and is extremely effective at close range.

PSG-1 Sniper Rifle - The PSG-1 is a semi-automatic sniper rifle. It has an exceptional rate of fire for a sniper rifle and carries a good amount of ammo, but is less accurate and less powerful than its counterpart, the Robar. 

Robar .50 Sniper Rifle - The Robar is a bolt-action sniper rifle. It has incredible stopping power, accuracy, and range. Its disadvantages lie with its low ammo capacity and slow firing rate. 

Flamethrower - The Flamethrower, banned by many treaty organizations because of its horrible brutality, has recently become more popular because of its ability to clear out enemy strongpoints very quickly.

LAW - The LAW (Light Anti-tank Weapon) is a shoulder-fired rocket launcher. It is good at stopping enemy ground vehicles and clearing out bunkers, but it carries little ammo and fires very slowly. 

Stinger - The Stinger is a man-portable SAM (Surface-to-Air Missile) Launcher that fires a small yet powerful heat-seeking warhead. It will not fire unless it is locked on to a valid target, so it is useless against all other targets besides aircraft.

Grenade - A standard frag grenade. Pull the pin, throw, and wait for the screams to stop. It can also be set to emit smoke.

 - Vehicles - 

M1A1 Abrams Tank - The M1A1 Abrams is a standard three-man battle tank. The passenger on the left side of the vehicle automatically mounts the 105mm main turret gun while the one on the right uses the anti-personnel machine gun. The Abrams is completely impervious to small arms fire. 

HMMWV - The HMMWV "Hummer" is a fast scout vehicle used for anti-tank operations and forward recon. It is mounted with a TOW Launcher and an MK-19 Auto Grenade Launcher.

M113 APC - The M113 is a five-man transport tank. It does not have any mounted guns, though passengers can shoot out of it. It is completely invulnerable to small arms fire. 

NOTE: Neither the Abrams, HMMWV, or M113 can fly; they are ground vehicles only. 

Apache - The Apache is a lightly-armored fast-attack VTOL craft that mounts a 20mm chaingun and Hellfire and Sidewinder missiles.

A-10 Warthog - The A-10 Warthog is an extremely durable aircraft that serves primarily in an anti-tank role. It carries a 30mm cannon, Hellfire missiles, and several Mk-82 bombs.

Blackhawk - The Blackhawk is a three-man VTOL craft that doubles as a personnel carrier and a gunship. Each passenger automatically mounts a minigun while on the vehicle which they can use to attack targets of opportunity on the ground. 

 - Packs - 

Parachute - The best friend of the airborne infantry, this little backpack is the only thing that turns a terrifying plunge to earth into a gentle gliding descent.

Airstrike - A small laser target designator which the user points at a target for 15 seconds, at which point friendly high-altitude bombers drop a little high-explosive care package down on the designated location. 

Reloader - The Reloader is used to reload turrets and vehicles when they have exhausted their ammunition supply.

Grappling Hook - The Grappling Hook is the tool of choice for quickly scaling large obstacles and entering structures covertly.

Medikit - The Medikit is the medic's primary tool. In skilled hands, it can quickly patch up wounded soldiers.  

Repair Toolkit - The Repair Toolkit is an all-purpose device that can repair damage to mechanical items such as stations, vehicles, and turrets.

Radar Jammer Pack - The faithful companion of a SpecOps soldier. It uses, on a miniature scale, the same technology that stealth fighters use to conceal themselves from enemy radar. 

Ammo Pack - As low-tech as you can get. An extra satchel full o' ammo. 

 - Deployables - 

SAM Launcher - This computer-controlled turret locks on to enemy aircraft and fires high-velocity heat-seeking missiles at them. 

20mm Cannon Turret - This turret fires 20mm shells at incoming enemy soldiers. It can only be controlled manually.

AA Flak Gun - An anti-aircraft turret that fires shells packed with flechette, preset to explode at a certain altitude.

Machine Gun - A small machine gun that automatically tracks and fires at nearby enemies. 

Howitzer - The Howitzer is an artillery piece that lobs 120mm High-Explosive shells long distances to their targets.

Portable Generator - The Portable Generator, when placed in close proximity to stations, can provide a secondary source of power in case of failure in the primary generators.

Explosive Charge - A small package of plastique that can be placed on walls. It has a timer set for 10 seconds. If the timer is destroyed, the explosive is useless. 

Mine - A small burrowing proximity mine that detonates when enemy soldiers or vehicles approach. It has a small reciever that detects friendly transponders, allowing friendly units to traverse them with impunity. 

Radar Sensor - A minature version of the radar tower. 

Motion Sensor - Tracks nearby enemy movements. 

Camera - A small hidden camera that can be planted inside enemy strongholds in order to remotely view them.

Deployable Radar Jammer - The Deployable Radar Jammer detects incoming enemy radar signals and then generates inverse waves to nullify them.

Deployable Inventory Station - When your troops need to be able to change roles quickly near the front lines, slap down one of these near them. 

Deployable Ammo Station - Keep your troops well-supplied and healthy with one of these.

Deployable Medical Station - When a medic can't attend personally to every wounded soldier on the field, he places down one of these miracles of modern technology. Within seconds, a grunt on the brink of death can be ready to fight once again.

 - New Gameplay Types -

Hostage - Several AI hostages are hidden within buildings on the map. Each team's objective is to capture the hostages and hold them for as long as possible to gain points.

Assassination - One team has to escort a VIP to an escape point on the other side of the map. The enemy team must kill him.


II.     Running DeltaForce on your Server

    Making a DeltaForce server is slightly more complicated than creating a normal Tribes server, so please read the following carefully. 

    For your convienence, we have provided two batch files which you can use to get your DeltaForce server up and running as quickly as possible. The first is "DeltaForce Dedicated.bat", which will start up a dedicated server using InfiniteSpawn (in case the game crashes). The other is "DeltaForce Listen.bat", which will run Tribes using the DeltaForce mod so that you can start a listen server.

    Since DeltaForce disables jet packs, most Tribes maps will not work with the mod as they assume the player to have this capability. Maps made specifically for DeltaForce will have a number of ramps and elevators to allow access to every part of the map, and will normally contain the prefix DF_ in their title. Make sure that only DeltaForce-certified missions are in your mission loop.  However, as long as you don't have non-Deltaforce missions in your automatic mission loop, you have nothing to worry about. The game is set up so that players can only vote for DeltaForce-certified missions. 

    Certain aspects of the game can be customized by the server admin. The first is the method by which ground vehicles are simulated. The default method is extremely accurate, but may cause lag. If this begins to happen, you can use a less accurate physics model for the vehicles, which should improve the situation. To do so, add the following line verbatim to ServerPrefs.cs in your Tribes\config directory:

$Server::FuzzyPhysics = true;

    The last aspect is the amount of time for which the smoke grenade is active. It is set by default for 8 seconds, but you can change this if users are abusing them or if they are causing lag. Add the following line to ServerPrefs.cs:

$Server::SmokePuffs = <number>;

and instead of <number>, substitute the number of seconds you want the grenade to be active for.

    If you have any questions or comments, please let me know at nmusurca@mindspring.com.


III.     FAQ

    This is a compilation of the most common questions I recieved while testing my mod over my server. 

Q: WTF??? My jet pack doesn't work! 
A: This is a realistic mod, attempting to approximate real-world infantry combat. I felt a jet pack would kinda screw that up.
 
Q: How the hell am I supposed to get out of my base, then? 
A: Use the elevator. This is why most normal Tribes maps don't work with DeltaForce; they all assume that the user has a jet pack. The custom maps we have created for this mod (all server-side, so don't worry about having to download anything) all contain elevators and ramps to reach high places. 

Q: The Abrams, M113, and Humvee won't fly! 
A: They're ground vehicles only. 

Q: The ground vehicles keep stopping on rough terrain. What am I doing wrong? 
A: Nothing. The Tribes engine intended these things to fly, and it was sort of a hack removing that ability. They work, after a fashion, but controlling them can be a tad aggravating.

Q: Why aren't my turrets firing automatically? 
A: Certain turrets, like the 20mm Cannon and the Howitzer, must be controlled manually to fire.

Q: What does the Airstrike do? 
A: You fire it at a target for 15 seconds, and a bomb gets dropped on it.
 
Q: I'm having a problem with the Airstrike... 
A: The most common problem with this device is that it is often activated while moving. You must be standing still for the entire 15 seconds in order for the strike to be successful.

Q: Wanna cyber? 
A: No. 

Q: Hey...all of your weapons still look like the Tribes guns! And the vehicles look the same, too! What the hell are you trying to pull? 
A: This is a server-side mod. That means that only the server admin has to download anything; the player just has to connect to the server. If I added all new models and skins for the weapons, vehicles, and people, the player would have to download about a 15 MB file before he could play. Besides that, I have absolutely no artistic skill whatsoever. =) If you want the game to have more of the feel of real-world combat, you can download the optional client-side pack from our web site, which adds new weapon models and, courtesy of the Ultra Renegades team, cool camoflauge skins over stations, turrets, weapons, vehicles, and people.

Q: Can I join the development team for this mod? (okay, so this wasn't exactly a commonly asked question) 
A: We're looking to improve the look of our optional client pack, so if you're a talented skinner or modeler, we'd love to have you aboard. Also, we always need new beta testers. Otherwise, we're not interested. Sorry. :) 

Q: Your logo looks suspiciously like the Tribes logo and NovaLogic's DeltaForce logo spliced together.
A: Heh...er...that's odd.


IV.     Credits

    First of all, we'd like to thank the developers of Renegades (http://www.planetstarsiege.com/renegades/) and Insomniax (http://www.insomniax.net/mods/). We'd be lying if we said we didn't borrow a few ideas from their code; however, we only did it after being unable to do a similiar thing on our own. 99% of DeltaForce was written entirely alone, but we did come across a few issues which were easier to solve by looking at how others had done it (especially with turrets). We'd also like to thank -=$uck-IT=- and Virus, the creators of Tribes Descrambler, for creating a great program that assisted us during our sojourns through the Renegades/Insomniax code. 

    Second, we'd like to thank the many people who played DeltaForce during its alpha and beta testing period. They dealt with crashes, bugs, and lag, yet still ended up giving us innumerable helpful suggestions. 

    Third, we'd like to thank the people at Red Storm Entertainment and NovaLogic for creating such cool games and for inspiring us to create this mod. 

    Fourth, we'd like to thank Hosed, for providing the code for the ground vehicles and taking the time to explain how it worked. :) Credits also go out to Ice for the collaboration on the Parachute code and to tenabrae of Trinity Armaments for creating the models that are used in our client-side pack. 

    Finally, Enigma would like to thank his @$$hole friends, whose only contribution, "You'll never finish it!", served as an impetus to complete this mod. He would also like to flame the sadistic slave-drivers at his anonymous private high-school, without whose intervention this mod would have been released a number of months ago.

    Some of you may notice a resemblance between this mod and the total conversion Screaming Fist. We did not rip any ideas/scripts from them; indeed, we didn't even know their mod existed until they released their first public beta. The gameplay involved in both our respective mods is actually quite different; you can check it out at http://sf.tribalwar.com.
� � �
	-The DeltaForce Team


V.      About the Team

DeltaForce is:

-Nick "Enigma" Musurca (nmusurca@mindspring.com)
Programmer

-Ron "Thrax-THC-" Freas (thrax@whoever.com)
Offical Cartographer / Designer

Leland "TheLelander" Price (thelelander@mindspring.com)
Web Graphics


VI.     Disclaimer

    If for some reason my mod or any part thereof causes your computer to start smoking and hanging out with the wrong crowd, or causes your spouse to start speaking in strange tongues and writing on the walls in their own blood, or otherwise damages any part of your person or property, it's not my fault.

   Anyway, now that that's over with, enjoy DeltaForce!

========================================================