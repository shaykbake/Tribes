DF_MissionPack.txt      1/28/2001

  This archive contains the latest release of mission/maps designed exclusively for use with the Delta Force Tribes Modification. While none of these maps are perfect, a great deal of care and attention to detail in producing the DF_Missions has been taken to ensure balance and maximum playability.

--- DONOT ATTEMPT TO USE STANDARD TRIBES MAPS WITH THE DELTA FORCE MODIFICATION --- 

  Installation is straight forward. Place all the mission files within the Tribes\deltaforce\missions directory. Installation also requires the stock Dynamix, Balanced, and OpenCall .ted and .vol files <leave them in the Tribes\base\missions dir> be present for the DF_Missions to function properly, as the DF_Maps are built upon existing server side terrain. No custom .ted files exist.  ...yet.  ;) 
  Future upgrades, bug fixes and new missions will be contained and released in a single DF_MissionUPGRADEpack, eliminating the need to selectively install individual files. 
  Bug reports and suggestions can be addressed to the Delta Force mailing list: 
deltaforce_test@lyris.gamespy.com 
Directly to: thrax@whoever.com
please visit http://www.planetstarsiege.com/deltaforce/  
and http://www.planetstarsiege.com/deltaforce/beta  for more information.
List and notes compiled by Thrax-THC-
If there is a Tribes mission/map that you would like to see converted, built from scratch or would like to submit for review, please contact above..
  
  Mod and maps tested on an Athlon750, 128 meg ram, Nvidia GeForce 256, Windows '98, Tribes v1.11, DeltaForceMod v0.9b5   with no clientside scripts running.
------------------------------------------------------------------------

Mission/map general update news.   12/10/2000  

  1. Most all of the mission/maps have gone through some major changes resulting from public playtesting on the Official delta Force Tribes server. Some mission/maps have been pulled from the MissionListing and are being redesigned. Before installing this update, DELETE ALL of DF_Missions.
  2. Problem fixed with the item restrictions not resetting from mission to mission. Any mission/maps previous to this release are to be eliminated and replaced with the maps contained within this release. This release is NOT compatable with v0.9b4  Compatable with DeltaForceTribes v0.9b5 
  3. Mission Briefing displayed with bottom-printed text during mission start countdown. This fixes the "blank" Mission Briefing screen when "Esc" key is pressed. Countdown time has been modified to accomodate Mission Briefing times. Now there will be no excuse for players not knowing what the mission objectives are.



  Mission listing as of 12/0/2000

  1. DF_Ambushed  v0.1  12/10/00  Fire Fight, Find and Retrive
  2. DF_Annihilator  v0.7  12/3/00  Capture and Hold
  3. DF_BridgeTooFar  v0.5 12/05/00  VIP Assassination
  4. DF_CanyonCrusher  v0.6  12/5/00  Capture the Flag
  5. DF_Citadels  v0.3  12/10/00  Capture and Hold
  6. DF_DamnnationAlley  v0.3  12/10/00  Capture the Flag
  7. DF_FailedNegotiations   v0.5  12/10/00  Hostage Rescue, Capture and Hold
  8. DF_GutterClaw   v0.1  12/10/00  Hostage, Find and Retrieve, Capture and Hold 
  9. DF_JaggedTooth   v0.1  12/10/00  Fire Fight
 10. DF_JaggedToothII   v0.1  12/10/00  Fire Fight
 11. DF_PorkchopHill   v0.5  12/10/00  Capture and Hold
 12. DF_ReignDeath   v1.6  12/10/00  Capture the Flag


  Discription listing:

  1. Mission/map-version/date-type
  2. Original/altered/based on using Required .ted and .vol files
  3. Short description.
  4. Changes from previous "Conversion".
  5. Known problems with possible workarounds.


  Mission Descriptions:

  1. DF_Ambushed  v0.2  1/28/01  Fire Fight, Find and Retrive
  2. Original mission using Peekaboo.
  3. One team must take the flag to the stand while the second team prevents them from completing the objective.
  4. New mission/map.  Removed Tournament start.
  5. A bit of frame lag from the mass amount of trees and rocks might occur on "weaker" machines. Known fix: Get a faster machine.  :)

  1. DF_Annihilator  v0.7  12/3/00  Capture and Hold
  2. Altered version of Balanced map Annihilator.
  3. Both teams have all available resources to fight for control over an arid desert waterwell.
  4. Added "pipeline" dividing misson area. Placed blast doors of front of supply bunker. Refined power supply. Added roof, AAFlak, Supply Station to "block building". Moved starting positions to objective area. Moved spawn points closer into base compound. Added spawn points to objective area switch.
  5. Along the outside edges of the mission area is a small cliff; players will pass through the terrain into "oblivion". No known FIX for this problem except to stay within the mission boundries.

  1. DF_BridgeTooFar v0.6 1/28/01  VIP Assasination
  2. Original mission/map using Open Call map CanyonCrusade.
  3. Escort VIP through enemy territory to disable ICBM.
  4. Many changes and tweaks. Moved aircraft and created a marked dropzone north over the hill into a small valley.  Three cargo boxes containing infantry based weapons, ammo and "supplies" dropped to aid the team. Removed lookout/radar bunker, replaced it with a small outpost on edge of ridge near DZ. I belive this setup will give the advance team a choice of weapons beyond the infantry spawn setup.  Tweaked object placement, seperated all bunkers and associated items into seperated directorys. Removed blocks in canyon. Moved and elevated ICBM silo, relocated switch towers. Removed Tournament start.
  5. Currently no known problems. The defending team has the advantage. Needs some serious playtesting.

  1. DF_CanyonCrusher  v0.6  12/5/00  Capture the Flag
  2. Altered version of Open Call map CanyonCrusade.
  3. Both teams have all available resources to fight for the capture of the enemy flag.
  4. Moved Start Points to centeral canyon around Bonus Flag. Moved Spawn points closer to Inventory Stations. Rearranged blocks in central canyon. Altered Vehicle Depot. Added Mine fields near second canyon enterance. Added "Blast Doors" to main bunkers. Added Indoor Turret near front of main bunker. Added AAFlak within base compound.
  5. Currently no known problems.

  1. DF_Citadels  v0.3  12/10/00  Capture and Hold
  2. Altered version of Dynamix release map Citadels.
  3. Two teams fight for control of 3 other bases.
  4. Fixed each teams main base blast doors. 
  5. Currently no known problems. Except for the slow and eratic movement of ground based vehicles over the moderately rolling terrain. Large map requiring many players with multiple squads per team. This idea needs to be explored further and maybe compacted down a little.

  1. DF_DamnnationAlley  v0.3  12/10/00  Capture the Flag
  2. Altered version of Open Call map MidnightMayhem.  
  3. Two teams battle for flag captures in a deeply ravined terrain.
  4. Added missing radar units. Added Stinger to weapons cache. Added AAFlak. Fixed a terrain morphing problem when running display in software mode.
  5. Currently no known problems.

  1. DF_FailedNegotiations  v0.5  12/10/00  Hostage Rescue/Capture and Hold
  2. Original mission/map using OpenCall Spartacus'Gauntlet.
  3. Offense team must rescue hostages, capture facility, and eliminate terrorist.
  4. Major revisions for this version.  Flamethrower removed to help resolve frame rate slowdown while fighting within the building areas. Besides, who wants fire in a chemicals facility anyway.   :)   Reduced mission area by eliminating the DF base and replaced it with the killer-bitchin troop transport aircraft than Enigma built for DF_BridgeTooFar. Added a couple vehicles for the terroist and a vehicle depot for ground units for the DF team.  Eliminated unnessecary items from inventory station. 
  5. Framerate slowdown in various areas of facility. Quite annoying, but should not affect game play. 

  1. DF_GutterClaw  v0.1  12/10/00  Hostage, Find and Retrive, Capture and Hold 
  2. Original mission/map using Peekaboo.
  3. Two teams fight for control of a Hostage, two flags and an objective.
  4. New Mission/Map.
  5. Currently no known problems. 

  1. DF_JaggedTooth and DF_JaggedToothII  v0.2  1/28/01  Fire Fight
  2. Original mission/map using LuckySeven.
  3. Fire Fight in a small canyon pass.
  4. New Maps.  Teams swap sides in second version. Removed Tournament start.
  5. Currently no known problems. 

  1. DF_PorkchopHill  v0.5  12/10/00  Capture and Hold
  2. Original mission built on Dynamix release map Broadside.
  3. Two teams fight for control of a stratigic hill located within a battle torn region.
  4. Enlarged mission area for airborne units.  Moved Start Points onto the hill around the Objective.  Moved Spawn Points closer to base.
  5. Currently no known bugs.

  1. DF_ReignDeath  v1.6  12/10/00  Capture the Flag
  2. Altered mission/map based on Dynamix release map Raindance.
  3. Two teams battle for flag captures and control of the bridge.
  4. Addition of spawn points to lessen the possibility of becoming isolated in the main base during a power failure. Enlarged mission area. Trees added.  Start Points moved to Bridge area objective.
  5.  Main feature is the flag not retuning to base upon dropping. THIS IS NOT A BUG !!!   However, once dropped out of bounds captured flag cannot be picked back up by capturing team.   Workaround: If dropped out of bounds, guard it with your life.




 Mission/Maps that haave been pulled for alterations:

  1. DF_Hostages
  2. DF_Siege

  1. DF_Hostages  v0.1  Hostage Rescue
  2. Altered mission/map based on Dynamix release map Scarabrae.
  3. Two teams must rescue hostages located in buildings near center of map.
  4. No changes to this version.   ...yet.
  5. Tough to get around main base.  This mission needs an overhaul.

  1. DF_Siege  v0.2  8/30/00  Defend and Destroy
  2. Altered map based on Dynamix release map Siege.
  3. Defend your base. Destroy enemy base. Simple eh?
  4. Enlarged mission area.  Fixed some elevators.
  5. Tough to get around main base.  This mission needs an overhaul.

