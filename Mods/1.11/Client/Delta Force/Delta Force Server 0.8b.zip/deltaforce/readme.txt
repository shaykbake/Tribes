              DeltaForce v0.8b
A Server-Side Modification for Starsiege: Tribes
==================================================

Contents:

I.   What is DeltaForce?
II.  Running DeltaForce on your Server
III. FAQ
IV.  Credits
V.   Disclaimer

==================================================

I.     What is DeltaForce?

    DeltaForce is a server-side modification for the multiplayer game Starsiege: Tribes. When a modification is server-side, that means that the actual players don't have to download anything; only the server admins who want to run the mod on their server are required to do this.

    The mod itself is a departure from the usual fare of Tribes mods. While there are some notable exceptions, most of the others focus on creating bigger and better weapons. I set out to create a mod that not only adds some fresh elements to Tribes play, but also adds a dash of realism. I have not only added all new weapons and vehicles based on real-world equivalents, but I have also made some changes to Tribes gameplay. The jet pack has been entirely eliminated, keeping with my objective to make a somewhat realistic infantry combat game. Certain vehicles now have turrets which passengers can mount, encouraging teamwork between vehicle teams. In addition, certain vehicles can only travel on the ground. Finally, most weapons can kill in only one or two hits, which requires players to be a little more cautious.

Here's a brief description of the various aspects of the DeltaForce mod:

 - Armor Classes -

Infantry - Your typical grunt. He has an average amount of body armor, runs at an average speed and is able to be outfitted with a number of different primary weapons, making this class the most versatile. 

Sniper - The enigmatic sniper is essential to the success of any platoon. This is the only class able to mount the two types of sniper rifles of the game. He is lightly armored, but fairly quick. 

SpecOps - Members of the elite SpecOps force attached to a platoon are considered the best of the best. Experts at infiltration and sabotage, they carry silenced weapons and have access to the special weaponry, such as airstrike packs and explosive charges. 

Army Engineer - The backbone of any platoon, these hard working grunts build the static defenses and logistical infrastructure of the army. No team is complete without a squad of skilled engineers. 

Pilot - While this class is considered the maverick of the platoon, no soldier would want to go into battle without experienced Pilots at the controls of the air support or in the driver's seat of the mechanized units. This is the only class that can control vehicles.

Artillery - These slow moving soldiers control a mobile Howitzer, and are able to rain explosive death upon their enemies. Every offensive should be supported by these behemoths. However, they are relatively lightly armored and should be protected diligently. 

 - Weapons - 

SOCOM Pistol - The preferred sidearm of many special forces units. It has high stopping power, but a low fire rate and ammo capacity, making it more of a weapon of last resort. 

OICW Rifle - The OICW is a standard assault rifle. It has good stopping power and a fairly high fire rate, combined with good accuracy at both short and medium ranges. 

M249 SAW - The M249 SAW is an infantry support light machine gun. It isn't as accurate as the OICW and its bullets don't have quite the stopping power, but it does have an insanely fast fire rate. 

Silenced MP5 - The MP5 is a sub-machine gun designed for use in close quarters. It is somewhat inaccurate at any range beyond short, but it is completely silenced, allowing a commando to kill without alerting nearby enemies to his presence. 

PSG-1 Sniper Rifle - The PSG-1 is a semi-automatic sniper rifle. It has an exceptional rate of fire for a sniper rifle and carries a good amount of ammo, but is less accurate and less powerful than its counterpart, the Robar. 

Robar .50 Sniper Rifle - The Robar is a bolt-action sniper rifle. It has incredible stopping power, accuracy, and range. Its disadvantages lie with its low ammo capacity and slow firing rate. 

LAW - The LAW (Light Anti-tank Weapon) is a shoulder-fired rocket launcher. It is good at stopping enemy ground vehicles and clearing out bunkers, but it carries little ammo and fires very slowly. 

Howitzer - The Howitzer is an artillery piece that lobs 120mm High-Explosive shells long distances to their targets. 'Nuff said. ;) 

Grenade - A standard frag grenade. Pull the pin, throw, and wait for the screams to stop. 

 - Vehicles - 

M1A1 Abrams Tank - The M1A1 Abrams is a standard three-man battle tank. The passenger on the left side of the vehicle automatically mounts the 105mm main turret gun while the one on the right uses the anti-personnel machine gun. The Abrams is completely impervious to small arms fire. 

M113 APC - The M113 is a five-man transport tank. It does not have any mounted guns, though passengers can shoot out of it. It is completely invulnerable to small arms fire. 

NOTE: Neither the tank nor the APC can fly; they are ground vehicles only. 

Apache - The Apache is a lightly-armored fast-attack VTOL craft that fires unguided rockets. The rockets do only a medium amount of damage, but they fire extremely quickly. 

Blackhawk - The Blackhawk is a three-man VTOL craft that doubles as a personnel carrier and a gunship. Each passenger automatically mounts a minigun while on the vehicle which they can use to attack targets of opportunity on the ground. 

 - Packs - 

Airstrike - A small laser target designator which the user points at a target for 15 seconds, at which point friendly high-altitude bombers drop a little high-explosive care package down to the designated location. 

Medikit - Most soldiers opt to carry the medikit with them into battle, which can be used to heal wounds during lulls in combat. 

Radar Jammer Pack - The faithful companion of a SpecOps soldier. It uses, on a miniature scale, the same technology that stealth fighters use to conceal themselves from enemy radar. 

Ammo Pack - As low-tech as you can get. An extra satchel full o' ammo. 

 - Deployables - 

SAM Launcher - This computer-controlled turret locks on to enemy aircraft and fires high-velocity heat-seeking missiles at them. 

20mm Cannon Turret - This turret fires 20mm shells at incoming enemy soldiers. It can only be controlled manually. 

Machine Gun - A small machine gun that automatically tracks and fires at nearby enemies. 

Howitzer Turret - A static version of the mobile 120mm artillery piece. It can only be controlled manually. 

Explosive Charge - A small package of plastique that can be placed on walls. It has a timer set for 10 seconds. If the timer is destroyed, the explosive is useless. 

Mine - A small burrowing proximity mine that detonates when enemy soldiers or vehicles approach. It has a small reciever that detects friendly transponders, allowing friendly units to traverse them with impunity. 

Radar Sensor - A minature version of the radar tower. 

Motion Sensor - Tracks nearby enemy movements. 

Deployable Inventory Station - When your troops need to be able to change roles quickly near the front lines, slap down one of these near them. 

Deployable Ammo Station - Keep your troops well-supplied and healthy with one of these.

 - New Gameplay Types -

Hostage - Several AI hostages are hidden within buildings on the map. Each team's objective is to capture the hostages and hold them for as long as possible to gain points. 


II.     Running DeltaForce on your Server

    Making a DeltaForce server is slightly more complicated than creating a normal Tribes server, so please read the following carefully. Since DeltaForce disables jet packs, most Tribes maps will not work with the mod as they assume the player to have this capability. Maps made specifically for DeltaForce will have a number of ramps and elevators to allow access to every part of the map, and will normally contain the prefix DF_ in their title. Make sure that only DeltaForce-certified missions are in your mission loop. 

    Since players sometimes vote to change the mission to a map not in your mission loop, I have included two utilities, df_prep and df_restore, to insure against this occurence (or, if you're feeling despotic, you can just prevent them from voting ;). These two batch files should have been unzipped into your \dynamix\tribes\base\missions directory; if not, copy them to that directory now. Before you run your DeltaForce server, run df_prep, which will move all of the missions in this directory to a temp directory. Then, run your DeltaForce server using the missions in the /tribes/deltaforce/missions directory. After you've shut the server down, run df_restore to return all of the normal Tribes missions to their rightful place.

    If you have any problems or comments about the mod, please let me know at nmusurca@bellatlantic.net.

III.     FAQ

    This is a compilation of the most common questions I recieved while testing my mod over my server. 

Q: WTF??? My jet pack doesn't work! 
A: This is a realistic mod, attempting to approximate real-world infantry combat. I felt a jet pack would kinda screw that up.
 
Q: How the hell am I supposed to get out of my base, then? 
A: Use the elevator. This is why most normal Tribes maps don't work with DeltaForce; they all assume that the user has a jet pack. The custom maps I have created for this mod (all server-side, so don't worry about having to download anything) all contain elevators and ramps to reach high places. 

Q: The Abrams and the Bradley vehicles won't fly! 
A: They're ground vehicles only. 

Q: The ground vehicles keep stopping on rough terrain. What am I doing wrong? 
A: Nothing. The Tribes engine intended these things to fly, and it was sort of a hack removing that ability. They work, after a fashion, but controlling them can be a tad aggravating. If anyone can give me some tips on fixing this, I'll put their name in flashing characters on the credits page. =)

Q: I drove one of the ground vehicles off a cliff and it flew into the air! I could fly it around the enemy's base! WTF?
A: Yet another bug. For some reason, if you get up enough speed and launch a vehicle from a sufficent height, you can fly it around for a bit. I'm still working on fixing this one.

Q: Why aren't my turrets firing automatically? 
A: Certain turrets, like the 20mm Cannon and the Howitzer, must be controlled manually to fire. The rest will fire automatically. 

Q: What does the Airstrike do? 
A: You fire it at a target for 15 seconds, and a bomb gets dropped on it.
 
Q: I'm having a problem with the Airstrike... 
A: I'm not surprised. The Airstrike is still very buggy, though it is basically functional. I considered taking it out from this release until it was perfected, but then I figured it was just too cool to leave out. It won't crash the server or anything, but it might not work sometimes. 

Q: Wanna cyber? 
A: No. 

Q: Hey...all of your weapons still look like the Tribes guns! And the vehicles look the same, too! What the hell are you trying to pull? 
A: This is a server-side mod. That means that only the server admin has to download anything; the player just has to connect to the server. If I added all new models and skins for the weapons, vehicles, and people, the player would have to download about a 15 MB file before he could play. Besides that, I have absolutely no artistic skill whatsoever. =) If you want the game to have more of the feel of real-world combat, you can download the URG skin pack, which puts cool camoflauge skins over stations, turrets, weapons, vehicles, and people, courtesy of the Ultra Renegades team. If you want to play a client-side real-world combat mod, check out Screaming Fist at http://sf.stomped.com.

Q: Can I join the development team for this mod? (okay, so this wasn't exactly a commonly asked question) 
A: I'm probably going to be working on other projects from now on, so I'm not sure if I'm going to release another version. If you've got some scripting skills and you'd like to take over the project, let me know. The mod could also use some more maps (only server-side, please); I'll probably be releasing some map packs for this mod if I get enough submissions. 

Q: Your logo looks suspiciously like the Tribes logo and the logo on the DeltaForce page spliced together. 
A: Heh...er...that's odd.

IV.     Credits

    First of all, I'd like to thank the developers of Renegades (http://www.planetstarsiege.com/renegades/) and Insomniax (http://www.insomniax.net/mods/). I'd be lying if I said I didn't borrow a few ideas from their code; however, I only did it after being unable to do a similiar thing on my own. 95% of DeltaForce was written entirely alone, but I did come across a few issues which were easier to solve by looking at how others had done it (especially with turrets). Secondly, I'd like to thank -=$uck-IT=- and Virus, the creators of Tribes Descrambler, for creating a great program that assisted me during my sojourns through the Renegades/Insomniax code. Thirdly, I'd like to thank the many people who played DeltaForce during its alpha testing period on my DSL server. They dealt with crashes, bugs, and lag, yet still ended up giving me a number of helpful suggestions. Fourth, I'd like to thank the people at Red Storm Entertainment and Novalogic for creating such cool games and for inspiring me to create this mod. Fifth, I'd like to thank my @$$hole friends, whose only contribution, "You'll never finish it!", served as an impetus to complete this mod. Finally, I'd like to flame the sadistic slave-drivers at my anonymous private high-school, without whose intervention this mod would have been released a number of months ago.

    Some of you may notice a resemblance between this mod and the recently-released client/server-side mod Screaming Fist. I did not rip any ideas/scripts from them; indeed, I didn't even know their mod existed until they released their first public beta. Actually, since I recently assisted its development team with some scripting, I'd like to take this opportunity to pimp their mod. Check it out at: http://sf.stomped.com.
� � �
	-ATM/NTDF_Enigma

V.     Disclaimer

    If for some reason my mod or any part thereof causes your computer to start smoking and hanging out with the wrong crowd, or causes your spouse to start speaking in strange tongues and writing on the walls in their own blood, or otherwise damages any part of your person or property, it's not my fault.

   Anyway, now that that's over with, enjoy DeltaForce!

========================================================