Welcom to the R1 version 1.2 mod Written by Ryan Smith


NEW Models I got from Ultra Renegades 3 Mayhem Mod- have to give credit where its due
------------------------------------------
Installation

Unzip Models.vol to your c:\...\tribes\base\skins
Unzip all .dts files to your C:\...\tribes\base
Unzip the rest of the files into c:\...\tribes\R1
Then right click the tribes icon icon in your tribes directory and select "Create Shortcut"
Then right click the new Icon and select "Properties" and where it says 
c:\...\tribes\tribes.exe
and add -mod R1
so it looks like
c:\...\tribes\tribes.exe -mod R1
------------------------------------------
New Weapons

Energy Cannon- Replaces the blaster though only the heavy armor can handle it it uses an
extreme amount of energy to blast even turrets in one shot when in close enough range no
explosion radius so you have to be accurate.

Plasma Chaingun- Replaces both Plasma gun and chaingun firing plasma bolts at almost 
chaingun speeds. only assult and heavy armors can use it.

Sniper gun- Almost as powerful as the mortar but no explosion radius and VERY accurate
VERY deadly
------------------------------------------
Armors

Flying Armor- Just as it says it can fly it does have limited energy but it isn't used by
the jet pack also its the only armor that can pilot aircraft. Very light also you should 
only use as sniper or pilot or quick attack

Assult Armor- More like the original tribes light Armor but can carry more weapons. usally
used for attack.

Heavy Armor- name says it all it can use all the weapons short of the sniper gun and laser
rifle, it is very slow though (slower than the original) can carry all the weapons it can 
use at the same time too.