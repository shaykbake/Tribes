exec(serverStarCraft);

function serverLink::Start()
{
  serverStarCraft::Start();
}

function serverLink::InitializeMission()
{
  serverStarCraft::InitializeMission();
}