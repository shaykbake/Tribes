For this readme to display properly, you need to hit edit->set 
font and put font on Fixedsys size 9 regular and word wrap needs to be off



Hello boys, girls, and others! Welcome to the Read Me (And please do read it) of the...

				       +--=STARCRAFT MOD=--+
 _______________________________________________________________________________________________
/		 /+_/                           /\                           \_+\               \
|_______________/+/                       _____/()\_____	               \+\______________|
|_=_=_=_=_=_=_=_=\\____________________   \++++\__/++++/   ____________________//=_=_=_=_=_=_=_=|
|              / /=_=_=_=_=_=_=_=_\ __ \  / __/^^^^\__ \  / __ /_=_=_=_=_=_=_=_=\ \             |
|             / * /                \\ \ \/ /  \_/\_/  \ \/ / //		       \ * \    	|
|            / * /                 /\\ \/_/------------\_\/ //\			\ * \		|
|           / * /                 //_\\/)((Version SSC3))(\//_\\		 \ * \ 		|
|          / * /                 /_/  \\_((  Matthias  ))_//  \_\		  \ * \         |
|	  / * / 		///    \++\------------/++/    \\\      	   \ * \ 	|
|	 / * /  	       /_/      \_/\____/\____/\_/ 	\_\		    \ * \       |
|	/ * /	              ///\	   \\   \/   //		/\\\	       	     \ * \      |
|      / * / 	             /_/\_\         \\_/..\_//	       /_/\_\		      \ * \     |
|     / * /		    ///  \_\         \\    //         /_/  \\\		       \ * \	|
|____/ * /      	   /_/    \_\         \\  //         /_/    \_\		      	\ * \___|
|,,,,,,,/        	  ///      \_\         \\//         /_/      \\\		 \,,,,,,|
\________________________/_/________\_\________//\\________/_/________\_\_______________________/

				            By Matthias

Uses source code from Warhammer 40k 1.2b/1.3 (Edgecrusher/Paladin and others)

					TABLE OF CONTENTS

	1.  Welcome
	2.  Credits, Thanks, etc. (Anyone I forget please tell me and I will place your name down)
	3.  Installation
	4.  Ideas In Matthias' Head
	5.  Changes Throughout The Life Of This Mod
	6.  Always Accepting Ideas On The Mod

********************************************************************************************************************************
*Testers- Anyone and everyone who's played this mod.. thanks!         						               *
*Skinner- Ecliptici, Spider												       *
*Mappers- Ecliptici						        				                       *
*Models - Timothy Giovanni, {Rk|Spider}, Raptor197 (AKA CookieMonster), HiVoltage					       *
********************************************************************************************************************************

Uses code setup from Warhammer 40k 1.2b/1.3 (<DC>Edgecrusher/Paladin and others)

I want to thank the War40K team deeply for letting me use their code to get this mod on it's feet, THX!


INSTALLATION OF THIS MOD
------------ -- ---- ---

=================================================================================================
===WARNING:"IF YOU HAVE ALREADY INSTALLED A PREVIOUS VERSION OF STARSIEGECRAFT THEN DELETE THE===
====================STARSIEGECRAFT DIRECTORY BEFORE INSTALLING A NEW VERSION"====================
=================================================================================================
==											       ==
==    1.  Make a SSC3 directory in your main Tribes directory (Spell/cap it right!)    	       ==
==											       ==
==   ---If you have several .cs files and another .ZIP follow these instructions  2-4 ---      ==
==    2.  Unzip the *.cs files of StarSiegeCraft.zip into the SSC3 directory                   ==
==    3.  Create a folder named scripts in the SSC3 folder 				       ==
==    4.  Unzip SSCScripts.zip into that scripts folder					       ==
==					     -=OR=-					       ==
==           ---If you have a scripts.VOL in the zip file follow these instructions--          ==
==    2.  unzip the scripts.vol into the SSC3 folder                                           ==
=================================================================================================
=================================================================================================
 _____________________________________________________________________________________________________________________________________________
| /_________________________________________________________________________________________________________________________________________\ |
|/|     		 _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _        |\|
|||   /\		/													    \	    |||
|||  //\\______________ |Next, make a shortcut of Tribes.exe, and set its properties as follows:				    |	    |||
||| //__Non-Dedicated__||													    |       |||
||| \\_//========___|   |C:\Dynamix\Tribes\Tribes.exe -mod SSC3 (assuming C:\Dynamix\Tribes is your Tribes root directory)	    |	    |||
| |  \//________|	\_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _/	    |||
_____//_________________ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _					    |||
     \\ 		/									      \					    |||
| |  /\\ 		|If you wish to run a dedicated server, the command line should be as follows:|					    |||
||| //_\\__________	|   ***-dedicated MUsT Be AlL iN lOWeR cASe LetTeRs***			      |					    |||
||| \\__Dedicated__|	|C:\Dynamix\Tribes\Tribes.exe -mod SSC3 -dedicated			      |					    |||
|||  \\//====___|       |This does require additional CPU resources to run a dedicated server.	      |					    |||
|||   \/____|   	\_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _/					    |||
|\|_________________________________________________________________________________________________________________________________________|/|
|_\_________________________________________________________________________________________________________________________________________/_|

And then just run the shortcut, be aware many things can change in the future of this mod...

Any questions, comments, bug reports, and "other" can go to this e-mail emblazoned in glowing
phosphor on your computer screen:




			              Matthias@planetstarsiege.com





The website for this mod is located at

http://www.planetstarsiege.com/ssc

-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

THOUGHTS IN MATTHIAS' BIG HEAD
-------- -- --------- --- ----


You may support, or object to any of these thoughts by e-mailing me


-)(-...


If anyone has ideas, comments, or anything to say about these thoughts, this mod, or anything else please e-mail me at SC_Matthias@hotmail.com


/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\


CHANGES THROUGHOUT THE LIFE OF THIS MOD
------- ---------- --- ---- -- ---- ---
-=+=-1.2

*-Lots new models

*-Added Ion Cannon

*-Added Vespene Laser for Protoss

*-Added Neutron Blast

*-Added Psionic Assault

*-Strengthened the Infested Terran's explosion, slightly

*-Added Medic Armor

*-Added Dark Templar Armor

*-Added Lurker Armor

*-Warning above 3 armors have kick ass beacons/grens/everything!

*-Warp blades for DT cloak DT when using, :)

*-Infused mod with new models, HELL YEA, THANKS TIMMY G!!!!!

*-Redid fission/fusion line of Terran weapons

*-Redid burst laser

*-Redid Shock Cannon

*-Removed Shock Gun

*-Renamed Space Construction Unit to SCV

*-Added Heavy Flamer

*-Removed Heavy Flamer for the Firebat Fuel Pack

*-Redid flamer to burn stuff

*-Turrets faster, but not as much damage

*-Removed sniper mode for Psionic Receptive

*-Redid Penis Cursed armor

*-Removed Targeting Laser

*-Added old gauss rifle

*-Redid Yamato Launcher

*-Upped Gemini Launcher

*-Added Optical Flare, with "blinding", which was my pride of the day :)

*-Added Hypodermic Needles, which poison ppl

*-Redid Irradiation Blast, now fires a random # of projectiles, so it doesn't always do as much damage, but has potential to

*-Psionic storm requires energy, if u dont' have enough energy, nothing happens

*-Warp blades only for DT

*-Added feedback rifle, does more damage depending on how much energy the target has

*-Upped Scarab Cannon, this was severely needed :)

*-New explosion for BattleCruiser

*-Added Broodling Spawn weapon, spawns 2 mines after killing someone :)

*-Upped most of the armor's jetting strength, now they shouldn't feel like ur hauling pounds of lead with you!

*-Removed Arbiter, and added a Corsair again, :)

*-Weakened psi storm and increased radius a bit

*-As always a bunch of stuff that I didnt' list here



-=+=-1.0-1.19

*-Added the attachable grenade launcher to the Gauss Rifle
*-Gave the Gauss Rifle an ammo type
*-Strengthened heavy armor
*-Removed Corsair, and added Wraith
*-Weakened Infested Terran's dying explosion, by half
*-Other things I don't remember
*-Changed the turrets... now they are REALLY EVIL, remember, there are ways to get by a turret,
	Mainly cloak, use cover strategically, destroy the turret from far off (helps a lot with
	2 people that have sniper weapons), an EMP gen from an angle the turret can't hit then 
	smack it with about any weapon, oh yeh, plague can now kill turrets, again.
*-Put the penis curse in the mod, now called the Balls of Life
*-Added Zerg Infested Marine, people who like Zerg and Marines should check this one out...
*-Added Infestation Juices for Infested Marine, you know, the stuff that goes !BOOM!
*-Added Infested Burst Laser (more powerful than the "other" one we all know about)
*-Added the way cool Infested Gauss Rifle
*-Added the infested flame thrower (Extremely strong, but uses the Infested's blood for napalm, so you get hurt by using it)
*-Gauss Pistol will not detach weapons from people, but is instead stronger, I have found it moderately efficient against heavies
*-C10 canister rifle cannot be thrown, certain people would shoot, throw the weapon, pick it up and get around the reload time in this manner of cheesiness
*-Reload on various vehicles changed
*-Projectiles on various vehicles changed
*-Upped Protoss snipe weapons
*-Removed force fields, people cheesed with them WAY too much
*-Strengthened heavy armor
*-Changed the turrets...
*-Made burst laser more "bursty" (Shoots twice as fast with half the damage it used to do with each shot)
*-Shortened range of gauss rifle
*-Changed several death messages
*-Changed Zerg vehicle projectiles
*-Several weapons should be able to harm vehicles now, before they did no damage
*-Zerg vehicles can now hurt themselves
*-COMPLETELY REMOVED DEMETABOLIZERS-  Why'd I add em in the first place?
*-Slightly strengthened Plague, and increased energy drain from target, energy usage stayed same
*-Gemini launcher has faster fire rate
*-Switched dropship and shuttle projectiles around, now they seem to reflect their race a bit more.
*-Just remembered I need to change my web site to reflect these changes, later all!
*-Strengthened the flak cannon, I had made it too weak, oops
*-Added Devourer flying Zerg strain, poisons people
*-Added Guardian flying Zerg strain
*-Added Mutalisk flying Zerg strain, has the popular glave wurm, but stronger, "I hope those 3 toys make you happier Moo, now people might not be able to smack a demetabolizer on you as often when you're in a vehicle, or flying Zerg strain or whatever"
*-Fixed the gauss pistol and it, hopefully, will detach weapons from others now, also is much more accurate than before
*-Reduced energy needed to use Plague per second, still only the Ultralisk has enough energy to use it effectively
*-Changed the Terran's Spore Demetabolizer into a grenade projectile
*-Added two lovely little beauties that should make the game a lot more even, the two Spore Demetabolizers, that instantly kill any Zerg scum in it's radius, although you only get 3 shots with it.  Also good for jumping yourself, since it won't do damage to Terran or Protoss
*-Name change in mod, from the StarCraft mod to the StarsiegeCraft mod, changed due to copyright reasons
*-Weakened the Flak Cannon, it was way too strong before
*-Added the flak cannon for Terran with 2 fire modes, shell and spray
*-Added the Psionic Anchor Grenade for the Archon
*-Added the Flak Grenade for the Vulture
*-Removed the Repair turret, as it wouldn't work if TD was off, and most people like Team Damage off, so there would be no point to it
*-Made weapon text white, to make more noticable, then maybe people will stop asking "Wat does dis wepun do?"
*-Made Protoss and Terran armors/weapons/packs/war gear available at a vehicle station, to even lessen the Inventory lines, and so incase you got the wrong armor, you don't have to go all the way back and change armors
*-Fixed Carrier projectile bug where it would travel through terrain
*-Changed starting equipment, no one ever used the arclite gun, so the fission cutter replaced it in the starting loadout
*-Edited numerous weapons to make more balanced *cough* plague, *cough* ;)
*-Added the Particle Cannon to the protoss armaments, with 3 modes of fire, GRENADE, MISSILE, AND SPREAD
*-Added the Psionic Receptive to the protoss armaments, with 3 modes of fire, DISC, GRENADE, and SNIPER, people asked me where the popular disc launcher went, here it is!
*-Added the gauss pistol, moderately strengthed, but is able to knock weapons out of people's hands, used correctly could really mess someone up
*-Added in the Ultralisk armor, with the Plasma Metamorphosis weapon, where the plasma has a small chance to go "out of control" and do tons of damage
*-The repair turret was "completed", although still needs work, won't repair something that has shields on, sometimes doesn't repair machinery, but will repair people
*-Armors, Weapons, etc. except the builder armor and the repair turret available at remote inventory stations
*-I took Doe Young's idea of a StarCraft mod, and Paladin's WH40K 1.2b, and tried to make something amazing!
*-Other things I don't really remember that well, although I know I did em :D

=================================================================================================================================
Admin Stuff

I have admin powers in this mod(Matthias).  Know that I am a responsible admin, and will
ban TKs, Team changers, and holes in general.  I can monitor an active SSC server when the 
server owner is not present, since the SSC mod tends to attract holes.  Also some people
I have known for a long time also have admin powers, but they are people to be trusted and 
will use SAD powers only as they should be used.


Peace out everyone and thanks for spending the time to read my boring ReadMe