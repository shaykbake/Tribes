
//excess stuff

$ItemMax[armorAss, FlakC]= 0;
$ItemMax[armorAss, RepairKit] = 3;
$ItemMax[armorAss, grenade] = 5;
$ItemMax[armorAss, beacon] = 3;
$ItemMax[armorAss, mineammo] = 5;
$ItemMax[armormLing, PlasMeta] = 0;
$ItemMax[armormLing, Stream] = 0;
$ItemMax[armormLing, Heal] = 1;
$ItemMax[armormLing, Pull] = 1;
$ItemMax[armormLing, Zap] = 1;
$ItemMax[armormLing, Fireball] = 1;
$ItemMax[armormLing, Cloak] = 1;
$ItemMax[armormLing, Dis] = 1;
$ItemMax[armormLing, PsiLaser] = 1;
$ItemMax[armormLing, Gravi] = 0;
$ItemMax[armormLing, Sword] = 1;
$ItemMax[armorfLing, PlasMeta] = 0;
$ItemMax[armorfLing, Stream] = 0;
$ItemMax[armorfLing, Heal] = 1;
$ItemMax[armorfLing, Pull] = 1;
$ItemMax[armorfLing, Zap] = 1;
$ItemMax[armorfLing, Fireball] = 1;
$ItemMax[armorfLing, Cloak] = 1;
$ItemMax[armorfLing, Dis] = 1;
$ItemMax[armorfLing, PsiLaser] = 1;
$ItemMax[armorfLing, Gravi] = 0;
$ItemMax[armorfLing, Sword] = 1;
$ItemMax[armormSniper, Boost] = 3;
$ItemMax[armormSniper, Plastique] = 0;
$ItemMax[armormSniper, LaserTurretPack] = 1;
$ItemMax[armormSniper, RocketPack] = 0;
$ItemMax[armormSniper, PlasmaTurretPack] = 0;
$ItemMax[armormSniper, CloakingDevice] = 0;
$ItemMax[armormSniper, StealthShieldPack] = 0;
$ItemMax[armormSniper, MortarTurretPack] = 0;
$ItemMax[armormSniper, Laptop] = 0;
$ItemMax[armormSniper, ShockTurretPack] = 0;
$ItemMax[armormSniper, RegenerationPack] = 1;
$ItemMax[armormSniper, LightningPack] = 0;
$ItemMax[armormSniper, SMRPack] = 0;
$ItemMax[armormSniper, RailTurretPack] = 0;
$ItemMax[armormSniper, VulcanTurretPack] = 0;
$ItemMax[armormSniper, ImRecPack] = 1;
$ItemMax[armorfSniper, Boost] = 3;
$ItemMax[armorfSniper, Plastique] = 0;
$ItemMax[armorfSniper, Gaussgun] = 0;
$ItemMax[armorfSniper, LaserTurretPack] = 1;
$ItemMax[armorfSniper, RocketPack] = 0;
$ItemMax[armorfSniper, PlasmaTurretPack] = 0;
$ItemMax[armorfSniper, CloakingDevice] = 0;
$ItemMax[armorfSniper, StealthShieldPack] = 0;
$ItemMax[armorfSniper, MortarTurretPack] = 0;
$ItemMax[armorfSniper, Laptop] = 0;
$ItemMax[armorfSniper, ShockTurretPack] = 0;
$ItemMax[armorfSniper, RegenerationPack] = 0;
$ItemMax[armorfSniper, LightningPack] = 0;
$ItemMax[armorfSniper, SMRPack] = 0;
$ItemMax[armorfSniper, RailTurretPack] = 0;
$ItemMax[armorfSniper, VulcanTurretPack] = 0;
$ItemMax[armorfSniper, ImRecPack] = 1;
$ItemMax[armormScout, Boost] = 5;
$ItemMax[armormScout, Plastique] = 0;
$ItemMax[armormScout, Gaussgun] = 0;
$ItemMax[armormScout, LaserTurretPack] = 0;
$ItemMax[armormScout, RocketPack] = 0;
$ItemMax[armormScout, PlasmaTurretPack] = 0;
$ItemMax[armormScout, CloakingDevice] = 0;
$ItemMax[armormScout, StealthShieldPack] = 1;
$ItemMax[armormScout, MortarTurretPack] = 0;
$ItemMax[armormScout, Laptop] = 0;
$ItemMax[armormScout, ShockTurretPack] = 0;
$ItemMax[armormScout, RegenerationPack] = 0;
$ItemMax[armormScout, LightningPack] = 0;
$ItemMax[armormScout, SMRPack] = 0;
$ItemMax[armormScout, RailTurretPack] = 0;
$ItemMax[armormScout, VulcanTurretPack] = 0;
$ItemMax[armormMercenary, Boost] = 4;
$ItemMax[armormMercenary, Plastique] = 0;
$ItemMax[armormMercenary, LaserTurretPack] = 0;
$ItemMax[armormMercenary, RocketPack] = 0;
$ItemMax[armormMercenary, PlasmaTurretPack] = 0;
$ItemMax[armormMercenary, CloakingDevice] = 0;
$ItemMax[armormMercenary, StealthShieldPack] = 0;
$ItemMax[armormMercenary, MortarTurretPack] = 0;
$ItemMax[armormMercenary, Laptop] = 0;
$ItemMax[armormMercenary, ShockTurretPack] = 0;
$ItemMax[armormMercenary, RegenerationPack] = 0;
$ItemMax[armormMercenary, LightningPack] = 0;
$ItemMax[armormMercenary, SMRPack] = 0;
$ItemMax[armormMercenary, RailTurretPack] = 0;
$ItemMax[armormMercenary, VulcanTurretPack] = 0;
$ItemMax[armormMercenary, ImRecPack] = 1;
$ItemMax[armorfMercenary, Boost] = 4;
$ItemMax[armorfMercenary, Plastique] = 0;
$ItemMax[armorfMercenary, Gaussgun] = 0;
$ItemMax[armorfMercenary, LaserTurretPack] = 0;
$ItemMax[armorfMercenary, RocketPack] = 0;
$ItemMax[armorfMercenary, PlasmaTurretPack] = 0;
$ItemMax[armorfMercenary, CloakingDevice] = 0;
$ItemMax[armorfMercenary, StealthShieldPack] = 0;
$ItemMax[armorfMercenary, MortarTurretPack] = 0;
$ItemMax[armorfMercenary, Laptop] = 0;
$ItemMax[armorfMercenary, ShockTurretPack] = 0;
$ItemMax[armorfMercenary, RegenerationPack] = 0;
$ItemMax[armorfMercenary, LightningPack] = 0;
$ItemMax[armorfMercenary, SMRPack] = 0;
$ItemMax[armorfMercenary, RailTurretPack] = 0;
$ItemMax[armorfMercenary, VulcanTurretPack] = 0;
$ItemMax[armormBurster, Boost] = 4;
$ItemMax[armormBurster, Plastique] = 0;
$ItemMax[armormBurster, LaserTurretPack] = 0;
$ItemMax[armormBurster, RocketPack] = 0;
$ItemMax[armormBurster, PlasmaTurretPack] = 0;
$ItemMax[armormBurster, CloakingDevice] = 0;
$ItemMax[armormBurster, StealthShieldPack] = 0;
$ItemMax[armormBurster, MortarTurretPack] = 0;
$ItemMax[armormBurster, Laptop] = 0;
$ItemMax[armormBurster, ShockTurretPack] = 0;
$ItemMax[armormBurster, RegenerationPack] = 0;
$ItemMax[armormBurster, LightningPack] = 0;
$ItemMax[armormBurster, SMRPack] = 0;
$ItemMax[armormBurster, RailTurretPack] = 0;
$ItemMax[armormBurster, VulcanTurretPack] = 0;
$ItemMax[armormBurster, TrackerMissilePack] = 1;
$ItemMax[armormBurster, TrackerMissileAmmo] = 8;
$ItemMax[armorCyborg, Boost] = 5;
$ItemMax[armorCyborg, Plastique] = 0;
$ItemMax[armorCyborg, MassDriver] = 0;
$ItemMax[armorCyborg, MassAmmo] = 20;
$ItemMax[armorCyborg, LaserTurretPack] = 1;
$ItemMax[armorCyborg, RocketPack] = 1;
$ItemMax[armorCyborg, PlasmaTurretPack] = 0;
$ItemMax[armorCyborg, CloakingDevice] = 0;
$ItemMax[armorCyborg, StealthShieldPack] = 1;
$ItemMax[armorCyborg, FgcPack] = 1;
$ItemMax[armorCyborg, MortarTurretPack] = 0;
$ItemMax[armorCyborg, Laptop] = 0;
$ItemMax[armorCyborg, ShockTurretPack] = 0;
$ItemMax[armorCyborg, RegenerationPack] = 1;
$ItemMax[armorCyborg, LightningPack] = 0;
$ItemMax[armorCyborg, SMRPack] = 1;
$ItemMax[armorCyborg, RailTurretPack] = 0;
$ItemMax[armorCyborg, VulcanTurretPack] = 0;
$ItemMax[armorCyborg, ImRecPack] = 1;
$ItemMax[armorCyborg, TrackerMissilePack] = 1;
$ItemMax[armorCyborg, TrackerMissileAmmo] = 16;
$ItemMax[armorCyborg, PhotonPack] = 1;
$ItemMax[armorfScout, Boost] = 5;
$ItemMax[armorfScout, Plastique] = 0;
$ItemMax[armorfScout, Gaussgun] = 0;
$ItemMax[armorfScout, LaserTurretPack] = 0;
$ItemMax[armorfScout, RocketPack] = 0;
$ItemMax[armorfScout, PlasmaTurretPack] = 0;
$ItemMax[armorfScout, CloakingDevice] = 0;
$ItemMax[armorfScout, StealthShieldPack] = 1;
$ItemMax[armorfScout, MortarTurretPack] = 0;
$ItemMax[armorfScout, Laptop] = 0;
$ItemMax[armorfScout, ShockTurretPack] = 0;
$ItemMax[armorfScout, RegenerationPack] = 0;
$ItemMax[armorfScout, LightningPack] = 0;
$ItemMax[armorfScout, SMRPack] = 0;
$ItemMax[armorfScout, RailTurretPack] = 0;
$ItemMax[armorfScout, VulcanTurretPack] = 0;
$ItemMax[armorfBurster, Boost] = 4;
$ItemMax[armorfBurster, Plastique] = 0;
$ItemMax[armorfBurster, LaserTurretPack] = 0;
$ItemMax[armorfBurster, RocketPack] = 0;
$ItemMax[armorfBurster, PlasmaTurretPack] = 0;
$ItemMax[armorfBurster, CloakingDevice] = 0;
$ItemMax[armorfBurster, StealthShieldPack] = 0;
$ItemMax[armorfBurster, MortarTurretPack] = 0;
$ItemMax[armorfBurster, Laptop] = 0;
$ItemMax[armorfBurster, ShockTurretPack] = 0;
$ItemMax[armorfBurster, RegenerationPack] = 0;
$ItemMax[armorfBurster, LightningPack] = 0;
$ItemMax[armorfBurster, SMRPack] = 0;
$ItemMax[armorfBurster, RailTurretPack] = 0;
$ItemMax[armorfBurster, VulcanTurretPack] = 0;
$ItemMax[armorfBurster, TrackerMissilePack] = 1;
$ItemMax[armorfBurster, TrackerMissileAmmo] = 8;
$ItemMax[armormSpy, Boost] = 3;
$ItemMax[armormSpy, Plastique] = 0;
$ItemMax[armormSpy, Gaussgun] = 0;
$ItemMax[armormSpy, LaserTurretPack] = 0;
$ItemMax[armormSpy, RocketPack] = 0;
$ItemMax[armormSpy, PlasmaTurretPack] = 1;
$ItemMax[armormSpy, CloakingDevice] = 0;
$ItemMax[armormSpy, StealthShieldPack] = 0;
$ItemMax[armormSpy, Laptop] = 1;
$ItemMax[armormSpy, MortarTurretPack] = 0;
$ItemMax[armormSpy, ShockTurretPack] = 0;
$ItemMax[armormSpy, RegenerationPack] = 0;
$ItemMax[armormSpy, LightningPack] = 0;
$ItemMax[armormSpy, SMRPack] = 0;
$ItemMax[armormSpy, RailTurretPack] = 0;
$ItemMax[armormSpy, VulcanTurretPack] = 0;
$ItemMax[armorfSpy, Boost] = 3;
$ItemMax[armorfSpy, Plastique] = 0;
$ItemMax[armorfSpy, Gaussgun] = 0;
$ItemMax[armorfSpy, LaserTurretPack] = 0;
$ItemMax[armorfSpy, RocketPack] = 0;
$ItemMax[armorfSpy, PlasmaTurretPack] = 1;
$ItemMax[armorfSpy, CloakingDevice] = 0;
$ItemMax[armorfSpy, StealthShieldPack] = 0;
$ItemMax[armorfSpy, Laptop] = 1;
$ItemMax[armorfSpy, MortarTurretPack] = 0;
$ItemMax[armorfSpy, ShockTurretPack] = 0;
$ItemMax[armorfSpy, RegenerationPack] = 0;
$ItemMax[armorfSpy, LightningPack] = 0;
$ItemMax[armorfSpy, SMRPack] = 0;
$ItemMax[armorfSpy, RailTurretPack] = 0;
$ItemMax[armorfSpy, VulcanTurretPack] = 0;
$ItemMax[armormEngineer, RepairTurretPack] = 1;
$ItemMax[armormEngineer, Boost] = 4;
$ItemMax[armormEngineer, Plastique] = 0;
$ItemMax[armormEngineer, Gaussgun] = 0;
$ItemMax[armormEngineer, LaserTurretPack] = 1;
$ItemMax[armormEngineer, RocketPack] = 1;
$ItemMax[armormEngineer, NukeTurretPack] = 1;
$ItemMax[armormEngineer, PlasmaTurretPack] = 1;
$ItemMax[armormEngineer, CloakingDevice] = 0;
$ItemMax[armormEngineer, StealthShieldPack] = 0;
$ItemMax[armormEngineer, Laptop] = 1;
$ItemMax[armormEngineer, ShockTurretPack] = 1;
$ItemMax[armormEngineer, MortarTurretPack] = 1;
$ItemMax[armormEngineer, RegenerationPack] = 0;
$ItemMax[armormEngineer, LightningPack] = 0;
$ItemMax[armormEngineer, SMRPack] = 1;
$ItemMax[armormEngineer, RailTurretPack] = 1;
$ItemMax[armormEngineer, VulcanTurretPack] = 1;
$ItemMax[armormEngineer, HFlameTurretPack] = 1;
$ItemMax[armormEngineer, ElecTurretPack] = 1;
$ItemMax[armormEngineer, FlameTurretPack] = 1;
$ItemMax[armormEngineer, AAPack] = 1;
$ItemMax[armormEngineer, BarragePack] = 1;
$ItemMax[armorfEngineer, RepairTurretPack] = 1;
$ItemMax[armorfEngineer, Boost] = 4;
$ItemMax[armorfEngineer, Plastique] = 0;
$ItemMax[armorfEngineer, Gaussgun] = 0;
$ItemMax[armorfEngineer, LaserTurretPack] = 1;
$ItemMax[armorfEngineer, RocketPack] = 1;
$ItemMax[armorfEngineer, PlasmaTurretPack] = 1;
$ItemMax[armorfEngineer, CloakingDevice] = 0;
$ItemMax[armorfEngineer, StealthShieldPack] = 0;
$ItemMax[armorfEngineer, Laptop] = 1;
$ItemMax[armorfEngineer, ShockTurretPack] = 1;
$ItemMax[armorfEngineer, MortarTurretPack] = 1;
$ItemMax[armorfEngineer, RegenerationPack] = 0;
$ItemMax[armorfEngineer, LightningPack] = 0;
$ItemMax[armorfEngineer, SMRPack] = 1;
$ItemMax[armorfEngineer, RailTurretPack] = 1;
$ItemMax[armorfEngineer, VulcanTurretPack] = 1;
$ItemMax[armorfEngineer, HFlameTurretPack] = 1;
$ItemMax[armorfEngineer, ElecTurretPack] = 1;
$ItemMax[armorfEngineer, FlameTurretPack] = 1;
$ItemMax[armorfEngineer, AAPack] = 1;
$ItemMax[armorfEngineer, BarragePack] = 1;
$ItemMax[armormAlien, Boost] = 4;
$ItemMax[armormAlien, Plastique] = 0;
$ItemMax[armormAlien, LaserTurretPack] = 0;
$ItemMax[armormAlien, RocketPack] = 0;
$ItemMax[armormAlien, PlasmaTurretPack] = 0;
$ItemMax[armormAlien, CloakingDevice] = 1;
$ItemMax[armormAlien, StealthShieldPack] = 0;
$ItemMax[armormAlien, MortarTurretPack] = 0;
$ItemMax[armormAlien, Laptop] = 0;
$ItemMax[armormAlien, ShockTurretPack] = 0;
$ItemMax[armormAlien, RegenerationPack] = 1;
$ItemMax[armormAlien, LightningPack] = 1;
$ItemMax[armormAlien, SMRPack] = 0;
$ItemMax[armormAlien, RailTurretPack] = 0;
$ItemMax[armormAlien, VulcanTurretPack] = 0;
$ItemMax[armorfAlien, Boost] = 4;
$ItemMax[armorfAlien, Plastique] = 0;
$ItemMax[armorfAlien, LaserTurretPack] = 0;
$ItemMax[armorfAlien, RocketPack] = 0;
$ItemMax[armorfAlien, PlasmaTurretPack] = 0;
$ItemMax[armorfAlien, CloakingDevice] = 1;
$ItemMax[armorfAlien, StealthShieldPack] = 0;
$ItemMax[armorfAlien, MortarTurretPack] = 0;
$ItemMax[armorfAlien, Laptop] = 0;
$ItemMax[armorfAlien, ShockTurretPack] = 0;
$ItemMax[armorfAlien, RegenerationPack] = 1;
$ItemMax[armorfAlien, LightningPack] = 1;
$ItemMax[armorfAlien, SMRPack] = 0;
$ItemMax[armorfAlien, RailTurretPack] = 0;
$ItemMax[armorfAlien, VulcanTurretPack] = 0;
//NEW ARMOURS ADDED IN BY PALADIN FOR WARHAMMER 40K MOD
//Dark Reaper
$ItemMax[armormCommando, Boost] = 3;
$ItemMax[armormCommando, Plastique] = 0;
$ItemMax[armormCommando, Gaussgun] = 0;
$ItemMax[armormCommando, LaserTurretPack] = 0;
$ItemMax[armormCommando, RocketPack] = 1;
$ItemMax[armormCommando, PlasmaTurretPack] = 1;
$ItemMax[armormCommando, CloakingDevice] = 0;
$ItemMax[armormCommando, StealthShieldPack] = 1;
$ItemMax[armormCommando, Laptop] = 1;
$ItemMax[armormCommando, MortarTurretPack] = 0;
$ItemMax[armormCommando, ShockTurretPack] = 0;
$ItemMax[armormCommando, RegenerationPack] = 1;
$ItemMax[armormCommando, LightningPack] = 1;
$ItemMax[armormCommando, SMRPack] = 0;
$ItemMax[armormCommando, RailTurretPack] = 0;
$ItemMax[armormCommando, VulcanTurretPack] = 0;
$ItemMax[armormCommando, ImRecPack]=1;
$ItemMax[armormCommando, MassDriver] = 1;
$ItemMax[armormCommando, MassAmmo] = 30;
$ItemMax[armorfCommando, Boost] = 3;
$ItemMax[armorfCommando, Plastique] = 0;
$ItemMax[armorfCommando, Gaussgun] = 0;
$ItemMax[armorfCommando, LaserTurretPack] = 0;
$ItemMax[armorfCommando, RocketPack] = 1;
$ItemMax[armorfCommando, PlasmaTurretPack] = 1;
$ItemMax[armorfCommando, CloakingDevice] = 0;
$ItemMax[armorfCommando, StealthShieldPack] = 1;
$ItemMax[armorfCommando, Laptop] = 1;
$ItemMax[armorfCommando, MortarTurretPack] = 0;
$ItemMax[armorfCommando, ShockTurretPack] = 0;
$ItemMax[armorfCommando, RegenerationPack] = 1;
$ItemMax[armorfCommando, LightningPack] = 1;
$ItemMax[armorfCommando, SMRPack] = 0;
$ItemMax[armorfCommando, RailTurretPack] = 0;
$ItemMax[armorfCommando, VulcanTurretPack] = 0;
$ItemMax[armorfCommando, ImRecPack]=1;
$ItemMax[armorfCommando, MassDriver] = 1;
$ItemMax[armorfCommando, MassAmmo] = 30;
//WraithLord
$ItemMax[armorDestroyer, Boost] = 3;
$ItemMax[armorDestroyer, Plastique] = 0;
$ItemMax[armorDestroyer, Gaussgun] = 1;
$ItemMax[armorDestroyer, LaserTurretPack] = 0;
$ItemMax[armorDestroyer, RocketPack] = 1;
$ItemMax[armorDestroyer, PlasmaTurretPack] = 1;
$ItemMax[armorDestroyer, CloakingDevice] = 1;
$ItemMax[armorDestroyer, StealthShieldPack] = 1;
$ItemMax[armorDestroyer, Laptop] = 1;
$ItemMax[armorDestroyer, MortarTurretPack] = 0;
$ItemMax[armorDestroyer, ShockTurretPack] = 0;
$ItemMax[armorDestroyer, RegenerationPack] = 1;
$ItemMax[armorDestroyer, LightningPack] = 1;
$ItemMax[armorDestroyer, SMRPack] = 1;
$ItemMax[armorDestroyer, RailTurretPack] = 0;
$ItemMax[armorDestroyer, VulcanTurretPack] = 0;
$ItemMax[armorDestroyer, ImRecPack]=1;
$ItemMax[armorDestroyer, TrackerMissilePack] = 1;
$ItemMax[armorDestroyer, TrackerMissileAmmo] = 16;
$ItemMax[armorDestroyer, PhotonPack] = 1;
$ItemMax[armorDestroyer, MassDriver] = 0;
$ItemMax[armorDestroyer, MassAmmo] = 30;
//Warp Spider
$ItemMax[armormLoader, Boost] = 3;
$ItemMax[armormLoader, Plastique] = 0;
$ItemMax[armormLoader, Gaussgun] = 0;
$ItemMax[armormLoader, LaserTurretPack] = 0;
$ItemMax[armormLoader, RocketPack] = 1;
$ItemMax[armormLoader, PlasmaTurretPack] = 1;
$ItemMax[armormLoader, CloakingDevice] = 0;
$ItemMax[armormLoader, StealthShieldPack] = 1;
$ItemMax[armormLoader, Laptop] = 1;
$ItemMax[armormLoader, MortarTurretPack] = 0;
$ItemMax[armormLoader, ShockTurretPack] = 0;
$ItemMax[armormLoader, RegenerationPack] = 1;
$ItemMax[armormLoader, LightningPack] = 1;
$ItemMax[armormLoader, SMRPack] = 1;
$ItemMax[armormLoader, RailTurretPack] = 0;
$ItemMax[armormLoader, VulcanTurretPack] = 0;
$ItemMax[armorfLoader, Boost] = 3;
$ItemMax[armorfLoader, Plastique] = 0;
$ItemMax[armorfLoader, Gaussgun] = 0;
$ItemMax[armorfLoader, LaserTurretPack] = 0;
$ItemMax[armorfLoader, RocketPack] = 1;
$ItemMax[armorfLoader, PlasmaTurretPack] = 1;
$ItemMax[armorfLoader, CloakingDevice] = 0;
$ItemMax[armorfLoader, StealthShieldPack] = 1;
$ItemMax[armorfLoader, Laptop] = 1;
$ItemMax[armorfLoader, MortarTurretPack] = 0;
$ItemMax[armorfLoader, ShockTurretPack] = 0;
$ItemMax[armorfLoader, RegenerationPack] = 1;
$ItemMax[armorfLoader, LightningPack] = 1;
$ItemMax[armorfLoader, SMRPack] = 1;
$ItemMax[armorfLoader, RailTurretPack] = 0;
$ItemMax[armorfLoader, VulcanTurretPack] = 0;
//SWOOPING HAWKS
$ItemMax[armormSprint, Boost] = 3;
$ItemMax[armormSprint, Plastique] = 0;
$ItemMax[armormSprint, Gaussgun] = 0;
$ItemMax[armormSprint, LaserTurretPack] = 0;
$ItemMax[armormSprint, RocketPack] = 1;
$ItemMax[armormSprint, PlasmaTurretPack] = 1;
$ItemMax[armormSprint, CloakingDevice] = 0;
$ItemMax[armormSprint, StealthShieldPack] = 1;
$ItemMax[armormSprint, Laptop] = 1;
$ItemMax[armormSprint, MortarTurretPack] = 0;
$ItemMax[armormSprint, ShockTurretPack] = 0;
$ItemMax[armormSprint, RegenerationPack] = 1;
$ItemMax[armormSprint, LightningPack] = 1;
$ItemMax[armormSprint, SMRPack] = 0;
$ItemMax[armormSprint, RailTurretPack] = 0;
$ItemMax[armormSprint, VulcanTurretPack] = 0;
$ItemMax[armorfSprint, Boost] = 3;
$ItemMax[armorfSprint, Plastique] = 0;
$ItemMax[armorfSprint, Gaussgun] = 0;
$ItemMax[armorfSprint, LaserTurretPack] = 0;
$ItemMax[armorfSprint, RocketPack] = 1;
$ItemMax[armorfSprint, PlasmaTurretPack] = 1;
$ItemMax[armorfSprint, CloakingDevice] = 0;
$ItemMax[armorfSprint, StealthShieldPack] = 1;
$ItemMax[armorfSprint, Laptop] = 1;
$ItemMax[armorfSprint, MortarTurretPack] = 0;
$ItemMax[armorfSprint, ShockTurretPack] = 0;
$ItemMax[armorfSprint, RegenerationPack] = 1;
$ItemMax[armorfSprint, LightningPack] = 1;
$ItemMax[armorfSprint, SMRPack] = 0;
$ItemMax[armorfSprint, RailTurretPack] = 0;
$ItemMax[armorfSprint, VulcanTurretPack] = 0;
$ItemMax[dmarmor, Boost] = 4;
$ItemMax[dmarmor, Plastique] = 1;
$ItemMax[dmarmor, IonTurretPack] = 0;
$ItemMax[dmarmor, LaserTurretPack] = 0;
$ItemMax[dmarmor, RocketPack] = 0;
$ItemMax[dmarmor, PlasmaTurretPack] = 0;
$ItemMax[dmarmor, CloakingDevice] = 0;
$ItemMax[dmarmor, StealthShieldPack] = 0;
$ItemMax[dmarmor, MortarTurretPack] = 0;
$ItemMax[dmarmor, Laptop] = 0;
$ItemMax[dmarmor, ShockTurretPack] = 0;
$ItemMax[dmarmor, RegenerationPack] = 1;
$ItemMax[dmarmor, LightningPack] = 1;
$ItemMax[dmarmor, SMRPack] = 1;
$ItemMax[dmarmor, RailTurretPack] = 1;
$ItemMax[dmarmor, VulcanTurretPack] = 1;
$ItemMax[dmfemale, Boost] = 4;
$ItemMax[dmfemale, Plastique] = 1;
$ItemMax[dmfemale, IonTurretPack] = 0;
$ItemMax[dmfemale, LaserTurretPack] = 0;
$ItemMax[dmfemale, RocketPack] = 0;
$ItemMax[dmfemale, PlasmaTurretPack] = 0;
$ItemMax[dmfemale, CloakingDevice] = 0;
$ItemMax[dmfemale, StealthShieldPack] = 0;
$ItemMax[dmfemale, MortarTurretPack] = 0;
$ItemMax[dmfemale, Laptop] = 0;
$ItemMax[dmfemale, ShockTurretPack] = 0;
$ItemMax[dmfemale, RegenerationPack] = 1;
$ItemMax[dmfemale, LightningPack] = 1;
$ItemMax[dmfemale, SMRPack] = 1;
$ItemMax[dmfemale, RailTurretPack] = 1;
$ItemMax[dmfemale, VulcanTurretPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, AcceleratorDevicePack] = 0; // Light 
$ItemMax[armorfSniper, AcceleratorDevicePack] = 0; 
$ItemMax[armormMercenary, AcceleratorDevicePack] = 0; // Medium 
$ItemMax[armorfMercenary, AcceleratorDevicePack] = 0; 
$ItemMax[harmor, AcceleratorDevicePack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, AcceleratorDevicePack] = 0; // Scout
$ItemMax[armorfScout, AcceleratorDevicePack] = 0; 
$ItemMax[armormSpy, AcceleratorDevicePack] = 0; // Spy
$ItemMax[armorfSpy, AcceleratorDevicePack] = 0; 
$ItemMax[armormBurster, AcceleratorDevicePack] = 0; // Burster
$ItemMax[armorfBurster, AcceleratorDevicePack] = 0; 
$ItemMax[armormEngineer, AcceleratorDevicePack] = 1; // Engineer
$ItemMax[armorfEngineer, AcceleratorDevicePack] = 1; 
$ItemMax[armormAlien, AcceleratorDevicePack] = 0; // Alien
$ItemMax[armorfAlien, AcceleratorDevicePack] = 0; 
$ItemMax[armorCyborg, AcceleratorDevicePack] = 0; // Cyborg

$ItemMax[dmarmor, AcceleratorDevicePack] = 0; // Deathmatch
$ItemMax[dmfemale, AcceleratorDevicePack] = 0;

 // "Base" armor
$ItemMax[armormSniper, BlastWallPack] = 0; // Light 
$ItemMax[armorfSniper, BlastWallPack] = 0; 
$ItemMax[armormMercenary, BlastWallPack] = 0; // Medium 
$ItemMax[armorfMercenary, BlastWallPack] = 0; 
$ItemMax[harmor, BlastWallPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, BlastWallPack] = 0; // Scout
$ItemMax[armorfScout, BlastWallPack] = 0; 
$ItemMax[armormSpy, BlastWallPack] = 0; // Spy
$ItemMax[armorfSpy, BlastWallPack] = 0; 
$ItemMax[armormBurster, BlastWallPack] = 0; // Burster
$ItemMax[armorfBurster, BlastWallPack] = 0; 
$ItemMax[armormEngineer, BlastWallPack] = 1; // Engineer
$ItemMax[armorfEngineer, BlastWallPack] = 1; 
$ItemMax[armormAlien, BlastWallPack] = 0; // Alien
$ItemMax[armorfAlien, BlastWallPack] = 0; 
$ItemMax[armorCyborg, BlastWallPack] = 0; // Cyborg

$ItemMax[dmarmor, BlastWallPack] = 0; // Deathmatch
$ItemMax[dmfemale, BlastWallPack] = 0;

$ItemMax[armormSniper, IonTurretPack] = 0; 
$ItemMax[armormMercenary, IonTurretPack] = 1; 
$ItemMax[harmor, IonTurretPack] = 1; 
$ItemMax[armorfSniper, IonTurretPack] = 0;
$ItemMax[armorfMercenary, IonTurretPack] = 1; 
$ItemMax[armormScout, IonTurretPack] = 0; 
$ItemMax[armormBurster, IonTurretPack] = 0; 
$ItemMax[armorCyborg, IonTurretPack] = 1; 
$ItemMax[armorfScout, IonTurretPack] = 0; 
$ItemMax[armorfBurster, IonTurretPack] = 0; 
$ItemMax[armormSpy, IonTurretPack] = 0; 
$ItemMax[armorfSpy, IonTurretPack] = 0; 
$ItemMax[armormEngineer, IonTurretPack] = 1;
$ItemMax[armorfEngineer, IonTurretPack] = 1;
$ItemMax[armormAlien, IonTurretPack] = 1; 
$ItemMax[armorfAlien, IonTurretPack] = 1; 

 // "Base" armor
$ItemMax[armormSniper, ForceFieldPack] = 1; // Light 
$ItemMax[armorfSniper, ForceFieldPack] = 1; 
$ItemMax[armormMercenary, ForceFieldPack] = 1; // Medium 
$ItemMax[armorfMercenary, ForceFieldPack] = 1; 
$ItemMax[harmor, ForceFieldPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, ForceFieldPack] = 1; // Scout
$ItemMax[armorfScout, ForceFieldPack] = 1; 
$ItemMax[armormSpy, ForceFieldPack] = 1; // Spy
$ItemMax[armorfSpy, ForceFieldPack] = 1; 
$ItemMax[armormBurster, ForceFieldPack] = 1; // Burster
$ItemMax[armorfBurster, ForceFieldPack] = 1; 
$ItemMax[armormEngineer, ForceFieldPack] = 1; // Engineer
$ItemMax[armorfEngineer, ForceFieldPack] = 1; 
$ItemMax[armormAlien, ForceFieldPack] = 1; // Alien
$ItemMax[armorfAlien, ForceFieldPack] = 1; 
$ItemMax[armorCyborg, ForceFieldPack] = 1; // Cyborg

$ItemMax[dmarmor, ForceFieldPack] = 1; // Deathmatch
$ItemMax[dmfemale, ForceFieldPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, LargeForceFieldPack] = 0; // Light 

$ItemMax[armorfSniper, LargeForceFieldPack] = 0; 
$ItemMax[armormMercenary, LargeForceFieldPack] = 0; // Medium 
$ItemMax[armorfMercenary, LargeForceFieldPack] = 0; 
$ItemMax[harmor, LargeForceFieldPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, LargeForceFieldPack] = 0; // Scout
$ItemMax[armorfScout, LargeForceFieldPack] = 0; 
$ItemMax[armormSpy, LargeForceFieldPack] = 0; // Spy
$ItemMax[armorfSpy, LargeForceFieldPack] = 0; 
$ItemMax[armormBurster, LargeForceFieldPack] = 0; // Burster
$ItemMax[armorfBurster, LargeForceFieldPack] = 0; 
$ItemMax[armormEngineer, LargeForceFieldPack] = 1; // Engineer
$ItemMax[armorfEngineer, LargeForceFieldPack] = 1; 
$ItemMax[armormAlien, LargeForceFieldPack] = 0; // Alien
$ItemMax[armorfAlien, LargeForceFieldPack] = 0; 
$ItemMax[armorCyborg, LargeForceFieldPack] = 1; // Cyborg

$ItemMax[dmarmor, LargeForceFieldPack] = 0; // Deathmatch
$ItemMax[dmfemale, LargeForceFieldPack] = 0;

 // "Base" armor
$ItemMax[armormSniper, MannequinPack] = 1; // Light 
$ItemMax[armorfSniper, MannequinPack] = 1; 
$ItemMax[armormMercenary, MannequinPack] = 1; // Medium 
$ItemMax[armorfMercenary, MannequinPack] = 1; 
$ItemMax[harmor, MannequinPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, MannequinPack] = 1; // Scout
$ItemMax[armorfScout, MannequinPack] = 1; 
$ItemMax[armormSpy, MannequinPack] = 1; // Spy
$ItemMax[armorfSpy, MannequinPack] = 1; 
$ItemMax[armormBurster, MannequinPack] = 1; // Burster
$ItemMax[armorfBurster, MannequinPack] = 1; 
$ItemMax[armormEngineer, MannequinPack] = 1; // Engineer
$ItemMax[armorfEngineer, MannequinPack] = 1; 
$ItemMax[armormAlien, MannequinPack] = 1; // Alien
$ItemMax[armorfAlien, MannequinPack] = 1; 
$ItemMax[armorCyborg, MannequinPack] = 1; // Cyborg

$ItemMax[dmarmor, MannequinPack] = 1; // Deathmatch
$ItemMax[dmfemale, MannequinPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, PlatformPack] = 0; // Light 
$ItemMax[armorfSniper, PlatformPack] = 0; 
$ItemMax[armormMercenary, PlatformPack] = 0; // Medium 
$ItemMax[armorfMercenary, PlatformPack] = 0; 


$ItemMax[harmor, PlatformPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, PlatformPack] = 0; // Scout
$ItemMax[armorfScout, PlatformPack] = 0; 
$ItemMax[armormSpy, PlatformPack] = 0; // Spy
$ItemMax[armorfSpy, PlatformPack] = 0; 
$ItemMax[armormBurster, PlatformPack] = 0; // Burster
$ItemMax[armorfBurster, PlatformPack] = 0; 
$ItemMax[armormEngineer, PlatformPack] = 1; // Engineer
$ItemMax[armorfEngineer, PlatformPack] = 1; 
$ItemMax[armormAlien, PlatformPack] = 0; // Alien
$ItemMax[armorfAlien, PlatformPack] = 0; 
$ItemMax[armorCyborg, PlatformPack] = 0; // Cyborg

$ItemMax[dmarmor, AcceleratorDevicePack] = 1; // Deathmatch
$ItemMax[dmfemale, AcceleratorDevicePack] = 1;

 // "Base" armor
$ItemMax[armormSniper, DeployableComPack] = 0; // Light 
$ItemMax[armorfSniper, DeployableComPack] = 0; 
$ItemMax[armormMercenary, DeployableComPack] = 0; // Medium 
$ItemMax[armorfMercenary, DeployableComPack] = 0; 
$ItemMax[harmor, DeployableComPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, DeployableComPack] = 0; // Scout
$ItemMax[armorfScout, DeployableComPack] = 0; 
$ItemMax[armormSpy, DeployableComPack] = 0; // Spy
$ItemMax[armorfSpy, DeployableComPack] = 0; 
$ItemMax[armormBurster, DeployableComPack] = 0; // Burster
$ItemMax[armorfBurster, DeployableComPack] = 0; 
$ItemMax[armormEngineer, DeployableComPack] = 1; // Engineer
$ItemMax[armorfEngineer, DeployableComPack] = 1; 
$ItemMax[armormAlien, DeployableComPack] = 0; // Alien
$ItemMax[armorfAlien, DeployableComPack] = 0; 
$ItemMax[armorCyborg, DeployableComPack] = 1; // Cyborg

$ItemMax[dmarmor, DeployableComPack] = 0; // Deathmatch
$ItemMax[dmfemale, DeployableComPack] = 0;

 // "Base" armor
$ItemMax[armormSniper, DeployableInvPack] = 0; // Light 
$ItemMax[armorfSniper, DeployableInvPack] = 0; 
$ItemMax[armormMercenary, DeployableInvPack] = 0; // Medium 
$ItemMax[armorfMercenary, DeployableInvPack] = 0; 
$ItemMax[harmor, DeployableInvPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, DeployableInvPack] = 0; // Scout
$ItemMax[armorfScout, DeployableInvPack] = 0; 
$ItemMax[armormSpy, DeployableInvPack] = 0; // Spy
$ItemMax[armorfSpy, DeployableInvPack] = 0; 
$ItemMax[armormBurster, DeployableInvPack] = 0; // Burster
$ItemMax[armorfBurster, DeployableInvPack] = 0; 
$ItemMax[armormEngineer, DeployableInvPack] = 1; // Engineer
$ItemMax[armorfEngineer, DeployableInvPack] = 1; 
$ItemMax[armormAlien, DeployableInvPack] = 0; // Alien
$ItemMax[armorfAlien, DeployableInvPack] = 0; 
$ItemMax[armorCyborg, DeployableInvPack] = 0; // Cyborg

$ItemMax[dmarmor, DeployableInvPack] = 1; // Deathmatch
$ItemMax[dmfemale, DeployableInvPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, SpringPack] = 0; // Light 
$ItemMax[armorfSniper, SpringPack] = 0; 
$ItemMax[armormMercenary, SpringPack] = 0; // Medium 
$ItemMax[armorfMercenary, SpringPack] = 0; 
$ItemMax[harmor, SpringPack] = 0; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, SpringPack] = 0; // Scout
$ItemMax[armorfScout, SpringPack] = 0; 
$ItemMax[armormSpy, SpringPack] = 0; // Spy
$ItemMax[armorfSpy, SpringPack] = 0; 
$ItemMax[armormBurster, SpringPack] = 0; // Burster
$ItemMax[armorfBurster, SpringPack] = 0; 
$ItemMax[armormEngineer, SpringPack] = 1; // Engineer
$ItemMax[armorfEngineer, SpringPack] = 1; 
$ItemMax[armormAlien, SpringPack] = 0; // Alien
$ItemMax[armorfAlien, SpringPack] = 0; 
$ItemMax[armorCyborg, SpringPack] = 0; // Cyborg

$ItemMax[dmarmor, SpringPack] = 1; // Deathmatch
$ItemMax[dmfemale, SpringPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, TeleportPack] = 0; // Light 
$ItemMax[armorfSniper, TeleportPack] = 0; 
$ItemMax[armormMercenary, TeleportPack] = 0; // Medium 
$ItemMax[armorfMercenary, TeleportPack] = 0; 
$ItemMax[harmor, TeleportPack] = 1; // Heavy 


 // "Renegades" armor
$ItemMax[armormScout, TeleportPack] = 0; // Scout
$ItemMax[armorfScout, TeleportPack] = 0; 

$ItemMax[armormSpy, TeleportPack] = 0; // Spy
$ItemMax[armorfSpy, TeleportPack] = 0; 
$ItemMax[armormBurster, TeleportPack] = 0; // Burster
$ItemMax[armorfBurster, TeleportPack] = 0; 
$ItemMax[armormEngineer, TeleportPack] = 1; // Engineer
$ItemMax[armorfEngineer, TeleportPack] = 1; 
$ItemMax[armormAlien, TeleportPack] = 0; // Alien
$ItemMax[armorfAlien, TeleportPack] = 0; 
$ItemMax[armorCyborg, TeleportPack] = 0; // Cyborg

$ItemMax[dmarmor, TeleportPack] = 1; // Deathmatch
$ItemMax[dmfemale, TeleportPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, TreePack] = 1; // Light 
$ItemMax[armorfSniper, TreePack] = 1; 
$ItemMax[armormMercenary, TreePack] = 0; // Medium 
$ItemMax[armorfMercenary, TreePack] = 0; 
$ItemMax[harmor, TreePack] = 0; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, TreePack] = 0; // Scout
$ItemMax[armorfScout, TreePack] = 0; 
$ItemMax[armormSpy, TreePack] = 0; // Spy
$ItemMax[armorfSpy, TreePack] = 0; 
$ItemMax[armormBurster, TreePack] = 0; // Burster
$ItemMax[armorfBurster, TreePack] = 0; 
$ItemMax[armormEngineer, TreePack] = 1; // Engineer
$ItemMax[armorfEngineer, TreePack] = 1; 
$ItemMax[armormAlien, TreePack] = 0; // Alien
$ItemMax[armorfAlien, TreePack] = 0; 
$ItemMax[armorCyborg, TreePack] = 0; // Cyborg


$ItemMax[dmarmor, TreePack] = 0; // Deathmatch
$ItemMax[dmfemale, TreePack] = 0;

$ItemMax[armormSniper, MechPack] = 0; 
$ItemMax[armormMercenary, MechPack] = 0; 
$ItemMax[harmor, MechPack] = 0; 
$ItemMax[armorfSniper, MechPack] = 0; 
$ItemMax[armorfMercenary, MechPack] = 0; 
$ItemMax[armormScout, MechPack] = 1; 
$ItemMax[armormBurster, MechPack] = 0; 
$ItemMax[armorCyborg, MechPack] = 0; 
$ItemMax[armorfScout, MechPack] = 1; 
$ItemMax[armorfBurster, MechPack] = 0; 
$ItemMax[armormSpy, MechPack] = 0; 
$ItemMax[armorfSpy, MechPack] = 0; 
$ItemMax[armormEngineer, MechPack] = 0; 
$ItemMax[armorfEngineer, MechPack] = 0; 
$ItemMax[armormAlien, MechPack] = 0; 
$ItemMax[armorfAlien, MechPack] = 0; 
$ItemMax[dmarmor, MechPack] = 0; 
$ItemMax[dmfemale, MechPack] = 0; 

$ItemMax[armormMercenary, DetPack] = 0; 
$ItemMax[armormSniper, DetPack] = 0; 
$ItemMax[harmor, DetPack] = 0; 
$ItemMax[armorfSniper, DetPack] = 0; 
$ItemMax[armorfMercenary, DetPack] = 0; 
$ItemMax[armormScout, DetPack] = 0; 
$ItemMax[armormBurster, DetPack] = 0; 
$ItemMax[armorCyborg, DetPack] = 0; 
$ItemMax[armorfScout, DetPack] = 0; 
$ItemMax[armorfBurster, DetPack] = 0;
$ItemMax[armormSpy, DetPack] = 0;  
$ItemMax[armorfSpy, DetPack] = 0; 
$ItemMax[armormEngineer, DetPack] = 1; 
$ItemMax[armorfEngineer, DetPack] = 1; 
$ItemMax[armormAlien, DetPack] = 0; 
$ItemMax[armorfAlien, DetPack] = 0; 
$ItemMax[dmarmor, DetPack] = 0; 
$ItemMax[dmfemale, DetPack] = 0;

 // "Base" armor
$ItemMax[armormSniper, PackOMen] = 1; // Light 
$ItemMax[armorfSniper, PackOMen] = 1; 
$ItemMax[armormMercenary, PackOMen] = 1; // Medium 
$ItemMax[armorfMercenary, PackOMen] = 1; 
$ItemMax[harmor, PackOMen] = 1; // Heavy 



// "Renegades" armor
$ItemMax[armormScout, PackOMen] = 1; // Scout
$ItemMax[armorfScout, PackOMen] = 1; 
$ItemMax[armormSpy, PackOMen] = 1; // Spy
$ItemMax[armorfSpy, PackOMen] = 1; 
$ItemMax[armormBurster, PackOMen] = 1; // Burster
$ItemMax[armorfBurster, PackOMen] = 1; 
$ItemMax[armormEngineer, PackOMen] = 1; // Engineer
$ItemMax[armorfEngineer, PackOMen] = 1; 
$ItemMax[armormAlien, PackOMen] = 1; // Alien

$ItemMax[armorfAlien, PackOMen] = 1; 
$ItemMax[armorCyborg, PackOMen] = 1; // Cyborg

$ItemMax[dmarmor, PackOMen] = 1; // Deathmatch
$ItemMax[dmfemale, PackOMen] = 1;

// TargetMarkLaser
$ItemMax[armormScout, TargetMarkLaser] = 0; // Scout
$ItemMax[armorfScout, TargetMarkLaser] = 0; 
$ItemMax[armormSpy, TargetMarkLaser] = 0; // Spy
$ItemMax[armorfSpy, TargetMarkLaser] = 0; 
$ItemMax[armormBurster, TargetMarkLaser] = 0; // Burster
$ItemMax[armorfBurster, TargetMarkLaser] = 0; 
$ItemMax[armormEngineer, TargetMarkLaser] = 0; // Engineer
$ItemMax[armorfEngineer, TargetMarkLaser] = 0; 
$ItemMax[armormAlien, TargetMarkLaser] = 0; // Alien
$ItemMax[armorfAlien, TargetMarkLaser] = 0; 
$ItemMax[armorCyborg, TargetMarkLaser] = 1; // Cyborg
$ItemMax[armormCommando, TargetMarkLaser] = 1; // Commando(Dark Reaper)
$ItemMax[armorfCommando, TargetMarkLaser] = 1; // Commando(Dark Reaper)
$ItemMax[armorDestroyer, TargerMarkLaser] = 1; //Wraithlord

$ItemMax[dmarmor, TargetMarkLaser] = 0; // Deathmatch
$ItemMax[dmfemale, TargetMarkLaser] = 0;

// PhotonPack
$ItemMax[armormScout, PhotonPack] = 0; // Scout

$ItemMax[armorfScout, PhotonPack] = 0; 
$ItemMax[armormSpy, PhotonPack] = 0; // Spy
$ItemMax[armorfSpy, PhotonPack] = 0; 
$ItemMax[armormBurster, PhotonPack] = 0; // Burster
$ItemMax[armorfBurster, PhotonPack] = 0; 
$ItemMax[armormEngineer, PhotonPack] = 0; // Engineer
$ItemMax[armorfEngineer, PhotonPack] = 0; 
$ItemMax[armormAlien, PhotonPack] = 0; // Alien
$ItemMax[armorfAlien, PhotonPack] = 0; 
$ItemMax[armorCyborg, PhotonPack] = 1; // Cyborg

$ItemMax[armormCommando, PhotonPack] = 1; //Dark Reaper
$ItemMax[armorfCommando, PhotonPack] = 1; //Dark Reaper
$ItemMax[armorDestroyer, PhotonPack] = 1; //Wraithlord

$ItemMax[dmarmor, PhotonPack] = 0; // Deathmatch
$ItemMax[dmfemale, PhotonPack] = 0;

// Tracker Missile Pack
$ItemMax[armormScout, TrackerMissilePack] = 0; // Scout

$ItemMax[armorfScout, TrackerMissilePack] = 0; 
$ItemMax[armormSpy, TrackerMissilePack] = 0; // Spy
$ItemMax[armorfSpy, TrackerMissilePack] = 0; 
$ItemMax[armormBurster, TrackerMissilePack] = 0; // Burster
$ItemMax[armorfBurster, TrackerMissilePack] = 0; 
$ItemMax[armormEngineer, TrackerMissilePack] = 0; // Engineer
$ItemMax[armorfEngineer, TrackerMissilePack] = 0; 
$ItemMax[armormAlien, TrackerMissilePack] = 0; // Alien
$ItemMax[armorfAlien, TrackerMissilePack] = 0; 
$ItemMax[armorCyborg, TrackerMissilePack] = 1; // Cyborg
$ItemMax[armormCommando, TrackerMissilePack] = 1; //Dark Reaper
$ItemMax[armorfCommando, TrackerMissilePack] = 1; //Dark Reaper
$ItemMax[armorDestroyer, TrackerMissilePack] = 1; //Wraithlord

$ItemMax[dmarmor, TrackerMissilePack] = 0; // Deathmatch
$ItemMax[dmfemale, TrackerMissilePack] = 0;

// Tracker Missiles
$ItemMax[armormScout, TrackerMissileAmmo] = 5; // Scout
$ItemMax[armorfScout, TrackerMissileAmmo] = 5; 
$ItemMax[armormSpy, TrackerMissileAmmo] = 5; // Spy
$ItemMax[armorfSpy, TrackerMissileAmmo] = 5; 
$ItemMax[armormBurster, TrackerMissileAmmo] = 7; // Burster
$ItemMax[armorfBurster, TrackerMissileAmmo] = 7; 
$ItemMax[armormEngineer, TrackerMissileAmmo] = 7; // Engineer
$ItemMax[armorfEngineer, TrackerMissileAmmo] = 7; 
$ItemMax[armormAlien, TrackerMissileAmmo] = 7; // Alien
$ItemMax[armorfAlien, TrackerMissileAmmo] = 7; 
$ItemMax[armorCyborg, TrackerMissileAmmo] = 15; // Cyborg
$ItemMax[armormCommando, TrackerMissileAmmo] = 10; //Dark Reaper
$ItemMax[armorfCommando, TrackerMissileAmmo] = 10; //Dark Reaper
$ItemMax[armorDestroyer, TrackerMissileAmmo] = 20; //Wraithlord

$ItemMax[dmarmor, TrackerMissileAmmo] = 0; // Deathmatch
$ItemMax[dmfemale, TrackerMissileAmmo] = 0;

// Tractor Device
$ItemMax[armormScout, TractorDevice] = 0; // Scout
$ItemMax[armorfScout, TractorDevice] = 0; 
$ItemMax[armormSpy, TractorDevice] = 0; // Spy
$ItemMax[armorfSpy, TractorDevice] = 0; 
$ItemMax[armormBurster, TractorDevice] = 0; // Burster
$ItemMax[armorfBurster, TractorDevice] = 0; 
$ItemMax[armormEngineer, TractorDevice] = 0; // Engineer
$ItemMax[armorfEngineer, TractorDevice] = 0; 
$ItemMax[armormAlien, TractorDevice] = 0; // Alien
$ItemMax[armorfAlien, TractorDevice] = 0; 
$ItemMax[armorCyborg, TractorDevice] = 0;// Cyborg
$ItemMax[armormCommando, TractorDevice] = 0; //Dark Reaper
$ItemMax[armorfCommando, TractorDevice] = 0; //Dark Reaper
$ItemMax[armorDestroyer, TractorDevice] = 0; //Wraithlord
$ItemMax[armormAlien, TractorDevice] = 0; //Wraithguard
$ItemMax[armorfAlien, TractorDevice] = 0; //Wraithguard

$ItemMax[dmarmor, TractorDevice] = 0; // Deathmatch
$ItemMax[dmfemale, TractorDevice] = 0;

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // TEAM ITEM MAXs
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

$TeamItemMax[IonTurretPack] = 5;
$TeamItemMax[LaserTurretPack] = 6;
$TeamItemMax[RocketPack] = 3;
$TeamItemMax[MortarTurretPack] = 1;
$TeamItemMax[PlasmaTurretPack] = 4;
$TeamItemMax[RailTurretPack] = 2;
$TeamItemMax[SatchelPack] = 25;
$TeamItemMax[ShockTurretPack] = 4;
$TeamItemMax[VulcanTurretPack] = 2;
$TeamItemMax[FlameTurretPack] = 2;
$TeamItemMax[HFlameTurretPack] = 2;
$TeamItemMax[ElecTurretPack] = 2;

$TeamItemMax[AcceleratorDevice] = 3;
$TeamItemMax[BlastWallPack] = 8; 
$TeamItemMax[CameraPack] = 10;
$TeamItemMax[ForceFieldPack] = 8; 
$TeamItemMax[LargeForceFieldPack] = 4; 
$TeamItemMax[Mannequin] = 10;
$TeamItemMax[MotionSensorPack] = 10;
$TeamItemMax[PlatformPack] = 10; 
$TeamItemMax[PulseSensorPack] = 10;
$TeamItemMax[DeployableSensorJammerPack] = 10;
$TeamItemMax[DeployableAmmoPack] = 10; 
$TeamItemMax[DeployableComPack] = 5; 
$TeamItemMax[DeployableInvPack] = 10; 
$TeamItemMax[Springboard] = 3;

