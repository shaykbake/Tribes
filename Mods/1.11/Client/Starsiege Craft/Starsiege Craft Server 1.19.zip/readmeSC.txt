Hello boys, girls, and others! Welcome to the Read Me (And please do read it) of the...

					  STARCRAFT MOD
 _______________________________________________________________________________________________
/		 /+_/                                                        \_+\               \
|_______________/+/                       _____    _____	               \+\______________|
|_=_=_=_=_=_=_=_=\\____________________   \++++\__/++++/   ____________________//=_=_=_=_=_=_=_=|
|              / /=_=_=_=_=_=_=_=_\ __ \  / ____/\____ \  / __ /_=_=_=_=_=_=_=_=\ \             |
|             /   /                \\ \ \/ /	\/    \ \/ / //		       \   \    	|
|            /   /                 /\\ \/_/------------\_\/ //\			\   \		|
|           /   /                 //_\\/)((Version 1.19))(\//_\\		 \   \ 		|
|          /   /                 /_/  \\_(([SC]Matthias))_//  \_\		  \   \         |
|	  /   / 		///    \++\------------/++/    \\\      	   \   \ 	|
|	 /   /  	       /_/      \_/\____/\____/\_/ 	\_\		    \   \       |
|	/   /	              ///\	   \\   \/   //		/\\\	       	     \   \      |
|      /   / 	             /_/\_\         \\_/..\_//	       /_/\_\		      \   \     |
|     /   /		    ///  \_\         \\    //         /_/  \\\		       \   \	|
|____/   /      	   /_/    \_\         \\  //         /_/    \_\		      	\   \___|
|,,,,,,,/        	  ///      \_\         \\//         /_/      \\\		 \,,,,,,|
\________________________/_/________\_\________//\\________/_/________\_\_______________________/
				           By Matthias

Uses source code from Warhammer 40k 1.2b/1.3 (Edgecrusher/Paladin and others)

					TABLE OF CONTENTS

	1.  Welcoming Symbol (Gets More Complex With Every New Version)
	2.  Credits, Thanks, etc. (Anyone I forget please tell me and I will place your name down)
	3.  Installation
	4.  Ideas In Matthias' Head
	5.  Changes Throughout The Life Of This Mod
	6.  Always Accepting Ideas On The Mod

********************************************************************************************************************************
*Skinner- None right now												       *
*Mappers- Ecliptici is busy with his own projects, and, while he has made a few maps for SSC, I need a mapper for the mod      *
*Main SSC 														       *
*Servers- Walking Deadman- Deadman's Party 1 and 2, Realm of the Fallen, }*2K*{ clan server, DM clan server	               *
*Clannie- }*2K*{, the SC in front of my name is just to say, "Hi, I'm the StarCraft guy"                   	               *
*Models - Trife Gazer (Timmy G)							               				       *
********************************************************************************************************************************

Modified from Warhammer 40k 1.2b/1.3 (<DC>Edgecrusher/Paladin and others)

I want to thank the War40K team deeply for letting me use their code to get this mod on it's feet, THX!

As of now this mod is SERVER SIDE, I hope for it to go TC, when enough models are put into it.

INSTALLATION OF THIS MOD
------------ -- ---- ---

=================================================================================================
===WARNING:"IF YOU HAVE ALREADY INSTALLED A PREVIOUS VERSION OF STARSIEGECRAFT THEN DELETE THE===
====================STARSIEGECRAFT DIRECTORY BEFORE INSTALLING A NEW VERSION"====================
=================================================================================================
==											       ==
==    1.  Make a StarSiegeCraft directory in your main Tribes directory (Spell it right!)      ==
==    2.  Unzip the *.cs files of StarSiegeCraft.zip into the StarSiegeCraft directory         ==
==    3.  Create a folder named scripts in the StarSiegeCraft folder 			       ==
==    4.  Unzip SSCScripts.zip into that scripts folder					       ==
==											       ==
=================================================================================================
=================================================================================================
 _____________________________________________________________________________________________________________________________________________
| /_________________________________________________________________________________________________________________________________________\ |
|/|     		 _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _        |\|
|||   /\		/													    \	    |||
|||  //\\______________ |Next, make a shortcut of Tribes.exe, and set its properties as follows:				    |	    |||
||| //__Non-Dedicated__||													    |       |||
||| \\_//========___|   |C:\Dynamix\Tribes\Tribes.exe -mod StarSiegeCraft (assuming C:\Dynamix\Tribes is your Tribes root directory)|	    |||
| |  \//________|	\_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _/	    |||
_____//_________________ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _					    |||
     \\ 		/									      \					    |||
| |  /\\ 		|If you wish to run a dedicated server, the command line should be as follows:|					    |||
||| //_\\__________	|									      |					    |||
||| \\__Dedicated__|	|C:\Dynamix\Tribes\Tribes.exe -mod StarSiegeCraft -dedicated		      |					    |||
|||  \\//====___|       |This does require additional CPU resources to run a dedicated server.	      |					    |||
|||   \/____|   	\_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _/					    |||
|\|_________________________________________________________________________________________________________________________________________|/|
|_\_________________________________________________________________________________________________________________________________________/_|

And then just run the shortcut, be aware many things can change in the future of this mod...

Any questions, comments, bug reports, and "other" can go to this e-mail emblazoned in glowing
phosphor on your computer screen:




			          matthias@planetstarsiege.com 





The website for this mod is located at

http://www.planetstarsiege.com/ssc

-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

THOUGHTS IN MATTHIAS' BIG HEAD
-------- -- --------- --- ----

You may support, or object to any of these thoughts by e-mailing me


-)(-None right now, just balancing SSC3


If anyone has ideas, comments, or anything to say about these thoughts, this mod, or anything else please e-mail me at SC_Matthias@hotmail.com


/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\



CHANGES THROUGHOUT THE LIFE OF THIS MOD
------- ---------- --- ---- -- ---- ---
-=+=-1.19

*-Added the attachable grenade launcher to the Gauss Rifle

*-Gave the Gauss Rifle an ammo type

*-Strengthened heavy armor

*-Removed Corsair, and added Wraith

*-Weakened Infested Terran's dying explosion, by half

*-Other things I don't remember

*-Changed the turrets... now they are REALLY EVIL, remember, there are ways to get by a turret,
	Mainly cloak, use cover strategically, destroy the turret from far off (helps a lot with
	2 people that have sniper weapons), an EMP gen from an angle the turret can't hit then 
	smack it with about any weapon, oh yeh, plague can now kill turrets, again.  There are
	many other ways to kill turrets, but you can find them out, can't you? :)

-=+=-1.18

*-Put the penis curse in the mod, now called the Balls of Life

*-Added Zerg Infested Marine, people who like Zerg and Marines should check this one out...

*-Added Infestation Juices for Infested Marine, you know, the stuff that goes !BOOM!

*-Added Infested Burst Laser (more powerful than the "other" one we all know about)

*-Added the way cool Infested Gauss Rifle

*-Added the infested flame thrower (Extremely strong, but uses the Infested's blood for napalm, so you get hurt by using it)

*-Gauss Pistol will not detach weapons from people, but is instead stronger, I have found it moderately efficient against heavies

*-C10 canister rifle cannot be thrown, certain people would shoot, throw the weapon, pick it up and get around the reload time in this manner of cheesiness

*-Reload on various vehicles changed

*-Projectiles on various vehicles changed

*-Upped Protoss snipe weapons

*-Removed force fields, people cheesed with them WAY too much

*-Strengthened heavy armor

*-Changed the turrets...


-=+=-1.175-1.0

*-Made burst laser more "bursty" (Shoots twice as fast with half the damage it used to do with each shot)
*-Shortened range of gauss rifle
*-Changed several death messages
*-Changed Zerg vehicle projectiles
*-Several weapons should be able to harm vehicles now, before they did no damage
*-Zerg vehicles can now hurt themselves
*-COMPLETELY REMOVED DEMETABOLIZERS- due to Moo the Zerg's constant complaining, oh well it was fun while it lasted, LOL
*-Slightly strengthened Plague, and increased energy drain from target, energy usage stayed same
*-Gemini launcher has faster fire rate
*-Switched dropship and shuttle projectiles around, now they seem to reflect their race a bit more.
*-Just remembered I need to change my web site to reflect these changes, later all!
*-Strengthened the flak cannon, I had made it too weak, oops
*-Added Devourer flying Zerg strain, poisons people
*-Added Guardian flying Zerg strain
*-Added Mutalisk flying Zerg strain, has the popular glave wurm, but stronger, "I hope those 3 toys make you happier Moo, now people might not be able to smack a demetabolizer on you as often when you're in a vehicle, or flying Zerg strain or whatever"
*-Fixed the gauss pistol and it, hopefully, will detach weapons from others now, also is much more accurate than before
*-Reduced energy needed to use Plague per second, still only the Ultralisk has enough energy to use it effectively
*-Changed the Terran's Spore Demetabolizer into a grenade projectile
*-Added two lovely little beauties that should make the game a lot more even, the two Spore Demetabolizers, that instantly kill any Zerg scum in it's radius, although you only get 3 shots with it.  Also good for jumping yourself, since it won't do damage to Terran or Protoss
*-Name change in mod, from the StarCraft mod to the StarsiegeCraft mod, changed due to copyright reasons
*-Weakened the Flak Cannon, it was way too strong before
*-Added the flak cannon for Terran with 2 fire modes, shell and spray
*-Added the Psionic Anchor Grenade for the Archon
*-Added the Flak Grenade for the Vulture
*-Removed the Repair turret, as it wouldn't work if TD was off, and most people like Team Damage off, so there would be no point to it
*-Made weapon text white, to make more noticable, then maybe people will stop asking "Wat does dis wepun do?"
*-Made Protoss and Terran armors/weapons/packs/war gear available at a vehicle station, to even lessen the Inventory lines, and so incase you got the wrong armor, you don't have to go all the way back and change armors
*-Fixed Carrier projectile bug where it would travel through terrain
*-Changed starting equipment, no one ever used the arclite gun, so the fission cutter replaced it in the starting loadout
*-Edited numerous weapons to make more balanced *cough* plague, *WHEEZ* !<DC>Wyvern! *cough*, ;)
*-Added the Particle Cannon to the protoss armaments, with 3 modes of fire, GRENADE, MISSILE, AND SPREAD
*-Added the Psionic Receptive to the protoss armaments, with 3 modes of fire, DISC, GRENADE, and SNIPER, people asked me where the popular disc launcher went, here it is!
*-Added the gauss pistol, moderately strengthed, but is able to knock weapons out of people's hands, used correctly could really mess someone up
*-Added in the Ultralisk armor, with the Plasma Metamorphosis weapon, where the plasma has a small chance to go "out of control" and do tons of damage
*-The repair turret was "completed", although still needs work, won't repair something that has shields on, sometimes doesn't repair machinery, but will repair people
*-Armors, Weapons, etc. except the builder armor and the repair turret available at remote inventory stations
*-I took Doe Young's idea of a StarCraft mod, and Paladin's WH40K 1.2b, and tried to make something amazing!
*-Other things I don't really remember that well, although I know I did em :D

=================================================================================================================================
