
$CanPilot = 1;
$CanRide = 2;

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // ARMOR 
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Deathmatch
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[dmarmor] = 4;
$DamageScale[dmarmor, $LandingDamageType] = 1.0;
$DamageScale[dmarmor, $ImpactDamageType] = 1.0;
$DamageScale[dmarmor, $CrushDamageType] = 1.0;
$DamageScale[dmarmor, $BulletDamageType] = 1.0;
$DamageScale[dmarmor, $PlasmaDamageType] = 1.0;
$DamageScale[dmarmor, $EnergyDamageType] = 1.0;
$DamageScale[dmarmor, $ExplosionDamageType] = 1.0;
$DamageScale[dmarmor, $MissileDamageType] = 1.0;
$DamageScale[dmarmor, $ShrapnelDamageType] = 1.0;
$DamageScale[dmarmor, $DebrisDamageType] = 1.0;
$DamageScale[dmarmor, $LaserDamageType] = 1.0;
$DamageScale[dmarmor, $MortarDamageType] = 1.0;
$DamageScale[dmarmor, $BlasterDamageType] = 1.0;
$DamageScale[dmarmor, $ElectricityDamageType] = 1.0;
$DamageScale[dmarmor, $MineDamageType] = 1.0;
$DamageScale[dmarmor, $SniperDamageType] = 1.0;
$DamageScale[dmarmor, $FlashDamageType] = 1.0;
$DamageScale[dmarmor, $MeltaDamageType] = 1.0;
$DamageScale[dmarmor, $DeathDamageType] = 1.0;
$DamageScale[dmarmor, $FlamerDamageType] = 1.0;
$DamageScale[dmarmor, $DDamageType] = 0.1;
$DamageScale[dmarmor, $ShurikenDamageType] = 1.0;
$DamageScale[dmarmor, $ReaperDamageType] = 1.0;
$DamageScale[dmarmor, $ShellDamageType] = 1.0;
 //
$VehicleUse[dmarmor, Wraith] = $CanRide;
$VehicleUse[dmarmor, Interceptor] = $CanRide;
$VehicleUse[dmarmor, Scout] = $CanRide;
$VehicleUse[dmarmor, LAPC] = $CanRide;
$VehicleUse[dmarmor, HAPC] = $CanRide;

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Deathmatch
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[dmfemale] = 4;
$DamageScale[dmfemale, $LandingDamageType] = 1.0;
$DamageScale[dmfemale, $ImpactDamageType] = 1.0;
$DamageScale[dmfemale, $CrushDamageType] = 1.0;
$DamageScale[dmfemale, $BulletDamageType] = 1.0;
$DamageScale[dmfemale, $PlasmaDamageType] = 1.0;
$DamageScale[dmfemale, $EnergyDamageType] = 1.0;
$DamageScale[dmfemale, $ExplosionDamageType] = 1.0;
$DamageScale[dmfemale, $MissileDamageType] = 1.0;
$DamageScale[dmfemale, $ShrapnelDamageType] = 1.0;
$DamageScale[dmfemale, $DebrisDamageType] = 1.0;
$DamageScale[dmfemale, $LaserDamageType] = 1.0;
$DamageScale[dmfemale, $MortarDamageType] = 1.0;
$DamageScale[dmfemale, $BlasterDamageType] = 1.0;
$DamageScale[dmfemale, $ElectricityDamageType] = 1.0;
$DamageScale[dmfemale, $MineDamageType] = 1.0;
$DamageScale[dmfemale, $SniperDamageType] = 1.0;
$DamageScale[dmfemale, $FlashDamageType] = 1.0;
$DamageScale[dmfemale, $MeltaDamageType] = 1.0;
$DamageScale[dmfemale, $DeathDamageType] = 1.0;
$DamageScale[dmfemale, $FlamerDamageType] = 1.0;
$DamageScale[dmfemale, $DDamageType] = 0.1;
$DamageScale[dmfemale, $ShurikenDamageType] = 1.0;
$DamageScale[dmfemale, $ReaperDamageType] = 1.0;
$DamageScale[dmfemale, $ShellDamageType] = 1.0;

 //
$VehicleUse[dmfemale, Wraith] = $CanRide;
$VehicleUse[dmfemale, Interceptor] = $CanRide;
$VehicleUse[dmfemale, Scout] = $CanRide;
$VehicleUse[dmfemale, LAPC] = $CanRide;
$VehicleUse[dmfemale, HAPC] = $CanRide;

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Scout Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormScout] = 3;
$DamageScale[armormScout, $LandingDamageType] = 0.5;
$DamageScale[armormScout, $ImpactDamageType] = 0.5;
$DamageScale[armormScout, $CrushDamageType] = 0.5;
$DamageScale[armormScout, $BulletDamageType] = 0.8;
$DamageScale[armormScout, $PlasmaDamageType] = 1.0;
$DamageScale[armormScout, $EnergyDamageType] = 1.3;
$DamageScale[armormScout, $ExplosionDamageType] = 1.0;
$DamageScale[armormScout, $MissileDamageType] = 1.0;
$DamageScale[armormScout, $DebrisDamageType] = 1.2;
$DamageScale[armormScout, $ShrapnelDamageType] = 1.2;
$DamageScale[armormScout, $LaserDamageType] = 1.2;
$DamageScale[armormScout, $MortarDamageType] = 1.3;
$DamageScale[armormScout, $BlasterDamageType] = 1.3;
$DamageScale[armormScout, $ElectricityDamageType] = 1.0;
$DamageScale[armormScout, $MineDamageType] = 1.2;
$DamageScale[armormScout, $SniperDamageType] = 1.0;
$DamageScale[armormScout, $FlashDamageType] = 1.0;
$DamageScale[armormScout, $MeltaDamageType] = 1.0;
$DamageScale[armormScout, $DeathDamageType] = 1.0;
$DamageScale[armormScout, $FlamerDamageType] = 1.0;
$DamageScale[armormScout, $DDamageType] = 0.1;
$DamageScale[armormScout, $ShurikenDamageType] = 1.0;
$DamageScale[armormScout, $ReaperDamageType] = 1.0;
$DamageScale[armormScout, $ShellDamageType] = 1.0;
$DamageScale[armormScout, $PsiDamageType] = 1.0;
 //
$VehicleUse[armormScout, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armormScout, Interceptor] = $CanRide;
$VehicleUse[armormScout, Scout] = $CanRide;
$VehicleUse[armormScout, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armormScout, HAPC] = $CanRide;
$VehicleUse[armormScout, DogFighter] = $CanRide;
$VehicleUse[armormScout, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armormScout, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armormScout, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Scout Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfScout] = 3;
$DamageScale[armorfScout, $LandingDamageType] = 0.5;
$DamageScale[armorfScout, $ImpactDamageType] = 0.5;
$DamageScale[armorfScout, $CrushDamageType] = 0.5;
$DamageScale[armorfScout, $BulletDamageType] = 0.8;
$DamageScale[armorfScout, $PlasmaDamageType] = 1.0;
$DamageScale[armorfScout, $EnergyDamageType] = 1.3;
$DamageScale[armorfScout, $ExplosionDamageType] = 1.0;
$DamageScale[armorfScout, $MissileDamageType] = 1.0;
$DamageScale[armorfScout, $ShrapnelDamageType] = 1.2;
$DamageScale[armorfScout, $DebrisDamageType] = 1.2;
$DamageScale[armorfScout, $LaserDamageType] = 1.0;
$DamageScale[armorfScout, $MortarDamageType] = 1.3;
$DamageScale[armorfScout, $BlasterDamageType] = 1.3;
$DamageScale[armorfScout, $ElectricityDamageType] = 1.0;
$DamageScale[armorfScout, $MineDamageType] = 1.2;
$DamageScale[armorfScout, $SniperDamageType] = 1.0;
$DamageScale[armorfScout, $FlashDamageType] = 1.0;
$DamageScale[armorfScout, $MeltaDamageType] = 1.0;
$DamageScale[armorfScout, $DeathDamageType] = 1.0;
$DamageScale[armorfScout, $FlamerDamageType] = 1.0;
$DamageScale[armorfScout, $DDamageType] = 0.1;
$DamageScale[armorfScout, $ShurikenDamageType] = 1.0;
$DamageScale[armorfScout, $ReaperDamageType] = 1.0;
$DamageScale[armorfScout, $ShellDamageType] = 1.0;
$DamageScale[armorfScout, $PsiDamageType] = 1.0;
 //
$VehicleUse[armorfScout, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armorfScout, Interceptor] = $CanRide;
$VehicleUse[armorfScout, Scout] = $CanRide;
$VehicleUse[armorfScout, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfScout, HAPC] = $CanRide;
$VehicleUse[armorfScout, DogFighter] = $CanRide;
$VehicleUse[armorfScout, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armorfScout, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armorfScout, Tempest] = $CanRide;

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Assault Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormSpy] = 3;
$DamageScale[armormSpy, $LandingDamageType] = 0.5;
$DamageScale[armormSpy, $ImpactDamageType] = 0.5;
$DamageScale[armormSpy, $CrushDamageType] = 0.5;
$DamageScale[armormSpy, $BulletDamageType] = 0.5;
$DamageScale[armormSpy, $PlasmaDamageType] = 1.2;
$DamageScale[armormSpy, $EnergyDamageType] = 1.3;
$DamageScale[armormSpy, $ExplosionDamageType] = 1.2;
$DamageScale[armormSpy, $MissileDamageType] = 1.3;
$DamageScale[armormSpy, $DebrisDamageType] = 1.3;
$DamageScale[armormSpy, $ShrapnelDamageType] = 1.3;
$DamageScale[armormSpy, $LaserDamageType] = 1.0;
$DamageScale[armormSpy, $MortarDamageType] = 1.3;
$DamageScale[armormSpy, $BlasterDamageType] = 1.3;
$DamageScale[armormSpy, $ElectricityDamageType] = 1.0;
$DamageScale[armormSpy, $MineDamageType] = 1.2;
$DamageScale[armormSpy, $SniperDamageType] = 1.0;
$DamageScale[armormSpy, $FlashDamageType] = 1.0;
$DamageScale[armormSpy, $MeltaDamageType] = 1.0;
$DamageScale[armormSpy, $DeathDamageType] = 1.0;
$DamageScale[armormSpy, $FlamerDamageType] = 1.0;
$DamageScale[armormSpy, $DDamageType] = 0.1;
$DamageScale[armormSpy, $ShurikenDamageType] = 1.0;
$DamageScale[armormSpy, $ReaperDamageType] = 1.0;
$DamageScale[armormSpy, $ShellDamageType] = 1.0;
$DamageScale[armormSpy, $PsiDamageType] = 1.0;

 //
$VehicleUse[armormSpy, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armormSpy, Interceptor] = $CanRide;
$VehicleUse[armormSpy, Scout] =$CanRide;
$VehicleUse[armormSpy, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armormSpy, HAPC] = $CanRide;
$VehicleUse[armormSpy, DogFighter] = $CanRide;
$VehicleUse[armormSpy, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armormSpy, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armormSpy, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Assault Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfSpy] = 3;
$DamageScale[armorfSpy, $LandingDamageType] = 0.5;
$DamageScale[armorfSpy, $ImpactDamageType] = 0.5;
$DamageScale[armorfSpy, $CrushDamageType] = 0.5;
$DamageScale[armorfSpy, $BulletDamageType] = 0.5;
$DamageScale[armorfSpy, $PlasmaDamageType] = 1.2;
$DamageScale[armorfSpy, $EnergyDamageType] = 1.3;
$DamageScale[armorfSpy, $ExplosionDamageType] = 1.2;
$DamageScale[armorfSpy, $MissileDamageType] = 1.3;
$DamageScale[armorfSpy, $DebrisDamageType] = 1.3;
$DamageScale[armorfSpy, $ShrapnelDamageType] = 1.3;
$DamageScale[armorfSpy, $LaserDamageType] = 1.0;
$DamageScale[armorfSpy, $MortarDamageType] = 1.3;
$DamageScale[armorfSpy, $BlasterDamageType] = 1.3;
$DamageScale[armorfSpy, $ElectricityDamageType] = 1.0;
$DamageScale[armorfSpy, $MineDamageType] = 1.2;
$DamageScale[armorfSpy, $SniperDamageType] = 1.0;
$DamageScale[armorfSpy, $FlashDamageType] = 1.0;
$DamageScale[armorfSpy, $MeltaDamageType] = 1.0;
$DamageScale[armorfSpy, $DeathDamageType] = 1.0;
$DamageScale[armorfSpy, $FlamerDamageType] = 1.0;
$DamageScale[armorfSpy, $DDamageType] = 0.1;
$DamageScale[armorfSpy, $ShurikenDamageType] = 1.0;
$DamageScale[armorfSpy, $ReaperDamageType] = 1.0;
$DamageScale[armorfSpy, $ShellDamageType] = 1.0;
$DamageScale[armorfSpy, $PsiDamageType] = 1.0;

 // 
$VehicleUse[armorfSpy, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armorfSpy, Interceptor] = $CanRide;
$VehicleUse[armorfSpy, Scout] =$CanRide;
$VehicleUse[armorfSpy, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfSpy, HAPC] = $CanRide;
$VehicleUse[armorfSpy, DogFighter] = $CanRide;
$VehicleUse[armorfSpy, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armorfSpy, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armorfSpy, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Guardian Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormSniper] = 3;
$DamageScale[armormSniper, $LandingDamageType] = 0.5;
$DamageScale[armormSniper, $ImpactDamageType] = 0.5;
$DamageScale[armormSniper, $CrushDamageType] = 0.5;
$DamageScale[armormSniper, $BulletDamageType] = 1.2;
$DamageScale[armormSniper, $PlasmaDamageType] = 1.0;
$DamageScale[armormSniper, $EnergyDamageType] = 0.5;
$DamageScale[armormSniper, $ExplosionDamageType] = 1.0;
$DamageScale[armormSniper, $MissileDamageType] = 1.0;
$DamageScale[armormSniper, $DebrisDamageType] = 1.2;
$DamageScale[armormSniper, $ShrapnelDamageType] = 1.2;
$DamageScale[armormSniper, $LaserDamageType] = 1.0;
$DamageScale[armormSniper, $MortarDamageType] = 1.3;
$DamageScale[armormSniper, $BlasterDamageType] = 1.3;
$DamageScale[armormSniper, $ElectricityDamageType] = 1.0;
$DamageScale[armormSniper, $MineDamageType] = 1.2;
$DamageScale[armormSniper, $SniperDamageType] = 1.0;
$DamageScale[armormSniper, $FlashDamageType] = 1.0;
$DamageScale[armormSniper, $MeltaDamageType] = 1.0;
$DamageScale[armormSniper, $DeathDamageType] = 1.0;
$DamageScale[armormSniper, $FlamerDamageType] = 1.0;
$DamageScale[armormSniper, $DDamageType] = 0.1;
$DamageScale[armormSniper, $ShurikenDamageType] = 0.5;
$DamageScale[armormSniper, $ReaperDamageType] = 0.5;
$DamageScale[armormSniper, $ShellDamageType] = 1.0;
$DamageScale[armormSniper, $PsiDamageType] = 1.0;

 //
$VehicleUse[armormSniper, Wraith] = $CanRide;
$VehicleUse[armormSniper, Interceptor] = $CanPilot | $CanRide;
$VehicleUse[armormSniper, Scout] = $CanPilot | $CanRide;
$VehicleUse[armormSniper, LAPC] = $CanRide;
$VehicleUse[armormSniper, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armormSniper, DogFighter] = $CanPilot | $CanRide;
$VehicleUse[armormSniper, QuickLPC] = $CanRide;
$VehicleUse[armormSniper, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armormSniper, Speeder] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Guardian Armor 
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfSniper] = 3;
$DamageScale[armorfSniper, $LandingDamageType] = 0.5;
$DamageScale[armorfSniper, $ImpactDamageType] = 0.5;
$DamageScale[armorfSniper, $CrushDamageType] = 0.5;
$DamageScale[armorfSniper, $BulletDamageType] = 1.2;
$DamageScale[armorfSniper, $PlasmaDamageType] = 1.0;
$DamageScale[armorfSniper, $EnergyDamageType] = 0.5;
$DamageScale[armorfSniper, $ExplosionDamageType] = 1.0;
$DamageScale[armorfSniper, $MissileDamageType] = 1.0;
$DamageScale[armorfSniper, $ShrapnelDamageType] = 1.2;
$DamageScale[armorfSniper, $DebrisDamageType] = 1.2;
$DamageScale[armorfSniper, $LaserDamageType] = 1.0;
$DamageScale[armorfSniper, $MortarDamageType] = 1.3;
$DamageScale[armorfSniper, $BlasterDamageType] = 1.3;
$DamageScale[armorfSniper, $ElectricityDamageType] = 1.0;
$DamageScale[armorfSniper, $MineDamageType] = 1.2;
$DamageScale[armorfSniper, $SniperDamageType] = 1.0;
$DamageScale[armorfSniper, $FlashDamageType] = 1.0;
$DamageScale[armorfSniper, $MeltaDamageType] = 1.0;
$DamageScale[armorfSniper, $DeathDamageType] = 1.0;
$DamageScale[armorfSniper, $FlamerDamageType] = 1.0;
$DamageScale[armorfSniper, $DDamageType] = 0.1;
$DamageScale[armorfSniper, $ShurikenDamageType] = 0.5;
$DamageScale[armorfSniper, $ReaperDamageType] = 0.5;
$DamageScale[armorfSniper, $ShellDamageType] = 1.0;
$DamageScale[armorfSniper, $PsiDamageType] = 1.0;

 //
$VehicleUse[armorfSniper, Wraith] = $CanRide;
$VehicleUse[armorfSniper, Interceptor] = $CanPilot | $CanRide;
$VehicleUse[armorfSniper, Scout] = $CanPilot | $CanRide;
$VehicleUse[armorfSniper, LAPC] = $CanRide;
$VehicleUse[armorfSniper, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfSniper, DogFighter] = $CanPilot | $CanRide;
$VehicleUse[armorfSniper, QuickLPC] = $CanRide;
$VehicleUse[armorfSniper, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armorfSniper, Speeder] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Tactical Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormMercenary] = 3;
$DamageScale[armormMercenary, $LandingDamageType] = 1.0;
$DamageScale[armormMercenary, $ImpactDamageType] = 1.0;
$DamageScale[armormMercenary, $CrushDamageType] = 0.5;
$DamageScale[armormMercenary, $BulletDamageType] = 0.5;
$DamageScale[armormMercenary, $PlasmaDamageType] = 1.0;
$DamageScale[armormMercenary, $EnergyDamageType] = 1.0;
$DamageScale[armormMercenary, $ExplosionDamageType] = 1.0;
$DamageScale[armormMercenary, $MissileDamageType] = 1.0;
$DamageScale[armormMercenary, $ShrapnelDamageType] = 1.0;
$DamageScale[armormMercenary, $DebrisDamageType] = 1.0;
$DamageScale[armormMercenary, $LaserDamageType] = 0.8;
$DamageScale[armormMercenary, $MortarDamageType] = 1.0;
$DamageScale[armormMercenary, $BlasterDamageType] = 1.0;
$DamageScale[armormMercenary, $ElectricityDamageType] = 1.0;
$DamageScale[armormMercenary, $MineDamageType] = 1.0;
$DamageScale[armormMercenary, $SniperDamageType] = 1.0;
$DamageScale[armormMercenary, $FlashDamageType] = 1.0;
$DamageScale[armormMercenary, $MeltaDamageType] = 1.0;
$DamageScale[armormMercenary, $DeathDamageType] = 1.0;
$DamageScale[armormMercenary, $FlamerDamageType] = 1.0;
$DamageScale[armormMercenary, $DDamageType] = 0.1;
$DamageScale[armormMercenary, $ShurikenDamageType] = 1.0;
$DamageScale[armormMercenary, $ReaperDamageType] = 1.0;
$DamageScale[armormMercenary, $ShellDamageType] = 1.0;
$DamageScale[armormMercenary, $PsiDamageType] = 1.0;
 //
$VehicleUse[armormMercenary, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armormMercenary, Interceptor] = $CanRide;
$VehicleUse[armormMercenary, Scout] = $CanRide;
$VehicleUse[armormMercenary, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armormMercenary, HAPC] = $CanRide;
$VehicleUse[armormMercenary, DogFighter] = $CanRide;
$VehicleUse[armormMercenary, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armormMercenary, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armormMercenary, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Tactical Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfMercenary] = 3;
$DamageScale[armorfMercenary, $LandingDamageType] = 1.0;
$DamageScale[armorfMercenary, $ImpactDamageType] = 1.0;
$DamageScale[armorfMercenary, $CrushDamageType] = 0.5;
$DamageScale[armorfMercenary, $BulletDamageType] = 0.5;
$DamageScale[armorfMercenary, $EnergyDamageType] = 1.0;
$DamageScale[armorfMercenary, $PlasmaDamageType] = 1.0;
$DamageScale[armorfMercenary, $ExplosionDamageType] = 1.0;
$DamageScale[armorfMercenary, $MissileDamageType] = 1.0;
$DamageScale[armorfMercenary, $ShrapnelDamageType] = 1.0;
$DamageScale[armorfMercenary, $DebrisDamageType] = 1.0;
$DamageScale[armorfMercenary, $LaserDamageType] = 0.8;
$DamageScale[armorfMercenary, $MortarDamageType] = 1.0;
$DamageScale[armorfMercenary, $BlasterDamageType] = 1.0;
$DamageScale[armorfMercenary, $ElectricityDamageType] = 1.0;
$DamageScale[armorfMercenary, $MineDamageType] = 1.0;
$DamageScale[armorfMercenary, $SniperDamageType] = 1.0;
$DamageScale[armorfMercenary, $FlashDamageType] = 1.0;
$DamageScale[armorfMercenary, $MeltaDamageType] = 1.0;
$DamageScale[armorfMercenary, $DeathDamageType] = 1.0;
$DamageScale[armorfMercenary, $FlamerDamageType] = 1.0;
$DamageScale[armorfMercenary, $DDamageType] = 0.1;
$DamageScale[armorfMercenary, $ShurikenDamageType] = 1.0;
$DamageScale[armorfMercenary, $ReaperDamageType] = 1.0;
$DamageScale[armorfMercenary, $ShellDamageType] = 1.0;
$DamageScale[armorfMercenary, $PsiDamageType] = 1.0;

 //
$VehicleUse[armorfMercenary, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armorfMercenary, Interceptor] = $CanRide;
$VehicleUse[armorfMercenary, Scout] = $CanRide;
$VehicleUse[armorfMercenary, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfMercenary, HAPC] = $CanRide;
$VehicleUse[armorfMercenary, DogFighter] = $CanRide;
$VehicleUse[armorfMercenary, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armorfMercenary, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armorfMercenary, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Tech Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormEngineer] = 3;
$DamageScale[armormEngineer, $LandingDamageType] = 0.5;
$DamageScale[armormEngineer, $ImpactDamageType] = 0.5;
$DamageScale[armormEngineer, $CrushDamageType] = 0.5;
$DamageScale[armormEngineer, $BulletDamageType] = 0.3;
$DamageScale[armormEngineer, $PlasmaDamageType] = 0.3;
$DamageScale[armormEngineer, $EnergyDamageType] = 0.3;
$DamageScale[armormEngineer, $ExplosionDamageType] = 1.0;
$DamageScale[armormEngineer, $MissileDamageType] = 1.0;
$DamageScale[armormEngineer, $ShrapnelDamageType] = 1.0;
$DamageScale[armormEngineer, $DebrisDamageType] = 1.0;
$DamageScale[armormEngineer, $LaserDamageType] = 0.3;
$DamageScale[armormEngineer, $MortarDamageType] = 1.0;
$DamageScale[armormEngineer, $BlasterDamageType] = 0.3;
$DamageScale[armormEngineer, $ElectricityDamageType] = 0.3;
$DamageScale[armormEngineer, $MineDamageType] = 1.0;
$DamageScale[armormEngineer, $SniperDamageType] = 0.3;
$DamageScale[armormEngineer, $FlashDamageType] = 1.0;
$DamageScale[armormEngineer, $MeltaDamageType] = 0.3;
$DamageScale[armormEngineer, $DeathDamageType] = 0.3;
$DamageScale[armormEngineer, $FlamerDamageType] = 0.3;
$DamageScale[armormEngineer, $DDamageType] = 0.1;
$DamageScale[armormEngineer, $ShurikenDamageType] = 0.3;
$DamageScale[armormEngineer, $ReaperDamageType] = 0.3;
$DamageScale[armormEngineer, $ShellDamageType] = 0.3;
$DamageScale[armormEngineer, $PsiDamageType] = 1.0;
 //
$VehicleUse[armormEngineer, Wraith] = $CanRide;
$VehicleUse[armormEngineer, Interceptor] = $CanRide;
$VehicleUse[armormEngineer, Scout] = $CanRide;
$VehicleUse[armormEngineer, LAPC] = $CanRide;
$VehicleUse[armormEngineer, HAPC] = $CanRide;
$VehicleUse[armormEngineer, DogFighter] = $CanRide;
$VehicleUse[armormEngineer, QuickLPC] = $CanRide;
$VehicleUse[armormEngineer, Speeder] = $CanRide;
$VehicleUse[armormEngineer, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Tech Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfEngineer] = 3;
$DamageScale[armorfEngineer, $LandingDamageType] = 0.5;
$DamageScale[armorfEngineer, $ImpactDamageType] = 0.5;
$DamageScale[armorfEngineer, $CrushDamageType] = 0.5;
$DamageScale[armorfEngineer, $BulletDamageType] = 0.3;
$DamageScale[armorfEngineer, $PlasmaDamageType] = 0.3;
$DamageScale[armorfEngineer, $EnergyDamageType] = 0.3;
$DamageScale[armorfEngineer, $ExplosionDamageType] = 1.0;
$DamageScale[armorfEngineer, $MissileDamageType] = 1.0;
$DamageScale[armorfEngineer, $ShrapnelDamageType] = 1.0;
$DamageScale[armorfEngineer, $DebrisDamageType] = 1.0;
$DamageScale[armorfEngineer, $LaserDamageType] = 0.3;
$DamageScale[armorfEngineer, $MortarDamageType] = 1.0;
$DamageScale[armorfEngineer, $BlasterDamageType] = 0.3;
$DamageScale[armorfEngineer, $ElectricityDamageType] = 0.3;
$DamageScale[armorfEngineer, $MineDamageType] = 1.0;
$DamageScale[armorfEngineer, $SniperDamageType] = 0.5;
$DamageScale[armorfEngineer, $FlashDamageType] = 1.0;
$DamageScale[armorfEngineer, $MeltaDamageType] = 0.3;
$DamageScale[armorfEngineer, $DeathDamageType] = 0.3;
$DamageScale[armorfEngineer, $FlamerDamageType] = 0.3;
$DamageScale[armorfEngineer, $DDamageType] = 0.1;
$DamageScale[armorfEngineer, $ShurikenDamageType] = 0.3;
$DamageScale[armorfEngineer, $ReaperDamageType] = 0.3;
$DamageScale[armorfEngineer, $ShellDamageType] = 0.3;
$DamageScale[armorfEngineer, $PsiDamageType] = 1.0;
 //
$VehicleUse[armorfEngineer, Wraith] = $CanRide;
$VehicleUse[armorfEngineer, Interceptor] = $CanRide;
$VehicleUse[armorfEngineer, Scout] = $CanRide;
$VehicleUse[armorfEngineer, LAPC] = $CanRide;
$VehicleUse[armorfEngineer, HAPC] = $CanRide;
$VehicleUse[armorfEngineer, DogFighter] = $CanRide;
$VehicleUse[armorfEngineer, QuickLPC] = $CanRide;
$VehicleUse[armorfEngineer, Speeder] = $CanRide;
$VehicleUse[armorfEngineer, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Devastator Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormBurster] = 3;
$DamageScale[armormBurster, $LandingDamageType] = 1.0;
$DamageScale[armormBurster, $ImpactDamageType] = 1.0;
$DamageScale[armormBurster, $CrushDamageType] = 0.5;
$DamageScale[armormBurster, $BulletDamageType] = 0.5;
$DamageScale[armormBurster, $PlasmaDamageType] = 0.5;
$DamageScale[armormBurster, $EnergyDamageType] = 1.1;
$DamageScale[armormBurster, $ExplosionDamageType] = 0.5;
$DamageScale[armormBurster, $MissileDamageType] = 1.5;
$DamageScale[armormBurster, $ShrapnelDamageType] = 0.5;
$DamageScale[armormBurster, $DebrisDamageType] = 1.0;
$DamageScale[armormBurster, $LaserDamageType] = 0.5;
$DamageScale[armormBurster, $MortarDamageType] = 0.5;
$DamageScale[armormBurster, $BlasterDamageType] = 1.2;
$DamageScale[armormBurster, $ElectricityDamageType] = 1.0;
$DamageScale[armormBurster, $MineDamageType] = 0.5;
$DamageScale[armormBurster, $SniperDamageType] = 1.0;
$DamageScale[armormBurster, $FlashDamageType] = 1.0;
$DamageScale[armormBurster, $MeltaDamageType] = 1.0;
$DamageScale[armormBurster, $DeathDamageType] = 1.0;
$DamageScale[armormBurster, $FlamerDamageType] = 1.0;
$DamageScale[armormBurster, $DDamageType] = 0.1;
$DamageScale[armormBurster, $ShurikenDamageType] = 1.0;
$DamageScale[armormBurster, $ReaperDamageType] = 1.0;
$DamageScale[armormBurster, $ShellDamageType] = 1.0;
$DamageScale[armormBurster, $PsiDamageType] = 1.0;
 // 
$VehicleUse[armormBurster, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armormBurster, Interceptor] = $CanRide;
$VehicleUse[armormBurster, Scout] = $CanRide;
$VehicleUse[armormBurster, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armormBurster, HAPC] = $CanRide;
$VehicleUse[armormBurster, DogFighter] = $CanRide;
$VehicleUse[armormBurster, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armormBurster, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armormBurster, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Devastator Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfBurster] = 3;
$DamageScale[armorfBurster, $LandingDamageType] = 1.0;
$DamageScale[armorfBurster, $ImpactDamageType] = 1.0;
$DamageScale[armorfBurster, $CrushDamageType] = 0.5;
$DamageScale[armorfBurster, $BulletDamageType] = 0.5;
$DamageScale[armorfBurster, $PlasmaDamageType] = 0.5;
$DamageScale[armorfBurster, $EnergyDamageType] = 1.1;
$DamageScale[armorfBurster, $ExplosionDamageType] = 0.5;
$DamageScale[armorfBurster, $MissileDamageType] = 1.5;
$DamageScale[armorfBurster, $ShrapnelDamageType] = 0.5;
$DamageScale[armorfBurster, $DebrisDamageType] = 1.0;
$DamageScale[armorfBurster, $LaserDamageType] = 0.5;
$DamageScale[armorfBurster, $MortarDamageType] = 0.5;
$DamageScale[armorfBurster, $BlasterDamageType] = 1.2;
$DamageScale[armorfBurster, $ElectricityDamageType] = 1.0;
$DamageScale[armorfBurster, $MineDamageType] = 0.5;
$DamageScale[armorfBurster, $SniperDamageType] = 1.0;
$DamageScale[armorfBurster, $FlashDamageType] = 1.0;
$DamageScale[armorfBurster, $MeltaDamageType] = 1.0;
$DamageScale[armorfBurster, $DeathDamageType] = 1.0;
$DamageScale[armorfBurster, $FlamerDamageType] = 1.0;
$DamageScale[armorfBurster, $DDamageType] = 0.1;
$DamageScale[armorfBurster, $ShurikenDamageType] = 1.0;
$DamageScale[armorfBurster, $ReaperDamageType] = 1.0;
$DamageScale[armorfBurster, $ShellDamageType] = 1.0;
$DamageScale[armorfBurster, $PsiDamageType] = 1.0;
 // 
$VehicleUse[armorfBurster, Wraith] = $CanPilot | $CanRide;
$VehicleUse[armorfBurster, Interceptor] = $CanRide;
$VehicleUse[armorfBurster, Scout] = $CanRide;
$VehicleUse[armorfBurster, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfBurster, HAPC] = $CanRide;
$VehicleUse[armorfBurster, DogFighter] = $CanRide;
$VehicleUse[armorfBurster, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armorfBurster, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armorfBurster, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Wraithguard Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormAlien] = 3;
$DamageScale[armormAlien, $LandingDamageType] = 0.5;
$DamageScale[armormAlien, $ImpactDamageType] = 1.0;
$DamageScale[armormAlien, $CrushDamageType] = 0.5;
$DamageScale[armormAlien, $BulletDamageType] = 1.0;
$DamageScale[armormAlien, $PlasmaDamageType] = 1.0;
$DamageScale[armormAlien, $EnergyDamageType] = 0.5;
$DamageScale[armormAlien, $ExplosionDamageType] = 0.5;
$DamageScale[armormAlien, $MissileDamageType] = 1.0;
$DamageScale[armormAlien, $ShrapnelDamageType] = 1.0;
$DamageScale[armormAlien, $DebrisDamageType] = 1.0;
$DamageScale[armormAlien, $LaserDamageType] = 0.5;
$DamageScale[armormAlien, $MortarDamageType] = 1.2;
$DamageScale[armormAlien, $BlasterDamageType] = 0.5;
$DamageScale[armormAlien, $ElectricityDamageType] = 0.5;
$DamageScale[armormAlien, $MineDamageType] = 1.0;
$DamageScale[armormAlien, $SniperDamageType] = 1.0;
$DamageScale[armormAlien, $FlashDamageType] = 2.0;
$DamageScale[armormAlien, $MeltaDamageType] = 1.0;
$DamageScale[armormAlien, $DeathDamageType] = 1.0;
$DamageScale[armormAlien, $FlamerDamageType] = 1.0;
$DamageScale[armormAlien, $DDamageType] = 0.1;
$DamageScale[armormAlien, $ShurikenDamageType] = 1.0;
$DamageScale[armormAlien, $ReaperDamageType] = 1.0;
$DamageScale[armormAlien, $ShellDamageType] = 1.0;
$DamageScale[armormAlien, $PsiDamageType] = 1.0;
 //
$VehicleUse[armormAlien, Wraith] = $CanRide;
$VehicleUse[armormAlien, Interceptor] = $CanRide;
$VehicleUse[armormAlien, Scout] = $CanRide;
$VehicleUse[armormAlien, LAPC] = $CanRide;
$VehicleUse[armormAlien, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armormAlien, DogFighter] = $CanRide;
$VehicleUse[armormAlien, QuickLPC] = $CanRide;
$VehicleUse[armormAlien, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armormAlien, Speeder] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Wraithguard Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfAlien] = 3;
$DamageScale[armorfAlien, $LandingDamageType] = 0.5;
$DamageScale[armorfAlien, $ImpactDamageType] = 1.0;
$DamageScale[armorfAlien, $CrushDamageType] = 0.5;
$DamageScale[armorfAlien, $BulletDamageType] = 1.0;
$DamageScale[armorfAlien, $PlasmaDamageType] = 1.0;
$DamageScale[armorfAlien, $EnergyDamageType] = 0.5;
$DamageScale[armorfAlien, $ExplosionDamageType] = 0.5;
$DamageScale[armorfAlien, $MissileDamageType] = 1.0;
$DamageScale[armorfAlien, $ShrapnelDamageType] = 1.0;
$DamageScale[armorfAlien, $DebrisDamageType] = 1.0;
$DamageScale[armorfAlien, $LaserDamageType] = 0.5;
$DamageScale[armorfAlien, $MortarDamageType] = 1.2;
$DamageScale[armorfAlien, $BlasterDamageType] = 0.5;
$DamageScale[armorfAlien, $ElectricityDamageType] = 0.5;
$DamageScale[armorfAlien, $MineDamageType] = 1.0;
$DamageScale[armorfAlien, $SniperDamageType] = 1.0;
$DamageScale[armorfAlien, $FlashDamageType] = 2.0;
$DamageScale[armorfAlien, $MeltaDamageType] = 1.0;
$DamageScale[armorfAlien, $DeathDamageType] = 1.0;
$DamageScale[armorfAlien, $FlamerDamageType] = 1.0;
$DamageScale[armorfAlien, $DDamageType] = 0.1;
$DamageScale[armorfAlien, $ShurikenDamageType] = 1.0;
$DamageScale[armorfAlien, $ReaperDamageType] = 1.0;
$DamageScale[armorfAlien, $ShellDamageType] = 1.0;
$DamageScale[armorfAlien, $PsiDamageType] = 1.0;
 // 
$VehicleUse[armorfAlien, Wraith] = $CanRide;
$VehicleUse[armorfAlien, Interceptor] = $CanRide;
$VehicleUse[armorfAlien, Scout] = $CanRide;
$VehicleUse[armorfAlien, LAPC] = $CanRide;
$VehicleUse[armorfAlien, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfAlien, DogFighter] = $CanRide;
$VehicleUse[armorfAlien, QuickLPC] = $CanRide;
$VehicleUse[armorfAlien, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armorfAlien, Speeder] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Terminator Marine Armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorCyborg] = 4;
$DamageScale[armorCyborg, $LandingDamageType] = 0.5;
$DamageScale[armorCyborg, $ImpactDamageType] = 0.4;
$DamageScale[armorCyborg, $CrushDamageType] = 0.4;
$DamageScale[armorCyborg, $BulletDamageType] = 0.3;
$DamageScale[armorCyborg, $PlasmaDamageType] = 0.4;
$DamageScale[armorCyborg, $EnergyDamageType] = 1.0;
$DamageScale[armorCyborg, $ExplosionDamageType] = 0.4;
$DamageScale[armorCyborg, $MissileDamageType] = 0.3;
$DamageScale[armorCyborg, $DebrisDamageType] = 0.3;
$DamageScale[armorCyborg, $ShrapnelDamageType] = 0.3;
$DamageScale[armorCyborg, $LaserDamageType] = 1.0;
$DamageScale[armorCyborg, $MortarDamageType] = 0.5;
$DamageScale[armorCyborg, $BlasterDamageType] = 0.3;
$DamageScale[armorCyborg, $ElectricityDamageType] = 1.0;
$DamageScale[armorCyborg, $MineDamageType] = 1.0;
$DamageScale[armorCyborg, $SniperDamageType] = 1.0;
$DamageScale[armorCyborg, $FlashDamageType] = 1.0;
$DamageScale[armorCyborg, $MeltaDamageType] = 1.0;
$DamageScale[armorCyborg, $DeathDamageType] = 0.4;
$DamageScale[armorCyborg, $FlamerDamageType] = 0.2;
$DamageScale[armorCyborg, $DDamageType] = 0.1;
$DamageScale[armorCyborg, $ShurikenDamageType] = 0.3;
$DamageScale[armorCyborg, $ReaperDamageType] = 1.5;
$DamageScale[armorCyborg, $ShellDamageType] = 0.4;
$DamageScale[armorCyborg, $PsiDamageType] = 1.0;
 //
$VehicleUse[armorCyborg, Wraith] = $CanRide;
$VehicleUse[armorCyborg, Interceptor] = $CanRide;
$VehicleUse[armorCyborg, Scout] = $CanRide;
$VehicleUse[armorCyborg, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armorCyborg, HAPC] = $CanRide;
$VehicleUse[armorCyborg, DogFighter] = $CanRide;
$VehicleUse[armorCyborg, QuickLPC] = $CanPilot | $CanRide;
$VehicleUse[armorCyborg, Speeder] = $CanPilot | $CanRide;
$VehicleUse[armorCyborg, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Ultralisk armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorAss] = 4;
$DamageScale[armorAss, $LandingDamageType] = 0.5;
$DamageScale[armorAss, $ImpactDamageType] = 1.0;
$DamageScale[armorAss, $CrushDamageType] = 0.4;
$DamageScale[armorAss, $BulletDamageType] = 0.4;
$DamageScale[armorAss, $PlasmaDamageType] = 0.8;
$DamageScale[armorAss, $EnergyDamageType] = 1.0;
$DamageScale[armorAss, $ExplosionDamageType] = 0.7;
$DamageScale[armorAss, $MissileDamageType] = 0.7;
$DamageScale[armorAss, $DebrisDamageType] = 1.0;
$DamageScale[armorAss, $ShrapnelDamageType] = 0.7;
$DamageScale[armorAss, $LaserDamageType] = 1.0;
$DamageScale[armorAss, $MortarDamageType] = 1.0;
$DamageScale[armorAss, $BlasterDamageType] = 0.6;
$DamageScale[armorAss, $ElectricityDamageType] = 1.0;
$DamageScale[armorAss, $MineDamageType] = 0.4;
$DamageScale[armorAss, $SniperDamageType] = 1.0;
$DamageScale[armorAss, $FlashDamageType] = 1.0;
$DamageScale[armorAss, $MeltaDamageType] = 1.0;
$DamageScale[armorAss, $DeathDamageType] = 1.0;
$DamageScale[armorAss, $FlamerDamageType] = 0.8;
$DamageScale[armorAss, $DDamageType] = 10.0;
$DamageScale[armorAss, $ShurikenDamageType] = 0.6;
$DamageScale[armorAss, $ReaperDamageType] = 1.0;
$DamageScale[armorAss, $ShellDamageType] = 0.5;
$DamageScale[armorAss, $PsiDamageType] = 1.0;
 //
$VehicleUse[armorAss, Wraith] = $CanRide;
$VehicleUse[armorAss, Interceptor] = $CanRide;
$VehicleUse[armorAss, Scout] = $CanRide;
$VehicleUse[armorAss, LAPC] = $CanRide;
$VehicleUse[armorAss, HAPC] = $CanRide;
$VehicleUse[armorAss, DogFighter] = $CanRide;
$VehicleUse[armorAss, QuickLPC] = $CanRide;
$VehicleUse[armorAss, Tempest] = $CanRide;
$VehicleUse[armorAss, Speeder] = $CanRide;
//$VehicleUse[armorAss, Muta] = $CanPilot;
$VehicleUse[armorAss, Guard] = $CanPilot;
$VehicleUse[armorAss, Dev] = $CanPilot;

//infested terran!

$MaxWeapons[armormInfest] = 3;
$DamageScale[armormInfest, $LandingDamageType] = 0.5;
$DamageScale[armormInfest, $ImpactDamageType] = 0.5;
$DamageScale[armormInfest, $CrushDamageType] = 0.5;
$DamageScale[armormInfest, $BulletDamageType] = 0.5;
$DamageScale[armormInfest, $PlasmaDamageType] = 1.2;
$DamageScale[armormInfest, $EnergyDamageType] = 1.3;
$DamageScale[armormInfest, $ExplosionDamageType] = 1.2;
$DamageScale[armormInfest, $MissileDamageType] = 1.3;
$DamageScale[armormInfest, $DebrisDamageType] = 1.3;
$DamageScale[armormInfest, $ShrapnelDamageType] = 1.3;
$DamageScale[armormInfest, $LaserDamageType] = 1.0;
$DamageScale[armormInfest, $MortarDamageType] = 1.3;
$DamageScale[armormInfest, $BlasterDamageType] = 1.3;
$DamageScale[armormInfest, $ElectricityDamageType] = 1.0;
$DamageScale[armormInfest, $MineDamageType] = 1.2;
$DamageScale[armormInfest, $SniperDamageType] = 1.0;
$DamageScale[armormInfest, $FlashDamageType] = 1.0;
$DamageScale[armormInfest, $MeltaDamageType] = 1.0;
$DamageScale[armormInfest, $DeathDamageType] = 1.0;
$DamageScale[armormInfest, $FlamerDamageType] = 1.0;
$DamageScale[armormInfest, $DDamageType] = 0.1;
$DamageScale[armormInfest, $ShurikenDamageType] = 1.0;
$DamageScale[armormInfest, $ReaperDamageType] = 1.0;
$DamageScale[armormInfest, $ShellDamageType] = 1.0;
$DamageScale[armormInfest, $PsiDamageType] = 1.0;

 //
$VehicleUse[armormInfest, Wraith] = $CanRide;
$VehicleUse[armormInfest, Interceptor] = $CanRide;
$VehicleUse[armormInfest, Scout] =$CanRide;
$VehicleUse[armormInfest, LAPC] = $CanRide;
$VehicleUse[armormInfest, HAPC] = $CanRide;
$VehicleUse[armormInfest, DogFighter] = $CanRide;
$VehicleUse[armormInfest, QuickLPC] = $CanRide;
$VehicleUse[armormInfest, Speeder] = $CanRide;
$VehicleUse[armormInfest, Tempest] = $CanRide;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female infested terran!
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfInfest] = 3;
$DamageScale[armorfInfest, $LandingDamageType] = 0.5;
$DamageScale[armorfInfest, $ImpactDamageType] = 0.5;
$DamageScale[armorfInfest, $CrushDamageType] = 0.5;
$DamageScale[armorfInfest, $BulletDamageType] = 0.5;
$DamageScale[armorfInfest, $PlasmaDamageType] = 1.2;
$DamageScale[armorfInfest, $EnergyDamageType] = 1.3;
$DamageScale[armorfInfest, $ExplosionDamageType] = 1.2;
$DamageScale[armorfInfest, $MissileDamageType] = 1.3;
$DamageScale[armorfInfest, $DebrisDamageType] = 1.3;
$DamageScale[armorfInfest, $ShrapnelDamageType] = 1.3;
$DamageScale[armorfInfest, $LaserDamageType] = 1.0;
$DamageScale[armorfInfest, $MortarDamageType] = 1.3;
$DamageScale[armorfInfest, $BlasterDamageType] = 1.3;
$DamageScale[armorfInfest, $ElectricityDamageType] = 1.0;
$DamageScale[armorfInfest, $MineDamageType] = 1.2;
$DamageScale[armorfInfest, $SniperDamageType] = 1.0;
$DamageScale[armorfInfest, $FlashDamageType] = 1.0;
$DamageScale[armorfInfest, $MeltaDamageType] = 1.0;
$DamageScale[armorfInfest, $DeathDamageType] = 1.0;
$DamageScale[armorfInfest, $FlamerDamageType] = 1.0;
$DamageScale[armorfInfest, $DDamageType] = 0.1;
$DamageScale[armorfInfest, $ShurikenDamageType] = 1.0;
$DamageScale[armorfInfest, $ReaperDamageType] = 1.0;
$DamageScale[armorfInfest, $ShellDamageType] = 1.0;
$DamageScale[armorfInfest, $PsiDamageType] = 1.0;

 // 
$VehicleUse[armorfInfest, Wraith] = $CanRide;
$VehicleUse[armorfInfest, Interceptor] = $CanRide;
$VehicleUse[armorfInfest, Scout] =$CanRide;
$VehicleUse[armorfInfest, LAPC] = $CanRide;
$VehicleUse[armorfInfest, HAPC] = $CanRide;
$VehicleUse[armorfInfest, DogFighter] = $CanRide;
$VehicleUse[armorfInfest, QuickLPC] = $CanRide;
$VehicleUse[armorfInfest, Speeder] = $CanRide;
$VehicleUse[armorfInfest, Tempest] = $CanRide;

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Dark Reaper Armor 
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormCommando] = 3;
$DamageScale[armormCommando, $LandingDamageType] = 0.5;
$DamageScale[armormCommando, $ImpactDamageType] = 1.0;
$DamageScale[armormCommando, $CrushDamageType] = 1.0;
$DamageScale[armormCommando, $BulletDamageType] = 1.2;
$DamageScale[armormCommando, $PlasmaDamageType] = 0.5;
$DamageScale[armormCommando, $EnergyDamageType] = 0.8;
$DamageScale[armormCommando, $ExplosionDamageType] = 0.5;
$DamageScale[armormCommando, $MissileDamageType] = 0.5;
$DamageScale[armormCommando, $ShrapnelDamageType] = 1.2;
$DamageScale[armormCommando, $DebrisDamageType] = 1.2;
$DamageScale[armormCommando, $LaserDamageType] = 1.0;
$DamageScale[armormCommando, $MortarDamageType] = 1.3;
$DamageScale[armormCommando, $BlasterDamageType] = 1.3;
$DamageScale[armormCommando, $ElectricityDamageType] = 1.0;
$DamageScale[armormCommando, $MineDamageType] = 1.2;
$DamageScale[armormCommando, $SniperDamageType] = 1.0;
$DamageScale[armormCommando, $FlashDamageType] = 1.0;
$DamageScale[armormCommando, $MeltaDamageType] = 1.0;
$DamageScale[armormCommando, $DeathDamageType] = 1.0;
$DamageScale[armormCommando, $FlamerDamageType] = 1.0;
$DamageScale[armormCommando, $DDamageType] = 0.1;
$DamageScale[armormCommando, $ShurikenDamageType] = 1.0;
$DamageScale[armormCommando, $ReaperDamageType] = 1.0;
$DamageScale[armormCommando, $ShellDamageType] = 0.6;
$DamageScale[armormCommando, $PsiDamageType] = 1.0;
//
$VehicleUse[armormCommando, Wraith] = $CanRide;
$VehicleUse[armormCommando, Interceptor] = $CanRide;
$VehicleUse[armormCommando, Scout] = $CanRide;
$VehicleUse[armormCommando, LAPC] = $CanRide;
$VehicleUse[armormCommando, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armormCommando, DogFighter] = $CanRide;
$VehicleUse[armormCommando, QuickLPC] = $CanRide;
$VehicleUse[armormCommando, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armormCommando, Speeder] = $CanRide;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Dark Reaper Armor 
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfCommando] = 3;
$DamageScale[armorfCommando, $LandingDamageType] = 0.5;
$DamageScale[armorfCommando, $ImpactDamageType] = 1.0;
$DamageScale[armorfCommando, $CrushDamageType] = 1.0;
$DamageScale[armorfCommando, $BulletDamageType] = 1.2;
$DamageScale[armorfCommando, $PlasmaDamageType] = 0.5;
$DamageScale[armorfCommando, $EnergyDamageType] = 0.8;
$DamageScale[armorfCommando, $ExplosionDamageType] = 0.5;
$DamageScale[armorfCommando, $MissileDamageType] = 0.5;
$DamageScale[armorfCommando, $ShrapnelDamageType] = 1.2;
$DamageScale[armorfCommando, $DebrisDamageType] = 1.2;
$DamageScale[armorfCommando, $LaserDamageType] = 1.0;
$DamageScale[armorfCommando, $MortarDamageType] = 1.3;
$DamageScale[armorfCommando, $BlasterDamageType] = 1.3;
$DamageScale[armorfCommando, $ElectricityDamageType] = 1.0;
$DamageScale[armorfCommando, $MineDamageType] = 1.2;
$DamageScale[armorfCommando, $SniperDamageType] = 1.0;
$DamageScale[armorfCommando, $FlashDamageType] = 1.0;
$DamageScale[armorfCommando, $MeltaDamageType] = 1.0;
$DamageScale[armorfCommando, $DeathDamageType] = 1.0;
$DamageScale[armorfCommando, $FlamerDamageType] = 1.0;
$DamageScale[armorfCommando, $DDamageType] = 0.1;
$DamageScale[armorfCommando, $ShurikenDamageType] = 1.0;
$DamageScale[armorfCommando, $ReaperDamageType] = 1.0;
$DamageScale[armorfCommando, $ShellDamageType] = 1.0;
$DamageScale[armorfCommando, $PsiDamageType] = 1.0;
//
$VehicleUse[armorfCommando, Wraith] = $CanRide;
$VehicleUse[armorfCommando, Interceptor] = $CanRide;
$VehicleUse[armorfCommando, Scout] = $CanRide;
$VehicleUse[armorfCommando, LAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfCommando, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfCommando, DogFighter] = $CanRide;
$VehicleUse[armorfCommando, QuickLPC] = $CanRide;
$VehicleUse[armorfCommando, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armorfCommando, Speeder] = $CanRide;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Wraith Lord
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorDestroyer] = 4;
$DamageScale[armorDestroyer, $LandingDamageType] = 0.5;
$DamageScale[armorDestroyer, $ImpactDamageType] = 0.3;
$DamageScale[armorDestroyer, $CrushDamageType] = 0.3;
$DamageScale[armorDestroyer, $BulletDamageType] = 0.6;
$DamageScale[armorDestroyer, $PlasmaDamageType] = 0.4;
$DamageScale[armorDestroyer, $EnergyDamageType] = 0.1;
$DamageScale[armorDestroyer, $ExplosionDamageType] = 0.5;
$DamageScale[armorDestroyer, $MissileDamageType] = 0.6;
$DamageScale[armorDestroyer, $ShrapnelDamageType] = 0.4;
$DamageScale[armorDestroyer, $DebrisDamageType] = 1.2;
$DamageScale[armorDestroyer, $LaserDamageType] = 0.8;
$DamageScale[armorDestroyer, $MortarDamageType] = 0.8;
$DamageScale[armorDestroyer, $BlasterDamageType] = 0.3;
$DamageScale[armorDestroyer, $ElectricityDamageType] = 0.5;
$DamageScale[armorDestroyer, $MineDamageType] = 1.2;
$DamageScale[armorDestroyer, $SniperDamageType] = 1.0;
$DamageScale[armorDestroyer, $FlashDamageType] = 1.0;
$DamageScale[armorDestroyer, $MeltaDamageType] = 0.5;
$DamageScale[armorDestroyer, $DeathDamageType] = 0.6;
$DamageScale[armorDestroyer, $FlamerDamageType] = 1.0;
$DamageScale[armorDestroyer, $ShurikenDamageType] = 0.5;
$DamageScale[armorDestroyer, $ReaperDamageType] = 1.0;
$DamageScale[armorDestroyer, $ShellDamageType] = 0.4;
$DamageScale[armorDestroyer, $PsiDamageType] = 1.0;
//
$VehicleUse[armorDestroyer, Wraith] = $CanRide;
$VehicleUse[armorDestroyer, Interceptor] = $CanRide;
$VehicleUse[armorDestroyer, Scout] = $CanRide;
$VehicleUse[armorDestroyer, LAPC] = $CanRide;
$VehicleUse[armorDestroyer, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armorDestroyer, DogFighter] = $CanRide;
$VehicleUse[armorDestroyer, QuickLPC] = $CanRide;
$VehicleUse[armorDestroyer, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armorDestroyer, Speeder] = $CanRide;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male LING
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormLing] = 3;
$DamageScale[armormLing, $LandingDamageType] = 1.0;
$DamageScale[armormLing, $ImpactDamageType] = 1.0;
$DamageScale[armormLing, $CrushDamageType] = 1.0;
$DamageScale[armormLing, $BulletDamageType] = 1.3;
$DamageScale[armormLing, $PlasmaDamageType] = 1.0;
$DamageScale[armormLing, $EnergyDamageType] = 1.0;
$DamageScale[armormLing, $ExplosionDamageType] = 1.0;
$DamageScale[armormLing, $MissileDamageType] = 1.0;
$DamageScale[armormLing, $ShrapnelDamageType] = 0.8;
$DamageScale[armormLing, $DebrisDamageType] = 0.6;
$DamageScale[armormLing, $LaserDamageType] = 1.0;
$DamageScale[armormLing, $MortarDamageType] = 1.3;
$DamageScale[armormLing, $BlasterDamageType] = 0.7;
$DamageScale[armormLing, $ElectricityDamageType] = 1.0;
$DamageScale[armormLing, $MineDamageType] = 1.2;
$DamageScale[armormLing, $SniperDamageType] = 1.0;
$DamageScale[armormLing, $FlashDamageType] = 1.0;
$DamageScale[armormLing, $MeltaDamageType] = 1.0;
$DamageScale[armormLing, $DeathDamageType] = 1.0;
$DamageScale[armormLing, $FlamerDamageType] = 1.0;
$DamageScale[armormLing, $DDamageType] = 10.0;
$DamageScale[armormLing, $ShurikenDamageType] = 1.0;
$DamageScale[armormLing, $ReaperDamageType] = 1.0;
$DamageScale[armormLing, $ShellDamageType] = 1.0;
$DamageScale[armormLing, $PsiDamageType] = 1.0;
//
$VehicleUse[armormLing, Wraith] = $CanRide;
$VehicleUse[armormLing, Interceptor] = $CanRide;
$VehicleUse[armormLing, Scout] = $CanRide;
$VehicleUse[armormLing, LAPC] = $CanRide;
$VehicleUse[armormLing, HAPC] = $CanRide;
$VehicleUse[armormLing, DogFighter] = $CanRide;
$VehicleUse[armormLing, QuickLPC] = $CanRide;
$VehicleUse[armormLing, Tempest] = $CanRide;
$VehicleUse[armormLing, Speeder] = $CanRide;
$VehicleUse[armormLing, Muta] = $CanPilot;
$VehicleUse[armormLing, Guard] = $CanPilot;
$VehicleUse[armormLing, Dev] = $CanPilot;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Ling
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfLing] = 3;
$DamageScale[armorfLing, $LandingDamageType] = 1.0;
$DamageScale[armorfLing, $ImpactDamageType] = 1.0;
$DamageScale[armorfLing, $CrushDamageType] = 1.0;
$DamageScale[armorfLing, $BulletDamageType] = 1.3;
$DamageScale[armorfLing, $PlasmaDamageType] = 1.0;
$DamageScale[armorfLing, $EnergyDamageType] = 1.0;
$DamageScale[armorfLing, $ExplosionDamageType] = 1.0;
$DamageScale[armorfLing, $MissileDamageType] = 1.0;
$DamageScale[armorfLing, $ShrapnelDamageType] = 0.8;
$DamageScale[armorfLing, $DebrisDamageType] = 0.6;
$DamageScale[armorfLing, $LaserDamageType] = 1.0;
$DamageScale[armorfLing, $MortarDamageType] = 1.3;
$DamageScale[armorfLing, $BlasterDamageType] = 0.7;
$DamageScale[armorfLing, $ElectricityDamageType] = 1.0;
$DamageScale[armorfLing, $MineDamageType] = 1.2;
$DamageScale[armorfLing, $SniperDamageType] = 1.0;
$DamageScale[armorfLing, $FlashDamageType] = 1.0;
$DamageScale[armorfLing, $MeltaDamageType] = 1.0;
$DamageScale[armorfLing, $DeathDamageType] = 1.0;
$DamageScale[armorfLing, $FlamerDamageType] = 1.0;
$DamageScale[armorfLing, $DDamageType] = 10.0;
$DamageScale[armorfLing, $ShurikenDamageType] = 1.0;
$DamageScale[armorfLing, $ReaperDamageType] = 1.0;
$DamageScale[armorfLing, $ShellDamageType] = 1.0;
$DamageScale[armorfLing, $PsiDamageType] = 1.0;
//
$VehicleUse[armorfLing, Wraith] = $CanRide;
$VehicleUse[armorfLing, Interceptor] = $CanRide;
$VehicleUse[armorfLing, Scout] = $CanRide;
$VehicleUse[armorfLing, LAPC] = $CanRide;
$VehicleUse[armorfLing, HAPC] = $CanRide;
$VehicleUse[armorfLing, DogFighter] = $CanRide;
$VehicleUse[armorfLing, QuickLPC] = $CanRide;
$VehicleUse[armorfLing, Tempest] = $CanRide;
$VehicleUse[armorfLing, Speeder] = $CanRide;
$VehicleUse[armorfLing, Muta] = $CanPilot;
$VehicleUse[armorfLing, Guard] = $CanPilot;
$VehicleUse[armorfLing, Dev] = $CanPilot;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Hydra
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormLoader] = 4;
$DamageScale[armormLoader, $LandingDamageType] = 1.0;
$DamageScale[armormLoader, $ImpactDamageType] = 1.0;
$DamageScale[armormLoader, $CrushDamageType] = 1.0;
$DamageScale[armormLoader, $BulletDamageType] = 1.3;
$DamageScale[armormLoader, $PlasmaDamageType] = 1.0;
$DamageScale[armormLoader, $EnergyDamageType] = 0.5;
$DamageScale[armormLoader, $ExplosionDamageType] = 1.0;
$DamageScale[armormLoader, $MissileDamageType] = 1.0;
$DamageScale[armormLoader, $ShrapnelDamageType] = 1.0;
$DamageScale[armormLoader, $DebrisDamageType] = 0.6;
$DamageScale[armormLoader, $LaserDamageType] = 1.0;
$DamageScale[armormLoader, $MortarDamageType] = 1.3;
$DamageScale[armormLoader, $BlasterDamageType] = 0.7;
$DamageScale[armormLoader, $ElectricityDamageType] = 1.0;
$DamageScale[armormLoader, $MineDamageType] = 1.2;
$DamageScale[armormLoader, $SniperDamageType] = 1.0;
$DamageScale[armormLoader, $FlashDamageType] = 1.0;
$DamageScale[armormLoader, $MeltaDamageType] = 1.0;
$DamageScale[armormLoader, $DeathDamageType] = 1.0;
$DamageScale[armormLoader, $FlamerDamageType] = 1.0;
$DamageScale[armormLoader, $DDamageType] = 10.0;
$DamageScale[armormLoader, $ShurikenDamageType] = 1.0;
$DamageScale[armormLoader, $ReaperDamageType] = 1.0;
$DamageScale[armormLoader, $ShellDamageType] = 1.0;
$DamageScale[armormLoader, $PsiDamageType] = 1.0;
//
$VehicleUse[armormLoader, Wraith] = $CanRide;
$VehicleUse[armormLoader, Interceptor] = $CanRide;
$VehicleUse[armormLoader, Scout] = $CanRide;
$VehicleUse[armormLoader, LAPC] = $CanRide;
$VehicleUse[armormLoader, HAPC] = $CanRide;
$VehicleUse[armormLoader, DogFighter] = $CanRide;
$VehicleUse[armormLoader, QuickLPC] = $CanRide;
$VehicleUse[armormLoader, Tempest] = $CanRide;
$VehicleUse[armormLoader, Speeder] = $CanRide;
$VehicleUse[armormLoader, Muta] = $CanPilot;
$VehicleUse[armormLoader, Guard] = $CanPilot;
$VehicleUse[armormLoader, Dev] = $CanPilot;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Hydra
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfLoader] = 4;
$DamageScale[armorfLoader, $LandingDamageType] = 1.0;
$DamageScale[armorfLoader, $ImpactDamageType] = 1.0;
$DamageScale[armorfLoader, $CrushDamageType] = 1.0;
$DamageScale[armorfLoader, $BulletDamageType] = 1.3;
$DamageScale[armorfLoader, $PlasmaDamageType] = 1.0;
$DamageScale[armorfLoader, $EnergyDamageType] = 0.5;
$DamageScale[armorfLoader, $ExplosionDamageType] = 1.0;
$DamageScale[armorfLoader, $MissileDamageType] = 1.0;
$DamageScale[armorfLoader, $ShrapnelDamageType] = 1.0;
$DamageScale[armorfLoader, $DebrisDamageType] = 0.6;
$DamageScale[armorfLoader, $LaserDamageType] = 1.0;
$DamageScale[armorfLoader, $MortarDamageType] = 1.3;
$DamageScale[armorfLoader, $BlasterDamageType] = 0.7;
$DamageScale[armorfLoader, $ElectricityDamageType] = 1.0;
$DamageScale[armorfLoader, $MineDamageType] = 1.2;
$DamageScale[armorfLoader, $SniperDamageType] = 1.0;
$DamageScale[armorfLoader, $FlashDamageType] = 1.0;
$DamageScale[armorfLoader, $MeltaDamageType] = 1.0;
$DamageScale[armorfLoader, $DeathDamageType] = 1.0;
$DamageScale[armorfLoader, $FlamerDamageType] = 1.0;
$DamageScale[armorfLoader, $DDamageType] = 10.0;
$DamageScale[armorfLoader, $ShurikenDamageType] = 1.0;
$DamageScale[armorfLoader, $ReaperDamageType] = 1.0;
$DamageScale[armorfLoader, $ShellDamageType] = 1.0;
$DamageScale[armorfLoader, $PsiDamageType] = 1.0;
//
$VehicleUse[armorfLoader, Wraith] = $CanRide;
$VehicleUse[armorfLoader, Interceptor] = $CanRide;
$VehicleUse[armorfLoader, Scout] = $CanRide;
$VehicleUse[armorfLoader, LAPC] = $CanRide;
$VehicleUse[armorfLoader, HAPC] = $CanRide;
$VehicleUse[armorfLoader, DogFighter] = $CanRide;
$VehicleUse[armorfLoader, QuickLPC] = $CanRide;
$VehicleUse[armorfLoader, Tempest] = $CanRide;
$VehicleUse[armorfLoader, Speeder] = $CanRide;
$VehicleUse[armorfLoader, Muta] = $CanPilot;
$VehicleUse[armorfLoader, Guard] = $CanPilot;
$VehicleUse[armorfLoader, Dev] = $CanPilot;
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // balls o life armor
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[parmor] = 1;
$DamageScale[parmor, $LandingDamageType] = 0.5;
$DamageScale[parmor, $ImpactDamageType] = 0.5;
$DamageScale[parmor, $CrushDamageType] = 0.5;
$DamageScale[parmor, $BulletDamageType] = 0.5;
$DamageScale[parmor, $PlasmaDamageType] = 1.2;
$DamageScale[parmor, $EnergyDamageType] = 1.3;
$DamageScale[parmor, $ExplosionDamageType] = 1.2;
$DamageScale[parmor, $MissileDamageType] = 1.3;
$DamageScale[parmor, $DebrisDamageType] = 1.3;
$DamageScale[parmor, $ShrapnelDamageType] = 1.3;
$DamageScale[parmor, $LaserDamageType] = 1.0;
$DamageScale[parmor, $MortarDamageType] = 1.3;
$DamageScale[parmor, $BlasterDamageType] = 1.3;
$DamageScale[parmor, $ElectricityDamageType] = 1.0;
$DamageScale[parmor, $MineDamageType] = 1.2;
$DamageScale[parmor, $SniperDamageType] = 1.0;
$DamageScale[parmor, $FlashDamageType] = 1.0;
$DamageScale[parmor, $MeltaDamageType] = 1.0;
$DamageScale[parmor, $DeathDamageType] = 1.0;
$DamageScale[parmor, $FlamerDamageType] = 1.0;
$DamageScale[parmor, $DDamageType] = 0.1;
$DamageScale[parmor, $ShurikenDamageType] = 1.0;
$DamageScale[parmor, $ReaperDamageType] = 1.0;
$DamageScale[parmor, $ShellDamageType] = 1.0;
$DamageScale[parmor, $PsiDamageType] = 1.0;

 //
$VehicleUse[parmor, Wraith] = $CanRide;
$VehicleUse[parmor, Interceptor] = $CanRide;
$VehicleUse[parmor, Scout] =$CanRide;
$VehicleUse[parmor, LAPC] = $CanRide;
$VehicleUse[parmor, HAPC] = $CanRide;
$VehicleUse[parmor, DogFighter] = $CanRide;
$VehicleUse[parmor, QuickLPC] = $CanRide;
$VehicleUse[parmor, Speeder] = $CanRide;
$VehicleUse[parmor, Tempest] = $CanRide;

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Male Swooping Hawk
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armormSprint] = 3;
$DamageScale[armormSprint, $LandingDamageType] = 0.0;
$DamageScale[armormSprint, $ImpactDamageType] = 1.0;
$DamageScale[armormSprint, $CrushDamageType] = 1.0;
$DamageScale[armormSprint, $BulletDamageType] = 1.3;
$DamageScale[armormSprint, $PlasmaDamageType] = 1.0;
$DamageScale[armormSprint, $EnergyDamageType] = 1.0;
$DamageScale[armormSprint, $ExplosionDamageType] = 1.0;
$DamageScale[armormSprint, $MissileDamageType] = 1.0;
$DamageScale[armormSprint, $ShrapnelDamageType] = 1.0;
$DamageScale[armormSprint, $DebrisDamageType] = 1.0;
$DamageScale[armormSprint, $LaserDamageType] = 1.0;
$DamageScale[armormSprint, $MortarDamageType] = 1.0;
$DamageScale[armormSprint, $BlasterDamageType] = 1.0;
$DamageScale[armormSprint, $ElectricityDamageType] = 1.0;
$DamageScale[armormSprint, $MineDamageType] = 1.2;
$DamageScale[armormSprint, $SniperDamageType] = 1.0;
$DamageScale[armormSprint, $FlashDamageType] = 1.0;
$DamageScale[armormSprint, $MeltaDamageType] = 1.0;
$DamageScale[armormSprint, $DeathDamageType] = 1.0;
$DamageScale[armormSprint, $FlamerDamageType] = 1.0;
$DamageScale[armormSprint, $DDamageType] = 0.1;
$DamageScale[armormSprint, $ShurikenDamageType] = 1.0;
$DamageScale[armormSprint, $ReaperDamageType] = 1.0;
$DamageScale[armormSprint, $ShellDamageType] = 1.0;
$DamageScale[armormSprint, $PsiDamageType] = 1.0;
//
$VehicleUse[armormSprint, Wraith] = $CanRide;
$VehicleUse[armormSprint, Interceptor] = $CanPilot | $CanRide;
$VehicleUse[armormSprint, Scout] = $CanPilot | $CanRide;
$VehicleUse[armormSprint, LAPC] = $CanRide;
$VehicleUse[armormSprint, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armormSprint, DogFighter] = $CanPilot | $CanRide;
$VehicleUse[armormSprint, QuickLPC] = $CanRide;
$VehicleUse[armormSprint, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armormSprint, Speeder] = $CanRide;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // Female Swooping Hawk
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$MaxWeapons[armorfSprint] = 3;
$DamageScale[armorfSprint, $LandingDamageType] = 0.0;
$DamageScale[armorfSprint, $ImpactDamageType] = 1.0;
$DamageScale[armorfSprint, $CrushDamageType] = 1.0;
$DamageScale[armorfSprint, $BulletDamageType] = 1.3;
$DamageScale[armorfSprint, $PlasmaDamageType] = 1.0;
$DamageScale[armorfSprint, $EnergyDamageType] = 1.0;
$DamageScale[armorfSprint, $ExplosionDamageType] = 1.0;
$DamageScale[armorfSprint, $MissileDamageType] = 1.0;
$DamageScale[armorfSprint, $ShrapnelDamageType] = 1.0;
$DamageScale[armorfSprint, $DebrisDamageType] = 1.0;
$DamageScale[armorfSprint, $LaserDamageType] = 1.0;
$DamageScale[armorfSprint, $MortarDamageType] = 1.0;
$DamageScale[armorfSprint, $BlasterDamageType] = 1.0;
$DamageScale[armorfSprint, $ElectricityDamageType] = 1.0;
$DamageScale[armorfSprint, $MineDamageType] = 1.2;
$DamageScale[armorfSprint, $SniperDamageType] = 1.0;
$DamageScale[armorfSprint, $FlashDamageType] = 1.0;
$DamageScale[armorfSprint, $MeltaDamageType] = 1.0;
$DamageScale[armorfSprint, $DeathDamageType] = 1.0;
$DamageScale[armorfSprint, $FlamerDamageType] = 1.0;
$DamageScale[armorfSprint, $DDamageType] = 0.1;
$DamageScale[armorfSprint, $ShurikenDamageType] = 1.0;
$DamageScale[armorfSprint, $ReaperDamageType] = 1.0;
$DamageScale[armorfSprint, $ShellDamageType] = 1.0;
$DamageScale[armorfSprint, $PsiDamageType] = 1.0;
//
$VehicleUse[armorfSprint, Wraith] = $CanRide;
$VehicleUse[armorfSprint, Interceptor] = $CanPilot | $CanRide;
$VehicleUse[armorfSprint, Scout] = $CanPilot | $CanRide;
$VehicleUse[armorfSprint, LAPC] = $CanRide;
$VehicleUse[armorfSprint, HAPC] = $CanPilot | $CanRide;
$VehicleUse[armorfSprint, DogFighter] = $CanRide;
$VehicleUse[armorfSprint, QuickLPC] = $CanRide;
$VehicleUse[armorfSprint, Tempest] = $CanPilot | $CanRide;
$VehicleUse[armorfSprint, Speeder] = $CanRide;
function PopulateItemMax(%item, %mDM, %fDM, %mSC, %fSC, %mSP, %fSP, %mSN, %fSN, %mME, %fME, %mEN, %fEN, %mBU, %fBU, %mAL, %fAL, %CY, %mCO, %fCO, %DE, %mLO, %fLO, %mSR, %fSR, %mLI, %fLI, %AS, %mIT, %fIT, %PA)
{
  $ItemMax[dmarmor, %item] = %mDM;
  $ItemMax[dmfemale, %item] = %fDM;
  $ItemMax[armormScout, %item] = %mSC;
  $ItemMax[armorfScout, %item] = %fSC;
  $ItemMax[armormSpy, %item] = %mSP;
  $ItemMax[armorfSpy, %item] = %fSP;
  $ItemMax[armormSniper, %item] = %mSN;
  $ItemMax[armorfSniper, %item] = %fSN;
  $ItemMax[armormMercenary, %item] = %mME;
  $ItemMax[armorfMercenary, %item] = %fME;
  $ItemMax[armormEngineer, %item] = %mEN;
  $ItemMax[armorfEngineer, %item] = %fEN;
  $ItemMax[armormBurster, %item] = %mBU;
  $ItemMax[armorfBurster, %item] = %fBU;
  $ItemMax[armormAlien, %item] = %mAL;
  $ItemMax[armorfAlien, %item] = %fAL;
  $ItemMax[armorCyborg, %item] = %CY; 
  $ItemMax[armormCommando, %item] = %mCO;  
  $ItemMax[armorfCommando, %item] = %fCO;
  $ItemMax[armorDestroyer, %item] = %DE;
  $ItemMax[armormLoader, %item] = %mLO;
  $ItemMax[armorfLoader, %item] = %fLO;
  $ItemMax[armormSprint, %item] = %mSR;
  $ItemMax[armorfSprint, %item] = %fSR; 
  $ItemMax[armormLing, %item] = %mLI;
  $ItemMax[armorfLing, %item] = %fLI;
  $ItemMax[armorAss, %item] = %AS;
  $ItemMax[armormInfest, %item] = %mIT;
  $ItemMax[armorfInfest, %item] = %fIT;
  $ItemMax[parmor, %item] = %PA;
}

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // WEAPONS
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 //                              mDM, fDM, mSC, fSC, mSP, fSP, mSN, fSN, mME, fME, mEN, fEN, mBU, fBU, mAL, fAL,  CY, mCO, fCO,  DE, mLO, fLO, mSR, fSR, mLI, fLI,  AS, mIT, fIT,  PA
 //                              ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   --  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---

PopulateItemMax(InfFlame,          0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0);
PopulateItemMax(InfOmega,          0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0);
PopulateItemMax(InfhyperB,         0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0);
PopulateItemMax(AniZergLauncher,   0,   0,   1,   1,   1,   1,   0,   0,   1,   1,   0,   0,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(AniZergAmmo,       0,   0,   3,   3,   3,   3,   0,   0,   3,   3,   0,   0,   3,   3,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(AntiZergLauncher,  0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(AntiZergAmmo,      0,   0,   1,   1,   1,   1,   3,   3,   0,   0,   0,   0,   0,   0,   3,   3,   0,   3,   3,   3,   0,   0,   3,   3,   0,   0,   0,   0,   0,   0);
PopulateItemMax(BlueTerror,        1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Blaster,           1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Bolt,              1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Chaingun,          1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(BulletAmmo,      250, 250, 200, 200, 200, 200, 100, 100, 300, 300, 150, 150, 150, 150,   0,   0, 400,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(DeathLaser,        1,   1,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(DiscLauncher,      1,   1,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(DiscAmmo,         35,  35,  15,  15,  15,  15,  35,  35,  15,  15,  15,  15,  30,  30,  15,  15,  15,  50,  50,  80,  40,  40,  40,  40,   0,   0,   0,   0,   0,   0);
PopulateItemMax(EnergyRifle,       1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Fixit,             1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Flamer,            1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(GrenadeLauncher,   1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(GrenadeAmmo,      20,  20,  10,  10,  10,  10,  10,  10,  20,  20,  20,  20,  30,  30,  20,  20,  35,  20,  20,  30,   0,   0,  20,  20,   0,   0,   0,   0,   0,   0);
PopulateItemMax(HyperB,            1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(HyperBAmmo,      300, 300, 200, 200, 300, 300,   0,   0, 200, 200, 300, 300, 300, 300,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(IonGun,            1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(LaserRifle,        1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Mortar,            1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(MortarAmmo,        8,   8,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,   5,   5,  10,  10,  10,   5,   5,  10,   0,   0,   5,   5,   0,   0,   0,   0,   0,   0);  
PopulateItemMax(Flak,              1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(FlakAmmo,          8,   8,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,   5,   5,  10,  10,  10,   5,   5,  10,   0,   0,   5,   5,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Omega,             1,   1,   0,   0,   1,   1,   0,   0,   1,   1,   0,   0,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(PlasmaGun,         1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(PlasmaAmmo,       40,  40,  30,  30,  30,  30,  30,  30,  40,  40,  40,  40,  15,  15,  40,  40,  30,  20,  20,  70,   0,   0,  20,  20,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Railgun,           1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(RailAmmo,        200, 200,  50,  50,  50,  50,  50,  50,  60,  60,  60,  60, 150, 150,  50,  50, 300,  50,  50,  50,   0,   0,  50,  50,   0,   0,   0,   0,   0,   0);
PopulateItemMax(RocketLauncher,    1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(RocketAmmo,       10,  10,   5,   5,   5,   5,   5,   5,   5,   5,   5,   5,  10,  10,   5,   5,  20,   5,   5,  10,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Silencer,          1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(SilencerAmmo,    150, 150, 150, 150, 150, 150, 150, 150, 250, 250, 150, 150, 350, 350,   0,   0, 400,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(SniperRifle,       1,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(SniperAmmo,       15,  15,   5,   5,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,  25,   0,   0,  25,  25,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TargetingLaser,    1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TranqGun,          1,   1,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TranqAmmo,        20,  20,  20,  20,  20,  20,  30,  30,  20,  20,  20,  20,  20,  20,  20,  20,  20,  20,  20,  20,   0,   0,  30,  30,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Vulcan,            1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(VulcanAmmo,      150, 150, 100, 100, 100, 100, 100, 100, 250, 250, 250, 250, 250, 250, 250, 250, 100,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(WaveGun,           1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Shotgun,           1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(ShotgunAmmo,      20,  20,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,  20,  10,  20,  20,   0,   0,  20,  20,   0,   0,   0,   0,   0,   0);  
PopulateItemMax(LasCannon,         1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(HFlamer,           1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Autogun,           1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(AutoAmmo,        150, 150,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  50,  50,   0,   0, 100,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(DemoGun,           1,   1,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(PartGun,           1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Warp,              1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(WarpAmmo,          1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  15,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(ShurCannon,        1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0); 
PopulateItemMax(ShurAmmo,          1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  50,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TargetMarkLaser,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0);   
PopulateItemMax(TractorDevice,     1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(LongRifle,         1,   1,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(LongAmmo,         20,  20,   0,   0,   0,   0,  15,  15,   0,   0,   0,   0,   0,   0,  20,  20,   0,   0,   0,   0,   0,   0,  10,  10,   0,   0,   0,   0,   0,   0);
PopulateItemMax(ELF,               1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);   
PopulateItemMax(Pist,              1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Melta,             0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(MeltaAmmo,         0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  15,  15,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Virus,             1,   1,   0,   0,   1,   1,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(VirusAmmo,       100, 100,   0,   0, 100, 100,   0,   0, 120, 120,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(EMP,               0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(EMPAmmo,           0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  10,  10,  10,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Grav,              1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Cyclone,           0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(CycloneAmmo,       0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TMortar,           1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TMortarAmmo,       5,   5,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,   5,   0,   5,   5,   10,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(FlakC,             1,   1,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(FlakCAmmo,        10,  10,   0,   0,   0,   0,  10,  10,   0,   0,   0,   0,   0,   0,  15,  15,   0,  15,  15,   20,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0);

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // MISC 
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 //                              mDM, fDM, mSC, fSC, mSP, fSP, mSN, fSN, mME, fME, mEN, fEN, mBU, fBU, mAL, fAL,  CY,  mCO, fCO,  DE, mLO, fLO, mSR, fSR, mLI, fLI, AS,  mIT, fIT, PA
 //                              ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---
PopulateItemMax(Beacon,            5,   5,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   0);  
PopulateItemMax(Grenade,           5,   5,   5,   5,   2,   2,   5,   5,   6,   6,   6,   6,   6,   6,   5,   5,   2,   5,   5,   5,   3,   3,   5,   5,   5,   5,   3,   2,   2,   0);
PopulateItemMax(MineAmmo,          5,   5,   3,   3,   5,   5,   3,   3,   5,   5,   5,   5,   6,   6,   3,   3,   5,   5,   5,   5,   5,   5,   8,   8,   2,   2,   5,   5,   5,   0);
PopulateItemMax(RepairKit,         2,   2,   1,   1,   2,   2,   2,   2,   2,   2,   2,   2,   2,   2,   2,   2,   5,   2,   2,   4,   2,   2,   1,   1,   1,   1,   5,   2,   2,   0);
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // PACKS
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 //                              mDM, fDM, mSC, fSC, mSP, fSP, mSN, fSN, mME, fME, mEN, fEN, mBU, fBU, mAL, fAL,  CY, mCO, fCO,  DE, mLO, fLO, mSR, fSR, mLI, fLI, AS,  mIT, fIT, PA
 //                              ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   ---  ---  ---  ---  ---  ---  --- ---  ---  ---  ---  ---  ---
PopulateItemMax(InfTerranPack,     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0);
PopulateItemMax(AmmoPack,          1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(EnergyPack,        1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(RepairPack,        1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(ShieldPack,        1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   0,   1,   1,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(SensorJammerPack,  0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0);
PopulateItemMax(penis,             0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1);
PopulateItemMax(LRSensorJammerPack, 0,   0,   0,   0,   0,   0,   0,  0,    0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0); 
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // DEPLOYABLE WEAPONS
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // DEPLOYABLE SENSORS
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 //                                        mDM, fDM, mSC, fSC, mSP, fSP, mSN, fSN, mME, fME, mEN, fEN, mBU, fBU, mAL, fAL,  CY,  mCO, fCO,  DE, mLO, fLO, mSR, fSR
 //                                        ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   ---   ---  --- ---  ---  ---  ---
PopulateItemMax(CameraPack,                  0,   0,   1,   1,   1,   1,   1,   1,   0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1);
PopulateItemMax(DeployableSensorJammerPack,  0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1);
PopulateItemMax(MotionSensorPack,            0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1);
PopulateItemMax(PulseSensorPack,             0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1);

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // DEPLOYABLE OBJECTS
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 //                              mDM, fDM, mSC, fSC, mSP, fSP, mSN, fSN, mME, fME, mEN, fEN, mBU, fBU, mAL, fAL,  CY, mCO, fCO,  DE,  mLO, fLO, mSR, fSR,  mIT,  fIT
 //                              ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   ---  ---  ---  ---  ---   ---   ---

PopulateItemMax(DeployableAmmoPack,1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,    1,   1,   1,   1,   0,   0);
PopulateItemMax(BlastWallPack,     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(ForceFieldPack,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(LargeForceFieldPack, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(PlatformPack,      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(InventoryPack,     0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,    1,   1,   0,   0,   0,   0);
PopulateItemMax(SpringBoardPack,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(TeleportPack,      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(TreePack,          0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(MechPack,          0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   1,   1,   0,   1,   1,   1,    1,   1,   1,   1,   0,   0);
PopulateItemMax(AcceleratorPack,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(CameraPack,        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(PulseSensorPack,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(SensorJammerPack,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(DeployableComPack, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(DeployableInvPack, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(SpringPack,        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(AcceleratorDevicePack,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(TurretPack,        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(IonTurretPack,     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(AirPlatformPack,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(LargeAirPlatPack,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(DetPack,           0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   0,   0,   1,   1,   0,   1,   1,   1,    1,   1,   1,   1,   0,   0);
PopulateItemMax(BigInvPack,        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,    0,   0,   0,   0,   0,   0);
PopulateItemMax(LRMotionSensorPack,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(LRPulseSensorPack,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(DeployableLRSensorJammerPack,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(BigFieldPack,      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0);
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // PSIONICS
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 //                              mDM, fDM, mSC, fSC, mSP, fSP, mSN, fSN, mME, fME, mEN, fEN, mBU, fBU, mAL, fAL,  CY, mCO, fCO,  DE,  mLO, fLO, mSR, fSR, mLI, fLI, AS, mIT, fIT, PA
 //                              ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   ---  ---  ---  ---  ---  ---  ---  --  ---  ---  ---
PopulateItemMax(PlasMeta,         0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0);
PopulateItemMax(Stream,           0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   1,   1,   1,   0);
PopulateItemMax(Heal,             0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   1,   0,   0,   0);
PopulateItemMax(Pull,             0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   1,   0,   0,   0);
PopulateItemMax(Zap,              0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0);
PopulateItemMax(Fireball,         0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   1,   1,   1,   0);
PopulateItemMax(Cloak,            0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   1,   0,   0,   0);
PopulateItemMax(Rain,             0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0);
PopulateItemMax(Dis,              0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   1,   0,   0,   0);
PopulateItemMax(PsiLaser,         0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   1,   1,   1,   0);
PopulateItemMax(Gravi,            0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   1,   0,   0,   0);
PopulateItemMax(Sword,            0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   0,   0,   1,   1,   1,   0,   0,   0);

$ItemMax[armorAss, FlakC]= 0;
$ItemMax[armorAss, RepairKit] = 3;
$ItemMax[armorAss, grenade] = 5;
$ItemMax[armorAss, beacon] = 3;
$ItemMax[armorAss, mineammo] = 5;
$ItemMax[armormLing, PlasMeta] = 0;
$ItemMax[armormLing, Stream] = 0;
$ItemMax[armormLing, Heal] = 1;
$ItemMax[armormLing, Pull] = 1;
$ItemMax[armormLing, Zap] = 1;
$ItemMax[armormLing, Fireball] = 1;
$ItemMax[armormLing, Cloak] = 1;
$ItemMax[armormLing, Dis] = 1;
$ItemMax[armormLing, PsiLaser] = 1;
$ItemMax[armormLing, Gravi] = 0;
$ItemMax[armormLing, Sword] = 1;
$ItemMax[armorfLing, PlasMeta] = 0;
$ItemMax[armorfLing, Stream] = 0;
$ItemMax[armorfLing, Heal] = 1;
$ItemMax[armorfLing, Pull] = 1;
$ItemMax[armorfLing, Zap] = 1;
$ItemMax[armorfLing, Fireball] = 1;
$ItemMax[armorfLing, Cloak] = 1;
$ItemMax[armorfLing, Dis] = 1;
$ItemMax[armorfLing, PsiLaser] = 1;
$ItemMax[armorfLing, Gravi] = 0;
$ItemMax[armorfLing, Sword] = 1;
$ItemMax[armormSniper, Boost] = 3;
$ItemMax[armormSniper, Plastique] = 0;
$ItemMax[armormSniper, LaserTurretPack] = 1;
$ItemMax[armormSniper, RocketPack] = 0;
$ItemMax[armormSniper, PlasmaTurretPack] = 0;
$ItemMax[armormSniper, CloakingDevice] = 0;
$ItemMax[armormSniper, StealthShieldPack] = 0;
$ItemMax[armormSniper, MortarTurretPack] = 0;
$ItemMax[armormSniper, Laptop] = 0;
$ItemMax[armormSniper, ShockTurretPack] = 0;
$ItemMax[armormSniper, RegenerationPack] = 1;
$ItemMax[armormSniper, LightningPack] = 0;
$ItemMax[armormSniper, OpticPack] = 1;
$ItemMax[armormSniper, SMRPack] = 0;
$ItemMax[armormSniper, RailTurretPack] = 0;
$ItemMax[armormSniper, VulcanTurretPack] = 0;
$ItemMax[armormSniper, ImRecPack] = 1;
$ItemMax[armorfSniper, Boost] = 3;
$ItemMax[armorfSniper, Plastique] = 0;
$ItemMax[armorfSniper, Gaussgun] = 0;
$ItemMax[armorfSniper, LaserTurretPack] = 1;
$ItemMax[armorfSniper, RocketPack] = 0;
$ItemMax[armorfSniper, PlasmaTurretPack] = 0;
$ItemMax[armorfSniper, CloakingDevice] = 0;
$ItemMax[armorfSniper, StealthShieldPack] = 0;
$ItemMax[armorfSniper, MortarTurretPack] = 0;
$ItemMax[armorfSniper, Laptop] = 0;
$ItemMax[armorfSniper, ShockTurretPack] = 0;
$ItemMax[armorfSniper, RegenerationPack] = 0;
$ItemMax[armorfSniper, LightningPack] = 0;
$ItemMax[armorfSniper, OpticPack] = 1;
$ItemMax[armorfSniper, SMRPack] = 0;
$ItemMax[armorfSniper, RailTurretPack] = 0;
$ItemMax[armorfSniper, VulcanTurretPack] = 0;
$ItemMax[armorfSniper, ImRecPack] = 1;
$ItemMax[armormScout, Boost] = 5;
$ItemMax[armormScout, Plastique] = 0;
$ItemMax[armormScout, Gaussgun] = 0;
$ItemMax[armormScout, LaserTurretPack] = 0;
$ItemMax[armormScout, RocketPack] = 0;
$ItemMax[armormScout, PlasmaTurretPack] = 0;
$ItemMax[armormScout, CloakingDevice] = 0;
$ItemMax[armormScout, StealthShieldPack] = 1;
$ItemMax[armormScout, MortarTurretPack] = 0;
$ItemMax[armormScout, Laptop] = 0;
$ItemMax[armormScout, ShockTurretPack] = 0;
$ItemMax[armormScout, RegenerationPack] = 0;
$ItemMax[armormScout, LightningPack] = 0;
$ItemMax[armormScout, OpticPack] = 0;
$ItemMax[armormScout, SMRPack] = 0;
$ItemMax[armormScout, RailTurretPack] = 0;
$ItemMax[armormScout, VulcanTurretPack] = 0;
$ItemMax[armormMercenary, Boost] = 4;
$ItemMax[armormMercenary, Plastique] = 0;
$ItemMax[armormMercenary, LaserTurretPack] = 0;
$ItemMax[armormMercenary, RocketPack] = 0;
$ItemMax[armormMercenary, PlasmaTurretPack] = 0;
$ItemMax[armormMercenary, CloakingDevice] = 0;
$ItemMax[armormMercenary, StealthShieldPack] = 0;
$ItemMax[armormMercenary, MortarTurretPack] = 0;
$ItemMax[armormMercenary, Laptop] = 0;
$ItemMax[armormMercenary, ShockTurretPack] = 0;
$ItemMax[armormMercenary, RegenerationPack] = 0;
$ItemMax[armormMercenary, LightningPack] = 0;
$ItemMax[armormMercenary, OpticPack] = 0;
$ItemMax[armormMercenary, SMRPack] = 0;
$ItemMax[armormMercenary, RailTurretPack] = 0;
$ItemMax[armormMercenary, VulcanTurretPack] = 0;
$ItemMax[armormMercenary, ImRecPack] = 1;
$ItemMax[armorfMercenary, Boost] = 4;
$ItemMax[armorfMercenary, Plastique] = 0;
$ItemMax[armorfMercenary, Gaussgun] = 0;
$ItemMax[armorfMercenary, LaserTurretPack] = 0;
$ItemMax[armorfMercenary, RocketPack] = 0;
$ItemMax[armorfMercenary, PlasmaTurretPack] = 0;
$ItemMax[armorfMercenary, CloakingDevice] = 0;
$ItemMax[armorfMercenary, StealthShieldPack] = 0;
$ItemMax[armorfMercenary, MortarTurretPack] = 0;
$ItemMax[armorfMercenary, Laptop] = 0;
$ItemMax[armorfMercenary, ShockTurretPack] = 0;
$ItemMax[armorfMercenary, RegenerationPack] = 0;
$ItemMax[armorfMercenary, LightningPack] = 0;
$ItemMax[armorfMercenary, OpticPack] = 0;
$ItemMax[armorfMercenary, SMRPack] = 0;
$ItemMax[armorfMercenary, RailTurretPack] = 0;
$ItemMax[armorfMercenary, VulcanTurretPack] = 0;
$ItemMax[armormBurster, Boost] = 4;
$ItemMax[armormBurster, Plastique] = 0;
$ItemMax[armormBurster, LaserTurretPack] = 0;
$ItemMax[armormBurster, RocketPack] = 0;
$ItemMax[armormBurster, PlasmaTurretPack] = 0;
$ItemMax[armormBurster, CloakingDevice] = 0;
$ItemMax[armormBurster, StealthShieldPack] = 0;
$ItemMax[armormBurster, MortarTurretPack] = 0;
$ItemMax[armormBurster, Laptop] = 0;
$ItemMax[armormBurster, ShockTurretPack] = 0;
$ItemMax[armormBurster, RegenerationPack] = 0;
$ItemMax[armormBurster, LightningPack] = 0;
$ItemMax[armormBurster, OpticPack] = 0;
$ItemMax[armormBurster, SMRPack] = 0;
$ItemMax[armormBurster, RailTurretPack] = 0;
$ItemMax[armormBurster, VulcanTurretPack] = 0;
$ItemMax[armormBurster, TrackerMissilePack] = 1;
$ItemMax[armormBurster, TrackerMissileAmmo] = 8;
$ItemMax[armorCyborg, Boost] = 5;
$ItemMax[armorCyborg, Plastique] = 0;
$ItemMax[armorCyborg, MassDriver] = 0;
$ItemMax[armorCyborg, MassAmmo] = 20;
$ItemMax[armorCyborg, LaserTurretPack] = 1;
$ItemMax[armorCyborg, RocketPack] = 1;
$ItemMax[armorCyborg, PlasmaTurretPack] = 0;
$ItemMax[armorCyborg, CloakingDevice] = 0;
$ItemMax[armorCyborg, StealthShieldPack] = 1;
$ItemMax[armorCyborg, FgcPack] = 1;
$ItemMax[armorCyborg, MortarTurretPack] = 0;
$ItemMax[armorCyborg, Laptop] = 0;
$ItemMax[armorCyborg, ShockTurretPack] = 0;
$ItemMax[armorCyborg, RegenerationPack] = 1;
$ItemMax[armorCyborg, LightningPack] = 0;
$ItemMax[armorCyborg, OpticPack] = 0;
$ItemMax[armorCyborg, SMRPack] = 1;
$ItemMax[armorCyborg, RailTurretPack] = 0;
$ItemMax[armorCyborg, VulcanTurretPack] = 0;
$ItemMax[armorCyborg, ImRecPack] = 1;
$ItemMax[armorCyborg, TrackerMissilePack] = 1;
$ItemMax[armorCyborg, TrackerMissileAmmo] = 16;
$ItemMax[armorCyborg, PhotonPack] = 1;
$ItemMax[armorfScout, Boost] = 5;
$ItemMax[armorfScout, Plastique] = 0;
$ItemMax[armorfScout, Gaussgun] = 0;
$ItemMax[armorfScout, LaserTurretPack] = 0;
$ItemMax[armorfScout, RocketPack] = 0;
$ItemMax[armorfScout, PlasmaTurretPack] = 0;
$ItemMax[armorfScout, CloakingDevice] = 0;
$ItemMax[armorfScout, StealthShieldPack] = 1;
$ItemMax[armorfScout, MortarTurretPack] = 0;
$ItemMax[armorfScout, Laptop] = 0;
$ItemMax[armorfScout, ShockTurretPack] = 0;
$ItemMax[armorfScout, RegenerationPack] = 0;
$ItemMax[armorfScout, LightningPack] = 0;
$ItemMax[armorfScout, OpticPack] = 0;
$ItemMax[armorfScout, SMRPack] = 0;
$ItemMax[armorfScout, RailTurretPack] = 0;
$ItemMax[armorfScout, VulcanTurretPack] = 0;
$ItemMax[armorfBurster, Boost] = 4;
$ItemMax[armorfBurster, Plastique] = 0;
$ItemMax[armorfBurster, LaserTurretPack] = 0;
$ItemMax[armorfBurster, RocketPack] = 0;
$ItemMax[armorfBurster, PlasmaTurretPack] = 0;
$ItemMax[armorfBurster, CloakingDevice] = 0;
$ItemMax[armorfBurster, StealthShieldPack] = 0;
$ItemMax[armorfBurster, MortarTurretPack] = 0;
$ItemMax[armorfBurster, Laptop] = 0;
$ItemMax[armorfBurster, ShockTurretPack] = 0;
$ItemMax[armorfBurster, RegenerationPack] = 0;
$ItemMax[armorfBurster, LightningPack] = 0;
$ItemMax[armorfBurster, OpticPack] = 0;
$ItemMax[armorfBurster, SMRPack] = 0;
$ItemMax[armorfBurster, RailTurretPack] = 0;
$ItemMax[armorfBurster, VulcanTurretPack] = 0;
$ItemMax[armorfBurster, TrackerMissilePack] = 1;
$ItemMax[armorfBurster, TrackerMissileAmmo] = 8;
$ItemMax[armormSpy, Boost] = 3;
$ItemMax[armormSpy, Plastique] = 0;
$ItemMax[armormSpy, Gaussgun] = 0;
$ItemMax[armormSpy, LaserTurretPack] = 0;
$ItemMax[armormSpy, RocketPack] = 0;
$ItemMax[armormSpy, PlasmaTurretPack] = 1;
$ItemMax[armormSpy, CloakingDevice] = 0;
$ItemMax[armormSpy, StealthShieldPack] = 0;
$ItemMax[armormSpy, Laptop] = 1;
$ItemMax[armormSpy, MortarTurretPack] = 0;
$ItemMax[armormSpy, ShockTurretPack] = 0;
$ItemMax[armormSpy, RegenerationPack] = 0;
$ItemMax[armormSpy, LightningPack] = 0;
$ItemMax[armormSpy, OpticPack] = 0;
$ItemMax[armormSpy, SMRPack] = 0;
$ItemMax[armormSpy, RailTurretPack] = 0;
$ItemMax[armormSpy, VulcanTurretPack] = 0;
$ItemMax[armorfSpy, Boost] = 3;
$ItemMax[armorfSpy, Plastique] = 0;
$ItemMax[armorfSpy, Gaussgun] = 0;
$ItemMax[armorfSpy, LaserTurretPack] = 0;
$ItemMax[armorfSpy, RocketPack] = 0;
$ItemMax[armorfSpy, PlasmaTurretPack] = 1;
$ItemMax[armorfSpy, CloakingDevice] = 0;
$ItemMax[armorfSpy, StealthShieldPack] = 0;
$ItemMax[armorfSpy, Laptop] = 1;
$ItemMax[armorfSpy, MortarTurretPack] = 0;
$ItemMax[armorfSpy, ShockTurretPack] = 0;
$ItemMax[armorfSpy, RegenerationPack] = 0;
$ItemMax[armorfSpy, LightningPack] = 0;
$ItemMax[armorfSpy, OpticPack] = 0;
$ItemMax[armorfSpy, SMRPack] = 0;
$ItemMax[armorfSpy, RailTurretPack] = 0;
$ItemMax[armorfSpy, VulcanTurretPack] = 0;
$ItemMax[armormEngineer, RepairTurretPack] = 1;
$ItemMax[armormEngineer, Boost] = 4;
$ItemMax[armormEngineer, Plastique] = 0;
$ItemMax[armormEngineer, Gaussgun] = 0;
$ItemMax[armormEngineer, LaserTurretPack] = 1;
$ItemMax[armormEngineer, RocketPack] = 1;
$ItemMax[armormEngineer, NukeTurretPack] = 1;
$ItemMax[armormEngineer, PlasmaTurretPack] = 1;
$ItemMax[armormEngineer, CloakingDevice] = 0;
$ItemMax[armormEngineer, StealthShieldPack] = 0;
$ItemMax[armormEngineer, Laptop] = 1;
$ItemMax[armormEngineer, ShockTurretPack] = 1;
$ItemMax[armormEngineer, MortarTurretPack] = 1;
$ItemMax[armormEngineer, RegenerationPack] = 0;
$ItemMax[armormEngineer, LightningPack] = 0;
$ItemMax[armormEngineer, OpticPack] = 0;
$ItemMax[armormEngineer, SMRPack] = 1;
$ItemMax[armormEngineer, RailTurretPack] = 1;
$ItemMax[armormEngineer, VulcanTurretPack] = 1;
$ItemMax[armormEngineer, HFlameTurretPack] = 1;
$ItemMax[armormEngineer, ElecTurretPack] = 1;
$ItemMax[armormEngineer, FlameTurretPack] = 1;
$ItemMax[armormEngineer, AAPack] = 1;
$ItemMax[armormEngineer, BarragePack] = 1;
$ItemMax[armorfEngineer, RepairTurretPack] = 1;
$ItemMax[armorfEngineer, Boost] = 4;
$ItemMax[armorfEngineer, Plastique] = 0;
$ItemMax[armorfEngineer, Gaussgun] = 0;
$ItemMax[armorfEngineer, LaserTurretPack] = 1;
$ItemMax[armorfEngineer, RocketPack] = 1;
$ItemMax[armorfEngineer, PlasmaTurretPack] = 1;
$ItemMax[armorfEngineer, CloakingDevice] = 0;
$ItemMax[armorfEngineer, StealthShieldPack] = 0;
$ItemMax[armorfEngineer, Laptop] = 1;
$ItemMax[armorfEngineer, ShockTurretPack] = 1;
$ItemMax[armorfEngineer, MortarTurretPack] = 1;
$ItemMax[armorfEngineer, RegenerationPack] = 0;
$ItemMax[armorfEngineer, LightningPack] = 0;
$ItemMax[armorfEngineer, OpticPack] = 0;
$ItemMax[armorfEngineer, SMRPack] = 1;
$ItemMax[armorfEngineer, RailTurretPack] = 1;
$ItemMax[armorfEngineer, VulcanTurretPack] = 1;
$ItemMax[armorfEngineer, HFlameTurretPack] = 1;
$ItemMax[armorfEngineer, ElecTurretPack] = 1;
$ItemMax[armorfEngineer, FlameTurretPack] = 1;
$ItemMax[armorfEngineer, AAPack] = 1;
$ItemMax[armorfEngineer, BarragePack] = 1;
$ItemMax[armormAlien, Boost] = 4;
$ItemMax[armormAlien, Plastique] = 0;
$ItemMax[armormAlien, LaserTurretPack] = 0;
$ItemMax[armormAlien, RocketPack] = 0;
$ItemMax[armormAlien, PlasmaTurretPack] = 0;
$ItemMax[armormAlien, CloakingDevice] = 1;
$ItemMax[armormAlien, StealthShieldPack] = 0;
$ItemMax[armormAlien, MortarTurretPack] = 0;
$ItemMax[armormAlien, Laptop] = 0;
$ItemMax[armormAlien, ShockTurretPack] = 0;
$ItemMax[armormAlien, RegenerationPack] = 1;
$ItemMax[armormAlien, LightningPack] = 1;
$ItemMax[armormAlien, OpticPack] = 0;
$ItemMax[armormAlien, SMRPack] = 0;
$ItemMax[armormAlien, RailTurretPack] = 0;
$ItemMax[armormAlien, VulcanTurretPack] = 0;
$ItemMax[armorfAlien, Boost] = 4;
$ItemMax[armorfAlien, Plastique] = 0;
$ItemMax[armorfAlien, LaserTurretPack] = 0;
$ItemMax[armorfAlien, RocketPack] = 0;
$ItemMax[armorfAlien, PlasmaTurretPack] = 0;
$ItemMax[armorfAlien, CloakingDevice] = 1;
$ItemMax[armorfAlien, StealthShieldPack] = 0;
$ItemMax[armorfAlien, MortarTurretPack] = 0;
$ItemMax[armorfAlien, Laptop] = 0;
$ItemMax[armorfAlien, ShockTurretPack] = 0;
$ItemMax[armorfAlien, RegenerationPack] = 1;
$ItemMax[armorfAlien, LightningPack] = 1;
$ItemMax[armorfAlien, OpticPack] = 0;
$ItemMax[armorfAlien, SMRPack] = 0;
$ItemMax[armorfAlien, RailTurretPack] = 0;
$ItemMax[armorfAlien, VulcanTurretPack] = 0;
//NEW ARMOURS ADDED IN BY PALADIN FOR WARHAMMER 40K MOD
//Dark Reaper
$ItemMax[armormCommando, Boost] = 3;
$ItemMax[armormCommando, Plastique] = 0;
$ItemMax[armormCommando, Gaussgun] = 0;
$ItemMax[armormCommando, LaserTurretPack] = 0;
$ItemMax[armormCommando, RocketPack] = 1;
$ItemMax[armormCommando, PlasmaTurretPack] = 1;
$ItemMax[armormCommando, CloakingDevice] = 0;
$ItemMax[armormCommando, StealthShieldPack] = 1;
$ItemMax[armormCommando, Laptop] = 1;
$ItemMax[armormCommando, MortarTurretPack] = 0;
$ItemMax[armormCommando, ShockTurretPack] = 0;
$ItemMax[armormCommando, RegenerationPack] = 1;
$ItemMax[armormCommando, LightningPack] = 1;
$ItemMax[armormCommando, OpticPack] = 1;
$ItemMax[armormCommando, SMRPack] = 0;
$ItemMax[armormCommando, RailTurretPack] = 0;
$ItemMax[armormCommando, VulcanTurretPack] = 0;
$ItemMax[armormCommando, ImRecPack]=1;
$ItemMax[armormCommando, MassDriver] = 1;
$ItemMax[armormCommando, MassAmmo] = 30;
$ItemMax[armorfCommando, Boost] = 3;
$ItemMax[armorfCommando, Plastique] = 0;
$ItemMax[armorfCommando, Gaussgun] = 0;
$ItemMax[armorfCommando, LaserTurretPack] = 0;
$ItemMax[armorfCommando, RocketPack] = 1;
$ItemMax[armorfCommando, PlasmaTurretPack] = 1;
$ItemMax[armorfCommando, CloakingDevice] = 0;
$ItemMax[armorfCommando, StealthShieldPack] = 1;
$ItemMax[armorfCommando, Laptop] = 1;
$ItemMax[armorfCommando, MortarTurretPack] = 0;
$ItemMax[armorfCommando, ShockTurretPack] = 0;
$ItemMax[armorfCommando, RegenerationPack] = 1;
$ItemMax[armorfCommando, LightningPack] = 1;
$ItemMax[armorfCommando, OpticPack] = 1;
$ItemMax[armorfCommando, SMRPack] = 0;
$ItemMax[armorfCommando, RailTurretPack] = 0;
$ItemMax[armorfCommando, VulcanTurretPack] = 0;
$ItemMax[armorfCommando, ImRecPack]=1;
$ItemMax[armorfCommando, MassDriver] = 1;
$ItemMax[armorfCommando, MassAmmo] = 30;
//WraithLord
$ItemMax[armorDestroyer, Boost] = 3;
$ItemMax[armorDestroyer, Plastique] = 0;
$ItemMax[armorDestroyer, Gaussgun] = 1;
$ItemMax[armorDestroyer, LaserTurretPack] = 0;
$ItemMax[armorDestroyer, RocketPack] = 1;
$ItemMax[armorDestroyer, PlasmaTurretPack] = 1;
$ItemMax[armorDestroyer, CloakingDevice] = 1;
$ItemMax[armorDestroyer, StealthShieldPack] = 1;
$ItemMax[armorDestroyer, Laptop] = 1;
$ItemMax[armorDestroyer, MortarTurretPack] = 0;
$ItemMax[armorDestroyer, ShockTurretPack] = 0;
$ItemMax[armorDestroyer, RegenerationPack] = 1;
$ItemMax[armorDestroyer, LightningPack] = 1;
$ItemMax[armorDestroyer, OpticPack] = 1;
$ItemMax[armorDestroyer, SMRPack] = 1;
$ItemMax[armorDestroyer, RailTurretPack] = 0;
$ItemMax[armorDestroyer, VulcanTurretPack] = 0;
$ItemMax[armorDestroyer, ImRecPack]=1;
$ItemMax[armorDestroyer, TrackerMissilePack] = 1;
$ItemMax[armorDestroyer, TrackerMissileAmmo] = 16;
$ItemMax[armorDestroyer, PhotonPack] = 1;
$ItemMax[armorDestroyer, MassDriver] = 0;
$ItemMax[armorDestroyer, MassAmmo] = 30;
//Warp Spider
$ItemMax[armormLoader, Boost] = 3;
$ItemMax[armormLoader, Plastique] = 0;
$ItemMax[armormLoader, Gaussgun] = 0;
$ItemMax[armormLoader, LaserTurretPack] = 0;
$ItemMax[armormLoader, RocketPack] = 1;
$ItemMax[armormLoader, PlasmaTurretPack] = 1;
$ItemMax[armormLoader, CloakingDevice] = 0;
$ItemMax[armormLoader, StealthShieldPack] = 1;
$ItemMax[armormLoader, Laptop] = 1;
$ItemMax[armormLoader, MortarTurretPack] = 0;
$ItemMax[armormLoader, ShockTurretPack] = 0;
$ItemMax[armormLoader, RegenerationPack] = 1;
$ItemMax[armormLoader, LightningPack] = 1;
$ItemMax[armormLoader, OpticPack] = 1;
$ItemMax[armormLoader, SMRPack] = 1;
$ItemMax[armormLoader, RailTurretPack] = 0;
$ItemMax[armormLoader, VulcanTurretPack] = 0;
$ItemMax[armorfLoader, Boost] = 3;
$ItemMax[armorfLoader, Plastique] = 0;
$ItemMax[armorfLoader, Gaussgun] = 0;
$ItemMax[armorfLoader, LaserTurretPack] = 0;
$ItemMax[armorfLoader, RocketPack] = 1;
$ItemMax[armorfLoader, PlasmaTurretPack] = 1;
$ItemMax[armorfLoader, CloakingDevice] = 0;
$ItemMax[armorfLoader, StealthShieldPack] = 1;
$ItemMax[armorfLoader, Laptop] = 1;
$ItemMax[armorfLoader, MortarTurretPack] = 0;
$ItemMax[armorfLoader, ShockTurretPack] = 0;
$ItemMax[armorfLoader, RegenerationPack] = 1;
$ItemMax[armorfLoader, LightningPack] = 1;
$ItemMax[armorfLoader, OpticPack] = 1;
$ItemMax[armorfLoader, SMRPack] = 1;
$ItemMax[armorfLoader, RailTurretPack] = 0;
$ItemMax[armorfLoader, VulcanTurretPack] = 0;
//SWOOPING HAWKS
$ItemMax[armormSprint, Boost] = 3;
$ItemMax[armormSprint, Plastique] = 0;
$ItemMax[armormSprint, Gaussgun] = 0;
$ItemMax[armormSprint, LaserTurretPack] = 0;
$ItemMax[armormSprint, RocketPack] = 1;
$ItemMax[armormSprint, PlasmaTurretPack] = 1;
$ItemMax[armormSprint, CloakingDevice] = 0;
$ItemMax[armormSprint, StealthShieldPack] = 1;
$ItemMax[armormSprint, Laptop] = 1;
$ItemMax[armormSprint, MortarTurretPack] = 0;
$ItemMax[armormSprint, ShockTurretPack] = 0;
$ItemMax[armormSprint, RegenerationPack] = 1;
$ItemMax[armormSprint, LightningPack] = 1;
$ItemMax[armormSprint, OpticPack] = 1;
$ItemMax[armormSprint, SMRPack] = 0;
$ItemMax[armormSprint, RailTurretPack] = 0;
$ItemMax[armormSprint, VulcanTurretPack] = 0;
$ItemMax[armorfSprint, Boost] = 3;
$ItemMax[armorfSprint, Plastique] = 0;
$ItemMax[armorfSprint, Gaussgun] = 0;
$ItemMax[armorfSprint, LaserTurretPack] = 0;
$ItemMax[armorfSprint, RocketPack] = 1;
$ItemMax[armorfSprint, PlasmaTurretPack] = 1;
$ItemMax[armorfSprint, CloakingDevice] = 0;
$ItemMax[armorfSprint, StealthShieldPack] = 1;
$ItemMax[armorfSprint, Laptop] = 1;
$ItemMax[armorfSprint, MortarTurretPack] = 0;
$ItemMax[armorfSprint, ShockTurretPack] = 0;
$ItemMax[armorfSprint, RegenerationPack] = 1;
$ItemMax[armorfSprint, LightningPack] = 1;
$ItemMax[armorfSprint, OpticPack] = 1;
$ItemMax[armorfSprint, SMRPack] = 0;
$ItemMax[armorfSprint, RailTurretPack] = 0;
$ItemMax[armorfSprint, VulcanTurretPack] = 0;
$ItemMax[dmarmor, Boost] = 4;
$ItemMax[dmarmor, Plastique] = 1;
$ItemMax[dmarmor, IonTurretPack] = 0;
$ItemMax[dmarmor, LaserTurretPack] = 0;
$ItemMax[dmarmor, RocketPack] = 0;
$ItemMax[dmarmor, PlasmaTurretPack] = 0;
$ItemMax[dmarmor, CloakingDevice] = 0;
$ItemMax[dmarmor, StealthShieldPack] = 0;
$ItemMax[dmarmor, MortarTurretPack] = 0;
$ItemMax[dmarmor, Laptop] = 0;
$ItemMax[dmarmor, ShockTurretPack] = 0;
$ItemMax[dmarmor, RegenerationPack] = 1;
$ItemMax[dmarmor, LightningPack] = 1;
$ItemMax[dmarmor, OpticPack] = 1;
$ItemMax[dmarmor, SMRPack] = 1;
$ItemMax[dmarmor, RailTurretPack] = 1;
$ItemMax[dmarmor, VulcanTurretPack] = 1;
$ItemMax[dmfemale, Boost] = 4;
$ItemMax[dmfemale, Plastique] = 1;
$ItemMax[dmfemale, IonTurretPack] = 0;
$ItemMax[dmfemale, LaserTurretPack] = 0;
$ItemMax[dmfemale, RocketPack] = 0;
$ItemMax[dmfemale, PlasmaTurretPack] = 0;
$ItemMax[dmfemale, CloakingDevice] = 0;
$ItemMax[dmfemale, StealthShieldPack] = 0;
$ItemMax[dmfemale, MortarTurretPack] = 0;
$ItemMax[dmfemale, Laptop] = 0;
$ItemMax[dmfemale, ShockTurretPack] = 0;
$ItemMax[dmfemale, RegenerationPack] = 1;
$ItemMax[dmfemale, LightningPack] = 1;
$ItemMax[dmfemale, OpticPack] = 1;
$ItemMax[dmfemale, SMRPack] = 1;
$ItemMax[dmfemale, RailTurretPack] = 1;
$ItemMax[dmfemale, VulcanTurretPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, AcceleratorDevicePack] = 0; // Light 
$ItemMax[armorfSniper, AcceleratorDevicePack] = 0; 
$ItemMax[armormMercenary, AcceleratorDevicePack] = 0; // Medium 
$ItemMax[armorfMercenary, AcceleratorDevicePack] = 0; 
$ItemMax[harmor, AcceleratorDevicePack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, AcceleratorDevicePack] = 0; // Scout
$ItemMax[armorfScout, AcceleratorDevicePack] = 0; 
$ItemMax[armormSpy, AcceleratorDevicePack] = 0; // Spy
$ItemMax[armorfSpy, AcceleratorDevicePack] = 0; 
$ItemMax[armormBurster, AcceleratorDevicePack] = 0; // Burster
$ItemMax[armorfBurster, AcceleratorDevicePack] = 0; 
$ItemMax[armormEngineer, AcceleratorDevicePack] = 1; // Engineer
$ItemMax[armorfEngineer, AcceleratorDevicePack] = 1; 
$ItemMax[armormAlien, AcceleratorDevicePack] = 0; // Alien
$ItemMax[armorfAlien, AcceleratorDevicePack] = 0; 
$ItemMax[armorCyborg, AcceleratorDevicePack] = 0; // Cyborg

$ItemMax[dmarmor, AcceleratorDevicePack] = 0; // Deathmatch
$ItemMax[dmfemale, AcceleratorDevicePack] = 0;

 // "Base" armor
$ItemMax[armormSniper, BlastWallPack] = 0; // Light 
$ItemMax[armorfSniper, BlastWallPack] = 0; 
$ItemMax[armormMercenary, BlastWallPack] = 0; // Medium 
$ItemMax[armorfMercenary, BlastWallPack] = 0; 
$ItemMax[harmor, BlastWallPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, BlastWallPack] = 0; // Scout
$ItemMax[armorfScout, BlastWallPack] = 0; 
$ItemMax[armormSpy, BlastWallPack] = 0; // Spy
$ItemMax[armorfSpy, BlastWallPack] = 0; 
$ItemMax[armormBurster, BlastWallPack] = 0; // Burster
$ItemMax[armorfBurster, BlastWallPack] = 0; 
$ItemMax[armormEngineer, BlastWallPack] = 1; // Engineer
$ItemMax[armorfEngineer, BlastWallPack] = 1; 
$ItemMax[armormAlien, BlastWallPack] = 0; // Alien
$ItemMax[armorfAlien, BlastWallPack] = 0; 
$ItemMax[armorCyborg, BlastWallPack] = 0; // Cyborg

$ItemMax[dmarmor, BlastWallPack] = 0; // Deathmatch
$ItemMax[dmfemale, BlastWallPack] = 0;

$ItemMax[armormSniper, IonTurretPack] = 0; 
$ItemMax[armormMercenary, IonTurretPack] = 1; 
$ItemMax[harmor, IonTurretPack] = 1; 
$ItemMax[armorfSniper, IonTurretPack] = 0;
$ItemMax[armorfMercenary, IonTurretPack] = 1; 
$ItemMax[armormScout, IonTurretPack] = 0; 
$ItemMax[armormBurster, IonTurretPack] = 0; 
$ItemMax[armorCyborg, IonTurretPack] = 1; 
$ItemMax[armorfScout, IonTurretPack] = 0; 
$ItemMax[armorfBurster, IonTurretPack] = 0; 
$ItemMax[armormSpy, IonTurretPack] = 0; 
$ItemMax[armorfSpy, IonTurretPack] = 0; 
$ItemMax[armormEngineer, IonTurretPack] = 1;
$ItemMax[armorfEngineer, IonTurretPack] = 1;
$ItemMax[armormAlien, IonTurretPack] = 1; 
$ItemMax[armorfAlien, IonTurretPack] = 1; 

 // "Base" armor
$ItemMax[armormSniper, ForceFieldPack] = 1; // Light 
$ItemMax[armorfSniper, ForceFieldPack] = 1; 
$ItemMax[armormMercenary, ForceFieldPack] = 1; // Medium 
$ItemMax[armorfMercenary, ForceFieldPack] = 1; 
$ItemMax[harmor, ForceFieldPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, ForceFieldPack] = 1; // Scout
$ItemMax[armorfScout, ForceFieldPack] = 1; 
$ItemMax[armormSpy, ForceFieldPack] = 1; // Spy
$ItemMax[armorfSpy, ForceFieldPack] = 1; 
$ItemMax[armormBurster, ForceFieldPack] = 1; // Burster
$ItemMax[armorfBurster, ForceFieldPack] = 1; 
$ItemMax[armormEngineer, ForceFieldPack] = 1; // Engineer
$ItemMax[armorfEngineer, ForceFieldPack] = 1; 
$ItemMax[armormAlien, ForceFieldPack] = 1; // Alien
$ItemMax[armorfAlien, ForceFieldPack] = 1; 
$ItemMax[armorCyborg, ForceFieldPack] = 1; // Cyborg

$ItemMax[dmarmor, ForceFieldPack] = 1; // Deathmatch
$ItemMax[dmfemale, ForceFieldPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, LargeForceFieldPack] = 0; // Light 

$ItemMax[armorfSniper, LargeForceFieldPack] = 0; 
$ItemMax[armormMercenary, LargeForceFieldPack] = 0; // Medium 
$ItemMax[armorfMercenary, LargeForceFieldPack] = 0; 
$ItemMax[harmor, LargeForceFieldPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, LargeForceFieldPack] = 0; // Scout
$ItemMax[armorfScout, LargeForceFieldPack] = 0; 
$ItemMax[armormSpy, LargeForceFieldPack] = 0; // Spy
$ItemMax[armorfSpy, LargeForceFieldPack] = 0; 
$ItemMax[armormBurster, LargeForceFieldPack] = 0; // Burster
$ItemMax[armorfBurster, LargeForceFieldPack] = 0; 
$ItemMax[armormEngineer, LargeForceFieldPack] = 1; // Engineer
$ItemMax[armorfEngineer, LargeForceFieldPack] = 1; 
$ItemMax[armormAlien, LargeForceFieldPack] = 0; // Alien
$ItemMax[armorfAlien, LargeForceFieldPack] = 0; 
$ItemMax[armorCyborg, LargeForceFieldPack] = 1; // Cyborg

$ItemMax[dmarmor, LargeForceFieldPack] = 0; // Deathmatch
$ItemMax[dmfemale, LargeForceFieldPack] = 0;

 // "Base" armor
$ItemMax[armormSniper, MannequinPack] = 1; // Light 
$ItemMax[armorfSniper, MannequinPack] = 1; 
$ItemMax[armormMercenary, MannequinPack] = 1; // Medium 
$ItemMax[armorfMercenary, MannequinPack] = 1; 
$ItemMax[harmor, MannequinPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, MannequinPack] = 1; // Scout
$ItemMax[armorfScout, MannequinPack] = 1; 
$ItemMax[armormSpy, MannequinPack] = 1; // Spy
$ItemMax[armorfSpy, MannequinPack] = 1; 
$ItemMax[armormBurster, MannequinPack] = 1; // Burster
$ItemMax[armorfBurster, MannequinPack] = 1; 
$ItemMax[armormEngineer, MannequinPack] = 1; // Engineer
$ItemMax[armorfEngineer, MannequinPack] = 1; 
$ItemMax[armormAlien, MannequinPack] = 1; // Alien
$ItemMax[armorfAlien, MannequinPack] = 1; 
$ItemMax[armorCyborg, MannequinPack] = 1; // Cyborg

$ItemMax[dmarmor, MannequinPack] = 1; // Deathmatch
$ItemMax[dmfemale, MannequinPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, PlatformPack] = 0; // Light 
$ItemMax[armorfSniper, PlatformPack] = 0; 
$ItemMax[armormMercenary, PlatformPack] = 0; // Medium 
$ItemMax[armorfMercenary, PlatformPack] = 0; 


$ItemMax[harmor, PlatformPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, PlatformPack] = 0; // Scout
$ItemMax[armorfScout, PlatformPack] = 0; 
$ItemMax[armormSpy, PlatformPack] = 0; // Spy
$ItemMax[armorfSpy, PlatformPack] = 0; 
$ItemMax[armormBurster, PlatformPack] = 0; // Burster
$ItemMax[armorfBurster, PlatformPack] = 0; 
$ItemMax[armormEngineer, PlatformPack] = 1; // Engineer
$ItemMax[armorfEngineer, PlatformPack] = 1; 
$ItemMax[armormAlien, PlatformPack] = 0; // Alien
$ItemMax[armorfAlien, PlatformPack] = 0; 
$ItemMax[armorCyborg, PlatformPack] = 0; // Cyborg

$ItemMax[dmarmor, AcceleratorDevicePack] = 1; // Deathmatch
$ItemMax[dmfemale, AcceleratorDevicePack] = 1;

 // "Base" armor
$ItemMax[armormSniper, DeployableComPack] = 0; // Light 
$ItemMax[armorfSniper, DeployableComPack] = 0; 
$ItemMax[armormMercenary, DeployableComPack] = 0; // Medium 
$ItemMax[armorfMercenary, DeployableComPack] = 0; 
$ItemMax[harmor, DeployableComPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, DeployableComPack] = 0; // Scout
$ItemMax[armorfScout, DeployableComPack] = 0; 
$ItemMax[armormSpy, DeployableComPack] = 0; // Spy
$ItemMax[armorfSpy, DeployableComPack] = 0; 
$ItemMax[armormBurster, DeployableComPack] = 0; // Burster
$ItemMax[armorfBurster, DeployableComPack] = 0; 
$ItemMax[armormEngineer, DeployableComPack] = 1; // Engineer
$ItemMax[armorfEngineer, DeployableComPack] = 1; 
$ItemMax[armormAlien, DeployableComPack] = 0; // Alien
$ItemMax[armorfAlien, DeployableComPack] = 0; 
$ItemMax[armorCyborg, DeployableComPack] = 1; // Cyborg

$ItemMax[dmarmor, DeployableComPack] = 0; // Deathmatch
$ItemMax[dmfemale, DeployableComPack] = 0;

 // "Base" armor
$ItemMax[armormSniper, DeployableInvPack] = 0; // Light 
$ItemMax[armorfSniper, DeployableInvPack] = 0; 
$ItemMax[armormMercenary, DeployableInvPack] = 0; // Medium 
$ItemMax[armorfMercenary, DeployableInvPack] = 0; 
$ItemMax[harmor, DeployableInvPack] = 1; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, DeployableInvPack] = 0; // Scout
$ItemMax[armorfScout, DeployableInvPack] = 0; 
$ItemMax[armormSpy, DeployableInvPack] = 0; // Spy
$ItemMax[armorfSpy, DeployableInvPack] = 0; 
$ItemMax[armormBurster, DeployableInvPack] = 0; // Burster
$ItemMax[armorfBurster, DeployableInvPack] = 0; 
$ItemMax[armormEngineer, DeployableInvPack] = 1; // Engineer
$ItemMax[armorfEngineer, DeployableInvPack] = 1; 
$ItemMax[armormAlien, DeployableInvPack] = 0; // Alien
$ItemMax[armorfAlien, DeployableInvPack] = 0; 
$ItemMax[armorCyborg, DeployableInvPack] = 0; // Cyborg

$ItemMax[dmarmor, DeployableInvPack] = 1; // Deathmatch
$ItemMax[dmfemale, DeployableInvPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, SpringPack] = 0; // Light 
$ItemMax[armorfSniper, SpringPack] = 0; 
$ItemMax[armormMercenary, SpringPack] = 0; // Medium 
$ItemMax[armorfMercenary, SpringPack] = 0; 
$ItemMax[harmor, SpringPack] = 0; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, SpringPack] = 0; // Scout
$ItemMax[armorfScout, SpringPack] = 0; 
$ItemMax[armormSpy, SpringPack] = 0; // Spy
$ItemMax[armorfSpy, SpringPack] = 0; 
$ItemMax[armormBurster, SpringPack] = 0; // Burster
$ItemMax[armorfBurster, SpringPack] = 0; 
$ItemMax[armormEngineer, SpringPack] = 1; // Engineer
$ItemMax[armorfEngineer, SpringPack] = 1; 
$ItemMax[armormAlien, SpringPack] = 0; // Alien
$ItemMax[armorfAlien, SpringPack] = 0; 
$ItemMax[armorCyborg, SpringPack] = 0; // Cyborg

$ItemMax[dmarmor, SpringPack] = 1; // Deathmatch
$ItemMax[dmfemale, SpringPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, TeleportPack] = 0; // Light 
$ItemMax[armorfSniper, TeleportPack] = 0; 
$ItemMax[armormMercenary, TeleportPack] = 0; // Medium 
$ItemMax[armorfMercenary, TeleportPack] = 0; 
$ItemMax[harmor, TeleportPack] = 1; // Heavy 


 // "Renegades" armor
$ItemMax[armormScout, TeleportPack] = 0; // Scout
$ItemMax[armorfScout, TeleportPack] = 0; 

$ItemMax[armormSpy, TeleportPack] = 0; // Spy
$ItemMax[armorfSpy, TeleportPack] = 0; 
$ItemMax[armormBurster, TeleportPack] = 0; // Burster
$ItemMax[armorfBurster, TeleportPack] = 0; 
$ItemMax[armormEngineer, TeleportPack] = 1; // Engineer
$ItemMax[armorfEngineer, TeleportPack] = 1; 
$ItemMax[armormAlien, TeleportPack] = 0; // Alien
$ItemMax[armorfAlien, TeleportPack] = 0; 
$ItemMax[armorCyborg, TeleportPack] = 0; // Cyborg

$ItemMax[dmarmor, TeleportPack] = 1; // Deathmatch
$ItemMax[dmfemale, TeleportPack] = 1;

 // "Base" armor
$ItemMax[armormSniper, TreePack] = 1; // Light 
$ItemMax[armorfSniper, TreePack] = 1; 
$ItemMax[armormMercenary, TreePack] = 0; // Medium 
$ItemMax[armorfMercenary, TreePack] = 0; 
$ItemMax[harmor, TreePack] = 0; // Heavy 

 // "Renegades" armor
$ItemMax[armormScout, TreePack] = 0; // Scout
$ItemMax[armorfScout, TreePack] = 0; 
$ItemMax[armormSpy, TreePack] = 0; // Spy
$ItemMax[armorfSpy, TreePack] = 0; 
$ItemMax[armormBurster, TreePack] = 0; // Burster
$ItemMax[armorfBurster, TreePack] = 0; 
$ItemMax[armormEngineer, TreePack] = 1; // Engineer
$ItemMax[armorfEngineer, TreePack] = 1; 
$ItemMax[armormAlien, TreePack] = 0; // Alien
$ItemMax[armorfAlien, TreePack] = 0; 
$ItemMax[armorCyborg, TreePack] = 0; // Cyborg


$ItemMax[dmarmor, TreePack] = 0; // Deathmatch
$ItemMax[dmfemale, TreePack] = 0;

$ItemMax[armormSniper, MechPack] = 0; 
$ItemMax[armormMercenary, MechPack] = 0; 
$ItemMax[harmor, MechPack] = 0; 
$ItemMax[armorfSniper, MechPack] = 0; 
$ItemMax[armorfMercenary, MechPack] = 0; 
$ItemMax[armormScout, MechPack] = 1; 
$ItemMax[armormBurster, MechPack] = 0; 
$ItemMax[armorCyborg, MechPack] = 0; 
$ItemMax[armorfScout, MechPack] = 1; 
$ItemMax[armorfBurster, MechPack] = 0; 
$ItemMax[armormSpy, MechPack] = 0; 
$ItemMax[armorfSpy, MechPack] = 0; 
$ItemMax[armormEngineer, MechPack] = 0; 
$ItemMax[armorfEngineer, MechPack] = 0; 
$ItemMax[armormAlien, MechPack] = 0; 
$ItemMax[armorfAlien, MechPack] = 0; 
$ItemMax[dmarmor, MechPack] = 0; 
$ItemMax[dmfemale, MechPack] = 0; 

$ItemMax[armormMercenary, DetPack] = 0; 
$ItemMax[armormSniper, DetPack] = 0; 
$ItemMax[harmor, DetPack] = 0; 
$ItemMax[armorfSniper, DetPack] = 0; 
$ItemMax[armorfMercenary, DetPack] = 0; 
$ItemMax[armormScout, DetPack] = 0; 
$ItemMax[armormBurster, DetPack] = 0; 
$ItemMax[armorCyborg, DetPack] = 0; 
$ItemMax[armorfScout, DetPack] = 0; 
$ItemMax[armorfBurster, DetPack] = 0;
$ItemMax[armormSpy, DetPack] = 0;  
$ItemMax[armorfSpy, DetPack] = 0; 
$ItemMax[armormEngineer, DetPack] = 1; 
$ItemMax[armorfEngineer, DetPack] = 1; 
$ItemMax[armormAlien, DetPack] = 0; 
$ItemMax[armorfAlien, DetPack] = 0; 
$ItemMax[dmarmor, DetPack] = 0; 
$ItemMax[dmfemale, DetPack] = 0;

 // "Base" armor
$ItemMax[armormSniper, PackOMen] = 1; // Light 
$ItemMax[armorfSniper, PackOMen] = 1; 
$ItemMax[armormMercenary, PackOMen] = 1; // Medium 
$ItemMax[armorfMercenary, PackOMen] = 1; 
$ItemMax[harmor, PackOMen] = 1; // Heavy 



// "Renegades" armor
$ItemMax[armormScout, PackOMen] = 1; // Scout
$ItemMax[armorfScout, PackOMen] = 1; 
$ItemMax[armormSpy, PackOMen] = 1; // Spy
$ItemMax[armorfSpy, PackOMen] = 1; 
$ItemMax[armormBurster, PackOMen] = 1; // Burster
$ItemMax[armorfBurster, PackOMen] = 1; 
$ItemMax[armormEngineer, PackOMen] = 1; // Engineer
$ItemMax[armorfEngineer, PackOMen] = 1; 
$ItemMax[armormAlien, PackOMen] = 1; // Alien

$ItemMax[armorfAlien, PackOMen] = 1; 
$ItemMax[armorCyborg, PackOMen] = 1; // Cyborg

$ItemMax[dmarmor, PackOMen] = 1; // Deathmatch
$ItemMax[dmfemale, PackOMen] = 1;

// TargetMarkLaser
$ItemMax[armormScout, TargetMarkLaser] = 0; // Scout
$ItemMax[armorfScout, TargetMarkLaser] = 0; 
$ItemMax[armormSpy, TargetMarkLaser] = 0; // Spy
$ItemMax[armorfSpy, TargetMarkLaser] = 0; 
$ItemMax[armormBurster, TargetMarkLaser] = 0; // Burster
$ItemMax[armorfBurster, TargetMarkLaser] = 0; 
$ItemMax[armormEngineer, TargetMarkLaser] = 0; // Engineer
$ItemMax[armorfEngineer, TargetMarkLaser] = 0; 
$ItemMax[armormAlien, TargetMarkLaser] = 0; // Alien
$ItemMax[armorfAlien, TargetMarkLaser] = 0; 
$ItemMax[armorCyborg, TargetMarkLaser] = 1; // Cyborg
$ItemMax[armormCommando, TargetMarkLaser] = 1; // Commando(Dark Reaper)
$ItemMax[armorfCommando, TargetMarkLaser] = 1; // Commando(Dark Reaper)
$ItemMax[armorDestroyer, TargerMarkLaser] = 1; //Wraithlord

$ItemMax[dmarmor, TargetMarkLaser] = 0; // Deathmatch
$ItemMax[dmfemale, TargetMarkLaser] = 0;

// PhotonPack
$ItemMax[armormScout, PhotonPack] = 0; // Scout

$ItemMax[armorfScout, PhotonPack] = 0; 
$ItemMax[armormSpy, PhotonPack] = 0; // Spy
$ItemMax[armorfSpy, PhotonPack] = 0; 
$ItemMax[armormBurster, PhotonPack] = 0; // Burster
$ItemMax[armorfBurster, PhotonPack] = 0; 
$ItemMax[armormEngineer, PhotonPack] = 0; // Engineer
$ItemMax[armorfEngineer, PhotonPack] = 0; 
$ItemMax[armormAlien, PhotonPack] = 0; // Alien
$ItemMax[armorfAlien, PhotonPack] = 0; 
$ItemMax[armorCyborg, PhotonPack] = 1; // Cyborg

$ItemMax[armormCommando, PhotonPack] = 1; //Dark Reaper
$ItemMax[armorfCommando, PhotonPack] = 1; //Dark Reaper
$ItemMax[armorDestroyer, PhotonPack] = 1; //Wraithlord

$ItemMax[dmarmor, PhotonPack] = 0; // Deathmatch
$ItemMax[dmfemale, PhotonPack] = 0;

// Tracker Missile Pack
$ItemMax[armormScout, TrackerMissilePack] = 0; // Scout

$ItemMax[armorfScout, TrackerMissilePack] = 0; 
$ItemMax[armormSpy, TrackerMissilePack] = 0; // Spy
$ItemMax[armorfSpy, TrackerMissilePack] = 0; 
$ItemMax[armormBurster, TrackerMissilePack] = 0; // Burster
$ItemMax[armorfBurster, TrackerMissilePack] = 0; 
$ItemMax[armormEngineer, TrackerMissilePack] = 0; // Engineer
$ItemMax[armorfEngineer, TrackerMissilePack] = 0; 
$ItemMax[armormAlien, TrackerMissilePack] = 0; // Alien
$ItemMax[armorfAlien, TrackerMissilePack] = 0; 
$ItemMax[armorCyborg, TrackerMissilePack] = 1; // Cyborg
$ItemMax[armormCommando, TrackerMissilePack] = 1; //Dark Reaper
$ItemMax[armorfCommando, TrackerMissilePack] = 1; //Dark Reaper
$ItemMax[armorDestroyer, TrackerMissilePack] = 1; //Wraithlord

$ItemMax[dmarmor, TrackerMissilePack] = 0; // Deathmatch
$ItemMax[dmfemale, TrackerMissilePack] = 0;

// Tracker Missiles
$ItemMax[armormScout, TrackerMissileAmmo] = 5; // Scout
$ItemMax[armorfScout, TrackerMissileAmmo] = 5; 
$ItemMax[armormSpy, TrackerMissileAmmo] = 5; // Spy
$ItemMax[armorfSpy, TrackerMissileAmmo] = 5; 
$ItemMax[armormBurster, TrackerMissileAmmo] = 7; // Burster
$ItemMax[armorfBurster, TrackerMissileAmmo] = 7; 
$ItemMax[armormEngineer, TrackerMissileAmmo] = 7; // Engineer
$ItemMax[armorfEngineer, TrackerMissileAmmo] = 7; 
$ItemMax[armormAlien, TrackerMissileAmmo] = 7; // Alien
$ItemMax[armorfAlien, TrackerMissileAmmo] = 7; 
$ItemMax[armorCyborg, TrackerMissileAmmo] = 15; // Cyborg
$ItemMax[armormCommando, TrackerMissileAmmo] = 10; //Dark Reaper
$ItemMax[armorfCommando, TrackerMissileAmmo] = 10; //Dark Reaper
$ItemMax[armorDestroyer, TrackerMissileAmmo] = 20; //Wraithlord

$ItemMax[dmarmor, TrackerMissileAmmo] = 0; // Deathmatch
$ItemMax[dmfemale, TrackerMissileAmmo] = 0;

// Tractor Device
$ItemMax[armormScout, TractorDevice] = 0; // Scout
$ItemMax[armorfScout, TractorDevice] = 0; 
$ItemMax[armormSpy, TractorDevice] = 0; // Spy
$ItemMax[armorfSpy, TractorDevice] = 0; 
$ItemMax[armormBurster, TractorDevice] = 0; // Burster
$ItemMax[armorfBurster, TractorDevice] = 0; 
$ItemMax[armormEngineer, TractorDevice] = 0; // Engineer
$ItemMax[armorfEngineer, TractorDevice] = 0; 
$ItemMax[armormAlien, TractorDevice] = 0; // Alien
$ItemMax[armorfAlien, TractorDevice] = 0; 
$ItemMax[armorCyborg, TractorDevice] = 0;// Cyborg
$ItemMax[armormCommando, TractorDevice] = 0; //Dark Reaper
$ItemMax[armorfCommando, TractorDevice] = 0; //Dark Reaper
$ItemMax[armorDestroyer, TractorDevice] = 0; //Wraithlord
$ItemMax[armormAlien, TractorDevice] = 0; //Wraithguard
$ItemMax[armorfAlien, TractorDevice] = 0; //Wraithguard

$ItemMax[dmarmor, TractorDevice] = 0; // Deathmatch
$ItemMax[dmfemale, TractorDevice] = 0;

 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 // TEAM ITEM MAXs
 //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

$TeamItemMax[IonTurretPack] = 5;
$TeamItemMax[LaserTurretPack] = 6;
$TeamItemMax[RocketPack] = 3;
$TeamItemMax[MortarTurretPack] = 1;
$TeamItemMax[PlasmaTurretPack] = 4;
$TeamItemMax[RailTurretPack] = 2;
$TeamItemMax[SatchelPack] = 25;
$TeamItemMax[ShockTurretPack] = 4;
$TeamItemMax[VulcanTurretPack] = 2;
$TeamItemMax[FlameTurretPack] = 2;
$TeamItemMax[HFlameTurretPack] = 2;
$TeamItemMax[ElecTurretPack] = 2;

$TeamItemMax[AcceleratorDevice] = 3;
$TeamItemMax[BlastWallPack] = 8; 
$TeamItemMax[CameraPack] = 10;
$TeamItemMax[ForceFieldPack] = 8; 
$TeamItemMax[LargeForceFieldPack] = 4; 
$TeamItemMax[Mannequin] = 10;
$TeamItemMax[MotionSensorPack] = 10;
$TeamItemMax[PlatformPack] = 10; 
$TeamItemMax[PulseSensorPack] = 10;
$TeamItemMax[DeployableSensorJammerPack] = 10;
$TeamItemMax[DeployableAmmoPack] = 10; 
$TeamItemMax[DeployableComPack] = 5; 
$TeamItemMax[DeployableInvPack] = 10; 
$TeamItemMax[Springboard] = 3;
$TeamItemMax[TreePack] = 10; 
