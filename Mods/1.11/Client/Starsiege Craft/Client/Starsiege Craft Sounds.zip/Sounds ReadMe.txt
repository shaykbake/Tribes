I know, eeeeeewwwwwwwwwww, a yucky plain ol' readme, oh well...


Use of these sounds is easy, put all the .wav files into your \base
directory.  I got most of the sounds from StarCraft, but I know there 
might be some that I got from some other place, if you have a sound that
is in this pack, please tell me so I can give proper credit to you.

Matthias