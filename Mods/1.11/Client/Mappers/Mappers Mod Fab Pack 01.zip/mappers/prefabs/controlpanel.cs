//---------------------------------------------------------
// Prefab by Bloodguard
//---------------------------------------------------------
// Building regristration file, for use with Mappers Mod'.
// Place this file inside *\Tribes\mappers\prefabs\
//---------------------------------------------------------

MissionRegDis(NewBloodguard, controlpanel);