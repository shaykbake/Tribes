//---------------------------------------------------------
// Prefab by Omnipotent
//---------------------------------------------------------
// Building regristration file, for use with Mappers Mod'.
// Place this file inside *\Tribes\mappers\prefabs\
//---------------------------------------------------------

MissionRegDis(NewOmnipotent, desk);