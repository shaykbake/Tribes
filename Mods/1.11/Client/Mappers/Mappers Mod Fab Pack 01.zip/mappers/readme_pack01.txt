Prefab pack 1
Dated = 16/02/2000
----------------------

This is a list of all the people that have contributed to this, the
first prefab pack:


Omnipotent = The Prefabs: barn, bench, bridge, computer, desk, hanger,
	     monitor, olbridge, pillbox, rhino, robot, seasaw, slide,
	     streetlight, telecable, teleline, & tube.

Bloodguard = The Prefabs: beam, controlpanel, deathstar2, pathway,
	     & throne.

GraphicCode = The Prefab: PB (Pillbox).

DarkEvil = The Prefab: advpill (Advanced Pillbox).

Dynamix = The Prefabs: floatpad, flytower, kiel, siam, sbunker, tblock,
	  & watchtower (ripped from their 'Balanced Missions' pack).

And Me! Nicodemus = The Prefabs: ntank1, nruin1.