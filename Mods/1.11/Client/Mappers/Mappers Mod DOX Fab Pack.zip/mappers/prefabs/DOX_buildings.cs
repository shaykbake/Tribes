//---------------------------------------------------------
// Prefab by DOX
//---------------------------------------------------------
// Building regristration file, for use with Mappers Mod'.
// Place this file inside *\Tribes\mappers\prefabs\
//---------------------------------------------------------

MissionRegDis(NewDOX, aw_fin);
MissionRegDis(NewDOX, aw_pod);
MissionRegDis(NewDOX, aw_pod_lid);
MissionRegDis(NewDOX, aw_sub);
MissionRegDis(NewDOX, be_rig);
MissionRegDis(NewDOX, beacon);
MissionRegDis(NewDOX, block1);
MissionRegDis(NewDOX, block2);
MissionRegDis(NewDOX, cc_wall);
MissionRegDis(NewDOX, ccbeaglelz);
MissionRegDis(NewDOX, ccbox);
MissionRegDis(NewDOX, ccbunker);
MissionRegDis(NewDOX, cccargoprism);
MissionRegDis(NewDOX, cccommtower);
MissionRegDis(NewDOX, ccdswordlz);
MissionRegDis(NewDOX, ccradartower);
MissionRegDis(NewDOX, ccwall_end);
MissionRegDis(NewDOX, ds_rig);
MissionRegDis(NewDOX, fc_fireblade);
MissionRegDis(NewDOX, fc_logopanel);
MissionRegDis(NewDOX, fc_thunderwolf);
MissionRegDis(NewDOX, helibunker_be);
MissionRegDis(NewDOX, helibunker_ds);
MissionRegDis(NewDOX, id_uplinktower);
MissionRegDis(NewDOX, idariel);
MissionRegDis(NewDOX, idhangar);
MissionRegDis(NewDOX, idtower);
MissionRegDis(NewDOX, jcbase);
MissionRegDis(NewDOX, jcbridgend1);
MissionRegDis(NewDOX, jcbridgend2);
MissionRegDis(NewDOX, jcbridgespan1);
MissionRegDis(NewDOX, jcbridgespan2);
MissionRegDis(NewDOX, jstower_base);
MissionRegDis(NewDOX, lightstand);
MissionRegDis(NewDOX, minesign);
MissionRegDis(NewDOX, mm_bridge);
MissionRegDis(NewDOX, mm_hangar);
MissionRegDis(NewDOX, mx3);
MissionRegDis(NewDOX, sc_flagstand);
MissionRegDis(NewDOX, sc_uplinktower);
MissionRegDis(NewDOX, sensor_tower);
MissionRegDis(NewDOX, sw_base);
MissionRegDis(NewDOX, sw_sign);
MissionRegDis(NewDOX, sw_turretbase);
MissionRegDis(NewDOX, turretbase);