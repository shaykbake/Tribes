//---------------------------------------------------------
// Prefab by ToasT
//---------------------------------------------------------
// Building regristration file, for use with Mappers Mod'.
// Place this file inside *\Tribes\mappers\prefabs\
//---------------------------------------------------------

MissionRegDis(NewToasT, gatewall);