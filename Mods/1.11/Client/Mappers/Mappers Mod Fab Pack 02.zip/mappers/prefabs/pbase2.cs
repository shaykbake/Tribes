//---------------------------------------------------------
// Prefab by Ecliptici
//---------------------------------------------------------
// Building regristration file, for use with Mappers Mod'.
// Place this file inside *\Tribes\mappers\prefabs\
//---------------------------------------------------------

MissionRegDis(NewEcliptici, pbase2);