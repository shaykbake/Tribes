Prefab pack 2 readme
Dated = 02/05/2000
----------------------

This is a list of all the people that have contributed to this, the
second prefab pack:


Ecliptici = The Prefabs: pbase2 & tbase3.

Ruffy =     The Prefabs: acid, acidflag, acidflag2, rbase,
	    rbridge, & rcapt.

ToasT =	    The Prefabs: gatedoor, gatewall, & tower.



To install, just extract all files (keeping the directory structure
intact) to the *\Tribes\ directory.