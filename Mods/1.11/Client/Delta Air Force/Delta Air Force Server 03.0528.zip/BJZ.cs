// PILOT

PlayerData bjz
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;
   maxJetSideForceFactor = 0.0;
   maxJetForwardVelocity = 0;
   minJetEnergy = 200;
   jetForce = 0;
   jetEnergyDrain = 0.0;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundtraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 12;
	damageScale = 0.01;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   //animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[19] = { "run", none, 1, true, false, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };


   //jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.35;
   boxDepth = 0.35;
   boxNormalHeight = 2.05;
   boxCrouchHeight = 1.5;

   boxNormalHeadPercentage  = 0.90;
   boxNormalTorsoPercentage = 0.25;
   boxCrouchHeadPercentage  = 0.80;
   boxCrouchTorsoPercentage = 0.30;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

// SPECOPS FEMALE

$DamageScale[bjz, $LandingDamageType] = 1.0;
$DamageScale[bjz, $ImpactDamageType] = 1.0;	
$DamageScale[bjz, $CrushDamageType] = 1.0;	
$DamageScale[bjz, $BulletDamageType] = 1.2;
$DamageScale[bjz, $PlasmaDamageType] = 1.0;
$DamageScale[bjz, $EnergyDamageType] = 1.3;
$DamageScale[bjz, $ExplosionDamageType] = 1.0;
$DamageScale[bjz, $MissileDamageType] = 1.0;
$DamageScale[bjz, $ShrapnelDamageType] = 1.2;
$DamageScale[bjz, $DebrisDamageType] = 1.2;
$DamageScale[bjz, $LaserDamageType] = 1.0;
$DamageScale[bjz, $MortarDamageType] = 1.3;
$DamageScale[bjz, $BlasterDamageType] = 1.3;
$DamageScale[bjz, $ElectricityDamageType] = 1.0;
$DamageScale[bjz, $MineDamageType] = 1.2;
$DamageScale[bjz, $ChargeDamageType] = 1.2;
$DamageScale[bjz, $AirstrikeDamageType] = 1.0;
$DamageScale[bjz, $BleedDamageType] = 1.0;
$DamageScale[bjz, $GrenadeDamageType] = 1.0;
$DamageScale[bjz, $PoisonDamageType] = 1.0;
$DamageScale[bjz, $SmokeDamageType] = 1.0;
$DamageScale[bjz, $StabDamageType] = 1.0;

$ItemMax[bjz, Blaster] = 1;
$ItemMax[bjz, Chaingun] = 1;
$ItemMax[bjz, Disclauncher] = 1;
$ItemMax[bjz, GrenadeLauncher] = 1;
$ItemMax[bjz, Mortar] = 1;
$ItemMax[bjz, PlasmaGun] = 1;
$ItemMax[bjz, LaserRifle] = 1;
$ItemMax[bjz, EnergyRifle] = 1;
$ItemMax[bjz, TargetingLaser] = 1;
$ItemMax[bjz, MineAmmo] = 3;
$ItemMax[bjz, Grenade] = 5;
$ItemMax[bjz, Beacon] = 3;
$ItemMax[bjz, SOCOM] = 1;
$ItemMax[bjz, OICW] = 1;
$ItemMax[bjz, SAW] = 1;
$ItemMax[bjz, MP5] = 1;
$ItemMax[bjz, PSG1] = 1;
$ItemMax[bjz, FiftyCal] = 1;
$ItemMax[bjz, LAW] = 1;
$ItemMax[bjz, AutoShotgun] = 1;
$ItemMax[bjz, Howitzer] = 1;
$ItemMax[bjz, Airstrike] = 1;
$ItemMax[bjz, Stinger] = 1;
$ItemMax[bjz, Flamethrower] = 1;

$ItemMax[bjz, BulletAmmo] = 100;
$ItemMax[bjz, PlasmaAmmo] = 30;
$ItemMax[bjz, DiscAmmo] = 15;
$ItemMax[bjz, GrenadeAmmo] = 10;
$ItemMax[bjz, MortarAmmo] = 10;
$ItemMax[bjz, Knife] = 1;
$ItemMax[bjz, SOCOMAmmo] = 50;
$ItemMax[bjz, OICWAmmo] = 0;
$ItemMax[bjz, SAWAmmo] = 0;
$ItemMax[bjz, MP5Ammo] = 200;
$ItemMax[bjz, PSG1Ammo] = 0;
$ItemMax[bjz, FiftyCalAmmo] = 0;
$ItemMax[bjz, LAWAmmo] = 0;
$ItemMax[bjz, AutoShotgunAmmo] = 0;
$ItemMax[bjz, HowitzerAmmo] = 0;
$ItemMax[bjz, StingerAmmo] = 2;
$ItemMax[bjz, FlameAmmo] = 0;

$ItemMax[bjz, EnergyPack] = 1;
$ItemMax[bjz, RepairPack] = 1;
$ItemMax[bjz, ShieldPack] = 1;
$ItemMax[bjz, SensorJammerPack] = 1;
$ItemMax[bjz, MotionSensorPack] = 0;
$ItemMax[bjz, PulseSensorPack] = 0;
$ItemMax[bjz, DeployableSensorJammerPack] = 1;
$ItemMax[bjz, DeployableHealthPack] = 0;
$ItemMax[bjz, CameraPack] = 1;
$ItemMax[bjz, TurretPack] = 0;
$ItemMax[bjz, AmmoPackSmall] = 1;
$ItemMax[bjz, AmmoPackHeavy] = 1;
$ItemMax[bjz, AmmoPackExp] = 1;
$ItemMax[bjz,  RepairKit] = 1;
$ItemMax[bjz, DeployableInvPack] = 0;
$ItemMax[bjz, DeployableAmmoPack] = 0;
$ItemMax[bjz, TwentyPack] = 0;
$ItemMax[bjz, HowitzerPack] = 0;
$ItemMax[bjz, SAMPack] = 0;
$ItemMax[bjz, Charge] = 1;
$ItemMax[bjz, AirstrikePack] = 1;
$ItemMax[bjz, GrapplePack] = 1;
$ItemMax[bjz, GrappleHook] = 1;
$ItemMax[bjz, ReloaderPack] = 1;
$ItemMax[bjz, Parachute] = 1;
$ItemMax[bjz, FuelPack] = 1;
$ItemMax[bjz, PortGenPack] = 0;
$ItemMax[bjz, AAPack] = 0;
$ItemMax[bjz, MedicPack] = 1;

$MaxWeapons[bjz] = 10;
