DAF ClientPack 


RELEASE UPDATE (5/28/03):
Provides clientside support for the third ("2") firelinking option on vehicles.
Using your numberpad, you may select hardpoints 0-9, "." for 10, or "+" for primary guns
to fire. Pressing one of them again will deselect that particular hardpoint. Pressing
"Enter" on the numberpad will clear all selected hardpoints.


*Note* If you already have the DF clientpack converted over for DAF, then you dont need
to download or install the second part of this download. You already have it.
What it is:
This instalation is for the DAF Clientpack, for use with the DAF Tribes mod.

What it will do:
-Everything that the DF clientpack does
 -Change sounds
 -Change weapon shapes
 -Change vehicle/station/turret skins
 -Make things much more interesting.
-Allow the execution of a barrel roll with the fighter jets, by pressing m while tipped to one side.
-Disable personal jets so that you never worry about getting stuck.

Basically this is a replacement for those that use the DF clientpack for DAF clientpack.
However, this can also be used (and probably should) by those that dont use the DF clientpack,
but still play DAF. It will make for a much more enjoyable game.
On another note, the scripts in here are basically a hack, as I am not proficient in the use of 
scripts, but they do work properly. If anyone out there knows a better or more efficient way of 
doing what i've done, drop me an email to help fix it. If your suggestion and help are used, you 
will be listed among the benefactors in the credits along side your contribution.

Instructions for instalation:
-Download both files.
-Extract the files in both zips into a temporary folder.
-Move the free floating files (AutoExec.cs, DAFChangeables.cs, EndDeltaAirForce.cs, and 
	StartDeltaAirForce.cs) into your /tribes/config/ folder. If you already have an existing 
	AutoExec.cs file, then add the information in this one to the end of that one. I don't 
	make any assurances that it will work properly for you, as i did this without any
	previous AutoExec.cs files, but it should be alright.
-Open DAFChangeables and follow the header directions to make sure your controls are binding to
	the controls you want them binded to, as opposed to the default setup.
**If you already have DF converted over, you can stop there. You got all the new stuff in.
-Move the DeltaAirForce folder into your /tribes/ folder.
-Move the Skins folder into your /tribes/DeltaAirForce/ folder.
-Connect to a DAF site and start playing!

Disclaimer of use.
Everything contained in these zip files are either my intelectual property (the 4 main *.cs files)
or have a disclaimer of their own steming from the original DF team (www.planettribes.com/deltaforce)
Any claims otherwise are made illegally and subject to copywrite laws. With the non DF files, you 
are free to use all or parts of the code for your own uses. By using these items, you know
and understand this. 

Made by Jesus 10/21/02

Questions can be sent to Deathknight@hehe.com or posted on the forum at www.jmods.bravepages.com