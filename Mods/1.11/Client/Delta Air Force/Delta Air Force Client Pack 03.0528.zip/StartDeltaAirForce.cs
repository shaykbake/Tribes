
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Dont change anything below here unless you know
//| What your doing.
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

EditActionMap("playMap.sae");	
bindCommand($DAF_MineInput, make, $DAF_Mine, TO, "throwStart(\"Mine\");");
bindCommand($DAF_GrenadeInput, make, $DAF_Grenade, TO, "throwStart(\"Grenade\");");

// For firelinking
bindCommand($DAF_ClearFLInput, make, $DAF_ClearFL, TO, 		"remoteEval(2048,selectFireGroup,\"Clear\");");
bindCommand($DAF_FLSetPrimeInput, make, $DAF_FLSetPrime, TO, 	"remoteEval(2048,selectFireGroup,\"-1\");");
bindCommand($DAF_FLSet0Input, make, $DAF_FLSet0, TO, 		"remoteEval(2048,selectFireGroup,\"0\");");
bindCommand($DAF_FLSet1Input, make, $DAF_FLSet1, TO, 		"remoteEval(2048,selectFireGroup,\"1\");");
bindCommand($DAF_FLSet2Input, make, $DAF_FLSet2, TO, 		"remoteEval(2048,selectFireGroup,\"2\");");
bindCommand($DAF_FLSet3Input, make, $DAF_FLSet3, TO, 		"remoteEval(2048,selectFireGroup,\"3\");");
bindCommand($DAF_FLSet4Input, make, $DAF_FLSet4, TO, 		"remoteEval(2048,selectFireGroup,\"4\");");
bindCommand($DAF_FLSet5Input, make, $DAF_FLSet5, TO, 		"remoteEval(2048,selectFireGroup,\"5\");");
bindCommand($DAF_FLSet6Input, make, $DAF_FLSet6, TO, 		"remoteEval(2048,selectFireGroup,\"6\");");
bindCommand($DAF_FLSet7Input, make, $DAF_FLSet7, TO, 		"remoteEval(2048,selectFireGroup,\"7\");");
bindCommand($DAF_FLSet8Input, make, $DAF_FLSet8, TO, 		"remoteEval(2048,selectFireGroup,\"8\");");
bindCommand($DAF_FLSet9Input, make, $DAF_FLSet9, TO, 		"remoteEval(2048,selectFireGroup,\"9\");");
bindCommand($DAF_FLSet10Input, make, $DAF_FLSet10, TO,		"remoteEval(2048,selectFireGroup,\"10\");");

// Disable right mouse button (jet) every time.
// If you want the jet button to do something different instead, then just change the "IDACTIOn" part
// (bindAction(mouse0, make, button1, TO, IDACTION_JET, 1.000000); ) to whatever you want it to do,
// for each one.

bindCommand($DAF_JetInput, make, $DAF_Jet, TO, "nothing();");
bindCommand($DAF_JetInput, break, $DAF_Jet, TO, "nothing();");

//Our nothing function. It does.. nothing.

function nothing() {}

// Set these next to to handel the barrel rolls.

function throwStart(%type)
{
	$throwStartTime = getSimTime();
	if(%type  == "Mine" ){
		remoteEval(2048,checkForRoll);
}
}

// Set up these functions to handle switching jets on when in vehicles,
// and off again when not in vehicles.
function remoteActivateJets()
{
	EditActionMap("playMap.sae");	
	bindAction($DAF_JetInput, make, $DAF_Jet, TO, IDACTION_JET, 1.000000);
	bindAction($DAF_JetInput, break,$DAF_Jet, TO, IDACTION_JET, 0.000000);
	
}
function remoteDeactivateJets()
{
	EditActionMap("playMap.sae");	
	bindCommand($DAF_JetInput, make, $DAF_Jet, TO, "nothing();");
	bindCommand($DAF_JetInput, break, $DAF_Jet, TO, "nothing();");
	postAction(2048, IDACTION_JET, 0.000000); 

}