
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Set these values to whatever values you normally
//| keep your jetpack, mine, and grenade buttons
//| mapped to.
//|
//|	For the inputs, it will be "mouse0" for
//|	the mouse, and "keyboard0" for the keyboard.
//|
//|	For the others, it will be whatever button
//|	on those devices you use for that.
//|	I use my right mousebutton for jet, so i have
//|		$Jet = "button1";
//|	Button0 is the left button.
//|	I use my mines on M, so i have
//|		$Mine = "m";
//|	I use my grenades on G, so i have
//|		$Grenade = "g";
//|
//|	If you use a shift, alt or control button
//|	for these normally, then you got more work
//|	ahead of you. This wont support them naturally.
//|	If you know how to fix it for yourself, do so.
//|	If not, you CAN contact me and i should be
//|	able to help (although it wont be pretty).
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

$DAF_JetInput = "mouse0";
$DAF_Jet = "button1";

$DAF_MineInput = "keyboard0";
$DAF_Mine = "m";

$DAF_GrenadeInput = "keyboard0";
$DAF_Grenade = "g";


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| For these values, if you use the currently mapped
//| buttons for something ELSE, then be SURE to change
//| these to something that you are NOT using.
//| Failing to do so, will cause these buttons to NOT
//| works for your original settings on both DAF
//| servers, AND OTHER SERVERS. I.e. your original
//| settings will NOT BE RESTORED.
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$DAF_ClearFLInput = "keyboard0"; //Clears all selected fire locations
$DAF_ClearFL = "numpadenter";

$DAF_FLSetPrimeInput = "keyboard0"; //Selects your prime vehicle gun
$DAF_FLSetPrime = "numpad+";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//| Number to hardpoint locations on vehicles:
//|
//|      For vehicles with odd number HardPoints                               
//|                     0                              
//|                   2   1                             
//|                 4       3                          
//|               6           5       <=Falcon(7HPs)             
//|             8               7                       
//|           10                  9   <=Warthog(11HPs)       
//|                                                   
//|      For vehicles with even number hardpoints                                             
//|                                                   
//|                   1    0                            
//|                 3         2                         
//|               5             4     <=Hind,Apache,               
//|                                     Tomcat(6HPs)           
//|                                                   
//|                                                   
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

$DAF_FLSet0Input = "keyboard0";
$DAF_FLSet0 = "numpad0";
$DAF_FLSet1Input = "keyboard0";
$DAF_FLSet1 = "numpad1";
$DAF_FLSet2Input = "keyboard0";
$DAF_FLSet2 = "numpad2";
$DAF_FLSet3Input = "keyboard0";
$DAF_FLSet3 = "numpad3";
$DAF_FLSet4Input = "keyboard0";
$DAF_FLSet4 = "numpad4";
$DAF_FLSet5Input = "keyboard0";
$DAF_FLSet5 = "numpad5";
$DAF_FLSet6Input = "keyboard0";
$DAF_FLSet6 = "numpad6";
$DAF_FLSet7Input = "keyboard0";
$DAF_FLSet7 = "numpad7";
$DAF_FLSet8Input = "keyboard0";
$DAF_FLSet8 = "numpad8";
$DAF_FLSet9Input = "keyboard0";
$DAF_FLSet9 = "numpad9";
$DAF_FLSet10Input = "keyboard0";
$DAF_FLSet10 = "decimal";

