
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Set these values to whatever values you normally
//| keep your jetpack, mine, and grenade buttons
//| mapped to.
//|
//|	For the inputs, it will be "mouse0" for
//|	the mouse, and "keyboard0" for the keyboard.
//|
//|	For the others, it will be whatever button
//|	on those devices you use for that.
//|	I use my right mousebutton for jet, so i have
//|		$Jet = "button1";
//|	Button0 is the left button.
//|	I use my mines on M, so i have
//|		$Mine = "m";
//|	I use my grenades on G, so i have
//|		$Grenade = "g";
//|
//|	If you use a shift, alt or control button
//|	for these normally, then you got more work
//|	ahead of you. This wont support them naturally.
//|	If you know how to fix it for yourself, do so.
//|	If not, you CAN contact me and i should be
//|	able to help (although it wont be pretty).
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

$DAF_JetInput = "mouse0";
$DAF_Jet = "button1";

$DAF_MineInput = "keyboard0";
$DAF_Mine = "m";

$DAF_GrenadeInput = "keyboard0";
$DAF_Grenade = "g";
