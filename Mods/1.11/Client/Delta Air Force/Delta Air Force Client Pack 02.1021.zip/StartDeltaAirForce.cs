
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Dont change anything below here unless you know
//| What your doing.
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

EditActionMap("playMap.sae");	
bindCommand($DAF_MineInput, make, $DAF_Mine, TO, "throwStart(\"Mine\");");
bindCommand($DAF_GrenadeInput, make, $DAF_Grenade, TO, "throwStart(\"Grenade\");");

// Disable right mouse button (jet) every time.
// If you want the jet button to do something different instead, then just change the "IDACTIOn" part
// (bindAction(mouse0, make, button1, TO, IDACTION_JET, 1.000000); ) to whatever you want it to do,
// for each one.

bindCommand($DAF_JetInput, make, $DAF_Jet, TO, "nothing();");
bindCommand($DAF_JetInput, break, $DAF_Jet, TO, "nothing();");

//Our nothing function. It does.. nothing.

function nothing() {}

// Set these next to to handel the barrel rolls.

function throwStart(%type)
{
	$throwStartTime = getSimTime();
	if(%type  == "Mine" ){
		remoteEval(2048,checkForRoll);
}
}

// Set up these functions to handle switching jets on when in vehicles,
// and off again when not in vehicles.
function remoteActivateJets()
{
	EditActionMap("playMap.sae");	
	bindAction($DAF_JetInput, make, $DAF_Jet, TO, IDACTION_JET, 1.000000);
	bindAction($DAF_JetInput, break,$DAF_Jet, TO, IDACTION_JET, 0.000000);
	
}
function remoteDeactivateJets()
{
	EditActionMap("playMap.sae");	
	bindCommand($DAF_JetInput, make, $DAF_Jet, TO, "nothing();");
	bindCommand($DAF_JetInput, break, $DAF_Jet, TO, "nothing();");
	postAction(2048, IDACTION_JET, 0.000000); 

}