
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//|
//| Dont change anything below here unless you know
//| What your doing.
//|
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//Reset our keymapping.

EditActionMap("playMap.sae");	
bindCommand($DAF_MineInput, make, $DAF_Mine, TO, "throwStart();");
bindCommand($DAF_GrenadeInput, make, $DAF_Grenade, TO, "throwStart();");
bindAction($DAF_JetInput, make, $DAF_Jet, TO, IDACTION_JET, 1.000000);
bindAction($DAF_JetInput, break,$DAF_Jet, TO, IDACTION_JET, 0.000000);

//Reset any functions we changed.

function throwStart()
{
	$throwStartTime = getSimTime();
}


