
$ModInfo = "               Prepare for Ultra_Renegades 3 Mayhem!!!!                                        Download client models @ www.planetstarsiege.com/ultra";
$FileURL = "www.planetstarsiege.com/ultra";
$ultra_renegades3::BanKickTime = "99999999999999999999999999999999999999999999999999999999999999999999999";
$ultra_renegades3::fairTeams = "true";
$ultra_renegades3::PABan = "true";
$ultra_renegades3::PAKick = "true";
$ultra_renegades3::PAMission = "true";
$ultra_renegades3::PAModOptions = "true";
$ultra_renegades3::PAResetDefaults = "true";
$ultra_renegades3::PATeamChange = "true";
$ultra_renegades3::PATeamDamage = "false";
$ultra_renegades3::PATeamInfo = "false";
$ultra_renegades3::PATimelimit = "true";
$ultra_renegades3::PATourneyMode = "false";
$ultra_renegades3::PAVote = "false";
$ultra_renegades3::tkClientLvl = "0";
$ultra_renegades3::tkLimit = "5";
$ultra_renegades3::tkMultiple = "3";
$ultra_renegades3::tkServerLvl = "1";
$ultra_renegades3::BanMessage = "Your IP address or IP Class C mask has been banned from this server.  Either you or someone else in your IP class did something dumb!";
$ultra_renegades3::IP1 = "198.198.198.5";
$ultra_renegades3::IP2 = "129.37.169.72";
$ultra_renegades3::IP3 = "209.215.4.*";
$ultra_renegades3::IPCount = "2";
$ultra_renegades3::KickMessage = "Your IP Address has been permanantly banned by the Admin.";
$ultra_renegades3::KickMessageC = "Your class C IP mask has been permanantly banned by the Admin.";


