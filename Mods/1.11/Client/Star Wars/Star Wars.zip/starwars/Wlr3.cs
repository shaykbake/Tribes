$InvList[Laserwaffe3] = 0;











//-----------------projectile-----------------------------

LaserData starLaser3
{
   laserBitmapName   = "laserpulse3.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.36;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.2;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData Laserwaffe3Image
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	projectileType = starLaser3;
	accuFire = true;
	reloadTime = 0.3;
	fireTime = 0.3;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Laserwaffe3
{
	description = "Laser Waffe Type C";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "sniper";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = Laserwaffe3Image;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};

function Laserwaffe3::onMount(%player,%imageSlot,%item) 
{    
     %client = Player::getClient(%player); 
   Bottomprint(%client, "<jc><f3>Laser Waffe Type C\n Schaden pro schuss = St�rke 3", 5); 
} 