$InvList[ToolLw] = 0;





//-----------------projectile-----------------------------
RocketData krassToolRocket
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = grenadeExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 250.0;
   muzzleVelocity   = 200.0;
   terminalVelocity = 200.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "shockwave_large.dts";
   smokeDist   = 30;

   soundId = SoundJetHeavy;
};


//----------------waffe---------------------

ItemImageData krassToolImage
{
   shapeFile  = "plasma";   //paintgun
	mountPoint = 0;
	mountOffset = {0, 0, 0.2};
	//mountRotation = {0, -3.14, 0};
	//ammoType = doppelammo;
	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.1;
	minEnergy = 1;
	maxEnergy = 1;
	projectileType = krassToolRocket;
	accuFire = false;
};

ItemData krassTool
{
   heading = "TWaffen-Aufsteck-Tools";
	description = "Aufsteck Tool  -  FlakModus";
	className = "Weapon";
   shapeFile  = "paintgun";
	hudIcon = "paintgun";
	shadowDetailMask = 4;
	imageType = krassToolImage;
	price = 850;
	showWeaponBar = false;
	showInventory = false; 
};


