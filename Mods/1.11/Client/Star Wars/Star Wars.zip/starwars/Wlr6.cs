$InvList[Laserwaffe6] = 0;









RocketData starBolt
{
   bulletShapeName  = "breath.dts";
   explosionTag     = LargeShockwave;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 20.5;
   kickBackStrength = 550.0;
   muzzleVelocity   = 100.0;
   terminalVelocity = 100.0;
   acceleration     = 3.0;
   totalTime        = 10.0;
   liveTime         = 5.0;
   lightRange       = 0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   

   soundId = SoundJetHeavy;
};

//-----------------projectile-----------------------------

LaserData starLaser6
{
   laserBitmapName   = "laserpulse5.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.9;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.1;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData Laserwaffe6Image
{
	shapeFile = "breath";
	mountPoint = 0;
	mountOffset = {-0.5, -0.16, 0};

	weaponType = 0; // Single Shot
//	projectileType = starLaser6;
	accuFire = true;
	reloadTime = 0.2;
	fireTime = 5;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Laserwaffe6
{
	description = "Macht";
	className = "Weapon";
	shapeFile = "breath";
	hudIcon = "breath";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = Laserwaffe6Image;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};




//---------------------funktionkacke-------------------

function Laserwaffe6Image::onFire(%player,%slot)
{


%trans = GameBase::getMuzzleTransform(%player); 
         %vel = Item::getVelocity(%player); 
         %xrnd = (floor(getRandom() *21)-10)/100;      //*21 -10)/100 
         %yrnd = (floor(getRandom() *21)-10)/100; 
         %zrnd = (floor(getRandom() *21)-10)/100; 

         %trans1= getWord(%trans,0); 
         %trans2= getWord(%trans,1); 
         %trans3= getWord(%trans,2); 
         %trans4= getWord(%trans,3);// + %xrnd; 
         %trans5= getWord(%trans,4);// + %yrnd; 
         %trans6= getWord(%trans,5);// + %zrnd; 
         %trans7= getWord(%trans,6); 
         %trans8= getWord(%trans,7); 
         %trans9= getWord(%trans,8); 
         %trans10=getWord(%trans,9); 
         %trans11=getWord(%trans,10); 
         %trans12=getWord(%trans,11); 
         %NewTrans = %trans1 @" "@ %trans2 @" "@ %trans3 @" "@ %trans4 @" "@ %trans5 @" "@ %trans6 @" "@ %trans7 @" "@ %trans8 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 

         //Projectile::spawnProjectile(starLaser6,%NewTrans,%player,%vel); 
         Projectile::spawnProjectile(starBolt,%NewTrans,%player,%vel); 

}

function Laserwaffe6::onMount(%player,%imageSlot,%item) 
{    
     %client = Player::getClient(%player); 
   Bottomprint(%client, "<jc><f3>DIE MACHT dunkel ODER hell\n Welcher seite du auch immer angeh�rst.", 5); 
} 