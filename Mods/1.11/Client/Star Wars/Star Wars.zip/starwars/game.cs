exec("comchat.cs");
$SensorNetworkEnabled = true;

$GuiModePlay = 1;
$GuiModeCommand = 2;
$GuiModeVictory = 3;
$GuiModeInventory = 4;
$GuiModeObjectives = 5;
$GuiModeLobby = 6;


//  Global Variables

//---------------------------------------------------------------------------------
// Energy each team is given at beginning of game
//---------------------------------------------------------------------------------
$DefaultTeamEnergy = "Infinite";

//---------------------------------------------------------------------------------
// Team Energy variables
//---------------------------------------------------------------------------------
$TeamEnergy[-1] = $DefaultTeamEnergy; 
$TeamEnergy[0]  = $DefaultTeamEnergy; 
$TeamEnergy[1]  = $DefaultTeamEnergy; 
$TeamEnergy[2]  = $DefaultTeamEnergy; 
$TeamEnergy[3]  = $DefaultTeamEnergy; 
$TeamEnergy[4]  = $DefaultTeamEnergy; 
$TeamEnergy[5]  = $DefaultTeamEnergy; 
$TeamEnergy[6]  = $DefaultTeamEnergy; 				
$TeamEnergy[7]  = $DefaultTeamEnergy; 

//---------------------------------------------------------------------------------
// Time in sec player must wait before he can throw a Grenade or Mine after leaving
//	a station.
//---------------------------------------------------------------------------------
$WaitThrowTime = 2;

//---------------------------------------------------------------------------------
// If 1 then Team Spending Ignored -- Team Energy is set to $MaxTeamEnergy every
// 	$secTeamEnergy.
//---------------------------------------------------------------------------------
$TeamEnergyCheat = 0;

//---------------------------------------------------------------------------------
// MAX amount team energy can reach
//---------------------------------------------------------------------------------
$MaxTeamEnergy = 700000;

//---------------------------------------------------------------------------------
//  Time player has to put flag in flagstand before it gets returned to its last
//  location. 
//---------------------------------------------------------------------------------
$flagToStandTime = 180;	  

//---------------------------------------------------------------------------------
// Amount to inc team energy every ($secTeamEnergy) seconds
//---------------------------------------------------------------------------------
$incTeamEnergy = 700;

//---------------------------------------------------------------------------------
// (Rate is sec's) Set how often TeamEnergy is incremented
//---------------------------------------------------------------------------------
$secTeamEnergy = 30;

//---------------------------------------------------------------------------------
// (Rate is sec's) Items respwan
//---------------------------------------------------------------------------------
$ItemRespawnTime = 30;

//---------------------------------------------------------------------------------
//Amount of Energy remote stations start out with
//---------------------------------------------------------------------------------
$RemoteAmmoEnergy = 2500; 
$RemoteInvEnergy = 3000;

//---------------------------------------------------------------------------------
// TEAM ENERGY -  Warn team when teammate has spent x amount - Warn team that 
//				  energy level is low when it reaches x amount 
//---------------------------------------------------------------------------------
$TeammateSpending = -4000;  //Set = to 0 if don't want the warning message
$WarnEnergyLow = 4000;	    //Set = to 0 if don't want the warning message

//---------------------------------------------------------------------------------
// Amount added to TeamEnergy when a player joins a team
//---------------------------------------------------------------------------------
$InitialPlayerEnergy = 5000;

//---------------------------------------------------------------------------------
// REMOTE TURRET
//---------------------------------------------------------------------------------
$MaxNumTurretsInBox = 2000;     //Number of remote turrets allowed in the area
$TurretBoxMaxLength = 5;    //Define Max Length of the area
$TurretBoxMaxWidth =  5;    //Define Max Width of the area
$TurretBoxMaxHeight = 25;    //Define Max Height of the area

$TurretBoxMinLength = 1;	  //Define Min Length from another turret
$TurretBoxMinWidth =  1;	  //Define Min Width from another turret
$TurretBoxMinHeight = 1;    //Define Min Height from another turret

//---------------------------------------------------------------------------------
//	Object Types	
//---------------------------------------------------------------------------------
$SimTerrainObjectType    = 1 << 1;
$SimInteriorObjectType   = 1 << 2;
$SimPlayerObjectType     = 1 << 7;

$MineObjectType		    = 1 << 26;	
$MoveableObjectType	    = 1 << 22;
$VehicleObjectType	 	 = 1 << 29;  
$StaticObjectType			 = 1 << 23;	   
$ItemObjectType			 = 1 << 21;	  

//---------------------------------------------------------------------------------
// CHEATS
//---------------------------------------------------------------------------------
$ServerCheats = 0;
$TestCheats = 0;

//---------------------------------------------------------------------------------
//Respawn automatically after X sec's -  If 0..no respawn
//---------------------------------------------------------------------------------
$AutoRespawn = 0;

//---------------------------------------------------------------------------------
// Player death messages - %1 = killer's name, %2 = victim's name
//       %3 = killer's gender pronoun (his/her), %4 = victim's gender pronoun
//---------------------------------------------------------------------------------
$deathMsg[$LandingDamageType, 0]      = "%2 st�rzt sich zu tote.";
$deathMsg[$LandingDamageType, 1]      = "%2 hat sein Bungee-seil vergessen.";
$deathMsg[$LandingDamageType, 2]      = "%2 k�sst gern den Boden.";
$deathMsg[$LandingDamageType, 3]      = "%2 f�llt und f�llt und f�llt und ist TOT.";
$deathMsg[$ImpactDamageType, 0]      = "%1 hinterl�st nen ziemlichen eindruck auf %2.";
$deathMsg[$ImpactDamageType, 1]      = "%2 becomes the victim of a fly-by from %1.";
$deathMsg[$ImpactDamageType, 2]      = "%2 leaves a nasty dent in %1's fender.";
$deathMsg[$ImpactDamageType, 3]      = "%1 sagt, 'Hey %2, du zerkrazt mein bild!'";
$deathMsg[$BulletDamageType, 0]      = "%1 macht schweizer K�se aus %2 mit seiner chaingun.";
$deathMsg[$BulletDamageType, 1]      = "%1 gibt %2 ne extra-portion Blei.";
$deathMsg[$BulletDamageType, 2]      = "%1 l�chert %2`s K�rper.";
$deathMsg[$BulletDamageType, 3]      = "%1 schie�t %2 tot.";
$deathMsg[$EnergyDamageType, 0]      = "%2 wirft sich frustriert vor einen turret.";
$deathMsg[$EnergyDamageType, 1]      = "%2 war wohl zu nah beim gegner.";
$deathMsg[$EnergyDamageType, 2]      = "%2 war �berw�ltigt von den turrets.";
$deathMsg[$EnergyDamageType, 3]      = "%2 hats sich hinterm falschen turret versteckt.";
$deathMsg[$PlasmaDamageType, 0]      = "%2 f�hlt die wohlige W�rme von %1's Plasma-feuer.";
$deathMsg[$PlasmaDamageType, 1]      = "%1 gibt %2 eine Plasma-Injektion direkt in die vene.";
$deathMsg[$PlasmaDamageType, 2]      = "%1 fragt %2 nach Plasma-feuer f�r seine zigrette.";
$deathMsg[$PlasmaDamageType, 3]      = "%2 verbrennt im PLasmafeuer der h�lle.";
$deathMsg[$ExplosionDamageType, 0]   = "%2 frisst anscheinend gern die energy-disken von %1.";
$deathMsg[$ExplosionDamageType, 1]   = "%1 feuert %2 mit einer disk ins aus.";
$deathMsg[$ExplosionDamageType, 2]   = "%2 hat die letzte disk von %1 wohl nicht gesehn.";
$deathMsg[$ExplosionDamageType, 3]   = "%2 wird zum opfer von %1's Vorschlaghammer.";
$deathMsg[$ShrapnelDamageType, 0]    = "%1 veranstalltet ein feuerwerk mit %2.";
$deathMsg[$ShrapnelDamageType, 1]    = "%2 schmeckt den geschmack von %1's Ammo.";
$deathMsg[$ShrapnelDamageType, 2]    = "%2 bekommt von %1 eine �bergezogen.";
$deathMsg[$ShrapnelDamageType, 3]    = "%2 hat den letzten schuss von %1 wohl nicht gesehen.";
$deathMsg[$LaserDamageType, 0]       = "%1 kann seine KILL-LIST mit %2 namen erweitern.";
$deathMsg[$LaserDamageType, 1]       = "%1 gibt %2 nen Kopfschuss.";
$deathMsg[$LaserDamageType, 2]       = "%2 war zu langsam f�r %1's Reflexe.";
$deathMsg[$LaserDamageType, 3]       = "%2 hat %1's Fadenkreuz gek�sst.";
$deathMsg[$MortarDamageType, 0]      = "%1 m�rsert %2 in die uuuunendlichen weiten......";
$deathMsg[$MortarDamageType, 1]      = "%2 hat das letzte ding von %1 wohl nich gesehn.";
$deathMsg[$MortarDamageType, 2]      = "%1 reist ne rie�en fleischwunde in %2's K�rper.";
$deathMsg[$MortarDamageType, 3]      = "%1's M�rser schickt %2 in die H�lle.";
$deathMsg[$BlasterDamageType, 0]     = "%1 sagt Asta La Vista zu %2";
$deathMsg[$BlasterDamageType, 1]     = "%2 stand in einem warmen sommerregen aus %1's blaster-feuer.";
$deathMsg[$BlasterDamageType, 2]     = "%1's Blaster zeigt %2 eine neue ebene des schmerzempfindens.";
$deathMsg[$BlasterDamageType, 3]     = "%2 begegnet %1's Knarre.";
$deathMsg[$ElectricityDamageType, 0] = "%2 l�st sich durch %1's ELF gun in einzelteile auf.";
$deathMsg[$ElectricityDamageType, 1] = "%1 elektrifiziert %2 ";
$deathMsg[$ElectricityDamageType, 2] = "%2 hatte ein schockierendes treffen mit %1.";
$deathMsg[$ElectricityDamageType, 3] = "%1 verk�rzt %2's lebenszeit.";
$deathMsg[$CrushDamageType, 0]		 = "%2 blieb nich weitgenug weg von dem Teil.....";
$deathMsg[$CrushDamageType, 1]		 = "%2 is irgendwo reinge-crashed.";
$deathMsg[$CrushDamageType, 2]		 = "%2 wurde plattgedr�ckt.";
$deathMsg[$CrushDamageType, 3]		 = "%2 wurde von n paar zahnr�dern zermalmt.";
$deathMsg[$DebrisDamageType, 0]		 = "%2 is wohl tot.";
$deathMsg[$DebrisDamageType, 1]		 = "%2 is killed by debris.";
$deathMsg[$DebrisDamageType, 2]		 = "%2 becomes a victim of collateral damage.";
$deathMsg[$DebrisDamageType, 3]		 = "%2 got too close to the exploding stuff.";
$deathMsg[$MissileDamageType, 0]	    = "%2 spielt baron m�nchhausen mit ner rakete.";
$deathMsg[$MissileDamageType, 1]	    = "%2 Lebte von heute bis Eben, m�ge er in frieden ruhen.";
$deathMsg[$MissileDamageType, 2]	    = "%2 merkte erst jetzt das es ne rakete war und nicht heidi klum.";
$deathMsg[$MissileDamageType, 3]	    = "%2 kam einem sprengkopf n�her als man sollte.";
$deathMsg[$MineDamageType, 0]	       = "%1 l�sst gern %2 durch die gegend fliegen.";
$deathMsg[$MineDamageType, 1]	       = "%2 scn�fflet nach %1's Minen (ohne detektor).";
$deathMsg[$MineDamageType, 2]	       = "%1 gibt %2 eine lektion in sachen Schmerz.";
$deathMsg[$MineDamageType, 3]	       = "%2 muss ein bisschen besser aufpassen.";

// "you just killed yourself" messages
//   %1 = player name,  %2 = player gender pronoun

$deathMsg[-2,0]						 = "%1 is zu dumm um abgeknallt zu werden.";
$deathMsg[-2,1]						 = "%1 ist stark suizidgef�hrdet.";
$deathMsg[-2,2]						 = "%1 is zu dumm zum leben.";
$deathMsg[-2,3]						 = "%1 versucht zu GOTT aufzusteigen.";
$deathMsg[-2,4]						 = "%1 dreht durch und gibt sich nen kopfschuss.";

$numDeathMsgs = 5;
//------------------------------------NORMALE SPAWNLISTE---------------------------------------------
//---------------------------------------------------------------------------------------------------

$spawnBuyList[0] = LightArmor;
$spawnBuyList[1] = Laserwaffe;
$spawnBuyList[2] = "";

function remotePlayMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModePlay);
   }
}

function remoteCommandMode(%clientId)
{
   // can't switch to command mode while a server menu is up
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);  // force the bandwidth to be full command
		if(%clientId.observerMode != "pregame")
		   checkControlUnmount(%clientId);
		Client::setGuiMode(%clientId, $GuiModeCommand);
   }
}

function remoteInventoryMode(%clientId)
{
   if(!%clientId.guiLock && !Observer::isObserver(%clientId))
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeInventory);
   }
}

function remoteObjectivesMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeObjectives);
   }
}

function remoteScoresOn(%clientId)
{
   if(!%clientId.menuMode)
      Game::menuRequest(%clientId);
}

function remoteScoresOff(%clientId)
{
   Client::cancelMenu(%clientId);
}

function remoteToggleCommandMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeCommand)
		remoteCommandMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleInventoryMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeInventory)
		remoteInventoryMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleObjectivesMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeObjectives)
		remoteObjectivesMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function Time::getMinutes(%simTime)
{
   return floor(%simTime / 60);
}

function Time::getSeconds(%simTime)
{
   return %simTime % 60;
}

function Game::pickRandomSpawn(%team)
{
   %group = nameToID("MissionGroup/Teams/team" @ %team @ "/DropPoints/Random");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;
  	%spawnIdx = floor(getRandom() * (%count - 0.1));
  	%value = %count;
	for(%i = %spawnIdx; %i < %value; %i++) {
		%set = newObject("set",SimSet);
		%obj = Group::getObject(%group, %i);
		if(containerBoxFillSet(%set,$SimPlayerObjectType|$VehicleObjectType,GameBase::getPosition(%obj),2,2,4,0) == 0) {
			deleteObject(%set);
			return %obj;		
		}
		if(%i == %count - 1) {
			%i = -1;
			%value = %spawnIdx;
		}
		deleteObject(%set);
	}
   return false;
}

function Game::pickStartSpawn(%team)
{
   %group = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\DropPoints\\Start");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;

   %spawnIdx = $lastTeamSpawn[%team] + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   $lastTeamSpawn[%team] = %spawnIdx;
   return Group::getObject(%group, %spawnIdx);
}

function Game::pickTeamSpawn(%team, %respawn)
{
   if(%respawn)
      return Game::pickRandomSpawn(%team);
   else
   {
      %spawn = Game::pickStartSpawn(%team);
      if(%spawn == -1)
         return Game::pickRandomSpawn(%team);
      return %spawn;
   }
}

function Game::pickObserverSpawn(%client)
{
   %group = nameToID("MissionGroup\\ObserverDropPoints");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team" @ Client::getTeam(%client) @ "\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team0\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      return -1;
   %spawnIdx = %client.lastObserverSpawn + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   %client.lastObserverSpawn = %spawnIdx;
	return Group::getObject(%group, %spawnIdx);
}

function UpdateClientTimes(%time)
{
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      remoteEval(%cl, "setTime", -%time);
}

function Game::notifyMatchStart(%time)
{
   messageAll(0, "H�Lle startet in " @ %time @ " sekunden.");
   UpdateClientTimes(%time);
}

function Game::startMatch()
{
//--------------------------------------------------------------ALLE STARWARSVARIABLEN RESTEN----------------------------------------------------------------------
$MountTool = 0;
$FLAKMODUS = 0;
$PSP = 0;
$PSPD = 0;
$PSPR = 0;
$InvList[laserwaffe] = 0;
$InvList[laserwaffe2] = 0;
$InvList[laserwaffe3] = 0;
$InvList[laserwaffe4] = 0;
$InvList[laserwaffe5] = 0;
$InvList[laserwaffe6] = 0;
$InvList[krass] = 0;

   $matchStarted = true;
   $missionStartTime = getSimTime();
   messageAll(0, "H�LLE gestartet.");
	Game::resetScores();	


// schedule("brauchen();", 180);




   %numTeams = getNumTeams();
   for(%i = 0; %i < %numTeams; %i = %i + 1) {
		if($TeamEnergy[%i] != "Infinite")
			schedule("replenishTeamEnergy(" @ %i @ ");", $secTeamEnergy);
	}

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
		if(%cl.observerMode == "pregame")
      {
         %cl.observerMode = "";
         Client::setControlObject(%cl, Client::getOwnedObject(%cl));
      }
   	Game::refreshClientScore(%cl);
	}
   Game::checkTimeLimit();
}

function Game::pickPlayerSpawn(%clientId, %respawn)
{
   return Game::pickTeamSpawn(Client::getTeam(%clientId), %respawn);
}







function information(%clientId)
{
	if(($PSP != "" ) && ($PSPD != ""))
	{
	%RATIO = ($PSP/$PSPD)*100;
	}

		if(($PSP == "" || $PSP == 0) && ($PSPD == "" || $PSPD == 0))
		{
		%RATIO = 0;
		}

$PLIP = Client::getTransportAddress(%clientId);

	
%namePL = Client::getName(%clientId);
bottomprint(%clientId, "<jc><f0>DER AKTUELLE STATUS VON: <f1>"@%namePL@" \n <f0>IP: <f1>"@$PLIP@"\n<f0>Kills:<f1> "@$PSP@"   <f0>Gestorben: <f1>"@$PSPD@"  <f0>Effizienz: <f1>"@$PSPR@"%", 15); 
}


function Game::playerSpawn(%clientId, %respawn)
{
   if(!$ghosting)
      return false;

	Client::clearItemShopping(%clientId);
   %spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);
   
//---------------------------PUNKTESTAND ANZEIGEN---------------------------------------------------------------   
   schedule("information("@%clientId@");", 10,%clientId);
   if(!%respawn)
   {
      // initial drop
      bottomprint(%clientId, "<jc><f0>Mission: <f1>" @ $missionName @ "   <f0>Mission Typ: <f1>" @ $Game::missionType @ "\n<f0>dr�ck <f1>'O'<f0> f�r mehr Informationen.", 10);

	 
 
 


   }
	if(%spawnMarker) {   
		%clientId.guiLock = "";
	 	%clientId.dead = "";
	   if(%spawnMarker == -1)
	   {
	      %spawnPos = "0 0 300";
	      %spawnRot = "0 0 0";
	   }
	   else
	   {
	      %spawnPos = GameBase::getPosition(%spawnMarker);
	      %spawnRot = GameBase::getRotation(%spawnMarker);
	   }

		if(!String::ICompare(Client::getGender(%clientId), "Male"))
	      %armor = "larmor";
	   else
	      %armor = "lfemale";

	   %pl = spawnPlayer(%armor, %spawnPos, %spawnRot);
	   echo("SPAWN: cl:" @ %clientId @ " pl:" @ %pl @ " marker:" @ %spawnMarker @ " armor:" @ %armor);
	   if(%pl != -1)
	   {
	      GameBase::setTeam(%pl, Client::getTeam(%clientId));
	      Client::setOwnedObject(%clientId, %pl);
	      Game::playerSpawned(%pl, %clientId, %armor, %respawn);
	      
	      if($matchStarted)
	         Client::setControlObject(%clientId, %pl);
	      else
	      {
	         %clientId.observerMode = "pregame";
	         Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
	         Observer::setOrbitObject(%clientId, %pl, 3, 3, 3);
	      }
	   }
      return true;
	}
	else {
		Client::sendMessage(%clientId,0,"Tut mir leid aber zurzeit sind keine RE-Spawn-Positionen frei - versuch es gleich nochmal ");
      return false;
	}
}

function Game::playerSpawned(%pl, %clientId, %armor)
{						  
	%clientId.spawn= 1;
	%max = getNumItems();
   for(%i = 0; (%item = $spawnBuyList[%i]) != ""; %i++)
   {
		buyItem(%clientId,%item);	
		if(%item.className == Weapon) 
			%clientId.spawnWeapon = %item;
	}
	%clientId.spawn= "";
	if(%clientId.spawnWeapon != "") {
		Player::useItem(%pl,%clientId.spawnWeapon);	
   	%clientId.spawnWeapon="";
	}
} 

function Game::autoRespawn(%client)
{


	if(%client.dead == 1)
		Game::playerSpawn(%client, "true");


}

function onServerGhostAlwaysDone()
{
}

function Game::initialMissionDrop(%clientId)
{
	Client::setGuiMode(%clientId, $GuiModePlay);

   if($Server::TourneyMode)
      GameBase::setTeam(%clientId, -1);
   else
   {
      if(%clientId.observerMode == "observerFly" || %clientId.observerMode == "observerOrbit")
      {
	      %clientId.observerMode = "observerOrbit";
	      %clientId.guiLock = "";
         Observer::jump(%clientId);
         return;
      }
      %numTeams = getNumTeams();
      %curTeam = Client::getTeam(%clientId);

      if(%curTeam >= %numTeams || (%curTeam == -1 && (%numTeams < 2 || $Server::AutoAssignTeams)) )
         Game::assignClientTeam(%clientId);
   }    
	Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
   %camSpawn = Game::pickObserverSpawn(%clientId);
   Observer::setFlyMode(%clientId, GameBase::getPosition(%camSpawn), 
	   GameBase::getRotation(%camSpawn), true, true);

   if(Client::getTeam(%clientId) == -1)
   {
      %clientId.observerMode = "pickingTeam";

      if($Server::TourneyMode && ($matchStarted || $matchStarting))
      {
         %clientId.observerMode = "observerFly";
         return;
      }
      else if($Server::TourneyMode)
      {
         if($Server::TeamDamageScale)
            %td = "ENABLED";
         else
            %td = "DISABLED";
         bottomprint(%clientId, "<jc><f1>DER SERVER TR�GT ZUR ZEIT EIN TURNIER AUS\nw�hl ein Team.\nTeam-Damage ist " @ %td, 0);
      }
      Client::buildMenu(%clientId, "Pick a team:", "InitialPickTeam");
      Client::addMenuItem(%clientId, "0Observe", -2);
      Client::addMenuItem(%clientId, "1Automatic", -1);
      for(%i = 0; %i < getNumTeams(); %i = %i + 1)
         Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
      %clientId.justConnected = "";
   }
   else 
   {
      Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
      if(%clientId.justConnected)
      {
         centerprint(%clientId, $Server::JoinMOTD, 0);
         %clientId.observerMode = "justJoined";
         %clientId.justConnected = "";
      }
      else if(%clientId.observerMode == "justJoined")
      {
         centerprint(%clientId, "");
         %clientId.observerMode = "";
         Game::playerSpawn(%clientId, false);
      }
      else
         Game::playerSpawn(%clientId, false);
	}
	if($TeamEnergy[Client::getTeam(%clientId)] != "Infinite")
		$TeamEnergy[Client::getTeam(%clientId)] += $InitialPlayerEnergy;
	%clientId.teamEnergy = 0;
}

function processMenuInitialPickTeam(%clientId, %team)
{
   if($Server::TourneyMode && $matchStarted)
      %team = -2;

   if(%team == -2)
   {
      Observer::enterObserverMode(%clientId);
   }
   if(%team == -1)
   {
      Game::assignClientTeam(%clientId);
      %team = Client::getTeam(%clientId);
   }
   if(%team != -2)
   {
      GameBase::setTeam(%clientId, %team);
		if($TeamEnergy[%team] != "Infinite")
			$TeamEnergy[%team] += $InitialPlayerEnergy;
      %clientId.teamEnergy = 0;
      Client::setControlObject(%clientId, -1);
      Game::playerSpawn(%clientId, false);
   }
   if($Server::TourneyMode && !$CountdownStarted)
   {
      if(%team != -2)
      {
         bottomprint(%clientId, "<f1><jc>Dr���ck krasse Linke maustaste wenn bereit..ja?!.", 0);
         %clientId.notready = true;
         %clientId.notreadyCount = "";
      }
      else
      {
         bottomprint(%clientId, "", 0);
         %clientId.notready = "";
         %clientId.notreadyCount = "";
      }
   }
}

function Game::ForceTourneyMatchStart()
{
   %playerCount = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pregame")
         %playerCount++;
   }
   if(%playerCount == 0)
      return;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")   
         processMenuInitialPickTeam(%cl, -2); // throw these guys into observer
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
   }
   Server::Countdown(30);
}

function Game::CheckTourneyMatchStart()
{
   if($CountdownStarted || $matchStarted)
      return;
   
   // loop through all the clients and see if any are still notready
   %playerCount = 0;
   %notReadyCount = 0;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")
      {
         %notReady[%notReadyCount] = %cl;
         %notReadyCount++;
      }   
      else if(%cl.observerMode == "pregame")
      {
         if(%cl.notready)
         {
            %notReady[%notReadyCount] = %cl;
            %notReadyCount++;
         }
         else
            %playerCount++;
      }
   }
   if(%notReadyCount)
   {
      if(%notReadyCount == 1)
         MessageAll(0, Client::getName(%notReady[0]) @ " ist noch nicht bereit!");
      else if(%notReadyCount < 4)
      {
         for(%i = 0; %i < %notReadyCount - 2; %i++)
            %str = Client::getName(%notReady[%i]) @ ", " @ %str;

         %str = %str @ Client::getName(%notReady[%i]) @ " und " @ Client::getName(%notReady[%i+1]) 
                     @ " sind noch nicht bereit!";
         MessageAll(0, %str);
      }
      return;
   }

   if(%playerCount != 0)
   {
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
      Server::Countdown(30);
   }
}


function Game::checkTimeLimit()
{
   // if no timeLimit set or timeLimit set to 0,
   // just reschedule the check for a minute hence
   $timeLimitReached = false;

   if(!$Server::timeLimit)
   {
      schedule("Game::checkTimeLimit();", 60);
      return;
   }
   %curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
   if(%curTimeLeft <= 0 && $matchStarted)
   {
      echo("GAME: Timelimit reached.");
      $timeLimitReached = true;
      Server::nextMission();
   }
   else
   {
      schedule("Game::checkTimeLimit();", 20);
      UpdateClientTimes(%curTimeLeft);
   }
}

function Game::resetScores(%client)
{
	if(%client == "") {
	   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
	      %cl.scoreKills = 0;
   	   %cl.scoreDeaths = 0;
			%cl.ratio = 0;
      	%cl.score = 0;
		}
	}
	else {
      %client.scoreKills = 0;
  	   %client.scoreDeaths = 0;
		%client.ratio = 0;
     	%client.score = 0;
	}
}

function remoteSetArmor(%player, %armorType)
{
	if ($ServerCheats) {
		checkMax(Player::getClient(%player),%armorType);
	   Player::setArmor(%player, %armorType);
	}
	else if($TestCheats) {
	   Player::setArmor(%player, %armorType);
	}
}


function Game::onPlayerConnected(%playerId)
{


   %playerId.scoreKills = 0;
   %playerId.scoreDeaths = 0;
	%playerId.score = 0;
   %playerId.justConnected = true;
   $menuMode[%playerId] = "None";
   Game::refreshClientScore(%playerId);
   

}

function Game::assignClientTeam(%playerId)
{
   if($teamplay)
   {
      %name = Client::getName(%playerId);
      %numTeams = getNumTeams();
      if($teamPreset[%name] != "")
      {
         if($teamPreset[%name] < %numTeams)
         {
            GameBase::setTeam(%playerId, $teamPreset[%name]);
            echo(Client::getName(%playerId), " was preset to team ", $teamPreset[%name]);
            return;
         }            
      }
      %numPlayers = getNumClients();
      for(%i = 0; %i < %numTeams; %i = %i + 1)
         %numTeamPlayers[%i] = 0;

      for(%i = 0; %i < %numPlayers; %i = %i + 1)
      {
         %pl = getClientByIndex(%i);
         if(%pl != %playerId)
         {
            %team = Client::getTeam(%pl);
            %numTeamPlayers[%team] = %numTeamPlayers[%team] + 1;
         }
      }
      %leastPlayers = %numTeamPlayers[0];
      %leastTeam = 0;
      for(%i = 1; %i < %numTeams; %i = %i + 1)
      {
         if( (%numTeamPlayers[%i] < %leastPlayers) || 
            ( (%numTeamPlayers[%i] == %leastPlayers) && 
            ($teamScore[%i] < $teamScore[%leastTeam] ) ))
         {
            %leastTeam = %i;
            %leastPlayers = %numTeamPlayers;
         }
      }
      GameBase::setTeam(%playerId, %leastTeam);
      echo(Client::getName(%playerId), " Wurde automatisch zum d�ner-stand geschickt. Besitzer Team: ", %leastTeam);
	  
   }
   else
   {
      GameBase::setTeam(%playerId, 0);
   }
}

function Client::onKilled(%playerId, %killerId, %damageType)
{

   echo("GAME: kill " @ %killerId @ " " @ %playerId @ " " @ %damageType);
   %playerId.guiLock = true;
   Client::setGuiMode(%playerId, $GuiModePlay);
	if(!String::ICompare(Client::getGender(%playerId), "Male"))
   {
      %playerGender = "sein";
   }
	else
	{
		%playerGender = "ihr";
	}
	%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
	%victimName = Client::getName(%playerId);


   if(!%killerId)
   {
      messageAll(0, strcat(%victimName, " stirbt."), $DeathMessageMask);
      %playerId.scoreDeaths++;
  }
   else if(%killerId == %playerId)
   {
	  %oopsMsg = sprintf($deathMsg[-2, %ridx], %victimName, %playerGender);
      messageAll(0, %oopsMsg, $DeathMessageMask);
      %playerId.scoreDeaths++;
      %playerId.score--;
      Game::refreshClientScore(%playerId);
   }
   else
   {
		if(!String::ICompare(Client::getGender(%killerId), "Male"))
		{
			%killerGender = "sein";
		}
		else
		{
			%killerGender = "ihr";
		}
      if($teamplay && (Client::getTeam(%killerId) == Client::getTeam(%playerId)))
      {
		if(%damageType != $MineDamageType) 
	    	messageAll(0, strcat(Client::getName(%killerId), 
   	        " vernichtet ", %killerGender, " kammeraden, ", %victimName), $DeathMessageMask);
		else 
	         messageAll(0, strcat(Client::getName(%killerId), 
   	     	" t�tet", %killerGender, " kammeraden, ", %victimName ," mit einer mine."), $DeathMessageMask);
		 %killerId.scoreDeaths++;
       %killerId.score--;
       Game::refreshClientScore(%killerId);
      }
      else
      {
	     %obitMsg = sprintf($deathMsg[%damageType, %ridx], Client::getName(%killerId),
	       %victimName, %killerGender, %playerGender);
         messageAll(0, %obitMsg, $DeathMessageMask);
         %killerId.scoreKills++;
         %playerId.scoreDeaths++;  // test play mode
         %killerId.score++;
         Game::refreshClientScore(%killerId);
         Game::refreshClientScore(%playerId);
      }
   }
   Game::clientKilled(%playerId, %killerId);

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------  
//--------------------------------------------------------ROLLENSPIEL MODIFIKATIONEN-------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------


$PSP = %playerId.score;
$PSPD = %playerId.scoreDeaths;

$PSPR = $PSP/(($PSP + $PSPD) / 100);

$InvList[laserwaffe] = 1;

if($PSPR > 10)
{
$MountTool = 0;
$FLAKMODUS = 0;


$InvList[laserwaffe] = 1;
$InvList[laserwaffe2] = 1;
$InvList[laserwaffe3] = 0;
$InvList[laserwaffe4] = 0;
$InvList[laserwaffe5] = 0;
$InvList[laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe2] = 1;
$ItemMax[marmor, laserwaffe2] = 1;
$ItemMax[harmor, laserwaffe2] = 1;

$ItemMax[harmor, laserwaffe3] = 0;
$ItemMax[harmor, laserwaffe4] = 0;
$ItemMax[harmor, laserwaffe5] = 0;
$ItemMax[larmor, laserwaffe3] = 0;
$ItemMax[larmor, laserwaffe4] = 0;
$ItemMax[larmor, laserwaffe5] = 0;
$ItemMax[marmor, laserwaffe3] = 0;
$ItemMax[marmor, laserwaffe4] = 0;
$ItemMax[marmor, laserwaffe5] = 0;
$ItemMax[harmor, laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe6] = 0;
$ItemMax[marmor, laserwaffe6] = 0;
$ItemMax[harmor, krass] = 0;


$spawnBuyList[1] = Laserwaffe2;
}

if($PSPR > 25)
{
$MountTool = 0;
$FLAKMODUS = 0;

$InvList[laserwaffe3] = 1;
$InvList[laserwaffe4] = 0;
$InvList[laserwaffe5] = 0;
$InvList[laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe3] = 1;
$ItemMax[marmor, laserwaffe3] = 1;
$ItemMax[harmor, laserwaffe3] = 1;


$ItemMax[harmor, laserwaffe4] = 0;
$ItemMax[harmor, laserwaffe5] = 0;
$ItemMax[larmor, laserwaffe4] = 0;
$ItemMax[larmor, laserwaffe5] = 0;
$ItemMax[marmor, laserwaffe4] = 0;
$ItemMax[marmor, laserwaffe5] = 0;
$ItemMax[harmor, laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe6] = 0;
$ItemMax[marmor, laserwaffe6] = 0;
$ItemMax[harmor, krass] = 0;

$spawnBuyList[1] = Laserwaffe3;
}

if($PSPR > 40)
{
$MountTool = 0;
$FLAKMODUS = 0;

$InvList[laserwaffe4] = 1;
$InvList[laserwaffe5] = 0;
$InvList[laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe4] = 1;
$ItemMax[marmor, laserwaffe4] = 1;
$ItemMax[harmor, laserwaffe4] = 1;



$ItemMax[harmor, laserwaffe5] = 0;
$ItemMax[larmor, laserwaffe5] = 0;
$ItemMax[marmor, laserwaffe5] = 0;
$ItemMax[harmor, laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe6] = 0;
$ItemMax[marmor, laserwaffe6] = 0;
$ItemMax[harmor, krass] = 0;

$spawnBuyList[1] = Laserwaffe4;
}

if($PSPR > 50)
{
$MountTool = 0;
$FLAKMODUS = 0;

$InvList[laserwaffe5] = 1;
$InvList[laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe5] = 1;
$ItemMax[marmor, laserwaffe5] = 1;
$ItemMax[harmor, laserwaffe5] = 1;
$ItemMax[harmor, krass] = 0;

$spawnBuyList[1] = Laserwaffe5;
}

if($PSPR > 60)
{
$MountTool = 0;
$FLAKMODUS = 0;

$InvList[laserwaffe6] = 1;
$ItemMax[larmor, laserwaffe6] = 0;
$ItemMax[marmor, laserwaffe6] = 1;
$ItemMax[harmor, laserwaffe6] = 1;
$ItemMax[harmor, krass] = 0;

}

if($PSPR > 65)
{
$MountTool = 1;
$FLAKMODUS = 0;

$InvList[krass] = 1;
$ItemMax[larmor, krass] = 0;
$ItemMax[marmor, krass] = 0;
$ItemMax[harmor, krass] = 1;

}

if($PSPR > 70)
{
$MountTool = 1;
$FLAKMODUS = 0;

$ItemMax[larmor, ToolLw] = 1;
$InvList[ToolLw] = 1;
$MountTool = 1;

$spawnBuyList[1] = Laserwaffe5;
}

if($PSPR > 80)
{
$MountTool = 1;

$FLAKMODUS = 1;

}

if($PSPR < 11)
{
$spawnBuyList[1] = Laserwaffe;

$ItemMax[harmor, laserwaffe4] = 0;
$ItemMax[harmor, laserwaffe5] = 0;
$ItemMax[larmor, laserwaffe4] = 0;
$ItemMax[larmor, laserwaffe5] = 0;
$ItemMax[marmor, laserwaffe4] = 0;
$ItemMax[marmor, laserwaffe5] = 0;
$ItemMax[harmor, laserwaffe6] = 0;
$ItemMax[larmor, laserwaffe6] = 0;
$ItemMax[marmor, laserwaffe6] = 0;
$ItemMax[harmor, krass] = 0;


}
}








function Game::clientKilled(%playerId, %killerId)
{
   // do nothing
}

function Client::leaveGame(%clientId)
{
   // do nothing
}

function Player::enterMissionArea(%player)
{
   echo("Spieler " @ %player @ " betritt den Platz des H�LLEN-DESTRICT.");
}

function Player::leaveMissionArea(%player)
{
   echo("Spieler " @ %player @ " verl�sst den H�LLEN-DESTRICT.");
}

function GameBase::getHeatFactor(%this)
{
   return 0.0;
}

