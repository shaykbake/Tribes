$InvList[RL1] = 0;









RocketData RL1Bolt
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.1;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 10.0;
   kickBackStrength = 20.0;
   muzzleVelocity   = 200.0;
   terminalVelocity = 200.0;
   acceleration     = 3.0;
   totalTime        = 10.0;
   liveTime         = 5.0;
   lightRange       = 0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   

   soundId = SoundJetHeavy;
};

//-----------------projectile-----------------------------

LaserData starLaserX
{
   laserBitmapName   = "laserpulse5.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.9;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.1;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData RL1Image
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = {0, 0, 0};

	weaponType = 0; // Single Shot
//	projectileType = starLaser6;
	accuFire = true;
	reloadTime = 0.05;
	fireTime = 0.05;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData RL1
{
	description = "RaketenwerferType 1";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenadeL";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = RL1Image;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};




//---------------------funktionkacke-------------------

function RL1Image::onFire(%player,%slot)
{


%trans = GameBase::getMuzzleTransform(%player); 
         %vel = Item::getVelocity(%player); 
         %xrnd = (floor(getRandom() *21)-10)/100;      //*21 -10)/100 
         %yrnd = (floor(getRandom() *21)-10)/100; 
         %zrnd = (floor(getRandom() *21)-10)/100; 

         %trans1= getWord(%trans,0); 
         %trans2= getWord(%trans,1); 
         %trans3= getWord(%trans,2); 
         %trans4= getWord(%trans,3) + %xrnd; 
         %trans5= getWord(%trans,4) + %yrnd; 
         %trans6= getWord(%trans,5) + %zrnd; 
         %trans7= getWord(%trans,6); 
         %trans8= getWord(%trans,7); 
         %trans9= getWord(%trans,8); 
         %trans10=getWord(%trans,9); 
         %trans11=getWord(%trans,10); 
         %trans12=getWord(%trans,11); 
         %NewTrans = %trans1 @" "@ %trans2 @" "@ %trans3 @" "@ %trans4 @" "@ %trans5 @" "@ %trans6 @" "@ %trans7 @" "@ %trans8 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 

         //Projectile::spawnProjectile(starLaser6,%NewTrans,%player,%vel); 
         Projectile::spawnProjectile(RL1Bolt,%NewTrans,%player,%vel); 

}

function RL1::onMount(%player,%imageSlot,%item) 
{    
     %client = Player::getClient(%player); 
   Bottomprint(%client, "<jc><f0>RaketenwerferType 1 :  Muliple-Raketen", 5); 
} 