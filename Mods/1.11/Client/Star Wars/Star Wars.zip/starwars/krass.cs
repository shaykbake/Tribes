$InvList[krass] = 0;




ExplosionData krassExp
{
   shapeName = "breath.dts";
   soundId   = energyExplosion;

   faceCamera = true;
   randomSpin = true;
   hasLight   = true;
   lightRange = 3.0;

   timeZero = 0.450;
   timeOne  = 0.750;

   colors[0]  = { 0.25, 0.25, 1.0 };
   colors[1]  = { 0.25, 0.25, 1.0 };
   colors[2]  = { 1.0, 1.0,  1.0 };
   radFactors = { 1.0, 1.0,  1.0 };

   shiftPosition = True;
};

GrenadeData krassGren
{
   bulletShapeName    = "shield.dts";
   explosionTag       = rocketExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 100;
   totalTime          = 5.0;    // special meaning for grenades...
   liveTime           = 5.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "paint.dts";
};

RocketData krassBolt2
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = krassExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.1;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 10.0;
   kickBackStrength = 20.0;
   muzzleVelocity   = 30.0;
   terminalVelocity = 30.0;
   acceleration     = 3.0;
   totalTime        = 1.0;
   liveTime         = 1.0;
   lightRange       = 0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 150;
   trailWidth  = 1.3;

   soundId = SoundJetHeavy;
};


RocketData krassBolt
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = krassExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1.1;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 10.0;
   kickBackStrength = 20.0;
   muzzleVelocity   = 100.0;
   terminalVelocity = 100.0;
   acceleration     = 3.0;
   totalTime        = 3.1;
   liveTime         = 3.1;
   lightRange       = 0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   

   soundId = SoundJetHeavy;
};

//-----------------projectile-----------------------------

LaserData krasslaser
{
   laserBitmapName   = "laserpulse5.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.000001;
   baseDamageType    = $LaserDamageType;

   beamTime          = 10.1;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData krassImage
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = {0, 0, 0};

	weaponType = 0; // Single Shot
//	projectileType = starLaser6;
	accuFire = true;
	reloadTime = 5;
	fireTime = 5;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData krass
{
	description = "Raketenwerfer Type2";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenadeL";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = krassImage;
	price = 0;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};




//---------------------funktionkacke-------------------






function krass::onMount(%player,%imageSlot,%item) 
{   
	 
	 
%client = Player::getClient(%player); 

if($FLAKMODUS == 1)
{
Player::mountItem(%player,krassTool,7);
Bottomprint(%client, "<jc><f0>Raketenwerfer Type2: Fl�chenbombardierung\n<f1>Zusatztool :  "@ krassTool.description @"", 5);
}
	else
	{
 	 Bottomprint(%client, "<jc><f0>Raketenwerfer Type2: Fl�chenbombardierung", 5);
	}  

} 

function krass::onUnmount(%player,%imageSlot) 
{
	Player::unmountItem(%player,7); 
} 








function krassImage::onFire(%player, %slot)
{ 
  
   $trans = GameBase::getMuzzleTransform(%player);
   %vel = Item::getVelocity(%player); 
   %obj = Projectile::spawnProjectile(krassBolt, $trans, %player, %vel); 


 
%velocity = Item::getVelocity(%obj);

%client = Player::getClient(%player);

schedule("boden("@%client@","@%obj@","@%player@");", 1.5,%obj);
schedule("boden2("@%client@","@%obj@","@%player@");", 1.5,%obj);
schedule("boden3("@%client@","@%obj@","@%player@");", 1.5,%obj);
schedule("boden4("@%client@","@%obj@","@%player@");", 1.5,%obj);

schedule("boden("@%client@","@%obj@","@%player@");", 2,%obj);
schedule("boden2("@%client@","@%obj@","@%player@");", 2,%obj);
schedule("boden3("@%client@","@%obj@","@%player@");", 2,%obj);
schedule("boden4("@%client@","@%obj@","@%player@");", 2,%obj);

schedule("boden("@%client@","@%obj@","@%player@");", 2.5,%obj);
schedule("boden2("@%client@","@%obj@","@%player@");", 2.5,%obj);
schedule("boden3("@%client@","@%obj@","@%player@");", 2.5,%obj);
schedule("boden4("@%client@","@%obj@","@%player@");", 2.5,%obj);

	if($FLAKMODUS == 1)
	{
	Player::trigger(%player,7,true);
	Player::trigger(%player,7,false);
	}
} 


//----------------------------------------------------------------------------------------------
//----------------------------------erstes projektil---------------------------------------
//----------------------------------------------------------------------------------------------
function boden(%client,%obj,%player)
{

%position = GameBase::getPosition(%obj);

%vl = Item::getVelocity(%obj);
%tra = GameBase::getTransform(%obj);
%TP = GameBase::getMuzzleTransform(%client);


//---------NEW PROJECTILE OUT OF THE OLD ONE---------------------

%xrnd = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd = (floor(getRandom() *21)-10)/10; 
%zrnd = (floor(getRandom() *21)-10)/10; 

%MANUtrans = "1 0 "@%xrnd@" "@%yrnd@" "@%zrnd@" 0 1 0 1 "@%position;
%Nobj = Projectile::spawnProjectile(krassBolt2, %MANUtrans, %player, %vl);    //warum zum teufel fliegt das 2. projectile nicht dorthin wo ich hinziele

%positionPRO2 = GameBase::getPosition(%Nobj);
//Bottomprint(%client, "<jc><f3>ZEUG:        "@%MANUtrans@"", 10);

schedule("multigranate("@%player@","@%Nobj@");", 0.9,%Nobj);
}


//----------------------------------------------------------------------------------------------
//----------------------------------zweites projektil--------------------------------------
//----------------------------------------------------------------------------------------------
function boden2(%client,%obj,%player)
{

%position = GameBase::getPosition(%obj);

%vl = Item::getVelocity(%obj);
%tra = GameBase::getTransform(%obj);
%TP = GameBase::getMuzzleTransform(%client);


//---------NEW PROJECTILE OUT OF THE OLD ONE---------------------

%xrnd = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd = (floor(getRandom() *21)-10)/10; 
%zrnd = (floor(getRandom() *21)-10)/10; 

%MANUtrans = "1 0 "@%xrnd@" "@%yrnd@" "@%zrnd@" 0 1 0 1 "@%position;
%Nobj = Projectile::spawnProjectile(krassBolt2, %MANUtrans, %player, %vl);    //warum zum teufel fliegt das 2. projectile nicht dorthin wo ich hinziele

%positionPRO2 = GameBase::getPosition(%Nobj);
//Bottomprint(%client, "<jc><f3>ZEUG:        "@%MANUtrans@"", 10);

schedule("multigranate("@%player@","@%Nobj@");", 0.9,%Nobj);
}


//----------------------------------------------------------------------------------------------
//----------------------------------drittes projektil---------------------------------------
//----------------------------------------------------------------------------------------------
function boden3(%client,%obj,%player)
{

%position = GameBase::getPosition(%obj);

%vl = Item::getVelocity(%obj);
%tra = GameBase::getTransform(%obj);
%TP = GameBase::getMuzzleTransform(%client);


//---------NEW PROJECTILE OUT OF THE OLD ONE---------------------

%xrnd = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd = (floor(getRandom() *21)-10)/10; 
%zrnd = (floor(getRandom() *21)-10)/10; 

%MANUtrans = "1 0 "@%xrnd@" "@%yrnd@" "@%zrnd@" 0 1 0 1 "@%position;
%Nobj = Projectile::spawnProjectile(krassBolt2, %MANUtrans, %player, %vl);    //warum zum teufel fliegt das 2. projectile nicht dorthin wo ich hinziele

%positionPRO2 = GameBase::getPosition(%Nobj);
//Bottomprint(%client, "<jc><f3>ZEUG:        "@%MANUtrans@"", 10);

schedule("multigranate("@%player@","@%Nobj@");", 0.9,%Nobj);
}


//----------------------------------------------------------------------------------------------
//----------------------------------viertes projektil---------------------------------------
//----------------------------------------------------------------------------------------------
function boden4(%client,%obj,%player)
{

%position = GameBase::getPosition(%obj);

%vl = Item::getVelocity(%obj);
%tra = GameBase::getTransform(%obj);
%TP = GameBase::getMuzzleTransform(%client);


//---------NEW PROJECTILE OUT OF THE OLD ONE---------------------

%xrnd = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd = (floor(getRandom() *21)-10)/10; 
%zrnd = (floor(getRandom() *21)-10)/10; 

%MANUtrans = "1 0 "@%xrnd@" "@%yrnd@" "@%zrnd@" 0 1 0 1 "@%position;
%Nobj = Projectile::spawnProjectile(krassBolt2, %MANUtrans, %player, %vl);    //warum zum teufel fliegt das 2. projectile nicht dorthin wo ich hinziele



//Bottomprint(%client, "<jc><f3>ZEUG:        "@%MANUtrans@"", 10);

schedule("multigranate("@%player@","@%Nobj@");", 0.9,%Nobj);
}




function multigranate(%player,%Nobj)
{
%positionPRO2 = GameBase::getPosition(%Nobj);

%xrnd2 = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd2 = (floor(getRandom() *21)-10)/10; 
%zrnd2 = (floor(getRandom() *21)-10)/10; 

%xrnd3 = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd3 = (floor(getRandom() *21)-10)/10; 
%zrnd3 = (floor(getRandom() *21)-10)/10; 

%xrnd4 = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd4 = (floor(getRandom() *21)-10)/10; 
%zrnd4 = (floor(getRandom() *21)-10)/10; 

%xrnd5 = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd5 = (floor(getRandom() *21)-10)/10; 
%zrnd5 = (floor(getRandom() *21)-10)/10; 

%xrnd6 = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd6 = (floor(getRandom() *21)-10)/10; 
%zrnd6 = (floor(getRandom() *21)-10)/10; 

%xrnd7 = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
%yrnd7 = (floor(getRandom() *21)-10)/10; 
%zrnd7 = (floor(getRandom() *21)-10)/10; 

%vl2 = Item::getVelocity(%player);
%MANUtrans2 = "1 0 "@%xrnd2@" "@%yrnd2@" "@%zrnd2@" 0 1 0 1 "@%positionPRO2;
%MANUtrans3 = "1 0 "@%xrnd3@" "@%yrnd3@" "@%zrnd3@" 0 1 0 1 "@%positionPRO2;
%MANUtrans4 = "1 0 "@%xrnd4@" "@%yrnd4@" "@%zrnd4@" 0 1 0 1 "@%positionPRO2;
%MANUtrans5 = "1 0 "@%xrnd5@" "@%yrnd5@" "@%zrnd5@" 0 1 0 1 "@%positionPRO2;
%MANUtrans6 = "1 0 "@%xrnd6@" "@%yrnd6@" "@%zrnd6@" 0 1 0 1 "@%positionPRO2;
%MANUtrans7 = "1 0 "@%xrnd7@" "@%yrnd7@" "@%zrnd7@" 0 1 0 1 "@%positionPRO2;

if($FLAKMODUS == 1)
{
krassGren.liveTime = (floor(getRandom() *21)-10)/10; 
krassGren.totalTime = (floor(getRandom() *21)-10)/10;
}

Projectile::spawnProjectile(krassGren, %MANUtrans2, %player, %vl2);

if($FLAKMODUS == 1)
{
krassGren.liveTime = (floor(getRandom() *21)-10)/10; 
krassGren.totalTime = (floor(getRandom() *21)-10)/10;
}

Projectile::spawnProjectile(krassGren, %MANUtrans3, %player, %vl2);

if($FLAKMODUS == 1)
{
krassGren.liveTime = (floor(getRandom() *21)-10)/10; 
krassGren.totalTime = (floor(getRandom() *21)-10)/10;
}

Projectile::spawnProjectile(krassGren, %MANUtrans4, %player, %vl2);

if($FLAKMODUS == 1)
{
krassGren.liveTime = (floor(getRandom() *21)-10)/10; 
krassGren.totalTime = (floor(getRandom() *21)-10)/10;
}

Projectile::spawnProjectile(krassGren, %MANUtrans5, %player, %vl2);

if($FLAKMODUS == 1)
{
krassGren.liveTime = (floor(getRandom() *21)-10)/10; 
krassGren.totalTime = (floor(getRandom() *21)-10)/10;
}

Projectile::spawnProjectile(krassGren, %MANUtrans6, %player, %vl2);

if($FLAKMODUS == 1)
{
krassGren.liveTime = (floor(getRandom() *21)-10)/10; 
krassGren.totalTime = (floor(getRandom() *21)-10)/10;
}

Projectile::spawnProjectile(krassGren, %MANUtrans7, %player, %vl2);


%Ltime = krassGren.liveTime;
%Ttime = krassGren.totalTime;



%client = Player::getClient(%player);

//Bottomprint(%client, "<jc><f3>ZEUG:        "@%Ltime@"     "@%Ttime@"", 10);
};






