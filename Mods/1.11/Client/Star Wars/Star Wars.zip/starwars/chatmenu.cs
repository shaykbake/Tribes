newObject(PlayChatMenu, ChatMenu, "Root Menu:");
newObject(CommandChatMenu, ChatMenu, "Command Menu");

function setPlayChatMenu(%heading)
{
   $curPlayChatMenu = %heading;
}

function setCommanderChatMenu(%heading)
{
   $curCommanderChatMenu = %heading;
}

function addPlayTeamChat(%text, %msg, %sound)
{
   if(%sound != "")
   {
      %msg = %msg @ "~w" @ %sound;
   }
   if($curPlayChatMenu != "")
   {
      %text = $curPlayChatMenu @ "\\" @ %text;
   }
   addCMCommand(PlayChatMenu, %text, say, 1, %msg);
}

function addPlayChat(%text, %msg, %sound)
{
   if(%sound != "")
   {
      %msg = %msg @ "~w" @ %sound;
   }
   if($curPlayChatMenu != "")
   {
      %text = $curPlayChatMenu @ "\\" @ %text;
   }
   addCMCommand(PlayChatMenu, %text, say, 0, %msg);
}

function addPlayAnim(%text, %anim, %sound)
{
   if($curPlayChatMenu != "")
   {
      %text = $curPlayChatMenu @ "\\" @ %text;
   }
   addCMCommand(PlayChatMenu, %text, messageAndAnimate, %anim, %sound);
}

function addLocal(%text, %sound)
{
   if($curPlayChatMenu != "")
   {
      %text = $curPlayChatMenu @ "\\" @ %text;
   }
   addCMCommand(PlayChatMenu, %text, localMessage, %sound);
}

function addPlayCMDResponse(%text, %action, %msg, %sound)
{
   if(%sound != "")
      %msg = %msg @ "~w" @ %sound;
   if($curPlayChatMenu != "")
      %text = $curPlayChatMenu @ "\\" @ %text;
   addCMCommand(PlayChatMenu, %text, remoteEval, 2048, "CStatus", %action, %msg);
}

function addCommandResponse(%text, %action, %msg, %sound)
{
   if(%sound != "")
      %msg = %msg @ "~w" @ %sound;
   if($curCommanderChatMenu != "")
      %text = $curCommanderChatMenu @ "\\" @ %text;
   addCMCommand(CommandChatMenu, %text, remoteEval, 2048, "CStatus", %action, %msg);
}


function addContextCommand(%text, %type)
{
   if($curCommanderChatMenu != "")
      %text = $curCommanderChatMenu @ "\\" @ %text;
   addCMCommand(CommandChatMenu, %text, contextCommand, %type);
}

function addCommand(%text, %action, %msg, %sound)
{
   if(%sound != "")
      %msg = %msg @ "~w" @ %sound;
   if($curCommanderChatMenu != "")
      %text = $curCommanderChatMenu @ "\\" @ %text;
   addCMCommand(CommandChatMenu, %text, setIssueCommand, %action, %msg);
}

// Player Chat menu

setPlayChatMenu("vANGRIFF");
		addPlayTeamChat("aAngriff!!","verdammt nochmal greift AN!!!!!", attack);
		addPlayTeamChat("wWartet auf Signal", "Wartet auf mein Signal zum Attackieren!!", waitsig);
		addPlayTeamChat("cFeuer einstellen", "Feuer einstellen!!!", cease);
		addPlayTeamChat("mAusr�cken", "Alle mann ausr�cken", moveout);
		addPlayTeamChat("rR�ckzug", "R�ckzug!!", retreat);
		addPlayTeamChat("hZielt auf Decke", "Zielt auf die Decke", hitdeck);
		addPlayTeamChat("eNeu gruppieren", "gruppiert euch neu", regroup);
		addPlayTeamChat("vDeckung", "Gebt mir Deckung", coverme);
		addPlayTeamChat("gZur Offensive", "Offensiv angriff ohne auf verluste zu achten.", ono);
		addPlayTeamChat("zFlugschiff bereit", "Flugschiff bereit ..warte auf passagiere", waitpas);

setPlayChatMenu("tZIEL");
		addPlayTeamChat("aZiel gefunden!!", "Habe Ziel gefunden!!!", tgtacq);
		addPlayTeamChat("fFeuer auf mein Ziel", "Feuert auf Mein Ziel!!!", firetgt);
		addPlayTeamChat("nBrauche Ziel", "Ich brauch ein Ziel!!", needtgt);
		addPlayTeamChat("oZiel auser reichweite", "Ziel auserhalb der Reichweite!!", tgtout);
		addPlayTeamChat("dZerst�rt feindlichen Generator!!!", "Zerst�rt feindlichen Generator!!!", desgen);
		addPlayTeamChat("eFeindliche Generatoren Zerst�rt", "Feindlicher Generator Zerst�rt!!", gendes);
		addPlayTeamChat("tZerst�rt feindliche Turrets!!", "Zerst�rt feindliche Turrets!!", destur);
		addPlayTeamChat("sFeindlicher Turret zerst�rt", "Feindlicher Turret Zerst�rt.", turdes);

setPlayChatMenu("dVERTEIDIGUNG");
		addPlayTeamChat("iFeind in sicht", "Feind ist in sicht!!!", incom2);
		addPlayTeamChat("aAttackiert", "wir werden attackiert!!!!", basatt);
		addPlayTeamChat("eAngriff auf unsere Basis", "Der Feind attackiert unsere basis!!!", basundr);
		addPlayTeamChat("nMehr Verteidigung", "Wir brauchen mehr verteidigung!!!", needdef);
		addPlayTeamChat("bBasis verteidigen", "Verteidigt unsere Basis!!!!verdammt nochmal!!!!", defbase);
		addPlayTeamChat("dBeimverteidigen", "verteidige unsere basis", defend);
		addPlayTeamChat("tBasis eingenommen", "Basis wurde eingenommen.", basetkn);
		addPlayTeamChat("cBasis gesichert", "Basis ist gesichert.", bsclr2);
		addPlayTeamChat("qbasis gesichert?", "Ist unsere Basis gesichert?", isbsclr);

setPlayChatMenu("fFLAGGE");
		addPlayTeamChat("gFlag gone", "Our flag is not in the base!", flgtkn1);
		addPlayTeamChat("eEnemy has flag", "The enemy has our flag!", flgtkm2);
		addPlayTeamChat("hhab Flagge", "I have the enemy flag.", haveflg);
		addPlayTeamChat("sFlagge sicher", "Flagge wurde gesichert", flaghm);
		addPlayTeamChat("rFlagge zur�ck", "Bringt unsere verdammt flagge zur�ck", retflag);
		addPlayTeamChat("fFlagge holen", "Holt die generische Flagge schnell, ich hab sie makiert!!!", geteflg);
		addPlayTeamChat("mFlagge vermient", "Unsere flagge ist vermient", flgmine);
		addPlayTeamChat("cFlagge entmienen", "entfernt die minen von der flagge", clrflg);
		addPlayTeamChat("dMienen weg", "Minen wurden beseitigt.", mineclr);

setPlayChatMenu("rBRAUCHE");
		addPlayTeamChat("rReparatur!", "Bitte schnell reparieren!!", needrep);
		addPlayTeamChat("aNeed APC Pickup", "I need an APC pickup.", needpku);
		addPlayTeamChat("eBrauch Begleitschutz", "Ich brauch ne Escorte zur�ck zur basis", needesc);
		addPlayTeamChat("tBrauch Ammo", "Kann mir irgendwer Ammo bringen?", needamo);

setPlayChatMenu("eTEAM");
		addPlayTeamChat("wPass beim Schie�en auf", "Pass auf wo du hinschie�t!!", wshoot3);
		addPlayTeamChat("dK.A.", "Keine Ahnung", dontkno);
		addPlayTeamChat("nNein", "NEIN!!!.", no);
		addPlayTeamChat("yJa", "JA", yes);
		addPlayTeamChat("tDanke", "Danke ;)", thanks);
		addPlayTeamChat("aK.p.", "Kein problem", noprob);
		addPlayTeamChat("sSorry", "Sorry.", sorry);
		addLocal("hBeeil dich", hurystn);

setPlayChatMenu("gGLOBALER CHAT");
		addPlayChat("zNein", "Nein!!!", oops1);
		addPlayChat("oShit", "Shit", oops2);
		addPlayChat("sCheater", "Schei� Cheater", color2);
		addPlayChat("qVerdammt", "Verdammter Bullshit", color6);
		addPlayChat("cMuhaha", "Das wirst du 1000-fach bezahlen", color7);
		addPlayChat("eVerpissen", "Verpiss dich du Opfer", dsgst1);
		addPlayChat("xAusrasten", "DU VOLL SPASTI, ARSCHKRIECHER, KANALREINIGER, WICHSER, ARSCHLOCH, ICH MACH DICH KALT!!!!! KAUF DIR SCHON MAL NEN SARG!!!!!", dsgst2);

setPlayChatMenu("aANIMATION");
		addPlayAnim("oHier her", 0, ovrhere);
		addPlayAnim("dGeh ausm Weg", 1, outway);
		addPlayAnim("rR�ckzug", 2, retreat);
		addPlayAnim("sStop", 3, dsgst4);
		addPlayAnim("fSalute", 4, yes);
		addPlayAnim("zKnie-Pose", 10);
		addPlayAnim("xSteh-Pose", 11);
		addPlayAnim("qAbfeiern 1", 5, cheer1);
		addPlayAnim("eAbfeiern 2", 6, cheer2);
		addPlayAnim("wAbfeiern 3", 7, cheer3);
		addPlayAnim("vNa wie hat sich das angef�hlt??", 8, taunt10);
		addPlayAnim("gWo das herkommt gibts noch mehr!!", 9, taunt4);
		addPlayAnim("hTach", 12, hello);
		addPlayAnim("bHau nei", 12, bye);


setPlayChatMenu("zCommand Response");
	addPlayCMDResponse("aAcknowledged", 1, "Command acknowledged", "acknow");
	addPlayCMDResponse("zCompleted", 0, "Objective complete", "objcomp");
	addPlayCMDResponse("uUnable to complete", 0, "Unable to complete objective", "objxcmp");


// Commander Menu

function contextIssueCommand(%action, %msg, %sound)
{
   if(%sound != "")
      %msg = %msg @ "~w" @ %sound;
   setIssueCommand(%action, %msg);
}

// $CommandTarget can be one of:

// waypoint
// enemy vehicle
// enemy player
// enemy static
// enemy turret
// enemy sensor
// friendly vehicle
// friendly player
// friendly static
// friendly turret
// friendly sensor


function Commander::StarCommand(%type)
{
   if(%type == "*Attack")
   {
      if($CommandTarget == "enemy static")
			contextIssueCommand(1, "zerst�re feindlich ausr�stung bei ziel koordinaten(ziel auf karte)", "attobj"); 
      else if($CommandTarget == "enemy turret")
			contextIssueCommand(1, "zerst�re feindliche Turrets bei Zielkoordinaten(ziel auf karte)", "attobj"); 
      else if($CommandTarget == "enemy sensor")
			contextIssueCommand(1, "zerst�re feindlichen Sensor bei zielkoordinaten(ziel auf karte)", "attobj"); 
      else if($CommandTarget == "enemy player" || $CommandTarget == "enemy vehicle")
         contextIssueCommand(1, "Greif feind an(ziel auf karte)" @ $CommandTargetName, "attway");
      else if($CommandTarget == "friendly player")
         contextIssueCommand(1, "gib deckung(ziel auf karte)" @ $CommandTargetName, "escfr");
      else if($CommandTarget == "friendly vehicle")
         contextIssueCommand(1, "komm an board von flugsvhiff(ziel auf karte)", "boarda");
      else
         contextIssueCommand(1, "Greif feindliche Basis an (ziel auf karte)", "attway");
   }
   else if(%type == "*Defend")
   {
		if($CommandTarget == "friendly player")
		   contextIssueCommand(2, "Verteidige (ziel auf karte)" @ $CommandTargetName, "escfr"); 
		else
		   contextIssueCommand(2, "verteidige zielkoordinaten(ziel auf karte)", "defway");
   }
   else if(%type == "*Repair")
   {
		if($CommandTarget == "friendly player")
		   contextIssueCommand(2, "Reparier spieler(ziel auf karte)" @ $CommandTargetName, "repplyr"); 
		else
		   contextIssueCommand(2, "Reparier objekt (ziel auf karte)" @ $CommandTargetName, "repobj");
   }
}

setCommanderChatMenu("");

   addCommand("aAngriff", 1, "*Angriff");
   addCommand("dVerteidigen", 2, "*Verteidigen");
   addCommand("rReparieren", 3, "*Reparieren");

   setCommanderChatMenu("ePlazieren");
		setCommanderChatMenu("ePlazieren\\sSensor");
			addCommand("pPulse sensor", 2, "plaziere Pulse Sensor bei zielkoordinaten", "deppuls");
			addCommand("jJammer", 2, "Plaziere Sensor-jammer bei zielkoordinaten", "depjamr");
			addCommand("mMotion sensor", 2, "plaziere Motion-Sensor bei zielkoordinaten", "depmot");
			addCommand("cCamera", 2, "Plaziere Kammera bei Zielkoordinaten", "depcam");
		setCommanderChatMenu("ePlazieren\\aObjekt");
			addCommand("aAmmoStation", 2, "Plaziere Ammo Station bei zielkoordinaten", "depamo");
			addCommand("iInventory", 2, "Plaziere Inventory Station bei zielkoordinaten", "depinv");
			addCommand("tTurret", 2, "plaziere Turret bei Zielkoordianten", "deptur");
			addCommand("bMarkierer", 2, "Plaziere Markierung bei Zielkoordinaten", "depbecn");
		setCommanderChatMenu("ePlazieren Flugschiff");
		addCommand("vA.P.C.", 2, "Flieg APC zum Zielpunkt", "pilot");

setCommanderChatMenu("kCommand Response");
	addCommandResponse("aAcknwledged", 1, "Command acknowledged", "acknow");
	addCommandResponse("cCompleted", 0, "Objective complete", "objcomp");
	addCommandResponse("uUnable to complete", 0, "Unable to complete objective", "objxcmp");