



function STARGATEEIN::onEnter(%this,%object)
{
%type = getObjectType(%object);

if(%type == "Player" || %type == "Vehicle")
	{
		if((%this.STARGATEEIN == true) || (%this.STARGATEAUS == true))
		{
			SG::onTrigEnter(%this, %object);
		}
		
	}

}




SG::onTrigEnter(%this, %object)
{

	%type = getObjectType(%object);
	if(%type == "Player" || %type == "Vehicle" || %type == "Flier")
	{
		%client = Player::getclient(%object);
		if(GameBase::getControlClient(%object) != %client) %client = GameBase::getControlClient(%object);
		if(Client::getTeam(%client) != GameBase::getTeam(%this) && GameBase::getTeam(%this) != -1) return;
		%group = getGroup(%this);
 		%count = Group::objectCount(%group);
 		for(%i = 0; %i < %count; %i++)
 			{ 	
 			%data = GameBase::getDataName(Group::getObject(%group,%i));
 			if(%data == DropPointMarker) 
 				{
 				%DropCount++;	
 				%droppos = Group::getObject(%group,%i);
 				%teleset = nameToID("MissionCleanup/TeleportSet"@%this);
				if(%teleset == -1)
				{
					%group = newObject("TeleportSet"@%this, SimSet);
					addToSet(MissionCleanup, %group);
				}
 				addToSet("MissionCleanup/TeleportSet"@%this, %droppos);	
 				}
 			}
 			
	// pick a random tele point within the set -plasmatic
 			%spawnIdx = floor(getRandom() * (%DropCount - 0.1));
			%group = nameToID("MissionCleanup/TeleportSet"@%this);		
 			%newpos = Group::getObject(%group,%spawnIdx);	
 		
 		if(GameBase::GetPosition(%newpos) != "0 0 0")
 			{
 			GameBase::playSound(%object, ForceFieldOpen, 0);
			GameBase::playSound(%this, ForceFieldOpen, 0);
			Client::sendMessage(%client, 0, "Der Raum wurde an der stelle wo du dich befandest gekr�mmt.~wshieldhit.wav");
			GameBase::SetPosition(%object, GameBase::GetPosition(%newpos));
			%Trot = GameBase::getRotation(%newpos); 
			GameBase::setRotation(%object,%Trot);
			GameBase::startFadeIn(%object);	
 			} 
 		else echo("!! WARNUNG !! kein passendes Wurmloch gefunden!!");		
	}





}