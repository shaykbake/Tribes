$InvList[Laserwaffe2] = 0;











//-----------------projectile-----------------------------

LaserData starLaser2
{
   laserBitmapName   = "paintPulse.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.18;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.2;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData Laserwaffe2Image
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	projectileType = starLaser2;
	accuFire = true;
	reloadTime = 0.2;
	fireTime = 0.2;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Laserwaffe2
{
	description = "Laser Waffe Type B";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "sniper";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = Laserwaffe2Image;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};

function Laserwaffe2::onMount(%player,%imageSlot,%item) 
{    
     %client = Player::getClient(%player); 
   Bottomprint(%client, "<jc><f3>Laser Waffe Type B\n Schaden pro schuss = St�rke 2", 5); 
} 