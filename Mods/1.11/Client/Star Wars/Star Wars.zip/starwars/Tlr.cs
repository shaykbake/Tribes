$InvList[ToolLw] = 0;





//-----------------projectile-----------------------------

RocketData TB1
{
   bulletShapeName  = "paint.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 10.0;
   kickBackStrength = 20.0;
   muzzleVelocity   = 300.0;
   terminalVelocity = 300.0;
   acceleration     = 3.0;
   totalTime        = 5.0;
   liveTime         = 5.0;
   lightRange       = 10;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   

   soundId = SoundJetHeavy;
};

//----------------waffe---------------------

ItemImageData TLRMImage
{
   shapeFile  = "paintgun";   //paintgun
	mountPoint = 0;
	mountOffset = {0, 0, 0.2};
	//mountRotation = {0, -3.14, 0};
	//ammoType = doppelammo;
	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 1.5;
	minEnergy = 1;
	maxEnergy = 1;
	projectileType = TB1;
	accuFire = false;
};

ItemData TLRM
{
   heading = "TWaffen-Aufsteck-Tools";
	description = "Aufsteck Blaster Typ1 - Sternenrakete";
	className = "Weapon";
   shapeFile  = "paintgun";
	hudIcon = "paintgun";
	shadowDetailMask = 4;
	imageType = TLRMImage;
	price = 850;
	showWeaponBar = false;
	showInventory = false; 
};


