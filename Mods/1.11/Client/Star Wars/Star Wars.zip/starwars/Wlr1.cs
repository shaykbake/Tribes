$InvList[Laserwaffe] = 1;









BulletData LaserBullet1
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 0;
   mass               = 0.05;
   //bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.09;
   damageType         = $LaserDamageType;

   aimDeflection      = 0.00;
   muzzleVelocity     = 9225.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

  // tracerPercentage   = 1.0;
   tracerLength       = 0;
};

//-----------------projectile-----------------------------

LaserData starLaser1
{
   laserBitmapName   = "laserpulse2.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.09;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.2;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData LaserwaffeImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	projectileType = starLaser1;
	accuFire = true;
	reloadTime = 0.1;
	fireTime = 0.1;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Laserwaffe
{
	description = "Laser Waffe Type A";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "sniper";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = LaserwaffeImage;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};

function Laserwaffe::onMount(%player,%imageSlot,%item) 
{ 
%client = Player::getClient(%player); 


	Bottomprint(%client, "<jc><f3>Laser Waffe Type A\n Schaden pro schuss = St�rke 1", 5); 

    
   
} 




function LaserwaffeImage::onFire(%player, %slot) 
{ 


%trans = GameBase::getMuzzleTransform(%player);
%vel = Item::getVelocity(%player);

Projectile::spawnProjectile("starLaser1",%trans,%player,%vel);
Projectile::spawnProjectile("LaserBullet1",%trans,%player,%vel);



}

