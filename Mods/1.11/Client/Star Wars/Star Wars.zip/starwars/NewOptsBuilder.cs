$NewOptsBuilder::version = "1.5";
//
// ======    NewOptsBuilder   ======
// ============================
// done by |HH|BigBunny
// ============================
//
//
// INSTALLATION & USE:
//
//	Run this script and open up the console. There you will
//	find explaned what functions you can use. For more information
//	you can read the comments with the functions below.
//	If you know what you're doing, the 'private functions' section
//	may contain valuable functions for you.
//
//	Please know I am still writing and improving this script, so
//	updates are frequent. You can allways mail or ICQ me
//	and ask the latest news. Also I would really like to hear *any*
//	suggestion you have. Email:: bigbunny@planetstarsiege.com
//	or ICQ: 29509702.
//
//	Now may this tool help you in your creation of Gui-Files and
//	hopefully we'll have a future where all script are newopts
//	configurable.
//
//	|HH|BigBunny
//
//
// =============================================================
// =============================================================
//                   B E G I N   O F   C O D E 
// =============================================================
// =============================================================


// variable initialization
$NewOptsBuilder::script = "NoName";
$NewOptsFrameID = 0; // means unknown
$NewOptsBuilder::debugMode = false;


echo("Testing for full initialization....");


// =============================================================
// =============================================================
//                P R I V A T E   F U N C TI O N S 
// =============================================================
// =============================================================
//
// These functions are internally used by this script, but they may be
// interesting for you too. (If you understand what they do, and what
// limitations they have.)
//
//
// ============================
//       'TREE' FUNCTIONS
// ============================

function getNewOptsFrame()
// "tree-walks" to the newoptsframe
// this function was coded by presto
{
	if ($NewOptsFrameID && Object::GetName($NewOptsFrameID) == "NewOptsFrame") return $NewOptsFrameID;

	%root = nameToID(OptionsGui);
	for (%i = 0; true;%i++) {
		%shell = Group::GetObject(%root, %i);
		if (%shell == -1)
			return -1;
		if (Group::ObjectCount(%shell) > 1)
			break;
		}
	for (%i = 0; true;%i++) {
		%box = Group::GetObject(%shell, %i);
		if (%box == -1)
			return -1;
		if (isMember(%box, "NewOptsPage"))
			break;
		}
	for (%i = 0; true;%i++) {
		%page = Group::GetObject(%box, %i);
		if (%page == -1)
			return -1;
		if (isMember(%page, "NewOptsFrame"))
			break;
		}
	for (%i = 0; true;%i++) {
		%frame = Group::GetObject(%page, %i);
		if (%frame == -1)
			return -1;
		if (Object::GetName(%frame) == "NewOptsFrame")
			break;
		}
	$NewOptsFrameID = %frame;
	return $NewOptsFrameID;
}

function getObjectID(%testObject)
// Replaces nameToID, so this will find objects within the
// NewOptsFrame (and that itself) too.
// This functions searches for the name %testObject in:
// 	- Tribes default objects (all obj. Tribes created itself)
//	- NewOptsFrame and its subobjects
{
	// Known to Tribes
	if (nameToID(%testObject) != -1) return nameToID(%testObject); 
	// NewOptsFrame itself
	if (%testObject == "NewOptsFrame") return getNewOptsFrame();
	// Search the NewOptsFrame 
	return searchSubObject(getNewOptsFrame(), %testObject);
}

function searchSubObject(%testSet, %testObject)
// Introduced this function to search for objects down a whole tree.
// I have no idea what limitations it has for %testSet (0 crashed Tribes).
{
	for (%p = 0; %val != -1; %p++) {
		%val = getObjectIndexSub(%testSet, %p);
		if (Object::GetName(%val) == %testObject) return %val;
		}
	return -1;
}

function getTotalSubObjects(%testSet)
// Returns the total amount of objects within %testSet,
// That means including its sub- and sub-sub-objects etc.
{
	%totalAmount = 0;
	for (%p = 0; %p < Group::objectCount(%testSet); %p++) {
		%item = Group::getObject(%testSet, %p);
		if (Group::objectCount(%item)) {
			%totalAmount += (getTotalSubObjects(%item) + 1);
			}
		else %totalAmount++;
		}
	return %totalAmount;
}

function getObjectIndexSub(%set, %ind)
// Returns object at %index in %testSet, its subSets, etc.etc.
// Use this to list all objects in a set (till returned -1)!
// This function seems so easy, but was sooooo hard to write :(
{
	%indexNo = 0;
	for (%p = 0; %p < Group::objectCount(%set); %p++) {
		%curObj = Group::getObject(%set, %p);
		%nextIndexNo = %indexNo + getTotalSubObjects(%curObj) + 1;
		if (%ind == %indexNo) return %curObj;
		if (%ind < %nextIndexNo) return getObjectIndexSub(%curObj, %ind - (%indexNo + 1) );		
		%indexNo = %nextIndexNo;
		}
	return -1;
}

function frameTree() 
// Shows the tree-window with NewOptsFrame as root.
// This function is presto's code.
{
	simTreeCreate(tree, MainWindow);
	simTreeAddSet(tree, getNewOptsFrame() );
}

function addToNewOptsSet(%obj)
// Tries to add object with %obj as ID to the NewOptsSet.
// Returns boolean indicating if it was succesfully completed.
// Will fail if %obj <= 0 (thus return 0).
{
	if (%obj > 0) {
		addToSet(getNewOptsFrame(), %obj);
		if ($NewOptsBuilder::debugMode) echo ("addToSet("@getNewOptsFrame()@", "@%obj@");");
		return 1;
		}
	return 0;
}

// ============================
//           'DATA'   
// ============================

function addGuiObjectClass(%name, %guiClass, %defGui, %width, %height, %activeState, %needsText, %help1, %help2, %help3, %help4, %help5)
// Initializes object, allowing 5 info/help lines.
// The parameters should contain the default properties of this object class.
{
	// Constant, pretty useless to set everytime the function is called, but what the heck :)
	// If I'd decide to change this, only add another variable to this functions signature and change this number:
	$NOB::supportedHelpLines = 5;
	
	$NOB::knownClasses++;
	$NOB::classIndex[$NOB::knownClasses] = %name;
	if (%defGui) $NOB::loadGui[%name] = "Default" @ %name @ ".gui";
	else {
		$NOB::width[%name] = %width;
		$NOB::height[%name] = %height;
		}
	$NOB::guiClass[%name] = %guiClass;
	$NOB::activeState[%name] = %activeState;
	$NOB::needsText[%name] = %needsText;

	for (%counter = 1; %counter <= $NOB::supportedHelpLines; %counter++)
		if (%help[%counter] != "") $NOB::help[%counter, %name] = %help[%counter];
}

// This could be public, but it is sensitive to errors, so private.
addGuiObjectClass("Label", FearGui::FGSimpleText, False,
		150, 15, false, true,
		"");

addGuiObjectClass("FormattedText", FearGuiFormattedText, False,
		150, 15, false, true,
		"");

addGuiObjectClass("TextField", FearGui::TestEdit, False,
		150, 15, false, true,
		"This requires you to get and set value at the opening of the newopts screen.");

addGuiObjectClass("CFGButton", "PreDrawn", True,
		130, 30, true, true,
		"Needs NO further script support (just make sure to set the (alt) console command!).");

addGuiObjectClass("CheckBox", "PreDrawn", True,
		0, 0, false, false,
		"Set console var. and mirror cons. var. to keep var. matching *without* scripted support.");

addGuiObjectClass("Button", FearGui::FGUniversalButton, False,
		20, 20, false, false,
		"Button's are invisible, except when setting a known BMP root name. Shite!");

addGuiObjectClass("ComboBox", FearGui::FGStandardComboBox, False,
		150, 20, false, false,
		"For now i can only say this needs lots of scripted support,",
		"read Gui-scripters guide by Zear for more information.");

//Keeps Crashing on me, anyone sees the bug???
//addGuiObjectClass("TextList", FearGui::FGTextList, False,
//		150, 200, false, false,
//		"");
//		"For now i can only say this needs lots of scripted support,",
//		"read Gui-scripters guide by Zear for more information.");

addGuiObjectClass("Slider", FearGui::FGSlider, False,
		150, 15, false, false,
		"This requires you to get and set value at the opening/closing of the newopts screen.",
		"Note that it has a range from 0 to 1, so you'll have to do some scripted math-work.");

addGuiObjectClass("Frame", "PreDrawn", True,
		0, 0, false, false,
		"You have to be sure to move objects that are supposed to be within the frame under",
		"it in the NewOpts-tree. Maybe i'll make this easier in future. (yes, even easier!).");

addGuiObjectClass("ScrollBox", "PreDrawn", True,
		0, 0, false, false,
		"You have to be sure to move objects that are supposed to be showed in this",
		"scrollpanel under it in the NewOpts-tree (Under SimGui::ScrollContentCtrl that is).",
		"Scrolling will be taken care of automatically by Tribes.");

addGuiObjectClass("ScrollPanel", "PreDrawn", True,
		0, 0, false, false,
		"You have to be sure to move objects that are supposed to be showed in this scrollpanel under",
		"it in the NewOpts-tree. (Under SimGui::ScrollContentCtrl that is). Scrolling will be taken care of",
		"automatically by Tribes. Note that this is a plain scrollpanel, which is probably invisible.",
		"Use ScrollBox to have a Frame around it at creation.");

addGuiObjectClass("ThickFrame", FearGui::FearGuiBox, False,
		250, 150, false, false,
		"You have to be sure to move objects that are supposed to be within the frame",
		"under it in the NewOpts-tree.");

// =============================================================
// =============================================================
//                  P U B L I C   F U N C TI O N S 
// =============================================================
// =============================================================
//
// These are the ones available to the user!

function setScript(%script)
// Set script to work with, base actions/namegiving on
{
	if (%script == "") echo("Syntax: setScript(%script); where %script is the script name (without .cs)");
	else $NewOptsBuilder::script = %script;
}

function storeNewOptsPage()
// exports the current newopts page to a gui-file
// i guess you REALLY (!) want to do [ cropToScript(); ] first!
{
	if ( getNewOptsFrame() ) {
		%filename = "temp\\" @ $NewOptsBuilder::script @ ".gui";
		storeObject(getNewOptsFrame(), %filename);
		echo("NewOpts Page stored to " @ %filename);
		}
	else echo("Error writing, NewOptsFrame not found.");
}

function cropToScript()
// Deletes all newoptsframe entries except chooser and objects,
// which name starts with current work script [ setScript(); ].
{
	for (%p = getTotalSubObjects(getNewOptsFrame()) -1; %p >= 0; %p--) {
		%curObj = getObjectIndexSub(getNewOptsFrame(), %p);
		%name = Object::getName(%curObj);
		if ( String::findSubStr(%name, $NewOptsBuilder::script) == -1)
			deleteObject(%curObj);
		}			
}				

function deleteNewOptsChooser()
// Deletes newoptschooser
{
	if (getObjectID("NewOptsChooser") != -1)
		deleteObject(getObjectID("NewOptsChooser"));
	else echo("Chooser doesn't exist (anymore).");
}

function clearNewOpts()
// Clears whole newoptsframe
{
	%amount = Group::objectCount(getNewOptsFrame());
	for (%p = %amount - 1; %p  >= 0; %p--) // start at the bottom, to maitain index etc.
		deleteObject(Group::getObject($NewOptsFrameID, %p));
}

function guiTools()
// Opens usefull tools for editing the NewOptsFrame
// you'll probably have these on ALL the time :)
{
	editGui();
	frameTree();
	echo("Note that this opens windows outside the Tribes-screen. These may be invisible");
	echo("when you're in full-screen mode. Press ALT+Tab to return to windowed mode.");
}

function guiToolsGeneral()
// Opens usefull tools for gui-editing in general
{
	editGui();
	tree();
	echo("Note that this opens windows outside the Tribes-screen. These may be invisible");
	echo("when you're in full-screen mode. Press ALT+Tab to return to windowed mode.");
}

function addNewOpts(%obj, %name)
// This is what its all about!
// Adds %obj to NewOptsFrame, with %name
// 	%name will be checked for existence
//	possible %obj are created above with addGuiObjectClass();
{
	if (%obj == "" || $NOB::guiClass[%obj] == "") {
		echo("Syntax: addNewOpts(<object> , <name>);");
		echo("Where <name> is optional and <object> can be:");
		for (%counter = 1; %counter <= $NOB::knownClasses; %counter++) echo ($NOB::classIndex[%counter]);
		return;
		}
	
	if ( addToNewOptsSet( getNewObject(%obj, %name) ) ) { // this line did a lot of things!
		// added succesfully, help follows:
		if ($NewOptsBuilder::debugMode) echo("Going to show the help-lines...");
		for (%counter = 1; %counter <= $NOB::supportedHelpLines; %counter++)
			if ($NOB::help[%counter, %obj] != "") echo($NOB::help[%counter, %obj]);
		}
}

function listKnownClasses()
// Echo's all known classes (known to NOB that is)
// to the console. Use these names for all object functions
// that NOB provides and require a class as parameter.
{
	for (%counter = 1; %counter <= $NOB::knownClasses; %counter++) echo ($NOB::classIndex[%counter]);
}
	

function getNewObject(%class, %name)
// Returns a new object %class, which is how the gui-class 
// is known to NewoptsBuilder. All properties are set to Default values.
// Returns the objectID of the new object or 0 if failed
// Treat like an easier and better working [ newObject(); ]
{
	if (%class == "") {
		echo("Syntaxis: getNewObject(<class>, <name>)");
		echo("where <name> is optional. Classes known can be listed by:");
		echo("listKnownClasses();");
		}
	else
	{
		if ($NOB::guiClass[%class] == "") {
			echo("Invalid Gui-Class for NewOptsBuilder.");
			return 0;
			}
		
		// Setup the name:
		if (%name == "") %name = $NewOptsBuilder::script @ "::" @ %class @ $NOB::built[%class];
		else %name = $NewOptsBuilder::script @ "::" @ %name;
		
		if ( getObjectID(%name) != -1 ) {
			echo ("Name allready in use!");
			return 0;
			}
	
		if ($NOB::loadGui[%class] != "")
			%tempObj = loadObject(%name, $NOB::loadGui[%class]);
		else {
			%realClass = $NOB::guiClass[%class];
			%pos = 10 + 10 * $NOB::ObjectsBuilt;
			%width = $NOB::width[%class];
			%height = $NOB::height[%class];
			if ($NewOptsBuilder::debugMode) echo("newObject("@%name@", "@%realClass@", "@%pos@", "@%pos@", "@%width@", "@%height@", \"\", \"\");");
			%tempobj = newObject(%name, %realClass, %pos, %pos, %width, %height, "", "");
			}

		if ( $NOB::activeState[%class] ) {
			Control::setActive(%name, true); 
			if ($NewOptsBuilder::debugMode) echo ("Setting object to active");
			}
		if ( $NOB::needsText[%class] ) {
			Control::setText(%name, %name);
			if ($NewOptsBuilder::debugMode) echo ("Giving object value: "@%name);
			}
	
		$NOB::built[%class]++;
		$NOB::ObjectsBuilt++;
	
		return %tempobj;
	}
}

function store(%gui)
// Stores the gui %gui as a file in the tempdir.
// This is very usefull cos you cant crash Tribes with
// wrong store commands anymore.
// Usefull only for general Gui editing.
{
	if (%gui == JoinGameGui) %name = "temp\\JoinGame.gui";
	if (%gui == CreateServerGui) %name = "temp\\CreateServer.gui";
	if (%gui == ConnectGui) %name = "temp\\Connect.gui";
	if (%gui == MainMenuGui) %name = "temp\\MainMenu.gui";
	if (%gui == RecordingsGui) %name = "temp\\Recordings.gui";
	if (%gui == PlayerSetupGui) %name = "temp\\PlayerSetup.gui";
	if (%gui == CmdInventoryGui) %name = "temp\\CmdInventory.gui";
	if (%gui == PlayGui) %name = "temp\\play.gui";
	if (%gui == commandGui) %name = "temp\\command.gui";


	storeObject(nametoID(%gui), %name);
}

function exportNewOptsCode()
// Partly functional yet. Planning more user-friendly things.
// But for now it works and is bugless.
{
	//%openCode = "Control::setText(%object, %var);";
	//%closeCode = "%var = Control::getText(%object);";

	if (isFile("Console.log")) %wasFile = true; else %wasFile = false;
	$Console::LogMode = 2; 
	echo("========= AUTOGENERATED BY NEWOPTSBUILDER ================");
	echo("");
	echo("function "@ $NewOptsBuilder::script @ "::NewOptsOpen() {");
	echo("\t//code comes here!");
	echo("\t}");
	echo("");
	echo("function "@ $NewOptsBuilder::script @ "::NewOptsClose() {");
	echo("\t//code comes here!");
	echo("\t}");
	echo("");
	echo("NewOpts::register(\"" @ $NewOptsBuilder::script @ "\",");
	echo("\t\t\"" @ $NewOptsBuilder::script @ ".gui\",");
	echo("\t\t\"" @ $NewOptsBuilder::script @ "::NewOptsOpen();\",");
	echo("\t\t\"" @ $NewOptsBuilder::script @ "::NewOptsClose();\",");
	echo("\t\tTRUE);");
	echo("");
	echo("NewOpts::registerHelp(\"" @ $NewOptsBuilder::script @ "\", \"Topic\", \"Help itself comes here\");");
	echo("// Repeat help-registering lines, till complete help is written.");
	echo("");
	echo("=============== END OF AUTOGENERATED CODE ================");
	$Console::LogMode = 0; 
	echo("Ignore all text above, the NewOpts-code has been written to Tribes\\Console.log");
	echo("You know how to cut and paste do you? :) Ill make this function more user-friendly in future.");
	if (%wasFile) echo("Because the file allready existed, the code was written at the bottom of it!");
}

function howToReach(%object)
// Not really for NewOptsBuilder, more for gui-editing in general.
// To find an object %object in the tree.
// Used when found an object with the gui-tools, and
// you want to control it from the tree.
{
	if (%object != "") {
		%start = %object;	
		while (getGroup(%object)) {
			%text = getGroup(%object) @ " ==> " @ %text;
			%object = getGroup(%object);
			}
		echo("From the root (0): " @ %text @ "your request: " @ %start);
		}
	else echo("Syntaxis: howToReach(<objectID>);");
}

// ============================
//        'HELP - FUNCTION'
// ============================

function registerNOBHELP(%func, %help)
{
	$NOBHelpItems++;
	$NOBHelpItem[$NOBHelpItems] = %func;
	$NOBFunctionHelp[%func] = %help;
}

registerNOBHELP("nobHelp();","Produces this 'help-screen'. (The one you're reading now)");
registerNOBHELP("guiTools();","Opens tools for editing the NewOptsFrame - you'll really need these.");
registerNOBHELP("clearNewOpts();","Clears whole newoptsframe.");
registerNOBHELP("deleteNewOptsChooser();","Deletes newoptschooser.");
registerNOBHELP("addNewOpts();","To add objects to your newoptsframe (call w/o parameters for syntaxis).");
registerNOBHELP("setScript();","Set script to work with, this is where namegiving and cropToScript is based upon.");
registerNOBHELP("cropToScript();","Crops NewOptsFrame-set to objects named like the current work-script (set with setScript(); ).");
registerNOBHELP("storeNewOptsPage();","Exports the newopts frame to a gui-file.");
registerNOBHELP("exportNewOptsCode();","Maybe I'll let it create more code once. Works perfect yet.");
registerNOBHELP("getNewObject();","Return new object (call w/o parameters for syntaxis).");
registerNOBHELP("listKnownClasses();","Echo's all known classes (known to NOB that is).");
registerNOBHELP("howToReach();","Echo's the objects from 0 to your request. Kind of tree-walk down.");
registerNOBHELP("guiToolsGeneral();","Opens tools for gui-editing.");
registerNOBHELP("store(%gui);","Stores the gui %gui as a file in the tempdir. No more crashing and lost work!");
registerNOBHELP("All other functions Tribes provides","Don't forget those! And if you don't know em... errrr :)");

function nobHelp()
{
	echo("================================================================");
	echo("===========                  NEWOPTS BUILDER HELP                    ===========");
	echo("================================================================");
	for (%p = 1; %p <= $NOBHelpItems; %p++) {
		echo("==== " @ $NOBHelpItem[%p]);
		echo("====       " @ $NOBFunctionHelp[$NOBHelpItem[%p]]);
		}
	echo("================================================================");
}

// ============================
//        CHECKING ETC.
// ============================

if (getObjectID("NewOptsFrame") == -1) echo("OPEN OPTIONSGUI FIRST!");
echo("Testing succesfully completed.");
echo("================================================================");
echo("========          NEWOPTS BUILDER VERSION " @ $NewOptsBuilder::version @ " INITIALIZED            ========");
echo("================================================================");
echo("================    type \"nobHelp();\" to get 'help-screen'     ================");
echo("================================================================");