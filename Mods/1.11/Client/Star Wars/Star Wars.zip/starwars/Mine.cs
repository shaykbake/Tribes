//----------------------------------------------------------------------------
// MINE DYNAMIC DATA

MineData AntipersonelMine
{
	className = "Mine";
   description = "Antipersonel Mine";
   shapeFile = "mine";
   validateShape = true;
   validateMaterials = true;
   shadowDetailMask = 4;
   explosionId = mineExp;
	explosionRadius = 10.0;
	damageValue = 0.00001;
	damageType = $MineDamageType;
	kickBackStrength = 150;
	triggerRadius = 2.5;
	maxDamage = 0.5;
	shadowDetailMask = 0;
	destroyDamage = 1.0;
	damageLevel = {1.0, 1.0};
};

function AntipersonelMine::onAdd(%this)
{
	%this.damage = 0;
	AntipersonelMine::deployCheck(%this);
	
	



}

function AntipersonelMine::onCollision(%this,%object)
{
	%type = getObjectType(%object);
	%data = GameBase::getDataName(%this);
	if ((%type == "Player" || %data == AntipersonelMine || %data == Vehicle || %type == "Moveable") &&
			GameBase::isActive(%this)) 
		GameBase::setDamageLevel(%this, %data.maxDamage);

}

function AntipersonelMine::deployCheck(%this)
{
	if (GameBase::isAtRest(%this)) {
		GameBase::playSequence(%this,1,"deploy");
	 	GameBase::setActive(%this,true);
		%set = newObject("set",SimSet);
		if(1 != containerBoxFillSet(%set,$MineObjectType,GameBase::getPosition(%this),1,1,1,0)) {
			%data = GameBase::getDataName(%this);
			GameBase::setDamageLevel(%this, %data.maxDamage);
		}
		deleteObject(%set);
	}
	else 
		schedule("AntipersonelMine::deployCheck(" @ %this @ ");", 3, %this);
}	

function AntipersonelMine::onDestroyed(%this)
{
	$TeamItemCount[GameBase::getTeam(%this) @ "mineammo"]--;
	

}

function AntipersonelMine::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%data = GameBase::getDataName(%this);
	if((%data.maxDamage/1.5) < %this.damage+%value) 
		GameBase::setDamageLevel(%this, %data.maxDamage);
	else 
		%this.damage += %value;
}

//----------------------------------------------------------------------------

MineData Handgrenade
{
   mass = 0.3;
   drag = 1.0;
   density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
   description = "Handgrenade";
   shapeFile = "grenade";
   shadowDetailMask = 4;
   explosionId = grenadeExp;
	explosionRadius = 10.0;
	damageValue = 0.000001;
	damageType = $ShrapnelDamageType;
	kickBackStrength = 100;
	triggerRadius = 0.5;
	maxDamage = 2;
};

function Handgrenade::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

function Mine::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}

function Mine::Detonate(%this)
{
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);
	
	
%trans = GameBase::getMuzzleTransform(%this); 
         %vel = Item::getVelocity(%player); 
         %xrnd = (floor(getRandom() *21)-10)/10;      //*21 -10)/100 
         %yrnd = (floor(getRandom() *21)-10)/10; 
         %zrnd = (floor(getRandom() *21)-10)/10; 

         %trans1= getWord(%trans,0); 
         %trans2= getWord(%trans,1); 
         %trans3= getWord(%trans,2); 
         %trans4= getWord(%trans,3) + %xrnd; 
         %trans5= getWord(%trans,4) + %yrnd; 
         %trans6= getWord(%trans,5) + %zrnd; 
         %trans7= getWord(%trans,6); 
         %trans8= getWord(%trans,7); 
         %trans9= getWord(%trans,8); 
         %trans10=getWord(%trans,9); 
         %trans11=getWord(%trans,10); 
         %trans12=getWord(%trans,11); 
%NewTrans1 = %trans1 @" "@ %trans2 @" "@ %trans3 +5.2@" "@ %trans4-5 @" "@ %trans5+15 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+1 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans2 = %trans1 @" "@ %trans2 @" "@ %trans3 +10.4@" "@ %trans4-10 @" "@ %trans5+30 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+2 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans3 = %trans1 @" "@ %trans2 @" "@ %trans3+15.6 @" "@ %trans4-15 @" "@ %trans5+45 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+3 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans4 = %trans1 @" "@ %trans2 @" "@ %trans3+20.8 @" "@ %trans4-20 @" "@ %trans5+1.2 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+4 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans5 = %trans1 @" "@ %trans2 @" "@ %trans3+25 @" "@ %trans4-25 @" "@ %trans5+1.5 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+5 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans6 = %trans1 @" "@ %trans2 @" "@ %trans3+30.2 @" "@ %trans4-30 @" "@ %trans5+1.8 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+6 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans7 = %trans1 @" "@ %trans2 @" "@ %trans3-35.4 @" "@ %trans4+35 @" "@ %trans5-2.1 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+7 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans8 = %trans1 @" "@ %trans2 @" "@ %trans3-40.6 @" "@ %trans4+40 @" "@ %trans5-2.4 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+8 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans9 = %trans1 @" "@ %trans2 @" "@ %trans3-45.8 @" "@ %trans4+45 @" "@ %trans5-2.7 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+9 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans10 = %trans1 @" "@ %trans2 @" "@ %trans3-50 @" "@ %trans4+50 @" "@ %trans5-3 @" "@ %trans6+100 @" "@ %trans7 @" "@ %trans8+10 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans11 = %trans1 @" "@ %trans2 @" "@ %trans3-55.2 @" "@ %trans4+55 @" "@ %trans5-3.3 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+11 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans12 = %trans1 @" "@ %trans2 @" "@ %trans3-60.4 @" "@ %trans4+60 @" "@ %trans5-3.6 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+12 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans13 = %trans1 @" "@ %trans2 @" "@ %trans3-65.6 @" "@ %trans4+65 @" "@ %trans5-4.2 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+13 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans14 = %trans1 @" "@ %trans2 @" "@ %trans3-70.6 @" "@ %trans4+70 @" "@ %trans5-4.5 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+14 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans15 = %trans1 @" "@ %trans2 @" "@ %trans3+75.6 @" "@ %trans4-75 @" "@ %trans5+4.8 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+15 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans16 = %trans1 @" "@ %trans2 @" "@ %trans3+80.6 @" "@ %trans4-80 @" "@ %trans5+5.1 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+16 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans17 = %trans1 @" "@ %trans2 @" "@ %trans3+85.6 @" "@ %trans4-85 @" "@ %trans5+5.4 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+17 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans18 = %trans1 @" "@ %trans2 @" "@ %trans3+90.6 @" "@ %trans4-90 @" "@ %trans5+5.7 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+18 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 
%NewTrans19 = %trans1 @" "@ %trans2 @" "@ %trans3+95.6 @" "@ %trans4-95 @" "@ %trans5+6 @" "@ %trans6-100 @" "@ %trans7 @" "@ %trans8+19 @" "@ %trans9 @" "@ %trans10 @" "@ %trans11 @" "@ %trans12; 

         //Projectile::spawnProjectile(starLaser6,%NewTrans,%player,%vel); 
         Projectile::spawnProjectile(starLaserZZZ1,%NewTrans1,%this,%vel); 
		  Projectile::spawnProjectile(starLaserZZZ2,%NewTrans2,%this,%vel);
		   Projectile::spawnProjectile(starLaserZZZ3,%NewTrans3,%this,%vel);
		    Projectile::spawnProjectile(starLaserZZZ4,%NewTrans4,%this,%vel);
			 Projectile::spawnProjectile(starLaserZZZ1,%NewTrans5,%this,%vel);
			  Projectile::spawnProjectile(starLaserZZZ2,%NewTrans6,%this,%vel);
			   Projectile::spawnProjectile(starLaserZZZ3,%NewTrans7,%this,%vel);
			    Projectile::spawnProjectile(starLaserZZZ4,%NewTrans8,%this,%vel);
				 Projectile::spawnProjectile(starLaserZZZ1,%NewTrans9,%this,%vel);
				  Projectile::spawnProjectile(starLaserZZZ2,%NewTrans10,%this,%vel);
				   Projectile::spawnProjectile(starLaserZZZ3,%NewTrans11,%this,%vel);
				    Projectile::spawnProjectile(starLaserZZZ4,%NewTrans12,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ1,%NewTrans13,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ2,%NewTrans14,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ3,%NewTrans15,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ4,%NewTrans16,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ1,%NewTrans17,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ2,%NewTrans18,%this,%vel);
					 Projectile::spawnProjectile(starLaserZZZ3,%NewTrans19,%this,%vel);

}

LaserData starLaserZZZ1
{
   laserBitmapName   = "laserpulse.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.0;
   baseDamageType    = $LaserDamageType;

   beamTime          = 30.1;

   lightRange        = 10.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData starLaserZZZ2
{
   laserBitmapName   = "laserpulse2.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.0;
   baseDamageType    = $LaserDamageType;

   beamTime          = 30.1;

   lightRange        = 10.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData starLaserZZZ3
{
   laserBitmapName   = "laserpulse3.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.0;
   baseDamageType    = $LaserDamageType;

   beamTime          = 30.1;

   lightRange        = 10.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

LaserData starLaserZZZ4
{
   laserBitmapName   = "laserpulse4.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.0;
   baseDamageType    = $LaserDamageType;

   beamTime          = 30.1;

   lightRange        = 10.0;
   lightColor        = { 1.0, 2.25, 5.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};






