$InvList[Laserwaffe5] = 0;









BulletData LaserBullet5
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.7;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.00;
   muzzleVelocity     = 9225.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 0;
};


//-----------------projectile-----------------------------

LaserData starLaser5
{
   laserBitmapName   = "laserpulse5.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.7;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.2;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData Laserwaffe5Image
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	//projectileType = starLaser5;
	accuFire = true;
	reloadTime = 0.5;
	fireTime = 0.5;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Laserwaffe5
{
	description = "Laser Waffe Type E";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "sniper";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = Laserwaffe5Image;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};

function Laserwaffe5::onMount(%player,%imageSlot,%item) 
{    
     %client = Player::getClient(%player);
	
if($MountTool == 1)
{
Player::mountItem(%player,TLRM,7);
Bottomprint(%client, "<jc><f3>Laser Waffe Type E\n Schaden pro schuss = St�rke 5\n<f1>Zusatz :"@TLRM.description@" ", 5); 
}
	else
	{
	Bottomprint(%client, "<jc><f3>Laser Waffe Type E\n Schaden pro schuss = St�rke 5", 5); 
	}
} 

function Laserwaffe5::onUnmount(%player,%imageSlot) 
{
	Player::unmountItem(%player,7); 
} 

function Laserwaffe5Image::onFire(%player, %slot) 
{ 


%trans = GameBase::getMuzzleTransform(%player);
%vel = Item::getVelocity(%player);

Projectile::spawnProjectile("starLaser5",%trans,%player,%vel);
Projectile::spawnProjectile("LaserBullet5",%trans,%player,%vel);

Player::trigger(%player,7,true);
Player::trigger(%player,7,false);

}









