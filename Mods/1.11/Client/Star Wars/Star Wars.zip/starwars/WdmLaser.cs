$InvList[DML] = 0;











//-----------------projectile-----------------------------

LaserData DMLB
{
   laserBitmapName   = "paintPulse.bmp";
   hitName           = "shockwave_large.dts";

   damageConversion  = 0.7;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.1;

   lightRange        = 0.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//----------------waffe---------------------



ItemImageData DMLImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	projectileType = DMLB;
	accuFire = true;
	reloadTime = 0.15;
	fireTime = 0.15;
	minEnergy = 1;
	maxEnergy = 1;

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData DML
{
	description = "DML";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "sniper";
   heading = "bWeapons";
	shadowDetailMask = 4;
	imageType = DMLImage;
	price = 2000;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = true;
};

function DML::onMount(%player,%imageSlot,%item) 
{    
     %client = Player::getClient(%player); 
   Bottomprint(%client, "<jc><f3>DML\n <f0>Kreiert extra f�r DeathMatch�s", 5); 
} 