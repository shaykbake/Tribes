Star Wars Release 0.2k

Leader  : Noodles
Scripts : Machine
Models  : PhantomStranger
Maps    :

Sabers  : ? Tell me who you are!
and other ppl i didnt meantion msg me.

Extract into your Tribes folder. It will automaticlly make the folders for you.

To run the mod click on the StarWarsClient.bat file.

To host a dedicated server click on the StarWarsDedicated.bat file.

Have fun! :D

-Machine