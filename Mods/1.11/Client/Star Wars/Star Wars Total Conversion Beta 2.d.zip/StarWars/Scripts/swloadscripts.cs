// BEGIN STARWARS ADDITION ===============================
// Weapons
	exec(WPN_ForceThrow);
	exec(WPN_ForceLightning);
        exec(WPN_DroidBlaster);
	exec(WPN_Repeater);
	exec(WPN_BlasterRifle);
	exec(WPN_LukeForceSpeed);
	exec(WPN_TorpLauncher);
	exec(WPN_ScoutBlaster);
	exec(WPN_GuardGun);
	exec(WPN_FlakCannon);
	exec(WPN_ConcLauncher);

// Vehicles
        exec(VEH_Awing);
	exec(VEH_INT);
	exec(VEH_Spdr);
	exec(VEH_TIE);
	exec(VEH_TIEBomb);
	exec(VEH_YWing);
	exec(VEH_XWing);
// Characters
	exec(ARM_HSolo);
	exec(ARM_Luke);
	exec(ARM_DTroop);
	exec(ARM_RTroop);
	exec(ARM_RCommando);
	exec(ARM_Thrawn);
	exec(ARM_HothTroop);
	exec(ARM_Chewy);
	exec(ARM_BobaFett);
	
// Special Effects
	exec(ARM_SpdLuke);
	exec(trigs);
// END STARWARS ADDITION =================================