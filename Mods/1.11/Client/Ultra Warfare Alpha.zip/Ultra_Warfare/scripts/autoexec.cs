// this is modified strictly for Ultra_warfare mod... 
// this is not essential for playing the mod... 
// this raises the bar on how grand
// tribes should have been... 
////////////////////////////////////////////////////////////
// File:	Autoexec.cs 1.0Beta
// Author:	Runar
// Credits:	Dad?
// Info:	Not really needed is it?
//
////////////////////////////////////////////////////////////

if($Dedicated)
{
	echo("Starting dedicated server..");
	return;
}
else
{
	exec("Viking\\Viking.cs");
	exec("Connect.cs");
	//exec("movie.cs");
}

// Prefs that I use:
$pref::skipIntro = "True";
$pref::NumDecals = "5";