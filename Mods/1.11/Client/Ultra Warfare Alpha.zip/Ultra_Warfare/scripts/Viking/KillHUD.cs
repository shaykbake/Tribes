////////////////////////////////////////////////////////////
// File:	KillHUD.cs
// Version:	1.4
// Author:	Runar
// Credits:	Presto, BigBunny, Freaky Blaster, z0dd, Mr.Poop
// Info:	Pop-up's on kills and deaths.
//
// History:	1.4 Using TeamTrack better
//
//
////////////////////////////////////////////////////////////

Event::Attach(eventKillTrak, KillHUD::PopUp);

function KillHUD::PopUp(%serverId, %victimId, %killerId, %damageType)
{
	if(%serverid != 2048)
		return;

	// Suicide or other death, turret, fall etc.
	if(%killerId == "" || %killerId == %victimId)
	{
		return;
	}
	else
	{
		if(%victimId == $myId)
		{
			if($TT::Client::Team[%killerId] == $TT::Client::Team[$myId])
			{
				remoteTP(2048, "<JC><F0>TEAMKILLED<F2> by: <F1>" @ $TT::Client::Name[%killerId] @ "\n<F2>Weapon: " @ %damageType, 5);
			}
			else
			{
				remoteTP(2048, "<JC><F0>KILLED<F2> by: <F0>" @ $TT::Client::Name[%killerId] @ "\n<F2>Weapon: " @ %damageType, 5);
			}

			return;
		}
		else if(%killerId == $myId)
		{
			if($TT::Client::Team[%victimId] == $TT::Client::Team[$myId])
			{
				remoteTP(2048, "<JC><F2>You <F1>TEAMKILLED<F2> : <F1>" @ $TT::Client::Name[%victimId] @ "\n<F2>Weapon: " @ %damageType, 5);
			}
			else
			{
				if($Viking::Taunt)
					Taunt::Local();

				remoteTP(2048, "<JC><F2>You <F1>KILLED<F2> : <F0>" @ $TT::Client::Name[%victimId] @ "\n<F2>Weapon: " @ %damageType, 5);
			}

			return;
		}
	}
}

