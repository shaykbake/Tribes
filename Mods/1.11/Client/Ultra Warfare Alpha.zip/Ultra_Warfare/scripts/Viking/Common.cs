////////////////////////////////////////////////////////////
// File:	Common.cs 3.2
// Author:	Runar
// Credits:	Presto, |HH|BigBunny, Blaster, z0dd, Mr.Poop
// Info:	Common functions you cant live without..
//
// History: 1.5 Changed the toss, now the simtime doesnt
//		doesn't mess up so youll end up with the mine
//		at your feets :)
//		Doesn't buy unnecessary rep-kits anymore.
//
//		1.4 Updated the ski script, more efficient now.
//				
////////////////////////////////////////////////////////////

Event::Attach(eventReceivedItem, FastRep::ReceivedItem);

function Jump::Start()
{
	postAction(2048, IDACTION_MOVEUP, 1);
	Schedule::Add("Jump::Start();", $Jump:Delay);
}

function Jump::Stop()
{
	Schedule::Cancel("Jump::Start();");
}

function Jet::Start()
{
	if(getMountedItem(0) != -1 && $Jet::Jump)
	{
		postAction(2048, IDACTION_MOVEUP, 1);
        	postAction(2048, IDACTION_JET, 1);
	}
	else
	{
		postAction(2048, IDACTION_JET, 1);
	}
}

function Jet::Stop()
{
	postAction(2048, IDACTION_JET, 0);
}

function Jet::Toggle()
{
 	$Jet::Jump = !$Jet::Jump;
 
	if($Jet::Jump)
	{
		remoteBP(2048, "<JC><F2>Jet & Jump set to: <F1>ON", 2);
  	} 
	else
	{
  		remoteBP(2048, "<JC><F2>Jet & Jump set to: <F0>OFF", 2);
 	} 
}

function FastRep::Use()
{
	if($Favorite::InStation)
	{
		if(getItemCount("Light Armor"))
        		%kits = "3";
		else if(getItemCount("Medium Armor"))
        		%kits = "4";
		else if(getItemCount("Heavy Armor"))
        		%kits = "6";
		else
			%kits = "6";
			

		for(%i = 0; %i < %kits; %i++)
		{
			remoteEval(2048, useItem, 39);
			remoteEval(2048, buyItem, 39);
		}
	}
	else
	{
		if(getItemCount("Repair Kit"))
		{
			remoteEval(2048, useItem, 39);
		}
		else
		{
			$FastRep::UseNext = "True";
			remoteBP(2048, "<JC><F2>Next repair kit will be used on pickup!", 2);
		}
	}

	return;
}

function FastRep::ReceivedItem(%item)
{
	if(%item == "Repair Kit" && $FastRep::UseNext)
	{
		remoteEval(2048, useItem, 39);
	}

	$FastRep::UseNext = "False";

	return;
}

function FastRep::Toggle()
{
 	$Fastrep::Auto = !$Fastrep::Auto;
 
	if($Fastrep::Auto)
	{
		remoteBP(2048, "<JC><F2>Auto buy & use repair-kits set to: <F1>ON", 2);
  	} 
	else
	{
  		remoteBP(2048, "<JC><F2>Auto buy & use repair-kits set to: <F0>OFF", 2);
 	} 
}

function Toss::Start(%item)
{
	if(!getItemCount(%item))
		return;

	Toss::Throw(%item);
}

function Toss::Stop(%item)
{
	Schedule::Cancel("toss @ %item");
}

function Toss::Throw(%item)
{
	remoteEval(2048,throwItem, getItemType(%item), 100);
	Schedule::Add("Toss::Throw(" @ %item @ ");", 0.1, "toss @ %item");
}

function Taunt::Local()
{
	$Taunt::Index++;

	if($Taunt::Index > $Taunt::MaxIdx)
		$Taunt::Index = 1;
	
	localMessage($Taunt::Saying[$Taunt::Index]);
}

function Taunt::Toggle()
{
 	$Viking::Taunt = !$Viking::Taunt;
 
	if($Viking::Taunt)
	{
		remoteBP(2048, "<JC><F2>Local-taunts are now: <F1>ON", 2);
  	} 
	else
	{
  		remoteBP(2048, "<JC><F2>Local-taunts are now: <F0>OFF", 2);
 	} 
}

function MAscreen::Toggle()
{
 	$Viking::MAscreen = !$Viking::MAscreen;
 
	if($Viking::MAscreen)
	{
		remoteBP(2048, "<JC><F2>Mid-Air screenshot is: <F1>ON", 2);
  	} 
	else
	{
  		remoteBP(2048, "<JC><F2>Mid-Air screenshot is: <F0>OFF", 2);
 	} 
}
