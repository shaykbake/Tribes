////////////////////////////////////////////////////////////
// File:	Gui.cs
// Version: 	3.2 
// Author:	Runar
// Credits:	
// Info:	
//
// History: 	3.0 Initial version
//
////////////////////////////////////////////////////////////

// Don't touch these
IDBMP_VIKING_CHAT = 00160536, "Viking\\bmp\\Chathudbg.bmp";

function Gui::Position()
{
	%x = Viking::ScreenSize("x");
	%y = Viking::ScreenSize("y");

	// Flag, Trak & TsizeHud 640x480 = 10, 420
	Control::SetPosition("FlagHud_Container", 10 , %y - 60);

	// ItemHud 640x480 = 490, 420
	Control::SetPosition("ItemHud_Container", %x - 150, %y - 60);
	
	// AmmoHud 640x480 = 288, 272
	if($Viking::AmmoHud)
		Control::SetPosition("AmmoHud_Container", %x / 2 - 24, %y / 2 + 24);

	// TeamHud 640x480 = 440, 220
	if($Viking::TeamHud)
		Control::SetPosition("TeamHud_Container", %x - 200, %y / 3);

	// CmdView 640x480 = 440, 220
	if($Viking::CmdView)
		Control::SetPosition("CmdView_Container", %x - 260, %y - 280);

	// Reticle 640x480 = 304, 224
	if($Viking::Reticle)
		Control::SetPosition("Reticle_Container", %x / 2 - 15, %y / 2 - 15);

	// Reticle Compass
	if($Viking::RetCompass)
		Control::SetPosition("RetCompass_Container", %x / 2 - 32, %y / 2 - 32);

	// Mortar and Grenade Rangefinders
	if($Viking::RFinder)
		Control::SetPosition("RF_Container", %x / 2 - 31, %y / 2 + 10);
	
	// Pop-ups
	if($Viking::Popup)
	{
		Control::SetPosition("PopUp_T_Container", %x / 4, %y - 170);
		Control::SetExtent("PopUp_T_Container", %x/2, 70);
		Control::SetPosition("PopUp_C_Container", %x / 4, 100);
		Control::SetExtent("PopUp_C_Container", %x/2, 240);
		Control::SetPosition("PopUp_B_Container", %x / 4, %y - 100);
		Control::SetExtent("PopUp_B_Container", %x/2, 70);
	}

	// ChatHud 640x480 = Size: 380, 55 Pos: %y - 270 160, 5
	if(isObject("PlayGui/ChatHudBG_Container"))
	{
		Control::SetPosition("ChatHudBG_Container", %x / 4, 5);
		Control::SetExtent("ChatHudBG_Container", %x / 2, 40);
		Control::SetExtent("ChatHudBG_Bitmap", %x / 2, 40);
		Control::SetExtent("chatDisplayHud", %x / 2, 39);
		Control::SetPosition("chatDisplayHud", 1, 1);
	}
	else
	{
		Control::SetPosition("chatDisplayHud", %x / 4, 9);
		Control::SetExtent("chatDisplayHud", %x / 2, 45);
	}
}

function Gui::ToggleBG()
{
	Control::Toggle("FlagHud_BG");
	Control::Toggle("ItemHud_BG");
}

function Control::Toggle(%object)
{
	Control::SetVisible(%object, !Control::GetVisible(%object));
}

function ChatHudGui::Create()
{
	%x = Viking::ScreenSize("x");
	%y = Viking::ScreenSize("y");

	%HudContainer=newObject("ChatHudBG_Container", SimGui::Control, 160, 5, 380, 55);
	%HudBitmapCtrl=newObject("ChatHudBG_Bitmap", FearGui::FGBitmapCtrl, 0, 0, 380, 55);

	addToSet("ChatHudBG_Container", %HudBitmapCtrl);
	addToSet(PlayGui, %HudContainer);
}
