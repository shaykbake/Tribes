////////////////////////////////////////////////////////////
// File:	Snipe.cs
// Version:	3.2
// Author:	Runar
// Credits:	Freaky, z0dd who's scripts i used for input.
// Info:	Simple script to lower your mouse sensitivity
//		when zooming, also switch to laser and back.
//
//		V. 1.1: Had to make the yflip a user option.
//
////////////////////////////////////////////////////////////

$Snipe::nSense = Client::getMouseSensitivity("playMap.sae");

function Snipe::Zoom()
{
	postAction(2048, IDACTION_SNIPER_FOV, 1);

	$Snipe::Zoomed = "True";

	if($Viking::RFinder)
	{
		Schedule::Cancel("RangeFinder");
		control::setVisible("RF_Container", False);
	}

	if($Viking::Reticle)
	{
		Control::setVisible("Reticle_Container", "False");
	}

	$Snipe::Switched = "False";
	
	Viking::Sense($Snipe::nSense * $Snipe::Factor);

	if($Snipe::Switch && getItemCount("Laser Rifle"))
	{

		$Snipe::Previous = getMountedItem(0);
		$Snipe::Switched = "True";
		use("Laser Rifle");
	}
}
 
function Snipe::Unzoom()
{
	postAction(2048, IDACTION_SNIPER_FOV, 0);

	if($Snipe::Switch)
	{
		if($Snipe::Switched)
			useItem($Snipe::Previous);

	}

	if($Viking::RFinder)
	{
		schedule::add("RangeFinder::Update();", 0.5, "RangeFinder");
	}

	if($Viking::Reticle)
	{
		Control::setVisible("Reticle_Container", "True");
	}

	Viking::Sense($Snipe::nSense);
}

function Snipe::Toggle()
{
 	$Snipe::Switch = !$Snipe::Switch;
 
	if($Snipe::Switch)
	{
		remoteBP(2048, "<JC><F2>Switch to laser set to: <F1> ON", 2);
  	} 
	else
	{
  		remoteBP(2048, "<JC><F2>Switch to laser set to: <F0> OFF", 2);
 	} 
}