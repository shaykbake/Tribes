////////////////////////////////////////////////////////////
// File:	Chat.cs 1.0Beta
// Author:	Runar
// Credits:	z0dd and Presto for the Idea!
// Info:	A true rip-off from z0dd, just altered the
//		menus to my taste trying to keep orig. menu.
////////////////////////////////////////////////////////////

newObject(PlayChatMenu, ChatMenu, "Root Menu:");

// Player Chat menu
setPlayChatMenu("aAnimations");
		addPlayAnim("aArg!", 3, dsgst4);
		addPlayAnim("hHi!", 12, hello);
		addPlayAnim("bBye", 12, bye);
		addPlayAnim("fYes - Salute", 4, yes);
		addPlayAnim("rRetreat", 2, retreat);
		addPlayAnim("oOver here!", 0, ovrhere);
		addPlayAnim("dMove out of way", 1, outway);
		addPlayAnim("gCome get some", 9, taunt4);
		addPlayAnim("vHow'd that feel?", 8, taunt10);
		addPlayAnim("eWoo-Hoo", 6, cheer2);
		addPlayAnim("wAll-right!", 7, cheer3);
		addPlayAnim("qYeah!", 5, cheer1);					
		addPlayAnim("zPose: Stand", 11);
		addPlayAnim("xPose: Kneel", 10);

setPlayChatMenu("zCommand Response");
		addPlayCMDResponse("aAcknowledged", 1, "Command acknowledged!", "acknow");
		addPlayCMDResponse("zObjective completed", 0, "Objective completed!", "objcomp");
		addPlayCMDResponse("iUnable to complete", 0, "Unable to complete objective!", "objxcmp");


setPlayChatMenu("dDefense");
		addPlayTeamChat("lClear the mines from our objective", "Clear the mines from our objective", clrobj);
		addPlayTeamChat("oDefend objective", "Defend objective", defobj);
		addPlayTeamChat("bDefend our base", "Defend our base", defbase);
		addPlayTeamChat("dDefending our base", "Defending our base", defend);
		addPlayTeamChat("gGo on the defensive!", "Go on the defensive!", godef);
		addPlayTeamChat("hHit the deck!", "Hit the deck!", hitdeck);
 		addPlayTeamChat("iIncoming enemies", "Incoming enemies!", incom2);
		addPlayTeamChat("cIs base clear?", "Is our base clear?", isbsclr);
		addPlayTeamChat("tOur base has been Taken", "Our Base has been taken!", basetkn);		 										
		addPlayTeamChat("sOur base is secure", "Our Base is secure.", bsclr2);
		addPlayTeamChat("mOur Objective is mined!", "Our Objective is mined!", mineobj);
		addPlayTeamChat("rRepair objective", "Repair objective", repobj);
		addPlayTeamChat("vHit the deck, incoming mortars", "Hit the deck, incoming mortars!", hitdeck);
		addPlayTeamChat("eThe enemy is attacking our base", "The enemy is attacking our base", basundr);
		addPlayTeamChat("nWe need more defense", "We need more defense", needdef);							
		addPlayTeamChat("aWe're being attacked", "We are being attacked", basatt);

setPlayChatMenu("fFlag");
		addPlayTeamChat("bOur flag is not in the base", "Our flag is not in the base!", flgtkn1);
		addPlayTeamChat("cClear the mines from our flag", "Clear the mines from our flag!", clrflg);
		addPlayTeamChat("dMines have been cleared", "Mines have been cleared!", mineclr);
		addPlayTeamChat("eThe enemy has our flag", "The enemy has our flag!", flgtkm2);
		addPlayTeamChat("fGet the enemy flag", "Get the enemy flag!", geteflg);
		addPlayTeamChat("gFlagstand clear", "Flagstand/room is clear, get the enemy flag!", geteflg);
		addPlayTeamChat("hI have the enemy flag", "I have the enemy flag, cover my ass!", haveflg);	
		addPlayTeamChat("mOur flag is mined", "Our flag is mined!", flgmine);
		addPlayTeamChat("nMine the flag!", "Mine the flag!", mineflg);
		addPlayTeamChat("rReturn our flag to our base", "Return our flag to our base!", retflag);			
		addPlayTeamChat("sOur flag is secure", "Our flag is secure, waiting to return..", flaghm);
		addPlayTeamChat("tTake flag from me!", "Take the flag from me!", geteflg);			

setPlayChatMenu("yTaunts");
		addPlayChat("cCome get some!", "Come get some!", taunt4);
		addPlayChat("dDance!", "Dance!", taunt3);
		addPlayChat("hHow'd that feel?", "How'd that feel?", taunt10);
		addPlayChat("iI've had worse!", "I've had worse!", tautn11);
		addPlayChat("mMissed me!", "Missed me!", taunt2);
		addPlayChat("pYeah!", "Yeah!", cheer1);
		addPlayChat("xYou Idiot!", "You Idiot!", dsgst2);		
		addPlayChat("yYoo-Hoo!", "Yoo-Hoo!", taunt1);

setPlayChatMenu("gGlobal");
		addPlayChat("aNo problem.", "No problem.", noprob);
		addPlayChat("bBye", "Bye!", bye);
		addPlayChat("cAh, Crap!", "Ah, Crap!", color7);
		addPlayChat("dI don't know.", "I don't know.", dontkno);
		addPlayChat("eDuh!", "Duh!", dsgst1);
		addPlayChat("fWait!", "Wait!", wait1);
		addPlayChat("gWaiting..", "Waiting..", wait2);
		addPlayChat("hHi!", "Hi!", hello);
		addPlayChat("iSigh..", "Sigh..", dsgst5);
		addPlayChat("jArgh!", "Argh!", dsgst4);
		addPlayChat("kThis sucks!", "This sucks!", dsgst5);
		addPlayChat("lHey!!", "Hey!", wshoot1);
		addPlayChat("mHmmm..", "Hmmm..", color3);
		addPlayChat("nNo", "No", no);
		addPlayChat("oOops!", "Oops!", oops2);
		addPlayChat("pAll-right!", "All-right!", cheer3);
		addPlayChat("qDamnit", "Damnit!", color6);
		addPlayChat("rReady!", "Ready!", ready);
		addPlayChat("sSorry!", "Sorry!", sorry);
		addPlayChat("tThanks!", "Thanks!", thanks);
		addPlayChat("uShazbot!", "Shazbot!", color2);
		addPlayChat("wWoo-Hoo!!", "Woo-Hoo!!", cheer2);
		addPlayChat("xYou Idiot!", "You Idiot!", dsgst2);
		addPlayChat("yYes", "Yes", yes);
		addPlayChat("zDoh", "Doh!", oops1);
		
setPlayChatMenu("lLocal");
		addLocal("aAh Crap!", color7);
		addLocal("bBye", bye);
		addLocal("cCome get some", taunt4);
		addLocal("dDance!", taunt3);
		addLocal("eHelp!!", help);																			
		addLocal("hHi", hello);
		addLocal("iSigh..", dsgst5);
		addLocal("jDying..", death);
		addLocal("lHey!!", wshoot1);
		addLocal("mMissed me!", taunt2);
		addLocal("nNo", no);
		addLocal("yYes", yes);						
		addLocal("kWaiting..", wait2);
		addLocal("oOops", oops2);
		addLocal("qDamnit", color6);
		addLocal("rRetreat!", retreat);				
		addLocal("sSorry", sorry);
		addLocal("tThanks", thanks);						
		addLocal("vHow'd that feel?", taunt10);
		addLocal("xYou Idiot!", dsgst2);
		addLocal("zYoohoo", taunt1);
		addLocal("wShazbot!", color2);

setPlayChatMenu("rNeed");
		addPlayTeamChat("tCan anyone bring me some ammo?", "Can anyone bring me some ammo?", needamo);
		addPlayTeamChat("aI need an APC pickup", "I need an APC pickup", needpku);
		addPlayTeamChat("eI need an escort back to base", "I need an escort back to base", needesc);
		addPlayTeamChat("rNeed Repairs", "Need repairs", needrep);
		addPlayTeamChat("hRepair HoF", "HoF need repairs!", needrep);
		addPlayTeamChat("mMines to HoF", "HoF need more mines!", needamo);

setPlayChatMenu("vOffense");
		addPlayTeamChat("zAPC ready to go", "APC ready to go... waiting for passengers", waitpas);		
		addPlayTeamChat("aAttack!", "Attack now!", attac2);
		addPlayTeamChat("bAttack the enemy base!", "Attack the enemy base!", attbase);
		addPlayTeamChat("nAttack the enemy!", "Attack the enemy!", attenem);
		addPlayTeamChat("lAttack objective!", "Attack objective!", attobj);
		addPlayTeamChat("cCease fire, I'm going in.", "Cease fire, I'm going in!", cease);
		addPlayTeamChat("jCapture objective!", "Capture the objective!", capobj);
		addPlayTeamChat("kGet objective!", "Get objective!", getobj);								
		addPlayTeamChat("oGo on the offensive!", "Go on the offensive!", gooff);
		addPlayTeamChat("gGoing offense", "Going offense", ono);
		addPlayTeamChat("fGoing for flag", "Going for their flag.", ono);
		addPlayTeamChat("eGoing for generator", "Going for their generator", ono);
		addPlayTeamChat("mMove out!", "Move out!", moveout);
		addPlayTeamChat("sSpamming flagstand!", "Take cover, spamming enemy flagstand!", takcovr);
		addPlayTeamChat("vCover me!", "Cover my ass!", coverme);
		addPlayTeamChat("wWait for my signal to attack", "Wait for my signal to attack!", waitsig);
		addPlayTeamChat("qEnemy base raped", "Camping enemy base, bring me a sandwich!", gendes);

setPlayChatMenu("tTarget");
		addPlayTeamChat("dDestroy the enemy generator", "Destroy the enemy generator!", desgen);
		addPlayTeamChat("eEnemy generator destroyed", "Enemy generator destroyed!", gendes);
		addPlayTeamChat("tDestroy enemy turret", "Destroy enemy turret!", destur);
		addPlayTeamChat("sEnemy turret destroyed", "Enemy turret destroyed!", turdes);
		addPlayTeamChat("fFire on my target", "Fire on my target!", firetgt);
		addPlayTeamChat("nI need a target", "I need a target.", needtgt);						
		addPlayTeamChat("aTarget acquired", "Target acquired.", tgtacq);		
		addPlayTeamChat("lTarget location", "Target location.", tgtobj);
		addPlayTeamChat("oTarget out of range", "Target out of range.", tgtout);

setPlayChatMenu("eTeam");
		addPlayTeamChat("aNo Problem", "No Problem.", noprob);				
		addPlayTeamChat("bBelay order", "Belay order.", belay);
		addPlayTeamChat("cOrder cancelled", "Order cancelled!", ordcan);
		addPlayTeamChat("pProceed ahead", "Proceed ahead!", proceed);		
		addPlayTeamChat("gRegroup", "Regroup for new attack!", regroup);
		addPlayTeamChat("rReady", "Ready, I'm in position!", ready);
		addPlayTeamChat("jWait", "Wait, I'm not in position yet!", wait1);
		addPlayTeamChat("kWaiting", "Waiting..", wait2);
		addPlayTeamChat("eHelp!!", "Help, I need support NOW!", help);																			
		addPlayTeamChat("dI dont know", "I don't know", dontkno);
		addPlayTeamChat("nNo", "No", no);
		addPlayTeamChat("yYes", "Yes", yes);						
		addPlayTeamChat("sSorry", "Sorry", sorry);
		addPlayTeamChat("tThanks", "Thanks", thanks);						
		addPlayTeamChat("hHurry up with the station!", "Hurry up with the station!", hurystn);
		addPlayTeamChat("wWatch where you're shooting", "Watch where your shooting", wshoot3);
		addPlayTeamChat("xYou Idiot!", "You Idiot!", dsgst2);
