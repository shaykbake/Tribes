////////////////////////////////////////////////////////////
// File:	Waypoint.cs
// Version:	1.0
// Author:	Runar
// Credits:	|HH|Crunchy $ |HH|BigBunny who I believe
//		wrote this script originally.
// Info:	Waypoints Enemy/Friendly flagstand
//
////////////////////////////////////////////////////////////

function Viking::Waypoint(%team) 
{
	%Waypoint::Flag["3_Tyrants", 0] = "482 766"; 
	%Waypoint::Flag["3_Tyrants", 1] = "653 498"; 
	%Waypoint::Flag["Acrophobia", 0] = "697 799"; 
	%Waypoint::Flag["Acrophobia", 1] = "326 224"; 
	%Waypoint::Flag["ArcticWolf", 0] = "253 814"; 
	%Waypoint::Flag["ArcticWolf", 1] = "737 214"; 
	%Waypoint::Flag["Avalanche", 0] = "206 383"; 
	%Waypoint::Flag["Avalanche", 1] = "890 645"; 
	%Waypoint::Flag["AvalancheMkII", 0] = "879 726"; 
	%Waypoint::Flag["AvalancheMkII", 1] = "145 297"; 
	%Waypoint::Flag["Bastard_Forge", 0] = "376 296";
	%Waypoint::Flag["Bastard_Forge", 1] = "606 717";
	%Waypoint::Flag["Blastside", 0] = "654 520"; 
	%Waypoint::Flag["Blastside", 1] = "361 510"; 
	%Waypoint::Flag["Broadside", 0] = "645 520"; 
	%Waypoint::Flag["Broadside", 1] = "368 507"; 
	%Waypoint::Flag["CanyonCrusade", 0] = "805 593"; 
	%Waypoint::Flag["CanyonCrusade", 1] = "215 572"; 
	%Waypoint::Flag["CanyonCrusade_deluxe", 0] = "805 591"; 
	%Waypoint::Flag["CanyonCrusade_deluxe", 1] = "205 571"; 
	%Waypoint::Flag["CloakOfNight", 0] = "840 836"; 
	%Waypoint::Flag["CloakOfNight", 1] = "183 188";
	%Waypoint::Flag["Control", 0] = "807 751";
	%Waypoint::Flag["Control", 1] = "161 205 "; 
	%Waypoint::Flag["DangerousCrossing", 0] = "800 749"; 
	%Waypoint::Flag["DangerousCrossing", 1] = "420 286"; 
	%Waypoint::Flag["DarkAurora", 0] = "412 132"; 
	%Waypoint::Flag["DarkAurora", 1] = "629 502"; 
	%Waypoint::Flag["Death_Row", 0] = "663 74"; 
	%Waypoint::Flag["Death_Row", 1] = "303 928"; 
	%Waypoint::Flag["Deathcoaster", 0] = "323 719"; 
	%Waypoint::Flag["Deathcoaster", 1] = "305 404"; 
	%Waypoint::Flag["Desert_Of_Death", 0] = "389 196"; 
	%Waypoint::Flag["Desert_Of_Death", 1] = "371 882"; 
	%Waypoint::Flag["Domino", 0] = "255 226"; 
	%Waypoint::Flag["Domino", 1] = "768 797"; 
	%Waypoint::Flag["Duck_Rollercoaster", 0] = "487 901"; 
	%Waypoint::Flag["Duck_Rollercoaster", 1] = "382 168"; 
	%Waypoint::Flag["DusktoDawn", 0] = "889 782"; 
	%Waypoint::Flag["DusktoDawn", 1] = "141 301"; 
	%Waypoint::Flag["Emerald_Valley", 0] = "554 797"; 
	%Waypoint::Flag["Emerald_Valley", 1] = "555 141"; 
	%Waypoint::Flag["FleetCommand", 0] = "310 361"; 
	%Waypoint::Flag["FleetCommand", 1] = "789 810"; 
	%Waypoint::Flag["Hildebrand", 0] = "491 259";
	%Waypoint::Flag["Hildebrand", 1] = "443 752";
	%Waypoint::Flag["IceDagger", 0] = "222 233"; 
	%Waypoint::Flag["IceDagger", 1] = "808 786"; 
	%Waypoint::Flag["IceRidge", 0] = "599 211"; 
	%Waypoint::Flag["IceRidge", 1] = "343 787";
	%Waypoint::Base["Integration", 0] = "846 353";
	%Waypoint::Base["Integration", 1] = "226 544";
	%Waypoint::Flag["JaggedClaw", 0] = "635 250"; 
	%Waypoint::Flag["JaggedClaw", 1] = "297 756"; 
	%Waypoint::Flag["Massive_Sides", 0] = "658 532"; 
	%Waypoint::Flag["Massive_Sides", 1] = "370 464"; 
	%Waypoint::Flag["MidnightMayhem", 0] = "88 475"; 
	%Waypoint::Flag["MidnightMayhem", 1] = "915 522"; 
	%Waypoint::Flag["MidnightMayhem_deluxe", 0] = "123 510"; 
	%Waypoint::Flag["MidnightMayhem_deluxe", 1] = "885 491"; 
	%Waypoint::Flag["NightSlide", 0] = "549 817"; 
	%Waypoint::Flag["NightSlide", 1] = "514 176"; 
	%Waypoint::Flag["NorthernLights", 0] = "483 259"; 
	%Waypoint::Flag["NorthernLights", 1] = "540 764"; 
	%Waypoint::Flag["Obfuscation", 0] = "294 787"; 
	%Waypoint::Flag["Obfuscation", 1] = "729 235"; 
	%Waypoint::Flag["OlympusMons", 0] = "128 610"; 
	%Waypoint::Flag["OlympusMons", 1] = "884 458"; 
	%Waypoint::Flag["Raindance", 0] = "576 138"; 
	%Waypoint::Flag["Raindance", 1] = "386 842"; 
	%Waypoint::Flag["Raindance2", 0] = "527 107"; 
	%Waypoint::Flag["Raindance2", 1] = "435 843"; 
	%Waypoint::Flag["Reliquary", 0] = "633 189"; 
	%Waypoint::Flag["Reliquary", 1] = "390 834"; 
	%Waypoint::Flag["Rollercoaster", 0] = "487 901"; 
	%Waypoint::Flag["Rollercoaster", 1] = "382 168"; 
	%Waypoint::Flag["Runout", 0] = "879 738";
	%Waypoint::Flag["Runout", 1] = "135 289";
	%Waypoint::Flag["Scarabrae", 0] = "524 158"; 
	%Waypoint::Flag["Scarabrae", 1] = "590 817"; 
	%Waypoint::Flag["SideWinder", 0] = "153 458"; 
	%Waypoint::Flag["SideWinder", 1] = "850 628"; 
	%Waypoint::Flag["Simoom", 0] = "233 602"; 
	%Waypoint::Flag["Simoom", 1] = "790 421"; 
	%Waypoint::Flag["Snowblind", 0] = "193 501"; 
	%Waypoint::Flag["Snowblind", 1] = "863 607"; 
	%Waypoint::Flag["Spartacus'sGauntlet", 0] = "799 643"; 
	%Waypoint::Flag["Spartacus'sGauntlet", 1] = "223 283"; 
	%Waypoint::Flag["SpinCycle", 0] = "505 852"; 
	%Waypoint::Flag["SpinCycle", 1] = "507 202";
	%Waypoint::Flag["Starfall", 0] = "556 251";
	%Waypoint::Flag["Starfall", 1] = "552 765"; 
	%Waypoint::Flag["Stonehenge", 0] = "228 243"; 
	%Waypoint::Flag["Stonehenge", 1] = "813 734"; 
	%Waypoint::Flag["Sulfurious", 0] = "582 128"; 
	%Waypoint::Flag["Sulfurious", 1] = "405 885"; 
	%Waypoint::Flag["SuperCross_2", 0] = "791 800"; 
	%Waypoint::Flag["SuperCross_2", 1] = "193 202";
	%Waypoint::Flag["Tesseract", 0] = "512 907";
	%Waypoint::Flag["Tesseract", 1] = "512 109"; 
	%Waypoint::Flag["TheDamned", 0] = "524 158"; 
	%Waypoint::Flag["TheDamned", 1] = "590 817"; 
	%Waypoint::Flag["TheLongWalk", 0] = "527 599"; 
	%Waypoint::Flag["TheLongWalk", 1] = "457 365"; 
	%Waypoint::Flag["Turbulence", 0] = "512 712"; 
	%Waypoint::Flag["Turbulence", 1] = "512 312"; 

	%x = getWord(%Waypoint::Flag[$ServerMission, %team], 0); 
	%y = getWord(%Waypoint::Flag[$ServerMission, %team], 1); 

	if (%x != -1) 
	{
		if(%team ==  Client::GetTeam(getManagerID()))
		{
			remoteEval(2048, "IssueCommand", 5, "Waypoint set to Friendly flag-stand.", %x, %y, getManagerId()); 
		}
		else
		{
			remoteEval(2048, "IssueCommand", 5, "Waypoint set to Enemy flag-stand.", %x, %y, getManagerId()); 
		}
	} 
}
