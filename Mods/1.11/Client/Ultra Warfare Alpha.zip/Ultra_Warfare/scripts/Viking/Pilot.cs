////////////////////////////////////////////////////////////
// File:	Pilot.cs 3.2
// Author:	Runar
// Credits:	
// Info:	Alters your sense for piloting
//
// History: 	3.2 Initial version
//				
////////////////////////////////////////////////////////////

$Pilot::nSense = Client::getMouseSensitivity("playMap.sae");

function Pilot::Start()
{
	Viking::Sense($Pilot::pSense);
}

function Pilot::Stop()
{
	Viking::Sense($Pilot::nSense);
}

function Pilot::Toggle()
{
 	$Viking::isPilot = !$Viking::isPilot;
 
	if($Viking::isPilot)
	{
		Pilot::Start();
		remoteBP(2048, "<JC><F2>Pilot mode is now: <F1>ON", 2);
  	} 
	else
	{
		Pilot::Stop();
  		remoteBP(2048, "<JC><F2>Pilot mode is now: <F0>OFF", 2);
 	}
}

