EditActionMap("playMap.sae");
bindcommand(keyboard0, make, "f11", TO, "Movie::Start();");  
bindcommand(keyboard0, make, "f12", TO, "Movie::Stop();");  

// Frames/Second 
$Movie::FPS = 30;

// Seconds/Frame
$Movie::SPF = 1.0/$Movie::FPS;

// Timescale.. depends on computer
$Movie::TimeScale = 1.0/($Movie::FPS+($Movie::FPS/1.5));

function Movie::Start()
{
	$Movie::simTime = getSimTime();
	$SimGame::TimeScale = $Movie::TimeScale;

	function Game::EndFrame()
	{
		%now = getSimTime();

		if((%now - $Movie::simTime) >= $Movie::SPF)
		{
			$Movie::simTime = %now;
			screenShot(mainWindow);
		}
	}
}

function Movie::Stop()
{
		function Game::EndFrame()
		{
		}

		$SimGame::TimeScale = 1.0;
}