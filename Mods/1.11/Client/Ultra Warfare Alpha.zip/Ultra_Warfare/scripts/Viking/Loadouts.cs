////////////////////////////////////////////////////////////
// File:	Loadouts.cs
// Version:	1.0
// Author:	Runar
// Credits:	
// Info:	Contains the loadouts to Favorites.cs
//
////////////////////////////////////////////////////////////
// =========================================================
// Favorite loadouts
// =========================================================
//
// You need to make your loadout's based on the ItemID
// instead of the usual "ItemName".
//
// Don't bother about the extra ammo since we're always
// buying as much as we can carry, just make the weapon
// and pack selection here.
//
// Armors
// 2 = "Light Armor"
// 3 = "Medium Armor"
// 4 = "Heavy Armor"
//
// weapons
// 11, "Blaster"
// 13, "Chaingun"
// 15, "Plasma Gun"
// 17, "Grenade Launcher" 
// 19, "Mortar" 
// 21, "Disc Launcher" 
// 22, "Laser Rifle" 
// 24, "ELF Gun" 
//
// Ammo
// 14, "Plasma Bolt" 
// 16, "Grenade Ammo" 
// 18, "Mortar Ammo" 
// 20, "Disc" 
// 12, "Bullet" 
//
// Backpacks
// 27, "Inventory Station" 
// 28, "Ammo Station" 
// 29, "Energy Pack" 
// 30, "Repair Pack" 
// 31, "Shield Pack" 
// 32, "Sensor Jammer Pack" 
// 33, "Motion Sensor" 
// 34, "Ammo Pack" 
// 35, "Pulse Sensor" 
// 36, "Sensor Jammer" 
// 37, "Camera" 
// 38, "Turret" 
//
// Misc
// 39, "Repair Kit" 
// 40, "Mine" 
// 41, "Grenade" 
// 23, "Targeting Laser" 
// 42, "Beacon" 
//
// Vehicles
// 5, "Scout" 
// 6, "LPC" 
// 7, "HPC" 
//
// =========================================================
// Favorite load-out arrays, edit if you need..
// =========================================================
//
$Favorite::Descr[0] = "Light: Sniper";
$Favorite::Items[0] = "2, 29, 13, 21, 22, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[1] = "Light: Capper";
$Favorite::Items[1] = "2, 29, 17, 21, 16, 20, 39";
//
$Favorite::Descr[2] = "Light: Default";
$Favorite::Items[2] = "2, 29, 13, 17, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[3] = "Light: Default w. ELF";
$Favorite::Items[3] = "2, 29, 17, 21, 24, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[4] = "Light: Repair";
$Favorite::Items[4] = "2, 30 , 13, 17, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[5] = "Medium: Inventory Station";
$Favorite::Items[5] = "3, 27, 13, 15, 17, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[6] = "Medium: Turret";
$Favorite::Items[6] = "3, 38, 13, 15, 17, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[7] = "Heavy: Defense";
$Favorite::Items[7] = "4, 31, 13, 15, 17, 18, 19, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[8] = "Heavy: Offense";
$Favorite::Items[8] = "4, 29, 13, 15, 17, 18, 19, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[9] = "Heavy: Repair";
$Favorite::Items[9] = "4, 30, 13, 15, 17, 18, 19, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[10] = "Heavy: Inventory Station";
$Favorite::Items[10] = "4, 27, 13, 15, 17, 18, 19, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
// 
$Favorite::Descr[11] = "Heavy: Ammo Station";
$Favorite::Items[11] = "4, 28, 13, 15, 17, 18, 19, 21, 12, 14, 16, 18, 20, 23, 39, 40, 41, 42";
