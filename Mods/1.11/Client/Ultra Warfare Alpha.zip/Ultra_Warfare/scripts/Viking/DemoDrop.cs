editActionmap("playmap.sae");
bindCommand(keyboard0, make, alt, "home", TO, "DD::Start();");
bindCommand(keyboard0, make, alt, "end", TO, "DD::Stop();");

function DD::Start()
{
//	say(0, "Demo Drop... BRB.~wwait1"); // Uncomment to say "Demo Drop BRB"
	schedule("DD::SetupDemo();", 3);
}

function DD::Stop()
{
//	say(0, "Stopping the Demo. BRB.~wwait1"); // Uncomment to say "Stopping the Demo BRB"
	schedule("DD::StopDemo();", 3);
}

function DD::SetupDemo() {
	$ConnectedToServer = FALSE;
	setCursor(MainWindow, "Cur_Arrow.bmp");
	disconnect();
	deleteObject(ConsoleScheduler);
	newObject(ConsoleScheduler, SimConsoleScheduler);
	cursorOn(MainWindow);
	$recordDemo = true;
	setupRecorderFile();
	connect($Server::Address);
}



function DD::StopDemo()
{
	$ConnectedToServer = FALSE;
	setCursor(MainWindow, "Cur_Arrow.bmp");
	disconnect();
	deleteObject(ConsoleScheduler);
	newObject(ConsoleScheduler, SimConsoleScheduler);
	cursorOn(MainWindow);
	$recordDemo = false;
	$recorderFileName = "";
	connect($Server::Address);
}
