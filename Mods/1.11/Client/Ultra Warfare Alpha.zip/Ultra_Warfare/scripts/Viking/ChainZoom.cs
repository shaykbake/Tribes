////////////////////////////////////////////////////////////
// File:	ChainZoom.cs
// Version:	3.2
// Author:	Runar
// Credits:	Twin who came ut with the original script.
// Info:	Zooms when using the Chain-gun
//
// History:	2.1 added sense-setting..
//
//
////////////////////////////////////////////////////////////

// Set FOV to our setting
$pref::PlayerFov = $Chain::NormFov;

// Get normal sensitivity
$Chain::nSense = Client::getMouseSensitivity("playMap.sae");

function Viking::Fire(%fire)
{
	if(%fire)
	{
		postAction(2048,IDACTION_FIRE1, -0);

		if(getMountedItem(0) == 13)	
		{
			$pref::PlayerFov = $Chain::ZoomFov;
			Viking::Sense($Chain::nSense * $Chain::Factor);
			$Chain::ChgSens = "True";
		}
	}
	else
	{
		postAction(2048,IDACTION_BREAK1, -0); 

		$pref::PlayerFov = $Chain::NormFov;

		if($Chain::ChgSens)
	 		Viking::Sense($Chain::nSense);
	}
}
