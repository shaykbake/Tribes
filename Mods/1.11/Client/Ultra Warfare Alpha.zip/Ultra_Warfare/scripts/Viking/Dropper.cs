////////////////////////////////////////////////////////////
// File:	Dropper.cs
// Version:	2.0
// Author:	Runar
// Credits:	Presto, Blaster, Writer for the idea.
// Info:	Litter-bug rip-off.
// Functions:	Dropper::Start(%item)
//			Dropper::Stop()
//			Dropper::NextItem()
//			Dropper::PrevItem()
//		
////////////////////////////////////////////////////////////

$Dropper::Current = $Dropper::Item[$Dropper::Index];	//Set current to pre-def. Index

function Dropper::Start(%item)
{
	if(!$Favorite::InStation)
	{
		remoteBP(2048, "<JC><F1>You are not at an Inventory-station!", 3);
		return;
	}

	if(%item == "") 				// Maybe use this in other scripts..
		%item = $Dropper::Current;

	if(getItemCount("Light Armor"))
		buy("Medium Armor");
 
	if(getItemCount(%item))
		drop(%item);

	buy(%item);

 	Schedule::Add("Dropper::Start(\""@ %item @ "\");", $Dropper::Delay, Dropper);
}

function Dropper::Stop()
{
	Schedule::Cancel(Dropper);

	if($Favorite::InStation)
		Favorite::Buy();
		
}

function Dropper::NextItem()
{
	$Dropper::Index++;

	if($Dropper::Index > $Dropper::Max)
        	$Dropper::Index = 0;

	$Dropper::Current = $Dropper::Item[$Dropper::Index];
	remoteBP(2048, "<JC><F2>Dropper set to drop: <F1>" @ $Dropper::Current, 5);
}

function Dropper::PrevItem()
{
	$Dropper::Index--;

	if($Dropper::Index < 0)
		$Dropper::Index = $Dropper::Max;

	$Dropper::Current = $Dropper::Item[$Dropper::Index];
	remoteBP(2048, "<JC><F2>Dropper set to drop: <F1>" @ $Dropper::Current, 5);
}
