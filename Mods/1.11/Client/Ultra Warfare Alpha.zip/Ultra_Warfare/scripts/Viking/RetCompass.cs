////////////////////////////////////////////////////////////
// File:	RetCompass.cs
// Version:	2.1
// Author:	Runar
// Credits:	
// Info:	Nifty compass on your reticle
//
////////////////////////////////////////////////////////////

// Events
Event::Attach(eventLoadPlayGui, retCompass::Create);
Event::Attach(eventExit, retCompass::Destroy);

// Creation of the object
function retCompass::Create()
{
	if($retCompass::Exist)
		return;

	// Get resolution
	%x = Viking::ScreenSize("x");
	%y = Viking::ScreenSize("y");

	%Container = newObject("RetCompass_Container", SimGui::Control, %x /2 - 32, %y / 2 - 32, 64, 64);
	%Compass = newObject("RetCompass_Compass", FearGui::CompassHud, 0, 0, 1, 1);
	addToSet("RetCompass_Container", %Compass);
	addToSet(PlayGui, %Container);

	$retCompass::Exist = "True";
}

// Delete object
function retCompass::Destroy()
{
	HUD::Destroy("RetCompass_");
	HUD::Destroy("RetCompass_");
	$retCompass::Exist = "False";
}