//==========================================================================
// Raptor Rifle
//==========================================================================
$AutoUse[Raptor] = False;
//======================================================
$InvList[Raptor] = 1;
$InvList[RaptorAmmo] = 1;
$RemoteInvList[Raptor] = 1;
$RemoteInvList[RaptorAmmo] = 1;
//==========================================================================
$DamageScale[larmor, $RaptorDamageType] = 3.0;
$DamageScale[lfemale, $RaptorDamageType] = 3.0;
$DamageScale[marmor, $RaptorDamageType] = 3.0;
$DamageScale[mfemale, $RaptorDamageType] = 3.0;
$DamageScale[harmor, $RaptorDamageType] = 3.0;

$ItemMax[larmor, Raptor] = 1;
$ItemMax[lfemale, Raptor] = 1;
$ItemMax[marmor, Raptor] = 0;
$ItemMax[mfemale, Raptor] = 0;
$ItemMax[harmor, Raptor] = 0;

$ItemMax[larmor, RaptorAmmo] = 100;
$ItemMax[lfemale, RaptorAmmo] = 100;
$ItemMax[marmor, RaptorAmmo] = 0;
$ItemMax[mfemale, RaptorAmmo] = 0;
$ItemMax[harmor, RaptorAmmo] = 0;
//==========================================================================
SoundData SoundWPNRaptor
{
   wavFileName = "wpn_raptor.wav";
   profile = Profile3dNear;
};
//==========================================================================
RocketData Raptorproj 
{
	bulletShapeName = "bullet.dts";
	explosionTag = IXSniperExp;

	collisionRadius = 0.0;
	mass = 1.0;

	damageClass = 0;
	damageValue = 7.0;
	damageType = $RaptorDamageType;
	kickBackStrength = 10.0;
	explosionRadius = 0.25;
	muzzleVelocity = 9000.0;
	terminalVelocity = 9000.0;
	acceleration = 300.0;
	totalTime = 2.0;
	liveTime = 2.0;

	lightRange = 1.0;
	lightColor = { 2, 0, 0 };
	inheritedVelocityScale = 1.0;

	trailType = 1;
	trailLength = 50;
	trailWidth = 0.45;
};


//==========================================================================
ItemData RaptorAmmo
 {
 description = "Raptor Bullets";
 className = "Ammo";
 heading = "xAmmunition";
 shapeFile = "ammo_clip";
 shadowDetailMask = 4;
 price = 0;
 };

ItemImageData RaptorImage
 {
 shapeFile = "wpn_raptor";
 mountPoint = 0;
 weaponType = 0;
 ammoType = RaptorAmmo;
 projectileType = Raptorproj;
 accuFire = true;
 reloadTime = 0.0;
 fireTime = 0.075;
 sfxFire = SoundWPNRaptor;
 sfxActivate = SoundPickUpWeapon;
 };

ItemData Raptor
 {
 description = "Raptor Rifle";
 className = "weapon";
 shapeFile = "wpn_raptor";
 hudIcon = "rifle";
 heading = "bWeapons";
 shadowDetailMask = 4;
 imageType = RaptorImage;
 price = 0;
 showWeaponBar = true;
   //validateShape = true;
   //validateMaterials = true;
 };
//==========================================================================
//echo("Raptor Loaded");