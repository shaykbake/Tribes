=================Ultra_Warfare Alpha release==========================


//installation
extract this to your tribe directory (C:/Dynamix/tribes). there should be a folder named Ultra_Warfare that inside of your tribes folder... go inside it and goto "readme!" folder... inside you will find things needed to get you started.. use the non-dedicated for either joining servers... or to use to do self hosting... this is the one you will need if you plan on joining any warfare server.. if you don't the vols will not get loaded and thus you won't be able to join.. understand this cause this is the frequently asked question when others try to join these kinds of servers. 

please let me know of any bugs that you find... could be sounds, crashes, something out of the ordinary.

you need to know some things before attempting to play.. first off this is a still in testing.. no guarantee that you may not have some kind of issue.. no way of telling yet. 

you need to that there is a weapon named slayer that can only be bought with only one weapon in your inventory.... only because the weapon takes two slots.. once you buy it though you can fit more weapons.. the weapon also comes with two functions (thus two slots) primary is standard rockets... secondary (hit next weapon again to load it) will fire a guided rocket that you control!!! you have to crouch "x" in order to fire this weapon... you also have to be out of your sensor's range because the sensors interfere the missiles guided abilities... you are also limited two 3 missiles per team meaning only 3 are capable of being guided at a time.. this is to get rid of any issues that may occur.

also theres a flag mover armor (heavies) that can grab your own flag and relocate it... to relocate you need to get a deployable flagstand and simple walk over it with flag... simple as that... good for tactical use...

enjoy!!!! =)

for info on dedicated server check dedicated.txt

any questions or comments email me mtwur7824@hotmail.com, icq 70752450,  or aim PWA7824
