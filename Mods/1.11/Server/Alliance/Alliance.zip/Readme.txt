
  Alliance Engine

INSTALLATION
  
 1. Create a "alliance" subdirectory under your Tribes directory.
 2. Unzip the contents of this ZIP file into it.
 3. Install one of the Alliance mods.

NOTES
 
 Renegades Alliance is a reworking of server side scripts for Tribes to make it much
 easier to add and remove Weapons, Armor classes, and Deployables. 

Alazane (alazane@rkeng.com)