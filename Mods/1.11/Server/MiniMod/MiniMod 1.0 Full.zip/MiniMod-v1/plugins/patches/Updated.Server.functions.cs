// This was a MiniMod Plugin.
// This was a "functions" patch for upgrading Tribes to MiniMod v.071 compliance.
// This plugin is no longer needed, it's being handled by MiniMod main function files.
// The
$MM::Error="Notice: Latest version of Server Functions is being handled by MiniMod.Server.Function.cs file. Please remove ''Updated.Server.Functions.cs''";
