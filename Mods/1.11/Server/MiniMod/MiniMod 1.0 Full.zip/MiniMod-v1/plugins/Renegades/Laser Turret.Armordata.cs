//This is a MiniMod plugin...
//This is a modified Laser Pack from the ol' Renegades 1.2 mod. Ported and reworked by Dewy

$ItemMax[tarmor, LaserPack] = 1;
$ItemMax[larmor, LaserPack] = 1;
$ItemMax[marmor, LaserPack] = 1;
$ItemMax[harmor, LaserPack] = 1;
$ItemMax[lfemale, LaserPack] = 1;
$ItemMax[mfemale, LaserPack] = 1;
$ItemMax[sarmor, LaserPack] = 0;
$ItemMax[sfemale, LaserPack] = 0;
$ItemMax[barmor, LaserPack] = 1;
$ItemMax[darmor, LaserPack] = 1;
$ItemMax[bfemale, LaserPack] = 1;
$ItemMax[spyarmor, LaserPack] = 1;
$ItemMax[spyfemale, LaserPack] = 1;
$ItemMax[earmor, LaserPack] = 1;
$ItemMax[efemale, LaserPack] = 1;
