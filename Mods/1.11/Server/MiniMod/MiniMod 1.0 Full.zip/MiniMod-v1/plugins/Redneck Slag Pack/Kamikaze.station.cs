// List of all items available to buy from inventory station
$InvList[KamikazePack] = 1;

$RemoteInvList[KamikazePack] = 1;