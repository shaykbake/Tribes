exec("comchat.cs");
//---------------------------------------------------------------------
// Player death messages - %1 = killer's name, %2 = victim's name
//       %3 = killer's gender pronoun (his/her), %4 = victim's gender pronoun
//---------------------------------------------------------------------

$deathMsg[$KamikazeDamageType, 0]	="%2 learns to hate Kamikazes. %1 teaches a harsh lesson.";
$deathMsg[$KamikazeDamageType, 1]	="%1 died for his cause and took %2 with %3self.";
$deathMsg[$KamikazeDamageType, 2]	="%1 defines \"Kamikaze\" for %2.";
$deathMsg[$KamikazeDamageType, 3]	="%1 takes %2 to the afterlife with %3self.";