$DamageScale[Scout, $KamikazeDamageType] = 1.0;
$DamageScale[LAPC, $KamikazeDamageType] = 1.0;
$DamageScale[HAPC, $KamikazeDamageType] = 1.0;