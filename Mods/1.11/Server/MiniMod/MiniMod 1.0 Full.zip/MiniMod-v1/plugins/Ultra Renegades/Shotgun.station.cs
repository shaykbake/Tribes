// This is a MiniMod plugin
// This is the Shotgun From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

$InvList[Shotgun] = 1; 
$InvList[ShotgunShells] = 1; 
$RemoteInvList[Shotgun] = 1; 
$RemoteInvList[ShotgunShells] = 1; 
