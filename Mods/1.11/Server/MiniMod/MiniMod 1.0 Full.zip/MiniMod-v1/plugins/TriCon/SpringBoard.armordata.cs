///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, SpringPack] = 1;
$ItemMax[sarmor, SpringPack] = 1;
$ItemMax[barmor, SpringPack] = 1;
$ItemMax[harmor, SpringPack] = 1;
$ItemMax[darmor, SpringPack] = 1;
$ItemMax[earmor, SpringPack] = 1;
$ItemMax[efemale, SpringPack] = 1;
$ItemMax[lfemale, SpringPack] = 1;
$ItemMax[sfemale, SpringPack] = 1;
$ItemMax[bfemale, SpringPack] = 1;
$ItemMax[spyarmor, SpringPack] = 1;
$ItemMax[spyfemale, SpringPack] = 1;
$ItemMax[adarmor, SpringPack] = 1;
$ItemMax[sadarmor, SpringPack] = 1;
$ItemMax[parmor, SpringPack] = 0;