///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, newdoorfour] = 1;
$ItemMax[sarmor, newdoorfour] = 1;
$ItemMax[barmor, newdoorfour] = 0;
$ItemMax[harmor, newdoorfour] = 0;
$ItemMax[darmor, newdoorfour] = 0;
$ItemMax[marmor, newdoorfour] = 1;
$ItemMax[mfemale, newdoorfour] = 1;
$ItemMax[earmor, newdoorfour] = 1;
$ItemMax[efemale, newdoorfour] = 1;
$ItemMax[lfemale, newdoorfour] = 1;
$ItemMax[sfemale, newdoorfour] = 1;
$ItemMax[bfemale, newdoorfour] = 0;
$ItemMax[spyarmor, newdoorfour] = 0;
$ItemMax[spyfemale, newdoorfour] = 0;
$ItemMax[adarmor, newdoorfour] = 0;
$ItemMax[sadarmor, newdoorfour] = 0;
$ItemMax[parmor, newdoorfour] = 0;