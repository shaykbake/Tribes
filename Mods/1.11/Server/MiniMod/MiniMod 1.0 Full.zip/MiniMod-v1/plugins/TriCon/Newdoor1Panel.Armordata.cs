///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, newdoorone] = 1;
$ItemMax[sarmor, newdoorone] = 1;
$ItemMax[barmor, newdoorone] = 0;
$ItemMax[harmor, newdoorone] = 0;
$ItemMax[darmor, newdoorone] = 0;
$ItemMax[marmor, newdoorone] = 1;
$ItemMax[mfemale, newdoorone] = 1;
$ItemMax[earmor, newdoorone] = 1;
$ItemMax[efemale, newdoorone] = 1;
$ItemMax[lfemale, newdoorone] = 1;
$ItemMax[sfemale, newdoorone] = 1;
$ItemMax[bfemale, newdoorone] = 0;
$ItemMax[spyarmor, newdoorone] = 0;
$ItemMax[spyfemale, newdoorone] = 0;
$ItemMax[adarmor, newdoorone] = 0;
$ItemMax[sadarmor, newdoorone] = 0;
$ItemMax[parmor, newdoorone] = 0;