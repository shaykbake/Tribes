///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[newdoorthree] = 1;
$RemoteInvList[newdoorthree] = 1;