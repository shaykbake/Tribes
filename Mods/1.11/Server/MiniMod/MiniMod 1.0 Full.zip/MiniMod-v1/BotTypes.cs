MiniMod::MonitorFile(start, "BotTypes.cs", "AI taunts and responces for SpoonBot");


// Bot Type Functions by Wicked69 (Paul@Lathope.demon.co.uk) Started 6/11/1999.
// This code need changing to new bot format - You wanted this job!


$vcheerList[0] = "cheer1";   	// YEAH			//This sets up a list of voice comments
$vcheerList[1] = "cheer2";   	// WOO-HOO
$vcheerList[2] = "cheer3";   	// ALL RIGHT
$vcheerList[3] = "taunt1";   	// Yooo-Hooo!
$vcheerList[4] = "taunt10";    // Howd that feel?
$vcheerList[5] = "tautn11";    // I've Had worse
$vcheerList[6] = "taunt2";   	// Missed me!
$vcheerList[7] = "taunt3";   	// Dance!
$vcheerList[8] = "taunt4";   	// Come Get some
$vcheerList[9] = "taunt4";   	// Come Get some

$cheerList[0] = "Yeah, that's the ticket!";   	// YEAH			//This sets up a list of voice comments
$cheerList[1] = "Woo-hoo!! That gotta hurt!";   	// WOO-HOO
$cheerList[2] = "All right!!";   	// ALL RIGHT
$cheerList[3] = "Yooo-Hooo!";   	// Yooo-Hooo!
$cheerList[4] = "How did that feel?";    // Howd that feel?
$cheerList[5] = "I've had worse";    // I've Had worse
$cheerList[6] = "Missed me, sucker!";   	// Missed me!
$cheerList[7] = "Dance!";   	// Dance!
$cheerList[8] = "That looks like it's going to stain.";   	// Come Get some
$cheerList[9] = "Who gave you the nerve to get killed here?";   	// Come Get some
$cheerList[10] = "Geez, are you ok?";
$cheerList[11] = "Ouch, that HAD to hurt!";
$cheerList[12] = "Who da man!";
$cheerList[13] = "Yeh punk!";
$cheerList[14] = "You all banged up!";
$cheerList[15] = "Can anyone here play this game?";
$cheerList[16] = "Waiter! Come clean up this mess!";
$cheerList[17] = "Take my advice, or I'll spank you without pants";
$cheerList[18] = "Need a band-aid?";
$cheerList[19] = "Boo-Ya!!!";
$cheerList[20] = "Everyone line up single file... I'll get the laserrifle";
$cheerList[21] = "Sorry.  This is a NO BREATHING zone.  ";
$cheerList[22] = "Hey, drop to the console and type KILL.";
$cheerList[23] = "Damn, it should be illegal to suck so bad.";
$cheerList[24] = "Excuse me while I urinate on your corpse.";
$cheerList[25] = "Hey... found your spleen.";
$cheerList[26] = "Stick to Duke Nukem.";
$cheerList[27] = "That was just a sample.";
$cheerList[28] = "Nice try... A for effort.";
$cheerList[29] = "Thanks for the weapon.";
$cheerList[30] = "Just give up.";
$cheerList[31] = "How pathetic.";
$cheerList[32] = "Wow, what a shot.  I rule. ";
$cheerList[33] = "Sorry, didn't see you there. :)";
$cheerList[34] = "That's right... run... wuss....";
$cheerList[35] = "Why'd ya try to run %s?";
$cheerList[36] = "Just like a deer in headlights.";
$cheerList[37] = "Bahahaha!";
$cheerList[38] = "Man... I pity you. I really do.";
$cheerList[39] = "Yeah... you're my favorite.";
$cheerList[40] = "What do you call that shit?";
$cheerList[41] = "Learn from that.";
$cheerList[42] = "Your corpse made a fine screenshot.";
$cheerList[43] = "You weren't using that weapon anyway.";
$cheerList[44] = "Oh get up... you aint hurt!  :)";
$cheerList[45] = "Lovely chalk outline.";
$cheerList[46] = "Next time... move.";
$cheerList[47] = "Stick to observer mode.";
$cheerList[48] = "Love those death animations... you too apparently.";
$cheerList[49] = "Damn, you smell just like roast chicken.";
$cheerList[50] = "I love the sound of crunching bone. :)";
$cheerList[51] = "Burn baby burn.";
$cheerList[52] = "Dude... your skin blows.";
$cheerList[53] = "Instant karma.";
$cheerList[54] = "Does your face hurt? Well, its killin' me!";
$cheerList[55] = "Ooh, thats gotta hurt!";
$cheerList[56] = "B-b-b-b-Bad to the bone!";
$cheerList[57] = "Bull's Eye!";
$cheerList[58] = "I bet that hurt!";
$cheerList[59] = "Come meet my 2x4.";
$cheerList[60] = "Step right up to be knocked right down!";
$cheerList[61] = "He's dead, Jim!";
$cheerList[62] = "Keep the change.";
$cheerList[63] = "Oh, I'm gooood.";
$cheerList[64] = "There's no reason to act like that!";
$cheerList[65] = "Anyone got a spachula?";
$cheerList[66] = "Danger, Will Robinson, danger!";
$cheerList[67] = "Excuse me, is the circus in town?";
$cheerList[68] = "Terminated.";
$cheerList[69] = "BOOM, baby!";
$cheerList[70] = "You move like peanut butter!";
$cheerList[71] = "You gonna start playing or what?";
$cheerList[72] = "Keeping practising.";
$cheerList[73] = "Your in my house now!";
$cheerList[74] = "Ain't nobody stoppin me!";
$cheerList[75] = "Gun wounds again?";
$cheerList[76] = "Try strafing sometime.";
$cheerList[77] = "Can I be killed? I'm beginning to wonder.";
$cheerList[78] = "Next time, make me work for it.";
$cheerList[79] = "Am I a giant or did everyone else shrink?";
$cheerList[80] = "Why do you people even bother?";
$cheerList[81] = "Next time, don't bother dodging. Why prolong your agony?";
$cheerList[82] = "What happened?  >:)";
$cheerList[83] = "Mental note to self: Find server with better opponents.";
$cheerList[84] = "Christ people... try playing with a mouse. ";
$cheerList[85] = "Nobody can touch me in this level. ";
$cheerList[86] = "It *hurts* to be this kick-ass!  It *hurts*!";
$cheerList[87] = "I'm like the freaking energizer bunny over here.";
$cheerList[88] = "Why do they ALWAYS try to run??";
$cheerList[89] = "Just like cuttin' down weeds.";
$cheerList[90] = "Get the hell out of my way!";
$cheerList[91] = "Play dead... good boy.";
$cheerList[92] = "Step right up to get knocked right down!";
$cheerList[93] = "That's right, one free asskicking with every purchase.";
$cheerList[94] = "Did I get your attention?";
$cheerList[95] = "Am I evil?  Why, yes I am.";
$cheerList[96] = "Some people just don't die well.";
$cheerList[97] = "Hey look, I can chat while running full tilt!";
$cheerList[98] = "Hey, don't hate me just because you suck.";
$cheerList[99] = "BOW DOWN!";
$cheerList[100] = "He shoots... he SCORES!";
$cheerList[101] = "You should see a doctor about that.";
$cheerList[102] = "Thank you, come again.";
$cheerList[103] = "Down boy...";
$cheerList[104] = "I'm such a bastard. :)";
$cheerList[105] = "Hope you have death and dismemberment insurance.";
$cheerList[106] = "Boy, I'm gonna send this demo to Meanstryk. :)";
$cheerList[107] = "Sorry sir, but thank you for playing.";
$cheerList[108] = "Come on in... the slaughter's fine. ";
$cheerList[109] = "Hi... I'm the enemy.";
$cheerList[110] = "Making people feel bad feels SO good.";
$cheerList[111] = "Hey nice catch!";
$cheerList[112] = "Another one bites the dust.";
$cheerList[113] = "Someone had better dig a mass grave.";
$cheerList[114] = "Can't pay the bills, but damnit, this I can do.";
$cheerList[115] = "What the fuck you think YOU'RE doin'?";
$cheerList[116] = "Come share with me my hurtful thoughts. ";
$cheerList[117] = "Ha!  Somedays it really pays to be a bot.";
$cheerList[118] = "You should stick to Chess.";
$cheerList[119] = "Its frag time. Do you know where you're skill is?";
$cheerList[120] = "Walk into the light ;-)";
$cheerList[121] = "He chose...poorly.";
$cheerList[122] = "I'm immortal!...So far.";
$cheerList[123] = "Nothing can stop me now.";
$cheerList[124] = "I must be butter cause I'm on a roll!";
$cheerList[125] = "DEATH FROM ABOVE!!!";
$cheerList[126] = "I'd trash talk, but I'm too tired...*yawn*";
$cheerList[127] = "One small frag for me, one big head wound for you!";
$cheerList[128] = "All too easy.";
$cheerList[129] = "Come strong or don't come at all!";
$cheerList[130] = "Damnit! You messed my hair up!";



$vsuckList[0] = "color3";   	// Hmmm
$vsuckList[1] = "color6";   	// Dammit!
$vsuckList[2] = "color7";   	// Ahhh Crap!
$vsuckList[3] = "dsgst1";   	// Duh!
$vsuckList[4] = "dsgst2";   	// You Idiot!
$vsuckList[5] = "dsgst4";   	// AWWWWWUUUUHHH!!
$vsuckList[6] = "dsgst5";   	// <SIGH resignation of>
$vsuckList[7] = "oops1";   	// DOH! 
$vsuckList[8] = "oops2";   	// Ooops!
$vsuckList[9] = "oops2";   	// Ooops!

$suckList[0] = "Hmmm.";   	// Hmmm
$suckList[1] = "Damnit!";   	// Dammit!
$suckList[2] = "Ahhh crap!";   	// Ahhh Crap!
$suckList[3] = "Duh!";   	// Duh!
$suckList[4] = "You Idiot!";   	// You Idiot!
$suckList[5] = "AWWWWUUUUHHH!!";   	// AWWWWWUUUUHHH!!
$suckList[6] = "What should I say?";   	// <SIGH resignation of>
$suckList[7] = "Doh!";   	// DOH! 
$suckList[8] = "Ooops!";   	// Ooops!
$suckList[9] = "It's pay-back time!";   	// Ooops!
$suckList[10] = "Elvis has left the building!";
$suckList[11] = "Time to change your diaper.";
$suckList[12] = "In your face bitch... in your face.";
$suckList[13] = "Look out man, I'm back in my zone.  Watch your ass!";
$suckList[14] = "NOW who has the big gun mother-fucker?!?";
$suckList[15] = "Oh, no wonder... I had the safety on...";
$suckList[16] = "Better run. my lag is letting up. ";
$suckList[17] = "Look out, I'm just getting warmed up.";
$suckList[18] = "Looks like there's a new lawman in town, eh?";
$suckList[19] = "Okay, I have your punk-ass figured.";
$suckList[20] = "How the fuck do you like it?";
$suckList[21] = "No more Mr. Nice Guy.";
$suckList[22] = "Oh man, you've had it now.";
$suckList[23] = "Feel that?  That's my foot in your ass.";
$suckList[24] = "Anyone else hear the theme from Rocky?";
$suckList[25] = "Your time's up.";
$suckList[26] = "Okay, now I start playing for real.";
$suckList[27] = "Hurt much?";
$suckList[28] = "My how the mighty have fallen.";
$suckList[29] = "Here's where you get off.";
$suckList[30] = "This aint no petting zoo.";
$suckList[31] = "Ever hear of the golden rule?";
$suckList[32] = "Your bullying days are over.";
$suckList[33] = "Now the shoe's on the other foot.";
$suckList[34] = "Wanna try for two out of three?";
$suckList[35] = "Hah!";
$suckList[36] = "That's what I THOUGHT... loser.";
$suckList[37] = "Memento Mori.";
$suckList[38] = "The man who dies with the most toys still dies!";
$suckList[39] = "I'd give you the finger, but you shot them off.";
$suckList[40] = "Your meaty skull is beautiful to me.";
$suckList[41] = "You all saw him...he had a gun!";
$suckList[42] = "I'm not gonna kill ya. Like hell I'm not!";
$suckList[43] = "Use the Farse, puke!";
$suckList[44] = "Ah...the joy of deathmatch.";
$suckList[45] = "Where's your crown, King Nothing?";
$suckList[46] = "Chill.";
$suckList[47] = "I'm spittin' on your corpse!";
$suckList[48] = "Exit light, enter night.";
$suckList[49] = "Respect my authoritay!";
$suckList[50] = "...and now you're going to die.";







$friendlyFireList[0] = "Watch where you're shooting, pal!~wwshoot3";   // Watch where you're shooting






function BotTypes::IsCMD(%aiName)         //Checks if %aiName is a roaming bot
{
    if(String::findSubStr(%aiName, "CMD") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsRoam(%aiName)         //Checks if %aiName is a roaming bot
{
    if(String::findSubStr(%aiName, "CMD") == 0)
		return 1;

	return 0;
}


function BotTypes::IsGuard(%aiName)         //Checks if %aiName is a Guard Bot
{

    if(String::findSubStr(%aiName, "Guard") >= 0)
		return 1;

	return 0;
}


function BotTypes::IsMortar(%aiName)         //Checks if %aiName is a Mortar Bot
{

    if(String::findSubStr(%aiName, "Mortar") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsDemo(%aiName)         //Checks if %aiName is a Demo Bot
{

    if(String::findSubStr(%aiName, "Demo") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsPainter(%aiName)         //Checks if %aiName is a Painting bot
{

    if(String::findSubStr(%aiName, "Painter") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsSniper(%aiName)         //Checks if %aiName is a Sniper bot
{

    if(String::findSubStr(%aiName, "Sniper") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsMedic(%aiName)         //Checks if %aiName is a Medic bot
{

    if(String::findSubStr(%aiName, "Medic") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsMiner(%aiName)         //Checks if %aiName is a Mining bot
{

    if(String::findSubStr(%aiName, "Miner") >= 0)
		return 1;

	return 0;
}

function BotTypes::IsRecorder(%aiName)         //Checks if %aiName is a TreePoint Recorder - Testing
{

    if(String::findSubStr(%aiName, "Record") >= 0)
		return 1;

	return 0;
}

MiniMod::MonitorFile(stop, "BotTypes.cs", "AI taunts and responces for SpoonBot");
