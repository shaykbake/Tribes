Install:
Simply unzip to you Tribes dir, thats it.

To run:
Double click on MiniMod-v.06.bat


Development Notes:

If the "SCV Armor" can't deploy something (via. the TAB menu) it's because MiniMod can't find the coressponding plugin for what you want to deploy.

I'm working on porting the rest of Ideal's deployables specifically for this reason.

Other than that, holler if something is broken.

Note: With this plugin running you won't get the TAB menu options from the any other mod(s) that MiniMod is being ran with. As long as MiniMod is the last executed mod from the command line of course.

Porting of future mods depends on how successful this one with be with the public.

Thanks,
	Dewy

www.planetstarsiege.com/minimod

P.S. If you wish to disable it, just move this directory outside the main plugins directory. (MiniMod's Main dir would be fine since MiniMod only looks in the "plugins" directory for anything to load.)

Disclaimer: I refuse to take responsiblity for any thing conserning this Mod or any complications either directly or indirectly related to MiniMod or any MiniMod compatible plugins.