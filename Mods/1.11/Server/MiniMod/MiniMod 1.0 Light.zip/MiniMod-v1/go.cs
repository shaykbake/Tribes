MiniMod::MonitorFile(start, "go.cs", "Some thing for SpoonBot. (Tree Creation stuff?)");

$BotTree::Filename = "config\\BotTree2_" @ $missionName @ ".cs";
export("$BotTree::Treepoint*", $BotTree::Filename, false);

MiniMod::MonitorFile(stop, "go.cs", "Some thing for SpoonBot. (Tree Creation stuff?)");
