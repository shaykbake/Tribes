///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, newdoortwo] = 1;
$ItemMax[sarmor, newdoortwo] = 1;
$ItemMax[barmor, newdoortwo] = 0;
$ItemMax[harmor, newdoortwo] = 0;
$ItemMax[darmor, newdoortwo] = 0;
$ItemMax[marmor, newdoortwo] = 1;
$ItemMax[mfemale, newdoortwo] = 1;
$ItemMax[earmor, newdoortwo] = 1;
$ItemMax[efemale, newdoortwo] = 1;
$ItemMax[lfemale, newdoortwo] = 1;
$ItemMax[sfemale, newdoortwo] = 1;
$ItemMax[bfemale, newdoortwo] = 0;
$ItemMax[spyarmor, newdoortwo] = 0;
$ItemMax[spyfemale, newdoortwo] = 0;
$ItemMax[adarmor, newdoortwo] = 0;
$ItemMax[sadarmor, newdoortwo] = 0;
$ItemMax[parmor, newdoortwo] = 0;