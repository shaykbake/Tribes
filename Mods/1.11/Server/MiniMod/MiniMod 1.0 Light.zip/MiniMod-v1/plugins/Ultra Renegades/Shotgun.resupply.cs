// This is a MiniMod plugin
// This is the Shotgun From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

	%cnt = %cnt + AmmoStation::resupply($resupply,Shotgun,ShotgunShells,5); 
