//This is a MiniMod plugin...
//This is a modified Laser Turret from the ol' Renegades 1.2 mod. Ported and reworked by Dewy

$InvList[LaserPack] = 1;
$RemoteInvList[LaserPack] = 1;
