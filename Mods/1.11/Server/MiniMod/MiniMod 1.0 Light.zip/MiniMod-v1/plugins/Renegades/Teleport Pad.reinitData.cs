//This is a MiniMod Plugin...
//This is the Teleport Pad from the ol' Renegades1.2 mod. Ported&Modified by Dewy.

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ DeployableTeleport] = 0;
}
