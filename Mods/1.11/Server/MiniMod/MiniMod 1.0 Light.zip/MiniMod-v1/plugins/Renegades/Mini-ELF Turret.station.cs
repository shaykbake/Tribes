//This is a MiniMod plugin...
//This is a modified Laser Pack from the ol' Renegades 1.2 mod. Ported and reworked by Dewy

$InvList[ShockPack] = 1;
$RemoteInvList[ShockPack] = 1;
