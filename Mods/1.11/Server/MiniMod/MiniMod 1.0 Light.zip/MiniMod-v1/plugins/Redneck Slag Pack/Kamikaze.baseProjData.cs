# Damage Types
#
$KamikazeDamageType = 23;