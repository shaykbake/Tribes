MiniMod::MonitorFile(start, "BotTargets.cs", "AI targetting functions for SpoonBot");

function BotTargets::Init_Targets()
{
	BotFuncs::ScanObjectTree();
}

MiniMod::MonitorFile(stop, "BotTargets.cs", "AI targetting functions for SpoonBot");
