$BotTree::T_Count = "0";
$BotTree::T_Count_Calc = "0";
