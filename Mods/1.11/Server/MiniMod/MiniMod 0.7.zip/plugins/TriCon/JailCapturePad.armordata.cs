///-----------------------------------------------
/// description = "Jail Capture Pads";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, JailCapPack] = 1;
$ItemMax[sarmor, JailCapPack] = 1;
$ItemMax[barmor, JailCapPack] = 0;
$ItemMax[harmor, JailCapPack] = 0;
$ItemMax[darmor, JailCapPack] = 0;
$ItemMax[marmor, JailCapPack] = 1;
$ItemMax[mfemale, JailCapPack] = 1;
$ItemMax[earmor, JailCapPack] = 1;
$ItemMax[efemale, JailCapPack] = 1;
$ItemMax[lfemale, JailCapPack] = 1;
$ItemMax[sfemale, JailCapPack] = 1;
$ItemMax[bfemale, JailCapPack] = 0;
$ItemMax[spyarmor, JailCapPack] = 0;
$ItemMax[spyfemale, JailCapPack] = 0;
$ItemMax[adarmor, JailCapPack] = 0;
$ItemMax[sadarmor, JailCapPack] = 0;
$ItemMax[parmor, JailCapPack] = 0;