///-----------------------------------------------
/// description = "Air Base";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, airbase] = 1;
$ItemMax[sarmor, airbase] = 1;
$ItemMax[barmor, airbase] = 0;
$ItemMax[harmor, airbase] = 0;
$ItemMax[darmor, airbase] = 0;
$ItemMax[marmor, airbase] = 1;
$ItemMax[mfemale, airbase] = 1;
$ItemMax[earmor, airbase] = 1;
$ItemMax[efemale, airbase] = 1;
$ItemMax[lfemale, airbase] = 1;
$ItemMax[sfemale, airbase] = 1;
$ItemMax[bfemale, airbase] = 0;
$ItemMax[spyarmor, airbase] = 0;
$ItemMax[spyfemale, airbase] = 0;
$ItemMax[adarmor, airbase] = 0;
$ItemMax[sadarmor, airbase] = 0;
$ItemMax[parmor, airbase] = 0;