///-----------------------------------------------
/// Description - "Blast Wall";
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, BlastWall] = 1;
$ItemMax[sarmor, BlastWall] = 1;
$ItemMax[barmor, BlastWall] = 0;
$ItemMax[harmor, BlastWall] = 0;
$ItemMax[darmor, BlastWall] = 0;
$ItemMax[marmor, BlastWall] = 1;
$ItemMax[mfemale, BlastWall] = 1;
$ItemMax[earmor, BlastWall] = 1;
$ItemMax[efemale, BlastWall] = 1;
$ItemMax[lfemale, BlastWall] = 1;
$ItemMax[sfemale, BlastWall] = 1;
$ItemMax[bfemale, BlastWall] = 0;
$ItemMax[spyarmor, BlastWall] = 0;
$ItemMax[spyfemale, BlastWall] = 0;
$ItemMax[adarmor, BlastWall] = 0;
$ItemMax[sadarmor, BlastWall] = 0;
$ItemMax[parmor, BlastWall] = 0;