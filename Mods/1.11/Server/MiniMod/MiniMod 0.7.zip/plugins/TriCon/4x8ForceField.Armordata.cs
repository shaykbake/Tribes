///-----------------------------------------------
/// description = "4x8 Force Field";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, fourbyeightForceFieldPack] = 1;
$ItemMax[sarmor, fourbyeightForceFieldPack] = 1;
$ItemMax[barmor, fourbyeightForceFieldPack] = 0;
$ItemMax[harmor, fourbyeightForceFieldPack] = 0;
$ItemMax[darmor, fourbyeightForceFieldPack] = 0;
$ItemMax[marmor, fourbyeightForceFieldPack] = 1;
$ItemMax[mfemale, fourbyeightForceFieldPack] = 1;
$ItemMax[earmor, fourbyeightForceFieldPack] = 1;
$ItemMax[efemale, fourbyeightForceFieldPack] = 1;
$ItemMax[lfemale, fourbyeightForceFieldPack] = 1;
$ItemMax[sfemale, fourbyeightForceFieldPack] = 1;
$ItemMax[bfemale, fourbyeightForceFieldPack] = 0;
$ItemMax[spyarmor, fourbyeightForceFieldPack] = 0;
$ItemMax[spyfemale, fourbyeightForceFieldPack] = 0;
$ItemMax[adarmor, fourbyeightForceFieldPack] = 0;
$ItemMax[sadarmor, fourbyeightForceFieldPack] = 0;
$ItemMax[parmor, fourbyeightForceFieldPack] = 0;