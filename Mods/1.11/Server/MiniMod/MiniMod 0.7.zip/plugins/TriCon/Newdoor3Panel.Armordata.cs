///-----------------------------------------------
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, newdoorthree] = 1;
$ItemMax[sarmor, newdoorthree] = 1;
$ItemMax[barmor, newdoorthree] = 0;
$ItemMax[harmor, newdoorthree] = 0;
$ItemMax[darmor, newdoorthree] = 0;
$ItemMax[marmor, newdoorthree] = 1;
$ItemMax[mfemale, newdoorthree] = 1;
$ItemMax[earmor, newdoorthree] = 1;
$ItemMax[efemale, newdoorthree] = 1;
$ItemMax[lfemale, newdoorthree] = 1;
$ItemMax[sfemale, newdoorthree] = 1;
$ItemMax[bfemale, newdoorthree] = 0;
$ItemMax[spyarmor, newdoorthree] = 0;
$ItemMax[spyfemale, newdoorthree] = 0;
$ItemMax[adarmor, newdoorthree] = 0;
$ItemMax[sadarmor, newdoorthree] = 0;
$ItemMax[parmor, newdoorthree] = 0;