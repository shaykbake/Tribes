///-----------------------------------------------
/// description = "4x17 Force Field Door";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[doorfourbyseventeenForceFieldPack] = 1;
$RemoteInvList[doorfourbyseventeenForceFieldPack] = 1;