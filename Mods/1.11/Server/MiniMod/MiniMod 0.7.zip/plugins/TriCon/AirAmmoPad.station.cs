///-----------------------------------------------
/// description = "Air Ammo Pad";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[AirAmmoPad] = 1;
$RemoteInvList[AirAmmoPad] = 1;