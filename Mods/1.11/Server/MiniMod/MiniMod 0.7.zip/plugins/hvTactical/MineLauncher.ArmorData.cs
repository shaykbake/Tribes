// This is a MiniMod Plugin.
// This plugin is the Mine Launcher from the hvTactical mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    MineLauncher.ArmorData.cs
//    MineLauncher.baseProjData.cs
//    MineLauncher.item.cs
//    MineLauncher.station.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, MineLauncher] = 0;
$ItemMax[lfemale, MineLauncher] = 0;
$ItemMax[marmor, MineLauncher] = 1;
$ItemMax[mfemale, MineLauncher] = 1;
$ItemMax[harmor, MineLauncher] = 1;

$ItemMax[sarmor, MineLauncher] = 1;
$ItemMax[sfemale, MineLauncher] = 1;
$ItemMax[spyarmor, MineLauncher] = 0;
$ItemMax[spyfemale, MineLauncher] = 0;
$ItemMax[barmor, MineLauncher] = 1;
$ItemMax[bfemale, MineLauncher] = 1;
$ItemMax[earmor, MineLauncher] = 1;
$ItemMax[efemale, MineLauncher] = 1;
$ItemMax[aarmor, MineLauncher] = 0;
$ItemMax[afemale, MineLauncher] = 0;
$ItemMax[darmor, MineLauncher] = 0;

$ItemMax[larmor, MinelAmmo] = 0;
$ItemMax[lfemale, MinelAmmo] = 0;
$ItemMax[marmor, MinelAmmo] = 6;
$ItemMax[mfemale, MinelAmmo] = 6;
$ItemMax[harmor, MinelAmmo] = 10;

$ItemMax[sarmor, MinelAmmo] = 8;
$ItemMax[sfemale, MinelAmmo] = 8;
$ItemMax[spyarmor, MinelAmmo] = 0;
$ItemMax[spyfemale, MinelAmmo] = 0;
$ItemMax[barmor, MinelAmmo] = 8;
$ItemMax[bfemale, MinelAmmo] = 8;
$ItemMax[earmor, MinelAmmo] = 12;
$ItemMax[efemale, MinelAmmo] = 12;
$ItemMax[aarmor, MinelAmmo] = 0;
$ItemMax[afemale, MinelAmmo] = 0;
$ItemMax[darmor, MinelAmmo] = 0;
