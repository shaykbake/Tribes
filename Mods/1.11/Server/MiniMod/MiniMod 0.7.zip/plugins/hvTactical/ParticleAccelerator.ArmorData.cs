// This is a MiniMod Plugin.
// This plugin is the Particle Accelerator from the hvTactical mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    ParticleAccelerator.ArmorData.cs
//    ParticleAccelerator.baseProjData.cs
//    ParticleAccelerator.item.cs
//    ParticleAccelerator.station.cs
//
// to your MiniMod/plugins directory.

//$ItemMax[larmor, ClusterBomb] = 0;
//$ItemMax[lfemale, ClusterBomb] = 0;
//$ItemMax[marmor, ClusterBomb] = 0;
//$ItemMax[mfemale, ClusterBomb] = 0;
//$ItemMax[harmor, ClusterBomb] = 1;

//$ItemMax[sarmor, ClusterBomb] = 0;
//$ItemMax[sfemale, ClusterBomb] = 0;
//$ItemMax[spyarmor, ClusterBomb] = 0;
//$ItemMax[spyfemale, ClusterBomb] = 0;
//$ItemMax[barmor, ClusterBomb] = 0;
//$ItemMax[bfemale, ClusterBomb] = 0;
//$ItemMax[earmor, ClusterBomb] = 0;
//$ItemMax[efemale, ClusterBomb] = 0;
//$ItemMax[aarmor, ClusterBomb] = 0;
//$ItemMax[afemale, ClusterBomb] = 0;
//$ItemMax[darmor, ClusterBomb] = 1;

