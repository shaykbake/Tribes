// This is a MiniMod Plugin.
// This plugin is the Particle Accelerator from the hvTactical mod.
// Ported by PeterT.

$ItemClass = 7;
$Item = ClusterBomb;
$qty = 1;

MiniMod::Build::Classes();
