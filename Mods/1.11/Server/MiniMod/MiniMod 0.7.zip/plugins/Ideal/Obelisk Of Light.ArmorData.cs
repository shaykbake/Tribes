// This is a MiniMod Plugin.
// This plugin is the "Obelisk Of Light" (And Power source) from
// the Ideal mod. Ported by Dewy.
//
// To install this plugin just...
// Add:
//
//    Obelisk Of Light.ArmorData.cs
//    Obelisk Of Light.baseProjData.cs
//    Obelisk Of Light.item.cs
//    Obelisk Of Light.Nsound.cs
//    Obelisk Of Light.reinitData.cs
//    Obelisk Of Light.staticshape.cs
//    Obelisk Of Light.station.cs
//    Obelisk Of Light.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, ObeliskPowerPack] = 0;
$ItemMax[lfemale, ObeliskPowerPack] = 0;
$ItemMax[marmor, ObeliskPowerPack] = 0;
$ItemMax[mfemale, ObeliskPowerPack] = 0;
$ItemMax[harmor, ObeliskPowerPack] = 1;
$ItemMax[sarmor, ObeliskPowerPack] = 0;
$ItemMax[sfemale, ObeliskPowerPack] = 0;
$ItemMax[spyfemale, ObeliskPowerPack] = 0;
$ItemMax[spyarmor, ObeliskPowerPack] = 0;
$ItemMax[barmor, ObeliskPowerPack] = 0;
$ItemMax[bfemale, ObeliskPowerPack] = 0;
$ItemMax[earmor, ObeliskPowerPack] = 1;
$ItemMax[efemale, ObeliskPowerPack] = 1;
$ItemMax[darmor, ObeliskPowerPack] = 1;
$ItemMax[tarmor, ObeliskPowerPack] = 0;
$ItemMax[scvarmor, ObeliskPowerPack] = 0;

$ItemMax[larmor, ObeliskPack] = 0;
$ItemMax[lfemale, ObeliskPack] = 0;
$ItemMax[marmor, ObeliskPack] = 0;
$ItemMax[mfemale, ObeliskPack] = 0;
$ItemMax[harmor, ObeliskPack] = 1;
$ItemMax[sarmor, ObeliskPack] = 0;
$ItemMax[sfemale, ObeliskPack] = 0;
$ItemMax[spyarmor, ObeliskPack] = 0;
$ItemMax[spyfemale, ObeliskPack] = 0;
$ItemMax[barmor, ObeliskPack] = 0;
$ItemMax[bfemale, ObeliskPack] = 0;
$ItemMax[earmor, ObeliskPack] = 1;
$ItemMax[efemale, ObeliskPack] = 1;
$ItemMax[darmor, ObeliskPack] = 1;
$ItemMax[tarmor, ObeliskPack] = 0;
$ItemMax[scvarmor, ObeliskPack] = 0;

