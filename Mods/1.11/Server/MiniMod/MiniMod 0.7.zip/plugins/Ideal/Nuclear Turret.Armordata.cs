// This is a MiniMod Plugin.
// This plugin is the Nuclear Turret from the Ideal mod.
// Ported by Dewy.

$DamageScale[larmor, $FlameDamageType] = 0.9;
$DamageScale[lfemale, $FlameDamageType] = 0.9;
$DamageScale[marmor, $FlameDamageType] = 1.0;
$DamageScale[mfemale, $FlameDamageType] = 1.0;
$DamageScale[harmor, $FlameDamageType] = 1.1;
$DamageScale[sarmor, $FlameDamageType] = 1.4;
$DamageScale[sfemale, $FlameDamageType] = 1.4;
$DamageScale[spyarmor, $FlameDamageType] = 1.4;
$DamageScale[spyfemale, $FlameDamageType] = 1.4;
$DamageScale[barmor, $FlameDamageType] = 1.0;
$DamageScale[bfemale, $FlameDamageType] = 1.0;
$DamageScale[earmor, $FlameDamageType] = 1.0;
$DamageScale[efemale, $FlameDamageType] = 1.0;
$DamageScale[aarmor, $FlameDamageType] = 1.0;
$DamageScale[afemale, $FlameDamageType] = 1.0;
$DamageScale[barmor, $FlameDamageType] = 1.0;
$DamageScale[bfemale, $FlameDamageType] = 1.0;
$DamageScale[darmor, $FlameDamageType] = 1.0;
$DamageScale[tarmor, $FlameDamageType] = 1.3;
$DamageScale[scvarmor, $FlameDamageType] = 1.0;


$ItemMax[larmor, NuclearTurretPack] = 0;
$ItemMax[lfemale, NuclearTurretPack] = 0;
$ItemMax[marmor, NuclearTurretPack] = 0;
$ItemMax[mfemale, NuclearTurretPack] = 0;
$ItemMax[harmor, NuclearTurretPack] = 1;
$ItemMax[sarmor, NuclearTurretPack] = 0;
$ItemMax[sfemale, NuclearTurretPack] = 0;
$ItemMax[spyarmor, NuclearTurretPack] = 0;
$ItemMax[spyfemale, NuclearTurretPack] = 0;
$ItemMax[barmor, NuclearTurretPack] = 0;
$ItemMax[bfemale, NuclearTurretPack] = 0;
$ItemMax[earmor, NuclearTurretPack] = 1;
$ItemMax[efemale, NuclearTurretPack] = 1;
$ItemMax[aarmor, NuclearTurretPack] = 0;
$ItemMax[afemale, NuclearTurretPack] = 0;
$ItemMax[darmor, NuclearTurretPack] = 0;
$ItemMax[tarmor, NuclearTurretPack] = 0;
$ItemMax[scvarmor, NuclearTurretPack] = 0;
