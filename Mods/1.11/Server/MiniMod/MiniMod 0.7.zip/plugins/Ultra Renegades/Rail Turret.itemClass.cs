// This is a MiniMod plugin
// This is the Rail Turret From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

$ItemClass = 10;
$Item = RailTurret;
$qty = 1;
MiniMod::Build::Classes();

