// This is a MiniMod Plugin.
// This plugin is the Death of Bots.
// Note: Code is based off of PeterT's Watchdog Turret plugin.
// Ported by Dewy then modified further by PeterT.

$ItemClass = 12;
$Item = DoBPack;
$qty = 1;
MiniMod::Build::Classes();

