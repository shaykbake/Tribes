// Drinkers Practice Mod Version 1.0
//
// Initial Idea from :|NS|: Cybertron (Drink|Vodka); he also helped with testing.
// Coded by :|NS|: Shihan (Drink|Kahlua) with some help from :|NS|: Ath0 (back before I knew anything)
// This mod allows you to drop beacons and teleport to them.  
// Everything is menu-driven now... and there are many features.
                        
//ChaingunBullet.bulletShapeName = "shotgunbolt.dts";
//ChaingunBullet.isVisible = True;
//ChaingunBullet.tracerLength = 130;

exec("comchat.cs");
$SensorNetworkEnabled = true;

$GuiModePlay = 1;
$GuiModeCommand = 2;
$GuiModeVictory = 3;
$GuiModeInventory = 4;
$GuiModeObjectives = 5;
$GuiModeLobby = 6;


//  Global Variables

//---------------------------------------------------------------------------------
// Energy each team is given at beginning of game
//---------------------------------------------------------------------------------
$DefaultTeamEnergy = "Infinite";

//---------------------------------------------------------------------------------
// Team Energy variables
//---------------------------------------------------------------------------------
$TeamEnergy[-1] = $DefaultTeamEnergy; 
$TeamEnergy[0]  = $DefaultTeamEnergy; 
$TeamEnergy[1]  = $DefaultTeamEnergy; 
$TeamEnergy[2]  = $DefaultTeamEnergy; 
$TeamEnergy[3]  = $DefaultTeamEnergy; 
$TeamEnergy[4]  = $DefaultTeamEnergy; 
$TeamEnergy[5]  = $DefaultTeamEnergy; 
$TeamEnergy[6]  = $DefaultTeamEnergy; 				
$TeamEnergy[7]  = $DefaultTeamEnergy; 

//---------------------------------------------------------------------------------
// Time in sec player must wait before he can throw a Grenade or Mine after leaving
//	a station.
//---------------------------------------------------------------------------------
$WaitThrowTime = 2;

//---------------------------------------------------------------------------------
// If 1 then Team Spending Ignored -- Team Energy is set to $MaxTeamEnergy every
// 	$secTeamEnergy.
//---------------------------------------------------------------------------------
$TeamEnergyCheat = 0;

//---------------------------------------------------------------------------------
// MAX amount team energy can reach
//---------------------------------------------------------------------------------
$MaxTeamEnergy = 700000;

//---------------------------------------------------------------------------------
//  Time player has to put flag in flagstand before it gets returned to its last
//  location. 
//---------------------------------------------------------------------------------
$flagToStandTime = 180;	  

//---------------------------------------------------------------------------------
// Amount to inc team energy every ($secTeamEnergy) seconds
//---------------------------------------------------------------------------------
$incTeamEnergy = 700;

//---------------------------------------------------------------------------------
// (Rate is sec's) Set how often TeamEnergy is incremented
//---------------------------------------------------------------------------------
$secTeamEnergy = 30;

//---------------------------------------------------------------------------------
// (Rate is sec's) Items respwan
//---------------------------------------------------------------------------------
$ItemRespawnTime = 30;

//---------------------------------------------------------------------------------
//Amount of Energy remote stations start out with
//---------------------------------------------------------------------------------
$RemoteAmmoEnergy = 2500; 
$RemoteInvEnergy = 3000;

//---------------------------------------------------------------------------------
// TEAM ENERGY -  Warn team when teammate has spent x amount - Warn team that 
//				  energy level is low when it reaches x amount 
//---------------------------------------------------------------------------------
$TeammateSpending = -4000;  //Set = to 0 if don't want the warning message
$WarnEnergyLow = 4000;	    //Set = to 0 if don't want the warning message

//---------------------------------------------------------------------------------
// Amount added to TeamEnergy when a player joins a team
//---------------------------------------------------------------------------------
$InitialPlayerEnergy = 5000;

//---------------------------------------------------------------------------------
// REMOTE TURRET
//---------------------------------------------------------------------------------
$MaxNumTurretsInBox = 2;     //Number of remote turrets allowed in the area
$TurretBoxMaxLength = 50;    //Define Max Length of the area
$TurretBoxMaxWidth =  50;    //Define Max Width of the area
$TurretBoxMaxHeight = 25;    //Define Max Height of the area

$TurretBoxMinLength = 10;	  //Define Min Length from another turret
$TurretBoxMinWidth =  10;	  //Define Min Width from another turret
$TurretBoxMinHeight = 10;    //Define Min Height from another turret

//---------------------------------------------------------------------------------
//	Object Types	
//---------------------------------------------------------------------------------
$SimTerrainObjectType    = 1 << 1;
$SimInteriorObjectType   = 1 << 2;
$SimPlayerObjectType     = 1 << 7;

$MineObjectType		    = 1 << 26;	
$MoveableObjectType	    = 1 << 22;
$VehicleObjectType	 	 = 1 << 29;  
$StaticObjectType			 = 1 << 23;	   
$ItemObjectType			 = 1 << 21;	  

//---------------------------------------------------------------------------------
// CHEATS
//---------------------------------------------------------------------------------
$ServerCheats = 0;
$TestCheats = 0;

//---------------------------------------------------------------------------------
//Respawn automatically after X sec's -  If 0..no respawn
//---------------------------------------------------------------------------------
$AutoRespawn = 0;

//---------------------------------------------------------------------------------
// Player death messages - %1 = killer's name, %2 = victim's name
//       %3 = killer's gender pronoun (his/her), %4 = victim's gender pronoun
//---------------------------------------------------------------------------------
$deathMsg[$LandingDamageType, 0]      = "%2 falls to %3 death.";
$deathMsg[$LandingDamageType, 1]      = "%2 forgot to tie %3 bungie cord.";
$deathMsg[$LandingDamageType, 2]      = "%2 bites the dust in a forceful manner.";
$deathMsg[$LandingDamageType, 3]      = "%2 fall down go boom.";
$deathMsg[$ImpactDamageType, 0]      = "%1 makes quite an impact on %2.";
$deathMsg[$ImpactDamageType, 1]      = "%2 becomes the victim of a fly-by from %1.";
$deathMsg[$ImpactDamageType, 2]      = "%2 leaves a nasty dent in %1's fender.";
$deathMsg[$ImpactDamageType, 3]      = "%1 says, 'Hey %2, you scratched my paint job!'";
$deathMsg[$BulletDamageType, 0]      = "%1 ventilates %2 with %3 chaingun.";
$deathMsg[$BulletDamageType, 1]      = "%1 gives %2 an overdose of lead.";
$deathMsg[$BulletDamageType, 2]      = "%1 fills %2 full of holes.";
$deathMsg[$BulletDamageType, 3]      = "%1 guns down %2.";
$deathMsg[$EnergyDamageType, 0]      = "%2 dies of turret trauma.";
$deathMsg[$EnergyDamageType, 1]      = "%2 is chewed to pieces by a turret.";
$deathMsg[$EnergyDamageType, 2]      = "%2 walks into a stream of turret fire.";
$deathMsg[$EnergyDamageType, 3]      = "%2 ends up on the wrong side of a turret.";
$deathMsg[$PlasmaDamageType, 0]      = "%2 feels the warm glow of %1's plasma.";
$deathMsg[$PlasmaDamageType, 1]      = "%1 gives %2 a white-hot plasma injection.";
$deathMsg[$PlasmaDamageType, 2]      = "%1 asks %2, 'Got plasma?'";
$deathMsg[$PlasmaDamageType, 3]      = "%1 gives %2 a plasma transfusion.";
$deathMsg[$ExplosionDamageType, 0]   = "%2 catches a Frisbee of Death thrown by %1.";
$deathMsg[$ExplosionDamageType, 1]   = "%1 blasts %2 with a well-placed disc.";
$deathMsg[$ExplosionDamageType, 2]   = "%1's spinfusor caught %2 by surprise.";
$deathMsg[$ExplosionDamageType, 3]   = "%2 falls victim to %1's Stormhammer.";
$deathMsg[$ShrapnelDamageType, 0]    = "%1 blows %2 up real good.";
$deathMsg[$ShrapnelDamageType, 1]    = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$ShrapnelDamageType, 2]    = "%1 gives %2 a fatal concussion.";
$deathMsg[$ShrapnelDamageType, 3]    = "%2 never saw it coming from %1.";
$deathMsg[$LaserDamageType, 0]       = "%1 adds %2 to %3 list of sniper victims.";
$deathMsg[$LaserDamageType, 1]       = "%1 fells %2 with a sniper shot.";
$deathMsg[$LaserDamageType, 2]       = "%2 becomes a victim of %1's laser rifle.";
$deathMsg[$LaserDamageType, 3]       = "%2 stayed in %1's crosshairs for too long.";
$deathMsg[$MortarDamageType, 0]      = "%1 mortars %2 into oblivion.";
$deathMsg[$MortarDamageType, 1]      = "%2 didn't see that last mortar from %1.";
$deathMsg[$MortarDamageType, 2]      = "%1 inflicts a mortal mortar wound on %2.";
$deathMsg[$MortarDamageType, 3]      = "%1's mortar takes out %2.";
$deathMsg[$BlasterDamageType, 0]     = "%2 gets a blast out of %1.";
$deathMsg[$BlasterDamageType, 1]     = "%2 succumbs to %1's rain of blaster fire.";
$deathMsg[$BlasterDamageType, 2]     = "%1's puny blaster shows %2 a new world of pain.";
$deathMsg[$BlasterDamageType, 3]     = "%2 meets %1's master blaster.";
$deathMsg[$ElectricityDamageType, 0] = "%2 gets zapped with %1's ELF gun.";
$deathMsg[$ElectricityDamageType, 1] = "%1 gives %2 a nasty jolt.";
$deathMsg[$ElectricityDamageType, 2] = "%2 gets a real shock out of meeting %1.";
$deathMsg[$ElectricityDamageType, 3] = "%1 short-circuits %2's systems.";
$deathMsg[$CrushDamageType, 0]		 = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 1]		 = "%2 is crushed.";
$deathMsg[$CrushDamageType, 2]		 = "%2 gets smushed flat.";
$deathMsg[$CrushDamageType, 3]		 = "%2 gets caught in the machinery.";
$deathMsg[$DebrisDamageType, 0]		 = "%2 is a victim among the wreckage.";
$deathMsg[$DebrisDamageType, 1]		 = "%2 is killed by debris.";
$deathMsg[$DebrisDamageType, 2]		 = "%2 becomes a victim of collateral damage.";
$deathMsg[$DebrisDamageType, 3]		 = "%2 got too close to the exploding stuff.";
$deathMsg[$MissileDamageType, 0]	    = "%2 takes a missile up the keister.";
$deathMsg[$MissileDamageType, 1]	    = "%2 gets shot down.";
$deathMsg[$MissileDamageType, 2]	    = "%2 gets real friendly with a rocket.";
$deathMsg[$MissileDamageType, 3]	    = "%2 feels the burn from a warhead.";
$deathMsg[$MineDamageType, 0]	       = "%1 blows %2 up real good.";
$deathMsg[$MineDamageType, 1]	       = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$MineDamageType, 2]	       = "%1 gives %2 a fatal concussion.";
$deathMsg[$MineDamageType, 3]	       = "%2 never saw it coming from %1.";

// "you just killed yourself" messages
//   %1 = player name,  %2 = player gender pronoun

$deathMsg[-2,0]						 = "%1 ends it all.";
$deathMsg[-2,1]						 = "%1 takes %2 own life.";
$deathMsg[-2,2]						 = "%1 kills %2 own dumb self.";
$deathMsg[-2,3]						 = "%1 decides to see what the afterlife is like.";

$numDeathMsgs = 4;
//---------------------------------------------------------------------------------

$spawnBuyList[0] = LightArmor;
$spawnBuyList[1] = Blaster;
$spawnBuyList[2] = Chaingun;
$spawnBuyList[3] = Disclauncher;
$spawnBuyList[4] = RepairKit;
$spawnBuyList[5] = ""; 

$teamScoreLimit = 9999;

$RDTurrets[1 @ 0] = "-350.296 650.069 35.4374";
$RDTurrets[1 @ 1] = "-337.749 649.975 35.4374";
$RDTurrets[1 @ 2] = "-348.046 623.126 25.4375";
$RDTurrets[1 @ 3] = "-340.029 623.271 25.4375";
$RDTurrets[1 @ 4] = "-338.188 654.538 15.4375";
$RDTurrets[1 @ 5] = "-349.059 654.711 15.4375";
$RDTurrets[1 @ 6] = "-308.324 502.072 27.8791";
$RDTurrets[1 @ 7] = "-328.782 501.399 29.2488";
$RDTurrets[1 @ 8] = "-328.782 501.399 29.2488";
$RDTurrets[1 @ 9] = "-335.891 527.923 22.7821";
$RDTurretMax[1] = 10;

$RDTurrets[0 @ 0] = "-248.7 -16.1888 27.9999";
$RDTurrets[0 @ 1] = "-263.188 -14.8273 27.9999";
$RDTurrets[0 @ 2] = "-251.109 123.483 47.9717";
$RDTurrets[0 @ 3] = "-342.208 121.088 28.9421";
$RDTurrets[0 @ 4] = "-259.891 12.209 18";
$RDTurrets[0 @ 5] = "-251.925 12.2482 18";
$RDTurrets[0 @ 6] = "-248.298 -17.3521 8";
$RDTurrets[0 @ 7] = "-262.488 -18.2577 8";
$RDTurrets[0 @ 8] = "-242.848 56.1071 29.774";
$RDTurrets[0 @ 9] = "-253.811 39.6843 24.0982";
$RDTurrets[0 @ 10] = "-248.46 85.8286 40.6367";
$RDTurrets[0 @ 11] = "-327.013 143.64 37.6554";
$RDTurretMax[0] = 12;

$RCTurrets[0 @ 0] = "520.306 812.515 70.4786";
$RCTurrets[0 @ 1] = "530.46 809.299 70.4786";
$RCTurrets[0 @ 2] = "549.486 803.042 72.4786";
$RCTurrets[0 @ 3] = "463.739 852.982 72.4786";
$RCTurrets[0 @ 4] = "450.435 811.192 72.4786";
$RCTurrets[0 @ 5] = "500.312 818.528 72.4786";
$RCTurrets[0 @ 6] = "410.698 869.797 72.4786";
$RCTurrets[0 @ 7] = "530.127 785.406 85.4786";
$RCTurrets[0 @ 8] = "397.307 828.222 72.4786";
$RCTurrets[0 @ 9] = "520.052 836.367 85.4786";                     
$RCTurretMax[0] = 10;

$RCTurrets[1 @ 0] = "431.254 78.338 69.7567";
$RCTurrets[1 @ 1] = "421.191 83.2742 69.7567";
$RCTurrets[1 @ 2] = "352.601 92.9221 71.7568";
$RCTurrets[1 @ 3] = "403.469 91.6551 71.7567";
$RCTurrets[1 @ 4] = "372.338 131.589 71.7568";
$RCTurrets[1 @ 5] = "448.959 68.1481 71.7567";
$RCTurrets[1 @ 6] = "303.21 117.959 71.7568";
$RCTurrets[1 @ 7] = "322.792 156.762 71.7568";
$RCTurrets[1 @ 8] = "448.448 95.2458 84.7567";
$RCTurrets[1 @ 9] = "352.072 128.341 76.7568";
$RCTurretMax[1] = 10;
              
$SBTurrets[0 @ 0] = "-463.021 -5.69096 102.291";
$SBTurrets[0 @ 1] = "-472.61 24.4632 102.291";
$SBTurrets[0 @ 2] = "-455.581 -3.20796 102.291";
$SBTurrets[0 @ 3] = "-465.173 26.9905 102.291";
$SBTurrets[0 @ 4] = "-453.467 30.4821 121.041";
$SBTurrets[0 @ 5] = "-444.102 0.399876 121.041";
$SBTurrets[0 @ 6] = "-452.17 50.934 92.6309";
$SBTurrets[0 @ 7] = "-407.987 46.5192 84.3336";
$SBTurrets[0 @ 8] = "-397.738 2.44384 67.2171";
$SBTurrets[0 @ 9] = "-428.195 2.41552 85.1413";
$SBTurretMax[0] = 10;

$SBTurrets[1 @ 0] = "143.024 102.634 112.154";
$SBTurrets[1 @ 1] = "150.913 103.088 112.154";
$SBTurrets[1 @ 2] = "141.731 134.252 112.154";
$SBTurrets[1 @ 3] = "149.44 134.817 112.154";
$SBTurrets[1 @ 4] = "131.077 102.518 130.904";
$SBTurrets[1 @ 5] = "129.644 133.374 130.904";
$SBTurrets[1 @ 6] = "94.1289 108.075 108.521";
$SBTurrets[1 @ 7] = "81.9499 121.91 105.132";
$SBTurrets[1 @ 8] = "152.505 76.674 109.081";
$SBTurrets[1 @ 9] = "120.267 135.982 99.2506";
$SBTurretMax[1] = 10;
                                               
$DCTurrets[0 @ 0] = "380.355 76.0798 118.735";
$DCTurrets[0 @ 1] = "384.145 83.1645 118.735";
$DCTurrets[0 @ 2] = "356.498 98.6492 118.735";
$DCTurrets[0 @ 3] = "352.752 91.5955 118.735";
$DCTurrets[0 @ 4] = "372.907 82.0162 137.485";
$DCTurrets[0 @ 5] = "361.777 88.2383 137.485";
$DCTurrets[0 @ 6] = "382.882 65.475 102.22";
$DCTurrets[0 @ 7] = "392.431 103.589 117.146";
$DCTurrets[0 @ 8] = "344.505 83.9492 103.543";
$DCTurrets[0 @ 9] = "360.322 117.942 123.733";
$DCTurretMax[0] = 10;
                                               
$DCTurrets[1 @ 0] = "130.818 -222.689 123.521";
$DCTurrets[1 @ 1] = "152.077 -230.263 142.271";
$DCTurrets[1 @ 2] = "141.796 -223.32 142.271";
$DCTurrets[1 @ 3] = "156.623 -241.193 123.521";
$DCTurrets[1 @ 4] = "161.044 -234.827 123.521";
$DCTurrets[1 @ 5] = "169.814 -231.012 105.759";
$DCTurrets[1 @ 6] = "146.086 -264.762 130.388";
$DCTurrets[1 @ 7] = "115.68 -220.745 121.249";
$DCTurrets[1 @ 8] = "136.283 -205.511 105.84";
$DCTurrets[1 @ 9] = "126.132 -259.618 134.28";
$DCTurretMax[1] = 10;

$IRTurrets[0 @ 0] = "135.69 -45.0873 59.6783";
$IRTurrets[0 @ 1] = "105.931 -51.9141 53.4283";
$IRTurrets[0 @ 2] = "105.57 -43.8003 53.4283";
$IRTurrets[0 @ 3] = "101.95 -22.4877 59.6783";
$IRTurrets[0 @ 4] = "104.077 -12.1075 64.9283";
$IRTurrets[0 @ 5] = "130.426 -10.0396 59.6783";
$IRTurrets[0 @ 6] = "134.155 -16.6184 59.6783";
$IRTurrets[0 @ 7] = "132.622 -53.5848 59.6783";
$IRTurrets[0 @ 8] = "183.025 -16.778 78.9723";
$IRTurrets[0 @ 9] = "62.7458 -13.0346 74.0247";
$IRTurretMax[0] = 10;

$IRTurrets[1 @ 0] = "-61.6318 406.346 72.3511";
$IRTurrets[1 @ 1] = "-58.2363 395.733 72.3511";
$IRTurrets[1 @ 2] = "-84.5821 388.154 72.3511";
$IRTurrets[1 @ 3] = "-91.0283 391.564 72.3511";
$IRTurrets[1 @ 4] = "-69.9459 426.802 66.1011";
$IRTurrets[1 @ 5] = "-100.336 422.824 72.3511";
$IRTurrets[1 @ 6] = "-72.4017 433.993 66.1011";
$IRTurrets[1 @ 7] = "-98.8808 429.146 72.3511";
$IRTurrets[1 @ 8] = "-113.625 438.45 59.6287";
$IRTurrets[1 @ 9] = "-72.2373 478.151 50.8959";
$IRTurretMax[1] = 10;

$SHTurrets[0 @ 0] = "234.29 307.625 126.054";
$SHTurrets[0 @ 1] = "235.891 287.185 125.054";
$SHTurrets[0 @ 2] = "248.923 285.547 125.054";
$SHTurrets[0 @ 3] = "251.588 289.269 95.0727";
$SHTurrets[0 @ 4] = "231.719 366.844 113.56";
$SHTurrets[0 @ 5] = "241.304 250.953 94.3565";
$SHTurrets[0 @ 6] = "172.86 305.902 103.767";
$SHTurrets[0 @ 7] = "223.411 282.114 109.522";
$SHTurrets[0 @ 8] = "305.383 299.949 73.6867";
$SHTurrets[0 @ 9] = "179.424 378.123 69.7561";
$SHTurretMax[0] = 10;
                                
$SHTurrets[1 @ 0] = "530.918 528.395 141.917";
$SHTurrets[1 @ 1] = "538.01 523.012 141.917";
$SHTurrets[1 @ 2] = "523.342 529.522 108.039";
$SHTurrets[1 @ 3] = "480.616 551.584 127.748";
$SHTurrets[1 @ 4] = "561.559 502.682 127.164";
$SHTurrets[1 @ 5] = "462.531 486.846 115.997";
$SHTurrets[1 @ 6] = "526.074 569.074 113.24";
$SHTurrets[1 @ 7] = "568.788 543.489 144.947";
$SHTurrets[1 @ 8] = "599.026 506.681 132.083";
$SHTurrets[1 @ 9] = "514.022 505.511 104.087";
$SHTurretMax[1] = 10;
                                
if ($CurrentTurretMax[0] == "")
	$CurrentTurretMax[0] = 0;                
if ($CurrentTurretMax[1] == "")
	$CurrentTurretMax[1] = 0;                
                          
$RouteWeaponMax = 8;
$RoutePackMax = 4;

$RouteArmorTxt[LightArmor] = "Light Armor";
$RouteArmorTxt[MediumArmor] = "Medium Armor";
$RouteArmorTxt[HeavyArmor] = "Heavy Armor";

$RouteWeapon[1] = "Blaster";
$RouteWeapon[2] = "Chaingun";
$RouteWeapon[3] = "Disc Launcher";
$RouteWeapon[4] = "Grenade Launcher";
$RouteWeapon[5] = "Laser Rifle";
$RouteWeapon[6] = "Plasma Gun";
$RouteWeapon[7] = "ELF Gun";
$RouteWeapon[8] = "Mortar";

$RoutePack[1] = "Energy Pack";
$RoutePack[2] = "Repair Pack";
$RoutePack[3] = "Shield Pack";
$RoutePack[4] = "Ammo Pack";

$RouteRealPack[1] = EnergyPack;
$RouteRealPack[2] = RepairPack;
$RouteRealPack[3] = ShieldPack;
$RouteRealPack[4] = AmmoPack;

$RouteRealWeapon[1] = Blaster;
$RouteRealWeapon[2] = Chaingun;
$RouteRealWeapon[3] = DiscLauncher;
$RouteRealWeapon[4] = GrenadeLauncher;
$RouteRealWeapon[5] = LaserRifle;
$RouteRealWeapon[6] = PlasmaGun;
$RouteRealWeapon[7] = EnergyRifle;
$RouteRealWeapon[8] = Mortar;

$RouteWeaponAmmo[2] = BulletAmmo;
$RouteWeaponAmmo[3] = DiscAmmo;
$RouteWeaponAmmo[4] = GrenadeAmmo;
$RouteWeaponAmmo[6] = PlasmaAmmo;
$RouteWeaponAmmo[8] = MortarAmmo;

function RouteReturnFlag(%clientId, %teamNo)
{                              
	%flag = $teamFlag[%teamNo];
	if (%flag.carrier != -1)
	{
		Client::SendMessage(%clientId, 0, "You cannot return the flag if it's being carried.");
		return;
	}
	if (%flag.atHome)
	{
		Client::SendMessage(%clientId, 0, "Duh! The flag is already at home!");
		return;
	}
	Flag::checkReturn(%flag, %flag.pickupSequence);
	//TeamMessages(0, %teamNo, "Your flag was returned to base.~wflagreturn.wav", -2, "", "The " @ getTeamName(GameBase::getTeam(%flag)) @ " flag was returned to base.~wflagreturn.wav");
	//GameBase::setPosition(%flag, %flag.originalPosition));
	//%flag.flagStand.flag = %flag;
	//%flag.atHome = true;
	//%flag.holdingTeam = %teamNo;
	//%flag.carrier = -1;
	//%flag.holder = %flag.flagStand; */
	MessageAll(0, "" @ Client::GetName(%clientId) @ " has forced the " @ getTeamName(%teamNo) @ " flag to be returned.");
	return;
}

function remoteKillBeacon(%clientId,%beaconNo)
{                                                            
	if (%beaconNo == "" || %beaconNo < 0)
		%beaconNo = 1;       
	%team = Client::getTeam(%clientId);
	%numOfBeacons = $TeamItemCount[%team @ beacon];
	if (!%beaconNo)
	{
		client::sendMessage(%clientId,0,"Your team has " @ %numOfBeacons @ " beacons set");
		return false;
	}
	if (%numOfBeacons > 0)
	{                                              
		if (%beaconNo > %numOfBeacons)
			Client::sendMessage(%clientId,0,"Your team doesn't have that many beacons");
		else
		{
			if (%team == 0)
				%numOfBeacons = %numOfBeacons + $TeamItemCount[1 @ beacon];
			else
				%numOfBeacons = %numOfBeacons + $TeamItemCount[0 @ beacon];
			%num = 0;
			%beaconCounter = 0;                  
			%beaconTeamCounter = 0;
			%notDone = true;
			while (%notDone) {
				%obj = getObjectByTargetIndex(%num);
				if (GameBase::GetDataName(%obj) == "DefaultBeacon")
				{          
					%beaconCounter++;
					if (%beaconCounter > %numOfBeacons)
						return false;
					if (GameBase::getTeam(%obj) == %team)
						%beaconTeamCounter++;
					if (%team == GameBase::GetTeam(%obj) && %beaconTeamCounter == %beaconNo)
					{                   
						GameBase::SetDamageLevel(%obj, 2);
						Client::SendMessage(%clientId, 0, "You have destroyed beacon #" @ %beaconNo @ ".");
						return;
					}
				}
				%num++;
				%obj = getObjectByTargetIndex(%num);
			}
		}
	}
	else
		Client::sendMessage(%clientId,0,"Your team has no beacons");
}                   
                                     
function ClearTurretVariables()
{                 
	$TempTurretCount = 0;
	for (%i = 0; %i < 20; %i++) {
		$Turret::TempTurret[0 @ %i] = "";
		$Turret::TempTurret[1 @ %i] = "";
	}
}

function KillTurrets(%clientId, %teamNo)
{                             
	%turretsKilled = false;
	if ($CurrentTurretMax[%teamNo] > 0)
	{
		for (%i = 1; %i <= $CurrentTurretMax[%teamNo]; %i++) {
			if ($CurrentTurrets[%teamNo @ %i] != "" && getObjectType($CurrentTurrets[%teamNo @ %i]) == "Turret")
			{                                       
				GameBase::setDamageLevel($CurrentTurrets[%teamNo @ %i],2);
			}
			$CurrentTurrets[%teamNo @ %i] = "";
		}                                             
		$CurrentTurretMax[%teamNo] = 0;
		%turretsKilled = true;
	}                              
	else
	{
		Client::SendMessage(%clientId, 0, "That team has no turrets.");
	}
	if (%turretsKilled)
		MessageAll(2,"" @ Client::GetName(%clientId) @ " has destroyed the " @ getTeamName(%teamNo) @ " turrets.");	
}
                                     
function ResetTurrets(%clientId, %teamNo)
{                                            
	%turretsReset = false;                       
	if ($CurrentTurretMax[%teamNo] > 0)
	{
		for (%i = 1; %i <= $CurrentTurretMax[%teamNo]; %i++) {
			if ($CurrentTurrets[%teamNo @ %i] != "" && getObjectType($CurrentTurrets[%teamNo @ %i]) == "Turret")
			{                                       
				GameBase::setDamageLevel($CurrentTurrets[%teamNo @ %i],2);
			}
			$CurrentTurrets[%teamNo @ %i] = "";
		}                                             
	}
	$CurrentTurretMax[%teamNo] = 0;
	if ($missionName == "Raindance")
	{               
		if ($RDTurrets[%teamNo @ 0] != "")
		{
			for (%i = 0; %i < $RDTurretMax[%teamNo]; %i++) {
				%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
				$CurrentTurrets[%teamNo @ $CurrentTurretMax[%teamNo]++] = %turret;
				addToSet("MissionCleanup", %turret);
				GameBase::setTeam(%turret,%teamNo);
				GameBase::setPosition(%turret,$RDTurrets[%teamNo @ %i]);
				GameBase::setRotation(%turret,"0 0 0");
				Gamebase::setMapName(%turret,"RMT Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%clientId));
			}
			%turretsReset = true;
		}    
	}
	if ($missionName == "Rollercoaster")
	{               
		if ($RCTurrets[%teamNo @ 0] != "")
		{
			for (%i = 0; %i < $RCTurretMax[%teamNo]; %i++) {
				%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
				$CurrentTurrets[%teamNo @ $CurrentTurretMax[%teamNo]++] = %turret;
				addToSet("MissionCleanup", %turret);
				GameBase::setTeam(%turret,%teamNo);
				GameBase::setPosition(%turret,$RCTurrets[%teamNo @ %i]);
				GameBase::setRotation(%turret,"0 0 0");
				Gamebase::setMapName(%turret,"RMT Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%clientId));
			}
			%turretsReset = true;
		}    
	}
	if ($missionName == "Snowblind")
	{               
		if ($SBTurrets[%teamNo @ 0] != "")
		{
			for (%i = 0; %i < $SBTurretMax[%teamNo]; %i++) {
				%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
				$CurrentTurrets[%teamNo @ $CurrentTurretMax[%teamNo]++] = %turret;
				addToSet("MissionCleanup", %turret);
				GameBase::setTeam(%turret,%teamNo);
				GameBase::setPosition(%turret,$SBTurrets[%teamNo @ %i]);
				GameBase::setRotation(%turret,"0 0 0");
				Gamebase::setMapName(%turret,"RMT Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%clientId));
			}
			%turretsReset = true;
		}    
	}
	if ($missionName == "DangerousCrossing")
	{               
		if ($DCTurrets[%teamNo @ 0] != "")
		{
			for (%i = 0; %i < $DCTurretMax[%teamNo]; %i++) {
				%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
				$CurrentTurrets[%teamNo @ $CurrentTurretMax[%teamNo]++] = %turret;
				addToSet("MissionCleanup", %turret);
				GameBase::setTeam(%turret,%teamNo);
				GameBase::setPosition(%turret,$DCTurrets[%teamNo @ %i]);
				GameBase::setRotation(%turret,"0 0 0");
				Gamebase::setMapName(%turret,"RMT Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%clientId));
			}
			%turretsReset = true;
		}    
	}
	if ($missionName == "IceRidge")
	{               
		if ($IRTurrets[%teamNo @ 0] != "")
		{
			for (%i = 0; %i < $IRTurretMax[%teamNo]; %i++) {
				%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
				$CurrentTurrets[%teamNo @ $CurrentTurretMax[%teamNo]++] = %turret;
				addToSet("MissionCleanup", %turret);
				GameBase::setTeam(%turret,%teamNo);
				GameBase::setPosition(%turret,$IRTurrets[%teamNo @ %i]);
				GameBase::setRotation(%turret,"0 0 0");
				Gamebase::setMapName(%turret,"RMT Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%clientId));
			}
			%turretsReset = true;
		}    
	}
	if ($missionName == "Stonehenge")
	{               
		if ($SHTurrets[%teamNo @ 0] != "")
		{
			for (%i = 0; %i < $SHTurretMax[%teamNo]; %i++) {
				%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
				$CurrentTurrets[%teamNo @ $CurrentTurretMax[%teamNo]++] = %turret;
				addToSet("MissionCleanup", %turret);
				GameBase::setTeam(%turret,%teamNo);
				GameBase::setPosition(%turret,$SHTurrets[%teamNo @ %i]);
				GameBase::setRotation(%turret,"0 0 0");
				Gamebase::setMapName(%turret,"RMT Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%clientId));
			}
			%turretsReset = true;
		}    
	}
	if (%turretsReset)
		MessageAll(2,"" @ Client::GetName(%clientId) @ " has reset the " @ getTeamName(%teamNo) @ " turrets.");
	else
		Client::SendMessage(%clientId,0,"That team has no preset turrets.");
}

function FixBase(%clientId, %teamNo)
{
	%num = 0;
	%notDone = true;
	while (%notDone)
	{
		%obj = getObjectByTargetIndex(%num);
		if (%obj == -1)
			%notDone = false;
		else
		{
			if (GameBase::getTeam(%obj) == %teamNo)
			{
				%type = GameBase::GetDataName(%obj);
				//if (%type == "AmmoStation" || %type == "InventoryStation" || %type == "PlasmaTurret" || %type == "RocketTurret" || %type == "Generator" || %type == "PulseSensor" || %type == "CommandStation" || %type == "MortarTurret" || %type == "SolarPanel" || %type == "IndoorTurret")
					GameBase::SetDamageLevel(%obj,0);
			}
		}
		%num++;
	}
	MessageAll(2,"" @ Client::GetName(%clientId) @ " has repaired the " @ getTeamName(%teamNo) @ " base.");
}

function KillBase(%clientId, %teamNo)
{
	%num = 0;
	%notDone = true;
	while (%notDone)
	{
		%obj = getObjectByTargetIndex(%num);
		if (%obj == -1)
			%notDone = false;
		else
		{
			if (GameBase::getTeam(%obj) == %teamNo)
			{
				%type = GameBase::GetDataName(%obj);
				//if (%type == "AmmoStation" || %type == "InventoryStation" || %type == "PlasmaTurret" || %type == "RocketTurret" || %type == "Generator" || %type == "PulseSensor" || %type == "CommandStation" || %type == "MortarTurret" || %type == "SolarPanel" || %type == "IndoorTurret")
				if (%type != "DefaultBeacon" && %type != "Scout" && %type != "LAPC" && %type != "HAPC" 
					&& %type != "DeployableTurret" && %type != "DeployableInvStation")
					GameBase::SetDamageLevel(%obj,2);
			}
		}
		%num++;
	}
	MessageAll(1,"" @ Client::GetName(%clientId) @ " has destroyed the " @ getTeamName(%teamNo) @ " base.");
}

function MineFlag(%clientId, %teamNo)
{                
	%flag = $teamFlag[%teamNo];
	%flagLoc = GameBase::GetPosition(%flag);
	%mine = newObject("","Mine","antipersonelMine");
	$RouteMine[%teamNo] = %mine;
	addToSet("MissionCleanup", %mine);
	GameBase::SetPosition(%mine, %flagLoc);
	MessageAll(1, "" @ Client::GetName(%clientId) @ " has mined the " @ getTeamName(%teamNo) @ " flag.");
}

function ClearMineFlag(%clientId, %teamNo)
{
	if (getObjectType($RouteMine[%teamNo]) == "Mine")
	{
		GameBase::SetDamageLevel($RouteMine[%teamNo], 2);
		MessageAll(2, "" @ Client::GetName(%clientId) @ " has cleared the mine from the " @ getTeamName(%teamNo) @ " flag.");
	}
}

function Game::menuRequest(%clientId) {
	%curItem = 0;
	Client::buildMenu(%clientId, "Options", "options", true);
	if(%clientId.selClient) {
		%sel = %clientId.selClient;
		%name = Client::getName(%sel);
		if($curVoteTopic == "" && !%clientId.isAdmin) {
			Client::addMenuItem(%clientId, %curItem++ @ "Vote to kick " @ %name, "vkick " @ %sel);
		}
		if(%clientId.isAdmin) {
			Client::addMenuItem(%clientId, %curItem++ @ "Kick " @ %name, "kick " @ %sel);
			if(%clientId.isSuperAdmin) {
				Client::addMenuItem(%clientId, %curItem++ @ "Ban " @ %name, "ban " @ %sel);
			}
			Client::addMenuItem(%clientId, %curItem++ @ "Change " @ %name @ "'s team", "fteamchange " @ %sel);
		}
		if(%clientId.muted[%sel])
			Client::addMenuItem(%clientId, %curItem++ @ "Unmute " @ %name, "unmute " @ %sel);
		else
			Client::addMenuItem(%clientId, %curItem++ @ "Mute " @ %name, "mute " @ %sel);
		if(%clientId.observerMode == "observerOrbit")
			Client::addMenuItem(%clientId, %curItem++ @ "Observe " @ %name, "observe " @ %sel);
	}
	else
	{
		if (Client::GetTeam(%clientId) != -1)
		{                                                        
			Client::addMenuItem(%clientId, %curItem++ @ "Beacon Teleports", "beaconteleports");      
			Client::addMenuItem(%clientId, %curItem++ @ "Base Options", "baseopt");
			Client::addMenuItem(%clientId, %curItem++ @ "Mine-the-Flag Options", "mineopt");
			Client::addMenuItem(%clientId, %curItem++ @ "Beacon Options", "beaconopt");
		}   
		Client::addMenuItem(%clientId, %curItem++ @ "Flag Options", "flagopt");
		Client::addMenuItem(%clientId, %curItem++ @ "Player Options", "playeropt");
		if (%clientId.isAdmin)
			Client::addMenuItem(%clientId, %curItem++ @ "Admin Options", "adminopt");
	}
	Client::addMenuItem(%clientId, %curItem++ @ "Change Teams/Observe", "changeteams");
	                                                          
	if($curVoteTopic != "" && %clientId.vote == "") {
		Client::addMenuItem(%clientId, %curItem++ @ "Vote YES to " @ $curVoteTopic, "voteYes " @ $curVoteCount);
		Client::addMenuItem(%clientId, %curItem++ @ "Vote NO to " @ $curVoteTopic, "voteNo " @ $curVoteCount);
	}                
}
                                               
function processMenuBaseOptions(%clientId, %option) {
	%opt = getWord(%option, 0);
	%cl = getWord(%option, 1);
	if (%opt == "repairbasef")
	{
		FixBase(%clientId, Client::GetTeam(%clientId));
		return;                                                         
	}
	if (%opt == "repairbasee")
	{               
		if (Client::GetTeam(%clientId) == 0)
			FixBase(%clientId, 1);
		else
			FixBase(%clientId, 0);
		return;                                                         
	}
	if (%opt == "destroybasef")
	{
		KillBase(%clientId, Client::GetTeam(%clientId));
		return;                                                         
	}
	if (%opt == "destroybasee")
	{               
		if (Client::GetTeam(%clientId) == 0)
			KillBase(%clientId, 1);
		else
			KillBase(%clientId, 0);
		return;                                                         
	}                           
	if (%opt == "resetturretsf")
	{
		ResetTurrets(%clientId, Client::GetTeam(%clientId));
		return;                                                         
	}
	if (%opt == "resetturretse")
	{               
		if (Client::GetTeam(%clientId) == 0)
			ResetTurrets(%clientId, 1);
		else
			ResetTurrets(%clientId, 0);
		return;                                                         
	}
	if (%opt == "destroyturretsf")
	{
		KillTurrets(%clientId, Client::GetTeam(%clientId));
		return;                                                         
	}
	if (%opt == "destroyturretse")
	{               
		if (Client::GetTeam(%clientId) == 0)
			KillTurrets(%clientId, 1);
		else
			KillTurrets(%clientId, 0);
		return;                                                         
	}                         	
} 

function processMenuPlayerOptions(%clientId, %option)
{
	%opt = getWord(%option, 0);
	%cl = getWord(%option, 1); 
	if (%opt == "wsetup")
	{
		StartWeaponSetup(%clientId);
		return;
	}
	if (%opt == "asetup")
	{
		StartArmorSetup(%clientId);
		return;
	}
	if (%opt == "bsetup")
	{
		StartPackSetup(%clientId);
		return;
	}	                                  
	if (%opt == "displaysetup")
	{
		DisplayPlayerSetup(%clientId);
		return;
	}
}                    

function processMenuBeaconTeleports(%clientId, %option)
{
	remoteTeleportToBeacon(%clientId, %option);
}

function processMenuKillBeacon(%clientId, %option)
{
	remoteKillBeacon(%clientId, %option);
}
        
function processMenuMineOptions(%clientId, %option)
{
	if (%option == "minef")
	{
		%team = Client::GetTeam(%clientId);
		MineFlag(%clientId, %team);
		return;
	}
	if (%option == "minee")
	{
		%team = Client::GetTeam(%clientId);
		if (%team == 0)
			MineFlag(%clientId, 1);
		else
			MineFlag(%clientId, 0);
		return;
	}
	if (%option == "clearminef")
	{
		%team = Client::GetTeam(%clientId);
		ClearMineFlag(%clientId, %team);
		return;
	}
	if (%option == "clearminee")
	{
		%team = Client::GetTeam(%clientId);
		if (%team == 0)
			ClearMineFlag(%clientId, 1);
		else
			ClearMineFlag(%clientId, 0);
		return;
	}
}
     
function processMenuBeaconOptions(%clientId, %option)
{     
	%opt = getWord(%option, 0);
	if (%opt == "killbeacons")
	{           
		Client::buildMenu(%clientId, "Destroy Beacons:", "KillBeacon", true);
		%team = Client::getTeam(%clientId);
		%numOfBeacons = $TeamItemCount[%team @ beacon];
		if (%team == 0)
			%numOfBeacons = %numOfBeacons + $TeamItemCount[1 @ beacon];
		else
			%numOfBeacons = %numOfBeacons + $TeamItemCount[0 @ beacon];
			
		%beaconCounter = 0;
		%num = 0;
		%beaconCounter = 0;                  
		%beaconTeamCounter = 0;
		%notDone = true;
		if (%numOfBeacons > 0)
		{
			while (%notDone) {
				%obj = getObjectByTargetIndex(%num);
				if (GameBase::GetDataName(%obj) == "DefaultBeacon")
				{          
					%beaconCounter++;
					if (%beaconCounter >= %numOfBeacons)
						%notDone = false;
					if (GameBase::getTeam(%obj) == %team)
					{
						%beaconTeamCounter++;
						Client::addMenuItem(%clientId, %beaconTeamCounter @ "Destroy beacon " @ %beaconTeamCounter, %beaconTeamCounter);
					}
				}
				%num++;
			}             
		}
		return;
	} 
}               

function processMenuFlagOptions(%clientId, %option)
{
	%opt = getWord(%option, 0);
	%team = getWord(%option, 1);
	
	if (%opt == "returnflag")
	{
		RouteReturnFlag(%clientId, %team);
		return;
	}
}
	
function processMenuOptions(%clientId, %option) {
	%opt = getWord(%option, 0);
	%cl = getWord(%option, 1);
	if (%opt == "beaconteleports")
	{           
		Client::buildMenu(%clientId, "Beacon Teleports:", "BeaconTeleports", true);
		%team = Client::getTeam(%clientId);
		%numOfBeacons = $TeamItemCount[%team @ beacon];
		if (%team == 0)
			%numOfBeacons = %numOfBeacons + $TeamItemCount[1 @ beacon];
		else
			%numOfBeacons = %numOfBeacons + $TeamItemCount[0 @ beacon];
			
		%beaconCounter = 0;
		%num = 0;
		%beaconCounter = 0;                  
		%beaconTeamCounter = 0;
		%notDone = true;
		if (%numOfBeacons > 0)
		{
			while (%notDone) {
				%obj = getObjectByTargetIndex(%num);
				if (GameBase::GetDataName(%obj) == "DefaultBeacon")
				{          
					%beaconCounter++;
					if (%beaconCounter >= %numOfBeacons)
						%notDone = false;
					if (GameBase::getTeam(%obj) == %team)
					{
						%beaconTeamCounter++;
						Client::addMenuItem(%clientId, %beaconTeamCounter @ "Teleport to beacon " @ %beaconTeamCounter, %beaconTeamCounter);
					}
				}
				%num++;
			}             
		}
		return;
	}
	if (%opt == "beaconopt")
	{
		%curItem = 0;
		Client::buildMenu(%clientId, "Beacon Options:", "BeaconOptions", true);
		Client::addMenuItem(%clientId, %curItem++ @ "Destroy Beacons", "killbeacons");
		return;
	}                     
	if (%opt == "flagopt")
	{
		%curItem = 0;                                                      
		Client::buildMenu(%clientId, "Flag Options:", "FlagOptions", true);
		%team = Client::GetTeam(%clientId);
		Client::addMenuItem(%clientId, %curItem++ @ "Return Your Flag.", "returnflag " @ %team);
		if (%team == 0)
			Client::addMenuItem(%clientId, %curItem++ @ "Return Enemy Flag.", "returnflag 1");
		else
			Client::addMenuItem(%clientId, %curItem++ @ "Return Enemy Flag.", "returnflag 0");
		return;
	}                     
	if (%opt == "playeropt")
	{
		%curItem = 0;                                                      
		Client::buildMenu(%clientId, "Player Options:", "PlayerOptions", true);
		Client::addMenuItem(%clientId, %curItem++ @ "Display Current Setup", "displaysetup");
		Client::addMenuItem(%clientId, %curItem++ @ "Weapon Setup", "wsetup");
		Client::addMenuItem(%clientId, %curItem++ @ "Backpack Setup", "bsetup");
		Client::addMenuItem(%clientId, %curItem++ @ "Armor Setup", "asetup");
		return;
	}                     
	if (%opt == "mineopt")
	{                                 
		%curItem = 0;                                                      
		Client::buildMenu(%clientId, "Mine-the-Flag Options:", "MineOptions", true);
		Client::addMenuItem(%clientId, %curItem++ @ "Mine Your Team's Flag", "minef");
		Client::addMenuItem(%clientId, %curItem++ @ "Mine Enemy Flag", "minee");
		Client::addMenuItem(%clientId, %curItem++ @ "Clear Mine From Your Flag", "clearminef");
		Client::addMenuItem(%clientId, %curItem++ @ "Clear Mine From Enemy Flag", "clearminee");
		return;
	}
	if (%opt == "baseopt")
	{                                 
		%curItem = 0;                                                      
		Client::buildMenu(%clientId, "Base Options:", "BaseOptions", true);
		Client::addMenuItem(%clientId, %curItem++ @ "Repair Your Base", "repairbasef");
		Client::addMenuItem(%clientId, %curItem++ @ "Repair Enemy Base", "repairbasee");
		Client::addMenuItem(%clientId, %curItem++ @ "Destroy Your Base", "destroybasef");
		Client::addMenuItem(%clientId, %curItem++ @ "Destroy Enemy Base", "destroybasee");
		Client::addMenuItem(%clientId, %curItem++ @ "Reset Your Team's Turrets", "resetturretsf");
		Client::addMenuItem(%clientId, %curItem++ @ "Reset Your Enemy's Turrets", "resetturretse");
		Client::addMenuItem(%clientId, %curItem++ @ "Destroy Your Team's Turrets", "destroyturretsf");
		Client::addMenuItem(%clientId, %curItem++ @ "Destroy Your Enemy's Turrets", "destroyturretse");
		return;
	}
	if (%opt == "weaponsetup") {
        	Client::buildMenu(%clientId, "Weapon Setup:", "weapons", true);
        	Client::addMenuItem(%clientId, "1Setup 1 (dl,cg,gl)", 1);
        	Client::addMenuItem(%clientId, "2Setup 2 (dl,pg,gl)", 2);
        	return;
        }
	if(%opt == "fteamchange") {
		%clientId.ptc = %cl;
		Client::buildMenu(%clientId, "Pick a team:", "FPickTeam", true);
		Client::addMenuItem(%clientId, "0Observer", -2);
		for(%i = 0; %i < getNumTeams(); %i = %i + 1)
			client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
	  return;
	}		
	else if(%opt == "changeteams") {
		Client::buildMenu(%clientId, "Pick a team:", "PickTeam", true);
		Client::addMenuItem(%clientId, "0Observer", -2);
		for(%i = 0; %i < getNumTeams(); %i = %i + 1)
			Client::addMenuItem(%clientId, (%i+1) @ getTeamName(%i), %i);
		return;
	}                      
	else if(%opt == "toggleduelmode")
		DuelToggleMode(%clientId);
	else if(%opt == "duel")
	{ 
		DuelInit(%clientId,%cl);
		return;
	}
	else if(%opt == "mute")
		%clientId.muted[%cl] = true;
	else if(%opt == "unmute")
		%clientId.muted[%cl] = "";
	else if(%opt == "vkick") {
		%cl.voteTarget = true;
		Admin::startVote(%clientId, "kick " @ Client::getName(%cl), "kick", %cl);
	}
	else if(%opt == "vadmin") {
		%cl.voteTarget = true;
		Admin::startVote(%clientId, "admin " @ Client::getName(%cl), "admin", %cl);
	}
	else if(%opt == "vetd")
		Admin::startVote(%clientId, "enable team damage", "etd", 0);
	else if(%opt == "vdtd")
		Admin::startVote(%clientId, "disable team damage", "dtd", 0);
	else if(%opt == "voteYes" && %cl == $curVoteCount) {
		%clientId.vote = "yes";
		centerprint(%clientId, "", 0);
	}
	else if(%opt == "voteNo" && %cl == $curVoteCount) {
		%clientId.vote = "no";
		centerprint(%clientId, "", 0);
	}                      
	else if (%opt == "adminopt")
	{   
		%curItem = 0;
		Client::buildMenu(%clientId, "Admin Options:", "AdminOptions", true);
		if (ChaingunBullet.isVisible)
			Client::addMenuItem(%clientId, %curItem++ @ "Use Normal Chaingun Bullets ", "hidebullets");
		else
			Client::addMenuItem(%clientId, %curItem++ @ "Use Visible Chaingun Bullets", "showbullets");
		if($Server::TeamDamageScale == 1.0)
         		Client::addMenuItem(%clientId, %curItem++ @ "Disable team damage", "dtd");
      		else
         		Client::addMenuItem(%clientId, %curItem++ @ "Enable team damage", "etd");
		Client::addMenuItem(%clientId, %curItem++ @ "Change mission", "cmission");  
		if($Server::TourneyMode)
	    	{
	       		Client::addMenuItem(%clientId, %curItem++ @ "Change to FFA mode", "cffa");
	       		if(!$CountdownStarted && !$matchStarted)
	       		{
	          		Client::addMenuItem(%clientId, %curItem++ @ "Start the match", "smatch");
	          	}
	    	}
	    	else
	    	{
	      		Client::addMenuItem(%clientId, %curItem++ @ "Change to Tournament mode", "ctourney");
	    	}
		Client::addMenuItem(%clientId, %curItem++ @ "Set Time Limit", "ctimelimit");
		Client::addMenuItem(%clientId, %curItem++ @ "Reset Server Defaults", "reset");
		return;
	}
	else if(%opt == "kick") {
		Client::buildMenu(%clientId, "Confirm kick:", "kaffirm", true);
		Client::addMenuItem(%clientId, "1Kick " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't kick " @ Client::getName(%cl), "no " @ %cl);
		return;
	}
	else if(%opt == "admin") {
		Client::buildMenu(%clientId, "Confirm admim:", "aaffirm", true);
		Client::addMenuItem(%clientId, "1Admin " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't admin " @ Client::getName(%cl), "no " @ %cl);
		return;
	}
	else if(%opt == "ban") {
		Client::buildMenu(%clientId, "Confirm Ban:", "baffirm", true);
		Client::addMenuItem(%clientId, "1Ban " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't ban " @ Client::getName(%cl), "no " @ %cl);
		return;
	}
	else if(%opt == "observe") {
		Observer::setTargetClient(%clientId, %cl);
		return;
	}
	Game::menuRequest(%clientId);
}
    
function processMenuAdminOptions(%clientId, %option)
{   
	%opt = getWord(%option, 0);
	if(%opt == "smatch")
		Admin::startMatch(%clientId);
	else if(%opt == "showbullets")
	{
		ChaingunBullet.bulletShapeName = "shotgunbolt.dts";
		ChaingunBullet.isVisible = True;
		ChaingunBullet.tracerLength = 130;
		CenterPrintAll("<jc><f0>" @ Client::GetName(%clientId) @ " has set chaingun bullets to now be VISIBLE.\nReconnect to see them.", 10);
	}
	else if(%opt == "hidebullets")
	{
		ChaingunBullet.bulletShapeName = "bullet.dts";
		ChaingunBullet.isVisible = False;
		ChaingunBullet.tracerLength = 30;
		CenterPrintAll("<jc><f0>" @ Client::GetName(%clientId) @ " has set chaingun bullets to now be INVISIBLE.\nReconnect to restore settings to default.", 10);
	}
	else if(%opt == "etd")
      Admin::setTeamDamageEnable(%clientId, true);
	else if(%opt == "dtd")
      Admin::setTeamDamageEnable(%clientId, false);
	else if(%opt == "vcmission" || %opt == "cmission") 
	{
		Admin::changeMissionMenu(%clientId, %opt == "cmission");
		return;
	}   
	else if(%opt == "cffa")
      Admin::setModeFFA(%clientId);
	else if(%opt == "ctourney")
      Admin::setModeTourney(%clientId);
	else if(%opt == "ctimelimit")
	{
		Client::buildMenu(%clientId, "Change Time Limit:", "ctlimit", true);
		Client::addMenuItem(%clientId, "110 Minutes", 10);
		Client::addMenuItem(%clientId, "215 Minutes", 15);
		Client::addMenuItem(%clientId, "320 Minutes", 20);
		Client::addMenuItem(%clientId, "425 Minutes", 25);
		Client::addMenuItem(%clientId, "530 Minutes", 30);
		Client::addMenuItem(%clientId, "645 Minutes", 45);
		Client::addMenuItem(%clientId, "760 Minutes", 60);
		Client::addMenuItem(%clientId, "8No Time Limit", 0);
		return;
	}
	else if(%opt == "reset")
	{
		Client::buildMenu(%clientId, "Confirm Reset:", "raffirm", true);
		Client::addMenuItem(%clientId, "1Reset", "yes");
		Client::addMenuItem(%clientId, "2Don't Reset", "no");
		return;
	}
	Game::menuRequest(%clientId);
}                              

function processMenuCTLimit(%clientId, %opt)
{
   remoteSetTimeLimit(%clientId, %opt);
}

function StartWeaponSetup(%clientId)
{                                       
	if ($RouteArmor[%clientId] == "")
		$RouteArmor[%clientId] = LightArmor;                                             
	if ($RoutePack[%clientId] == "")
		$RoutePack[%clientId] = 1;
	$RouteWeaponSetup[%clientId] = "";
	%armor = $ArmorType[Client::getGender(%clientId), $RouteArmor[%clientId]];
	Client::buildMenu(%clientId, "Weapon Setup (Choose " @ $MaxWeapons[%armor] @ "):", "weaponselect", true);
	for (%i = 1;%i <= $RouteWeaponMax;%i++) {                          
		if ((($RouteRealWeapon[%i] == Mortar && $RouteArmor[%clientId] == HeavyArmor))
		  || (($RouteRealWeapon[%i] == LaserRifle && $RouteArmor[%clientId] == LightArmor && $RoutePack[%clientId] == 1))
		  || (($RouteRealWeapon[%i] != LaserRifle && $RouteRealWeapon[%i] != Mortar)))
			Client::addMenuItem(%clientId, "" @ %i @ $RouteWeapon[%i], "" @ %i @ " 1");
	}                   
}
                                    
function StartPackSetup(%clientId)
{
	Client::buildMenu(%clientId, "Backpack Setup (Choose 1):", "packselect", true);
	for (%i = 1;%i <= $RoutePackMax;%i++) {
		Client::addMenuItem(%clientId, "" @ %i @ $RoutePack[%i], %i);
	}                   
}

function StartArmorSetup(%clientId)
{   
	Client::buildMenu(%clientId, "Armor Setup (Choose 1):", "armorselect", true);
	Client::addMenuItem(%clientId, "1Light Armor", "pickarmor1");
	Client::addMenuItem(%clientId, "2Medium Armor", "pickarmor2");
	Client::addMenuItem(%clientId, "3Heavy Armor", "pickarmor3");
	return;
}

function processMenuArmorSelect(%clientId, %option)
{                                       
	if (%option == "pickarmor1")
	{
		$RouteArmor[%clientId] = LightArmor;   
	}
	if (%option == "pickarmor2")
	{
		$RouteArmor[%clientId] = MediumArmor;  
	}
	if (%option == "pickarmor3")
		$RouteArmor[%clientId] = HeavyArmor;   
		
	$RouteWeaponSetup[%clientId] = "3 2 4";
	Client::SendMessage(%clientId, 0, "Resetting your weapon loadout due to changing armors");
	DisplayPlayerSetup(%clientId);
	return;
}

function DisplayPlayerSetup(%clientId)
{                                         
	if ($RouteArmor[%clientId] == "")
		$RouteArmor[%clientId] = LightArmor;
	%armor = $ArmorType[Client::getGender(%clientId), $RouteArmor[%clientId]];
	%tmpMsg = "<f0>Your Player Setup Is: ";
	%tmpMsg = %tmpMsg @ "\n<f0>Weapons: "; 
	if (getWord($RouteWeaponSetup[%clientId],2) == -1)
		$RouteWeaponSetup[%clientId] = "3 2 4";
	for (%x = 0; %x < $MaxWeapons[%armor]; %x++)	{
		%tmpItem = getWord($RouteWeaponSetup[%clientId], %x);
		if (%tmpItem != "")
		{
			if (%x > 0)
				%tmpMsg = %tmpMsg @ ", ";
			%tmpMsg = %tmpMsg @ $RouteWeapon[%tmpItem];
		}
	}                                                
	if ($RoutePack[%clientId] == "")
		$RoutePack[%clientId] = 1;
	%tmpMsg = %tmpMsg @ "\n<f0>Backpack: " @ $RoutePack[$RoutePack[%clientId]];
	%tmpMsg = %tmpMsg @ "\n<f0>Armor: " @ $RouteArmorTxt[$RouteArmor[%clientId]];
	bottomprint(%clientId,%tmpMsg,10);
}
	
function processMenuPackSelect(%clientId, %option)
{
	$RoutePack[%clientId] = %option;
	DisplayPlayerSetup(%clientId);
	return;
}

function processMenuWeaponSelect(%clientId, %option)
{                                           
	if ($RouteArmor[%clientId] == "")
		$RouteArmor[%clientId] = LightArmor;        
	%selection = getWord(%option, 0);
	%num = getWord(%option, 1);
	%armor = $ArmorType[Client::getGender(%clientId), $RouteArmor[%clientId]];
	%tmpNum = $MaxWeapons[%armor] - %num;
	$RouteWeaponSetup[%clientId] = $RouteWeaponSetup[%clientId] @ " " @ %selection;
	if (%tmpNum == 0)
	{
		DisplayPlayerSetup(%clientId);
		return;
	}                                                  
	%tmpTitle = "Weapon Setup (Choose " @ %tmpNum @ " more):";
	Client::buildMenu(%clientId, %tmpTitle, "weaponselect", true);
	%tmpCounter = 0;
	for (%i = 1;%i <= $RouteWeaponMax;%i++) {
		%weaponTaken = false;
		for (%x = 0; %x < %num; %x++) {
			if (getWord($RouteWeaponSetup[%clientId], %x) == %i)
				%weaponTaken = true;
		}
		if (%i != %selection && !%weaponTaken)
		{                             
			if ((($RouteRealWeapon[%i] == Mortar && $RouteArmor[%clientId] == HeavyArmor))
		  		|| (($RouteRealWeapon[%i] == LaserRifle && $RouteArmor[%clientId] == LightArmor && $RoutePack[%clientId] == 1))
		  		|| (($RouteRealWeapon[%i] != LaserRifle && $RouteRealWeapon[%i] != Mortar))) {
				%tmpCounter++;
				Client::addMenuItem(%clientId, "" @ %tmpCounter @ $RouteWeapon[%i], "" @ %i @ " " @ (%num + 1));
			}
		}
		else if (!%weaponTaken)
		{
			if (%num == 1)
				$RouteWeaponSetup[%clientId] = %i;
			else
				$RouteWeaponSetup[%clientId] = $RouteWeaponSetup[%clientId] @ " " @ %i;
			echo($RouteWeaponSetup[%clientId]);
		}
	}
}

function OutfitPlayer(%clientId)
{
	%max = getNumItems();
	for (%i = 0; %i < %max; %i = %i + 1) { 
		%item = getItemData(%i);
		%count = Player::getItemCount(%clientId,%item);
		if(%count) {
			if(%item.className != Armor) 
			{
				Player::setItemCount(%clientId, %item, 0);  
			}
		}
	}
	if ($RouteArmor[%clientId] == "")
		$RouteArmor[%clientId] = LightArmor;
		
	Player::SetArmor(%clientId, $ArmorType[Client::getGender(%clientId), $RouteArmor[%clientId]]);
	Player::SetItemCount(%clientId, $RouteArmor[%clientId], 1);
    
    if ($RouteWeaponSetup[%clientId] == "" || (getWord($RouteWeaponSetup[%clientId],0) == -1 || getWord($RouteWeaponSetup[%clientId],1) == -1 || getWord($RouteWeaponSetup[%clientId],2) == -1))
    	$RouteWeaponSetup[%clientId] = "3 2 4";
	if ($RoutePack[%clientId] == "")
		$RoutePack[%clientId] = 1;
	%packNo = $RoutePack[%clientId];
	%pack = $RouteRealPack[%packNo];
	Player::SetItemCount(%clientId,%pack,1);
	Player::UseItem(%clientId,%pack);
	%armor = Player::GetArmor(%clientId);
    for (%i = 0;%i < $MaxWeapons[Player::GetArmor(%clientId)];%i++) {
    	%weapon = getWord($RouteWeaponSetup[%clientId],%i);
    	if (%weapon != -1)
    	{
	    	%weaponAmmo = $RouteWeaponAmmo[%weapon];
	    	%realweapon = $RouteRealWeapon[%weapon];
	    	Player::SetItemCount(%clientId,%realweapon,1);
	    	if (%weaponAmmo != "")                        
	    	{
	    		if (%pack == AmmoPack && $AmmoPackMax[%weaponAmmo] != "")
	    			Player::SetItemCount(%clientId,%weaponAmmo, $ItemMax[%armor, %weaponAmmo] + $AmmoPackMax[%weaponAmmo]);
	    		else
	    			Player::SetItemCount(%clientId,%weaponAmmo, $ItemMax[%armor, %weaponAmmo]);
	    	}                                   
	    }
    }                      
    if (%pack == AmmoPack)
    {
        Player::SetItemCount(%clientId,MineAmmo,$ItemMax[%armor, MineAmmo] + $AmmoPackMax[MineAmmo]);
		Player::SetItemCount(%clientId,Grenade,$ItemMax[%armor, Grenade] + $AmmoPackMax[Grenade]);  
		Player::SetItemCount(%clientId,Beacon,$ItemMax[%armor, Beacon] + $AmmoPackMax[Beacon]);  
	}
	else
	{
		Player::SetItemCount(%clientId,MineAmmo,$ItemMax[%armor, MineAmmo]);
		Player::SetItemCount(%clientId,Grenade,$ItemMax[%armor, Grenade]);  
		Player::SetItemCount(%clientId,Beacon,$ItemMax[%armor, Beacon]);  
	}          
	Player::SetItemCount(%clientId,TargetingLaser,1);
	Player::SetItemCount(%clientId,RepairKit,1);
	Player::UseItem(%clientId,$RouteRealWeapon[getWord($RouteWeaponSetup[%clientId],0)]);
}       

function remoteTeleportToBeacon(%clientId,%beaconNo)
{                                                            
	if (%beaconNo == "" || %beaconNo < 0)
		%beaconNo = 1;       
	%team = Client::getTeam(%clientId);
	%numOfBeacons = $TeamItemCount[%team @ beacon];
	if (!%beaconNo)
	{
		client::sendMessage(%clientId,0,"Your team has " @ %numOfBeacons @ " beacons set");
		return false;
	}
	if (%numOfBeacons > 0)
	{                                              
		if (%beaconNo > %numOfBeacons)
			Client::sendMessage(%clientId,0,"Your team doesn't have that many beacons");
		else
		{
			if (%team == 0)
				%numOfBeacons = %numOfBeacons + $TeamItemCount[1 @ beacon];
			else
				%numOfBeacons = %numOfBeacons + $TeamItemCount[0 @ beacon];
			%num = 0;
			%beaconCounter = 0;                  
			%beaconTeamCounter = 0;
			%notDone = true;
			while (%notDone) {
				%obj = getObjectByTargetIndex(%num);
				if (GameBase::GetDataName(%obj) == "DefaultBeacon")
				{          
					%beaconCounter++;
					if (%beaconCounter > %numOfBeacons)
						return false;
					if (GameBase::getTeam(%obj) == %team)
						%beaconTeamCounter++;
					if (%team == GameBase::GetTeam(%obj) && %beaconTeamCounter == %beaconNo)
					{                   
						%cl = %clientId;
						//if (Player::getMountObject(%cl) != -1) {        
							
							//remoteeval(%clientId, Kill);
						//	player::kill(%clientId);
						//}
						if (%cl.observerMode == "dead")
						{
							Game::autoRespawn(%cl);
						}
						if (Player::getItemCount(%clientid,Flag) == 1) {
							%flagReturnTime2 = $flagReturnTime;
							$flagReturnTime = 0.5;
							Player::DropItem(%clientId,Flag);
							schedule("$flagReturnTime = " @ %flagReturnTime2 @ ";", 0.6);
 						}    
 						%notDone = false;
						%sPos = GameBase::getPosition(%obj);
						%posX = getWord(%sPos,0);
						%posY = getWord(%sPos,1);
						%posZ = getWord(%sPos,2);  
						%fadeTime = 3;
						if (Player::getMountObject(%cl) != -1) {                                  
							GameBase::SetPosition(Player::getMountObject(%cl),"" @ %posX @ " " @ %posY @ " " @ %posZ + 5 @ "");
							client::sendmessage(%clientId,0,"Poof! You're there dude!");
						}       
						else
						{
							GameBase::SetPosition(%clientId, "" @ %posX @ " " @ %posY @ " " @ %posZ + 1 @ "");
							Item::setVelocity(%clientId,"0 0 0");
							GameBase::setEnergy(Client::GetOwnedObject(%clientId),100);
							client::sendmessage(%clientId,0,"Poof! You're there dude!");
						}
						OutfitPlayer(%clientId);
						if (GameBase::getDamageLevel(Client::GetOwnedObject(%clientId)) > 0)
						{
							GameBase::SetDamageLevel(Client::GetOwnedObject(%clientId),0);
							Client::SendMessage(%clientId,0,"You've been fully healed!");

						}
					}
				}
				%num++;
				%obj = getObjectByTargetIndex(%num);
			}
		}
	}
	else
		Client::sendMessage(%clientId,0,"Your team has no beacons");
}                   

function remoteT(%clientId,%beaconNo,%NoWantFade)
{               
	remoteTeleportToBeacon(%clientId,%beaconNo,%NoWantFade);
}

          
function remotePlayMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModePlay);
   }
}    


function remoteCommandMode(%clientId)
{
   // can't switch to command mode while a server menu is up
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);  // force the bandwidth to be full command
		if(%clientId.observerMode != "pregame")
		   checkControlUnmount(%clientId);
		Client::setGuiMode(%clientId, $GuiModeCommand);
   }
}

function remoteInventoryMode(%clientId)
{
   if(!%clientId.guiLock && !Observer::isObserver(%clientId))
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeInventory);
   }
}

function remoteObjectivesMode(%clientId)
{
   if(!%clientId.guiLock)
   {
      remoteSCOM(%clientId, -1);
      Client::setGuiMode(%clientId, $GuiModeObjectives);
   }
}

function remoteScoresOn(%clientId)
{
   if(!%clientId.menuMode)
      Game::menuRequest(%clientId);
}

function remoteScoresOff(%clientId)
{
   Client::cancelMenu(%clientId);
}

function remoteToggleCommandMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeCommand)
		remoteCommandMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleInventoryMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeInventory)
		remoteInventoryMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function remoteToggleObjectivesMode(%clientId)
{
	if (Client::getGuiMode(%clientId) != $GuiModeObjectives)
		remoteObjectivesMode(%clientId);
	else
		remotePlayMode(%clientId);
}

function Time::getMinutes(%simTime)
{
   return floor(%simTime / 60);
}

function Time::getSeconds(%simTime)
{
   return %simTime % 60;
}

function Game::pickRandomSpawn(%team)
{
   %group = nameToID("MissionGroup/Teams/team" @ %team @ "/DropPoints/Random");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;
  	%spawnIdx = floor(getRandom() * (%count - 0.1));
  	%value = %count;
	for(%i = %spawnIdx; %i < %value; %i++) {
		%set = newObject("set",SimSet);
		%obj = Group::getObject(%group, %i);
		if(containerBoxFillSet(%set,$SimPlayerObjectType|$VehicleObjectType,GameBase::getPosition(%obj),2,2,4,0) == 0) {
			deleteObject(%set);
			return %obj;		
		}
		if(%i == %count - 1) {
			%i = -1;
			%value = %spawnIdx;
		}
		deleteObject(%set);
	}
   return false;
}

function Game::pickStartSpawn(%team)
{
   %group = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\DropPoints\\Start");
   %count = Group::objectCount(%group);
   if(!%count)
      return -1;

   %spawnIdx = $lastTeamSpawn[%team] + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   $lastTeamSpawn[%team] = %spawnIdx;
   return Group::getObject(%group, %spawnIdx);
}

function Game::pickTeamSpawn(%team, %respawn)
{
   if(%respawn)
      return Game::pickRandomSpawn(%team);
   else
   {
      %spawn = Game::pickStartSpawn(%team);
      if(%spawn == -1)
         return Game::pickRandomSpawn(%team);
      return %spawn;
   }
}

function Game::pickObserverSpawn(%client)
{
   %group = nameToID("MissionGroup\\ObserverDropPoints");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team" @ Client::getTeam(%client) @ "\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      %group = nameToID("MissionGroup\\Teams\\team0\\DropPoints\\Random");
   %count = Group::objectCount(%group);
   if(%group == -1 || !%count)
      return -1;
   %spawnIdx = %client.lastObserverSpawn + 1;
   if(%spawnIdx >= %count)
      %spawnIdx = 0;
   %client.lastObserverSpawn = %spawnIdx;
	return Group::getObject(%group, %spawnIdx);
}

function UpdateClientTimes(%time)
{
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      remoteEval(%cl, "setTime", -%time);
}

function Game::notifyMatchStart(%time)
{
   messageAll(0, "Match starts in " @ %time @ " seconds.");
   UpdateClientTimes(%time);
}

function Game::startMatch()
{                              
   $teamScoreLimit = 9999;	
   $CurrentTurretMax[0] = 0;
   $CurrentTurretMax[1] = 0;
   $matchStarted = true;
   $missionStartTime = getSimTime();
   messageAll(0, "Match started.");
	Game::resetScores();	

   %numTeams = getNumTeams();
   for(%i = 0; %i < %numTeams; %i = %i + 1) {
		if($TeamEnergy[%i] != "Infinite")
			schedule("replenishTeamEnergy(" @ %i @ ");", $secTeamEnergy);
	}

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
		if(%cl.observerMode == "pregame")
      {
         %cl.observerMode = "";
         Client::setControlObject(%cl, Client::getOwnedObject(%cl));
      }
   	Game::refreshClientScore(%cl);
	}
   Game::checkTimeLimit();
}

function Game::pickPlayerSpawn(%clientId, %respawn)
{
   return Game::pickTeamSpawn(Client::getTeam(%clientId), %respawn);
}

function Game::playerSpawn(%clientId, %respawn)
{
   if(!$ghosting)
      return false;

	Client::clearItemShopping(%clientId);
   %spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);
   if(!%respawn)
   {
      // initial drop
      bottomprint(%clientId, "<jc><f0>Mission: <f1>" @ $missionName @ "   <f0>Mission Type: <f1>" @ $Game::missionType @ "\n<f0>Press <f1>'O'<f0> for specific objectives.", 5);
   }
	if(%spawnMarker) {   
		%clientId.guiLock = "";
	 	%clientId.dead = "";
	   if(%spawnMarker == -1)
	   {
	      %spawnPos = "0 0 300";
	      %spawnRot = "0 0 0";
	   }
	   else
	   {
	      %spawnPos = GameBase::getPosition(%spawnMarker);
	      %spawnRot = GameBase::getRotation(%spawnMarker);
	   }

		if(!String::ICompare(Client::getGender(%clientId), "Male"))
	      %armor = "larmor";
	   else
	      %armor = "lfemale";

	   %pl = spawnPlayer(%armor, %spawnPos, %spawnRot);
	   echo("SPAWN: cl:" @ %clientId @ " pl:" @ %pl @ " marker:" @ %spawnMarker @ " armor:" @ %armor);
	   if(%pl != -1)
	   {
	      GameBase::setTeam(%pl, Client::getTeam(%clientId));
	      Client::setOwnedObject(%clientId, %pl);
	      Game::playerSpawned(%pl, %clientId, %armor, %respawn);
	      
	      if($matchStarted)
	         Client::setControlObject(%clientId, %pl);
	      else
	      {
	         %clientId.observerMode = "pregame";
	         Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
	         Observer::setOrbitObject(%clientId, %pl, 3, 3, 3);
	      }
	   }
      return true;
	}
	else {
		Client::sendMessage(%clientId,0,"Sorry No Respawn Positions Are Empty - Try again later ");
      return false;
	}
}

function Game::playerSpawned(%pl, %clientId, %armor)
{						  
	%clientId.spawn= 1;
	%max = getNumItems();
   	for(%i = 0; (%item = $spawnBuyList[%i]) != ""; %i++)
   	{
		buyItem(%clientId,%item);	
		if(%item.className == Weapon) 
			%clientId.spawnWeapon = %item;
	}
	%clientId.spawn= "";
	if(%clientId.spawnWeapon != "") {
		Player::useItem(%pl,%clientId.spawnWeapon);	
   		%clientId.spawnWeapon="";
	}
	Player::SetItemCount(%clientId,Beacon,3);
} 

function Game::autoRespawn(%client)
{
	if(%client.dead == 1)
		Game::playerSpawn(%client, "true");
}

function onServerGhostAlwaysDone()
{
}

function Game::initialMissionDrop(%clientId)
{
	Client::setGuiMode(%clientId, $GuiModePlay);

   if($Server::TourneyMode)
      GameBase::setTeam(%clientId, -1);
   else
   {
      if(%clientId.observerMode == "observerFly" || %clientId.observerMode == "observerOrbit")
      {
	      %clientId.observerMode = "observerOrbit";
	      %clientId.guiLock = "";
         Observer::jump(%clientId);
         return;
      }
      %numTeams = getNumTeams();
      %curTeam = Client::getTeam(%clientId);

      if(%curTeam >= %numTeams || (%curTeam == -1 && (%numTeams < 2 || $Server::AutoAssignTeams)) )
         Game::assignClientTeam(%clientId);
   }    
	Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
   %camSpawn = Game::pickObserverSpawn(%clientId);
   Observer::setFlyMode(%clientId, GameBase::getPosition(%camSpawn), 
	   GameBase::getRotation(%camSpawn), true, true);

   if(Client::getTeam(%clientId) == -1)
   {
      %clientId.observerMode = "pickingTeam";

      if($Server::TourneyMode && ($matchStarted || $matchStarting))
      {
         %clientId.observerMode = "observerFly";
         return;
      }
      else if($Server::TourneyMode)
      {
         if($Server::TeamDamageScale)
            %td = "ENABLED";
         else
            %td = "DISABLED";
         bottomprint(%clientId, "<jc><f1>Server is running in Competition Mode\nPick a team.\nTeam damage is " @ %td, 0);
      }
      Client::buildMenu(%clientId, "Pick a team:", "InitialPickTeam");
      Client::addMenuItem(%clientId, "0Observe", -2);
      Client::addMenuItem(%clientId, "1Automatic", -1);
      for(%i = 0; %i < getNumTeams(); %i = %i + 1)
         Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
      %clientId.justConnected = "";
   }
   else 
   {
      Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
      if(%clientId.justConnected)
      {
         centerprint(%clientId, $Server::JoinMOTD, 0);
         %clientId.observerMode = "justJoined";
         %clientId.justConnected = "";
      }
      else if(%clientId.observerMode == "justJoined")
      {
         centerprint(%clientId, "");
         %clientId.observerMode = "";
         Game::playerSpawn(%clientId, false);
      }
      else
         Game::playerSpawn(%clientId, false);
	}
	if($TeamEnergy[Client::getTeam(%clientId)] != "Infinite")
		$TeamEnergy[Client::getTeam(%clientId)] += $InitialPlayerEnergy;
	%clientId.teamEnergy = 0;
}

function processMenuInitialPickTeam(%clientId, %team)
{
   if($Server::TourneyMode && $matchStarted)
      %team = -2;

   if(%team == -2)
   {
      Observer::enterObserverMode(%clientId);
   }
   if(%team == -1)
   {
      Game::assignClientTeam(%clientId);
      %team = Client::getTeam(%clientId);
   }
   if(%team != -2)
   {
      GameBase::setTeam(%clientId, %team);
		if($TeamEnergy[%team] != "Infinite")
			$TeamEnergy[%team] += $InitialPlayerEnergy;
      %clientId.teamEnergy = 0;
      Client::setControlObject(%clientId, -1);
      Game::playerSpawn(%clientId, false);
   }
   if($Server::TourneyMode && !$CountdownStarted)
   {
      if(%team != -2)
      {
         bottomprint(%clientId, "<f1><jc>Press FIRE when ready.", 0);
         %clientId.notready = true;
         %clientId.notreadyCount = "";
      }
      else
      {
         bottomprint(%clientId, "", 0);
         %clientId.notready = "";
         %clientId.notreadyCount = "";
      }
   }
}

function Admin::setModeFFA(%clientId)
{
   if($Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
   {
      $Server::TeamDamageScale = 0;
      if(%clientId == -1)
         messageAll(0, "Server switched to Free-For-All Mode.");
      else
         messageAll(0, "Server switched to Free-For-All Mode by " @ Client::getName(%clientId) @ ".");

      $Server::TourneyMode = false;
      centerprintall(); // clear the messages
      if(!$matchStarted && !$countdownStarted)
      {
         if($Server::warmupTime)
            Server::Countdown($Server::warmupTime);
         else   
            Game::startMatch();
      }
   }
}

function Admin::setModeTourney(%clientId)
{
   if(!$Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
   {
      $Server::TeamDamageScale = 1;
      if(%clientId == -1)
         messageAll(0, "Server switched to Tournament Mode.");
      else
         messageAll(0, "Server switched to Tournament Mode by " @ Client::getName(%clientId) @ ".");

      $Server::TourneyMode = true;
      Server::nextMission();
   }
}

function Game::ForceTourneyMatchStart()
{
   %playerCount = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pregame")
         %playerCount++;
   }
   if(%playerCount == 0)
      return;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")   
         processMenuInitialPickTeam(%cl, -2); // throw these guys into observer
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
   }
   Server::Countdown(30);
}

function Game::CheckTourneyMatchStart()
{
   if($CountdownStarted || $matchStarted)
      return;
   
   // loop through all the clients and see if any are still notready
   %playerCount = 0;
   %notReadyCount = 0;

   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      if(%cl.observerMode == "pickingTeam")
      {
         %notReady[%notReadyCount] = %cl;
         %notReadyCount++;
      }   
      else if(%cl.observerMode == "pregame")
      {
         if(%cl.notready)
         {
            %notReady[%notReadyCount] = %cl;
            %notReadyCount++;
         }
         else
            %playerCount++;
      }
   }
   if(%notReadyCount)
   {
      if(%notReadyCount == 1)
         MessageAll(0, Client::getName(%notReady[0]) @ " is holding things up!");
      else if(%notReadyCount < 4)
      {
         for(%i = 0; %i < %notReadyCount - 2; %i++)
            %str = Client::getName(%notReady[%i]) @ ", " @ %str;

         %str = %str @ Client::getName(%notReady[%i]) @ " and " @ Client::getName(%notReady[%i+1]) 
                     @ " are holding things up!";
         MessageAll(0, %str);
      }
      return;
   }

   if(%playerCount != 0)
   {
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         %cl.notready = "";
         %cl.notreadyCount = "";
         bottomprint(%cl, "", 0);
      }
      Server::Countdown(30);
   }
}


function Game::checkTimeLimit()
{
   // if no timeLimit set or timeLimit set to 0,
   // just reschedule the check for a minute hence
   $timeLimitReached = false;

   if(!$Server::timeLimit)
   {
      schedule("Game::checkTimeLimit();", 60);
      return;
   }
   %curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
   if(%curTimeLeft <= 0 && $matchStarted)
   {
      echo("GAME: Timelimit reached.");
      $timeLimitReached = true;
      Server::nextMission();
   }
   else
   {
      schedule("Game::checkTimeLimit();", 20);
      UpdateClientTimes(%curTimeLeft);
   }
}

function Game::resetScores(%client)
{
	if(%client == "") {
	   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
	      %cl.scoreKills = 0;
   	   %cl.scoreDeaths = 0;
			%cl.ratio = 0;
      	%cl.score = 0;
		}
	}
	else {
      %client.scoreKills = 0;
  	   %client.scoreDeaths = 0;
		%client.ratio = 0;
     	%client.score = 0;
	}
}

function remoteSetArmor(%player, %armorType)
{
	if ($ServerCheats) {
		checkMax(Player::getClient(%player),%armorType);
	   Player::setArmor(%player, %armorType);
	}
	else if($TestCheats) {
	   Player::setArmor(%player, %armorType);
	}
}


function Game::onPlayerConnected(%playerId)
{
   $RouteWeaponSetup[%playerId] = "";
   $RoutePack[%playerId] = "";
   $RouteArmor[%playerId] = "";
   
   %playerId.scoreKills = 0;
   %playerId.scoreDeaths = 0;
	%playerId.score = 0;
   %playerId.justConnected = true;
   $menuMode[%playerId] = "None";
   Game::refreshClientScore(%playerId);
}

function Game::assignClientTeam(%playerId)
{
   if($teamplay)
   {
      %name = Client::getName(%playerId);
      %numTeams = getNumTeams();
      if($teamPreset[%name] != "")
      {
         if($teamPreset[%name] < %numTeams)
         {
            GameBase::setTeam(%playerId, $teamPreset[%name]);
            echo(Client::getName(%playerId), " was preset to team ", $teamPreset[%name]);
            return;
         }            
      }
      %numPlayers = getNumClients();
      for(%i = 0; %i < %numTeams; %i = %i + 1)
         %numTeamPlayers[%i] = 0;

      for(%i = 0; %i < %numPlayers; %i = %i + 1)
      {
         %pl = getClientByIndex(%i);
         if(%pl != %playerId)
         {
            %team = Client::getTeam(%pl);
            %numTeamPlayers[%team] = %numTeamPlayers[%team] + 1;
         }
      }
      %leastPlayers = %numTeamPlayers[0];
      %leastTeam = 0;
      for(%i = 1; %i < %numTeams; %i = %i + 1)
      {
         if( (%numTeamPlayers[%i] < %leastPlayers) || 
            ( (%numTeamPlayers[%i] == %leastPlayers) && 
            ($teamScore[%i] < $teamScore[%leastTeam] ) ))
         {
            %leastTeam = %i;
            %leastPlayers = %numTeamPlayers;
         }
      }
      GameBase::setTeam(%playerId, %leastTeam);
      echo(Client::getName(%playerId), " was automatically assigned to team ", %leastTeam);
   }
   else
   {
      GameBase::setTeam(%playerId, 0);
   }
}

function Client::onKilled(%playerId, %killerId, %damageType)
{
   echo("GAME: kill " @ %killerId @ " " @ %playerId @ " " @ %damageType);
   %playerId.guiLock = true;
   Client::setGuiMode(%playerId, $GuiModePlay);
	if(!String::ICompare(Client::getGender(%playerId), "Male"))
   {
      %playerGender = "his";
   }
	else
	{
		%playerGender = "her";
	}
	%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
	%victimName = Client::getName(%playerId);


   if(!%killerId)
   {
      messageAll(0, strcat(%victimName, " dies."), $DeathMessageMask);
      %playerId.scoreDeaths++;
  }
   else if(%killerId == %playerId)
   {
	  %oopsMsg = sprintf($deathMsg[-2, %ridx], %victimName, %playerGender);
      messageAll(0, %oopsMsg, $DeathMessageMask);
      %playerId.scoreDeaths++;
      %playerId.score--;
      Game::refreshClientScore(%playerId);
   }
   else
   {
		if(!String::ICompare(Client::getGender(%killerId), "Male"))
		{
			%killerGender = "his";
		}
		else
		{
			%killerGender = "her";
		}
      if($teamplay && (Client::getTeam(%killerId) == Client::getTeam(%playerId)))
      {
		if(%damageType != $MineDamageType) 
	    	messageAll(0, strcat(Client::getName(%killerId), 
   	        " mows down ", %killerGender, " teammate, ", %victimName), $DeathMessageMask);
		else 
	         messageAll(0, strcat(Client::getName(%killerId), 
   	     	" killed ", %killerGender, " teammate, ", %victimName ," with a mine."), $DeathMessageMask);
		 %killerId.scoreDeaths++;
       %killerId.score--;
       Game::refreshClientScore(%killerId);
      }
      else
      {
	     %obitMsg = sprintf($deathMsg[%damageType, %ridx], Client::getName(%killerId),
	       %victimName, %killerGender, %playerGender);
         messageAll(0, %obitMsg, $DeathMessageMask);
         %killerId.scoreKills++;
         %playerId.scoreDeaths++;  // test play mode
         %killerId.score++;
         Game::refreshClientScore(%killerId);
         Game::refreshClientScore(%playerId);
      }
   }
   Game::clientKilled(%playerId, %killerId);
}

function Game::clientKilled(%playerId, %killerId)
{
   // do nothing
}

function Client::leaveGame(%clientId)
{
   // do nothing
}

function Player::enterMissionArea(%player)
{
   echo("Player " @ %player @ " entered the mission area.");
}

function Player::leaveMissionArea(%player)
{
   echo("Player " @ %player @ " left the mission area.");
}

function GameBase::getHeatFactor(%this)
{
   return 0.0;
}

