What this mod basically does is help your team practice.
I'm not gonna explain all the features here.  So download / install it and try it out!

Unzip this file into your Tribes directory.

Open a DOS window.  Go to your Tribes directory.  If you don't know how... learn DOS.

Run it by typing:
FOR A DEDICATED SERVER -> Tribes.exe -mod DrinkMOD -dedicated
-	-	-	-   -   -   - THEN... launch Tribes client seperately and connect to [IP:127.0.0.1:28001:00]
FOR A NON-DEDICATED SERVER -> Tribes.exe -mod DrinkMOD
-	-	-	-   -   -   - THEN... it'll launch tribes like normal, go to "Host a server" and away you go.


That's it!  Enjoy.

- Drink|Kahlua