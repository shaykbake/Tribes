exec(serverXKmod);

function serverLink::Start()
{
	serverXKmod::Start();
}

function serverLink::InitializeMission()
{
	serverXKmod::InitializeMission();
}