This is the {|XK|} 	   *******************************************
Mod!!               	   *  X      X  K    K      MM     MM  0000000             d  *                
Xtreme Knights         *    X  X    K  K        M  M  M M  0	  0             d  *
Rule!!             	  *     XX     KK          M     M   M  0	  0    dddddd  *
                  	  *    X  X    K  K        M          M  0	  0    d       d  * 	
                   	  *  K      X  K    K      M          M  0000000    dddddd  * 
                  	  *******************************************
                                     !{|XK|} Mod Beta Version 1.4.5!

=========
FILES-=-=-=-

Scripts.vol
XKmod.cs
serverLink.cs

============================================================================
INSTALLATION-=-=-=-

To install the XKmod.

1: Make a new folder in your main Tribes directory called "XKmod"

2: Extract "All Filesl" into that new folder you just created called "XKmod" in your main Tribes directory.

3: Hosting:: Go to your tribes Short cut & add this to the command line.
	C:\Dynamix\Tribes\Tribes.exe *tribes -mod XKmod

4: Dedicated:: Go to your tribes Short cut & add this to the command line.
	C:\Dynamix\Tribes\InfiniteSpawn.exe *tribes -mod XKmod -dedicated

============================================================================
CREDITS-=-=-=-

This mod was created by Neo{|XK|} and King Shit{|XK|}. We want to thank all 
the people in our clan who gave us some of the ideas for it. We have gotten 
some of the weapons and items from other cool mods. This mod is based off 
of Renegades Alliance which is a better version of Renegades and a whole 
new way to make mods.

We wanna thank the makers of Renegades Alliance, Shifter, 
Mini-Mod, Insomniax and War 40k. We thank you for letting us use some 
of your ideas in our mod. If you dont like us using your ideas please tell
us and we will remove them. 

============================================================================
CONTACT-=-=-=-

If you would like to contact us about the mod or you have ideas for it, 
my E-Mail Address is hunter472@hotmail.com If you would like mine or King's 
ICQ number mail me telling you want them.
Visit the {|XK|} Web Site at  http://www.planetstarsiege.com/hackerx/xtremeknights/!!
Please report bugs in the mod if you find any!!!!
[][][][][][][][][][][][][][]ENJOY THE MOD!!!!![][][][][][][][][][][][][][][]

============================================================================
NOTE:::

Please do not add-on to this mod or do anyting else unless I authorize you to do so, 
if you don't ask me first then "You got some Splainin to do!"

============================================================================
THANKS TOO-=-=-=-

We would like to think http://www.tribesplayerspage.com &all of their crew for hosting our mod!
:)

============================================================================

Signing Off,
Neo{|XK|}
-&-
King Shit{|XK|}
