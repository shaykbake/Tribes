{ATF} MOD v1.0.beta.I.guess


[Coding]

	This Mod....{ATF} Mod....it is the fruit of my creative mind...or something close to it.....it took three years to get what you have here...partly cause I always added more everytime I was gonna release it...and partly cause I stopped coding it for a few months at a time....(which coincidently was when I started getting laid)...you see to have true skill in coding you must have 3 things....Creativity being the first and most important...I myself watch tons of cartoons and I am sure I have many fine mental issues...(for all you that don't know, in the state of texas I legally am mentally disabled.....how's that kiddies :D) anyway...the second thing and secondly important is free time....what helps this situation is being a big loser face...(ie. me) easiest way to ascertain this quality is to steer clear of relationships with the opposite sex and only talking to people who have already ascertained this quality....(sex+coding=no good) to code well you need 28 hours out of your day to be able to flex that creativity we talked about...being a loser face helps.......and lastly 3 and the most unimportant....having a genius (or close) I.Q. ....now it really isn't that important...but it helps....my I.Q. definetly is not genius...far from....but a high I.Q. speeds along the learning process (and helps with issue number 2 a little)...so yes....Watch cartoons....get a mental disability.....be a loser face...keep away from girls...(or boys).....infact keep away from anyone who is not interacting with you through a computer to keep it safe.....and if you think neccesse est (somewhat latin meaning "It is Neccessary") grow a genius IQ....and with their powers combined.....we have this mod.......

[This Mod]

	If you read all that last part and are still reading I fear for you....this can't be healthy...but ohh well....{ATF} mod is well....a collaboration of everything i was thinking for 3 years....it's actually kinda poetic...to someone deranged.....actually I do believe coding is poetry but thats cause I AM strange....and I talked about coding up there...hmmm anyway...you will see many things in this mod.....ALOT...I don't even want to count how many weapons and other crap is in here....though I will say that I made it all....of course if I said that I'd be lying....I created 99.8% of this mod (with his bare hands folks) and the other stuff...well i will make acknowledgements at the bottom.....but yes...in my mod you can do many things..including but not limiting: Going Super Saiyan ; Firing a weapon that has the bullet suck people into it and explode ; Run Super fast destroying anything in your path ; Have an actual Server God :) so yes....there are many mismatched abilities and powers in this mod....ya know...you can even build a sky base and plant trees....so yeah...it may seem like alot at first....but most everything has a purpose....but not everything...remember...this came outta my head...mentally disabled....so yeah...play the mod and find out what all you can do.....

[Tips + Tricks]

	Well, server god will randomly give you mod tips...when he feels like it so...yeah just listen to him......and as for tricks.....my mod does have cheats :).....but......I don't like you have the ability to cheat up the ass....admins can use some commands to ask server god for stuff....but...if you do there is a 50% chance he will kill you and kick you off your team so I wouldn't try it.....if you still wanna try asking server god for stuff then in the chat area type (and it is case sensitive): ServerGod: GiveMe [Name an item] [Name how much you want]            so an example would be  ServerGod: GiveMe PlasmaAmmo 100   <======which asks for 100 plasma ammo :) it isn't hard.....there are a few god weapons you can ask for....but they are hard to get :)....you will blow up a bunch :) .....but i will give you the name of one....in the space where you put in what you want type Admin to recieve the Admin Gun....an interesting God Weapon.....so yeah I was nice and told you tricks and tips....DO NOT COME TO ME ASKING FOR MORE.....if you want more........there are ways of figuring it out....

[Bugs]

	Well.... all of you must understand one thing....I am a lazy bastard....but I do love to code...so if you find bugs in my mod tell me...	I will fix it....if it is something big like..."HaCk, (though you at school won't call me by that name ;) ) if you fire this gun during AntiTeam Warfare it shutsdown tribes" or a lag solving issue....anyway something big, I might give you a few god weapons to stare at and play with....and you will go in the credits....good good......

[Acknowledgments]

	Well, though i  made almost alll this mod there are some people I may have "borrowed" code from.....here I thank them:

	Bomblets Coding: Shifter Mod

	Warp Pack(Well I tweaked it a bunch): Plasmatic

	Air Plats: Balance of Power Mod 

	And there you have it......those three aren't the backbone of my mod...but I do think that the authors of them deserve the recognition


[Credits]

Producer: HaCk
Lead Programmer: HaCk
Assistant Programmer: HaCk
Art Director: HaCk
Lead Artists: HaCk
Composer: HaCk
Dude who spent 28 hours a day infront of a comp...and is a big loser face: HaCk



[Special Thanx]


Well anyone knows that behind every good programmer is good music....because coding is more fun with loud music so special thanx to:

System Of A Down (First CD)
(the second CD gets no thanx cause toxicity was over played)
System Of A Down (Steal this Album) (Third CD) 

Linkin Park (Hybrid Theory) (Back B4 it was over played)
Linkin Park (Meteora) (Which is helping me write this readme)

The Beatles

The Doors

The Rolling Stones

The Mama's and The Papa's

Kenna

Daft Punk

R.E.M.


and that ends music.....now for the people...




To here goes special thanx to all the girls who have preoccupied my head while writing this mod and slowed its production:):


Jena Huffman (who I dated for a very  very long time.....and who Hated my moding :)  p.s. thank her for the year long break in my coding.......stupid me-having-a-life)

Kelly McKeever (Who I dated......for 2 weeks......and who has spent more time preoccupying my mind then most)

Dana Cox (Self Explanatory)

and .......I am sure there are a few others I have forced out of my head.....




To here goes the poeple who helped along the creation of this mod:

Ashley Hestand ( Who actually tested out this waste of space I call a mod)

You for excepting this CD from me....

Me for coding this damn thing......

My computer...(For its support in holding all the crap I tell it to)





and so I end with just that...an ending.....you should go frolic in my mod or something now.....or.....I don't know...go pick up some chicks (or guys :P ) and be social....both are good plans and lead to you being satisfied...but take it from me...A big Loser Face....the first choice means that you don't have to get up :)



					
							-HaCk










