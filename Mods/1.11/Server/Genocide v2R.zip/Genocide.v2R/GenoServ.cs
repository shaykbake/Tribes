//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\\
//                                         .:(Genocide):.                                                              \\
//                                          Server Prefs                                                               \\
//                                 Modification By: 6|6|6*SlipKnot*                                                    \\
//                             Administration Coded By: ]|420|[*CraCka                                                 \\
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\\


//------------------------
$AutoBanTime = "18000000";  //Ban time of a player in seconds
//------------------------


//------------------------
$CodeRed::LowScore = "On";  //Auto-Kicks player if score reaches -10
$CodeRed::AntiTK = "On";    //Auto-Kicks player if he/she TK's 4 times
//------------------------


//------------------------
$VoteKick = "False";        //Allows Regular Players to Vote to KICK
$VoteAdmin = "False";       //Allows Regular Players to Vote to ADMIN
//------------------------


//----------------------------
//Banned Names Upto 100 blocks *Note* you must match ARMBAN name with the players IP in ARMBANIP
//----------------------------
$ArmBan[0] = "";
$ArmBan[1] = "";
$ArmBan[2] = "";
$ArmBan[3] = "";
$ArmBan[4] = "";
$ArmBan[5] = "";
$ArmBan[6] = "";
$ArmBan[7] = "";
$ArmBan[8] = "";
$ArmBan[9] = "";
//---------------------------


//-----------------------------
//Banned IPs upto 100 IP Blocks *Note* IP must match name above
//-----------------------------
$ArmBanIP[0] = "";
$ArmBanIP[1] = "";
$ArmBanIP[2] = "";
$ArmBanIP[3] = "";
$ArmBanIP[4] = "";
$ArmBanIP[5] = "";
$ArmBanIP[6] = "";
$ArmBanIP[7] = "";
$ArmBanIP[8] = "";
$ArmBanIP[9] = "";
//-----------------------------


//----------------------------------------------------
// Admin Data - 4 Levels of admin
//
// "Server Master" or Owner Admin
// "God" or God Admin
// "Super" or Super Admin
// "Public" or Public Admin
//_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-
//    *READ THIS*
// You can set upto 20 God,Super
// and Public Admin names and password
// but only *1* Owner Name and Password
// To setup a player with admin you must 
// first choose his or her level of admin
// Next choose his or her private PW to login
// *Note* you must have his or her game name 
// Spelled perfect it is case sensitive.
//-=-=-=-=-=-=-=-=-=EXAMPLE-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//
// IE $SuperPassword[0] = "heythere";
//    $SuperName[0] = "6|6|6*SlipKnot*";
//
//
// What this allows is multiple pws for ppl
// but it also acts as an alarm if say 
// .:(A):.Kevin:. tried to login with that pw
// it would alert everyone on the server
// So only the name that is on the $SuperName
// Can login with the password for that specific name
//----------------------------------------------------

//++++++++++++++++++++++++++++++++++
$OwnerPassword[0] = "YourPW";
$OwnerName[0] = "YourName";
//++++++++++++++++++++++++++++++++++


//==================================
// Telenet & Console Log Options
//==================================
$TelnetPort = 8888;
$TelnetPassword = "YourTelenetPW";
//==================================
// Make this value to "2" to produce 
// server logs. Set to "0" for no 
// log.
// The server log will appear as
// console.log in the TRIBES folder
//==================================
$console::logmode = "2";
//==================================


//----------------------------------
// God Admin Logins
//----------------------------------
$GodName[0] = "ChangeName";
$GodPassword[0] = "ChangePW";

$GodName[1] = "ChangeName";
$GodPassword[1] = "ChangePW";

$GodName[2] = "ChangeName";
$GodPassword[2] = "ChangePW";

$GodName[3] = "ChangeName";
$GodPassword[3] = "ChangePW";

$GodName[4] = "ChangeName";
$GodPassword[4] = "ChangePW";

$GodName[5] = "ChangeName";
$GodPassword[5] = "ChangePW";

$GodName[6] = "ChangeName";
$GodPassword[6] = "ChangePW";

$GodName[7] = "ChangeName";
$GodPassword[7] = "ChangePW";

$GodName[8] = "ChangeName";
$GodPassword[8] = "ChangePW";

$GodName[9] = "ChangeName";
$GodPassword[9] = "ChangePW";

$GodName[10] = "ChangeName";
$GodPassword[10] = "ChangePW";

$GodName[11] = "ChangeName";
$GodPassword[11] = "ChangePW";

$GodName[12] = "ChangeName";
$GodPassword[12] = "ChangePW";

$GodName[13] = "ChangeName";
$GodPassword[13] = "ChangePW";

$GodName[14] = "ChangeName";
$GodPassword[14] = "ChangePW";

$GodName[15] = "ChangeName";
$GodPassword[15] = "ChangePW";

$GodName[16] = "ChangeName";
$GodPassword[16] = "ChangePW";

$GodName[17] = "ChangeName";
$GodPassword[17] = "ChangePW";

$GodName[18] = "ChangeName";
$GodPassword[18] = "ChangePW";

$GodName[19] = "ChangeName";
$GodPassword[19] = "ChangePW";

$GodName[20] = "ChangeName";
$GodPassword[20] = "ChangePW";

//----------------------------------


//----------------------------------
// Super Admin Logins
//----------------------------------
$SuperName[0] = "ChangeName";
$SuperPassword[0] = "ChangePW";

$SuperName[1] = "ChangeName";
$SuperPassword[1] = "ChangePW";

$SuperName[2] = "ChangeName";
$SuperPassword[2] = "ChangePW";

$SuperName[3] = "ChangeName";
$SuperPassword[3] = "ChangePW";

$SuperName[4] = "ChangeName";
$SuperPassword[4] = "ChangePW";

$SuperName[5] = "ChangeName";
$SuperPassword[5] = "ChangePW";

$SuperName[6] = "ChangeName";
$SuperPassword[6] = "ChangePW";

$SuperName[7] = "ChangeName";
$SuperPassword[7] = "ChangePW";

$SuperName[8] = "ChangeName";
$SuperPassword[8] = "ChangePW";

$SuperName[9] = "ChangeName";
$SuperPassword[9] = "ChangePW";

$SuperName[10] = "ChangeName";
$SuperPassword[10] = "ChangePW";

$SuperName[11] = "ChangeName";
$SuperPassword[11] = "ChangePW";

$SuperName[12] = "ChangeName";
$SuperPassword[12] = "ChangePW";

$SuperName[13] = "ChangeName";
$SuperPassword[13] = "ChangePW";

$SuperName[14] = "ChangeName";
$SuperPassword[14] = "ChangePW";

$SuperName[15] = "ChangeName";
$SuperPassword[15] = "ChangePW";

$SuperName[16] = "ChangeName";
$SuperPassword[16] = "ChangePW";

$SuperName[17] = "ChangeName";
$SuperPassword[17] = "ChangePW";

$SuperName[18] = "ChangeName";
$SuperPassword[18] = "ChangePW";

$SuperName[19] = "ChangeName";
$SuperPassword[19] = "ChangePW";

$SuperName[20] = "ChangeName";
$SuperPassword[20] = "ChangePW";
//----------------------------------


//----------------------------------
// Public Admin Logins
//----------------------------------
$PublicName[0] = "ChangeName";
$PublicPassword[0] = "ChangePW";

$PublicName[1] = "ChangeName";
$PublicPassword[1] = "ChangePW";

$PublicName[2] = "ChangeName";
$PublicPassword[2] = "ChangePW";

$PublicName[3] = "ChangeName";
$PublicPassword[3] = "ChangePW";

$PublicName[4] = "ChangeName";
$PublicPassword[4] = "ChangePW";

$PublicName[5] = "ChangeName";
$PublicPassword[5] = "ChangePW";

$PublicName[6] = "ChangeName";
$PublicPassword[6] = "ChangePW";

$PublicName[7] = "ChangeName";
$PublicPassword[7] = "ChangePW";

$PublicName[8] = "ChangeName";
$PublicPassword[8] = "ChangePW";

$PublicName[9] = "ChangeName";
$PublicPassword[9] = "ChangePW";

$PublicName[10] = "ChangeName";
$PublicPassword[10] = "ChangePW";

$PublicName[11] = "ChangeName";
$PublicPassword[11] = "ChangePW";

$PublicName[12] = "ChangeName";
$PublicPassword[12] = "ChangePW";

$PublicName[13] = "ChangeName";
$PublicPassword[13] = "ChangePW";

$PublicName[14] = "ChangeName";
$PublicPassword[14] = "ChangePW";

$PublicName[15] = "ChangeName";
$PublicPassword[15] = "ChangePW";

$PublicName[16] = "ChangeName";
$PublicPassword[16] = "ChangePW";

$PublicName[17] = "ChangeName";
$PublicPassword[17] = "ChangePW";

$PublicName[18] = "ChangeName";
$PublicPassword[18] = "ChangePW";

$PublicName[19] = "ChangeName";
$PublicPassword[19] = "ChangePW";

$PublicName[20] = "ChangeName";
$PublicPassword[20] = "ChangePW";
//----------------------------------

//---------------------
// Admin Logouts - Do not edit or the function becomes useless
//---------------------
$Logout = "Logout";
$Logout2 = "logout";
//---------------------


//-------------------------------------------------------
// Server Information that the mod runs 
// when you hit tab and select Server Info option
// Edit to fit your Prefs
//-------------------------------------------------------
$OwnerName = "Your Name";
$Clan = "YourClan or N/A";
$ClanTag = "Clan Tag Here";
$ClanSite = "Clan URL Here";
$Admin = "Admins Names";
$Rules = "\n<jc><f3>1. <F2>No Spawn Killing\n<F3>2. <F2>No Off-Side Turreting\n<F3>3. <F2>No TKing\n<F3>4. <F2>No Cammping.";
//-------------------------------------------------------
// The rules above are just the rules i've played with 
// since i started playing, Edit to your liking
//--------------------------------------------------------


//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
// Basic Server Prefs
//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
$Server::Address = "LOOPBACK:28001";
$Server::AutoAssignTeams = "true";
$Server::CurrentMaster = "0";
$Server::fairteams = "true";
$Server::FloodProtectionEnabled = "true";
$Server::HostName = "6|6|6 Genocide Testing 6|6|6";
$Server::HostPublicGame = "true";
$Server::Info = "<jc><f1>Genocide\n<f3>Admin: <f2>YourName\n<f3>Email: <f2>YourE-Mail@Host.com\n<f3>Mod Info: <f2>www.TeamHybrid.Org";
$Server::JoinMOTD = "<jc><f2>Message of the day:\nThis is Genocide By: <f3>6|6|6*SlipKnot*\n<f1>Welcome To <F2>My <F1>Realm\nFew Rules Here:\n<f3>1. No Spawn Killing\n2. No Off-Side Turreting\n3. No TKing\n4. No Cammping\nFire For Chaos!!!";
$Server::lastMission = "Blastside";
$Server::Master1 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";
$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "US Tribes Master";
$Server::MasterName1 = "UK Tribes Master";
$Server::MasterName2 = "Australian Tribes Master";
$Server::MaxPlayers = "10";
$Server::MinVotes = "1";
$Server::MinVotesPct = "0.5";
$Server::MinVoteTime = "45";
$Server::numMasters = "3";
$Server::PABan = "false";
$Server::PAFairTeams = "true";
$Server::PAKick = "true";
$Server::PAMission = "true";
$Server::PAModOptions = "false";
$Server::PAResetDefaults = "false";
$Server::PATeamChange = "true";
$Server::PATeamDamage = "true";
$Server::PATeamInfo = "true";
$Server::PATimeLimit = "true";
$Server::PATourneyMode = "true";
$Server::PAVote = "false";
$Server::Port = "28001";
$Server::PSkin = "true";
$Server::PVFairTeams = "true";
$Server::PVKick = "true";
$Server::PVMission = "true";
$Server::PVTeamDamage = "true";
$Server::PVTourneyMode = "true";
$Server::respawnInvulnerableTime = "10";
$Server::respawnTime = "1";
$Server::SafeStation = "true";
$Server::StationTime = "15";
$Server::TeamDamageScale = "0";
$Server::teamName0 = "6|6|6";
$Server::teamName1 = "+]-[+";
$Server::teamName2 = "}KR{";
$Server::teamName3 = "<R-A>";
$Server::teamName4 = "Generic 1";
$Server::teamName5 = "Generic 2";
$Server::teamName6 = "Generic 3";
$Server::teamName7 = "Generic 4";
$Server::teamSkin0 = "666MOTB";
$Server::teamSkin1 = "HybridOriginalv2K3";
$Server::teamSkin2 = "cphoenix";
$Server::teamSkin3 = "AnarchyAssault";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";
$Server::timeLimit = "60";
$Server::tkClientLvl = "0";
$Server::tkLimit = "3";
$Server::tkMultiple = "2";
$Server::tkServerLvl = "2";
$Server::TourneyMode = "false";
$Server::VoteAdminWinMargin = "0.659999";
$Server::VoteFailTime = "30";
$Server::VoteWinMargin = "0.549999";
$Server::VotingTime = "20";
$Server::warmupTime = "5";
$Server::XLMaster1 = "IP:64.94.105.150:28000";
$Server::XLMaster2 = "IP:Broadcast:28001";
$Server::XLMasterN0 = "IP:198.74.32.55:28000";
$Server::XLMasterN1 = "IP:198.74.35.10:28000";
$Server::XLMasterN2 = "IP:198.74.40.67:28000";
$pref::LastMission = "Blastside";







