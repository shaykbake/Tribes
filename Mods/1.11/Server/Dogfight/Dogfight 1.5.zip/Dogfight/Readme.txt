Extract Scripts.vol to Tribes\dogfight
Extract DogfightServerConfig to Tribes\Config