Extract Scripts.vol to Tribes\Dogfight,
Extract Dogfight.cs, DogfightServerConfig.cs, and serverPrefs.cs to Tribes\Config 
Overwrite the ServerPrefs curently in config