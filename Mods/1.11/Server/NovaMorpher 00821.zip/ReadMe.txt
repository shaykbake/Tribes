+-------------------------+-------+---------------------------------+
|                         |BY:    |     My Most Favorite Quote      |
| NNN    NN  MMM      MMM +---V---+---------------------------------+
| NNNN   NN  MMMM    MMMM |   R   |   "   Always SHARE, - that   "  |
| NN NN  NN  MM MM  MM MM |   W   |   " way you and others don't "  |
| NN  NN NN  MM  MMMM  MM |   A   |   "   have to re-invent the  "  |
| NN   NNNN  MM   MM   MM |   R   |   "   wheel over and over    "  |
| NN    NNN  MM        MM |   P   |   "   again all the time.    "  |
| NN     NN  MM        MM |   E   |            -Werewolf            |
|    -|-NovaMorpher-|-    |   R   |               Maker of SpoonBots|
+-------------------------+-------+---------------------------------+
|Special Thanks TO:                                                 |
|  - Chivalry Community                                             |
|  - Meltdown Mod                                                   |
|  - Shifter Mod                                                    |
|  - Vengeance - Helped me along the way of the development         |
|  - ROS|Lethedius - Helped me start up this mod                    |
|  - [CLU] CLU - Maker of chivalry                                  |
|  - And everyone else who made this possible =)                    |
+-------------------------------------------------------------------+
|    Thank-you for downloading and trying NovaMorpher -- VRWarper   |
+-------------------------------------------------------------------+

Installation:

+--------+
|STEP ONE|
+--------+
Automatic: This should have been done already IF you unzipped it to
           the correct directory =). Otherwise you will have to do
           MANUAL installation... See below for details

Manual:    Usually you do this for two reasons... One, you accidentally 
           unzipped it to another directory instead of C or D or what
           Where ever the folder dynamix is located. or probably something
           else.

           You make a folder in...
           <where ever tribes.exe is located>\NovaMorpher
           Then you put SCRIPTS.vol (you may not see the .vol) and 
           NovaMorpher.cs (again you may not see .cs) into that folder

+--------+
|Step Two|
+--------+

Okay here is where it gets complicated... You have to create a shortcut to
tribes, (go to tribes.exe, right click, create shortcut) and rename it if
you want. Then you right click on the shortcut and go to properties an on
the "Target:" bar you will see "<path to tribes.exe>\tribes.exe".
Now append (add on to) the following WITHOUT the quotes (").

" -mod NovaMorpher"

add

" -dedicated" if you want to run a dedicated server.

Then click okay. And you set to go!


|------------------------------------------------------------------------------|

+--------------------------------+
|   Frequently Asked Questions   |
+--------------------------------+

Q) Can I copy your work?
A) Yes, but so far I do not plan on releasing the non-LZH compressed version
   of my mod until im fully satisfied with it. How ever you are still able
   to look at the scripts so it is at least possible to read.

Q) Can I make a suggestion?
A) Yes. Just write to me =)

Q) Can I send you a patch I make?
A) Yes, just send it to me =) I'd love to accept it.

Q) Can you teach me how to make a patch/script?
A) Sorry, can't... I'm too busy even though I'm 13 (At the time of writing this (3/6/02))

Q) I found a bug, how can I report it?
A) Use the listed methods of communications below...

Q) I have more questions, how can I ask you?
A) The best method is e-mailing me but AIM/ICQ/MSN/Yahoo would work also.
   MY..
   E-mail:  Benson@vrwarp.com
   AIM S/N: VRWarper
   ICQ #:   73883885
   Yahoo:   vrwarp@yahoo.com
   MSN:     VRWarper@hotmail.com

Q) Hey, are you T1 dead?
A) Most likely not, not until T1 is dead itself ;) So you should see me around....