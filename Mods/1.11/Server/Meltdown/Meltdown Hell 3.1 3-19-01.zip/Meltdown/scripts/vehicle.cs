//========================================================== Wheeeeeeeeeeee
//					Vehicles
//========================================================== Mega Man 1024


FlierData Scout
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.5;
   maxPitch = 0.5;
   maxSpeed = 65;
   minSpeed = -2;
	maxSideSpeed = 45;
	lift = 0.75;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 10.6;
	damageLevel = {1.0, 1.0};
	maxEnergy = 25;
	accel = 0.6;

	groundDamageScale = 1.0;

	projectileType = StdRocket;
	reloadDelay = 0.75;
	repairRate = 0;
	fireSound = SoundFireFlierRocket;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;

};

FlierData LAPC
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris2;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.3;
   maxPitch = 0.1;
   maxSpeed = 40;
   minSpeed = -10;
	lift = 0.5;
	maxAlt = 9;
	maxVertical = 5;
	maxDamage = 12.5;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 75;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	
//	projectileType = mortarshell;
	fireSound = SoundFireMortar;
	reloadDelay = 4.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

FlierData Interceptor
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris2;
	className = "Vehicle";
   shapeFile = "hover_apc_sml";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 3.25;
   maxPitch = 3.175;
   maxSpeed = 45;
   minSpeed = -12.5;
	lift = 0.5;
	maxAlt = 900;
	maxVertical = 900;
	maxDamage = 13.5;
	damageLevel = {1.0, 1.0};
	destroyDamage = 1.0;
	maxEnergy = 50;
	accel = 0.25;

	groundDamageScale = 0.50;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	
	projectileType = RPEMP;
	fireSound = SoundPlasmaTurretFire;
	reloadDelay = 2.0;
	damageSound = SoundTankCrash;
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

FlierData HAPC
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris3;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 18.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.25;
   maxPitch = 0.175;
   maxSpeed = 25;								   
   minSpeed = -1;
	lift = 0.35;
	maxAlt = 15;
	maxVertical = 6;
	maxDamage = 12.0;
	damageLevel = {1.0, 1.0};
	maxEnergy = 75;
	accel = 0.25;

	groundDamageScale = 0.125;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	fireSound = SoundFireFlierRocket;
	reloadDelay = 3.0;
	damageSound = SoundTankCrash;
	visibleToSensor = false;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

FlierData EOMissile
{
	explosionId = MortarExp;
	debrisId = EODebris;
	className = "Vehicle";
    shapeFile = "rocket";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 10.5;
    maxPitch = 11.15;
    maxSpeed = 65;
    minSpeed = 40;
	maxSideSpeed = 10;
	lift = 0.85;
	maxAlt = 200;
	maxVertical = 200;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 30; // time in seconds until explodes
	accel = 2.0;

	groundDamageScale = 20.0;

	repairRate = 0;
	damageSound = ShockExplosion;
	ramDamage = 1.28;
	ramDamageType = $MissileDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Electro-Optical Missile";
};

function EOMissile::onAdd(%this)
{
 GameBase::setRechargeRate (%this,0);
 schedule("EOMissile::exhaustFuel("@%this@");",1,%this);
}

function EOMissile::onCollision(%this,%object)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

function EOMissile::jump(%this,%mom)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function EOMissile::onDestroyed (%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   %pl = Client::getOwnedObject(%cl);
   if(%pl != -1) 
   {
    Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	if(%pl.lastWeapon != "") 
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle= "";
   }
   calcRadiusDamage(%this,$MissileDamageType, 30, 0.5, 20, 10, 8, 1.2, 0.7, 300, 200); 
}

function EOMissile::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 1);
   schedule("EOMissile::exhaustFuel("@%this@");",1,%this);
  }
}

FlierData ProbeDroid
{
	explosionId = GrenadeExp;
	debrisId = FlierDebris;
	className = "Vehicle";
    shapeFile = "rocket";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 10.5;
    maxPitch = 11.15;
    maxSpeed = 70;
    minSpeed = 35;
	maxSideSpeed = 10;
	lift = 0.85;
	maxAlt = 200;
	maxVertical = 200;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 15; // time in seconds until explodes
	accel = 2.0;

	groundDamageScale = 20.0;

	repairRate = 0;
	damageSound = ShockExplosion;
	ramDamage = 0.9;
	ramDamageType = $MissileDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Electro-Optical Missile";
};

function ProbeDroid::onAdd(%this)
{
 GameBase::setRechargeRate (%this,0);
 schedule("ProbeDroid::exhaustFuel("@%this@");",1,%this);
}

function ProbeDroid::onCollision(%this,%object)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

function ProbeDroid::jump(%this,%mom)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function ProbeDroid::onDestroyed (%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   %pl = Client::getOwnedObject(%cl);
   if(%pl != -1) 
   {
    Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	if(%pl.lastWeapon != "") 
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle= "";
   }
   calcRadiusDamage(%this,$MissileDamageType, 30, 0.5, 20, 10, 8, 1.2, 0.7, 300, 200); 
}

function ProbeDroid::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 1);
   schedule("ProbeDroid::exhaustFuel("@%this@");",1,%this);
  }
}

FlierData ScouterMissile
{
	explosionId = rocketExp;
	debrisId = flashDebrisLarge;
	className = "Vehicle";
    shapeFile = "rocket";
    shieldShapeName = "shield_medium";
    mass = 0.1;
    drag = 1.0;
    density = 1.2;
    maxBank = 10.5;
    maxPitch = 11.15;
    maxSpeed = 80;
    minSpeed = 40;
	lift = 0.85;
	maxAlt = 200;
	maxVertical = 200;
	maxDamage = 0.001;
	damageLevel = {1.0, 1.0};
	maxEnergy = 60; // time in seconds until explodes
	accel = 1.0;

	groundDamageScale = 20.0;

	repairRate = 0;

	damageSound = shockExplosion;
	ramDamage = 0.5;
	ramDamageType = $ImpactDamageType;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundJetHeavy;
	moveSound = SoundJetHeavy;

	visibleDriver = false;
	driverPose = 22;
	description = "Electro-Optical Missile";
};

function ScouterMissile::onAdd(%this)
{
 GameBase::setRechargeRate (%this,0);
 schedule("ScouterMissile::exhaustFuel("@%this@");",1,%this);
}

function ScouterMissile::onCollision(%this,%object)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
}

function ScouterMissile::jump(%this,%mom)
{
 GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0",%mom,%this);
}

function ScouterMissile::onDestroyed (%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   %pl = Client::getOwnedObject(%cl);
   if(%pl != -1) 
   {
    Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
	if(%pl.lastWeapon != "") 
	{
		Player::useItem(%pl,%pl.lastWeapon);		 	
		%pl.lastWeapon = "";
	}
	%pl.driver = "";
	%pl.vehicle= "";
   }
   calcRadiusDamage(%this,$MissileDamageType, 30, 0.5, 20, 10, 8, 1.2, 0.7, 300, 200); 
}

function ScouterMissile::exhaustFuel(%this)
{
  %fuel = GameBase::getEnergy(%this);
  if(%fuel < 1) GameBase::applyDamage(%this,$ImpactDamageType,10,GameBase::getPosition(%this),"0 0 0","0 0 0",%this);
  else 
  {
   GameBase::setEnergy(%this,%fuel - 1);
   schedule("ScouterMissile::exhaustFuel("@%this@");",1,%this);
  }
}

FlierData Arwing
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 60;
	maxSideSpeed = 10;
   minSpeed = -5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 12.5;
	damageLevel = {1.0, 1.0};
	accel = 0.4;

	groundDamageScale = 1.7;

	projectileType = DisruptorBeam;
	reloadDelay = 0.15;
	maxEnergy = 30;
	repairRate = 0;
	fireSound = SoundLaserHit;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Arwing";
};

FlierData SkyCutter
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 128;
	maxSideSpeed = 32;
   minSpeed = -8;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 10.1;
	damageLevel = {1.0, 1.0};
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = SuperBlaster;
	reloadDelay = 0.15;
	maxEnergy = 37.5;
	repairRate = 0;
	fireSound = SoundPlasmaTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Sky Cutter";
};

FlierData StarHammer
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 45;
	maxSideSpeed = 10;
   minSpeed = -5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 13.75;
	damageLevel = {1.0, 1.0};
	accel = 0.6;

	groundDamageScale = 0.01;

	projectileType = IonShock3;
	reloadDelay = 1.5;
	maxEnergy = 35;
	repairRate = 0;
	fireSound = capturedtower;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Star Hammer";
};

FlierData Explorer 
{	
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	classname = "Vehicle";
	shapeFile = "flyer";
	shieldShapeName = "shield_medium";
	mass = 1.0;
	drag = 0.1;
	density = 1.0;
	maxBank = 12.5;
	maxPitch = 12.0;
	maxSpeed = 75;
	minSpeed = -15;
	maxSideSpeed = 10;

	lift = 1.0;
	maxAlt = 100000;
	maxVertical = 0.0000001;
	maxDamage = 8;
	
	damageLevel = {1.0, 1.0};
	maxEnergy = 50;
	accel = 1.5;
	groundDamageScale = 0.5;
	projectileType = VertigoBeam;
	reloadDelay = 0.3;
	repairRate = 0;
	fireSound = SoundMortarTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 0.65;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;
	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;
	visibleDriver = true;
	driverPose = 22;
	description = "Explorer";
};

FlierData Skyranger
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 45;
	maxSideSpeed = 10;
   minSpeed = -10;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 12;
	damageLevel = {1.0, 1.0};
	maxEnergy = 75;
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = DiscShell;
	reloadDelay = 0.45;
	repairRate = 0;
	fireSound = SoundFireDisc;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Skyranger";
};

FlierData Avenger
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 50;
	maxSideSpeed = 10;
   minSpeed = -7.5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 11;
	damageLevel = {1.0, 1.0};
	maxEnergy = 17;
	accel = 0.4;

	groundDamageScale = 0.1;

	projectileType = PlasmaBolt2;
	reloadDelay = 0.45;
	repairRate = 0;
	fireSound = SoundFirePlasma;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "Avenger";
};

FlierData StarFighter
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris;
	className = "Vehicle";
   shapeFile = "flyer";
   shieldShapeName = "shield_medium";
   mass = 9.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 32;
   maxPitch = 32;
   maxSpeed = 70;
	maxSideSpeed = 10;
   minSpeed = -7.5;
	lift = 1;
	maxAlt = 25;
	maxVertical = 10;
	maxDamage = 12;
	damageLevel = {1.0, 1.0};
	maxEnergy = 10;
	accel = 0.4;

	groundDamageScale = 0.01;

	projectileType = Ionshockz;
	reloadDelay = 0.15;
	repairRate = 0;
	fireSound = SoundPlasmaTurretFire;
	damageSound = SoundFlierCrash;
	ramDamage = 1.5;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	visibleToSensor = true;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 22;
	description = "StarFighter";
};

FlierData HoverTank
{
	explosionId = FlierExplosion;
	debrisId = FlierDebris3;
	className = "Vehicle";
   shapeFile = "hover_apc";
   shieldShapeName = "shield_large";
   mass = 12.0;
   drag = 1.0;
   density = 1.2;
   maxBank = 0.9;
   maxPitch = 1;
   maxSpeed = 25;								   
   minSpeed = -1;
	lift = 2;
	maxAlt = 15;
	maxVertical = 0.001;
	maxDamage = 28.5;
	maxSideSpeed = 45;
	damageLevel = {1.0, 1.0};
	maxEnergy = 300;
	accel = 0.25;

	groundDamageScale = 0.001;

	repairRate = 0;
	ramDamage = 2;
	ramDamageType = -1;
	mapFilter = 2;
	mapIcon = "M_vehicle";
	projectileType = RPM; 
	fireSound = SoundFireMortar;
	reloadDelay = 2;
	damageSound = SoundTankCrash;
	visibleToSensor = false;
	shadowDetailMask = 2;

	mountSound = SoundFlyerMount;
	dismountSound = SoundFlyerDismount;
	idleSound = SoundFlyerIdle;
	moveSound = SoundFlyerActive;

	visibleDriver = true;
	driverPose = 23;
};

$DamageScale[EOMissile, $ImpactDamageType] = 1.0;
$DamageScale[EOMissile, $BulletDamageType] = 1.0;
$DamageScale[EOMissile, $PlasmaDamageType] = 1.0;
$DamageScale[EOMissile, $EnergyDamageType] = 1.0;
$DamageScale[EOMissile, $ExplosionDamageType] = 1.0;
$DamageScale[EOMissile, $ShrapnelDamageType] = 1.0;
$DamageScale[EOMissile, $DebrisDamageType] = 1.0;
$DamageScale[EOMissile, $MissileDamageType] = 1.0;
$DamageScale[EOMissile, $LaserDamageType] = 0.5;
$DamageScale[EOMissile, $MortarDamageType] = 1.0;
$DamageScale[EOMissile, $BlasterDamageType] = 0.5;
$DamageScale[EOMissile, $ElectricityDamageType] = 1.0;
$DamageScale[EOMissile, $MineDamageType]        = 1.0;

$DamageScale[EODisc, $ImpactDamageType] = 1.0;
$DamageScale[EODisc, $BulletDamageType] = 1.0;
$DamageScale[EODisc, $PlasmaDamageType] = 1.0;
$DamageScale[EODisc, $EnergyDamageType] = 1.0;
$DamageScale[EODisc, $ExplosionDamageType] = 1.0;
$DamageScale[EODisc, $ShrapnelDamageType] = 1.0;
$DamageScale[EODisc, $DebrisDamageType] = 1.0;
$DamageScale[EODisc, $MissileDamageType] = 1.0;
$DamageScale[EODisc, $LaserDamageType] = 0.5;
$DamageScale[EODisc, $MortarDamageType] = 1.0;
$DamageScale[EODisc, $BlasterDamageType] = 0.5;
$DamageScale[EODisc, $ElectricityDamageType] = 1.0;
$DamageScale[EODisc, $MineDamageType]        = 1.0;

$DamageScale[ScouterMissile, $ImpactDamageType] = 1.0;
$DamageScale[ScouterMissile, $BulletDamageType] = 1.0;
$DamageScale[ScouterMissile, $PlasmaDamageType] = 1.0;
$DamageScale[ScouterMissile, $EnergyDamageType] = 1.0;
$DamageScale[ScouterMissile, $ExplosionDamageType] = 1.0;
$DamageScale[ScouterMissile, $ShrapnelDamageType] = 1.0;
$DamageScale[ScouterMissile, $DebrisDamageType] = 1.0;
$DamageScale[ScouterMissile, $MissileDamageType] = 1.0;
$DamageScale[ScouterMissile, $LaserDamageType] = 0.5;
$DamageScale[ScouterMissile, $MortarDamageType] = 1.0;
$DamageScale[ScouterMissile, $BlasterDamageType] = 0.5;
$DamageScale[ScouterMissile, $ElectricityDamageType] = 1.0;
$DamageScale[ScouterMissile, $MineDamageType]        = 1.0;

$DamageScale[SurveyDrone, $ImpactDamageType] = 1.0;
$DamageScale[SurveyDrone, $BulletDamageType] = 1.0;
$DamageScale[SurveyDrone, $PlasmaDamageType] = 1.0;
$DamageScale[SurveyDrone, $EnergyDamageType] = 1.0;
$DamageScale[SurveyDrone, $ExplosionDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShrapnelDamageType] = 1.0;
$DamageScale[SurveyDrone, $DebrisDamageType] = 1.0;
$DamageScale[SurveyDrone, $MissileDamageType] = 1.0;
$DamageScale[SurveyDrone, $LaserDamageType] = 1.0;
$DamageScale[SurveyDrone, $MortarDamageType] = 1.0;
$DamageScale[SurveyDrone, $BlasterDamageType] = 0.5;
$DamageScale[SurveyDrone, $ElectricityDamageType] = 1.0;
$DamageScale[SurveyDrone, $MineDamageType]        = 1.0;
$DamageScale[SurveyDrone, $FusionDamageType] = 1.5;
$DamageScale[SurveyDrone, $DisruptorDamageType] = 1.0;
$DamageScale[SurveyDrone, $IonDamageType] = 2.2;
$DamageScale[SurveyDrone, $VulcanDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShotgunDamageType] = 1.0;
$DamageScale[SurveyDrone, $NukeDamageType] = 10.0;
$DamageScale[SurveyDrone, $ZapDamageType] = 2.0;
$DamageScale[SurveyDrone, $HeatDamageType] = 1.0;
$DamageScale[SurveyDrone, $ATCDamageType] = 1.0;
$DamageScale[SurveyDrone, $StarDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShockwaveDamageType] = 1.0;
$DamageScale[SurveyDrone, $PBWDamageType] = 1.0;
$DamageScale[SurveyDrone, $FlameDamageType] = 1.0;
$DamageScale[SurveyDrone, $IceDamageType] = 1.0;
$DamageScale[SurveyDrone, $BurstDamageType] = 1.0;
$DamageScale[SurveyDrone, $ReaverDamageType] = 1.0;
$DamageScale[SurveyDrone, $RifleDamageType] = 1.0;
$DamageScale[SurveyDrone, $MassShotgunDamageType] = 1.0;
$DamageScale[SurveyDrone, $GaussDamageType] = 1.0;
$DamageScale[SurveyDrone, $MBDamageType] = 1.0;
$DamageScale[SurveyDrone, $NullDamageType] = 1.0;

$DamageScale[ProbeDroid, $ImpactDamageType] = 1.0;
$DamageScale[ProbeDroid, $BulletDamageType] = 1.0;
$DamageScale[ProbeDroid, $PlasmaDamageType] = 1.0;
$DamageScale[ProbeDroid, $EnergyDamageType] = 1.0;
$DamageScale[ProbeDroid, $ExplosionDamageType] = 1.0;
$DamageScale[ProbeDroid, $ShrapnelDamageType] = 1.0;
$DamageScale[ProbeDroid, $DebrisDamageType] = 1.0;
$DamageScale[ProbeDroid, $MissileDamageType] = 1.0;
$DamageScale[ProbeDroid, $LaserDamageType] = 1.0;
$DamageScale[ProbeDroid, $MortarDamageType] = 1.0;
$DamageScale[ProbeDroid, $BlasterDamageType] = 0.5;
$DamageScale[ProbeDroid, $ElectricityDamageType] = 1.0;
$DamageScale[ProbeDroid, $MineDamageType]        = 1.0;
$DamageScale[ProbeDroid, $FusionDamageType] = 1.5;
$DamageScale[ProbeDroid, $DisruptorDamageType] = 1.0;
$DamageScale[ProbeDroid, $IonDamageType] = 2.2;
$DamageScale[ProbeDroid, $VulcanDamageType] = 1.0;
$DamageScale[ProbeDroid, $ShotgunDamageType] = 1.0;
$DamageScale[ProbeDroid, $NukeDamageType] = 10.0;
$DamageScale[ProbeDroid, $ZapDamageType] = 2.0;
$DamageScale[ProbeDroid, $HeatDamageType] = 1.0;
$DamageScale[ProbeDroid, $ATCDamageType] = 1.0;
$DamageScale[ProbeDroid, $StarDamageType] = 1.0;
$DamageScale[ProbeDroid, $ShockwaveDamageType] = 1.0;
$DamageScale[ProbeDroid, $PBWDamageType] = 1.0;
$DamageScale[ProbeDroid, $FlameDamageType] = 1.0;
$DamageScale[ProbeDroid, $IceDamageType] = 1.0;
$DamageScale[ProbeDroid, $BurstDamageType] = 1.0;
$DamageScale[ProbeDroid, $ReaverDamageType] = 1.0;
$DamageScale[ProbeDroid, $RifleDamageType] = 1.0;
$DamageScale[ProbeDroid, $MassShotgunDamageType] = 1.0;
$DamageScale[ProbeDroid, $GaussDamageType] = 1.0;
$DamageScale[ProbeDroid, $MBDamageType] = 1.0;
$DamageScale[ProbeDroid, $NullDamageType] = 1.0;

$DamageScale[Scout, $ImpactDamageType] = 1.0;
$DamageScale[Scout, $BulletDamageType] = 1.0;
$DamageScale[Scout, $PlasmaDamageType] = 1.0;
$DamageScale[Scout, $EnergyDamageType] = 1.0;
$DamageScale[Scout, $ExplosionDamageType] = 1.0;
$DamageScale[Scout, $ShrapnelDamageType] = 1.0;
$DamageScale[Scout, $DebrisDamageType] = 1.0;
$DamageScale[Scout, $MissileDamageType] = 1.0;
$DamageScale[Scout, $LaserDamageType] = 1.0;
$DamageScale[Scout, $MortarDamageType] = 1.0;
$DamageScale[Scout, $BlasterDamageType] = 0.5;
$DamageScale[Scout, $ElectricityDamageType] = 1.0;
$DamageScale[Scout, $MineDamageType]        = 1.0;

$DamageScale[LAPC, $ImpactDamageType] = 1.0;
$DamageScale[LAPC, $BulletDamageType] = 1.0;
$DamageScale[LAPC, $PlasmaDamageType] = 1.0;
$DamageScale[LAPC, $EnergyDamageType] = 1.0;
$DamageScale[LAPC, $ExplosionDamageType] = 1.0;
$DamageScale[LAPC, $ShrapnelDamageType] = 1.0;
$DamageScale[LAPC, $DebrisDamageType] = 1.0;
$DamageScale[LAPC, $MissileDamageType] = 1.0;
$DamageScale[LAPC, $LaserDamageType] = 0.5;
$DamageScale[LAPC, $MortarDamageType] = 1.0;
$DamageScale[LAPC, $BlasterDamageType] = 0.5;
$DamageScale[LAPC, $ElectricityDamageType] = 1.0;
$DamageScale[LAPC, $MineDamageType]        = 1.0;

$DamageScale[HAPC, $ImpactDamageType] = 1.0;
$DamageScale[HAPC, $BulletDamageType] = 1.0;
$DamageScale[HAPC, $PlasmaDamageType] = 1.0;
$DamageScale[HAPC, $EnergyDamageType] = 1.0;
$DamageScale[HAPC, $ExplosionDamageType] = 1.0;
$DamageScale[HAPC, $ShrapnelDamageType] = 1.0;
$DamageScale[HAPC, $DebrisDamageType] = 1.0;
$DamageScale[HAPC, $MissileDamageType] = 1.0;
$DamageScale[HAPC, $LaserDamageType] = 0.5;
$DamageScale[HAPC, $MortarDamageType] = 1.0;
$DamageScale[HAPC, $BlasterDamageType] = 0.5;
$DamageScale[HAPC, $ElectricityDamageType] = 1.0;
$DamageScale[HAPC, $MineDamageType]        = 1.0;

//----------------------------------------------------------------------------

function Vehicle::onAdd(%this)
{	
	%this.isMarked=false;
	GameBase::setRechargeRate (%this, 0);
	GameBase::setMapName (%this, "Vehicle");

 	if(GameBase::getDataName(%this) == Scout) 
	{	GameBase::setMapName (%this, "Scout");
		%this.shieldStrength = 0;
		GameBase::setRechargeRate (%this, 1);
	}
	else if(GameBase::getDataName(%this) == LAPC)
	{	GameBase::setMapName (%this, "LPC");
		%this.shieldStrength = 0.001;
		GameBase::setRechargeRate (%this, 1);
	}
	else if(GameBase::getDataName(%this) == HAPC) 
	{	GameBase::setMapName (%this, "HPC");
		%this.shieldStrength = 0.002;
		GameBase::setRechargeRate (%this, 1);
	}
	else if(GameBase::getDataName(%this) == HoverTank) 
	{	GameBase::setMapName (%this, "Hover Tank");
		%this.shieldStrength = 0.01;
		GameBase::setRechargeRate (%this, 1);
	}
	else if(GameBase::getDataName(%this) == StarHammer) 
	{	GameBase::setMapName (%this, "Star Hammer");
		%this.shieldStrength = 0.0001;
		GameBase::setRechargeRate (%this, 4);
	}
	else if(GameBase::getDataName(%this) == Arwing) 
	{	GameBase::setMapName (%this, "Arwing");
		%this.shieldStrength = 0.00375;
		GameBase::setRechargeRate (%this, 1);
	}
	else if(GameBase::getDataName(%this) == SkyCutter) 
	{	GameBase::setMapName (%this, "Sky Cutter");
		%this.shieldStrength = 0;
		GameBase::setRechargeRate (%this, 0);
	}
 	if(GameBase::getDataName(%this) == EscapePod) 
	{	GameBase::setMapName (%this, "Lightning");
		%this.shieldStrength = 0.0025;
		GameBase::setRechargeRate (%this, 0.5);
	}
	else if(GameBase::getDataName(%this) == Skyranger) 
	{	GameBase::setMapName (%this, "Skyranger");
		%this.shieldStrength = 0.0025;
		GameBase::setRechargeRate (%this, 1);
	}
	else if(GameBase::getDataName(%this) == StarFighter) 
	{	GameBase::setMapName (%this, "StarFighter");
		%this.shieldStrength = 0.1;
		GameBase::setRechargeRate (%this, 0);
	}
	else if(GameBase::getDataName(%this) == Avenger) 
	{	GameBase::setMapName (%this, "Avenger");
		%this.shieldStrength = 0.003;
		GameBase::setRechargeRate (%this, 0.5);
	}
	else if(GameBase::getDataName(%this) == Explorer) 
	{	GameBase::setMapName (%this, "Explorer");
		%this.shieldStrength = 0.001;
		GameBase::setRechargeRate (%this, 2);
	}
	else if(GameBase::getDataName(%this) == Interceptor) 
	{	GameBase::setMapName (%this, "Valkyrie Interceptor");
		%this.shieldStrength = 0.0006;
		GameBase::setRechargeRate (%this, 2);
	}

}

function Vehicle::onCollision (%this, %object)
{
	if(GameBase::getDamageLevel(%this) < (GameBase::getDataName(%this)).maxDamage) {
		if (getObjectType (%object) == "Player" && %object.vehicle == "" && (getSimTime() > %object.newMountTime || %object.lastMount != %this) && %this.fading == "")
			{
       //     	if(Player::isAiControlled(%object))
	   //            return;
               
				%armor = Player::getArmor(%object);
		      %client = Player::getClient(%object);
//#Modification #1	if ((%armor == "larmor" || %armor == "lfemale") && Vehicle::canMount (%this, %object))
				if ((%armor == "larmor" || %armor == "lfemale" || %armor == "marmor" || %armor == "mfemale" || %armor == "harmor") && Vehicle::canMount (%this, %object))
					{
					if (!Player::isAiControlled(%object))  //No bots allowed as drivers!! Only as passengers!
						{
						%weapon = Player::getMountedItem(%object,$WeaponSlot);
						if(%weapon != -1) {
							%object.lastWeapon = %weapon;
							Player::unMountItem(%object,$WeaponSlot);
							}
						Player::setMountObject(%object, %this, 1);
						Client::setControlObject(%client, %this);
						playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
						%object.driver= 1;
						%object.vehicle = %this;
						%this.clLastMount = %client;
						$Spoonbot::IsPilot[%client] = True;
						BotFuncs::BotsHopOn(%client);
						}
					}
//#Modification #2		else if(GameBase::getDataName(%this) != Scout) 
				else if(GameBase::getDataName(%this) != Scout || (%this) != EscapePod || (%this) != Jetfire || (%this) != SurveyDrone || (%this) !=  ProbeDroid || (%this) != Drone || (%this) != Scout || (%this) != EOMissile || (%this) != ScouterMissile || (%this) != Arwing || (%this) != SkyCutter || (%this) != StarHammer || (%this) != Explorer || (%this) != Skyranger || (%this) != Icarus || (%this) != Avenger || (%this) != StarFighter)   
					{
					 	%mountSlot= Vehicle::findEmptySeat(%this,%client); 
						if(%mountSlot) 
							{
								%object.vehicleSlot = %mountSlot;
								%object.vehicle = %this;
								Player::setMountObject(%object, %this, %mountSlot);
								playSound (GameBase::getDataName(%this).mountSound, GameBase::getPosition(%this));
							}
					}
				else if (GameBase::getControlClient(%this) == -1){}
//#Modification #3		Client::sendMessage(Player::getClient(%object),0,"You must be in Light Armor to pilot the vehicles.~wError_Message.wav");
			}
	}
}

function Vehicle::findEmptySeat(%this,%client)
{
//#M4	if(GameBase::getDataName(%this) == HAPC)
	if(GameBase::getDataName(%this) == HAPC || (%this) == HoverTank)
		%numSlots = 4;
	else
		%numSlots = 2;
	%count=0;
	for(%i=0;%i<%numSlots;%i++)  
		if(%this.Seat[%i] == "") {
			%slotPos[%count] = Vehicle::getMountPoint(%this,%i+2);
			%slotVal[%count] = %i+2;
			%lastEmpty = %i+2;
			%count++;
		}
	if(%count == 1) {
		%this.Seat[%lastEmpty-2] = %client;
		return %lastEmpty;
	}
	else if (%count > 1)	{
		%freeSlot = %slotVal[getClosestPosition(%count,GameBase::getPosition(%client),%slotPos[0],%slotPos[1],%slotPos[2],%slotPos[3])];
		%this.Seat[%freeSlot-2] = %client;
		return %freeSlot;
	}
	else
		return "False";
}

function getClosestPosition(%num,%playerPos,%slotPos0,%slotPos1,%slotPos2,%slotPos3)
{
	%playerX = getWord(%playerPos,0);
	%playerY = getWord(%playerPos,1);
	for(%i = 0 ;%i<%num;%i++) {
		%x = (getWord(%slotPos[%i],0)) - %playerX;
		%y = (getWord(%slotPos[%i],1)) - %playerY;
		if(%x < 0)
			%x *= -1;
		if(%y < 0)
			%y *= -1;
		%newDistance = sqrt((%x*%x)+(%y*%y));
		if(%newDistance < %distance || %distance == "") {
	  		%distance = %newDistance;			
			%closePos = %i;	
		}
	}		
	return %closePos;
}

function Vehicle::passengerJump(%this,%passenger,%mom)
{
	%armor = Player::getArmor(%passenger);
	if(%armor == "larmor" || %armor == "lfemale") {
		%height = 2;
		%velocity = 70;
		%zVec = 70;
	}
	else if(%armor == "marmor" || %armor == "mfemale") {
		%height = 2;
		%velocity = 100;
		%zVec = 100;
	}
	else if(%armor == "harmor") {
		%height = 2;
		%velocity = 140;
		%zVec = 110;
	}

	%pos = GameBase::getPosition(%passenger);
	%posX = getWord(%pos,0);
	%posY	= getWord(%pos,1);
	%posZ	= getWord(%pos,2);

	if(GameBase::testPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height))) {	
		%client = Player::getClient(%passenger);
		%this.Seat[%passenger.vehicleSlot-2] = "";
		%passenger.vehicleSlot = "";
	   %passenger.vehicle= "";
		Player::setMountObject(%passenger, -1, 0);
		%rotZ = getWord(GameBase::getRotation(%passenger),2);
		GameBase::setRotation(%passenger, "0 0 " @ %rotZ);
		GameBase::setPosition(%passenger,%posX @ " " @ %posY @ " " @ (%posZ + %height));
		%jumpDir = Vector::getFromRot(GameBase::getRotation(%passenger),%velocity,%zVec);
		Player::applyImpulse(%passenger,%jumpDir);

		if ($Spoonbot::IsPilot[%client]==True)  //It's a human who was piloting this thing, so make all riding bots bail out too.
		{
			BotsHopOff(%client);
		}

	}
	else
		Client::sendMessage(Player::getClient(%passanger),0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
}

function Vehicle::jump(%this,%mom)
{
   Vehicle::dismount(%this,%mom);
}

function Vehicle::dismount(%this,%mom)
{
   %cl = GameBase::getControlClient(%this);
   if(%cl != -1)
   {
	if(GameBase::getDataName(%this) == "Jetfire")
	{
		Jetfire::Dismount(%this, %cl);
		return;
	}
      %pl = Client::getOwnedObject(%cl);
      if(getObjectType(%pl) == "Player")
      {
		   // dismount the player	  
			if(GameBase::testPosition(%pl, Vehicle::getMountPoint(%this,0))) {
				%pl.lastMount = %this;
				%pl.newMountTime = getSimTime() + 3.0;
				Player::setMountObject(%pl, %this, 0);
        	 	Player::setMountObject(%pl, -1, 0);
				%rot = GameBase::getRotation(%this);
				%rotZ = getWord(%rot,2);
				GameBase::setRotation(%pl, "0 0 " @ %rotZ);
				Player::applyImpulse(%pl,%mom);
        	 	Client::setControlObject(%cl, %pl);
				playSound (GameBase::getDataName(%this).dismountSound, GameBase::getPosition(%this));
				if(%pl.lastWeapon != "") {
					Player::useItem(%pl,%pl.lastWeapon);		 	
					%pl.lastWeapon = "";

			if ($Spoonbot::IsPilot[%cl]==True)  //It's a human who was piloting this thing, so make all riding bots bail out too.
			{
				BotsHopOff(%cl);
			}
			if ($Spoonbot::IsPilot[%pl]==True)  //It's a human who was piloting this thing, so make all riding bots bail out too.
			{
				BotsHopOff(%pl);
			}


      		}
				%pl.driver = "";
				%pl.vehicle = "";
			}
			else
				Client::sendMessage(%cl,0,"Can not dismount - Obstacle in the way.~wError_Message.wav");
		}
   }
}

function Vehicle::onDestroyed (%this,%mom)
{
//	if($testcheats || $servercheats)
	$TeamItemCount[GameBase::getTeam(%this) @ $VehicleToItem[GameBase::getDataName(%this)]]--;
   %cl = GameBase::getControlClient(%this);
	%pl = Client::getOwnedObject(%cl);
	if(%pl != -1) {
	   Player::setMountObject(%pl, -1, 0);
   	Client::setControlObject(%cl, %pl);
		if(%pl.lastWeapon != "") {
			Player::useItem(%pl,%pl.lastWeapon);		 	
			%pl.lastWeapon = "";
		}
		%pl.driver = "";
	}

	if ($Spoonbot::IsPilot[%cl]==True)  //It's a human who was piloting this thing, so make all riding bots bail out too.
	{
		BotsHopOff(%cl);
	}
	if ($Spoonbot::IsPilot[%pl]==True)  //It's a human who was piloting this thing, so make all riding bots bail out too.
	{
		BotsHopOff(%pl);
	}

	for(%i = 0 ; %i < 4 ; %i++)
		if(%this.Seat[%i] != "") {
			%pl = Client::getOwnedObject(%this.Seat[%i]);
		   Player::setMountObject(%pl, -1, 0);
	  	 	Client::setControlObject(%this.Seat[%i], %pl);
		}
	calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 2, 0.55, 
		0.1, 225, 100); 
}

function Vehicle::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
	%value *= $damageScale[GameBase::getDataName(%this), %type];
	StaticShape::onDamage(%this,%type,%value,%pos,%vec,%mom,%object);
	if(%type == $EMPDamageType) {
		#GameBase::setEnergy(%this,0);
		GameBase::setRechargeRate(%this,0);
		Vehicle::onSelfDestruckt(%this); //dependant on the energy the flier has, is how long before the engines  "self destruct" hehehe
	}
}

function Vehicle::getHeatFactor(%this)
{
	// Not getting called right now because turrets don't track
	// vehicles.  A hack has been placed in Player::getHeatFactor.
   return 1.0;
}