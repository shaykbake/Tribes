//=============================================================================================
# Damage Types

$six66                 = -3;
$ImpactDamageType      = -1;
$LandingDamageType     =  0;
$BulletDamageType      =  1;
$EnergyDamageType      =  2;
$PlasmaDamageType      =  3;
$ExplosionDamageType   =  4;
$ShrapnelDamageType    =  5;
$LaserDamageType       =  6;
$MortarDamageType      =  7;
$BlasterDamageType     =  8;
$ElectricityDamageType =  9;
$CrushDamageType       = 10;
$DebrisDamageType      = 11;
$MissileDamageType     = 12;
$MineDamageType        = 13;
$EMPDamageType         = 14;
$SniperDamageType      = 15;
$ShotgunDamageType     = 16;
$MBDamageType          = 17;
$FlierBombDamageType   = 18;
$PulseDamageType       = 19;
$MBHeatDamageType      = 20;
$NullDamageType        = 21;
$TractorDamageType     = 22;
$EnergyTurretDamageType= 23;

//==============================================================================================
// Death Messages - INH*DynaBlade (Majestic 12)
// Maximum allowed messages: 8
// if there is a 9 or ++ then it will not print the selected weapon
// you can have up to 64 suicide messages; but you will strip your ability to print kill
// messages if you exceed 6 (8 in some cases)
//==============================================================================================

$deathMsg[$LandingDamageType, 0]      = "%1 falls to %3 death.";
$deathMsg[$LandingDamageType, 1]      = "%1 forgot to tie %3 bungie cord.";
$deathMsg[$LandingDamageType, 2]      = "%1 bites the dust in a forceful manner.";
$deathMsg[$LandingDamageType, 3]      = "%1 fall down go boom.";

$deathMsg[$ImpactDamageType, 0]      = "%1 makes quite an impact on %2.";
$deathMsg[$ImpactDamageType, 1]      = "%1 says, ''Hey %2, you scratched my paint job!''";
$deathMsg[$ImpactDamageType, 2] 	= "%1 shows %2 his new ride";
$deathMsg[$ImpactDamageType, 3] 	= "%1 shoves %2 into his jet thrust.";

$deathMsg[$BulletDamageType, 0]      = "%1 ventilates %2 with %3 chaingun.";
$deathMsg[$BulletDamageType, 1]      = "%1 gives %2 an overdose of lead.";
$deathMsg[$BulletDamageType, 2]      = "%1 turns %2 into swiss cheese.";
$deathMsg[$BulletDamageType, 3]      = "%2 felt like being Holy.";

$deathMsg[$EnergyDamageType, 0]      = "%1 wonders ''hey, what's this thing do?''";
$deathMsg[$EnergyDamageType, 1]      = "%1 got hit with a blast of energy.";
$deathMsg[$EnergyDamageType, 2]      = "%1 came face to face with an energy blast, and was later found dead.";
$deathMsg[$EnergyDamageType, 3]      = "%1 figures out what that pretty light was.";

$deathMsg[$PlasmaDamageType, 0]      = "%2 feels the warm glow of %1's plasma.";
$deathMsg[$PlasmaDamageType, 1]      = "%1 gives %2 a plasma transfusion.";
$deathMsg[$PlasmaDamageType, 2] 	 = "%1 asks %2, ''Need a light?''";
$deathMsg[$PlasmaDamageType, 3] 	 = "%2 saw %3 life before his eyes, or at least %1's glowing plasma.";

$deathMsg[$ExplosionDamageType, 0]   = "%2 catches a Frisbee of Death thrown by %1.";
$deathMsg[$ExplosionDamageType, 1]   = "%1 blasts %2 with a well-placed disc.";
$deathMsg[$ExplosionDamageType, 2]   = "%1's spinfusor caught %2 by surprise.";
$deathMsg[$ExplosionDamageType, 3]   = "%2 falls victim to %1's Stormhammer.";

$deathMsg[$ShrapnelDamageType, 0]    = "%1 blows %2 up real good.";
$deathMsg[$ShrapnelDamageType, 1]    = "%2 gets a taste of %1's explosive temper.";
$deathMsg[$ShrapnelDamageType, 2]    = "%1 gives %2 a fatal concussion.";
$deathMsg[$ShrapnelDamageType, 3]    = "%2 never saw it coming from %1.";

$deathMsg[$LaserDamageType, 0]       = "%2 is blown to bits by %1's beam.";
$deathMsg[$LaserDamageType, 1]       = "%2 becomes a victim of %1's beam of pain.";
$deathMsg[$LaserDamageType, 2]       = "%2 has a hole fried through %4 head by %1.";
$deathMsg[$LaserDamageType, 3]       = "%1 Lightly Amplified %2's Stimulated Emission of Radiation.";

$deathMsg[$MortarDamageType, 0]      = "%1 mortars %2 into oblivion.";
$deathMsg[$MortarDamageType, 1]      = "%2 didn't see that last mortar from %1.";
$deathMsg[$MortarDamageType, 2]      = "%1 inflicts a mortal mortar wound on %2.";
$deathMsg[$MortarDamageType, 3]      = "%1 blew %2 all to pieces.";

$deathMsg[$BlasterDamageType, 0]     = "%2 succumbs to %1's rain of blaster fire.";
$deathMsg[$BlasterDamageType, 1]     = "%1's puny blaster shows %2 a new world of pain.";
$deathMsg[$BlasterDamageType, 2]     = "%2 meets %1's master blaster.";
$deathMsg[$BlasterDamageType, 3] 	 = "%2 couldn't steer clear of %1's Blaster.";

$deathMsg[$ElectricityDamageType, 1] = "%1 gives %2 a nasty jolt.";
$deathMsg[$ElectricityDamageType, 2] = "%2 gets a real shock out of meeting %1.";
$deathMsg[$ElectricityDamageType, 3] = "%1 short-circuits %2's systems.";
$deathMsg[$ElectricityDamageType, 4] = "%2 caught a few volts.";

$deathMsg[$CrushDamageType, 0]	 = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 1]	 = "%2 gets caught in the machinery.";
$deathMsg[$CrushDamageType, 2]	 = "%2 didn't stay away from the moving parts.";
$deathMsg[$CrushDamageType, 3]	 = "%2 got a great deal for pizza.";

$deathMsg[$DebrisDamageType, 0]	 = "%2 is a victim among the wreckage.";
$deathMsg[$DebrisDamageType, 1]	 = "%2 is killed by debris.";
$deathMsg[$DebrisDamageType, 2]	 = "%2 becomes a victim of collateral damage.";
$deathMsg[$DebrisDamageType, 3]	 = "%2 got too close to the exploding stuff.";

$deathMsg[$MissileDamageType, 0]	 = "%2 takes a missile up the keister.";
$deathMsg[$MissileDamageType, 1] 	 = "%2 gets buttraped by a warhead.";
$deathMsg[$MissileDamageType, 2]  	 = "%2 played dodgeball with a rocket...And lost.";
$deathMsg[$MissileDamageType, 3] 	 = "%2 rides the rocket.";

$deathMsg[$MineDamageType, 0]	       = "%2 stepped on a toe-popper.";
$deathMsg[$MineDamageType, 1] 	 = "%1 gives %2 a piece of %3 mine.";
$deathMsg[$MineDamageType, 2] 	 = "%1 reminds %2 that a mine is a terrible thing to waste.";
$deathMsg[$MineDamageType, 3] 	 = "%2 is blown to bits by %1's mine.";

$deathMsg[$SniperDamageType, 0]	 = "%2 never saw it coming from %1.";
$deathMsg[$SniperDamageType, 1]      = "%1 tells %2 you zigged when you should have zagged.";
$deathMsg[$SniperDamageType, 2] 	 = "%1 gave %2 a shot right between the eyes.";
$deathMsg[$SniperDamageType, 3]	 = "%1 takes a pot shot at %2.";

$deathMsg[$ShotgunDamageType, 0]	 = "%1's Photon Cannon electricutes %2's vital parts.";
$deathMsg[$ShotgunDamageType, 1]	 = "%1 shoots %2 and zaps %3 head clean off their body.";
$deathMsg[$ShotgunDamageType, 2] 	 = "%2 caught a chest full of %1's Photonic Blast."; 
$deathMsg[$ShotgunDamageType, 3] 	 = "%2 has a hole punched through %3 by %1."; 

$deathMsg[$MBDamageType, 0]      	 = "%2 is blown away.";
$deathMsg[$MBDamageType, 1]      	 = "%1 gives %2 an overload of shear energy.";
$deathMsg[$MBDamageType, 2]      	 = "%1 fills %2 with a hyperactive blast.";
$deathMsg[$MBDamageType, 3]      	 = "%1 lets %4 Mitzi Blast eat %2 alive.";

$deathMsg[$FlierBombDamageType, 0]	 = "%2 got killed by a bomb.";
$deathMsg[$FlierBombDamageType, 1]	 = "%2 got bombed by %1.";
$deathMsg[$FlierBombDamageType, 2]	 = "%1 let his bombs loose on %2.";
$deathMsg[$FlierBombDamageType, 3] 	 = "%1 bombed the crap outa %2."; 

$deathMsg[$PulseDamageType, 0]	 = "%1's Annihilator Blast vaporizes %2.";
$deathMsg[$PulseDamageType, 1]	 = "%2 has been reduced to his componet atoms by %1's Annihilator blast.";
$deathMsg[$PulseDamageType, 2]	 = "%1 used the Force on %2.";
$deathMsg[$PulseDamageType, 3]	 = "%1 sends %2 clear through the next dimension.";

$deathMsg[$TractorDamageType, 0] = "%2 gets ripped apart.";
$deathMsg[$TractorDamageType, 1] = "%2 gets torn into pieces.";
$deathMsg[$TractorDamageType, 2] = "%2 gets pulled apart.";
$deathMsg[$TractorDamageType, 3] = "%2 came apart at the seams.";

$deathMsg[$EnergyTurretDamageType, 0]      = "%1 ends up on the wrong side of a turret.";
$deathMsg[$EnergyTurretDamageType, 1]      = "%1 loses a game of chicken with a turret.";
$deathMsg[$EnergyTurretDamageType, 2]      = "%1 managed to find the enemy turrets.";
$deathMsg[$EnergyTurretDamageType, 3]      = "%1 figures out what all those pretty lights are.";

$deathMsg[-2,0]                                          = "%1 wanted to make sure %2 gun was loaded.";
$deathMsg[-2,1]                                          = "%1 was last heard yelling ''death before dishonor!''"; 
$deathMsg[-2,2]                                          = "%1 shows off %2 mad dying skills.";
$deathMsg[-2,3]                                          = "%1 says: The Borg assimilated me & all I got was this stupid T-Shirt!";

$deathMsg[-3,0]                                          = "%2 wanted to make sure %2 gun was loaded.";
$deathMsg[-3,1]                                          = "%2 was last heard yelling ''death before dishonor!''"; 
$deathMsg[-3,2]                                          = "%2 shows off %2 mad dying skills.";
$deathMsg[-3,3]                                          = "%2 says: The Borg assimilated me & all I got was this stupid T-Shirt!";

$numDeathMsgs = 4;

//#############################################################################################

//=========Damage defs here

$DamageScale[larmor, $PulseDamageType] = 1.0;
$DamageScale[marmor, $PulseDamageType] = 1.0;
$DamageScale[harmor, $PulseDamageType] = 1.0;
$DamageScale[lfemale, $PulseDamageType] = 1.0;
$DamageScale[mfemale, $PulseDamageType] = 1.0;
$DamageScale[BlastechM, $PulseDamageType] = 1.0;
$DamageScale[MagIonM, $PulseDamageType] = 1.0;
$DamageScale[MECH, $PulseDamageType] = 1.0;
$DamageScale[BlastechF, $PulseDamageType] = 1.0;
$DamageScale[MagIonF, $PulseDamageType] = 1.0;
$DamageScale[sarmor, $PulseDamageType] = 1.0;
$DamageScale[sfemale, $PulseDamageType] = 1.0;
$DamageScale[mearmor, $PulseDamageType] = 1.0;
$DamageScale[ebarmor, $PulseDamageType] = 1.0;
$DamageScale[ebfemale, $PulseDamageType] = 1.0;

$DamageScale[Scout, $PulseDamageType] = 1.0;
$DamageScale[EscapePod, $PulseDamageType] = 1.0;
$DamageScale[Jetfire, $PulseDamageType] = 1.0;
$DamageScale[LAPC, $PulseDamageType] = 1.0;
$DamageScale[HAPC, $PulseDamageType] = 1.0;
$DamageScale[ScouterMissile, $PulseDamageType] = 1.0;
$DamageScale[CameraDrone, $PulseDamageType] = 1.0;
$DamageScale[SurveyDrone, $PulseDamageType] = 1.0;
$DamageScale[Retaliator, $PulseDamageType] = 1.0;
$DamageScale[Interceptor, $PulseDamageType] = 1.0;
$DamageScale[HoverTank, $PulseDamageType] = 1.0;
$DamageScale[Explorer, $PulseDamageType] = 1.0;
$DamageScale[Avenger, $PulseDamageType] = 1.0;
$DamageScale[StarFighter, $PulseDamageType] = 1.0;
$DamageScale[Icarus, $PulseDamageType] = 1.0;
$DamageScale[Skyranger, $PulseDamageType] = 1.0;
$DamageScale[StarHammer, $PulseDamageType] = 1.0;
$DamageScale[SkyCutter, $PulseDamageType] = 1.0;
$DamageScale[Arwing, $PulseDamageType] = 1.0;

$DamageScale[larmor, $FlierBombDamageType] = 1.0;
$DamageScale[marmor, $FlierBombDamageType] = 1.0;
$DamageScale[harmor, $FlierBombDamageType] = 1.0;
$DamageScale[lfemale, $FlierBombDamageType] = 1.0;
$DamageScale[mfemale, $FlierBombDamageType] = 1.0;
$DamageScale[BlastechM, $FlierBombDamageType] = -0.3;
$DamageScale[MagIonM, $FlierBombDamageType] = 1;
$DamageScale[MECH, $FlierBombDamageType] = 0.95;
$DamageScale[BlastechF, $FlierBombDamageType] = -0.3;
$DamageScale[MagIonF, $FlierBombDamageType] = 1;
$DamageScale[sarmor, $FlierBombDamageType] = 1.0;
$DamageScale[sfemale, $FlierBombDamageType] = 1.0;
$DamageScale[mearmor, $FlierBombDamageType] = 1.0;
$DamageScale[ebarmor, $FlierBombDamageType] = 1.0;
$DamageScale[ebfemale, $FlierBombDamageType] = 1.0;

$DamageScale[Scout, $FlierBombDamageType] = 1.0;
$DamageScale[EscapePod, $FlierBombDamageType] = 1.0;
$DamageScale[Jetfire, $FlierBombDamageType] = 1.0;
$DamageScale[LAPC, $FlierBombDamageType] = 1.0;
$DamageScale[HAPC, $FlierBombDamageType] = 1.0;
$DamageScale[ScouterMissile, $FlierBombDamageType] = 1.0;
$DamageScale[CameraDrone, $FlierBombDamageType] = 1.0;
$DamageScale[SurveyDrone, $FlierBombDamageType] = 1.0;
$DamageScale[Retaliator, $FlierBombDamageType] = 1.0;
$DamageScale[Interceptor, $FlierBombDamageType] = 1.0;
$DamageScale[HoverTank, $FlierBombDamageType] = 1.0;
$DamageScale[Explorer, $FlierBombDamageType] = 1.0;
$DamageScale[Avenger, $FlierBombDamageType] = 1.0;
$DamageScale[StarFighter, $FlierBombDamageType] = 1.0;
$DamageScale[Icarus, $FlierBombDamageType] = 1.0;
$DamageScale[Skyranger, $FlierBombDamageType] = 1.0;
$DamageScale[StarHammer, $FlierBombDamageType] = 1.0;
$DamageScale[SkyCutter, $FlierBombDamageType] = 1.0;
$DamageScale[Arwing, $FlierBombDamageType] = 1.0;

$DamageScale[larmor, $MBHeatDamageType] = 1.0;
$DamageScale[marmor, $MBHeatDamageType] = 1.0;
$DamageScale[harmor, $MBHeatDamageType] = 1.0;
$DamageScale[lfemale, $MBHeatDamageType] = 1.0;
$DamageScale[mfemale, $MBHeatDamageType] = 1.0;
$DamageScale[BlastechM, $MBHeatDamageType] = 1;
$DamageScale[MagIonM, $MBHeatDamageType] = 1;
$DamageScale[MECH, $MBHeatDamageType] = -0.1;
$DamageScale[BlastechF, $MBHeatDamageType] = 1;
$DamageScale[MagIonF, $MBHeatDamageType] = 1;
$DamageScale[sarmor, $MBHeatDamageType] = 1.0;
$DamageScale[sfemale, $MBHeatDamageType] = 1.0;
$DamageScale[mearmor, $MBHeatDamageType] = 1.0;
$DamageScale[ebarmor, $MBHeatDamageType] = 1.0;
$DamageScale[ebfemale, $MBHeatDamageType] = 1.0;

$DamageScale[Scout, $MBHeatDamageType] = 1.0;
$DamageScale[EscapePod, $MBHeatDamageType] = 1.0;
$DamageScale[Jetfire, $MBHeatDamageType] = 1.0;
$DamageScale[LAPC, $MBHeatDamageType] = 1.0;
$DamageScale[HAPC, $MBHeatDamageType] = 1.0;
$DamageScale[ScouterMissile, $MBHeatDamageType] = 1.0;
$DamageScale[CameraDrone, $MBHeatDamageType] = 1.0;
$DamageScale[SurveyDrone, $MBHeatDamageType] = 1.0;
$DamageScale[Retaliator, $MBHeatDamageType] = 1.0;
$DamageScale[Interceptor, $MBHeatDamageType] = 1.0;
$DamageScale[HoverTank, $MBHeatDamageType] = 1.0;
$DamageScale[Explorer, $MBHeatDamageType] = 1.0;
$DamageScale[Avenger, $MBHeatDamageType] = 1.0;
$DamageScale[StarFighter, $MBHeatDamageType] = 1.0;
$DamageScale[Icarus, $MBHeatDamageType] = 1.0;
$DamageScale[Skyranger, $MBHeatDamageType] = 1.0;
$DamageScale[StarHammer, $MBHeatDamageType] = 1.0;
$DamageScale[SkyCutter, $MBHeatDamageType] = 1.0;
$DamageScale[Arwing, $MBHeatDamageType] = 1.0;

$DamageScale[larmor, $MBDamageType] = 1.0;
$DamageScale[marmor, $MBDamageType] = 1.0;
$DamageScale[harmor, $MBDamageType] = 1.0;
$DamageScale[lfemale, $MBDamageType] = 1.0;
$DamageScale[mfemale, $MBDamageType] = 1.0;
$DamageScale[BlastechM, $MBDamageType] = 1;
$DamageScale[MagIonM, $MBDamageType] = 1;
$DamageScale[MECH, $MBDamageType] = 1;
$DamageScale[BlastechF, $MBDamageType] = 1;
$DamageScale[MagIonF, $MBDamageType] = 1;
$DamageScale[sarmor, $MBDamageType] = 1.0;
$DamageScale[sfemale, $MBDamageType] = 1.0;
$DamageScale[mearmor, $MBDamageType] = 1.0;
$DamageScale[ebarmor, $MBDamageType] = 1.0;
$DamageScale[ebfemale, $MBDamageType] = 1.0;

$DamageScale[Scout, $MBDamageType] = 1.0;
$DamageScale[EscapePod, $MBDamageType] = 1.0;
$DamageScale[Jetfire, $MBDamageType] = 1.0;
$DamageScale[LAPC, $MBDamageType] = 1.0;
$DamageScale[HAPC, $MBDamageType] = 1.0;
$DamageScale[ScouterMissile, $MBDamageType] = 1.0;
$DamageScale[CameraDrone, $MBDamageType] = 1.0;
$DamageScale[SurveyDrone, $MBDamageType] = 1.0;
$DamageScale[Retaliator, $MBDamageType] = 1.0;
$DamageScale[Interceptor, $MBDamageType] = 1.0;
$DamageScale[HoverTank, $MBDamageType] = 1.0;
$DamageScale[Explorer, $MBDamageType] = 1.0;
$DamageScale[Avenger, $MBDamageType] = 1.0;
$DamageScale[StarFighter, $MBDamageType] = 1.0;
$DamageScale[Icarus, $MBDamageType] = 1.0;
$DamageScale[Skyranger, $MBDamageType] = 1.0;
$DamageScale[StarHammer, $MBDamageType] = 1.0;
$DamageScale[SkyCutter, $MBDamageType] = 1.0;
$DamageScale[Arwing, $MBDamageType] = 1.0;

$DamageScale[larmor, $SniperDamageType] = 1.0;
$DamageScale[marmor, $SniperDamageType] = 1.0;
$DamageScale[harmor, $SniperDamageType] = 1.0;
$DamageScale[lfemale, $SniperDamageType] = 1.0;
$DamageScale[mfemale, $SniperDamageType] = 1.0;
$DamageScale[BlastechM, $SniperDamageType] = 1;
$DamageScale[MagIonM, $SniperDamageType] = 1;
$DamageScale[MECH, $SniperDamageType] = 1;
$DamageScale[BlastechF, $SniperDamageType] = 1;
$DamageScale[MagIonF, $SniperDamageType] = 1;
$DamageScale[sarmor, $SniperDamageType] = 1.0;
$DamageScale[sfemale, $SniperDamageType] = 1.0;
$DamageScale[mearmor, $SniperDamageType] = 1.0;
$DamageScale[ebarmor, $SniperDamageType] = 1.0;
$DamageScale[ebfemale, $SniperDamageType] = 1.0;

$DamageScale[Scout, $SniperDamageType] = 1.0;
$DamageScale[EscapePod, $SniperDamageType] = 1.0;
$DamageScale[Jetfire, $SniperDamageType] = 1.0;
$DamageScale[LAPC, $SniperDamageType] = 1.0;
$DamageScale[HAPC, $SniperDamageType] = 1.0;
$DamageScale[ScouterMissile, $SniperDamageType] = 1.0;
$DamageScale[CameraDrone, $SniperDamageType] = 1.0;
$DamageScale[SurveyDrone, $SniperDamageType] = 1.0;
$DamageScale[Retaliator, $SniperDamageType] = 1.0;
$DamageScale[Interceptor, $SniperDamageType] = 1.0;
$DamageScale[HoverTank, $SniperDamageType] = 1.0;
$DamageScale[Explorer, $SniperDamageType] = 1.0;
$DamageScale[Avenger, $SniperDamageType] = 1.0;
$DamageScale[StarFighter, $SniperDamageType] = 1.0;
$DamageScale[Icarus, $SniperDamageType] = 1.0;
$DamageScale[Skyranger, $SniperDamageType] = 1.0;
$DamageScale[StarHammer, $SniperDamageType] = 1.0;
$DamageScale[SkyCutter, $SniperDamageType] = 1.0;
$DamageScale[Arwing, $SniperDamageType] = 1.0;

$DamageScale[larmor, $ShotgunDamageType] = 1.0;
$DamageScale[marmor, $ShotgunDamageType] = 1.0;
$DamageScale[harmor, $ShotgunDamageType] = 1.0;
$DamageScale[lfemale, $ShotgunDamageType] = 1.0;
$DamageScale[mfemale, $ShotgunDamageType] = 1.0;
$DamageScale[BlastechM, $ShotgunDamageType] = 1;
$DamageScale[MagIonM, $ShotgunDamageType] = 1;
$DamageScale[MECH, $ShotgunDamageType] = 1;
$DamageScale[BlastechF, $ShotgunDamageType] = 1;
$DamageScale[MagIonF, $ShotgunDamageType] = 1;
$DamageScale[sarmor, $ShotgunDamageType] = 1.0;
$DamageScale[sfemale, $ShotgunDamageType] = 1.0;
$DamageScale[mearmor, $ShotgunDamageType] = 1.0;
$DamageScale[ebarmor, $ShotgunDamageType] = 1.0;
$DamageScale[ebfemale, $ShotgunDamageType] = 1.0;

$DamageScale[Scout, $ShotgunDamageType] = 1.0;
$DamageScale[EscapePod, $ShotgunDamageType] = 1.0;
$DamageScale[Jetfire, $ShotgunDamageType] = 1.0;
$DamageScale[LAPC, $ShotgunDamageType] = 1.0;
$DamageScale[HAPC, $ShotgunDamageType] = 1.0;
$DamageScale[ScouterMissile, $ShotgunDamageType] = 1.0;
$DamageScale[CameraDrone, $ShotgunDamageType] = 1.0;
$DamageScale[SurveyDrone, $ShotgunDamageType] = 1.0;
$DamageScale[Retaliator, $ShotgunDamageType] = 1.0;
$DamageScale[Interceptor, $ShotgunDamageType] = 1.0;
$DamageScale[HoverTank, $ShotgunDamageType] = 1.0;
$DamageScale[Explorer, $ShotgunDamageType] = 1.0;
$DamageScale[Avenger, $ShotgunDamageType] = 1.0;
$DamageScale[StarFighter, $ShotgunDamageType] = 1.0;
$DamageScale[Icarus, $ShotgunDamageType] = 1.0;
$DamageScale[Skyranger, $ShotgunDamageType] = 1.0;
$DamageScale[StarHammer, $ShotgunDamageType] = 1.0;
$DamageScale[SkyCutter, $ShotgunDamageType] = 1.0;
$DamageScale[Arwing, $ShotgunDamageType] = 1.0;

$DamageScale[larmor, $NullDamageType] = 0.0;
$DamageScale[marmor, $NullDamageType] = 0.0;
$DamageScale[harmor, $NullDamageType] = 0.0;
$DamageScale[lfemale, $NullDamageType] = 0.0;
$DamageScale[mfemale, $NullDamageType] = 0.0;
$DamageScale[BlastechM, $NullDamageType] = 0.0;
$DamageScale[BlastechF, $NullDamageType] = 0.0;
$DamageScale[MagIonM, $NullDamageType] = 0.0;
$DamageScale[MagIonF, $NullDamageType] = 0.0;
$DamageScale[MECH, $NullDamageType] = 0.0;
$DamageScale[sarmor, $NullDamageType] = 1.0;
$DamageScale[sfemale, $NullDamageType] = 1.0;
$DamageScale[mearmor, $NullDamageType] = 1.0;
$DamageScale[ebarmor, $NullDamageType] = 1.0;
$DamageScale[ebfemale, $NullDamageType] = 1.0;

$DamageScale[Scout, $NullDamageType] = 0.0;
$DamageScale[EscapePod, $NullDamageType] = 0.0;
$DamageScale[Jetfire, $NullDamageType] = 0.0;
$DamageScale[LAPC, $NullDamageType] = 0.0;
$DamageScale[HAPC, $NullDamageType] = 0.0;
$DamageScale[ScouterMissile, $NullDamageType] = 0.0;
$DamageScale[CameraDrone, $NullDamageType] = 0.0;
$DamageScale[SurveyDrone, $NullDamageType] = 0.0;
$DamageScale[Retaliator, $NullDamageType] = 0.0;
$DamageScale[Interceptor, $NullDamageType] = 0.0;
$DamageScale[HoverTank, $NullDamageType] = 0.0;
$DamageScale[Explorer, $NullDamageType] = 0.0;
$DamageScale[Avenger, $NullDamageType] = 0.0;
$DamageScale[StarFighter, $NullDamageType] = 0.0;
$DamageScale[Icarus, $NullDamageType] = 0.0;
$DamageScale[Skyranger, $NullDamageType] = 0.0;
$DamageScale[StarHammer, $NullDamageType] = 0.0;
$DamageScale[SkyCutter, $NullDamageType] = 0.0;
$DamageScale[Arwing, $NullDamageType] = 0.0;

$DamageScale[larmor, $six66] = 1.0;
$DamageScale[marmor, $six66] = 1.0;
$DamageScale[harmor, $six66] = 1.0;
$DamageScale[lfemale, $six66] = 1.0;
$DamageScale[mfemale, $six66] = 1.0;
$DamageScale[BlastechM, $six66] = 1.0;
$DamageScale[BlastechF, $six66] = 1.0;
$DamageScale[MagIonM, $six66] = 1.0;
$DamageScale[MagIonF, $six66] = 1.0;
$DamageScale[MECH, $six66] = 1.0;
$DamageScale[sarmor, $six66] = 1.0;
$DamageScale[sfemale, $six66] = 1.0;
$DamageScale[mearmor, $six66] = 1.0;
$DamageScale[ebarmor, $six66] = 1.0;
$DamageScale[ebfemale, $six66] = 1.0;

$DamageScale[Scout, $six66] = 1.0;
$DamageScale[EscapePod, $six66] = 1.0;
$DamageScale[Jetfire, $six66] = 1.0;
$DamageScale[LAPC, $six66] = 1.0;
$DamageScale[HAPC, $six66] = 1.0;
$DamageScale[ScouterMissile, $six66] = 1.0;
$DamageScale[CameraDrone, $six66] = 1.0;
$DamageScale[SurveyDrone, $six66] = 1.0;
$DamageScale[Retaliator, $six66] = 1.0;
$DamageScale[Interceptor, $six66] = 1.0;
$DamageScale[HoverTank, $six66] = 1.0;
$DamageScale[Explorer, $six66] = 1.0;
$DamageScale[Avenger, $six66] = 1.0;
$DamageScale[StarFighter, $six66] = 1.0;
$DamageScale[Icarus, $six66] = 1.0;
$DamageScale[Skyranger, $six66] = 1.0;
$DamageScale[StarHammer, $six66] = 1.0;
$DamageScale[SkyCutter, $six66] = 1.0;
$DamageScale[Arwing, $six66] = 1.0;

$DamageScale[larmor, $TractorDamageType] = 1.0;
$DamageScale[marmor, $TractorDamageType] = 1.0;
$DamageScale[harmor, $TractorDamageType] = 1.0;
$DamageScale[lfemale, $TractorDamageType] = 1.0;
$DamageScale[mfemale, $TractorDamageType] = 1.0;
$DamageScale[BlastechM, $TractorDamageType] = 1;
$DamageScale[MagIonM, $TractorDamageType] = 1;
$DamageScale[MECH, $TractorDamageType] = 1;
$DamageScale[BlastechF, $TractorDamageType] = 1;
$DamageScale[MagIonF, $TractorDamageType] = 1;
$DamageScale[sarmor, $TractorDamageType] = 1.0;
$DamageScale[sfemale, $TractorDamageType] = 1.0;
$DamageScale[mearmor, $TractorDamageType] = 1.0;
$DamageScale[ebarmor, $TractorDamageType] = 1.0;
$DamageScale[ebfemale, $TractorDamageType] = 1.0;

$DamageScale[larmor, $EnergyTurretDamageType] = 1.0;
$DamageScale[marmor, $EnergyTurretDamageType] = 1.0;
$DamageScale[harmor, $EnergyTurretDamageType] = 1.0;
$DamageScale[lfemale, $EnergyTurretDamageType] = 1.0;
$DamageScale[mfemale, $EnergyTurretDamageType] = 1.0;
$DamageScale[BlastechM, $EnergyTurretDamageType] = 1.0;
$DamageScale[MagIonM, $EnergyTurretDamageType] = 1.0;
$DamageScale[MECH, $EnergyTurretDamageType] = 1.0;
$DamageScale[BlastechF, $EnergyTurretDamageType] = 1.0;
$DamageScale[MagIonF, $EnergyTurretDamageType] = 1.0;
$DamageScale[sarmor, $EnergyTurretDamageType] = 1.0;
$DamageScale[sfemale, $EnergyTurretDamageType] = 1.0;
$DamageScale[mearmor, $EnergyTurretDamageType] = 1.0;
$DamageScale[ebarmor, $EnergyTurretDamageType] = -0.1;
$DamageScale[ebfemale, $EnergyTurretDamageType] = -0.1;

$DamageScale[Scout, $EnergyTurretDamageType] = 1.0;
$DamageScale[EscapePod, $EnergyTurretDamageType] = 1.0;
$DamageScale[Jetfire, $EnergyTurretDamageType] = 1.0;
$DamageScale[LAPC, $EnergyTurretDamageType] = 1.0;
$DamageScale[HAPC, $EnergyTurretDamageType] = 1.0;
$DamageScale[ScouterMissile, $EnergyTurretDamageType] = 1.0;
$DamageScale[CameraDrone, $EnergyTurretDamageType] = 1.0;
$DamageScale[SurveyDrone, $EnergyTurretDamageType] = 1.0;
$DamageScale[Retaliator, $EnergyTurretDamageType] = 1.0;
$DamageScale[Interceptor, $EnergyTurretDamageType] = 1.0;
$DamageScale[HoverTank, $EnergyTurretDamageType] = 1.0;
$DamageScale[Explorer, $EnergyTurretDamageType] = 1.0;
$DamageScale[Avenger, $EnergyTurretDamageType] = 1.0;
$DamageScale[StarFighter, $EnergyTurretDamageType] = 1.0;
$DamageScale[Icarus, $EnergyTurretDamageType] = 1.0;
$DamageScale[Skyranger, $EnergyTurretDamageType] = 1.0;
$DamageScale[StarHammer, $EnergyTurretDamageType] = 1.0;
$DamageScale[SkyCutter, $EnergyTurretDamageType] = 1.0;
$DamageScale[Arwing, $EnergyTurretDamageType] = 1.0;
