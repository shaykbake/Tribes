Meltdown 2.18 created by: |)efender.
using Dynablades meltdown code.

How to install the Meltdown mod!
------------------------------
Unzip to the tribes folder

C:\Dynamix\Tribes\  (or wherever u installed)

Or use the Meltdown bat to start the mod or use the run camand line below.
make a copy of your tribes icon, in the taget line use the line below.


(-DEDICATED Server)
C:\Dynamix\Tribes\InfiniteSpawn.exe tribes -mod Meltdown -dedicated


