# Makes you wonder doesn't it..........
# THIS IS NOT A SHIFTER, RENEGADES, INSOMNIAX OR ANY OTHER MOD COPY! 
# Infact I hate them for not helping me when I neded help.
# This mod is copyrighted (c) 2000 Branden M. Hall
#
# Base Programming by Mega Man 1024
# Debuggin' by {J}MEGA-Man
# Additional programming by: Z_Dog and Valya[AAOD]
# Other people who contributed: [Clu]Clu , Desertfox, Orzax Team, Shayne Hyde, Werewolf

#Server startup variables
$MeltdownInfo = "<f2>In Monoaural (where unavailiable)";  
$Meltdown::JoinMOTD = "( ( ( ( � $ � � � @ M � ) ) ) )";

#Server Anti-TK settings
$Meltdown::TKLimit = 3; 	// How many TKs before he is kicked
$Meltdown::TKBanXs = 2;		// How many times kicked from TKs before he's banned (experimental)

#Server Auto-admin Variables
#Add your ppl who you want to admin when they connect to the server
#You do not need to add the Addr.

$Server::AutoAdmin[16] = "";
$Server::AutoAdmin[17] = "";
$Server::AutoAdmin[18] = "";
$Server::AutoAdmin[19] = "";
$Server::AutoAdmin[20] = "";
$Server::AutoAdmin[21] = "";
$Server::AutoAdmin[22] = "";
$Server::AutoAdmin[23] = "";

$Server::AutoAdminAddr[16] = "";
$Server::AutoAdminAddr[17] = "";
$Server::AutoAdminAddr[18] = "";
$Server::AutoAdminAddr[19] = "";
$Server::AutoAdminAddr[20] = "";
$Server::AutoAdminAddr[21] = "";
$Server::AutoAdminAddr[22] = "";
$Server::AutoAdminAddr[23] = "-=}DM{=-Defender";

