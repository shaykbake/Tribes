################################################################################
# Meltdown Admin User List    			                               #
#==============================================================================#
# Made and tested by the Majestic 12 and INH						 #
# People who contributed: [CLU], <SSA>, Emo1313, Shayne Hyde and [HvC]NateDoGG #
# Email: meltdown@clannorthwind.net								 #
################################################################################

$CurAdminName = "Meltdown";  			// The Auto-Admin name that prompts you when you've been auto-admined by that name.

#######################################################
# Server Public Admin (PA) Passwords                  #
#=====================================================#
# Great for those clan Members who want Admin         #
# Usage: (console) sad("Password");                   # 
# You can add up to 96 differrent PA passwords (0-95) #
#######################################################

$Meltdown::PAPassword[0] = "";
$Meltdown::PAPassword[1] = "";
$Meltdown::PAPassword[2] = "";
$Meltdown::PAPassword[3] = "";
$Meltdown::PAPassword[4] = "";
$Meltdown::PAPassword[5] = "";
$Meltdown::PAPassword[6] = "";
$Meltdown::PAPassword[7] = "";
$Meltdown::PAPassword[8] = "";
$Meltdown::PAPassword[9] = "";
$Meltdown::PAPassword[10] = "";
$Meltdown::PAPassword[11] = "";
$Meltdown::PAPassword[12] = "";
$Meltdown::PAPassword[13] = "";
$Meltdown::PAPassword[14] = "";
$Meltdown::PAPassword[15] = "";

#################################################################################
# Server Sad Password allocation                                                #
#===============================================================================#
# Allows you to have multiple SAD passwords or store other ppl's SAD passwords. #
# MUCH safer than Auto-Admin, but it's manual...                                #
# You can add up to 64 differrent SAD passwords (0-63)                          #
#################################################################################

$Meltdown::SadPassword[0] = "";
$Meltdown::SadPassword[1] = "";
$Meltdown::SadPassword[2] = "";
$Meltdown::SadPassword[3] = "";
$Meltdown::SadPassword[4] = "";
$Meltdown::SadPassword[5] = "";
$Meltdown::SadPassword[6] = "";
$Meltdown::SadPassword[7] = "";

######################################################################
# Server Auto-admin Variables                                        #
#====================================================================#
# Add your ppl who you want to admin when they connect to the server #
# You can have as many as 128 different auto-admin names             #
######################################################################

$Server::AutoAdmin[0] = "";
$Server::AutoAdmin[1] = "";
$Server::AutoAdmin[2] = "";
$Server::AutoAdmin[3] = "";
$Server::AutoAdmin[4] = "";
$Server::AutoAdmin[5] = "";
$Server::AutoAdmin[6] = "";
$Server::AutoAdmin[7] = "";
$Server::AutoAdmin[8] = "";
$Server::AutoAdmin[9] = "";
$Server::AutoAdmin[10] = "";
$Server::AutoAdmin[11] = "";
$Server::AutoAdmin[12] = "";
$Server::AutoAdmin[13] = "";
$Server::AutoAdmin[14] = "";
$Server::AutoAdmin[15] = "";

##############################################################
# IPs have to be placed by IP: then your IP number.          #
# Ex.                                                        #
#                                                            #
# $Server::AutoAdminAddr[99] = "IP:123.456.789.0";           #
# You can have as many as 128 different auto-admin addresses #
##############################################################

$Server::AutoAdminAddr[0] = "";
$Server::AutoAdminAddr[1] = "";
$Server::AutoAdminAddr[2] = "";
$Server::AutoAdminAddr[3] = "";
$Server::AutoAdminAddr[4] = "";
$Server::AutoAdminAddr[5] = "";
$Server::AutoAdminAddr[6] = "";
$Server::AutoAdminAddr[7] = "";
$Server::AutoAdminAddr[8] = "";
$Server::AutoAdminAddr[9] = "";
$Server::AutoAdminAddr[10] = "";
$Server::AutoAdminAddr[11] = "";
$Server::AutoAdminAddr[12] = "";
$Server::AutoAdminAddr[13] = "";
$Server::AutoAdminAddr[14] = "";
$Server::AutoAdminAddr[15] = "";
