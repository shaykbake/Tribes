function BotTargets::Init_Targets()
{
	BotFuncs::ScanObjectTree();
}
