$Server::HostName = "Tribal_Gods Server Ohio";
$Server::Port = "28001";
$Server::HostPublicGame = true;
$Server::MaxPlayers = "6";
$Server::Password = "";
$pref::LastMission = "Broadside";
$Server::Info = "<jc><f1>Buy Your Favorite Setup Then Goto The Tab Menu\nCustomize Character > Spawn Options > Save Current Setup\nWhen you respawn you will have your favs.";// Server information listed on MasterServer List
$Server::MODInfo = "<jc><f1>This Server Has Been Modified, Running:\n <f2>Tribal<f0>_<f1>God<f0>_<f2>Mod<f0>_<f1>v6.5.1\nLast Update: 08-30-03";      // Information listed on server join screen
$Server::JoinMOTD = "<jc><f1>Just leaving it up for testing purposes...\nWebSite: <f2>http://www.tribal-gods.com/\n<f1>Last Update: <f2>11-10-03";// Message of the day listed once connected to the server
//===========================================================================================
// Tribal God Special Server Settings:
$TG::FlagDefencePoints = 1;// Set this to the points to be awarded when a turrent is deployed.

// (Infinite Settings: true = infinite, false = not infinite)
$TG::InfiniteAmmo:DoublePlasma = false;
$TG::InfiniteAmmo:MineLauncher = false;
$TG::InfiniteAmmo:DiscLauncher = false;
$TG::InfiniteAmmo:TankShredder = false;
$TG::InfiniteAmmo:RepairKit = true;
$TG::InfiniteAmmo:Mortar = false;
$TG::InfiniteAmmo:Boosts = true;
$TG::InfiniteAmmo:Grens = true;
$TG::InfiniteAmmo:Mine = false;

$TG::InfiniteDropAmmo = false; // Dropping ammo won't take any of your ammo if this is set to true.
$TG::PublicObsOn = false; // Notify everyone when they are being observed? true = yes false = no.
$TG::GiveallOn = true; // cheats (true = on || false = off)
$TG::LogIps = true; // For the iplogger - true = yes, false = no.

// (True = You will be warned at the defined time, false = you won't)
$TG::TwoMinWarn  = true;
$TG::FiveMinWarn = true;
//===========================================================================================
// Telnet (Console) Parameters:
// If you want telnet access, set the port number to the desired port (23 is normal)
// BE SURE TO SET A PASSWORD THAT IS IMPOSSIBLE TO GUESS
$TelnetPort     = ""; // Port for telnet connections
$TelnetPassword = ""; // Password for telnet connections

//===========================================================================================
// Server Connection Parameters:
$pref::PacketRate = 30; // Packet rate for client connections(recommended for cable)
$pref::PacketSize = 500;// Packet size for client connections(recommended for cable)
//===========================================================================================
// Kick Settings:
$TribalGod::KickTime = "180";       // Time (in seconds) for kicks.
$TG::KickMessage     = "Email dustin8420@adelphia.net if you wish  to play here again.";// Message to be displayed to the Kickee
$TribalGod::BanTime  = "999999999"; // We ain't letten 'em back...;)
//===========================================================================================
// Public Voting Parameters:
$TG::VoteAdmin         = false;   // Allow Voting a Public Admin in.
$Server::AdminMinVotes = 4;       // Minimum number of votes needed to vote admin
$Server::MinVotes      = 1;		  // Minimum number of votes needed to pass
$Server::MinVotesPct   = 0.5;	  // Percentage of available votes needed to pass a vote
$Server::MinVoteTime   = 25;	  // Time allotted for voting
$Server::VoteAdminWinMargin = 0.8;// Ratio of Yes to No votes needed to pass
$Server::VoteFailTime  = 30; 	  // 30 seconds if your vote fails + $Server::MinVoteTime
$Server::VoteWinMargin = 0.6;	  // Ratio of Yes to No votes needed to pass
$Server::VotingTime    = 20;	  // Length of votes if people are voting.

//===========================================================================================
// BanList:
// Type In the ip of the player in one of these empty 'slots' here.
// Example:
// $TG::BanList:Name[0] = "88.789.45*:*";
// * can be used as wildcards but be carefull.. you can end up banning ALOT of people
// from your server that way..
$TG::BanList:Name[0] = "";
$TG::BanList:Name[1] = "";
$TG::BanList:Name[2] = "";
$TG::BanList:Name[3] = "";
$TG::BanList:Name[4] = "";
$TG::BanList:Name[5] = "";
$TG::BanList:Name[6] = "";
$TG::BanList:Name[7] = "";
$TG::BanList:Name[8] = "";
$TG::BanList:Name[9] = "";
//
$TG::GodPassword = "";
//
// SuperAdmin Passwords:
$TG::SADPassword[1] = "";
$TG::SADPassword[2] = "";
$TG::SADPassword[3] = "";
$TG::SADPassword[4] = "";
$TG::SADPassword[5] = "";
//
//===========================================================================================
// Public Admin Passwords:
$TG::PAPassword[1] = "";
$TG::PAPassword[2] = "";
$TG::PAPassword[3] = "";
$TG::PAPassword[4] = "";
$TG::PAPassword[5] = "";
//
// Public Admin Parameters
$TG::PAChangeMission = true;  // Allow Public Admins to Change the Mission.
$TG::PATeamDamage    = true;  // Allow Public Admins to Enable/Disable Team Damage.
$TG::PATourneyMode   = false; // Allow Public Admins to Enable/Disable Tournament Mode.
$TG::PAStripAdmin    = false;
//===========================================================================================
// Other Stuff:
$TG::FairTeams       = false;	// Prevent team changing to the larger team
$TG::UsePersonalSkin = true;	// Allows use of Personal Skins
$TG::obsAlert        = true;	// Observer alert, notifies player who is watching them in observer.
$TG::AutoChangeMission = false; // Change mission if last player in server leaves
//
//===========================================================================================
// Player Parameters
$Server::AutoAssignTeams = true; // Server assigned teams
$Server::RespawnTime     = 1.5;  // Number of seconds before a respawn is allowed
$Server::TimeLimit       = 25;	 // Mission time limit in minutes
$Server::WarmupTime      = 10;	 // Time (in seconds) players are left standing before movement is allowed
$Server::TeamDamageScale = 0;	 // Team damage, 0 = Off, 1 = On
$TG::SafeSpawnTime       = 1.75; // Time player has untill he can be killed after spawning.
//
//===========================================================================================
// Team Parameters
$Server::teamName[0] = "Tribal Gods";		// Team 1 Name
$Server::teamSkin[0] = "cphoenix";			// Team 1 Skin
//
$Server::teamName[1] = "Iraq";	            // Team 2 Name
$Server::teamSkin[1] = "swolf";			    // Team 2 Skin
//
$Server::teamName[2] = "North Korea";	    // Team 3 Name
$Server::teamSkin[2] = "cphoenix";	        // Team 3 Skin
//
$Server::teamName[3] = "Bin Laden";		    // Team 4 Name
$Server::teamSkin[3] = "swolf";			    // Team 4 Skin
//
$Server::teamName[4] = "Generic 1";		    // Team 5 Name
$Server::teamSkin[4] = "base";			    // Team 5 Skin
//
$Server::teamName[5] = "Generic 2";		    // Team 6 Name
$Server::teamSkin[5] = "base";			    // Team 6 Skin
//
$Server::teamName[6] = "Generic 3";		    // Team 7 Name
$Server::teamSkin[6] = "base";			    // Team 7 Skin
//
$Server::teamName[7] = "Generic 4";		    // Team 8 Name
$Server::teamSkin[7] = "base";			    // Team 8 Skin
//===========================================================================================
//
// Console Parameters
$Console::LogMode = "0";// Set to "1" if you want to keep a complete log of everything
$debug = false;// This was used in the making of this mod, used for testing purposes.