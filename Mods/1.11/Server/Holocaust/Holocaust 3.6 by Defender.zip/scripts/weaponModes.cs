//--------------------------------------------------------------------------
// Beacon Mods- used for weapon fire modes
//--------------------------------------------------------------------------

function changeDiscLauncherMode(%player,%clientId)
{
  %clientId = Player::getClient(%player);
  %client = Player::getClient(%player);
//--------------------------------------------------------------------------
// Disc Launcher
//--------------------------------------------------------------------------
      if (Player::getMountedItem(%player, $WeaponSlot) == DiscLauncher)
      {
           if(%clientId.DiscLauncher >= 3)
               %clientId.DiscLauncher = -1;

          %clientId.DiscLauncher += 1;

      if(%clientId.DiscLauncher == 0)
      {
          Client::sendMessage(%clientId,0,"~wdiscreload.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Disc  -> [1/4]<f2> Standard\", 5);", 0);
      }
          //
      else if(%clientId.DiscLauncher == 1)
      {
          Client::sendMessage(%clientId,0,"~wdiscreload.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Disc  -> [2/4]<f2> Power Disc\", 5);", 0);
      }
          //
      else if(%clientId.DiscLauncher == 2)
      {
          Client::sendMessage(%clientId,0,"~wdiscreload.wav");
		  schedule("bottomprint(" @ %clientid @ ", \"<jc><f1>Disc  -> [3/4]<f2> Power Disc X2\", 5);", 0);
      }
          //
      else if(%clientId.DiscLauncher == 3)
      {
          Client::sendMessage(%clientId,0,"~wdiscreload.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Disc  -> [4/4]<f2> Multi Disc\", 5);", 0);
      }
   }
}


//--------------------------------------------------------------------------
//  MBCannon
//--------------------------------------------------------------------------

function changeMBCannonMode(%player,%clientId)
{
  %clientId = Player::getClient(%player);
  %client = Player::getClient(%player);
//--------------------------------------------------------------------------
// MBCannon
//--------------------------------------------------------------------------
      if (Player::getMountedItem(%player, $WeaponSlot) == MBCannon)
      {
           if(%clientId.Cannon >= 5)
               %clientId.Cannon = -1;

          %clientId.Cannon += 1;

      if(%clientId.Cannon == 0)
      {
          Client::sendMessage(%clientId,0,"~wturreton1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Electron Blast Cannon  -> [1/6]<f2> Standard\", 5);", 0);
      }
          //
      else if(%clientId.Cannon == 1)
      {
          Client::sendMessage(%clientId,0,"~wturreton1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Electron Blast Cannon  -> [2/6]<f2> EMP\", 5);", 0);
      }
          //
      else if(%clientId.Cannon == 2)
      {
          Client::sendMessage(%clientId,0,"~wturreton1.wav");
		  schedule("bottomprint(" @ %clientid @ ", \"<jc><f1>Electron Blast Cannon  -> [3/6]<f2> Booster\", 5);", 0);
      }
          //
      else if(%clientId.Cannon == 3)
      {
          Client::sendMessage(%clientId,0,"~wturreton1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Electron Blast Cannon  -> [4/6]<f2> Poisoning effects\", 5);", 0);
      }
      else if(%clientId.Cannon == 4)
      {
          Client::sendMessage(%clientId,0,"~wturreton1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Electron Blast Cannon  -> [5/6]<f2> Internal Flaming\", 5);", 0);
      }
      else if(%clientId.Cannon == 5)
      {
          Client::sendMessage(%clientId,0,"~wturreton1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Electron Blast Cannon  -> [6/6]<f2> Annihilation\", 5);", 0);
      }
   }
}

//--------------------------------------------------------------------------
// chaingun
//--------------------------------------------------------------------------

function changechaingunMode(%player,%clientId)
{
  %clientId = Player::getClient(%player);
  %client = Player::getClient(%player);
//--------------------------------------------------------------------------
// chaingun
//--------------------------------------------------------------------------
      if (Player::getMountedItem(%player, $WeaponSlot) == chaingun)
      {
           if(%clientId.chaingun >= 1)
               %clientId.chaingun = -1;

          %clientId.chaingun += 1;

      if(%clientId.chaingun == 0)
      {
          Client::sendMessage(%clientId,0,"~wdryfire1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Chaingun  -> [1/2]<f2> Standard\", 5);", 0);
      }
          //
      else if(%clientId.chaingun == 1)
      {
          Client::sendMessage(%clientId,0,"~wdryfire1.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Chaingun  -> [2/2]<f2> Vulcan\", 5);", 0);
      }
   }
}



//--------------------------------------------------------------------------
// Beacon Mods- used for weapon fire modes
//--------------------------------------------------------------------------

function changeMortarMode(%player,%clientId)
{
  %clientId = Player::getClient(%player);
  %client = Player::getClient(%player);
//--------------------------------------------------------------------------
// Disc Launcher
//--------------------------------------------------------------------------
      if (Player::getMountedItem(%player, $WeaponSlot) == Mortar)
      {
           if(%clientId.mortar >= 2)
               %clientId.mortar = -1;

          %clientId.mortar += 1;

      if(%clientId.mortar == 0)
      {
          Client::sendMessage(%clientId,0,"~wmortar_reload.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Mortar  -> [1/3]<f2> Standard\", 5);", 0);
      }
          //
      else if(%clientId.mortar == 1)
      {
          Client::sendMessage(%clientId,0,"~wmortar_reload.wav");
		  schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>Mortar  -> [2/3]<f2> Bouncing Betty\", 5);", 0);
      }
          //
      else if(%clientId.mortar == 2)
      {
          Client::sendMessage(%clientId,0,"~wmortar_reload.wav");
		  schedule("bottomprint(" @ %clientid @ ", \"<jc><f1>Mortar  -> [3/3]<f2> Vertigo Bomb\", 5);", 0);
      }
   }
}

