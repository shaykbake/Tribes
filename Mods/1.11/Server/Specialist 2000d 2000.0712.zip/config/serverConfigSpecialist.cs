$Server::HostName = "Specialist Server"; 
$Server::MaxPlayers = "12"; 
$AdminPassword = "ChangeMe"; 
$Server::FloodProtectionEnabled = true;
$Server::HostPublicGame = "true"; 
$Server::Info = "Specialist Server\nAdmin: AdminNameHERE\nEmail: AdminEMailHERE"; 
$Server::JoinMOTD = "<jc><f1>Message of the Day:\n\n\Welcome to "@ $Server::HostName@" running the Specialist mod.\n\nFire to Spawn.";
$Server::Port = "28001"; 
$Server::TimeLimit = 30; 
$pref::PacketRate = 10; 
$pref::PacketSize = 200; 
$Server::teamName0 = "Communist";
$Server::teamName1 = "Capitalist";
$Server::teamName2 = "Children of the Phoenix";
$Server::teamName3 = "Starwolf";
$Server::teamName4 = "Generic 1";
$Server::teamName5 = "Generic 2";
$Server::teamName6 = "Generic 3";
$Server::teamName7 = "Generic 4";
$Server::teamSkin0 = "beagle";
$Server::teamSkin1 = "green";
$Server::teamSkin2 = "cphoenix";
$Server::teamSkin3 = "swolf";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";

$Server::timeLimit = "30";
$Server::warmupTime = 20;

$Server::Password = "";

$Server::MinVotes = "2";
$Server::MinVotesPct = "0.5";
$Server::MinVoteTime = "45";
$Server::VoteAdminWinMargin = "0.659999";
$Server::VoteFailTime = "30";
$Server::VoteWinMargin = "0.51";
$Server::VotingTime = 20;

$Server::respawnInvulnerableTime = "2";
$Server::respawnTime = "3";

$Server::TeamDamageScale = 0;

$Console::LogMode = 0;	// 0 = off, 1 = continuously open and close log file, 2 = maintain file open
