// =====Poison Gas Cloud Config data ============
// == This may slow down the game, if it is too high. ==
$Specialist::MaximumNumberOfGasClouds = 30;

// ===== Smart mines can recognize teammates ===========
$Specialist::SmartMines = True;

// ===== Number of seconds until a hacked object is returned to it's original team ====
// ===== If zero, then the object is never returned to it's original team ===
$Specialist::unHackTime = 240;

// ===== AntiRape Mode makes generators and stations invincible ====
$Specialist::AntiRapeMode = "false";

// ===== Set the penalty for leaving the mission area ====
// Possible modes:
// 1. "Warn" = just warn the player
// 2. "Damage" = continously damage the player while they are out of bounds
// 3. "InstantKill" = instantly kill a player who steps out of bounds (oooh, you're a mean one)
// 4. "DelayedKill" = warn the player and kill them if they stay out of bounds too long
$Specialist::LeaveMissionAreaPenalty = "Warn";
$Specialist::LeaveMissionAreaGracePeriod = 10;	// number of seconds before final penalty is applied

// ===== Automatically make these people admins when they connect ====
// 1. Put the name of the admin in $Specialist::AdminName[?]; it can contain spaces, etc.
// 2. Put the IP addresses that they connect from in $Specialist::AdminIP[?, 0], $Specialist::AdminIP[?, 1], etc.
// 	You can use the asterisk (*) sign to indicate a wildcard.
// 3. Put the type of admin this person is in $Specialist::AdminType[?].  
//	This can be either "Admin" or "SuperAdmin".
// 4. There are no passwords or anything, so this file does not have to be that secure.

$Specialist::AdminName[0] = "Oberon |PTi|";
$Specialist::AdminIP[0, 0] = "199.232.32.*";
$Specialist::AdminIP[0, 1] = "24.147.137.*";
$Specialist::AdminType[0] = "SuperAdmin";

$Specialist::AdminName[1] = "{TGO}LadyMacbeth";
$Specialist::AdminIP[1, 0] = "199.232.32.*";
$Specialist::AdminIP[1, 1] = "24.147.137.*";
$Specialist::AdminType[1] = "SuperAdmin";

$Specialist::AdminName[2] = "DrinkSprite";
$Specialist::AdminIP[2, 0] = "199.232.32.*";
$Specialist::AdminIP[2, 1] = "24.147.*.*";
$Specialist::AdminType[2] = "SuperAdmin";

$Specialist::AdminName[3] = "JesuitKing|PTi|";
$Specialist::AdminIP[3, 0] = "199.232.32.*";
$Specialist::AdminIP[3, 1] = "24.147.*.*";
$Specialist::AdminType[3] = "Admin";

$Specialist::AdminName[4] = "Exodus20:13|PTi|";
$Specialist::AdminIP[4, 0] = "24.147.*.*";
$Specialist::AdminType[4] = "Admin";

$Specialist::AdminName[5] = "{TGO} Tab Chomper";
$Specialist::AdminIP[5, 0] = "24.147.*.*";
$Specialist::AdminType[5] = "SuperAdmin";
