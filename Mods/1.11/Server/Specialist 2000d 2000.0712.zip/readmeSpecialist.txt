==========================
The Specialist mod for Tribes
==========================

Release v2000d
7/12/00

This version is a release version.  Feel free to distribute it.

Installation instructions:
--------------------------------------
1. Unzip this archive (Specialist.zip) into the directory in which Tribes is installed (e.g. C:\Dynamix\Tribes).

2. Your Tribes command line must now include: -mod Specialist +exec serverConfigSpecialist
	(e.g.) Tribes.exe -mod Specialist
	or, to run a dedicated server (with InfiniteSpawn v1.1):
	(e.g.) InfiniteSpawn.exe *28001tribes -mod Specialist +exec serverConfigSpecialist -dedicated
	
NOTE: If you are using InfiniteSpawnv1.0, omit the "*28001".

3. To make your life a little easier, I've included two Windows shortcuts that execute the above command lines.
	They should unzip into your Tribes directory, and you may need to change their drive letter (e.g. F: to C:).
4. Enjoy.

-{TGO}LadyMacbeth

See http://prototypei.tripod.com/ for more information.
