if($pref::lastMission == "")
   $pref::lastMission = Raindance;

$MODInfo = "<f2>\nSpecialist mod v2000c\n<f1>By |PTi| and |V|\n";
