exec(serverSpecialist);

serverSpecialist::Start();
