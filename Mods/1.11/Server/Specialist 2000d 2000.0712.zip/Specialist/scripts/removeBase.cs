$InvList[LightArmor] = 0;
$InvList[MediumArmor] = 0;
$InvList[HeavyArmor] = 0;
$RemoteInvList[LightArmor] = 0;
$RemoteInvList[MediumArmor] = 0;
$RemoteInvList[HeavyArmor] = 0;

