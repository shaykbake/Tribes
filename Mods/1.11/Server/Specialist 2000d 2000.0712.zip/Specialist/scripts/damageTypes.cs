// Damage Types
//
$ImpactDamageType	= -1;
$LandingDamageType	=  0;
$BulletDamageType	=  1;
$EnergyDamageType      =  2;
$PlasmaDamageType      =  3;
$ExplosionDamageType   =  4;
$ShrapnelDamageType    =  5;
$LaserDamageType       =  6;
$MortarDamageType      =  7;
$BlasterDamageType     =  8;
$ElectricityDamageType =  9;
$CrushDamageType       = 10;
$DebrisDamageType      = 11;
$MissileDamageType     = 12;
$MineDamageType        = 13;

// Specialist damage types
$PoisonGasDamageType	= 14;
$RadiationDamageType	= 15;
$EMPDamageType		= 16;
$NullDamageType		= 17;
$FireDamageType		= 18;

$AcidDamageType		= 19;
$BlindDamageType		= 20;
$SniperRifleDamageType	= 21;
$ShotgunDamageType	= 22;
$FlakDamageType		= 23;
$ExplosiveGatDamageType	= 24;
$ArtilleryShellDamageType 	= 25;
$TimedExplosiveDamageType = 26;
$RemoteBombDamageType	= 27;
$HandDamageType		= 28;
$LeaveMissionAreaDamageType	= 29;