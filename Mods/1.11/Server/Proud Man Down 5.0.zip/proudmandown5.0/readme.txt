Mod Name: PROUD MAN DOWN

Creator: Xagon Games - Josh Buckingham AKA Sahbitar/Buletz

Mod Info: Proud Man Down: World War II puts you in the heart of the greatest war in the history of time.
Storm the beaches of Normandy & more on the France Campaign! Pilot a plane into the middle of a great
dogfight in German occupied Europe!

--------------------------------------------
INSTALLATION
--------------------------------------------

To install the mod & maps, follow the steps below:

1. Extract the winzip file contents into your ...\...\Tribes directory.

2. Copy your tribes shortcut.

3. Right click the new shortcut and click 'Properties' on the dropdown menu.

4. Click the 'Shortcut' tab and put this in the 'Target' box:

...\...\Tribes\Tribes.exe -mod ProudManDown

(NOTE: Replace the ...\...\ with the start of your tribes directory, eg. 'C:\Dynamix' is the default installation
path.

5. Click OK.

6. Double click the icon and get ready to play!

--------------------------------------------
FOR DEDICATED SERVERS:
- - - - - - - - - - - - - - - - - - - - - - - - - - -

1. Follow steps 1-4 in the installation instructions.

2. instead of 

...\...\Tribes\Tribes.exe -mod ProudManDown

Put:

...\...\Tribes\Tribes.exe -mod ProudManDown -dedicated

(NOTE: Replace the ...\...\ with the start of your tribes directory, eg. 'C:\Dynamix' is the default installation
path.

3. Click OK then double click the shortcut, it should run a dedicated server in a console window.


--------------------------------------------
SAHBiTAR'S DISCLAIMER
--------------------------------------------

All mod/script files in this Tribes* modification are provided for the public under these conditions:

1. Any modifications to this original mod then released to the public should be under permissions by me.

2. I, Sahb/Buletz AKA Josh Buckingham, take no responsibility for damage done to your computer.
I doubt any of this code will damage your computer at all, just writing this to save my ass here :P.

3. No portion of this code is to be handed out/used in a public wayunless with my permission. 
(I'm kinda over protective about my mod huh :D).

4.Finally, ENJOY the mod! This mod was originally created so that people could have fun! So go
blow up some men with your rocket launcher already and quit reading this readme!



*Starsiege Tribes is in no way associated with Xagon Games, ProudManDown mod, or myself. 
Tribes is a registered trademark of Dynamix/Sierra Inc.