$ObjData::Num = "1";
$ObjData::0_name = "Control Point";
$ObjData::0_type = "TowerSwitch";
$ObjData::0_SCORE = "0 12";
$ObjData::MissionType = "Capture and Hold";
