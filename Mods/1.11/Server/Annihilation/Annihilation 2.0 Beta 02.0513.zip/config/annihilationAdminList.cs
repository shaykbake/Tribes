// Annihilation Auto admin
//
// The Actual User.
// $UserList::UserName[1] = "<UserName>";
// $UserList::UserMask[1] = "<AccessLevel> <IP Masks>";
//
// <UserName> 	= What is this Users Regular Name. 
//
// <AccessLevel> 	= What Access do they have. Choices are:
//		  God			- Auto-God Admin status
//		  AutoSuper 	- Super Admin w/ Auto Admin. 
//		  AutoPublic 	- Public Admin w/ Auto Admin. 
//
// <IP Masks> 	= What IP or IPs you want to list for that user. you can list
//		  as many IPs as you want. the only wildcard accepted is * 
//		  For Example:
//			User's actual IP = 209.14.25.25
//			Successful IP Mask = 209.14.*.*
//		  When using the * that will allow any number for that part of the IP. 
//		  Please be aware of the consequences of using wildcards and autoadmin. 
//		  You may give a whole ISP control of your server, or even the whole Planet. 
// 		  Ip mask needs to be one word, with a space between additional ip's if needed.
//
// Examples:
//
//	$UserList::UserName[1] = "Fred Newby";
//	$UserList::UserMask[1] = "AutoPublic 255.255.42.*";
//
//	$UserList::UserName[2] = "Disc O God";
//	$UserList::UserMask[2] = "God 123.12.*.*";
//
// The list of actual users:

$UserList::MaxUsers = 2; 	// Total number of users

$UserList::UserName[1] = "{-o-} Plasmatic";
$UserList::UserMask[1] = "God 12.217.114.*";

$UserList::UserName[2] = "{-o-} Sevnn";
$UserList::UserMask[2] = "God 68.15.98.*";



