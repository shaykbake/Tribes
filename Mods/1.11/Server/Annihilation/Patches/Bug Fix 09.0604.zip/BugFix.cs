// Repair rewards and pbeam fix for Annihilation servers
// Plasmatic 
// 5/27/2009 4:38AM

// Drop this file info the config directory.
// Run from config\annihilation.cs with 
// exec(bugfix);


function ParticleBeamWeapon::onCharge(%player)
{
	if(%player.reloading == "True") 
		return;//plasmatic
	%clientId = GameBase::getOwnerClient(%player);
	if(Player::isTriggered(%player,0))
	{
		%player.pbeamcharging = true;
		if (%player.pbeamcharge < 100)
			%player.pbeamcharge++;
		else
		 	%player.pbeamcharge = 100;
	 	
		schedule("ParticleBeamWeapon::onCharge(" @ %player @ ");",0.05);
		GameBase::setEnergy(%player,GameBase::getEnergy(%player)-2.5);
		
		if (%player.pbeamcharge > 60 && GameBase::getLOSInfo(%player,3000))
		{
			if(!%clientId.locksound) 
			{
				%obj = getObjectType($los::object);
			//echo(%obj);
				if(%obj == "Player" || %obj == "Flier")
				{
					GameBase::playSound(%clientId,SoundMineActivate, 0);
					%clientId.locksound = true;
					schedule("ResetPbeamLock("@%ClientId@");",2);
				}
				else if(%obj != "SimTerrain" && %obj != "InteriorShape")
				{
					GameBase::playSound(%clientId,soundpackuse, 0);
					%ClientId.locksound = true;
					schedule("ResetPbeamLock("@%ClientId@");",2);
				}	
			}
			%trans = GameBase::getMuzzleTransform(%player);	
			%d1= getWord(%trans,3);
			%d2= getWord(%trans,4);
			%d3= getWord(%trans,5);		//3,4,5 are dir vec -plas
			
			%posX = getWord(%trans,9);		//x
			%posY = getWord(%trans,10);		//y
			%posZ = getWord(%trans,11); 		//z	
			%GunTipPos = %posX@" "@%posY@" "@%posZ;	
			
			%gunVec = vector::normalize(vector::sub($los::position,%GunTipPos));				
			
			%vec = vector::sub($los::position,%gunVec);
			%trans =  getWord(%trans,0)@" "@getWord(%trans,1)@" "@getWord(%trans,2)@" "@%gunVec@" "@getWord(%trans,6)@" "@getWord(%trans,7)@" "@getWord(%trans,8)@" "@%vec;
			%proj = Projectile::spawnProjectile("MarkerLaser", %trans, 2048, %vel);					
		}
		bottomprint(%clientId, "<jc><f2>ParticleBeam charged to <f1>"@%player.pbeamcharge@"<f2>%", 0.5);
	}
	
	else //if(!Player::isTriggered(%player,0))	//fire this bad boy. 
	{
		if(GameBase::getLOSInfo(%player,3000) && !Player::isdead(%player)) //plasmatic 3.0 Fixed sky fire bug. 
		{
			// there must be something in our sight. 
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%target = $los::object;	
			%obj = getObjectType(%target);
			if(%obj == "SimTerrain" || %obj == "InteriorShape") 
			{
				// Mine fix 4/9/2009 9:07PM -Plasmatic
				// getlosinfo doesn't pick up mine types. 
				%set = newObject("set",SimSet);
				if(containerBoxFillSet(%set,$MineObjectType,$los::position,0,0,0,0) >0 ) 
					GameBase::setDamageLevel(Group::getObject(%set, 0),(%player.pbeamcharge/8));
				
				deleteObject(%set);	
			}
			else
			{
				if (%obj=="Player" || %obj =="Flier") 
					%value = %player.pbeamcharge/25;
				if(GameBase::getMapName(%target) == Bunker)
					%value = %player.pbeamcharge/25;	//6 shots fer bunker -plasmatic
				else  
					%value = %player.pbeamcharge/8;
					
				GameBase::applyDamage(%target, $SniperDamageType, %value, $los::position, "0 0 0","0 0 0", %clientId);
				if($debug)
					Client::sendMessage(%clientId,0,"target "@ %target @" object type "@%obj@" Damage value "@%value);
				
			}
			
			
			
		}	
		// animate the beams -Plasmatic 3.0
		%trans = GameBase::getMuzzleTransform(%player);
		%vel = Item::getVelocity(%player);
		playSound(SoundFireLaser, GameBase::getPosition(%player));
		Player::trigger(%player, 4, true);
		Player::trigger(%player, 6, true);
	
		%smack = %player.pbeamcharge / 10;
		if (%smack < 4) 
			playSound(SoundMissileTurretFire, GameBase::getPosition(%player));
		if (%smack >= 4) 
			playSound(SoundPlasmaTurretFire, GameBase::getPosition(%player));
		if (%smack >= 8) 
			playSound(explo3, GameBase::getPosition(%player));
	
		if($debug)
			Client::sendMessage(%clientId,0,GameBase::getMapName(%target)@"target "@ %target @" object type "@%obj@" Damage value "@%value);

		%player.pbeamcharge = 0;
		%player.pbeamHoldcharge = 0;
		%player.pbeamcharging = false;
		Player::trigger(%player, 4, false);
		Player::trigger(%player, 6, false);

		%player.reloading = "True";//plasmatic
		schedule("reload(" @ %player @ ");",2.0); //PLASMATIC

	//new kickback- Plasmatic
		if(!Player::isDead(%player)) 
		{
			%rot=GameBase::getRotation(%player);
			%len = 30;
			%tr= getWord(%trans,5);
			%tr = -%tr;
			%tr = %tr+0.15;
			%up = %tr;
			%out = %tr -1;
			
			%vec = Vector::getFromRot(%rot,%len*%out*%smack,%len*%up*%smack);
			Player::applyImpulse(%player,%vec);
		}
	}
}


function RepairBolt::onRelease(%this, %player)
{
	%object = %player.repairTarget;
	if(%object != -1) 
	{
		%client = Player::getClient(%player);
		if(%object == %player) 
		{
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else 
		{
			if(GameBase::getDamageLevel(%object) == 0) 
			{
				Client::sendMessage(%client,0,"Repair Done");	
				RepairRewards(%object);
			}
			else 
			{
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
		if(%rate < 0)
			%rate = 0;
		
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

function SuperRepairBolt::onRelease(%this, %player)
{
	%object = %player.repairTarget;
	if(%object != -1) 
	{
		%client = Player::getClient(%player);
		if(%object == %player) 
		{
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else 
		{
			if(GameBase::getDamageLevel(%object) == 0) 
			{
				Client::sendMessage(%client,0,"Repair Done");
				RepairRewards(%object);
			}
			else 
			{
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
		if(%rate < 0)
			%rate = 0;
		
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

// Body blocking by Plasmatic..
// billiards game type anyone?... -Plasmatic
function Player::onCollision(%this,%obj)
{	
	if($debug) 
		event::collision(%this,%obj);
	if(%obj.testing)	//Plasmatic -Portal gun 11/20/2007 11:45PM
		return;
	//echo("player::oncollision "@getObjectType(%obj));
	//body blocking -Plasmatic
	if(getObjectType(%obj) == "Player")
	{
		//player colliding with another player
		if(Player::isDead(%obj))
		{
			//Kick dat corpse..  -Plasmatic
			%thisVel = Item::getVelocity(%this);	
			%objVel = Item::getVelocity(%obj);
			Item::setVelocity(%obj, %thisVel);
		}	
		else if(Player::isDead(%this)) 
		{
			// Dead players transfer all items to the live player
			%sound = false;
			%max = getNumItems();
			for(%i = 0; %i < %max; %i = %i + 1) 
			{
				%count = Player::getItemCount(%this,%i);
				if(%count) 
				{
					%delta = Item::giveItem(%obj,getItemData(%i),%count);
					if(%delta > 0) 
					{
						Annihilation::decItemCount(%this,%i,%delta);
						%sound = true;
					}
				}
			}
			if(%sound) 
			{
				// Play pickup if we gave him anything
				playSound(SoundPickupItem,GameBase::getPosition(%this));
			}
		}			
		else
		{
			// 2 live players colliding. Annihilation stuff. 
			%cliendId = Player::getClient(%obj);
			%thisId = Player::getClient(%this);
			%armor = Player::getArmor(%obj);
			eval(%armor @ "::onPlayerContact(" @ %this @ ", " @ %obj @ ");");	//fixed in 3.0 1/27/2005 6:03AM -Plasmatic
			
			if(GameBase::getTeam(%obj) == GameBase::getTeam(%this))
			{
				if(%this.cloaked > 0)
				{
					//pop this player visible for a second -plasmatic
					GameBase::startFadein(%this);	
					%this.cloaked = "";
				}
			}			
			// Body slamming with 2 live players -Plasmatic
			if(getSimTime() - %this.lastImpact < 1 && getObjectType(%obj) == "Player")
			{
				%Tm = player::getarmor(%this).mass;
				%Om = player::getarmor(%obj).mass;
				%m = %tm/%om;	//weight ratio between armors
				
				%vel = vector::multiply(%this.lastVel,%m@" "@%m@" "@%m);
				%speed = vector::getdistance("0 0 0",%vel);
						
				if(%speed > 100)
				{
					// Tackle deaths.
					playSound(shockExplosion,GameBase::getPosition(%this));
				//	GameBase::playSound(%player, shockExplosion, 0);
				//	Item::setVelocity(%obj,0);				
					%dead = Client::getName(GameBase::getControlClient(%obj));
					%killer = Client::getName(GameBase::getControlClient(%this));
					Item::setVelocity(%obj,"0 0 1");
					if($Annihilation::blood)
						Player::blowUp(%obj);	
					player::blood(%obj);	
					Player::kill(%obj);
					%message = %killer @ " tackled " @ %dead @" to death at "@%speed @"mph";
					echo(%message);
					messageall(0,%message);
					Player::setAnimation(%obj,$animNumber++);
										
					return;
				}
				else if(%speed > 65)
					playSound(soundArmorCrunch,GameBase::getPosition(%this));		
				else if(%speed > 45)
					playSound(soundArmorCrash,GameBase::getPosition(%this));
				else if(%speed > 25)	{}
				else if(%speed > 10)
					playSound(soundArmorSmack,GameBase::getPosition(%this));
				else 	
					playSound(soundArmorSlap,GameBase::getPosition(%this));
			
				Item::setVelocity(%obj,%vel);
			//	messageall(1,"bam? "@%m@", "@%speed@", "@%impactsound);				
			}		
		}
	}
	else
	{
		//player collision with something besides a player
		if(!Player::isDead(%this))
		{
			if(GameBase::getTeam(%obj) == GameBase::getTeam(%this))
			{
				if($ArmorName[Player::getArmor(%this)] == iarmorBuilder)		
				{
					%client = Player::getClient(%this);
					if(GameBase::getDamageLevel(%obj))
					{
						//%this.repairTarget = %obj;	
						%obj.LastRepairCl = %client;
						GameBase::repairDamage(%obj, 0.07);
						GameBase::playSound(%this, ForceFieldOpen,0);
					}
					else if(%obj.LastRepairCl == %client)
					{
						//we repaired this last, and it's fixed now eh?
						RepairRewards(%obj);	
					}
				}
			}	
		}
		else
		{
			//dead player health kit?
		}			
	}
}

// fixed 5/27/2009 4:38AM -Plasmatic (sigh)
function RepairRewards(%object)
{
	
	%client = %object.LastRepairCl;
	%object.LastRepairCl = "";
	%player = client::getownedobject(%client);
	if(%client != -1) 
	{	
		%name = GameBase::getDataName(%object);	
		%class = %name.className;
		%data = %name.description;		
	//	messageall(1,"N:"@ %name @", C:"@%class@", D:"@%data);
		
		if(GameBase::getTeam(%client) == GameBase::getTeam(%object)) 
		{	
			%lastdamage = %object.lastDamageObject;
			//%client = Player::getClient(%player);
			if(%lastdamage != %client)
			{
				%name = GameBase::getDataName(%object);	
				%class = %name.className;
				%data = %name.description;
					
				
	
				if(%name == PulseSensor || %class == Generator || %class == Station || %class == Turret)
				{
					//give players a point if it's their teams, and they didnt damage it last.. 
					%client.score++;
					Game::refreshClientScore(%client);
					%player.repairTarget = "";	//no more points.. 
					
					return ", 1 point";
				}	
			}
			
			//they caused the damage... NO POINT FOR JOO!
		}
		
	}
	return;
}
