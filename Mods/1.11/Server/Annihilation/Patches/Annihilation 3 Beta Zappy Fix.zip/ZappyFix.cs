//	Drop the file "ZappyFix.cs" into Annihilation/station to fix 
//	possible exploits and other issues with zappy inventories
//	in Annihilation 3.0 beta
//	
//	Visit the forums at:
//	www.annihilation.info 
//	for more information. 
//	
//	
//	-Plasmatic
//	Plasmatic@gmail.com
//	ICQ 77161332


//Infinite Zappy fix 3/17/2007 6:36AM Plasmatic
function InvTrigger::onEnter(%this,%object)
{
	%type = getObjectType(%object);
	if(%type == "Player") 
	{
		if(Player::isAIControlled(%object))
			return;
		%group = getGroup(%this); 
		%obj = %this.Owner;
		%client = GameBase::getOwnerClient(%object);	
		%object.InvObject = %obj;
		
		if($debug || $debuginv || $debugt)
		{
			echo("InvTrigger::onEnter "@%obj@" Damage state,"@GameBase::getDamageState(%obj)@", Powered,"@GameBase::isPowered(%obj)@" client,"@%client);
			echo("Left turret active"@%obj.lTurret@", "@GameBase::isActive(%obj.lTurret)@ " energy="@GameBase::getEnergy(%obj.lTurret)@ " right turret active"@%obj.rTurret@", "@GameBase::isActive(%obj.rTurret)@ " energy="@GameBase::getEnergy(%obj.rTurret));
		}
		if((GameBase::getTeam(%object) == GameBase::getTeam(%obj) || GameBase::getTeam(%obj) == -1) && %client.isSpy != true)
		{
			%client.InvTargetable = true;	//moved here in 3.0, station won't fire if unpowered.. -Plas 3.0
			if(GameBase::getDamageState(%obj) == "Enabled") 
			{
				if(GameBase::isPowered(%obj)) 
				{ 
					gamebase::setactive(%obj.lTurret,true);	//just to make certain.. gets changed on drop ship destroy.. for some damn reason..
					gamebase::setactive(%obj.rTurret,true);
					GameBase::setRechargeRate(%obj.lTurret,100);
					GameBase::setRechargeRate(%obj.rTurret,100);						
									
					//plas 3.0
					if(!$Annihilation::Zappy)
					{
						%Client.InvConnect = true;
						%client.ListType = "InvList";
						GameBase::playSound(%object, SoundActivatePDA,0);
						Client::sendMessage(%client,3,"..Inventory Uplink established..");
						QuickInv(%client);
						schedule("ZappyResupply(" @ %client @ ");",0.25);	
					}
				}
			}			
			else
			{
				gamebase::setactive(%obj.lTurret,false);	//just to make certain.. gets changed on drop ship destroy.. for some damn reason..
				gamebase::setactive(%obj.rTurret,false);
				GameBase::setRechargeRate(%obj.lTurret,100);
				GameBase::setRechargeRate(%obj.rTurret,100);	
			}			
		}		
	}
}


// Fix for overlaping Zappy Inv triggers 3/23/2007 4:21AM Plasamtic
// made easier by the.. Infinite Zappy fix 3/17/2007 6:46AM
function InvTrigger::onLeave(%this,%object)
{
	%type = getObjectType(%object);
	if(%type == "Player")
	{
		if(Player::isAIControlled(%object))
			return;
		
		%client = GameBase::getOwnerClient(%object);
				
		%TrigPos = Gamebase::getPosition(%this);
		%PlPos = getBoxCenter(%object);	
		%dist = vector::getdistance(%PlPos,%TrigPos);		
		if(%dist > 3)
		{
			
			%PlayerStation = %object.InvObject;
			%TriggerStation = %this.owner;
			if(%PlayerStation == %TriggerStation)
			{
				if($debug || $debuginv || $debugt)
				{
					echo("InvTrigger::onLeave, client= "@%client@" Dist= "@%dist);
				}
		
				%client.ConnectBeam = "";	//internal
				%client.InvTargetable = "";	//internal
				%Client.InvConnect = "";	//external	
				QuickInvOff(%client);	
				%object.ZappyResupply = "";
				%client.ListType = "";
			}
			else
			{
				// For the odd time 2 triggers overlap.. 3/23/2007 4:21AM Plasamtic
				// fire up the new triggers inventory station. 
		
				%client.ConnectBeam = "";	//internal
				if((GameBase::getTeam(%object) == GameBase::getTeam(%PlayerStation) || GameBase::getTeam(%PlayerStation) == -1) && %client.isSpy != true)
				{
					%client.InvTargetable = true;	//moved here in 3.0, station won't fire if unpowered.. -Plas 3.0
					if(GameBase::getDamageState(%PlayerStation) == "Enabled") 
					{
						if(GameBase::isPowered(%PlayerStation)) 
						{ 
							gamebase::setactive(%PlayerStation.lTurret,true);	//just to make certain.. gets changed on drop ship destroy.. for some damn reason..
							gamebase::setactive(%PlayerStation.rTurret,true);
							GameBase::setRechargeRate(%PlayerStation.lTurret,100);
							GameBase::setRechargeRate(%PlayerStation.rTurret,100);						
							Client::sendMessage(%client,3,"..Attempting Uplink transfer..");	//3/23/2007 4:41AM For overlaping triggers. -Plasmatic	
					
							//	//plas 3.0
							if(!$Annihilation::Zappy)
							{
								%Client.InvConnect = true;
								%client.ListType = "InvList";
								GameBase::playSound(%object, SoundActivatePDA,0);
								Client::sendMessage(%client,3,"..Inventory Uplink established..");
								QuickInv(%client);
								schedule("ZappyResupply(" @ %client @ ");",0.25);	
							}
						}
					}			
					else
					{
						gamebase::setactive(%PlayerStation.lTurret,false);	//just to make certain.. gets changed on drop ship destroy.. for some damn reason..
						gamebase::setactive(%PlayerStation.rTurret,false);
						GameBase::setRechargeRate(%PlayerStation.lTurret,100);
						GameBase::setRechargeRate(%PlayerStation.rTurret,100);	
					}			
				}
			}	
		}
	}
}

//Infinite Zappy fix 3/17/2007 6:56AM
function InventoryCharge::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
	%client = GameBase::getOwnerClient(%target);
	%InvObject = %target.InvObject;
	%InvPos = gamebase::getposition(%InvObject);
	if(%client.InvTargetable && %InvPos != "0 0 0")
	{
		if(!%Client.InvConnect)
		{	
			Client::sendMessage(%client,3,"..Inventory Uplink established..");
			
			QuickInv(%client);
			schedule("ZappyResupply(" @ %client @ ");",0.25);
			GameBase::playSound(%target, SoundActivatePDA,0);
					
		}
				
		%client.InvConnect = true;
		%client.ListType = "InvList";
		schedule("QuitBeam("@%client@");",1.0);
	}
	else
	{
		%client.ConnectBeam = "";	//internal
		%client.InvTargetable = "";	//internal
		%Client.InvConnect = "";	//external	
		QuickInvOff(%client);	
		%object.ZappyResupply = "";
		%client.ListType = "";		
	}
}

//Infinite Zappy fix Plasmatic 3/17/2007 6:49AM
function MobileInventory::onDestroyed(%this)
{
	if($trace) 
		echo($ver,"| MobileInventoryPack::onDestroyed");
	MobileInventory::onDisabled(%this);
	
	GameBase::setEnergy(%this.lTurret,0);	
	GameBase::setDamageLevel(%this.lTurret,1100);	
	GameBase::setEnergy(%this.rTurret,0);	
	GameBase::setDamageLevel(%this.rTurret,1100);	
	
	//Infinite Zappy fix Plasmatic 3/17/2007 7:03AM
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%player = Client::getOwnedObject(%cl);
		if(%player.InvObject == %this)
		{
			%cl.ConnectBeam = "";	//internal
			%cl.InvTargetable = "";	//internal
			%Cl.InvConnect = "";	//external	
			QuickInvOff(%cl);	
			%player.ZappyResupply = "";
			%cl.ListType = "";
		}
	}
	%this.cloakable = "";
	%this.nuetron = "";
	StaticShape::objectiveDestroyed(%this);
	if(!$NoCalcDamage)
		calcRadiusDamage(%this, $DebrisDamageType, 2.5, 0.05, 25, 13, 3, 0.55, 0.30, 250, 170);
	$TeamItemCount[GameBase::getTeam(%this) @ "MobileInventoryPack"]--;
}