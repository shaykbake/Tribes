 ||||   Top  Gun  v1.0    ||||
___________________________________

This is a modification of tribes to allow you to pilot military aircraft and
dogfight. The available aircraft are: F/A-18 Hornet, F-14 Tomcat, F-16 Falcon,
F-15 Eagle, A-10 Warthog, B-52 Stratofortress, and a C-130A Hercules. Top Gun
was made by Patriot who edited the Delta Force Modification. 50% of the credits 
go to the makers of DeltaForce and DeltaAirForce for this is basically a mod of a mod.
___________________________________

||||   How   To   Install    ||||

This bundle contains 3 zip files: TopGunMod.zip, TopGunMaps.zip, TopGunSkins.zip.
What you need to do is to make a folder in your tribes directory and name it:
TopGun   .   Now you unzip the TopGunMod.zip and extract all the files to the TopGun folder.
Now you must make a subdirectory in the TopGun Folder and name it Missions. Now unzip TopGunMaps.zip
and exract all the files the the Missions folder under TopGun. Last you need to make another
subdirectory in the TopGun folder and name it: Skins. Unzip TopGunSkins.zip and extract to the Skins 
folder in the TopGun folder. I know it's complicated but this should work.
__________________________________

||||  Setting Up a Server  ||||

To set up a TopGun base server just have to take the TopGunModfortribes infinite spawn program given
in this zip file and place it on your desktop. Anytime you want to set up a dedicated server just open
that program up. Make sure you have the TopGun folder already made in your tribes directory before you do this.

.:ms-dos box dedicated server commands:.

Admin -    id#.isadmin=true;      ex:  2049.isadmin=true;
SuperAdmin -    id#.issuperadmin=true;     ex:  2049.issuperadmin=true;
_________________________________

||||   Credits   ||||

TopGun base mod was made by Patriot

This mod came from editing the deltaforce mod so thanks to the creators of Delta Force and DeltaAirForce.


http://www.topguntribes.cjb.net

