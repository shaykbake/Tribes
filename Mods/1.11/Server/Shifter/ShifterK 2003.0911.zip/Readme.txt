   ____        _       			   _   _         _
  |  _ \  ___ | |  ___   __ _  ___   ___  | \ | |  ___  | |_  ___  ___
  | |_) |/ _ \| | / _ \ / _` |/ __| / _ \ |  \| | / _ \ | __|/ _ \/ __|
  |  _ <|  __/| ||  __/| (_| |\__ \|  __/ | |\  || (_) || |_|  __/\__ \
  |_| \_\\___||_| \___| \__,_||___/ \___| |_| \_| \___/  \__|\___||___/
------------------------------------------------------------------------------
ShifterK
http://www.tribeshifter.com/k/
Created by: KiLL(-) & enV.3zer0
   ShifterK is a MOD for the Starsiege TRIBES. It is based on another popular MOD called renegades. The MOD started back 1999 when a programmer by the name of Emo1313.
   Then in 2002, a young and very bright modder played the mod and decided the make his own set of changes. His mod was called Shifter_V1G. He modified Shifter to the max, making it a better MOD for all, after a year or so he decided to move on to other things.
   Finally in 2003, KiLL(-) decided to make some changes and fix some problems of the left off mod. After a little while a interested gamer, enV.3zer0. He  decided to help out KiLL(-) and that become the first official team of Shifter. KiLL(-) felt that ShifterK was safe in the hands of his new partner and decided to help out Tribes 2 Shifter. 
   Today enV.3zer0 is the current modder of Shifter and is currently helping out yet another programmer to join the history of Shifter.

ShifterK 9-11-03 Updates
------------------------------------------
Fixed Hyper blaster

ShifterK 8-15-03 Updates
------------------------------------------
� Added 3 new variables for cheating.

$Cheating::Ban = "false";			
 	Ban anyone who brings up the cheat message 5 times
$Cheating::DeployCheck = true;  		
 	Deploy Cheat Check On/Off -- Default: True (On)
$Cheating::UsageCheck = true;  			
 	Scheduled Use Cheat Check On/Off -- Default: True (On)
$Cheating::AutoJJCheck = false;  		
	Auto JJ Cheat Check On/Off -- Default: False (Off)

� Replace HeatSeeker with HeatLock - A mix between LockJaw and HeatSeeker.
	This announces to the player when he locks onto the target
	It also warns the target when a player locks on
	if the player fires while the target is jetting, a lockjawed missiles tracks him


If you need help with running a server, please visit:
Http://www.tribeshifter.com/k/howto.php

For previous updates, Please visit the K website.

If you have an Idea you'd like to submit for the next release
Please ethier Contact enV.3zer0 or post at the tribeshifter.com forums

enV.3zer0
-----------
AIM: enV3zer0
ICQ: 41511002
MSN: ek_opteron@hotmail.com