
   ____        _       ShifterK 6-25-05    _   _         _
  |  _ \  ___ | |  ___   __ _  ___   ___  | \ | |  ___  | |_  ___  ___
  | |_) |/ _ \| | / _ \ / _` |/ __| / _ \ |  \| | / _ \ | __|/ _ \/ __|
  |  _ <|  __/| ||  __/| (_| |\__ \|  __/ | |\  || (_) || |_|  __/\__ \
  |_| \_\\___||_| \___| \__,_||___/ \___| |_| \_| \___/  \__|\___||___/
                    +-------------------------------------------+
 %%%%%%%%%%%%%%%%%%%|%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%|%%%%%%%%
  +-----------------+-----+                                     |
  |                 |     | New Features                        |
  |   @@S@@@     @@@|@@@@ |                                     |
  |    @@@@      @@@|K@   |	In-Game Duel                    |
  |    @@@S     @@@@|     |	Admin Global commands           |
  |    @@@S    @@@@ |  	  |	Less lag during Tourny mode     |
  |    @@@@   @@@@  |     |                                     |
  |    S@@@@ @@@@   |  	  |	 Fixes                          |
  |    S@@@@@@@@    |     |         Save info works.            |
  |    S@@@@@@@     |  	  |         Readable echos.             |
  |    S@@@@@@@     |     |         Console config errors.      |
  |    S@@@@@@@K    +-----|-------------------------------------+
  |    @@@@SS@@@@         |
  |    @@@@@  @@@S        |
  |    @@@@@    @@@       |
  |   @@@@@@    %@@@#     |
  |  @@@@SSSSS   @@@@@%@@ |
  |        +--------------+----------------------------------+
  +--------+What-is-duel?-+ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%|
           |                                                 |
           |First off, In normal game play (that is, when    |
           |its not in tournment or anything) you press tab, |
           |and then you press on the person you want to     |
           |duel. Once you do that options come up and it    |
           |says "Challege to a duel" and "View duel stats"  |
           |The it asks what armor you wanna challege them   |
           |in, scout, sniper, chem, merc, dread. and if     |        
           |they accpet it. You both go way out of bounds,   |
           |away from anyone...and you duel. when one wins.  |
           |you both go back in game                         |
           |                                                 |
           +-------------------------------------------------+

		%%%%%%%%%%%%%%%%%%
		+-----------------+
		|Things to come.  |
		+-----------------+----------------------------+
		|Practice mode for duel.                       |
		|Just like regular duel expect you cant die    |
		|You get infinite ammo                         |
		|And it announces to you How well of shot      |
		|example: 1-100 rating on MDM shot.            |
		|100 being perfect shot.                       |
		+----------------------------------------------+-------------------------+
		|1v1 Option - Ingame time reset and counter.                             |
		|No public speaking for focus.                                           |
		|Everyone else gets no mission boundaries and sent to another copy of map|
		|where they can play if they dont wanna watch.                           |
		|Obs team is disabled during all matches, including 1v1 mostly.          |
		|Anyone not in the 1v1 auto Dies when entered the 1v1 area.              |
		+------------------------------------------------------------------------+
		|Practice map - D side, O side                                           |
		|D has operator for jugg bots, det bots, cappers.                        |
		|O has operator for all deployables.                                     |
		+------------------------------------------------------------------------+
		|SBA scoring redone.                                                     |
		|New way of scoring that applies to SBA and skill.                       |
		|Points for deploying, little for deployable kills.                      |
		|Beyond that Damage done to objects - Can add up.                        |
		|Damage done to players - Bigger points.                                 |
		|Points should equal contribution of game, Player of game.               |
		|IE: A jugg kills the shocks, sets off shields for juggs, takes out invos|
		|will have a better score than a jugg who just shoots HP.                |
		+------------------------------------------------------------------------+
		|No-fog/Happy mod steps                                                  |
		|Bots under maps sitting on cameras, to confuse the IFF (arrows)         |
		|A screenshot command to steal your picture and save to server.          |
		|Happymod code to lag you if used happymod.                              |
		|A IFF/Nofog Test - for those in query.                                  |
		+------------------------------------------------------------------------+
		|                                                                        |
		|Fstat like hits.                                                        |
		|A crosshair that will blink when every you damage someone.              |
		|nomore wonder if you MDM'ed that jugg.                                  |
		|Nomore wondering is u emped that jugg.                                  |
		+------------------------------------------------------------------------+
