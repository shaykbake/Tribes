$Shifter::badwordlist0="FUCK";
$Shifter::badwordlist1="cock";
$Shifter::badwordlist2="dick";
$Shifter::badwordlist3="pussy";
$Shifter::badwordlist4="fucker";
$Shifter::badwordlist5="fuk";
$Shifter::badwordlist6="fyk";
$Shifter::badwordlist7="nigger";
$Shifter::badwordlist8="bitch";
$Shifter::badwordlist9="fuq";
$Shifter::badwordlist10="shit";
$Shifter::badwordlist11="whore";
$Shifter::badwordlist12="slut";
$Shifter::badwordlist13="fuck";

