To install VIP Assassination unzip this to your Tribes directory and recreate sub-directories.  If for some reason this doesn't work, copy the VIP.cs file out and place it in your Tribes\base\ directory.  Place all missions in your Tribes\base\missions directory.

For information on how to play VIP Assassination go to:

http://www.planetstarsiege.com/vip/overview.html

For the latest news or updates of VIP Assassination go to the VIP Assassination site:

http://www.planetstarsiege.com/vip/

In order to report a bug or make a suggestion send e-mail to nagorak@home.com or post on the VIP Assassination Message Board:

http://pub8.ezboard.com/bvipassassination.html

To discuss strategies, tactics or anything related to VIP go to the VIP Assassination Message Board:

http://pub8.ezboard.com/bvipassassination.html