Title:
	Extreme Frisbee
	for StarSiege Tribes

	Version 1, BETA

Installation:
	Unzip the file this readme.txt is in, into your Tribes dir.
 	Make sure that you have the "create subdirectory " option on.
 	If your zip program does not have one of these options, put
 	the file "frisbee.cs" into the Tribes/base dir. Then put the
 	map files (*.mis and *.dsc) into the Tribes/base/missions
 	dir.

Hosting a server:
	Make sure that you have followed the above directions
	properly. Then host a server. To have your server play 		
	Extreme Frisbee change the map to any frisbee map.

Maps in ZIP:
	-Desert Frisbee
	-Mudpie Frisbee
	-No Man's Frisbee

Contact:
	Please send comments and suggestions to
	"gilthri@unforgettable.com"

	Also, visit the Extreme Frisbee homepage at:
	"www.planetstarsiege.com/frisbee/"