----------------------------------------------------------------
Name: Insomniax.net Admin Enhancements.
Version: 0.6b Beta (For TRIBES Version 1.2)
Date: 3-2-99
Author: Kevin Savage (*IX*Savage1)
Email: Savage1@insomniax.net
URL: http://www.insomniax.net
Purpose: To give Server Admins More control and flexability. 
Current Addititions: (Described in Detail Below)
	Anti-TK Settings.
	Out of Bounds Kill. (Adjustable)
	Disabling of Public Admin Commands. 
	Disable Admin Vote.
	Ability to Purge Public Admins. 
	Ability to Appoint a Public Admin. 

Notes: Some people have been taking code from this mod and pasting
       it into their own. What can I do im handing this out for free.
       if you do use this code I would appreciate a mention as to 
       where you got the information and/or code. Thanks.
Known Bugs: Anti-TK has problems when combined with other Mods.
	    Other Possible problems may arise when combining Mods.
---------------------------------------------------------------

Client Install: NONE.
	This is a Server Side Only Script. (Seriously)

Server Install: 
	1. Unzip IXAdmin06b.zip into default Tribes Dir.
	   (where tribes.exe resides - UNZIP WITH PATH INFORMATION)
	2. Command line to run the mod. 	
	   Just add "-mod ixadmin" to your current Server Command Line.
	   For Example:
		tribes.exe -mod ixadmin
	   If you have problems running a server please go to 
	   http://www.tribesplayers.com/
	   all the info you need is there.

When installed The Files Should be here: 
 Tribes\config\ixadmin.cs
 Tribes\insomniax\admin.cs
 Tribes\insomniax\game.cs
 Tribes\insomniax\gui.cs
 Tribes\insomniax\objectives.cs
 Tribes\insomniax\Readme.txt

NOTE: If these files are not in these folders ..put them there.

Full Instructions for the Mod will be Posted at the site as
soon as I get the chance to get them up. for now any questions 
will be answered on the message board. The URL is
http://www.insomniax.net/IXTribes.cgi. 

---------------------------------------------------------------

  Please post any and all feedback on the TRIBES Message board 
  on our web site. http://www.insomniax.net. This mod is still
  being created at this time. Bugs and suggestions will be worked
  on. Thanks.
  	-*IX*Savage1

---------------------------------------------------------------
Current Additions:
---------------------------------------------------------------
NOTE: When I mention the Options Menu I am refering to the Menu 
	you access by pressing TAB While in the game. 
	When I refer to "Super Admin" I am refering to the Admin
	with the SAD Password or a player Hosting the game.
	When i refer to a Public Admin I am refering to someone who 
	has either been appointed Admin by a Super Admin(See below) 
	or has been Voted into being Administrator. 

--------------------------------------------
 Anti-Team Killer 
--------------------------------------------
Server Variables:
	$Insomniax::tkClientLvl = "0";
	$Insomniax::tkLimit = "5";
	$Insomniax::tkMultiple = "3";
	$Insomniax::tkServerLvl = "1";
	$Insomniax::BanKickTime = "600"

    The Anti Team Killer part of this mod is simple but has many
  options. All Settings can be set during the game via the Options
  Menu.  There are Two Settings for the Anti-TK part of this mod. 
  Server Settings and Client Settings. The Server Settings determine
  what action the server will take when a TK is encountered. The client
  Settings determine to what severity the Client is allowed to Dispose
  of his last Team Killer. Here's how it works. 

  Ban/Kick Time: $Insomniax::BanKickTime
	    This variable sets the amount of time in seconds the Team 
	    Killer Kick will Ban the Player. This also effects All Normal
	    Kicks as well. This does Not Effect the Ban Option's Ban time.

  TK Limit: $Insomniax::tkLimit
	    This is the number of Team Kills that trigger a response
	    by the server and/or allow action by the victim client. 

  TK Server Level: $Insomniax::tkServerLvl 
	0: Logging of TK's Only.
	   This means that No action is taken by the server when 
           $Insomniax::tkLimit is Reached by a player. 
	1: Auto Vote Team Killer.
	   This Automaticly Votes to Kick the Team Killer when they
	   reach $Insomniax::tkLimit or any Multiple of $Insomniax::tkLimit
	   For example:
		$Insomniax::tkLimit = "2"; 
		I Team Kill 2 Times. The Server Auto Votes to Kick me.
		The Vote Fails. I Stay on the Server. The server will 
		then Initiate a Vote when I reach 4,6,8 Team Kills. 
		If Im still on the server it will Vote at every Multiple
		of 2.  
	2: Auto Vote Until Kicked.
	   This will work exactly like level 1 only except when the Team 
	   Kills Reach $Insomniax::tkMultiple of $Insomniax::tkLimit 
	   the Player is Kicked from the server. 
	   for example:
		$Insomniax::tkLimit = "2";
		$Insomniax::tkMultiple = "3";
		Same as the scenerio above, the server automaticly 
		initiates a vote at 2 Team Kills, and again at 4.
		When  6 Team Kills have been reached (2 * 3 = 6) 
		I am Kicked from the Server for Team Killing. 
	3: Auto Kick.
	   This Setting Kicks Team Killers as soon as the number 
	   of Team Kills Reaches $Insomniax::tkLimit.

  TK Multiple: $Insomniax::tkMultiple 
	Mentioned above this applys only to Server Level 2. 

  TK Client Level: $Insomniax::tkClientLvl = "0";
	0: Vote Option.
	   When a player Reaches the Team Kill Limit, as explained in the 
	   server level information above, all the victims of that player 
	   get an easy vote option to kick the Team Killer on the option 
         menu. It is an additional option to make it easier for people
	   to vote out the trouble makers.
	1: Kick Option.
	   If a player reaches the Team Kill Limit. All the victims of that
	   player have the power to kick that player outright. The vote option
	   is replaced with a Kick. Anyone with or without Admin status has
	   the power to kick a team killer if they have reached the TK Limit.
	   Only the victims of this killer have that option. (Exactly like the 
	   vote option above).

  NOTE: Team Kills are currently NOT RESET Between maps. as long as your on
	  the server it remembers how many times you have Team Killed. This also 
	  applies if you change teams. This may be changed in the future to reset
	  between maps. 

  Player TK Info: 
	Also Included with the Team Killer Options is Team Killer Information
	on any player at any time. Just click on their name in the options menu.
	It will display the last Person to Team Kill them, as well as who they
	last Team Killed and the Number of total Team Kills they currently have. 
	No more guessing weather or not they killed anyone. It's all there. 
	This display also shows the current Server and Client Level settings. 
	NOTE: If the Super Admin views the player's TK Information it does not
		display the Client Level information. This has been replaced with 
		the actual Players IP to make banning real problem players easier. 

--------------------------------------------
 Out of Bounds Kill
--------------------------------------------
Server Variables: 
	$Insomniax::LeaveAreaTime = "0";

    The Out of bounds kill is a server option that is not on by default but 
  may be enabled by the server admin.  The Time may be changed at will by 
  the admin using the Options menu.  It supports times between 10 and 60
  seconds, and is disabled(Zero Seconds) by default. 

--------------------------------------------
 Toggle Admin Voting
--------------------------------------------
Server Variables:
	$Insomniax::PAVote = "true";

    The Admin voting can be turned off. When off this doesnt allow the 
  player to vote themselves or anyone else to be the server admin. 
  The "Public Admin" voting may be toggled using the Options menu. 
  This is allowed ("true") by default.

--------------------------------------------
 Appoint Public Admin
--------------------------------------------
Server Variables: 
	None.

    Any super admin has the power to Appoint a player to be an Admin. 
  The "Appointed Admin" has the same power as a "Public Admin". Which
  is the same as being voted Admin. The "Appointed Admin" is subject
  to the Public Admin Lockouts. (Explained Below). To use this option
  select the player name from the option menu and select "Admin <player>"

--------------------------------------------
 Public Admin Lockouts
--------------------------------------------
Server Variables: 
	$Insomniax::PABan = "true";
	$Insomniax::PAKick = "true";
	$Insomniax::PAMission = "true";
	$Insomniax::PAModOptions = "true";
	$Insomniax::PAResetDefaults = "true";
	$Insomniax::PATeamChange = "true";
	$Insomniax::PATeamDamage = "true";
	$Insomniax::PATeamInfo = "true";
	$Insomniax::PATimelimit = "true";
	$Insomniax::PATourneyMode = "true";

    The Super Admin can turn on/off access to the Admin functions available 
  to the Public Admin.  This Includes Every option the Admin has on the Options
  menu. When an Option has been turned Off ("false") then they have the option 
  displayed as if they were not the administrator. All of these variables have 
  two values. "true" means the option is allowed, and "false" means the option 
  is not allowed. 
  For Example:
	  If the Kick option has been turned off, and a public admin checks the options 
	menu to kick a player, they find the "Vote to kick player" option instead of 
	the "Kick player" option. 
  All Admin Options are On by Default. ("true" is On, "false" is Off. When an Option 
  is on then the Public Admin CAN execute the option.)

  The Variables:
	
	$Insomniax::PABan
		This toggles the "Ban Player" Option.
	$Insomniax::PAKick
		This toggles the "Kick Player" Option.
	$Insomniax::PAMission
		This toggles weather or not a Public Admin can change the current mission.
		If this is "false" then they have to Vote to change the mission.
	$Insomniax::PAModOptions
		This toggles the Mod options menu for the Public Admin. This menu includes
		The Server and Client TK Level settings as well as the Out of bounds
		kill time. (Public Admins never have access to the Lockout Toggles)
	$Insomniax::PAResetDefaults
		This toggles the "Reset Server to Defaults" option.
	$Insomniax::PATeamChange
		With this Option set "false" then Public Admins cannot change anyones 
		team. 
	$Insomniax::TeamDamage
		This toggles the Public Admins ability to Enable/Disable team damage.
	$Insomnaix::TeamInfo
		This Blocks Public Admins from executing the comand SetTeamInfo().
	$Insomniax::TimeLimit
		This toggles the Set Time Limit Option on the Menu.
	$Insomniax::TourneyMode
		This toggles Public Admin Option for Tourney Mode/FFA Mode

--------------------------------------------
 Purge Public Admins
--------------------------------------------
Server Variables:
	NONE

    This option is accessable from the Insomniax Mod Settings selection on the 
  Options Menu. Purging Public Admins removes Admin status from all players that
  aren't Super Admins.  This is meant for "cleaning house" when you need to.

--------------------------------------------
 Game Changes
--------------------------------------------
THERE ARE NO GAME PLAY CHANGES IN THIS MOD!
This is strictly an Admin Mod to help Admins 
manage their servers. No weapons, Items or 
anything of the sort are in this Mod. 

---------------------------------------------------------------
Possible Future Additions:
---------------------------------------------------------------

  Fair Teams got pushed to the back burner. Hope to get it in soon.
  Mod Manual and Web site for the Mod itself. Let ppl know what is
  going on in here :).  All future additions will ..and ARE being 
  discussed on the web site's Message board. Feel free to hand 
  over your two cents.
	-*IX*Savage1

----------------------------------------------------------------
Disclaimer: I am not responsable for any damage this game 
	    modification may cause you or anything having to do 
	    with you. If you lose your job because you play this
	    game nite and day, it is purely your responsibility.
	    I also am not responsable for any hardware failures 
	    or software problems that may arise in TRIBES. For 
	    problems of that nature contact the game manufacturer.
	    If you believe this modification has problems please 
	    report them to me so that I may look into it. -Savage1
----------------------------------------------------------------