----------------------------------------------------------------
Name: Insomniax.net TRIBES Mod.
Version: 0.8 (For TRIBES Version 1.4.1)
Date: 5-24-99
Author: Kevin Savage (*IX*Savage1)
Email: Savage1@insomniax.net
URL: http://www.insomniax.net/mods
Purpose: To Maintain Game Balance and Increase Complexity. 
	 Also Increasing Intensity of Gameplay, with Teamwork. 

Notes: Other Mods have used code from this one and promised to 
       document what parts were used, so that my hard work would
       be acknoledged.  As of Renegades 2.0 (Today) there still
       is no credit given by the Mod's maker "Mephisto".  Ever 
       scince day 1 that mod has used Insomniax Mod Code as well
       as others. And scince day one has not documented thier use.
       This is a prime example of what not to do.  If you use this
       code, please have the decency to mention where you got it.
       It's only proper to give credit for the hard work of others
       that you use for your own benifit.  Under those conditions 
       you have my blessing to use the code as you see fit.  One 
       problem I do have however, please do NOT use this mod with
       the name Insomniax if you have made changes. I have had 
       people literally yell at me for changes or additions I did
       NOT make.  I find this somewhat taxing. Please, if you make
       changes, change the name too. 

Thanks: To the Tribes Dev Team, and All those at Dynamix/Sierra that
	make this game possible. I'd also like to thank them for
	answering my emails with questions about this or that, and 
	taking bug reports. They seem to truely care about what goes 
	into the game. I admire them for that. Thanks.

Known Bugs: Various problems occur when this mod is combined with others.
            If you want features from other mods incorperated into this 
 	    mod then let me know and we'll see if its worth doing. 

NOTICE: THIS IS NOT MEANT TO BE COMBINED WITH THE 
	INSOMNIAX ADMIN MOD.  BOTH MODS WORK JUST 
	FINE BY THEMSELVES. 
---------------------------------------------------------------

Client Install: NONE. 
	Notes for Client Playing the mod. Weapons can be accessed
	by Selecting "Next Weapon" or "Previous Weapon". There are
	no Numbers assigned to the new weapons. (Default key is 'Q')
	In order to bind the weapons and items you need to use(ItemName)
	The Item Names for each item is listed with the items below.

Server Install: 
	1. Unzip IXTribes08.zip into default Tribes Dir.
	   (where tribes.exe resides - UNZIP WITH PATH INFORMATION)
	This means:

	When installed The Files Should be here: 
		Tribes\config\insomniax.cs
	*new* 	Tribes\config\ixUserList.cs
		Tribes\insomniax\Readme.txt
		Tribes\insomniax\scripts.vol
		Tribes\insomniax\WhatsNew.txt
		Tribes\insomniax\WhatsOld.txt
	 
	Any Maps Included with this Mod should be here:
		Tribes\insomniax\missions

	NOTE: If these files are not in these folders ..put them there.
	      IF THIS IS NOT THE FIRST TIME INSTALLING and you have the 
	      insomniax.cs file already you dont need to unzip this
	      one. You can choose to add the new variables, or not.
	      The server will choose default values. Settings can be
	      changed during the game and are saved when the server
	      exits normally. If you want to save the config while
	      the game is active just execute the ixSave(); command
	      at the console.
	
	2. Command line to run the mod.
	   (A command line is what you use to start the game.
	    for windows its called a shortcut.)

	   Just add "-mod insomniax" to your current Server Command Line.
	   For Example:
		Running Normally. 
			tribes.exe
		Running this Mod.
			tribes.exe -mod insomniax

	   If you have a custom Server Config then add the +exec Parameter
	   BEFORE The -mod parameter. 	
	   For Example:
		Running Normally. 
			tribes.exe +exec MyConfig.cs
		Running this Mod.
			tribes.exe +exec MyConfig.cs -mod insomniax

	   If your runing dedicated and have a special server config. 
	   I suggest you use infinitespawn. (get it at tribesplayers.com)
	   For Example:
		Running Normally. 
			infinitespawn *tribes +exec MyConfig -dedicated
		Running this Mod.
			infinitespawn *tribes +exec MyConfig -mod insomniax -dedicated

	   If For Some Reason insomniax.cs is not executing when the mod loads. 
	   (It should be automatic) Then just add it to the command line.
	   For Example:
		Running Normally. 
			infinitespawn *tribes +exec MyConfig -dedicated
		Running this Mod and Executing the Mod Config.
			infinitespawn *tribes +exec MyConfig +exec insomniax -mod insomniax -dedicated

   If you dont know what im talking about then please learn
   how to run a server before yelling at me because you dont
   know how.

Here are a few URLs
	http://www.tribesplayers.com/tribesplayers/server-basic-config.html
 
	http://www.tribesplayers.com/tribesplayers/server-advanced-admin.html
 
	http://www.tribesplayers.com/tribesplayers/server-mods.html
 
	http://www.tribesplayers.com/tribesplayers/faq.html#sec1 


Full Instructions for the Mod can be found at the Mod Site (Still under construction)
	http://www.insomniax.net/mods

All Questions will be answered on the Mod message board.
Please post any and all feedback you have here. 
	http://www.insomniax.net/IXTribes.cgi. 

---------------------------------------------------------------
Whats IN the Mod?
---------------------------------------------------------------

  Check the Files WhatsOld.txt for a list of what was in this mod
  before this version, and WhatsNew.txt for what is new with this 
  version of the mod. (Bug Fixes etc.) For more News and Info on 
  this mod go to the Mod Web site mentioned above. 

----------------------------------------------------------------
Disclaimer:
	    I am not responsible for any damage this game 
	    modification may cause you or anything having to do 
	    with you. If you lose your job because you play this
	    game nite and day, it is purely your responsibility.
	    I also am not responsible for any hardware failures 
	    or software problems that may arise in TRIBES. For 
	    problems of that nature contact the game manufacturer.
	    If you believe this modification has problems please 
	    report them to me so that I may look into it. 
		I am not responsible for any bugs or problems caused
	    from copying this code into another mod. I do not claim
	    to support any other mod using my code. If they have
	    problems, bother them, not me. -*IX*Savage1
----------------------------------------------------------------