//=============================================================================================================================
//===Server Stuff===
$Server::HostName = "Knights Server";		// Server Name
$Server::Port = "28001";			// Port used for client connections to server (usually 28001)
$Server::HostPublicGame = true;			// Server is shown in MasterServer List
$Server::Password = "";				// Password needed to join server
$AdminPassword = "Knights";			// Local SuperAdmin password - CHANGE THIS



//=============================================================================================================================
//===Info=== 
//(<jc> = center justified, <f1> = tan font, <f2> = white font, <f3> = orange font, \n = new line)

//===Server information that is listed on MasterServer List===
$Server::Info = "Knights\nAdmin: high ranking }KR{\nEmail: darkknight7685@yahoo.com";

//===Message of the day listed once on the server===
$Server::JoinMOTD = "<jc><f1>\n}KR{'s home.\n}KR{ is recruiting. Website is <f3>www.krtribe.cjb.net";

//===Information listed when you are joining the server===
$MODInfo = "<jc><f2>www.krtribe.cjb.net\n<f1>Welcome to <f3>}KR{'s Realm<f1>Email admin at darkknight7685@yahoo.com";

//=============================================================================================================================
//===Telnet (Console) Parameters===
$TelnetPort="23";				// Port for telnet connections
$TelnetPassword="Knights";			// Password for telnet connections CHANGE THIS


//=============================================================================================================================
//===Server Connection Parameters===
$pref::LastMission = "Raindance";		// This sets the first map in rotate when server launches (make sure it is spelled correctly)



//=============================================================================================================================
// Player Parameters
$Server::MaxPlayers = "8";			// Maximum number of client connections allowed
$Server::AutoAssignTeams = true;		// Server assigned teams
$Server::respawnTime = 2; 			// Number of seconds before a respawn is allowed
$Server::TimeLimit = 30;			// Mission time limit in minutes
$Server::warmupTime = 10;			// Time (in seconds) players are left standing before movement is allowed

//=============================================================================================================================
//===Team Parameters===
$Server::teamName[0] = "}KR{";		// Team 1 Name
$Server::teamSkin[0] = "beagle";		      // Team 1 Skin
$Server::teamName[1] = "All";		      // Team 2 Name
$Server::teamSkin[1] = "dsword";		      // Team 2 Skin
$Server::teamName[2] = "Allies";		// Team 3 Name
$Server::teamSkin[2] = "cphoenix";		      // Team 3 Skin
$Server::teamName[3] = "Fools";		// Team 4 Name
$Server::teamSkin[3] = "swolf";			// Team 4 Skin
$Server::teamName[4] = "Generic 1";		// Team 5 Name
$Server::teamSkin[4] = "base";			// Team 5 Skin
$Server::teamName[5] = "Generic 2";		// Team 6 Name
$Server::teamSkin[5] = "base";			// Team 6 Skin
$Server::teamName[6] = "Generic 3";		// Team 7 Name
$Server::teamSkin[6] = "base";			// Team 7 Skin
$Server::teamName[7] = "Generic 4";		// Team 8 Name
$Server::teamSkin[7] = "base";			// Team 8 Skin


//=============================================================================================================================
//===Voting Parameters===
$Server::MinVoteTime = 45;			// Time allotted for voting
$Server::VotingTime = 20;			// Length of votes if people are voting.
$Server::VoteWinMargin = 0.6999;		// Ratio of Yes to No votes needed to pass
$Server::VoteAdminWinMargin = 0.6999;		// Ratio of Yes to No votes needed to pass
$Server::MinVotes = 1;				// Minimum number of votes needed to pass
$Server::MinVotesPct = 0.5;			// Percentage of available votes needed to pass a vote
$Server::VoteFailTime = 30; 			// 30 seconds if your vote fails + $Server::MinVoteTime


//==============================================================================================================================
//===Other Parameters===
$Server::TeamDamageScale = 0;			// Team damage, 0 = Off, 1 = On
$Server::TourneyMode = false;			// Tournament mode

//==============================================================================================================================
//===Knights Only=== (for Auto Admin Change the NAMES or IPS)
$Knights::UsePersonalSkin = True;
$Knights::FairTeams = True;

$Server::AutoAdmin[0] = "}KR{Dark Knight";
$Server::AutoAdmin[1] = "}KR{ShadowKnight";
$Server::AutoAdmin[2] = "}KR{CLob