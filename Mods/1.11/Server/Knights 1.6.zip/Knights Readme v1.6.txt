

}Knights Version 1.6{

Creator - }KR{Dark Knight
  Email - darkknight7685@yahoo.com
Website - http://www.krtribe.cjb.net
  Starting Date - 8/26/2003
Finishing Date - 9/02/2003

I would like to welcome you to the Knights Version 1.6 Modification for Tribes.
  This is a serverside mod. You only have to install the scripts.vol and the 
serverConfig.cs to run the mod. The mod works on both Dedicated and 
  Undedicated servers. I am glad you decided to try it out and I hope you won't
be disappointed. For no reason whatsoever should you edit the mod. You shall
  not unvolume the mod at all. You cannot steal script from my mod. You must ask
me what script you need and I'll give it to you. Now, on to installation!

}Installation{

1). Extract the files from the zip folder.
  2). Make a folder in your C:\Dynamix\Tribes folder called Knights.
3). Place the scripts.vol in this folder.
  4). Place the serverConfig.cs in your C:\Dynamix\Tribes\Config folder.
5). Place the icons on your desktop.
  6). It should be installed and run fine.
7). Send email to darkknight7685@yahoo.com telling that the mod is installed and 
  running.

}Special Thanks{

Special thanks to: }KR{CLob for hosting the mod, }KR{ShadowKnight for hosting 
  the mod, {MA}Sword for modding tutorial(didn't help much at all), Plasmatic 
for Script help, }KR{ShadowKnight for modding ideas, +]-[+Armagedon for giving
  me a reason to mod(TO BEAT YOUR ASS BITCH), to all the people who played 
the mod, and said it was fun, and last, to my clan, for supporting me all the way.

          