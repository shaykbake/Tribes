//----------------------
// Bot Skill Levels
//----------------------
// Select the skill level you want the bots to play at
// "Easy"
// "Beginner"
// "Advanced"
// "Medium"
// "Master"
// "Superior"
// "God"
//----------------------
$BOTAI::LEVEL = "Advanced";

//----------------------
// Bot Names
//----------------------
// Change the names of the bots here
$AI::BOTNAME[0]  ="Xihon";
$AI::BOTNAME[1]  ="Halvex";
$AI::BOTNAME[2]  ="Max";
$AI::BOTNAME[3]  ="Lenox";
$AI::BOTNAME[4]  ="DeadBazsi";
$AI::BOTNAME[5]  ="Delila";
$AI::BOTNAME[6]  ="Carlos";
$AI::BOTNAME[7]  ="YouSuck";
$AI::BOTNAME[8]  ="Anti-GraV";
$AI::BOTNAME[9]  ="Charger";
$AI::BOTNAME[10] ="KiCkEr";
$AI::BOTNAME[11] ="Bomber";
$AI::BOTNAME[12] ="LoSeR";
$AI::BOTNAME[13] ="Zeus";
$AI::BOTNAME[14] ="Ivan";
$AI::BOTNAME[15] ="Bloody";
$AI::BOTNAME[16] ="Morpheus";
$AI::BOTNAME[17] ="Csumi";
$AI::BOTNAME[18] ="Tanja";
$AI::BOTNAME[19] ="MrGex";
$AI::BOTNAME[20] ="Destroyer";
$AI::BOTNAME[21] ="Eraser";
$AI::BOTNAME[22] ="NoChance";
$AI::BOTNAME[23] ="Bernefo";
$AI::BOTNAME[24] ="Lucifer";
$AI::BOTNAME[25] ="NEO";
$AI::BOTNAME[26] ="AIDS";
$AI::BOTNAME[27] ="Napoleon";
$AI::BOTNAME[28] ="Joker";
$AI::BOTNAME[29] ="TheKing";
$AI::BOTNAME[30] ="Quark";
$AI::BOTNAME[31] ="Piton";
$AI::BOTNAME[32] ="Demorex";
$AI::BOTNAME[33] ="Qix";
$AI::BOTNAME[34] ="Saviour";
$AI::BOTNAME[35] ="Mutator";
$AI::BOTNAME[36] ="Retro";
$AI::BOTNAME[37] ="Winner";
$AI::BOTNAME[38] ="Terminator";
$AI::BOTNAME[39] ="Porx";

//----------------------
// Bot Weapon Loadout
//----------------------
// Change the loadout for each bot. *NOTE* Giving a light a mortar, or a heavy a sniper rifle WILL NOT WORK!!!
// Guard - Heavy
// Weapon Setup
$VoOBoT::weapon[Guard, 1] = "Chaingun";         // in-air > 50
$VoOBoT::weapon[Guard, 2] = "PlasmaGun";        // in-air
$VoOBoT::weapon[Guard, 3] = "Mortar";           // > 120
$VoOBoT::weapon[Guard, 4] = "Mortar";           // > 100
$VoOBoT::weapon[Guard, 5] = "DiscLauncher";     // > 70
$VoOBoT::weapon[Guard, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Guard, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Guard, 8] = "PlasmaGun";        // close-range

// Ammo Setup
$VoOBoT::ammo[Guard, BulletAmmo] = 50000;
$VoOBoT::ammo[Guard, PlasmaAmmo] = 500;
$VoOBoT::ammo[Guard, GrenadeAmmo] = 500;
$VoOBoT::ammo[Guard, MortarAmmo] = 150;
$VoOBoT::ammo[Guard, DiscAmmo] = 500;

// Demo - Medium
// Weapon Setup
$VoOBoT::weapon[Demo, 1] = "Chaingun";         // in-air > 50
$VoOBoT::weapon[Demo, 2] = "DiscLauncher";     // in-air
$VoOBoT::weapon[Demo, 3] = "DiscLauncher";     // > 120
$VoOBoT::weapon[Demo, 4] = "DiscLauncher";     // > 100
$VoOBoT::weapon[Demo, 5] = "GrenadeLauncher";  // > 70
$VoOBoT::weapon[Demo, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Demo, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Demo, 8] = "PlasmaGun";        // close-range

// Ammo Setup
$VoOBoT::ammo[Demo, BulletAmmo] = 50000;
$VoOBoT::ammo[Demo, PlasmaAmmo] = 500;
$VoOBoT::ammo[Demo, GrenadeAmmo] = 500;
$VoOBoT::ammo[Demo, DiscAmmo] = 500;

// Painter - Light
// Weapon Setup
$VoOBoT::weapon[Painter, 1] = "DiscLauncher";     // in-air > 50
$VoOBoT::weapon[Painter, 2] = "DiscLauncher";     // in-air
$VoOBoT::weapon[Painter, 3] = "Blaster";          // > 120
$VoOBoT::weapon[Painter, 4] = "DiscLauncher";     // > 100
$VoOBoT::weapon[Painter, 5] = "GrenadeLauncher";  // > 70
$VoOBoT::weapon[Painter, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Painter, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Painter, 8] = "Blaster";          // close-range

// Ammo Setup
$VoOBoT::ammo[Painter, GrenadeAmmo] = 500;
$VoOBoT::ammo[Painter, DiscAmmo] = 500;

// Sniper - Light
// Weapon Setup
$VoOBoT::weapon[Sniper, 1] = "DiscLauncher";     // in-air > 50
$VoOBoT::weapon[Sniper, 2] = "DiscLauncher";     // in-air
$VoOBoT::weapon[Sniper, 3] = "LaserRifle";       // > 120
$VoOBoT::weapon[Sniper, 4] = "DiscLauncher";     // > 100
$VoOBoT::weapon[Sniper, 5] = "GrenadeLauncher";  // > 70
$VoOBoT::weapon[Sniper, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Sniper, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Sniper, 8] = "DiscLauncher";     // close-range

// Ammo Setup
$VoOBoT::ammo[Sniper, GrenadeAmmo] = 500;
$VoOBoT::ammo[Sniper, DiscAmmo] = 500;

// Medic - Heavy
// Weapon Setup
$VoOBoT::weapon[Medic, 1] = "Chaingun";         // in-air > 50
$VoOBoT::weapon[Medic, 2] = "DiscLauncher";     // in-air
$VoOBoT::weapon[Medic, 3] = "Mortar";           // > 120
$VoOBoT::weapon[Medic, 4] = "Mortar";           // > 100
$VoOBoT::weapon[Medic, 5] = "DiscLauncher";     // > 70
$VoOBoT::weapon[Medic, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Medic, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Medic, 8] = "Chaingun";         // close-range

// Ammo Setup
$VoOBoT::ammo[Medic, BulletAmmo] = 50000;
$VoOBoT::ammo[Medic, PlasmaAmmo] = 500;
$VoOBoT::ammo[Medic, GrenadeAmmo] = 500;
$VoOBoT::ammo[Medic, MortarAmmo] = 500;
$VoOBoT::ammo[Medic, DiscAmmo] = 500;

// Miner - Light
// Weapon Setup
$VoOBoT::weapon[Miner, 1] = "DiscLauncher";     // in-air > 50
$VoOBoT::weapon[Miner, 2] = "PlasmaGun";        // in-air
$VoOBoT::weapon[Miner, 3] = "DiscLauncher";     // > 120
$VoOBoT::weapon[Miner, 4] = "DiscLauncher";     // > 100
$VoOBoT::weapon[Miner, 5] = "GrenadeLauncher";  // > 70
$VoOBoT::weapon[Miner, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Miner, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Miner, 8] = "PlasmaGun";        // close-range

// Ammo Setup
$VoOBoT::ammo[Miner, PlasmaAmmo] = 500;
$VoOBoT::ammo[Miner, GrenadeAmmo] = 500;
$VoOBoT::ammo[Miner, DiscAmmo] = 500;

// Defender - Heavy
// Weapon Setup
$VoOBoT::weapon[Defender, 1] = "Chaingun";         // in-air > 50
$VoOBoT::weapon[Defender, 2] = "PlasmaGun";        // in-air
$VoOBoT::weapon[Defender, 3] = "Mortar";           // > 120
$VoOBoT::weapon[Defender, 4] = "Mortar";           // > 100
$VoOBoT::weapon[Defender, 5] = "DiscLauncher";     // > 70
$VoOBoT::weapon[Defender, 6] = "GrenadeLauncher";  // > 40
$VoOBoT::weapon[Defender, 7] = "DiscLauncher";     // > 20
$VoOBoT::weapon[Defender, 8] = "PlasmaGun";        // close-range

// Ammo Setup
$VoOBoT::ammo[Defender, BulletAmmo] = 50000;
$VoOBoT::ammo[Defender, PlasmaAmmo] = 500;
$VoOBoT::ammo[Defender, GrenadeAmmo] = 500;
$VoOBoT::ammo[Defender, MortarAmmo] = 150;
$VoOBoT::ammo[Defender, DiscAmmo] = 500;

//----------------------
// Bot Auto-Spawn
//----------------------
// Select which and how many bots auto-spawn on each map.
//
// To set certain bots to auto-spawn on a map, follow this example:
// Replace "Raindance" with the map you want the bots to auto-spawn on
// Team0 = Team1
// Team1 = Team2
// I have to do it like this because of the way Tribes handles teams.
//
// RAINDANCE
// Team 1
$VoOBoT::autoSpawn[Guard, Team0, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = female;
$VoOBoT::autoSpawn[Demo, Team0, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team0, Raindance] = male;
$VoOBoT::autoSpawn[Painter, Team0, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team0, Raindance] = female;
$VoOBoT::autoSpawn[Sniper, Team0, Raindance] = 2;
$VoOBoT::autoSpawnGender[Guard, Team0, Raindance] = male;
$VoOBoT::autoSpawn[Medic, Team0, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team0, Raindance] = female;
$VoOBoT::autoSpawn[Miner, Team0, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team0, Raindance] = male;
$VoOBoT::autoSpawn[Defender, Team0, Raindance] = 2;
$VoOBoT::autoSpawnGender[Guard, Team0, Raindance] = female;
// Team 2
$VoOBoT::autoSpawn[Guard, Team1, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = female;
$VoOBoT::autoSpawn[Demo, Team1, Raindance] = 2;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = male;
$VoOBoT::autoSpawn[Painter, Team1, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = female;
$VoOBoT::autoSpawn[Sniper, Team1, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = male;
$VoOBoT::autoSpawn[Medic, Team1, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = female;
$VoOBoT::autoSpawn[Miner, Team1, Raindance] = 2;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = male;
$VoOBoT::autoSpawn[Defender, Team1, Raindance] = 1;
$VoOBoT::autoSpawnGender[Guard, Team1, Raindance] = female;