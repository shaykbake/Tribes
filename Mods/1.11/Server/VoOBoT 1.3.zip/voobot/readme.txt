  /////////
 ///INFO//
/////////
//MoD NaMe:  VoOBoT
//VeRsIoN:   1.3
//AuTHoR:    Ben "VoOdOo" Smith
//EmAiL:     stufuu@cache.net
//WeBPaGE:   http://voodoolair.scriptmania.com

  //////////
 ///ABOUT//
//////////
//This mod is basically a mod for a mod. It uses the Corwin bot mod, and reverts the weapons and gameplay
//back to BASE style play.

  ////////////////////
 ///VERSION HISTORY//
////////////////////
//	1.3 Fixed heavy armor bots not being able to use the Mortar
//	    Added a bigger and better config file where you can change skill level, bot names, and
//	      the bot weapon loadouts for each bot!!!
//	    New weapon change code that works faster, more efficiently, and fixes some bugs
//
//	1.2 Changed number of repair kits to 2, one for the bots use, the other for you =]
//	    Bots did not get hurt when they hit the ground too hard, this is now fixed
//	    Removed annoying DEBUGGING messages from bots. They still chat
//
//	1.1 Forgot that the bots got 3 repair kits, changed to 1
//	    Changed way bots use repair kit, works much more like a real repair kit, no self repair
//	    Took the Sniper Rifle away from the Defender (heavy)
//
//	1.0 Initial Release

  ///////////////////
 ///SUPPORTED MAPS//
///////////////////
//All maps work, but if the map is supported, it works better!
//
//Broadside
//Cakewalk
//Castles_2
//Citadels
//CoD03
//CoD04
//CoD06
//CoD08
//CoD11
//CoD22
//CoD23
//CoD29
//CoD34
//CoD35
//CoD36
//CoD39
//CoD42
//CoD49
//DangerousCrossing
//EDGE_CoD29
//Monolith
//PeakPerformance
//Prisioner_Of_War
//Raindance
//Towers

  /////////////////
 ///INSTALLATION//
/////////////////
//To install, extract to your <Tribes> folder.
//Then create a shortcut to Tribes and add the following in it's | Properties | Target |
//
//Tribes.exe -mod voobot
//
//If you want a dedicated server, add this
//
//Tribes.exe -mod voobot -dedicated

  //////////////////
 ///CONFIGURATION//
//////////////////
//To spawn bots in-game, press "tab" or the equivelant and go to VoOBoT Options | Add | <bot type> | <bot gender> |
//
//To remove a bot in-game, press "tab" or the equivelant and go to VoOBoT Options | Remove | <bot name> |
//
//To add auto-spawning bots for certain maps, go to your Tribes/config/BOTCFG.cs file, scroll down to the bottom of
//the file, and read the instructions for adding auto-spawning bots for certain maps.

That's all. Send feedback/questions to stufuu@cache.net