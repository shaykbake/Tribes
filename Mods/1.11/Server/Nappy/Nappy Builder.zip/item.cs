





$ItemFavoritesKey = "nappyBUILDER2_1"; 
$ItemPopTime = 30; 
$ToolSlot=0; $WeaponSlot=0; 
$BackpackSlot=1; 
$FlagSlot=2; 
$DefaultSlot=3; 

$AutoUse[Blaster] = True; 
$AutoUse[Chaingun] = True; 
$AutoUse[PlasmaGun] = True; 
$AutoUse[Mortar] = True; 
$AutoUse[GrenadeLauncher] = True; 
$AutoUse[LaserRifle] = True; 
$AutoUse[EnergyRifle] = True; 
$AutoUse[TargetingLaser] = False; 
$AutoUse[Fixit] = False; 
$AutoUse[ChargeGun] = True; 
$AutoUse[RocketLauncher] = True; 
$AutoUse[SniperRifle] = True; 
$AutoUse[WaveGun] = True; 
$AutoUse[Railgun] = True; 
$AutoUse[Bolt] = True; 
$AutoUse[Vulcan] = True; 
$AutoUse[Silencer] = True; 
$AutoUse[IonGun] = True; 
$AutoUse[TranqGun] = True; 
$AutoUse[HyperB] = True; 
$AutoUse[Omega] = True; 


$Use[Blaster] = True; 

$ArmorType[Male, LightArmor] = larmor; 
$ArmorType[Male, MediumArmor] = marmor; 
$ArmorType[Male, HeavyArmor] = harmor; 
$ArmorType[Male, ScoutArmor] = sarmor; 
$ArmorType[Male, BursterArmor] = barmor; 
$ArmorType[Male, EngArmor] = earmor; 
$ArmorType[Male, DragArmor] = darmor;
$ArmorType[Male, SpArmor] = spyarmor; 
$ArmorType[Male, AlArmor] = aarmor; 
$ArmorType[Male, DMArmor] = dmarmor; 
$ArmorType[Female, LightArmor] = lfemale; 
$ArmorType[Female, MediumArmor] = mfemale; 
$ArmorType[Female, HeavyArmor] = harmor; 
$ArmorType[Female, ScoutArmor] = sfemale; 
$ArmorType[Female, BursterArmor] = bfemale; 
$ArmorType[Female, EngArmor] = earmor; 
$ArmorType[Female, DragArmor] = darmor; 
$ArmorType[Female, SpArmor] = spyfemale; 
$ArmorType[Female, AlArmor] = afemale; 
$ArmorType[Female, DMArmor] = dmfemale; 
//=========================================DEFENDER
$ArmorType[Male, DefenderArmor] = defarmor;
$ArmorType[Female, DefenderArmor] = defarmor;
//==================================================



$ArmorName[larmor] = LightArmor; 
$ArmorName[marmor] = MediumArmor; 
$ArmorName[harmor] = HeavyArmor; 
$ArmorName[sarmor] = ScoutArmor; 
$ArmorName[barmor] = BursterArmor; 
$ArmorName[earmor] = EngArmor; 
$ArmorName[darmor] = DragArmor; 
$ArmorName[spyarmor] = SpArmor; 
$ArmorName[aarmor] = AlArmor; 
$ArmorName[dmarmor] = DMArmor; 
$ArmorName[lfemale] = LightArmor; 
$ArmorName[mfemale] = MediumArmor; 
$ArmorName[efemale] = EngArmor; 
$ArmorName[sfemale] = ScoutArmor; 
$ArmorName[bfemale] = BursterArmor; 
$ArmorName[spyfemale] = SpArmor; 
$ArmorName[afemale] = AlArmor; 
$ArmorName[dmfemale] = DMArmor; 

$ArmorName[defarmor] = DefenderArmor; 

$SellAmmo[BulletAmmo] = 25; 
$SellAmmo[PlasmaAmmo] = 5; 
$SellAmmo[DiscAmmo] = 5; 
$SellAmmo[GrenadeAmmo] = 5; 
$SellAmmo[MortarAmmo] = 5; 
$SellAmmo[Beacon] = 5; 
$SellAmmo[Boost] = 5; 
$SellAmmo[Plastique] = 5; 
$SellAmmo[MineAmmo] = 5; 
$SellAmmo[Grenade] = 5; 
$SellAmmo[RocketAmmo] = 3; 
$SellAmmo[SniperAmmo] = 15; 
$SellAmmo[RailAmmo] = 25; 
$SellAmmo[SilencerAmmo] = 25; 
$SellAmmo[VulcanAmmo] = 100; 
$SellAmmo[TranqAmmo] = 2; 

$AmmoPackItems[0] = BulletAmmo; 
$AmmoPackItems[1] = PlasmaAmmo; 
$AmmoPackItems[2] = DiscAmmo; 
$AmmoPackItems[3] = GrenadeAmmo; 
$AmmoPackItems[4] = Grenade; 
$AmmoPackItems[5] = MineAmmo; 
$AmmoPackItems[6] = MortarAmmo; 
$AmmoPackItems[7] = Beacon; 
$AmmoPackItems[8] = RocketAmmo; 
$AmmoPackItems[9] = SniperAmmo; 
$AmmoPackItems[10] = RailAmmo; 
$AmmoPackItems[11] = VulcanAmmo; 
$AmmoPackItems[12] = TranqAmmo; 
$AmmoPackItems[13] = SilencerAmmo; 

$AmmoPackMax[BulletAmmo] = 20000; 
$AmmoPackMax[PlasmaAmmo] = 20000; 
$AmmoPackMax[DiscAmmo] = 20000; 
$AmmoPackMax[GrenadeAmmo] = 20000; 
$AmmoPackMax[MortarAmmo] = 20000; 
$AmmoPackMax[MineAmmo] = 20000; 
$AmmoPackMax[Grenade] = 20000; 
$AmmoPackMax[Beacon] = 20000; 
$AmmoPackMax[Plastique] = 20000;
$AmmoPackMax[RocketAmmo] = 20000; 
$AmmoPackMax[SniperAmmo] = 20000; 
$AmmoPackMax[RailAmmo] = 20000; 
$AmmoPackMax[VulcanAmmo] = 20000; 
$AmmoPackMax[TranqAmmo] = 20000; 
$AmmoPackMax[SilencerAmmo] = 20000; 










$TeamItemMax[newdoorone] = 2000;
$TeamItemMax[newdoortwo] = 2000;
$TeamItemMax[newdoorthree] = 2000;
$TeamItemMax[newdoorfour] = 2000;

$TeamItemMax[doorthreebyfourForceFieldPack] = 2000;
$TeamItemMax[doorfourbyeightForceFieldPack] = 2000;
$TeamItemMax[doorfourbyfourteenForceFieldPack] = 2000;
$TeamItemMax[doorfourbyseventeenForceFieldPack] = 2000;
$TeamItemMax[doorfivebyfiveForceFieldPack] = 2000;

$TeamItemMax[BlastDoorPack] = 2000;
$TeamItemMax[IndoorPack] = 2000;
$TeamItemMax[DeployableElfTurret ] = 2000;
$TeamItemMax[LrgPltPack] = 2000;
$TeamItemMax[FlagStandPack] = 2000;
$TeamItemMax[JailCapPack] = 2000;
$TeamItemMax[jailpack] = 10;
$TeamItemMax[BaseAlarm] = 2000;

$TeamItemMax[ArbitorBoxPack] = 2000;
$TeamItemMax[DeployableAmmoPack] = 2000;
$TeamItemMax[DeployableInvPack] = 2000;
$TeamItemMax[TurretPack] = 2000; 
$TeamItemMax[CameraPack] = 2000; 
$TeamItemMax[DeployableSensorJammerPack] = 2000; 
$TeamItemMax[PulseSensorPack] = 2000; 
$TeamItemMax[MotionSensorPack] = 2000; 
$TeamItemMax[ScoutVehicle] = 2000; 
$TeamItemMax[HAPCVehicle] = 2000; 
$TeamItemMax[LAPCVehicle] = 2000; 
$TeamItemMax[Beacon] = 2000; 
$TeamItemMax[mineammo] = 2000; 
$TeamItemMax[LaserTurret] = 2000; 
$TeamItemMax[RailTurret] = 2000; 
$TeamItemMax[VulcanTurret] = 2000; 
$TeamItemMax[RocketPack] = 2000; 
$TeamItemMax[DeployableComPack] = 2000;
$TeamItemMax[ForceFieldPack] = 2000;
$TeamItemMax[LargeForceFieldPack] = 2000;
$TeamItemMax[LaserPack] = 2000; 
$TeamItemMax[TripwirePack] = 2000;
$TeamItemMax[DeployableTeleport] = 2000; 
$TeamItemMax[PlatformPack] = 5000; 
$TeamItemMax[TreePack] = 75; 
$TeamItemMax[WraithVehicle] = 2000; 
$TeamItemMax[JetVehicle] = 2000; 
$TeamItemMax[SpringPack] = 2000; 
$TeamItemMax[hologram] = 2000; 
$TeamItemMax[SatchelPack] = 2000; 
$TeamItemMax[BigInvPack] = 2; 
$TeamItemMax[ShockPack] = 2000; 
$TeamItemMax[TargetPack] = 2000;
$TeamItemMax[DeployablevhclPack] = 2000;
$TeamItemMax[AntiAirPack] = 2000;


DamageSkinData objectDamageSkins 
{ 
bmpName[0] = "dobj1_object"; 
bmpName[1] = "dobj2_object"; 
bmpName[2] = "dobj3_object"; 
bmpName[3] = "dobj4_object"; 
bmpName[4] = "dobj5_object"; 
bmpName[5] = "dobj6_object"; 
bmpName[6] = "dobj7_object"; 
bmpName[7] = "dobj8_object"; 
bmpName[8] = "dobj9_object"; 
bmpName[9] = "dobj10_object"; 
}; 

$WeaponAmmo[Blaster] = ""; 
$WeaponAmmo[PlasmaGun] = PlasmaAmmo; 
$WeaponAmmo[Chaingun] = BulletAmmo; 
$WeaponAmmo[DiscLauncher] = DiscAmmo; 
$WeaponAmmo[GrenadeLauncher] = GrenadeAmmo; 
$WeaponAmmo[Mortar] = Mortar; 
$WeaponAmmo[LaserRifle] = ""; 
$WeaponAmmo[EnergyRifle] = ""; 
$WeaponAmmo[RocketLauncher] = RocketAmmo; 
$WeaponAmmo[SniperRifle] = SniperAmmo; 
$WeaponAmmo[Railgun] = RailAmmo; 
$WeaponAmmo[WaveGun] = ""; 
$WeaponAmmo[IonGun] = ""; 
$WeaponAmmo[Flamer] = ""; 
$WeaponAmmo[Omega] = ""; 
$WeaponAmmo[Silencer] = SilencerAmmo; 
$WeaponAmmo[Vulcan] = VulcanAmmo; 
$WeaponAmmo[Bolt] = ""; 
$WeaponAmmo[TranqGun] = TranqAmmo; 


$totalNumAlarms[-1] = 0;
$totalNumAlarms[0] = 0;
$totalNumAlarms[1] = 0;
$totalNumAlarms[2] = 0;
$totalNumAlarms[3] = 0;
$totalNumAlarms[4] = 0;
$totalNumAlarms[5] = 0;
$totalNumAlarms[6] = 0;
$totalNumAlarms[7] = 0;






function teamEnergyBuySell(%player,%cost) { 
%client = Player::getClient(%player); 
%team = Client::getTeam(%client); 
%station = %player.Station; 
%stationName = GameBase::getDataName(%station); 
if(%stationName == DeployableInvStation || %stationName == DeployableAmmoStation) 
{ 
%station.Energy += %cost; 
if(%station.Energy < 1) %station.Energy = 0;
}
else 
if($TeamEnergy[%team] != "Infinite") 
{ 
$TeamEnergy[%team] += %cost; 
%client.teamEnergy += %cost; 
} 
} 



function remoteBuyFavorites(%client,%favItem0,%favItem1,%favItem2,%favItem3,%favItem4,%favItem5,%favItem6,%favItem7,%favItem8,%favItem9,%favItem10,%favItem11,%favItem12,%favItem13,%favItem14,%favItem15,%favItem16,%favItem17,%favItem18,%favItem19) 
{ 
%time = getIntegerTime(true) >> 4; 
if(%time <= %client.lastBuyFavTime) 
return; 
%client.lastBuyFavTime = %time; 
%station = (Client::getOwnedObject(%client)).Station; 
if(%station != "" ) 
{ 
%stationName = GameBase::getDataName(%station); 
if(%stationName == DeployableInvStation || %stationName == DeployableAmmoStation) 
%energy = %station.Energy; 
else 
%energy = $TeamEnergy[Client::getTeam(%client)]; 
if(%energy == "Infinite" || %energy > 0) 
{ 
%error = 0; 
%bought = 0; 
%max = getNumItems(); 
for (%i = 0; %i < %max; %i = %i + 1) 
{ 
%item = getItemData(%i); 
if ($ServerCheats || Client::isItemShoppingOn(%client,%item)|| $TestCheats) 
{ 
%count = Player::getItemCount(%client,%item); 
if(%count) 
{ 
if(%item.className != Armor) 
teamEnergyBuySell(Client::getOwnedObject(%client),(%item.price * %count)); 
Player::setItemCount(%client, %item, 0); 
} 
} 
} 
for (%i = 0; %i < 20; %i++) 
{ 
if(%favItem[%i] != "") 
{ 
%item = getItemData(%favItem[%i]); 
if ((Client::isItemShoppingOn(%client,%item)) && ($ItemMax[Player::getArmor(%client), %item] > Player::getItemCount(%client,%item) || %item.className == Armor)) 
{ 
if(!buyItem(%client,%item)) 
%error = 1; 
else %bought++; 
} 
} 
} 
if(%bought) 
{ 
if(%error) Client::sendMessage(%client,0,"~wC_BuySell.wav"); 
else 
Client::SendMessage(%client,0,"~wbuysellsound.wav"); 
} 
updateBuyingList(%client); 
} 
} 
} 



function replenishTeamEnergy(%team) 
{ 
$TeamEnergy[%team] += $incTeamEnergy; 
schedule("replenishTeamEnergy(" @ %team @ ");", $secTeamEnergy); 
} 


//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//================================CHECK RESOURCES=======================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

function checkResources(%player,%item,%delta,%noMessage) 
{ 
%client = Player::getClient(%player); 
%team = Client::getTeam(%client); 
%extraAmmo = 0 ; 
if (Player::getMountedItem(%client,$BackpackSlot) == ammopack && $AmmoPackMax[%item] != "") 
{ 
%extraAmmo = $AmmoPackMax[%item]; 
if(%delta == $ItemMax[Player::getArmor(%client), %item]) 
%delta = %delta + %extraAmmo; 
} 
if($TestCheats == 0 && %client.spawn == "") { %energy = $TeamEnergy[%team]; 
%station = %player.Station; 
%sName = GameBase::getDataName(%station); 
if(%sName == DeployableInvStation || %sName == DeployableAmmoStation)
{ 
%energy = %station.Energy; 
} 
if(%energy != "Infinite") 
{ 
if (%item.price * %delta > %energy) 
%delta = %energy / %item.price; 
if(%delta < 1 ) 
{ 
if(%noMessage == "") 
Client::sendMessage(%client,0,"Couldn't buy " @ %item.description @ " - "@ %energy @ " Energy points left"); 
return 0; 
} 
} 
} 
if(%item.className == Weapon) 
{ 
%armor = Player::getArmor(%client); 
%wcount = Player::getItemClassCount(%client,"Weapon"); 
if (Player::getItemClassCount(%client,"Weapon") >= $MaxWeapons[%armor]) 
{ 
Client::sendMessage(%client,0,"To many weapons for " @ $ArmorName[%armor].description @ " to carry"); 
return 0; 
} 
} 
else 
if(%item == RepairPatch) 
{ 
%pDamage = GameBase::getDamageLevel(%player); 
if(GameBase::getDamageLevel(%player) > 0) 
return 1; 
return 0; 
} 
else 
if($TeamItemMax[%item] != "" && !$TestCheats) 
{ 
if($TeamItemMax[%item] <= $TeamItemCount[%team, %item]) 
{ 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return 0; 
} 
} 
if(%item.className != Armor && %item.className != Vehicle) 
{ 
%count = Player::getItemCount(%client,%item); 
%max = $ItemMax[(Player::getArmor(%client)), %item] + %extraAmmo ; 
if(%delta + %count >= %max) %delta = %max - %count; 
} 
return %delta; 
} 






//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//================================BUY ITEM==============================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

function buyItem(%client,%item) 
{ 
%player = Client::getOwnedObject(%client); 
%armor = Player::getArmor(%client); 
if (($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats || %client.spawn) && ($ItemMax[%armor, %item] || %item.className == Armor || %item.className == Vehicle || $TestCheats)) 
{ 
if (%item.className == Armor) 
{ 
%buyarmor = $ArmorType[Client::getGender(%client), %item]; 
if(%armor != %buyarmor || Player::getItemCount(%client,%item) == 0) 
{ 
teamEnergyBuySell(%player,$ArmorName[%armor].price); 
if(checkResources(%player,%item,1)) 
{ 
teamEnergyBuySell(%player,$ArmorName[%buyarmor].price * -1); 
Player::setArmor(%client,%buyarmor); 
checkMax(%client,%buyarmor); 
armorChange(%client); 
Player::setItemCount(%client, $ArmorName[%armor], 0); 
Player::setItemCount(%client, %item, 1); 
if (Player::getMountedItem(%client,$BackpackSlot) == ammopack) 
fillAmmoPack(%client); 
return 1; 
} 
teamEnergyBuySell(%player,$ArmorName[%armor].price * -1); 
} 
} 
else 
if (%item.className == Backpack) 
{ 
%pack = Player::getMountedItem(%client,$BackpackSlot); 
if (%pack != -1) 
{ 
if(%pack == ammopack) 
checkMax(%client,%armor); 
else 
if(%pack == EnergyPack) 
{ 
if(Player::getItemCount(%client,"LaserRifle") > 0) 
{ 
Client::sendMessage(%client,0,"Sold Energy Pack - Auto Selling Laser Rifle"); 
remoteSellItem(%client,22); 
} 
} 
teamEnergyBuySell(%player,%pack.price); 
Player::decItemCount(%client,%pack); 
} 
if (checkResources(%player,%item,1) || $testCheats) { teamEnergyBuySell(%player,%item.price * -1); 
Player::incItemCount(%client,%item); 
Player::useItem(%client,%item); 
if(%item == ammopack) fillAmmoPack(%client); 
return 1; 
} 
else 
if(%pack != -1) 
{ 
teamEnergyBuySell(%player,%pack.price * -1); 
Player::incItemCount(%client,%pack); 
Player::useItem(%client,%pack); 
if(%pack == ammopack) 
fillAmmoPack(%client); 
} 
} 
else 
if(%item.className == Weapon) 
{ 
if(checkResources(%player,%item,1)) 
{ 
if(%item == LaserRifle && Player::getItemCount(%client,"EnergyPack") == 0) 
{ 
buyItem(%client,"EnergyPack"); 
Client::sendMessage(%client,0,"Bought Laser Rifle - Auto buying Energy Pack"); 
} 
Player::incItemCount(%client,%item); 
teamEnergyBuySell(%player,(%item.price * -1)); 
%ammoItem = %item.imageType.ammoType; 
if(%ammoItem != "") 
{ 
%delta = checkResources(%player,%ammoItem,$ItemMax[%armor, %ammoItem]); 
if(%delta || $testCheats) 
{ 
teamEnergyBuySell(%player,(%ammoItem.price * -1 * %delta)
); 
Player::incItemCount(%client,%ammoitem,%delta); 
} 
} 
return 1; 
} 
} 
else 
if(%item.className == Vehicle) 
{ 
%shouldBuy = VehicleStation::checkBuying(%client,%item); 
if(%shouldBuy == 1) 
{ 
teamEnergyBuySell(%player,(%item.price * -1)); 
return 1; 
} 
else 
if(%shouldBuy == 2) 
return 1; 
} 
else 
{ 
%delta = checkResources(%player,%item,$ItemMax[%armor, %item]); 
if(%delta || $testCheats) 
{ 
teamEnergyBuySell(%player,(%item.price * -1 * %delta)
); 
Player::incItemCount(%client,%item,%delta); 
return 1; 
} 
} 
} 
return 0; 
} 

//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//==================================ARMOR CHANGE========================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

function armorChange(%client) 
{ 
%player = Client::getOwnedObject(%client); 
if(%client.respawn == "" && %player.Station != "") 
{ 
%sPos = GameBase::getPosition(%player.Station); 
%pPos = GameBase::getPosition(%client); 
%posX = getWord(%sPos,0); 
%posY = getWord(%sPos,1); 
%posZ = getWord(%pPos,2); 
%vec = Vector::getFromRot(GameBase::getRotation(%player.Station),-1); 
%newPosX = (getWord(%vec,0) * 1) + %posX; %newPosY = (getWord(%vec,1) * 1) + %posY; GameBase::setPosition(%client, %newPosX @ " " @ %newPosY @ " " @ %posZ); 
} 
} 


//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//===============================REMOTE BUY ITEM========================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]



function remoteBuyItem(%client,%type) 
{ 
%item = getItemData(%type); 
if(buyItem(%client,%item)) 
{ 
Client::sendMessage(%client,0,"~wbuysellsound.wav"); 
updateBuyingList(%client); 
} 
else 
Client::sendMessage(%client,0,"You couldn't buy "@ %item.description @"~wC_BuySell.wav"); 
} 


//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//============================REMOTE SELL ITEM==========================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]


function remoteSellItem(%client,%type) 
{ 
%item = getItemData(%type); 
%player = Client::getOwnedObject(%client); 
if ($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats) 
{ 
if(Player::getItemCount(%client,%item) && %item.className != Armor) 
{ 
%numsell = 1; 
if(%item.className == Ammo || %item.className == HandAmmo) 
{ 
%count = Player::getItemCount(%client, %item); 
if(%count < $SellAmmo[%item]) %numsell = %count; else %numsell = $SellAmmo[%item]; 
} 
else 
if (%item == ammopack) 
checkMax(%client,Player::getArmor(%client)); 
else 
if($TeamItemMax[%item] != "") 
{ 
if(%item.className == Vehicle) 
$TeamItemCount[(Client::getTeam(%client)) @ %item]--; 
} 
else 
if(%item == EnergyPack) 
{ 
if(Player::getItemCount(%client,"LaserRifle") > 0) 
{ 
Client::sendMessage(%client,0,"Sold Energy Pack - Auto Selling Laser Rifle"); 
remoteSellItem(%client,22); 
} 
} 
teamEnergyBuySell(%player,%item.price * %numsell); 
Player::setItemCount(%player,%item,(%count-%numsell)); 
updateBuyingList(%client); 
Client::SendMessage(%client,0,"~wbuysellsound.wav"); 
return 1; 
} 
} 
Client::sendMessage(%client,0,"Cannot sell item ~wC_BuySell.wav"); 
} 


//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//===============================REMOTE USE ITEM========================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]



function remoteUseItem(%client,%type) 
{ 
%client.throwStrength = 1; 
%item = getItemData(%type); 
if (%item == Backpack) 
%item = Player::getMountedItem(%client,$BackpackSlot); 
else 
{ 
if (%item == Weapon) 
%item = Player::getMountedItem(%client,$WeaponSlot); 
} 
Player::useItem(%client,%item); 
} 



//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//=================================REMOTE THROW ITEM====================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]



function remoteThrowItem(%client,%type,%strength) 
{ 
%item = getItemData(%type); 
if (%item == Grenade || %item == MineAmmo) 
{ 
if (%strength < 0) 
%strength = 0; 
else 
if (%strength > 100) 
%strength = 100; 
%client.throwStrength = 0.3 + 0.7 * (%strength / 100); 
Player::useItem(%client,%item); 
} 
} 

//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//=================================REMOTE DROP ITEM=====================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]


function remoteDropItem(%client,%type) 
{ 
if((Client::getOwnedObject(%client)).driver != 1) 
{ 
%client.throwStrength = 1; 
%item = getItemData(%type); 
if (%item == Backpack) 
{ 
%item = Player::getMountedItem(%client,$BackpackSlot); 
Player::dropItem(%client,%item); 
} 
else 
if (%item == Weapon) 
{ 
%item = Player::getMountedItem(%client,$WeaponSlot); 
Player::dropItem(%client,%item); 
} 
else 
if (%item == Ammo) 
{ 
%item = Player::getMountedItem(%client,$WeaponSlot); 
if(%item.className == Weapon) 
{ 
%item = %item.imageType.ammoType; 
Player::dropItem(%client,%item); 
} 
} 
else 
Player::dropItem(%client,%item); 
} 
} 


//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//================================REMOTE DEPLOY ITEM====================================
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]



function remoteDeployItem(%client,%type) 
{ 
%item = getItemData(%type); 
Player::deployItem(%client,%item); 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ NEXT WEAPON ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{



$NextWeapon[JailGun] = Blaster; 
$NextWeapon[Blaster] = PlasmaGun; 
$NextWeapon[PlasmaGun] = Chaingun; 
$NextWeapon[Chaingun] = DiscLauncher; 
$NextWeapon[DiscLauncher] = GrenadeLauncher; 
$NextWeapon[GrenadeLauncher] = Mortar; 
$NextWeapon[Mortar] = LaserRifle; 
$NextWeapon[LaserRifle] = RocketLauncher; 
$NextWeapon[RocketLauncher] = SniperRifle; 
$NextWeapon[SniperRifle] = WaveGun; 
$NextWeapon[WaveGun] = EnergyRifle; 
$NextWeapon[EnergyRifle] = Railgun; 
$NextWeapon[Railgun] = Bolt; 
$NextWeapon[Bolt] = Silencer; 
$NextWeapon[Silencer] = Vulcan; 
$NextWeapon[Vulcan] = IonGun; 
$NextWeapon[IonGun] = Flamer; 
$NextWeapon[Flamer] = TranqGun; 
$NextWeapon[TranqGun] = HyperB; 
$NextWeapon[HyperB] = Omega; 
$NextWeapon[Omega] = Fixit; 
$NextWeapon[Fixit] = Hackit; 
$NextWeapon[Hackit] = JailGun; 


//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ PREVIOUS WEAPON ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{


$PrevWeapon[JailGun] = Hackit; 
$PrevWeapon[Blaster] = JailGun; 
$PrevWeapon[PlasmaGun] = Blaster; 
$PrevWeapon[Chaingun] = PlasmaGun; 
$PrevWeapon[DiscLauncher] = Chaingun; 
$PrevWeapon[GrenadeLauncher] = DiscLauncher; 
$PrevWeapon[Mortar] = GrenadeLauncher; 
$PrevWeapon[LaserRifle] = Mortar; 
$PrevWeapon[RocketLauncher] = LaserRifle; 
$PrevWeapon[SniperRifle] = RocketLauncher; 
$PrevWeapon[WaveGun] = SniperRifle; 
$PrevWeapon[EnergyRifle] = WaveGun; 
$PrevWeapon[Railgun] = EnergyRifle; 
$PrevWeapon[Bolt] = Railgun; 
$PrevWeapon[Silencer] = Bolt; 
$PrevWeapon[Vulcan] = Silencer; 
$PrevWeapon[Flamer] = Vulcan; 
$PrevWeapon[IonGun] = Flamer; 
$PrevWeapon[TranqGun] = IonGun; 
$PrevWeapon[HyperB] = TranqGun; 
$PrevWeapon[Omega] = HyperB; 
$PrevWeapon[Fixit] = Omega; 
$PrevWeapon[Hackit] = Fixit;

















function remoteNextWeapon(%client) { %item = Player::getMountedItem(%client,$WeaponSlot); if (%item == -1 || $NextWeapon[%item] == "") selectValidWeapon(%client); else { for (%weapon = $NextWeapon[%item]; %weapon != %item; %weapon = $NextWeapon[%weapon]) { if (isSelectableWeapon(%client,%weapon)) { Player::useItem(%client,%weapon); if (Player::getMountedItem(%client,$WeaponSlot) == %weapon || Player::getNextMountedItem(%client,$WeaponSlot) == %weapon) break; } } } } 



function remotePrevWeapon(%client) { %item = Player::getMountedItem(%client,$WeaponSlot); if (%item == -1 || $PrevWeapon[%item] == "") selectValidWeapon(%client); else { for (%weapon = $PrevWeapon[%item]; %weapon != %item; %weapon = $PrevWeapon[%weapon]) { if (isSelectableWeapon(%client,%weapon)) { Player::useItem(%client,%weapon); if (Player::getMountedItem(%client,$WeaponSlot) == %weapon || Player::getNextMountedItem(%client,$WeaponSlot) == %weapon) break; } } } } 



function selectValidWeapon(%client) { %item = EnergyRifle; for (%weapon = $NextWeapon[%item]; %weapon != %item; %weapon = $NextWeapon[%weapon]) { if (isSelectableWeapon(%client,%weapon)) { Player::useItem(%client,%weapon); break; } } } 



function isSelectableWeapon(%client,%weapon) { if (Player::getItemCount(%client,%weapon)) { %ammo = $WeaponAmmo[%weapon]; if (%ammo == "" || Player::getItemCount(%client,%ammo) > 0) return true; } return false; } 



function Item::giveItem(%player,%item,%delta) { %armor = Player::getArmor(%player); if($ItemMax[%armor, %item]) { %client = Player::getClient(%player); if (%item.className == Backpack) { if (Player::getMountedItem(%player,$BackpackSlot) == -1) { Player::incItemCount(%player,%item); Player::useItem(%player,%item); Client::sendMessage(%client,0,"You received a " @ %item @ " backpack"); return 1; } } else { if (%item.className == Weapon) { if (Player::getItemClassCount(%player,"Weapon") >= $MaxWeapons[%armor]) return 0; } %extraAmmo = 0 ; if (Player::getMountedItem(%client,$BackpackSlot) == ammopack && $AmmoPackMax[%item] != "") %extraAmmo = $AmmoPackMax[%item]; %count = Player::getItemCount(%player,%item); if (%count + %delta > $ItemMax[%armor, %item] + %extraAmmo) %delta = ($ItemMax[%armor, %item] + %extraAmmo) - %count; if (%delta > 0) { Player::incItemCount(%player,%item,%delta); if (%count == 0 && $AutoUse[%item]) Player::useItem(%player,%item); Client::sendMessage(%client,0,"You received " @ %delta @ " " @ %item.description); return %delta; } } } return 0; } $PickupSound[Ammo] = "SoundPickupAmmo"; $PickupSound[Weapon] = "SoundPickupWeapon"; $PickupSound[Backpack] = "SoundPickupBackpack"; $PickupSound[Repair] = "SoundPickupHealth"; 



function Item::playPickupSound(%this) { %item = Item::getItemData(%this); %sound = $PickupSound[%item.className]; if (%sound != "") playSound(%sound,GameBase::getPosition(%this)); else { playSound(SoundPickupItem,GameBase::getPosition(%this)); } } 


function Item::respawn(%this) { if (Item::isRotating(%this)) { Item::hide(%this,True); schedule("Item::hide(" @ %this @ ",false); GameBase::startFadeIn(" @ %this @ ");",$ItemRespawnTime,%this); } else { deleteObject(%this); } } 



function Item::onAdd(%this) { } 


function Item::onCollision(%this,%object) { if (getObjectType(%object) == "Player") { %item = Item::getItemData(%this); %count = Player::getItemCount(%object,%item); if (Item::giveItem(%object,%item,Item::getCount(%this))) { Item::playPickupSound(%this); Item::respawn(%this); } } } 


function Item::onMount(%player,%item) { } 


function Item::onUnmount(%player,%item) { } 

function Item::onUse(%player,%item) { Player::mountItem(%player,%item,$DefaultSlot); } function Item::pop(%item) { GameBase::startFadeOut(%item); schedule("deleteObject(" @ %item @ ");",2.5, %item); } function Item::onDrop(%player,%item) { if($matchStarted) { if(%item.className != Armor) { %obj = newObject("","Item",%item,1,false); schedule("Item::Pop(" @ %obj @ ");", $ItemPopTime, %obj); addToSet("MissionCleanup", %obj); if (Player::isDead(%player)) GameBase::throw(%obj,%player,10,true); else { GameBase::throw(%obj,%player,15,false); Item::playPickupSound(%obj); } Player::decItemCount(%player,%item,1); return %obj; } } } function Item::onDeploy(%player,%item,%pos) { } function Flag::onUse(%player,%item) { Player::mountItem(%player,%item,$FlagSlot); } 


//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  FLAGS  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{



ItemImageData FlagImage 
{ 
shapeFile = "flag"; 
mountPoint = 2; 
mountOffset = { 0, 0, -0.35 }; 
mountRotation = { 0, 0, 0 }; 
lightType = 2; 
lightRadius = 4; 
lightTime = 1.5; 
lightColor = { 1, 1, 1}; 
}; 

ItemData Flag 
{ 
description = "Flag"; 
shapeFile = "flag"; 
imageType = FlagImage; 
showInventory = false; 
shadowDetailMask = 4; 
lightType = 2; 
lightRadius = 4; 
lightTime = 1.5; 
lightColor = { 1, 1, 1 }; 
}; 

ItemData RaceFlag 
{ 
description = "Race Flag"; 
shapeFile = "flag"; 
imageType = FlagImage; 
showInventory = false; 
shadowDetailMask = 4; 
lightType = 2; 
lightRadius = 4; 
lightTime = 1.5; 
lightColor = { 1, 1, 1 }; 
}; 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  ARMORS  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{



ItemData ScoutArmor 
{ 
heading = "aArmor"; 
description = "Scout"; 
className = "Armor"; 
price = 175; 
}; 
ItemData SpArmor 
{ 
heading = "aArmor"; 
description = "Spy"; 
className = "Armor"; 
price = 175; 
}; 
ItemData LightArmor 
{ 
heading = "aArmor"; 
description = "Sniper"; 
className = "Armor"; 
price = 175; 
}; 
ItemData MediumArmor 
{ 
heading = "aArmor"; 
description = "Duel Armor"; 
className = "Armor"; 
price = 250; 
}; 
ItemData BursterArmor 
{ 
heading = "aArmor"; 
description = "Burster"; 
className = "Armor"; 
price = 250; 
}; 

ItemData EngArmor 
{ 
heading = "aArmor"; 
description = "Engineer"; 
className = "Armor"; 
price = 250; 
}; 
ItemData AlArmor 
{ 
heading = "aArmor"; 
description = "Flag Mover"; 
className = "Armor"; 
price = 250; 
}; 
ItemData DMArmor 
{ 
heading = "aArmor"; 
description = "Commando"; 
className = "Armor"; 
price = 250; 
}; 
ItemData DragArmor 
{ 
heading = "aArmor"; 
description = "Cyborg"; 
className = "Armor"; 
price = 400; }; 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  VEHICLES  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{

ItemData ScoutVehicle 
{ 
description = "Scout"; 
className = "Vehicle"; 
heading = "aVehicle"; 
price = 600;
}; 

ItemData WraithVehicle 
{ 
description = "Wraith"; 
className = "Vehicle"; 
heading = "aVehicle"; 
price = 600; 
}; 

ItemData JetVehicle 
{ 
description = "Interceptor"; 
className = "Vehicle"; 
heading = "aVehicle"; 
price = 600; 
}; 

ItemData LAPCVehicle 
{ 
description = "BomberLPC"; 
className = "Vehicle"; 
heading = "aVehicle"; 
price = 675; 
}; 

ItemData HAPCVehicle 
{ 
description = "StealthHPC"; 
className = "Vehicle"; 
heading = "aVehicle"; 
price = 875; 
}; 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  WEAPONS  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{



ItemData Weapon 
{ 
description = "Weapon"; 
showInventory = false; 
}; 

function Weapon::onUse(%player,%item) 
{ 
%ammo = %item.imageType.ammoType; 
if (%ammo == "") 
{ 
Player::mountItem(%player,%item,$WeaponSlot); 
} 
else 
{ 
if (Player::getItemCount(%player,%ammo) > 0) 
Player::mountItem(%player,%item,$WeaponSlot); 
else 
{ 
Client::sendMessage(Player::getClient(%player),0, strcat(%item.description," has no ammo")); 
} 
} 
} 

ItemData Tool 
{ 
description = "Tool"; 
showInventory = false; 
}; 

function Tool::onUse(%player,%item) 
{ 
Player::mountItem(%player,%item,$ToolSlot); 
} 

ItemData Ammo 
{ 
description = "Ammo"; 
showInventory = false; 
}; 

function Ammo::onDrop(%player,%item) 
{ 
if($matchStarted) 
{ 
%count = Player::getItemCount(%player,%item); 
%delta = $SellAmmo[%item]; 
if(%count <= %delta) 
{ 
if( %item == BulletAmmo || (Player::getMountedItem(%player,$WeaponSlot)).imageType.ammoType != %item) 
%delta = %count; 
else 
%delta = %count - 1; 
} 
if(%delta > 0) 
{ 
%obj = newObject("","Item",%item,%delta,false); 
schedule("Item::Pop(" @ %obj @ ");", $ItemPopTime, %obj); 
addToSet("MissionCleanup", %obj); 
GameBase::throw(%obj,%player,20,false); 
Item::playPickupSound(%obj); 
Player::decItemCount(%player,%item,%delta); 
} 
} 
} 







//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[==WEAPONS AND AMMO==]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]






//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//:::::::::::::::::::::::::::::::::  ENERGY GUN  :::::::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[=  =  BLASTER  =  =]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

ItemImageData BlasterImage 
{ 
shapeFile = "energygun"; 
mountPoint = 0; 
weaponType = 0; 
reloadTime = 0; 
fireTime = 0.3; 
minEnergy = 5; 
maxEnergy = 6; 
projectileType = BlasterBolt; 
accuFire = true; 
sfxFire = SoundFireBlaster; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData Blaster 
{ 
heading = "bWeapons"; 
description = "Blaster"; 
className = "Weapon"; 
shapeFile = "energygun"; 
hudIcon = "blaster"; 
shadowDetailMask = 4; 
imageType = BlasterImage; 
price = 85; 
showWeaponBar = true; 
}; 


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  MAGNUM  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

ItemData SilencerAmmo 
{ 
description = "Magnum Bullets"; 
className = "Ammo"; 
heading = "xAmmunition"; 
shapeFile = "ammo1"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData SilencerImage 
{ 
shapeFile = "energygun"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = SilencerAmmo; 
projectileType = SilencerBullet; 
accuFire = true; 
reloadTime = 0.0; 
fireTime = 0.5; 
lightType = 3; 
lightRadius = 6; 
lightTime = 2; 
lightColor = { 0, 0, 0 }; 
sfxFire = SoundFireMortar; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData Silencer 
{ 
description = "Magnum"; 
className = "Weapon"; 
shapeFile = "energygun"; 
hudIcon = "targetlaser"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = SilencerImage; 
price = 375; 
showWeaponBar = true; 
}; 













//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//:::::::::::::::::::::::::::::::::::  PLASMA GUN  :::::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,



//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  HYPER BLASTER  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



ItemImageData HyperBImage 
{ 
shapeFile = "plasma"; 
mountPoint = 0; 
weaponType = 0; 
reloadTime = 0; 
fireTime = 0.1; 
minEnergy = 5; 
maxEnergy = 6; 
projectileType = HyperBolt; 
accuFire = true; 
sfxFire = SoundFireLaser; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData HyperB 
{ 
heading = "bWeapons"; 
description = "Hyper Blaster"; 
className = "Weapon"; 
shapeFile = "plasma"; 
hudIcon = "blaster"; 
shadowDetailMask = 4; 
imageType = HyperBImage; 
price = 285; 
showWeaponBar = true; 
}; 





//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  PLASMA GUN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemData PlasmaAmmo 
{ 
description = "Plasma Bolt"; 
heading = "xAmmunition"; 
className = "Ammo"; 
shapeFile = "plasammo"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData PlasmaGunImage 
{ 
shapeFile = "plasma"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = PlasmaAmmo; 
projectileType = PlasmaBolt; 
accuFire = true; 
reloadTime = 0.1; 
fireTime = 0.5; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 1, 1, 0.2 }; 
sfxFire = SoundFirePlasma; 
sfxActivate = SoundPickUpWeapon; 
sfxReload = SoundDryFire; 
}; 

ItemData PlasmaGun 
{ 
description = "Plasma Gun"; 
className = "Weapon"; 
shapeFile = "plasma"; 
hudIcon = "plasma"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = PlasmaGunImage; 
price = 175; 
showWeaponBar = true; 
}; 









//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//:::::::::::::::::::::::::::::::::::  CHAINGUN  :::::::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,

//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  CHAINGUN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

ItemData BulletAmmo 
{ 
description = "Bullet"; 
className = "Ammo"; 
shapeFile = "ammo1"; 
heading = "xAmmunition"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData ChaingunImage 
{ 
shapeFile = "chaingun"; 
mountPoint = 0; 
weaponType = 1; 
reloadTime = 0; 
spinUpTime = 0.5; 
spinDownTime = 3; 
fireTime = 0.09; 
ammoType = BulletAmmo; 
projectileType = ChaingunBullet; 
accuFire = false; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 1,0,0}; 
sfxFire = SoundFireChaingun; 
sfxActivate = SoundPickUpWeapon; 
sfxSpinUp = SoundSpinUp; 
sfxSpinDown = SoundSpinDown; 
}; 

ItemData Chaingun 
{ 
description = "Chaingun"; 
className = "Weapon"; 
shapeFile = "chaingun"; 
hudIcon = "chain"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = ChaingunImage; 
price = 125; 
showWeaponBar = true; 
}; 


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  VULCAN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemData VulcanAmmo 
{ 
description = "Vulcan Bullet"; 
className = "Ammo"; 
shapeFile = "ammo1"; 
heading = "xAmmunition"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData VulcanImage 
{ 
shapeFile = "chaingun"; 
mountPoint = 0; 
weaponType = 1; 
reloadTime = 0; 
spinUpTime = 0.75; 
spinDownTime = 3; 
fireTime = 0.045; 
ammoType = VulcanAmmo; 
projectileType = VulcanBullet; 
accuFire = true; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 0.6, 1, 1 }; 
sfxFire = SoundFireChaingun; 
sfxActivate = SoundPickUpWeapon; 
sfxSpinUp = SoundSpinUp; 
sfxSpinDown = SoundSpinDown; 
}; 

ItemData Vulcan 
{ 
description = "Vulcan"; 
className = "Weapon"; 
shapeFile = "chaingun"; 
hudIcon = "chain"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = VulcanImage; 
price = 125; 
showWeaponBar = true; 
}; 












//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//::::::::::::::::::::::::::::::::  DISC  LAUNCHER  ::::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,





//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  DISC LAUNCHER  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



ItemData DiscAmmo 
{ 
description = "Disc"; 
className = "Ammo"; 
shapeFile = "discammo"; 
heading = "xAmmunition"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData DiscLauncherImage 
{ 
shapeFile = "disc"; 
mountPoint = 0; 
weaponType = 3; 
ammoType = DiscAmmo; 
projectileType = DiscShell; 
accuFire = true; 
reloadTime = 0.25; 
fireTime = 1.25; 
spinUpTime = 0.25; 
sfxFire = SoundFireDisc; 
sfxActivate = SoundPickUpWeapon; 
sfxReload = SoundDiscReload; 
sfxReady = SoundDiscSpin; 
}; 

ItemData DiscLauncher 
{ 
description = "Disc Launcher"; 
className = "Weapon"; 
shapeFile = "disc"; 
hudIcon = "disk"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = DiscLauncherImage; 
price = 150; 
showWeaponBar = true; 
}; 









//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//::::::::::::::::::::::::::::::::::  LITTLE LAUNCHER  :::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,



//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  GRENADE LAUNCHER  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemData GrenadeAmmo 
{ 
description = "Grenade Ammo"; 
className = "Ammo"; 
shapeFile = "grenammo"; 
heading = "xAmmunition"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData GrenadeLauncherImage 
{ 
shapeFile = "grenadeL"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = GrenadeAmmo; 
projectileType = GrenadeShell; 
accuFire = false; 
reloadTime = 0.5; 
fireTime = 0.5; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 0.6, 1, 1.0 }; 
sfxFire = SoundFireGrenade; 
sfxActivate = SoundPickUpWeapon; 
sfxReload = SoundDryFire; 
}; 

ItemData GrenadeLauncher 
{ 
description = "Grenade Launcher"; 
className = "Weapon"; 
shapeFile = "grenadeL"; 
hudIcon = "grenade"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = GrenadeLauncherImage; 
price = 150; 
showWeaponBar = true; 
}; 


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  FLAME THROWER  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData FlamerImage 
{ 
shapeFile = "GrenadeL"; 
mountPoint = 0; 
weaponType = 0; 
reloadTime = 0.05; 
fireTime = 0; 
minEnergy = 5; 
maxEnergy = 6; 
projectileType = FlamerBolt; 
accuFire = true; 
sfxFire = SoundJetHeavy; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData Flamer 
{ 
heading = "bWeapons"; 
description = "Flame Thrower"; 
className = "Weapon"; 
shapeFile = "GrenadeL"; 
hudIcon = "plasma"; 
shadowDetailMask = 4; 
imageType = FlamerImage; 
price = 385; 
showWeaponBar = true; 
}; 





//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  ION GUN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData IonGunImage 
{ 
shapeFile = "GrenadeL"; 
mountPoint = 0; 
weaponType = 0; 
reloadTime = 0; 
fireTime = 0.3; 
minEnergy = 19; 
maxEnergy = 20; 
projectileType = IonBolt; 
accuFire = true; 
sfxFire = SoundFireLaser; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData IonGun 
{ 
heading = "bWeapons"; 
description = "Ion Rifle"; 
className = "Weapon"; 
shapeFile = "GrenadeL"; 
hudIcon = "targetlaser"; 
shadowDetailMask = 4; 
imageType = IonGunImage; 
price = 250; 
showWeaponBar = true; 
}; 








//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//::::::::::::::::::::::::::::::::  LARGE  LAUNCHER  :::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,



//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  MORTAR  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]




ItemData MortarAmmo 
{ 
description = "Mortar Ammo"; 
className = "Ammo"; 
heading = "xAmmunition"; 
shapeFile = "mortarammo"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData MortarImage 
{ 
shapeFile = "mortargun"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = MortarAmmo; 
projectileType = MortarShell; 
accuFire = false; 
reloadTime = 0.5; 
fireTime = 2.0; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 0.6, 1, 1.0 }; 
sfxFire = SoundFireMortar; 
sfxActivate = SoundPickUpWeapon; 
sfxReload = SoundMortarReload; 
sfxReady = SoundMortarIdle; 
}; 

ItemData Mortar 
{ 
description = "Mortar"; 
className = "Weapon"; 
shapeFile = "mortargun"; 
hudIcon = "mortar"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = MortarImage; 
price = 375; 
showWeaponBar = true; 
}; 




//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  ROCKET LAUNCHER  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



ItemData RocketAmmo 
{ 
description = "Rockets"; 
className = "Ammo"; 
heading = "xAmmunition"; 
shapeFile = "rocket"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData RocketImage 
{ 
shapeFile = "mortargun"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = RocketAmmo; 
projectileType = StingerMissile; 
accuFire = true; 
reloadTime = 0.5; 
fireTime = 2.0; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 0.6, 1, 1.0 }; 
sfxFire = SoundMissileTurretFire; 
sfxActivate = SoundPickUpWeapon; 
sfxReload = SoundMortarReload; 
sfxReady = SoundMortarIdle; 
}; 

ItemData RocketLauncher 
{ 
description = "Rocket Launcher"; 
className = "Weapon"; 
shapeFile = "mortargun"; 
hudIcon = "mortar"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = RocketImage; 
price = 375; 
showWeaponBar = true; 
}; 





//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//:::::::::::::::::::::::::::::::::::  RIFLE  ::::::::::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  SNIPER RIFLE  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



ItemData SniperAmmo 
{ 
description = "Sniper Bullet"; 
className = "Ammo"; 
heading = "xAmmunition"; 
shapeFile = "ammo1"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData SniperRifleImage 
{ 
shapeFile = "sniper"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = SniperAmmo; 
projectileType = SniperRound; 
accuFire = true; 
reloadTime = 1.5; 
fireTime = 0; 
lightType = 3; 
lightRadius = 6; 
lightTime = 2; 
lightColor = { 1.0, 0, 0 }; 
sfxFire = SoundFireChainGun; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData SniperRifle 
{ 
description = "Sniper Rifle"; 
className = "Weapon"; 
shapeFile = "sniper"; 
hudIcon = "targetlaser"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = SniperRifleImage; 
price = 375; 
showWeaponBar = true; 
}; 



//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  DART RIFLE  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]





ItemData TranqAmmo 
{ 
description = "Poison Dart"; 
className = "Ammo"; 
heading = "xAmmunition"; 
shapeFile = "ammo1"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData TranqGunImage 
{ 
shapeFile = "sniper"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = TranqAmmo; 
projectileType = TranqDart; 
accuFire = true; 
reloadTime = 1.5; 
fireTime = 0; 
lightType = 3; 
lightRadius = 6; 
lightTime = 2; 
lightColor = { 1.0, 0, 0 }; 
sfxFire = SoundFireChainGun; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData TranqGun 
{ 
description = "Dart Rifle"; 
className = "Weapon"; 
shapeFile = "sniper"; 
hudIcon = "blaster"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = TranqGunImage; 
price = 475; 
showWeaponBar = true; 
}; 


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  LASER RIFLE  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



ItemImageData LaserRifleImage 
{ 
shapeFile = "sniper"; 
mountPoint = 0; 
weaponType = 0; 
projectileType = SniperLaser; 
accuFire = true; 
reloadTime = 0.1; 
fireTime = 0.5; 
minEnergy = 10; 
maxEnergy = 60; 
lightType = 3; 
lightRadius = 2; 
lightTime = 1; 
lightColor = { 0, 0, 0 }; 
sfxFire = SoundFireLaser; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData LaserRifle 
{ 
description = "Laser Rifle"; 
className = "Weapon"; 
shapeFile = "sniper"; 
hudIcon = "sniper"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = LaserRifleImage; 
price = 200; 
showWeaponBar = true; 
}; 

function LaserRifle::onUse(%player,%item) 
{ 
if(Player::getMountedItem(%player,$BackpackSlot) == EnergyPack) 
Weapon::onUse(%player,%item); 
else 
Client::sendMessage(Player::getClient(%player),0, "Must have an Energy Pack to use Laser Rifle."); 
} 


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  RAIL GUN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemData RailAmmo 
{ 
description = "Railgun Bolt"; 
className = "Ammo"; 
heading = "xAmmunition"; 
shapeFile = "ammo1"; 
shadowDetailMask = 4; 
price = 0; 
}; 

ItemImageData RailgunImage 
{ 
shapeFile = "sniper"; 
mountPoint = 0; 
weaponType = 0; 
ammoType = RailAmmo; 
projectileType = RailRound; 
accuFire = true; 
reloadTime = 0.2; 
fireTime = 2.0; 
lightType = 3; 
lightRadius = 6; 
lightTime = 2; 
lightColor = { 1.0, 0, 0 }; 
sfxFire = SoundMissileTurretFire; 
sfxActivate = SoundPickUpWeapon; 
sfxSpinUp = SoundSpinUp; 
sfxSpinDown = SoundSpinDown; 
}; 

ItemData Railgun 
{ 
description = "Railgun"; 
className = "Weapon"; 
shapeFile = "sniper"; 
hudIcon = "targetlaser"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = RailgunImage; 
price = 375; 
showWeaponBar = true; 
}; 

//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//::::::::::::::::::::::::::::::::::::  SHOTGUN  :::::::::::::::::::::::::::::::::::::::::
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,..,.,.,.,


//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  SHOCKWAVE CANNON  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData WaveGunImage 
{ 
shapeFile = "shotgun"; 
mountPoint = 0; 
weaponType = 0; 
minEnergy = 40; 
maxEnergy = 45; 
projectileType = Shock; 
accuFire = true; 
fireTime = 0.9; 
sfxFire = SoundPlasmaTurretFire; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData WaveGun 
{ 
description = "Shockwave Cannon"; 
className = "Weapon"; 
shapeFile = "shotgun"; 
hudIcon = "disk"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = WaveGunImage; 
price = 250; 
showWeaponBar = true; 
}; 







//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  OMEGA CANNON  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData OmegaImage 
{ 
shapeFile = "shotgun"; 
mountPoint = 0; 
weaponType = 0; 
reloadTime = 0.05; 
fireTime = 0; 
minEnergy = 5; 
maxEnergy = 6; 
projectileType = OmegaBolt; 
accuFire = false; 
sfxFire = SoundJetHeavy; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData Omega 
{ 
heading = "bWeapons"; 
description = "Omega Cannon"; 
className = "Weapon"; 
shapeFile = "shotgun"; 
hudIcon = "plasma"; 
shadowDetailMask = 4; 
imageType = OmegaImage; 
price = 385; 
showWeaponBar = true; 
}; 





//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  THUNDER BOLT  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData BoltImage 
{ 
shapeFile = "shotgun"; 
mountPoint = 0; 
weaponType = 2; 
projectileType = boltCharge; 
minEnergy = 15; 
maxEnergy = 20; 
reloadTime = 0.2; 
lightType = 3; 
lightRadius = 2; 
lightTime = 1; 
lightColor = { 0.25, 0.25, 0.85 }; 
sfxActivate = SoundPickUpWeapon; 
sfxFire = SoundELFIdle; 
}; 

ItemData Bolt 
{ 
description = "Thunderbolt"; 
shapeFile = "shotgun"; 
hudIcon = "energyRifle"; 
className = "Weapon"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = BoltImage; 
showWeaponBar = true; 
price = 750; 
};





//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  THUNDER BOLT 2 ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData EnergyRifleImage 
{ 
shapeFile = "shotgun"; 
mountPoint = 0; 
weaponType = 2; 
projectileType = boltCharge; 
minEnergy = 3; 
maxEnergy = 15; 
reloadTime = 0.2; 
lightType = 3; 
lightRadius = 2; 
lightTime = 1; 
lightColor = { 0.25, 0.25, 0.85 }; 
sfxActivate = SoundPickUpWeapon; 
sfxFire = SoundELFIdle; 
}; 

ItemData EnergyRifle 
{ 
description = "Thunderbolt"; 
shapeFile = "shotgun"; 
hudIcon = "energyRifle"; 
className = "Weapon"; 
heading = "bWeapons"; 
shadowDetailMask = 4; 
imageType = EnergyRifleImage; 
showWeaponBar = true; 
price = 500; 
}; 




//[[[[[[[[[[[[[[[[[[[[[[[[[[[[  TARGETING LASER  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData TargetingLaserImage 
{ 
shapeFile = "paintgun"; 
mountPoint = 0; 
weaponType = 2; 
projectileType = targetLaser; 
accuFire = true; 
minEnergy = 5; 
maxEnergy = 15; 
reloadTime = 1.0; 
lightType = 3; 
lightRadius = 1; 
lightTime = 1; 
lightColor = { 0.25, 1, 0.25 }; 
sfxFire = SoundFireTargetingLaser; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData TargetingLaser 
{ 
description = "Targeting Laser"; 
className = "Tool"; 
shapeFile = "paintgun"; 
hudIcon = "targetlaser"; 
heading = "tTools"; 
shadowDetailMask = 4; 
imageType = TargetingLaserImage; 
price = 50; 
showWeaponBar = false; 
}; 




//[[[[[[[[[[[[[[[[[[[[[[[[[[[[  ENGINEER REPAIR GUN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


ItemImageData FixitImage 
{ 
shapeFile = "repairgun"; 
mountPoint = 0; 
weaponType = 2; 
projectileType = RepairBolt; 
reloadTime = 0;  
minEnergy = 5; 
maxEnergy = 15; 
lightType = 3; 
lightRadius = 1; 
lightTime = 1; 
lightColor = { 0.25, 1, 0.25 }; 
sfxFire = SoundRepairItem; 
sfxActivate = SoundPickUpWeapon; 
}; 

ItemData Fixit 
{ 
description = "Engineer Repair-Gun"; 
className = "Tool"; 
shapeFile = "repairgun"; 
hudIcon = "targetlaser"; 
heading = "tTools"; 
shadowDetailMask = 4; 
imageType = FixitImage; 
price = 50; 
showWeaponBar = false; 
}; 




//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[  REPAIR GUN  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



ItemImageData RepairGunImage 
{ 
shapeFile = "repairgun"; 
mountPoint = 0; 
weaponType = 2; 
projectileType = RepairBolt; 
reloadTime = 0;  
minEnergy = 3; 
maxEnergy = 10; 
lightType = 3; 
lightRadius = 1; 
lightTime = 1; 
lightColor = { 0.25, 1, 0.25 }; 
sfxActivate = SoundPickUpWeapon; 
sfxFire = SoundRepairItem; 
}; 

ItemData RepairGun 
{ 
description = "Repair Gun"; 
shapeFile = "repairgun"; 
className = "Weapon"; 
shadowDetailMask = 4; 
imageType = RepairGunImage; 
showInventory = false; 
price = 125; 
}; 

function RepairGun::onMount(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,true); 
} 

function RepairGun::onUnmount(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,false); 
} 





//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]            ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[= = BACK   PACKS = =]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[            [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]




ItemData Backpack 
{ 
description = "Backpack"; 
showInventory = false; 
}; 

function Backpack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::trigger(%player,$BackpackSlot); 
} 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  ENERGY  PACK  ::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData EnergyPackImage 
{ 
shapeFile = "jetPack"; 
weaponType = 2; 
mountPoint = 2; 
mountOffset = { 0, -0.1, 0 }; 
minEnergy = -3; 
maxEnergy = -5; 
firstPerson = false; 
}; 

ItemData EnergyPack 
{ 
description = "Energy Pack"; 
shapeFile = "jetPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = EnergyPackImage; 
price = 150; 
hudIcon = "energypack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function EnergyPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
} 

function EnergyPack::onMount(%player,%item) 
{ 
Player::trigger(%player,$BackpackSlot,true); 
} 

function EnergyPack::onUnmount(%player,%item) 
{ 
if (Player::getMountedItem(%player,$WeaponSlot) == LaserRifle) 
Player::unmountItem(%player,$WeaponSlot); 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::::[   REPAIR  PACK   ]:::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

//======================================
ItemImageData RepairPackImage 
{ 
shapeFile = "armorPack"; 
mountPoint = 2; 
weaponType = 2; 
minEnergy = 0; 
maxEnergy = 0; 
reloadTime = 4; 
mountOffset = { 0, -0.05, 0 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData RepairPack 
{ 
description = "Repair Pack"; 
shapeFile = "armorPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = RepairPackImage; 
price = 125; 
hudIcon = "repairpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function RepairPack::onUnmount(%player,%item) 
{ 
if (Player::getMountedItem(%player,$WeaponSlot) == RepairGun) 
{ 
Player::unmountItem(%player,$WeaponSlot); 
} 
} 

function RepairPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::mountItem(%player,RepairGun,$WeaponSlot); 
} 
} 

function RepairPack::onDrop(%player,%item) 
{ 
if($matchStarted) 
{ 
%mounted = Player::getMountedItem(%player,$WeaponSlot); 
if (%mounted == RepairGun) 
{ 
Player::unmountItem(%player,$WeaponSlot); 
} 
else 
{ 
Player::mountItem(%player,%mounted,$WeaponSlot); 
} 
Item::onDrop(%player,%item); 
} 
} 
//==============================================================



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::  SHIELD  PACK  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData ShieldPackImage 
{ 
shapeFile = "shieldPack"; 
mountPoint = 2; 
weaponType = 2; 
minEnergy = 4; 
maxEnergy = 9; 
sfxFire = SoundShieldOn; 
firstPerson = false; 
}; 

ItemData ShieldPack 
{ 
description = "Shield Pack"; 
shapeFile = "shieldPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = ShieldPackImage; 
price = 175; 
hudIcon = "shieldpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function ShieldPackImage::onActivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"Shield On"); 
%player.shieldStrength = 0.012; 
} 

function ShieldPackImage::onDeactivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"Shield Off"); 
Player::trigger(%player,$BackpackSlot,false); 
%player.shieldStrength = 0; 
} 

ItemImageData SensorJammerPackImage 
{ 
shapeFile = "sensorjampack"; 
mountPoint = 2; 
weaponType = 2; 
maxEnergy = 10; 
sfxFire = SoundJammerOn; 
mountOffset = { 0, -0.05, 0 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData SensorJammerPack 
{ 
description = "Sensor Jammer Pack"; 
shapeFile = "sensorjampack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = SensorJammerPackImage; 
price = 200; 
hudIcon = "sensorjamerpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function SensorJammerPackImage::onActivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"Sensor Jammer On"); 
%rate = Player::getSensorSupression(%player) + 20; 
Player::setSensorSupression(%player,%rate); 
} 

function SensorJammerPackImage::onDeactivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"Sensor Jammer Off"); 
%rate = Player::getSensorSupression(%player) - 20; 
Player::setSensorSupression(%player,%rate); 
Player::trigger(%player,$BackpackSlot,false); 
} 

//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::::[ CLOAKING  DEVICE ]:::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData CloakingDeviceImage 
{ 
shapeFile = "sensorjampack"; 
mountPoint = 2; 
weaponType = 2; 
maxEnergy = 10; 
sfxFire = SoundJammerOn; 
mountOffset = { 0, -0.05, 0 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData CloakingDevice 
{ 
description = "Cloaking Device"; 
shapeFile = "sensorjampack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = CloakingDeviceimage; 
price = 600; 
hudIcon = "sensorjamerpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function CloakingDeviceImage::onActivate(%player,%imageSlot) 
{ 
GameBase::startFadeout(%player); 
Client::sendMessage(Player::getClient(%player),0,"Cloaking Device On"); 
%rate = Player::getSensorSupression(%player) + 5; 
Player::setSensorSupression(%player,%rate); 
%player.guiLock = true; 
%c = Player::getClient(%player); 
%c.guiLock = true; 
%clientId.ghostDoneFlag = true; 
startGhosting(%cl); 
} 

function CloakingDeviceImage::onDeactivate(%player,%imageSlot) 
{ 
GameBase::startFadein(%player); 
Client::sendMessage(Player::getClient(%player),0,"Cloaking Device Off"); 
%rate = Player::getSensorSupression(%player) - 5; 
Player::setSensorSupression(%player,%rate); 
Player::trigger(%player,$BackpackSlot,false); 
%player.guiLock = ""; 
%c = Player::getClient(%player); 
%c.guiLock = ""; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  STEALTH SHIELD PACK  ::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData StealthShieldPackImage 
{ 
shapeFile = "shieldPack"; 
mountPoint = 2; 
weaponType = 2; 
minEnergy = 6; 
maxEnergy = 9; 
sfxFire = SoundShieldOn; 
firstPerson = false; 
}; 

ItemData StealthShieldPack 
{ 
description = "StealthShield Pack"; 
shapeFile = "shieldPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = StealthShieldPackImage; 
price = 275; 
hudIcon = "shieldpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function StealthShieldPackImage::onActivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"StealthShield On"); 
%player.shieldStrength = 0.012; 
%rate = Player::getSensorSupression(%player) + 20; 
Player::setSensorSupression(%player,%rate); 
} 

function StealthShieldPackImage::onDeactivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"StealthShield Off"); 
Player::trigger(%player,$BackpackSlot,false); 
%player.shieldStrength = 0; 
%rate = Player::getSensorSupression(%player) - 20; 
Player::setSensorSupression(%player,%rate); 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  REGENERATION PACK  :::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData RegenerationPackImage 
{ 
shapeFile = "shieldPack"; 
mountPoint = 2; 
weaponType = 2; 
minEnergy = 8; 
maxEnergy = 14; 
sfxFire = SoundRepairItem; 
projectileType = AutoBolt; 
}; 

ItemData RegenerationPack 
{ 
description = "Regeneration Pack"; 
shapeFile = "shieldPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = RegenerationPackImage; 
price = 275; 
hudIcon = "shieldpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function RegenerationPackImage::onActivate(%player,%imageSlot) 
{ 
%clientId = Player::getClient(%player); 
} 

function RegenerationPackImage::onDeactivate(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,false); 
} 

function TransferHealth(%clientId, %player) 
{ 
Client::sendMessage(%clientId,1,"Regeneration On"); 
Player::unmountItem(%player,$WeaponSlot); 
if($regTime[%clientId] == 0) 
{ 
GameBase::setEnergy(%player,0); 
GameBase::setRechargeRate(%player,0); 
$regTime[%clientId] = 10; 
checkPlayerDrain(%clientId, %player); 
} 
else 
$regTime[%clientId] = 10; 
} 

function checkPlayerDrain(%clientId, %player) 
{ 
if($regTime[%clientId] > 0) 
{ 
$regTime[%clientId] -= 2; 
if(GameBase::getDamageLevel(%player)) 
{ 
GameBase::repairDamage(%player,0.04); 
GameBase::playSound(%player,ForceFieldOpen,0); 
} 
schedule("checkPlayerDrain(" @ %clientId @ ", " @ %player @ ");",2,%player); 
} 
else 
{ 
Client::sendMessage(%clientId,1,"Regeneration Off"); 
GameBase::setRechargeRate(%player,8); 
} 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  LIGHTNING PACK IMAGE  ::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData LightningPackImage 
{ 
shapeFile = "shieldPack"; 
mountPoint = 2; 
weaponType = 2; 
projectileType = boltCharge; 
minEnergy = 9; 
maxEnergy = 10; 
reloadTime = 0.2; 
sfxFire = SoundELFIdle; 
}; 

ItemData LightningPack 
{ 
description = "Lightning Pack"; 
shapeFile = "shieldPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = LightningPackImage; 
price = 275; 
hudIcon = "shieldpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function LightningPackImage::onActivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"Lightning Field On"); 
} 

function LightningPackImage::onDeactivate(%player,%imageSlot) 
{ 
Client::sendMessage(Player::getClient(%player),0,"Lightning Field Off"); 
Player::trigger(%player,$BackpackSlot,false); 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  CYBERNETIC  LASER  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData OpticPackImage 
{ 
shapeFile = "repairgun"; 
mountPoint = 2; 
mountOffset = { 0.2, 0.4, 0.45 }; 
mountRotation = { 0, 0, 0 }; 
weaponType = 0; 
projectileType = SniperLaser; 
accuFire = true; 
reloadTime = 6.5; 
fireTime = 0.0; 
minEnergy = 10; 
maxEnergy = 60; 
lightType = 3; 
lightRadius = 2; 
lightTime = 1; 
lightColor = { 1, 0, 0 }; 
sfxFire = SoundFireLaser; 
}; 

ItemData OpticPack 
{ 
description = "Cybernetic Laser"; 
shapeFile = "repairgun"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = OpticPackImage; 
price = 275; 
hudIcon = "sniper"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function OpticPackImage::onActivate(%player,%imageSlot) 
{ 
schedule("use(\"backpack\");", 0.5); 
} 

function OpticPackImage::onDeactivate(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,false); 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  AUTO ROCKET  CANNON  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData SMRPackImage 
{ 
shapeFile = "mortargun"; 
mountPoint = 2; 
mountOffset = { -0.4, 0.1, 0.4 }; 
mountRotation = { 0.2, 0, 0 }; 
weaponType = 0; 
ammoType = RocketAmmo; 
projectileType = StingerMissile; 
accuFire = true; 
reloadTime = 5.0; 
fireTime = 0.0; 
lightType = 3; 
lightRadius = 3; 
lightTime = 1; 
lightColor = { 0.6, 1, 1.0 }; 
sfxFire = SoundMissileTurretFire; 
sfxReload = SoundMortarReload; 
}; 

ItemData SMRPack 
{ 
description = "Auto-Rocket Cannon"; 
shapeFile = "mortargun"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = SMRPackImage; 
price = 350; 
hudIcon = "mortar"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function SMRPackImage::onActivate(%player,%imageSlot) 
{ 
schedule("use(\"backpack\");", 0.5); 
} 

function SMRPackImage::onDeactivate(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,false); 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::  AUTO CANNON  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData NewPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
weaponType = 0; 
projectileType = Nuke; 
minEnergy = 100; 
maxEnergy = 140; 
reloadTime = 5.0; 
sfxFire = SoundMissileTurretFire; 
sfxReload = SoundMortarReload; 
}; 

ItemData NewPack 
{ 
description = "Auto-Cannon"; 
shapeFile = "mortargun"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = NewPackImage; 
price = 350; 
hudIcon = "shieldpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function NewPackImage::onActivate(%player,%imageSlot) 
{ } 
function NewPackImage::onDeactivate(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,false); 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::AUTO CANNON::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData NewerPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
weaponType = 0; 
projectileType = Nuke; 
minEnergy = 100; 
maxEnergy = 140; 
reloadTime = 5.0; 
sfxFire = SoundMissileTurretFire; 
sfxReload = SoundMortarReload; 
}; 

ItemData NewerPack 
{ 
description = "Auto-Cannon"; 
shapeFile = "mortargun"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = NewerPackImage; 
price = 350; 
hudIcon = "shieldpack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function NewerPackImage::onActivate(%player,%imageSlot) 
{ } 

function NewerPackImage::onDeactivate(%player,%imageSlot) 
{ 
Player::trigger(%player,$BackpackSlot,false); 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  COMMAND  LAPTOP  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData LaptopImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
weaponType = 2; 
minEnergy = -1; 
maxEnergy = -3; 
mass = 0.5; 
firstPerson = false; 
}; 

ItemData Laptop 
{ 
description = "Command Laptop"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "cBackpacks"; 
shadowDetailMask = 4; 
imageType = LaptopImage; 
price = 650; 
hudIcon = "energypack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function Laptop::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
} 

function Laptop::onMount(%player,%item) 
{ 
Player::trigger(%player,$BackpackSlot,true); 
} 
function Laptop::onUnmount(%player,%item) 
{ } 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  SUICIDE DET PACK  :::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData SuicidePackImage 
{ 
shapeFile = "magcargo"; 
mountPoint = 2; 
mountOffset = { 0, -0.5, -0.3 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData SuicidePack 
{ 
description = "Suicide DetPack"; 
shapeFile = "magcargo"; 
className = "Backpack"; 
heading = "cBackpacks"; 
imageType = SuicidePackImage; 
shadowDetailMask = 4; 
mass = 2.5; 
elasticity = 0.2; 
price = 450; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function SuicidePack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function SuicidePack::onUnmount(%player,%item) 
{ } 

function SuicidePack::onDeploy(%player,%item,%pos) 
{ 
if (SuicidePack::deployShape(%player,%item)) 
{ 
Player::decItemCount(%player,%item); 
} 
} 

function SuicidePack::deployShape(%player,%item) 
{ 
Player::unmountItem(%player,$BackpackSlot); 
%obj = newObject("","Mine","Suicidebomb2"); 
addToSet("MissionCleanup", %obj); 
%client = Player::getClient(%player); 
GameBase::throw(%obj,%player,10 * %client.throwStrength,true); 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  AMMO  PACK  ::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData AmmoPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
firstPerson = false; 
}; 

ItemData AmmoPack 
{ 
description = "Ammo Pack"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "cBackpacks"; 
imageType = AmmoPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 325; 
hudIcon = "ammopack"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function AmmoPack::onDrop(%player, %item) 
{ 
if($matchStarted) 
{ 
%item = Item::onDrop(%player,%item); 
for(%i = 0; %i < 13 ; %i = %i +1) 
{ 
%numPack = 0; 
%ammoItem = $AmmoPackItems[%i]; 
%maxnum = $ItemMax[Player::getArmor(%player), %ammoItem]; 
%pCount = Player::getItemCount(%player, %ammoItem); 
if(%pCount > %maxnum) 
{ 
%numPack = %pCount - %maxnum; 
Player::decItemCount(%player,%ammoItem,%numPack); 
} 
if(%i == 0) 
{ 
%item.BulletAmmo = %numPack; 
} 
else 
if(%i == 1) 
{ 
%item.PlasmaAmmo = %numPack; 
} 
else 
if(%i == 2) 
{ 
%item.DiscAmmo = %numPack; 
} 
else 
if(%i == 3) 
{ 
%item.GrenadeAmmo = %numPack; 
} 
else 
if(%i == 4) 
{ 
%item.Grenade = %numPack; 
} 
else 
if(%i == 5) 
{ 
%item.MortarAmmo = %numPack; 
} 
else 
if(%i == 6) 
{ 
%item.RocketAmmo = %numPack; 
} 
else 
if(%i == 7) 
{ 
%item.SniperAmmo = %numPack; 
} 
else 
if(%i == 8) 
{ 
%item.RailAmmo = %numPack; 
} 
else 
if(%i == 9) 
{ 
%item.SilencerAmmo = %numPack; 
} 
else 
if(%i == 10) 
{ 
%item.VulcanAmmo = %numPack; 
} 
else 
if(%i == 11) 
{ 
%item.Beacon = %numPack; 
} 
else 
if(%i == 12) 
{ 
%item.TranqAmmo = %numPack; 
} 
else 
{ 
%item.MineAmmo = %numPack; 
} 
} 
} 
} 

function AmmoPack::onCollision(%this,%object) 
{ 
if (getObjectType(%object) == "Player") 
{ 
%item = Item::getItemData(%this); 
%count = Player::getItemCount(%object,%item); 
if (Item::giveItem(%object,%item,Item::getCount(%this))) 
{ 
Item::playPickupSound(%this); 
checkPacksAmmo(%object, %this); 
Item::respawn(%this); 
} 
} 
} 

function checkPacksAmmo(%player, %item) 
{ 
for(%i = 0; %i < 13 ; %i = %i +1) 
{ 
%ammoItem = $AmmoPackItems[%i]; 
if(%i == 0) 
{ 
%numAdd = %item.BulletAmmo; 
} 
else 
if(%i == 1) 
{ 
%numAdd = %item.PlasmaAmmo; 
} 
else 
if(%i == 2) 
{ 
%numAdd = %item.DiscAmmo; 
} 
else 
if(%i == 3) 
{ 
%numAdd = %item.GrenadeAmmo; 
} 
else 
if(%i == 4) 
{ 
%numAdd = %item.Grenade; 
} 
else 
if(%i == 5) 
{ 
%numAdd = %item.MortarAmmo; 
} 
else 
if(%i == 6) 
{ 
%numAdd = %item.RocketAmmo; 
} 
else 
if(%i == 7) 
{ 
%numAdd = %item.SniperAmmo; 
} 
else 
if(%i == 8) 
{ 
%numAdd = %item.RailAmmo; 
} 
else 
if(%i == 9) 
{ 
%numAdd = %item.SilencerAmmo; 
} 
else 
if(%i == 10) 
{ 
%numAdd = %item.VulcanAmmo; 
} 
else 
if(%i == 11) 
{ 
%numAdd = %item.Beacon; 
} 
else 
if(%i == 12) 
{ 
%numAdd = %item.TranqAmmo; 
} 
else 
{ 
%numAdd = %item.MineAmmo; 
} 
Player::incItemCount(%player,%ammoItem,%numAdd); 
} 
} 

function fillAmmoPack(%client) 
{ 
%player = Client::getOwnedObject(%client); 
for(%i = 0; %i < 13 ; %i = %i +1) 
{ 
%item = $AmmoPackItems[%i]; 
%maxnum = $AmmoPackMax[%item]; 
%maxnum = checkResources(%player,%item,%maxnum); 
if(%maxnum) 
{ 
Player::incItemCount(%client,%item,%maxnum); 
teamEnergyBuySell(%player,%item.price * %maxnum * -1); 
} 
} 
} 




//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]                         ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[ == DEPLOYABLE STATIONS == ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[                         [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  DEPLOYABLE  INVENTORY  PACK  :::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData DeployableInvPackImage 
{ 
shapeFile = "invent_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.3 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData DeployableInvPack 
{ 
description = "Inventory Station"; 
shapeFile = "invent_remote"; 
className = "Backpack"; 
heading = "eDeployable Stations"; 
shadowDetailMask = 4 ; 
imageType = DeployableInvPackImage; 
mass = 2.0; 
elasticity = 0.2; 
price = 5000; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function DeployableInvPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function DeployableInvPack::onDeploy(%player,%item,%pos) { if (DeployableInvPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function DeployableInvPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7)  
{ 
%inv = newObject("ammounit_remote","StaticShape","DeployableInvStation",true); 
addToSet("MissionCleanup", %inv); 
%rot = GameBase::getRotation(%player); 
GameBase::setTeam(%inv,GameBase::getTeam(%player)); 
GameBase::setPosition(%inv,$los::position); 
GameBase::setRotation(%inv,%rot); 
Gamebase::setMapName(%inv,%name); 
Client::sendMessage(%client,0,"Inventory Station deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%inv) @ "DeployableInvPack"]++; 
echo("MSG: ",%client," deployed an Inventory Station"); 
return true;  
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{                       {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  DEPLOYABLE AMMO STATION  :::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}                       }}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData DeployableAmmoPackImage 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, -0.3 }; 
mountRotation = { 0, 0, 0 }; 
mass = 1.0; 
firstPerson = false; 
}; 

ItemData DeployableAmmoPack 
{ 
description = "Ammo Station"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "eDeployable Stations"; 
shadowDetailMask = 4; 
imageType = DeployableAmmoPackImage; 
mass = 2.0; 
elasticity = 0.2; 
price = $RemoteAmmoEnergy; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function DeployableAmmoPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function DeployableAmmoPack::onDeploy(%player,%item,%pos) 
{ 
if (DeployableAmmoPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function DeployableAmmoPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%inv = newObject("ammounit_remote","StaticShape","DeployableAmmoStation",true); 
addToSet("MissionCleanup", %inv); 
%rot = GameBase::getRotation(%player); 
GameBase::setTeam(%inv,GameBase::getTeam(%player)); 
GameBase::setPosition(%inv,$los::position); 
GameBase::setRotation(%inv,%rot); 
Gamebase::setMapName(%inv,%name); 
Client::sendMessage(%client,0,"Ammo Station deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%inv) @ "DeployableAmmoPack"]++; 
echo("MSG: ",%client," deployed an Ammo Station"); 
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  DEPLOYABLE COMMAND STATION  ::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData DeployableComPackImage 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.3 }; 
mountRotation = { 0, 0, 0 }; 
mass = 4.5; 
firstPerson = false; 
}; 

ItemData DeployableComPack 
{ 
description = "Command Station"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "eDeployable Stations"; 
shadowDetailMask = 4 ; 
imageType = DeployableComPackImage; 
mass = 4.0; 
elasticity = 0.2; 
price = 2000; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function DeployableComPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function DeployableComPack::onDeploy(%player,%item,%pos) 
{ 
if (DeployableComPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function DeployableComPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%inv = newObject("comunit_remote","StaticShape","DeployableComStation",true); 
addToSet("MissionCleanup", %inv); 
%rot = GameBase::getRotation(%player); 
GameBase::setTeam(%inv,GameBase::getTeam(%player)); 
GameBase::setPosition(%inv,$los::position); 
GameBase::setRotation(%inv,%rot); 
Gamebase::setMapName(%inv,%name); 
Client::sendMessage(%client,0,"Command Station deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%inv) @ "DeployableComPack"]++;
echo("MSG: ",%client," deployed a Command Station");  
return true;  
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
}







//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::  DEPLOYABLE VEHICLE PACK STATION  ::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}




ItemImageData DeployablevhclPackImage 
{ 
shapeFile = "invent_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.3 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData DeployablevhclPack 
{ 
description = "Vehicle Station"; 
shapeFile = "invent_remote"; 
className = "Backpack"; 
heading = "eDeployable Stations"; 
shadowDetailMask = 4 ; 
imageType = DeployableInvPackImage; 
mass = 2.0; 
elasticity = 0.2; 
price = 5000; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function DeployablevhclPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function DeployablevhclPack::onDeploy(%player,%item,%pos) 
{ 
if (DeployablevhclPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 
function DeployablevhclPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7)  
{ 
%inv = newObject("ammounit_remote","StaticShape","DeployablevhclStation",true); 
addToSet("MissionCleanup", %inv); 
%rot = GameBase::getRotation(%player); 
GameBase::setTeam(%inv,GameBase::getTeam(%player)); 
GameBase::setPosition(%inv,$los::position); 
GameBase::setRotation(%inv,%rot); 
Gamebase::setMapName(%inv,%name); 
Client::sendMessage(%client,0,"Vehicle Station deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%inv) @ "DeployablevhclPack"]++; 
echo("MSG: ",%client," deployed a Vehicle Station"); 
return true;  
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 
 




//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//:::::::::::::::::::::::::::::::::::[ DEPLOYABLE SENSORS]::::::::::::::::::::::::::::::::
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]






ItemImageData MotionSensorPackImage 
{ 
shapeFile = "sensor_small"; 
mountPoint = 2; 
mountOffset = { 0, 0, 0.1 }; 
mountRotation = { 1.57, 0, 0 }; 
firstPerson = false; 
}; 

ItemData MotionSensorPack 
{ 
description = "Motion Sensor"; 
shapeFile = "sensor_small"; 
className = "Backpack"; 
heading = "fDeployable Sensors"; 
imageType = MotionSensorPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 125; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function MotionSensorPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} else 
{ 
Player::deployItem(%player,%item); } 
} 

function MotionSensorPack::onDeploy(%player,%item,%pos) 
{ 
if (MotionSensorPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
$TeamItemCount[GameBase::getTeam(%player) @ "MotionSensorPack"]++;echo("MSG: ",%client," deployed a Motion Sensor");  } 
} 

function MotionSensorPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) { %rot = "0 0 " @ %zRot; 
} else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} else 
{ 
%rot = Vector::getRotation($los::normal); } 
} 
if(checkDeployArea(%client,$los::position)) 
{ 
%mSensor = newObject
("","Sensor",DeployableMotionSensor,true); 
addToSet("MissionCleanup", %mSensor); 
GameBase::setTeam(%mSensor,GameBase::getTeam(%player)); GameBase::setRotation(%mSensor,%rot); 
GameBase::setPosition(%mSensor,$los::position); 
Gamebase::setMapName(%mSensor,"Motion Sensor"); 
Client::sendMessage(%client,0,"Motion Sensor deployed"); 
playSound(SoundPickupBackpack,$los::position); 
echo("MSG: ",%client," deployed a Motion Sensor"); 
return true; } 
} else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); } 
} else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); } 
} else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 






ItemImageData PulseSensorPackImage 
{ 
shapeFile = "radar_small"; 
mountPoint = 2; 
mountOffset = { 0, 0, 0.1 }; 
mountRotation = { 1.57, 0, 0 }; 
firstPerson = false; 
}; 

ItemData PulseSensorPack 
{ 
description = "Pulse Sensor"; 
shapeFile = "radar_small"; 
className = "Backpack"; 
heading = "fDeployable Sensors"; 
imageType = PulseSensorPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 125; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function PulseSensorPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} else 
{ 
Player::deployItem(%player,%item); } 
} 

function PulseSensorPack::onDeploy(%player,%item,%pos) 
{ 
if (Item::deployShape(%player,"Pulse Sensor",DeployablePulseSensor,%item)) 
{ 
//Player::decItemCount(%player,%item); 
$TeamItemCount[GameBase::getTeam(%player) @ "PulseSensorPack"]++;echo("MSG: ",%client," deployed a Pulse Sensor");  } 
} 






ItemImageData DeployableSensorJamPackImage
{
	shapeFile = "sensor_jammer";
 	mountPoint = 2;
  	mountOffset = { 0, 0.03, 0.1 };
  	mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData DeployableSensorJammerPack
{
	description = "Sensor Jammer";
  	shapeFile = "sensor_jammer";
  	className = "Backpack";
   heading = "fDeployable Sensors";
	imageType = DeployableSensorJamPackImage;
  	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
  	price = 225;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function DeployableSensorJammerPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function DeployableSensorJammerPack::onDeploy(%player,%item,%pos)
{
	if (Item::deployShape(%player,"Sensor Jammer",DeployableSensorJammer,%item)) {
		//Player::decItemCount(%player,%item);
		$TeamItemCount[GameBase::getTeam(%player) @ "DeployableSensorJammerPack"]++;echo("MSG: ",%client," deployed a Sensor Jammer"); 
	}
}

ItemImageData BaseAlarmImage
{
	shapeFile = "sensor_small";
	mountPoint = 2;
	mountOffset = { 0, 0, 0.1 };
	mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData BaseAlarm
{
   description = "Base Alarm";
   shapeFile = "sensor_small";
   className = "Backpack";
   heading = "fDeployable Sensors";
   shadowDetailMask = 4;
   imageType = BaseAlarmImage;
   mass = 2.0;
   elasticity = 0.2;
   price = 50;
   hudIcon = "deployable";
   showWeaponBar = true;
   hiliteOnActive = true;
};

function BaseAlarm::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function BaseAlarm::onDeploy(%player,%item,%pos)
{
	if (BaseAlarm::deployShape(%player,%item)) {
		//Player::decItemCount(%player,%item);
	}
}

function BaseAlarm::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);

	if (GameBase::getLOSInfo(%player,10000)) {
		%obj = getObjectType($los::object);
		if (%obj == "InteriorShape") {
			// Try to stick it straight up or down, otherwise
			// just use the surface normal
			if (Vector::dot($los::normal,"0 0 1") > 0.6) {
				%rot = "0 0 0";
			}
			else {
				if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
					%rot = "3.14159 0 0";
				}
				else {
					%rot = Vector::getRotation($los::normal);
				}
			}
			if(checkDeployArea(%client,$los::position)) {
				%alarm = newObject("","StaticShape", "AlarmKit",true);
 	 			addToSet("MissionCleanup", %alarm);
				GameBase::setTeam(%alarm,GameBase::getTeam(%player));
				GameBase::setRotation(%alarm,%rot);
				GameBase::setPosition(%alarm,$los::position);
				Gamebase::setMapName(%alarm,%name);
				Gamebase::setMapName(%alarm,"Base Alarm #" @ $totalNumAlarms[GameBase::getTeam(%player)]++);
				Client::sendMessage(%client,0,"Alarm #" @ $totalNumAlarms[GameBase::getTeam(%player)] @ " deployed");
				$TeamItemCount[GameBase::getTeam(%SGen) @ "BaseAlarm"]++;echo("MSG: ",%client," deployed a Base Alarm"); 
				return true;
			}
		}
		else {
			Client::sendMessage(%client,0,"Can only deploy on buildings");
		}
	}
	else {
		Client::sendMessage(%client,0,"Deploy position out of range");
	}

	return false;
}




ItemImageData CameraPackImage 
{ 
shapeFile = "camera"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, -0.06 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData CameraPack 
{ 
description = "Camera"; 
shapeFile = "camera"; 
className = "Backpack"; 
heading = "fDeployable Sensors"; 
imageType = CameraPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 100; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function CameraPack::onUse(%player,%item) { if (Player::getMountedItem(%player,$BackpackSlot) != %item) { Player::mountItem(%player,%item,$BackpackSlot); } else { Player::deployItem(%player,%item); } 
} 

function CameraPack::onDeploy(%player,%item,%pos) { if (CameraPack::deployShape(%player,%item)) { 
//Player::decItemCount(%player,%item); 
} 
} 

function CameraPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 

{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} 
else 
{ 
%rot = Vector::getRotation($los::normal); 
} 
} 
%camera = newObject("Camera","Turret",CameraTurret,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"Camera#"@ $totalNumCameras++ @ " " @ Client::getName(%client)); 
Client::sendMessage(%client,0,"Camera deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "CameraPack"]++; 
echo("MSG: ",%client," deployed a Camera"); 
return true; 
 
} else { Client::sendMessage(%client,0,"Deploy position out of range"); } } else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; } 








//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//:::::::::::::::::::::::::::::::::::[ DEPLOYABLE TURRETS]::::::::::::::::::::::::::::::::
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]




function checkDeployArea(%client,%pos) 
{ 
return 1;
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::  DEPLOYABLE  ION  TURRET  ::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}





ItemImageData TurretPackImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.1 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData TurretPack 
{ 
description = "Ion Turret"; 
shapeFile = "remoteturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = TurretPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 350; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function TurretPack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
Player::mountItem(%player,%item,$BackpackSlot);
}
else 
{
Player::deployItem(%player,%item);
}
}

function TurretPack::onDeploy(%player,%item,%pos)
{
if (TurretPack::deployShape(%player,%item)) 
{
//Player::decItemCount(%player,%item);
}
}





function TurretPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{
%obj = getObjectType($los::object);
%prot = GameBase::getRotation(%player);
%zRot = getWord(%prot,2);
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{
%rot = "0 0 " @ %zRot;
}
else 
{
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{
%rot = "3.14159 0 " @ %zRot;
}
else 
{
%rot = Vector::getRotation($los::normal);
}
}
%turret = newObject("remoteTurret","Turret",DeployableTurret,true); 
addToSet("MissionCleanup", %turret);
GameBase::setTeam(%turret,GameBase::getTeam(%player));
GameBase::setRotation(%turret,%rot);
GameBase::setPosition(%turret,$los::position);
Gamebase::setMapName(%turret,"RMT Ion Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client)); 
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"Ion Turret deployed");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%turret) @ "TurretPack"]++;
echo("MSG: ",%client," deployed an Ion Turret"); 
return true;
}
else 
Client::sendMessage(%client,0,"Deploy position out of range");
}
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  DEPLOYABLE  LASER  TURRET  :::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData LaserPackImage
{
shapeFile = "camera";
mountPoint = 2;
mountOffset = { 0, -0.1, -0.06 };
mountRotation = { 0, 0, 0 };
firstPerson = false;
};

ItemData LaserPack
{
description = "Laser Turret";
shapeFile = "camera";
className = "Backpack";
heading = "gDeployable Turrets";
imageType = CameraPackImage;
shadowDetailMask = 4;
mass = 2.0;
elasticity = 0.2;
price = 100;
hudIcon = "deployable";
showWeaponBar = true;
hiliteOnActive = true;
};

function LaserPack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else 
{
Player::deployItem(%player,%item);
}
}

function LaserPack::onDeploy(%player,%item,%pos)
{
if (LaserPack::deployShape(%player,%item)) 
{
//Player::decItemCount(%player,%item);
}
}

function LaserPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{
%obj = getObjectType($los::object);
%prot = GameBase::getRotation(%player);
%zRot = getWord(%prot,2);
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{
%rot = "0 0 " @ %zRot;
}
else 
{
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{
%rot = "3.14159 0 " @ %zRot;
}
else 
{
%rot = Vector::getRotation($los::normal);
}
}
%camera = newObject("Camera","Turret",DeployableLaser,true);
addToSet("MissionCleanup", %camera);
GameBase::setTeam(%camera,GameBase::getTeam(%player));
GameBase::setRotation(%camera,%rot);
GameBase::setPosition(%camera,$los::position);
Gamebase::setMapName(%camera,"Laser Turret#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::setOwnedObject(%client, %camera);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"Laser Turret deployed");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%camera) @ "LaserPack"]++;
echo("MSG: ",%client," deployed a Laser Turret"); 
return true;
}
else 
Client::sendMessage(%client,0,"Deploy position out of range");
}
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  SHOCK  TURRET  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData ShockPackImage 
{ 
shapeFile = "indoorgun"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, -0.06 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData ShockPack 
{ 
description = "Shock Turret"; 
shapeFile = "indoorgun"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = ShockPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function ShockPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function ShockPack::onDeploy(%player,%item,%pos) 
{ 
if (ShockPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function ShockPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain"; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} 
else 
{ 
%rot = Vector::getRotation($los::normal); 
} 
} 
if(%obj == "SimTerrain" ) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableShock",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%camera = newObject("Camera","Turret",DeployableShock,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"Shock Turret#"@ $totalNumCameras++ @ " " @ Client::getName(%client)); 
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);

Client::sendMessage(%client,0,"Shock Turret deployed"); playSound(SoundPickupBackpack,$los::position); $TeamItemCount[GameBase::getTeam(%camera) @ "ShockPack"]++; 
return true; 
} 
else Client::sendMessage(%client,0,"Interference from other Shock turrets in the area"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  MORTAR  TURRET  ::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData TargetPackImage 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, -0.06 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData TargetPack 
{ 
description = "Mortar Turret"; 
shapeFile = "mortar_turret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = TargetPackImage; 
shadowDetailMask = 4; 
mass = 3.0; 
elasticity = 0.2; 
price = 800; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function TargetPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ Player::deployItem(%player,%item); 
} 
} 

function TargetPack::onMount(%player,%item) 
{ 
%client = Player::getClient(%player); 
Bottomprint(%client, "The Mortar Turret has no auto-sensor and must be controlled manually to fire."); 
} 

function TargetPack::onDeploy(%player,%item,%pos) 
{ 
if (TargetPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function TargetPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableMortar",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableTurret",%num); 
deleteObject(%set); 
if(0 == %num) 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%turret = newObject("remoteTurret","Turret",DeployableMortar,true); addToSet("MissionCleanup", %turret); 
GameBase::setTeam(%turret,GameBase::getTeam(%player)); 
GameBase::setPosition(%turret,$los::position); 
GameBase::setRotation(%turret,%rot); 
Gamebase::setMapName(%turret,"Mortar Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client)); 
Client::sendMessage(%client,0,"Remote Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "TargetPack"]++; 
echo("MSG: ",%client," deployed a Mortar Turret"); 
Client::setOwnedObject(%client, %turret); 
Client::setOwnedObject(%client, %player); 
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets"); 
} 
else Client::sendMessage(%client,0,"Interference from other remote turrets in the area"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 







//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::  DEPLOYABLE  PLASMA  TURRET  :::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData LaserTurretImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.1 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData LaserTurret 
{ 
description = "Plasma Turret"; 
shapeFile = "remoteturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = LaserTurretImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 650; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function LaserTurret::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function LaserTurret::onDeploy(%player,%item,%pos) 
{ 
if (LaserTurret::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function CountObjects(%set,%name,%num) 
{ 
%count = 0; 
for(%i=0;%i<%num;%i++) 
{ 
%obj=Group::getObject(%set,%i); 
if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) %count++; 
} 
return %count; 
} 

function LaserTurret::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployablePlasma",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0); 
%num = CountObjects(%set,"DeployablePlasma",%num); 
deleteObject(%set); 
if(0 == %num) 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%turret = newObject("hellfiregun","Turret",DeployablePlasma,true); 
addToSet("MissionCleanup", %turret); 
GameBase::setTeam(%turret,GameBase::getTeam(%player)); 
GameBase::setPosition(%turret,$los::position); 
GameBase::setRotation(%turret,%rot); 
Gamebase::setMapName(%turret,"Plasma Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client)); 
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"Plasma Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "LaserTurret"]++;
echo("MSG: ",%client," deployed a Plasma Turret");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets"); 
} 
else 
Client::sendMessage(%client,0,"Interference from other remote turrets in the area"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  DEPLOYABLE  ELF  TURRET  :::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData DeployableElfTurretImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.1 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 


ItemData DeployableElfTurret 
{ 
description = "Elf Turret"; 
shapeFile = "remoteturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = DeployableElfTurretImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 650; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function DeployableElfTurret::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function DeployableElfTurret::onDeploy(%player,%item,%pos) 
{ 
if (DeployableElfTurret::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function CountObjects(%set,%name,%num) 
{ 
%count = 0; 
for(%i=0;%i<%num;%i++) 
{ 
%obj=Group::getObject(%set,%i); 
if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) %count++; 
} 
return %count; 
} 

function DeployableElfTurret::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableElf",%num); 
deleteObject(%set); 
if (%obj == "SimTerrain" ) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableElf",%num); 
deleteObject(%set); 
if(0 == %num) 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%turret = newObject("hellfiregun","Turret",DeployableElf,true); addToSet("MissionCleanup", %turret); 
GameBase::setTeam(%turret,GameBase::getTeam(%player)); 
GameBase::setPosition(%turret,$los::position); 
GameBase::setRotation(%turret,%rot); 
Gamebase::setMapName(%turret,"Elf Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client)); 
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"Elf Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "DeployableElfTurret"]++;
echo("MSG: ",%client," deployed a Elf Turret");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets"); 
} 
else 
Client::sendMessage(%client,0,"Interference from other remote turrets in the area"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::  DEPLOYABLE  INDOOR  TURRET  ::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData IndoorPackImage 
{ 
shapeFile = "indoorgun"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, -0.06 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData IndoorPack 
{ 
description = "Indoor Turret"; 
shapeFile = "indoorgun"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = IndoorPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function IndoorPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function IndoorPack::onDeploy(%player,%item,%pos) 
{ 
if (IndoorPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function IndoorPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain"; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} 
else 
{ 
%rot = Vector::getRotation($los::normal); 
} 
} 
if(%obj == "SimTerrain" ) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableIndoor",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%camera = newObject("Camera","Turret",DeployableIndoor,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"Indoor Turret#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"Indoor Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "IndoorPack"]++; 
return true; 
} 
else Client::sendMessage(%client,0,"Interference from other Indoor turrets in the area"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  DEPLOYABLE  VULCAN  TURRET  ::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData VulcanTurretImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.1 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData VulcanTurret 
{ 
description = "Vulcan Turret"; 
shapeFile = "remoteturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = VulcanTurretImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 750; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function VulcanTurret::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function VulcanTurret::onDeploy(%player,%item,%pos) 
{ 
if (VulcanTurret::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function VulcanTurret::onMount(%player,%item) 
{ 
%client = Player::getClient(%player); 
Bottomprint(%client, "The Vulcan Turret has no auto-sensor and must be controlled manually to fire."); 
} 

function CountObjects(%set,%name,%num) 
{ 
%count = 0; 
for(%i=0;%i<%num;%i++) 
{ 
%obj=Group::getObject(%set,%i); 
if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) %count++; 
} 
return %count; 
} 

function VulcanTurret::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableVulcan",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0); 
%num = CountObjects(%set,"DeployablePlasma",%num); 
deleteObject(%set); 
if(0 == %num) 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%turret = newObject("hellfiregun","Turret",DeployableVulcan,true); 
addToSet("MissionCleanup", %turret); 
GameBase::setTeam(%turret,GameBase::getTeam(%player)); 
GameBase::setPosition(%turret,$los::position); 
GameBase::setRotation(%turret,%rot); 
Gamebase::setMapName(%turret,"Vulcan Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client)); 
Client::sendMessage(%client,0,"Vulcan Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "VulcanTurret"]++;
echo("MSG: ",%client," deployed a Vulcan Turret");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets"); 
} 
else 
Client::sendMessage(%client,0,"Interference from other remote turrets in the area"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::  DEPLOYABLE  RAIL  TURRET  :::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData RailTurretImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.1 }; 
mountRotation = { 0, 0, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData RailTurret 
{ 
description = "Rail Turret"; 
shapeFile = "remoteturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = VulcanTurretImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 850; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function RailTurret::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function RailTurret::onDeploy(%player,%item,%pos) 
{ 
if (RailTurret::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function RailTurret::onMount(%player,%item) 
{ 
%client = Player::getClient(%player); 
Bottomprint(%client, "The Rail Turret has no auto-sensor and must be controlled manually to fire."); 
} 

function CountObjects(%set,%name,%num) 
{ 
%count = 0; 
for(%i=0;%i<%num;%i++) 
{ 
%obj=Group::getObject(%set,%i); 
if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) %count++; 
} 
return %count; 
} 
function RailTurret::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableVulcan",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0); 
%num = CountObjects(%set,"DeployablePlasma",%num); 
deleteObject(%set); 
if(0 == %num) 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%turret = newObject("hellfiregun","Turret",DeployableRail,true); 
addToSet("MissionCleanup", %turret); 
GameBase::setTeam(%turret,GameBase::getTeam(%player)); 
GameBase::setPosition(%turret,$los::position); 
GameBase::setRotation(%turret,%rot); 
Gamebase::setMapName(%turret,"Rail Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client)); 
Client::sendMessage(%client,0,"Rail Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "RailTurret"]++;
echo("MSG: ",%client," deployed a Rail Turret");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets"); 
} 
else 
Client::sendMessage(%client,0,"Interference from other remote turrets in the area"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  DEPLOYABLE  ROCKET  TURRET  ::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData RocketPackImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.12, -0.1 }; 
mountRotation = { 0, 0, 0 }; 
mass = 3.0; 
firstPerson = false; 
}; 

ItemData RocketPack 
{ 
description = "Missile Turret"; 
shapeFile = "missileturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = RocketPackImage; 
shadowDetailMask = 4; 
mass = 3.0; 
elasticity = 0.2; 
price = 950; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function RocketPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function RocketPack::onDeploy(%player,%item,%pos) 
{ 
if (RocketPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function RocketPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"DeployableSentry",%num) + CountObjects(%set,"DeployableTurret",%num) + CountObjects(%set,"DeployableRocket",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableSentry",%num) + CountObjects(%set,"DeployableTurret",%num) + CountObjects(%set,"DeployableRocket",%num); 
deleteObject(%set); 
if(0 == %num) 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%turret = newObject("missileturret","Turret",DeployableRocket,true); 
addToSet("MissionCleanup", %turret); 
GameBase::setTeam(%turret,GameBase::getTeam(%player)); 
GameBase::setPosition(%turret,$los::position); 
GameBase::setRotation(%turret,%rot); Gamebase::setMapName(%turret,"Missile#" @ $totalNumTurrets++ @ " " @ 
Client::getName(%client));
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"Missile Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "RocketPack"]++;
echo("MSG: ",%client," deployed a Rocket Turret");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets"); 
} 
else 
Client::sendMessage(%client,0,"Interference from other remote turrets in the area"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 







//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  ANTI  AIR  TURRET  ::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData AntiAirPackImage 
{ 
shapeFile = "remoteturret"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, -0.06 }; 
mountRotation = { 0, 0, 0 }; 
firstPerson = false; 
}; 

ItemData AntiAirPack 
{ 
description = "AntiAir Turret"; 
shapeFile = "remoteturret"; 
className = "Backpack"; 
heading = "gDeployable Turrets"; 
imageType = AntiAirPackImage; 
shadowDetailMask = 4; 
mass = 2.0; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function AntiAirPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function AntiAirPack::onDeploy(%player,%item,%pos) 
{ 
if (AntiAirPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function AntiAirPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain"; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} 
else 
{ 
%rot = Vector::getRotation($los::normal); 
} 
} 
if(%obj == "SimTerrain") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0); 
%num = CountObjects(%set,"AntiAirTurret",%num); 
deleteObject(%set); 
if($MaxNumTurretsInBox > %num) 
{ 
%camera = newObject("Camera","Turret",AntiAirTurret,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"AntiAir Turret#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::setOwnedObject(%client, %turret);
Client::setOwnedObject(%client, %player);
Client::sendMessage(%client,0,"AntiAir Turret deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "AntiAirPack"]++;
echo("MSG: ",%client," deployed an AntiAir Turret");  
return true; 
} 
else Client::sendMessage(%client,0,"Interference from other AntiAir turrets in the area"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 









//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]                     ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//:::::::::::::::::::::::::::::::::::[ DEPLOYABLE OBJECTS  ]::::::::::::::::::::::::::::::
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[                     [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  FORCE  FIELD  :::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData ForceFieldPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData ForceFieldPack 
{ 
description = "Force Field"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = ForceFieldPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function ForceFieldPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function ForceFieldPack::onDeploy(%player,%item,%pos) 
{ 
if (ForceFieldPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function ForceFieldPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableForceField",%num); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%phase = newObject("","StaticShape",DeployableForceField,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Force Field"); 
Client::sendMessage(%client,0,"Force Field Deployed"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
playSound(ForceFieldOpen,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "ForceFieldPack"]++;
echo("MSG: ",%client," deployed a Force Field");  
return true; 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::  LARGE  FORCE  FIELD  ::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData LargeForceFieldPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData LargeForceFieldPack 
{ 
description = "Large Force Field"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = LargeForceFieldPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 1200; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function LargeForceFieldPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function LargeForceFieldPack::onDeploy(%player,%item,%pos) 
{ 
if (LargeForceFieldPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function LargeForceFieldPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableForceField",%num); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%phase = newObject("","StaticShape",LargeForceField,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Force Field"); 
Client::sendMessage(%client,0,"Force Field Deployed"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
playSound(ForceFieldOpen,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "LargeForceFieldPack"]++;
echo("MSG: ",%client," deployed a Large Force Field");  
return true; 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::  BLAST  WALL  PACK  ::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData TripwirePackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData TripwirePack 
{ 
description = "Blast Wall"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = TripwirePackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function TripwirePack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ Player::deployItem(%player,%item); 
} 
} 

function TripwirePack::onDeploy(%player,%item,%pos) 
{ 
if (TripwirePack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 
function TripwirePack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{
%obj = getObjectType($los::object);
%prot = GameBase::getRotation(%player);
%zRot = getWord(%prot,2);
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"BlastWall",%num); 
deleteObject(%set); 

if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{
%rot = "0 0 " @ %zRot;
}
else 
{
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{
%rot = "3.14159 0 " @ %zRot;
}
else 
{
%rot = Vector::getRotation($los::normal);
}
}
%phase = newObject("","StaticShape",BlastWall,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Blast Wall"); 
Client::sendMessage(%client,0,"Blast Wall Deployed"); GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
playSound(ForceFieldOpen,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "TripwirePack"]++; 
return true; 
}
else 
Client::sendMessage(%client,0,"Deploy position out of range");
}
else											  
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  BLAST  DOOR  PACK  ::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData BlastDoorPackImage
{
shapeFile = "AmmoPack";
mountPoint = 2;
mountOffset = { 0, -0.12, 3.0 };
mountRotation = { 90, 0, 0 };
mass = 2.5;
firstPerson = false;
};

ItemData BlastDoorPack
{
description = "Blast Door";
shapeFile = "AmmoPack";
className = "Backpack";
heading = "pDoors";
imageType = BlastDoorPackImage;
shadowDetailMask = 4;
mass = 2.5;
elasticity = 0.2;
price = 500;
hudIcon = "deployable";
showWeaponBar = true;
hiliteOnActive = true;
};

function BlastDoorPack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item)
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else
{
Player::deployItem(%player,%item);
}
}

function BlastDoorPack::onDeploy(%player,%item,%pos)
{
if (BlastDoorPack::deployShape(%player,%item))
{
//Player::decItemCount(%player,%item);
}
}

function BlastDoorPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{
%obj = getObjectType($los::object);
%rot = GameBase::getRotation(%player);
%camera = newObject("BlastDoorPack","StaticShape",BlastDoorShape,true);
addToSet("MissionCleanup", %camera);
GameBase::setTeam(%camera,GameBase::getTeam(%player));
GameBase::setRotation(%camera,%rot);
GameBase::setPosition(%camera,$los::position);
Gamebase::setMapName(%camera,"Blast Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::sendMessage(%client,0,"Blast Door deployed");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%camera) @ "BlastDoorPack"]++;
echo("MSG: ",%client," deployed a Blast Door ");
return true;
}
else 
{
Client::sendMessage(%client,0,"Cannot deploy here.");
}
}
else
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::  FORCE  FIELD  DOOR  3X4  ::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

ItemImageData doorthreebyfourForceFieldPackImage
{
//shapeFile = "forcefield_3x4";
shapeFile = "AmmoPack";
mountPoint = 2;
mountOffset = { 0, -0.12, 3.0 };
mountRotation = { 90, 0, 0 };
mass = 2.5;
firstPerson = false;
};

ItemData doorthreebyfourForceFieldPack
{
description = "3x4 Field Door";
//shapeFile = "forcefield_3x4";
shapeFile = "AmmoPack";
className = "Backpack";
heading = "pDoors";
imageType = doorthreebyfourForceFieldPackImage;
shadowDetailMask = 4;
mass = 2.5;
elasticity = 0.2;
price = 500;
hudIcon = "deployable";
showWeaponBar = true;
hiliteOnActive = true;
};

function doorthreebyfourForceFieldPack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item)
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else
{
Player::deployItem(%player,%item);
}
}

function doorthreebyfourForceFieldPack::onDeploy(%player,%item,%pos)
{
if (doorthreebyfourForceFieldPack::deployShape(%player,%item))
{
//Player::decItemCount(%player,%item);
}
}

function doorthreebyfourForceFieldPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{
%obj = getObjectType($los::object);
%rot = GameBase::getRotation(%player);
%camera = newObject("doorthreebyfourForceFieldPack","StaticShape",doorthreebyfourForceFieldShape,true);
addToSet("MissionCleanup", %camera);
GameBase::setTeam(%camera,GameBase::getTeam(%player));
GameBase::setRotation(%camera,%rot);
GameBase::setPosition(%camera,$los::position);
Gamebase::setMapName(%camera,"3x4 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::sendMessage(%client,0,"3x4 Force Field Door deployed");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%camera) @ "doorthreebyfourForceFieldPack"]++;
echo("MSG: ",%client," deployed a 3x4 Force Field Door ");
return true;
}
else 
{
Client::sendMessage(%client,0,"Cannot deploy here.");
}
}
else
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::  FORCE  FIELD  DOOR  4X8  :::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}




ItemImageData doorfourbyeightForceFieldPackImage
{
//shapeFile = "forcefield_4x8";
shapeFile = "AmmoPack";
mountPoint = 2;
mountOffset = { 0, -0.12, 3.0 };
mountRotation = { 90, 0, 0 };
mass = 2.5;
firstPerson = false;
};

ItemData doorfourbyeightForceFieldPack
{
description = "4x8 Field Door";
//shapeFile = "forcefield_4x8";
shapeFile = "AmmoPack";
className = "Backpack";
heading = "pDoors";
imageType = doorfourbyeightForceFieldPackImage;
shadowDetailMask = 4;
mass = 2.5;
elasticity = 0.2;
price = 500;
hudIcon = "deployable";
showWeaponBar = true;
hiliteOnActive = true;
};

function doorfourbyeightForceFieldPack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item)
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else
{
Player::deployItem(%player,%item);
}
}

function doorfourbyeightForceFieldPack::onDeploy(%player,%item,%pos)
{
if (doorfourbyeightForceFieldPack::deployShape(%player,%item))
{
//Player::decItemCount(%player,%item);
}
}

function doorfourbyeightForceFieldPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{
%obj = getObjectType($los::object);
%rot = GameBase::getRotation(%player);
%camera = newObject("doorfourbyeightForceFieldPack","StaticShape",doorfourbyeightForceFieldShape,true);
addToSet("MissionCleanup", %camera);
GameBase::setTeam(%camera,GameBase::getTeam(%player));
GameBase::setRotation(%camera,%rot);
GameBase::setPosition(%camera,$los::position);
Gamebase::setMapName(%camera,"4x8 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::sendMessage(%client,0,"4x8 Force Field Door deployed");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%camera) @ "doorfourbyeightForceFieldPack"]++;
echo("MSG: ",%client," deployed a 4x8 Force Field Door ");
return true;
}
else 
{
Client::sendMessage(%client,0,"Cannot deploy here.");
}
}
else
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}









//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  FORCE  FIELD  DOOR  4X14  ::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}







ItemImageData doorfourbyfourteenForceFieldPackImage
{
        //shapeFile = "forcefield_4x14";
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData doorfourbyfourteenForceFieldPack
{
        description = "4x14 Field Door";
        //shapeFile = "forcefield_4x14";
        shapeFile = "AmmoPack";
        className = "Backpack";
          heading = "pDoors";
        imageType = doorfourbyfourteenForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function doorfourbyfourteenForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function doorfourbyfourteenForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (doorfourbyfourteenForceFieldPack::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function doorfourbyfourteenForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("doorfourbyfourteenForceFieldPack","StaticShape",doorfourbyfourteenForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"4x14 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"4x14 Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "doorfourbyfourteenForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a 4x14 Force Field Door ");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}













//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::  FORCE  FIELD  DOOR  4X17  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData doorfourbyseventeenForceFieldPackImage
{
        //shapeFile = "forcefield_4x17";
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData doorfourbyseventeenForceFieldPack
{
        description = "4x17 Field Door";
        //shapeFile = "forcefield_4x17";
        shapeFile = "AmmoPack";
        className = "Backpack";
         heading = "pDoors";
        imageType = doorfourbyseventeenForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function doorfourbyseventeenForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function doorfourbyseventeenForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (doorfourbyseventeenForceFieldPack::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function doorfourbyseventeenForceFieldPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{
if (GameBase::getLOSInfo(%player,10000)) 
{



%obj = getObjectType($los::object);
%rot = GameBase::getRotation(%player);
%camera = newObject("doorfourbyseventeenForceFieldPack","StaticShape",doorfourbyseventeenForceFieldShape,true);
addToSet("MissionCleanup", %camera);
GameBase::setTeam(%camera,GameBase::getTeam(%player));
GameBase::setRotation(%camera,%rot);
GameBase::setPosition(%camera,$los::position);
Gamebase::setMapName(%camera,"4x17 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
Client::sendMessage(%client,0,"4x17 Force Field Door deployed");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%camera) @ "doorfourbyseventeenForceFieldPack"]++;
echo("MSG: ",%client," deployed a 4x17 Force Field Door ");
return true;



}
else 
{
Client::sendMessage(%client,0,"Cannot deploy here.");
}
}
else
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
return false;
}










//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::  FORCE  FIELD  DOOR  5X5  :::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData doorfivebyfiveForceFieldPackImage
{
        //shapeFile = "forcefield_5x5";
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData doorfivebyfiveForceFieldPack
{
        description = "5x5 Field Door";
        //shapeFile = "forcefield_5x5";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "pDoors";
        imageType = doorfivebyfiveForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function doorfivebyfiveForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function doorfivebyfiveForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (doorfivebyfiveForceFieldPack::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function doorfivebyfiveForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("doorfivebyfiveForceFieldPack","StaticShape",doorfivebyfiveForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"5x5 Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"5x5 Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "doorfivebyfiveForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a 5x5 Force Field Door ");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}


//==============================================================
//==============================================================
//===============================================================







//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  PANEL  ONE  ::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData newdooroneImage
{
        shapeFile = "newdoor1_r";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData newdoorone
{
        description = "Panel One";
        shapeFile = "newdoor1_r";
        className = "Backpack";
        heading = "nDeployable Walls";
        imageType = newdooroneImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function newdoorone::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function newdoorone::onDeploy(%player,%item,%pos)
{
        if (newdoorone::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function newdoorone::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("newdoorone","StaticShape",newdooroneShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera," Panel Wall1 #"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Wall deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "newdoorone"]++;
                                        echo("MSG: ",%client," deployed a Panel One Wall");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}













//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  PANEL  TWO  ::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}




ItemImageData newdoortwoImage
{
        shapeFile = "newdoor2_r";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData newdoortwo
{
        description = "Panel Two";
        shapeFile = "newdoor2_r";
        className = "Backpack";
        heading = "nDeployable Walls";
        imageType = newdoortwoImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function newdoortwo::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function newdoortwo::onDeploy(%player,%item,%pos)
{
        if (newdoortwo::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function newdoortwo::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("newdoortwo","StaticShape",newdoortwoShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera," Panel Wall2 #"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Wall deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "newdoortwo"]++;
                                        echo("MSG: ",%client," deployed a Panel Two Wall");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}














//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::  PANEL  THREE  ::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData newdoorthreeImage
{
        shapeFile = "newdoor3_r";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData newdoorthree
{
        description = "Panel Three";
        shapeFile = "newdoor3_r";
        className = "Backpack";
        heading = "nDeployable Walls";
        imageType = newdoorthreeImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function newdoorthree::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function newdoorthree::onDeploy(%player,%item,%pos)
{
        if (newdoorthree::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function newdoorthree::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("newdoorthree","StaticShape",newdoorthreeShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera," Panel Wall3 #"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Wall deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "newdoorthree"]++;
                                        echo("MSG: ",%client," deployed a Panel Three Wall");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}











//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  PANEL  FOUR  ::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}




ItemImageData newdoorfourImage
{
        shapeFile = "newdoor4_r";
        mountPoint = 2;
        mountOffset = { 0, -0.12, 3.0 };
        mountRotation = { 90, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData newdoorfour
{
        description = "Panel Four";
        shapeFile = "newdoor4_r";
        className = "Backpack";
        heading = "nDeployable Walls";
        imageType = newdoorfourImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function newdoorfour::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function newdoorfour::onDeploy(%player,%item,%pos)
{
        if (newdoorfour::deployShape(%player,%item))
        {
                //Player::decItemCount(%player,%item);
        }
}

function newdoorfour::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("newdoorfour","StaticShape",newdoorfourShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera," Panel Wall 4 #"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Wall deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "newdoorfour"]++;
                                        echo("MSG: ",%client," deployed a Panel Four Wall");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}


























//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::  DEPLOYABLE  PLATFORM  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData PlatformPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData PlatformPack 
{ 
description = "Deployable Platform"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = PlatformPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function PlatformPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function PlatformPack::onDeploy(%player,%item,%pos) 
{ 
if (PlatformPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function PlatformPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"DeployablePlatform",%num); 
deleteObject(%set); 
%rot = GameBase::getRotation(%player); 
%phase = newObject("DeployablePlatform","StaticShape",DeployablePlatform,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Deployable Platform"); 
Client::sendMessage(%client,0,"Platform Deployed"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "PlatformPack"]++;
echo("MSG: ",%client," deployed a Platform");  
return true; 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::  LARGE  PLATFORM  ::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData LrgPltPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.1, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData LrgPltPack 
{ 
description = "LargePlatform"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = LrgPltPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function LrgPltPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function LrgPltPack::onDeploy(%player,%item,%pos) 
{ 
if (LrgPltPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function LrgPltPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"DeployablePlatform",%num); 
deleteObject(%set); 
%rot = GameBase::getRotation(%player); 
%phase = newObject("LargePlatform","StaticShape",LargePlatform,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Large Platform"); 
Client::sendMessage(%client,0,"Platform Deployed"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "LrgPltPack"]++; 
echo("MSG: ",%client," deployed a Large Platform");   
return true;  
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::  HOLOGRAM  :::::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData HoloPackImage 
{ 
shapeFile = "ShieldPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 1.0; firstPerson = false; 
}; 

ItemData HoloPack 
{ 
description = "Hologram"; 
shapeFile = "larmor"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = HoloPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 900; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function HoloPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} else 
{ 
Player::deployItem(%player,%item); } 
} 

function HoloPack::onDeploy(%player,%item,%pos) 
{ 
if (HoloPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function HoloPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ "hologram"] < $TeamItemMax["hologram"]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"Hologram",%num); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
if(checkDeployArea(%client,$los::position)) 
{ 
%rot = GameBase::getRotation(%player); 
%rnd = floor(getRandom() * 10); 
if(%rnd > 6) 
%phase = newObject("","StaticShape",Hologram1,true); 
else 
if((%rnd > 2) && (%rnd < 7)) 
%phase = newObject("","StaticShape",Hologram2,true); 
else 
%phase = newObject("","StaticShape",Hologram3,true); 
%armor = Player::getArmor(%player); 
if (%armor == "dmarmor" || %armor == "dmfemale") 
{ 
%phase = newObject("","StaticShape",Hologram2,true); 
} 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Client::sendMessage(%client,0,"Hologram Deployed"); GameBase::startFadeIn(%phase); 
playSound(ForceFieldOpen,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "hologram"]++;echo("MSG: ",%client," deployed a Hologram");  return true; } 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  TREE  PACK  ::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData TreePackImage 
{ 
shapeFile = "tree1"; 
mountPoint = 2; 
mountOffset = { 0, 0.15, -1 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData TreePack 
{ 
description = "Mechanical Tree"; 
shapeFile = "tree1"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = TreePackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function TreePack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function TreePack::onDeploy(%player,%item,%pos) 
{ 
if (TreePack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function TreePack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableTree",%num); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%rnd = floor(getRandom() * 10); 
if(%rnd > 5) 
%phase = newObject("","StaticShape",DeployableTree,true); 
else 
%phase = newObject("","StaticShape",DeployableTree2,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Mechanical Tree"); 
Client::sendMessage(%client,0,"Mechanical Tree Deployed"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
playSound(ForceFieldOpen,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "TreePack"]++;
echo("MSG: ",%client," deployed a Tree");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 

ItemImageData SpringPackImage 
{ 
shapeFile = "AmmoPack"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData SpringPack 
{ 
description = "Springboard"; 
shapeFile = "AmmoPack"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = SpringPackImage; 
shadowDetailMask = 4; 
mass = 1.0; 
elasticity = 0.2; 
price = 500; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function SpringPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function SpringPack::onDeploy(%player,%item,%pos) 
{ 
if (SpringPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function SpringPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape") 
{ 
%set = newObject("set",SimSet); 
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0); 
%num = CountObjects(%set,"DeployableCactus",%num); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%rot = GameBase::getRotation(%player); 
%phase = newObject("","StaticShape",DeployableSpring,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,$los::position); 
GameBase::setRotation(%phase,%rot); 
Gamebase::setMapName(%phase,"Springboard"); 
Client::sendMessage(%client,0,"Springboard Deployed"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
playSound(ForceFieldOpen,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "SpringPack"]++;
echo("MSG: ",%client," deployed a Spring Board");  
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData TeleportPackImage 
{ 
shapeFile = "flagstand"; 
mountPoint = 2; 
mountOffset = { 0, 0, 0.1 }; 
mountRotation = { 1.57, 0, 0 }; 
firstPerson = false; 
}; 

ItemData TeleportPack 
{ 
description = "Teleport Pad"; 
shapeFile = "flagstand"; 
className = "Backpack"; 
heading = "hDeployable Base Objects"; 
imageType = TeleportPackImage; 
shadowDetailMask = 4; 
mass = 5.0; 
elasticity = 0.2; 
price = 3200; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function TeleportPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function TeleportPack::onDeploy(%player,%item,%pos) 
{ 
if (teleportPack::deployShape(%player,"Teleport Pad",DeployableTeleport,%item)) 
{ 
//Player::decItemCount(%player,%item); 
$TeamItemCount[GameBase::getTeam(%player) @ "DeployableTeleport"]++; 
} 
} 

function CreateteleportSimSet() 
{ 
%teleset = nameToID("MissionCleanup/Teleports"); 
if(%teleset == -1) 
{ 
newObject("Teleports",SimSet); 
addToSet("MissionCleanup","Teleports"); 
} 
} 

function TeleportPack::deployShape(%player,%name,%shape,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ "DeployableTeleport"] < $TeamItemMax[DeployableTeleport]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%sensor = newObject("Teleport Pad","StaticShape",%shape,true); 
CreateteleportSimSet(); 
addToSet("MissionCleanup/Teleports", %sensor); 
addToSet("MissionCleanup", %sensor); 
GameBase::setTeam(%sensor,GameBase::getTeam(%player)); 
%pos = Vector::add($los::position,"0 0 1"); 
echo("LOS pos " @ $los::position @ " " @ %pos); 
GameBase::setPosition(%sensor,%pos); 
Gamebase::setMapName(%sensor,%name); 
Client::sendMessage(%client,0,%item.description @ " deployed"); 
%sensor.disabled = false; 
playSound(SoundPickupBackpack,$los::position); 
%beam = newObject("","StaticShape",ElectricalBeamBig,true); 
addToSet("MissionCleanup", %beam); 
GameBase::setTeam(%beam,GameBase::getTeam(%player)); 
GameBase::setPosition(%beam,%pos); 
%sensor.beam1 = %beam; 
return true;  
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %name @ "s"); 
return false; 
}





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::  DEPLOYABLE  FLAG  STAND  ::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


StaticShapeData DeployableFlagStand
{
   	description = "Deployable Flag Stand";
	shapeFile = "flagstand";
	debrisId = defaultDebrisSmall;
	maxDamage = 3.0;
	shadowDetailMask = 4;
	mapFilter = 4;
	explosionId = debrisExpMedium;
	visibleToSensor = true;
};


function DeployableFlagstand::onDestroyed(%this)
{	
   
   StaticShape::objectiveDestroyed(%this);
   $TeamItemCount[GameBase::getTeam(%this) @ "FlagStandPack"]--;
   %flag = %this.carryflag;
   if(%flag != "")
	{
		%flag.flagstand = "";
		schedule("Flag::checkReturn(" @ %flag @ ", " @ %flag.pickupSequence @ ");", $flagReturnTime);
	}
}

ItemImageData FlagstandPackImage
{
	shapeFile = "ammopack";
	mountPoint = 2;
	mountOffset = { 0, 0, 0 };
	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData FlagstandPack
{	
	description = "Flag Stand";
	shapefile = "ammopack";
	classname = "Backpack";
	heading = "hDeployable Base Objects";
	imageType = FlagstandPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.1;
	price = 100;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function FlagstandPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
	{
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else 
	{
		Player::deployItem(%player,%item);
	}
}

function FlagStandPack::onDeploy(%player,%item,%pos)
{
	if (FlagstandPack::deployShape(%player,%item)) 
	{
		//Player::decItemCount(%player,%item);
	}
}

function FlagstandPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
	{
		if (GameBase::getLOSInfo(%player,10000)) 
		{
			%obj = "InteriorShape";
			if (%obj == "InteriorShape") 
			{
				if (Vector::dot($los::normal,"0 0 1") > 0.7) 
				{
					if(%obj == "InteriorShape") 
					{
						%playerPos = GameBase::getPosition(%player);
						%flag = $teamFlag[GameBase::getTeam(%player)];
						%flagpos = %flag.originalposition;
						if(Vector::getDistance(%flagpos, %playerpos) < 7000)
						{
							%rot = GameBase::getRotation(%player); 
							%sensor = newObject("","Staticshape",DeployableFlagstand,true);
	                    					addToSet("MissionCleanup", %sensor);
							GameBase::setTeam(%sensor,GameBase::getTeam(%player));
							GameBase::setPosition(%sensor,$los::position);
							GameBase::setRotation(%sensor,%rot);
							Gamebase::setMapName(%sensor,"Flagstand #" @ $totalNumFlagstands++ @ " " @ Client::getName(%client));
							Client::sendMessage(%client,0,"Flag stand deployed");
							playSound(SoundPickupBackpack,$los::position);
							$TeamItemCount[GameBase::getTeam(%player) @ "FlagstandPack"]++;
							echo("MSG: ",%client," deployed a Flag stand");
							return true;
						}	
						else
						{
							Client::sendMessage(%client,0,"You are too far away from the flags original position.");
							return false;
						}
					}
				}
				else 
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
		return false;
}

function DeployableFlagstand::onCollision(%this,%object)
{
   if(%object.enterTime > getSimTime() - 3)
	return;
   %standTeam = GameBase::getTeam(%this);
   %playerTeam = GameBase::getTeam(%object);
   %playerClient = Player::getClient(%object);

   if(getObjectType(%object) != "Player" || %playerTeam != %standTeam || %object.carryflag == "") // %standteam == -1 ||
      return;

   %flag = %object.carryFlag;
   %flagTeam = GameBase::getTeam(%flag);
   if(%this.carryflag != "")
	return;

   %this.carryflag = %flag;
   %flag.carrier = -1;
   Item::hide(%flag, false);
   GameBase::setPosition(%flag, GameBase::getPosition(%this)); 
   playSound(SoundPickupBackpack, GameBase::getPosition(%this));

   %flag.flagStand = %this;
   Player::setItemCount(%object, Flag, 0);
   %object.carryFlag = "";
   %playerClient = Player::getClient(%object);
   Flag::clearWaypoint(%playerClient, true);
   if(getTeamName(%flag) == %playerTeam){
   	MessageAllExcept(%playerClient, 0,"The " @ getTeamName(%playerteam) @ " flag has been moved to a new position");
   	Client::sendMessage(%playerClient, 0, "You moved your flag.");
   }
   else {
	MessageAllExcept(%playerClient, 0,"The " @ getTeamName(%playerteam) @ " have set an enemy flag on a flagstand");
   	Client::sendMessage(%playerClient, 0, "You placed the enemy flag down.");
   }	
   %object.enterTime = getSimTime();
}







//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::  JAIL  GUN  ::::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData JailGunImage
{
          shapeFile = "shotgun";
           mountPoint = 0;

           weaponType = 2;
           projectileType = jailbolt;


           minEnergy = 5;
           maxEnergy = 80;
           reloadTime = 4.0;

          lightType = 3;
          lightRadius = 2;
          lightTime = 1;
          lightColor = { 0.25, 0.25, 0.85 };

          sfxActivate = SoundPickUpWeapon;
          sfxFire     = SoundELFIdle;
};
ItemData JailGun
{
        heading = "tTool";
        description = "Jailers Gun";
        className = "Tool";
        shapeFile  = "repairgun";
        hadowDetailMask = 4;
        imageType = JailGunImage;
        price = 385;
        showWeaponBar = true;
};






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  JAIL  CAP  PACK  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData JailCapPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, -0.5, -0.3 };
        mass = 2.5;
        firstPerson = false;
};

ItemData JailCapPack
{
        description = "Jail Capture Pad";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "iJail";
        imageType = JailCapPackImage;
        shadowDetailMask = 4;
        mass = 1.0;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function JailCapPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else {
                Player::deployItem(%player,%item);
        }
}

function JailCapPack::onDeploy(%player,%item,%pos)
{
        if (JailCapPack::deployShape(%player,%item)) {
                //Player::decItemCount(%player,%item);
        }
}
function JailCapPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,10000)) {

                        %obj = getObjectType($los::object);

                         %playerPos = GameBase::getPosition(%player);
                         %flag = $teamFlag[GameBase::getTeam(%player)];
                         %flagpos = gamebase::getPosition(%flag);

                         if(Vector::getDistance(%flagpos, %playerpos) < 10)
                          {
                          Client::sendMessage(%client,0,"You are too close to your flag, Must be further from flag to deploy.");
                          return;
                          }


                                %prot = GameBase::getRotation(%player);
                                %zRot = getWord(%prot,2);
                                %rot =  "1.57079 0 " @ %zRot;
                                %padd = "0 0 0";
                                %pos = Vector::add($los::position,%padd);
//
                                        %camera = newObject("","StaticShape","jailpad",true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,"0 0 0");
                                        GameBase::setPosition(%camera,%pos);
                                        Gamebase::setMapName(%camera,"JailPad " @ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Jail Pad Deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%player) @ "JailCapPack"]++;
                                        echo("MSG: ",%client," deployed a Jail Pad");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::  JAIL  CELL  PACK  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}




ItemImageData jailpackImage
{
shapeFile = "ammopack";
mountPoint = 2;
mountOffset = { 0, 0, 0 };
mountRotation = { 0, 0, 0 };
firstPerson = false;
};

ItemData jailpack
{
description = "Jail Cell";
shapeFile = "shieldpack";
className = "Backpack";
heading = "iJail";
imageType = jailpackImage;
shadowDetailMask = 4;
mass = 5.0;
elasticity = 0.2;
price = 9000;
hudIcon = "deployable";
showWeaponBar = true;
hiliteOnActive = true;
};

function jailpack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item)
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else
{
Player::deployItem(%player,%item);
}
}

function jailpack::onDeploy(%player,%item,%pos)
{
if (jailpack::deployShape(%player,%item))
{
Player::decItemCount(%player,%item);
}
}

function CreatejailportSimSet()
{
%teleset = nameToID("MissionCleanup/jailports");
if(%teleset == -1)
{
newObject("jailports",SimSet);
addToSet("MissionCleanup","jailports");
}
}

function jailpack::deployshape(%player,%item)
{
GameBase::getLOSInfo(%player,10000);
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ "jailpack"] >= $TeamItemMax[jailpack])
{
Client::sendMessage(%client,0,"Can Not Deploy Jail Cell Already In Place");
return false;
}
%playerPos = GameBase::getPosition(%player);
%flag = $teamFlag[GameBase::getTeam(%player)];
%flagpos = gamebase::getPosition(%flag);
if(Vector::getDistance(%flagpos, %playerpos) < 150)
{
Client::sendMessage(%client,0,"You are too close to your flag, Must be further from flag to deploy.");
return ; 
}
%obj = getObjectType($los::object);
%set = newObject("Jail",SimSet);
%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0);
%num = CountObjects(%set,"Jail",%num);

%objDevice =   newObject("Jail","Staticshape",LLargeForceField,true);
%objDevice.objSide1 = newObject("Jail","Staticshape",LLargeForceField,true);
%objDevice.objSide2 = newObject("Jail","Staticshape",LLargeForceField,true);
%objDevice.objSide3 = newObject("Jail","Staticshape",LLargeForceField,true);
%objDevice.objSide4 = newObject("Jail","Staticshape",LLargeForceField,true);
%objDevice.objSide5 = newObject("Jail","StaticShape",LLargeForceField,true);
%objDevice.objSide6 = newObject("Jail","StaticShape",LLargeForceField,true);
%objDevice.objSide7 = newObject("Jail","StaticShape",LLargeForceField,true);
%objDevice.objSide8 = newObject("Jail","StaticShape",JailSwitchOpen,true);
%objDevice.objSide9 = newObject("Jail","StaticShape",LLargeForceField,true);
%objDevice.objSide10 = newObject("Jail","StaticShape",JailSwitchClose,true);

%objDevice.objSide1.objParent = %objDevice;
%objDevice.objSide2.objParent = %objDevice;
%objDevice.objSide3.objParent = %objDevice;
%objDevice.objSide4.objParent = %objDevice;
%objDevice.objSide5.objParent = %objDevice;
%objDevice.objSide6.objParent = %objDevice;
%objDevice.objSide7.objParent = %objDevice;
%objDevice.objSide8.objParent = %objDevice;
%objDevice.objSide9.objParent = %objDevice;
%objDevice.objSide10.objParent = %objDevice;

addToSet(MissionCleanup, %objDevice);
addToSet(MissionCleanup, %objDevice.objSide1);
addToSet(MissionCleanup, %objDevice.objSide2);
addToSet(MissionCleanup, %objDevice.objSide3);
addToSet(MissionCleanup, %objDevice.objSide4);
addToSet(MissionCleanup, %objDevice.objSide5);
addToSet(MissionCleanup, %objDevice.objSide6);
addToSet(MissionCleanup, %objDevice.objSide7);
addToSet(MissionCleanup, %objDevice.objSide8);
addToSet(MissionCleanup, %objDevice.objSide9);
addToSet(MissionCleanup, %objDevice.objSide10);

%pos = Vector::add(GameBase::getPosition(%player), "0 1 80");
GameBase::setRotation(%objDevice.objSide1,"0 0 0");
GameBase::setPosition(%objDevice.objSide1,%pos);
GameBase::setTeam(%objDevice.objSide1,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "-5.5 6.5 80");
GameBase::setRotation(%objDevice.objSide2,"0 0 4.71339");
GameBase::setPosition(%objDevice.objSide2,%pos);
GameBase::setTeam(%objDevice.objSide2,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "5.5 6.5 80");
GameBase::setRotation(%objDevice.objSide3,"0 0 4.71339");
GameBase::setPosition(%objDevice.objSide3,%pos);
GameBase::setTeam(%objDevice.objSide3,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "0 12.5 86");
GameBase::setRotation(%objDevice.objSide4,"-4.71339 0 0");
GameBase::setPosition(%objDevice.objSide4,%pos);
GameBase::setTeam(%objDevice.objSide4,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "0 .5 86");
GameBase::setRotation(%objDevice,"4.71339 0 0");
GameBase::setPosition(%objDevice,%pos);
GameBase::setTeam(%objDevice,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "0 12.5 80");
GameBase::setRotation(%objDevice.objSide6,"-4.71339 0 0");
GameBase::setPosition(%objDevice.objSide6,%pos);
GameBase::setTeam(%objDevice.objSide6,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "0 .5 80");
GameBase::setRotation(%objDevice.objSide7,"4.71339 0 0");
GameBase::setPosition(%objDevice.objSide7,%pos);
GameBase::setTeam(%objDevice.objSide7,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "-5 13 80.00");
GameBase::setRotation(%objDevice.objSide8,"0 0 0");
GameBase::setPosition(%objDevice.objSide8,%pos);
GameBase::setTeam(%objDevice.objSide8,GameBase::getTeam(%player));

%pos = Vector::add(GameBase::getPosition(%player), "0 18 80");
GameBase::setRotation(%objDevice.objSide9,"-4.71339 0 0");
GameBase::setPosition(%objDevice.objSide9,%pos);
GameBase::setTeam(%objDevice.objSide9,GameBase::getTeam(%player));


%pos = Vector::add(GameBase::getPosition(%player), "5 13 80.00");
GameBase::setRotation(%objDevice.objSide10,"0 0 0");
GameBase::setPosition(%objDevice.objSide10,%pos);
GameBase::setTeam(%objDevice.objSide10,GameBase::getTeam(%player));


playSound(SoundPickupBackpack,$los::position);

newObject("jaildoor",SimSet);
addToSet("MissionCleanup","jaildoor");
%sensor = newObject("jaildoor","StaticShape",jLargeForceField,true);

addToSet("MissionCleanup/jaildoor", %sensor);
addToSet("MissionCleanup", %sensor);
GameBase::setTeam(%sensor,GameBase::getTeam(%player));
%pos = Vector::add(GameBase::getPosition(%player), "0 12 80");
GameBase::setPosition(%sensor,%pos);
GameBase::setRotation(%sensor,"0 0 0");
%sensor.disabled = false;
playSound(SoundPickupBackpack,$los::position);



%sensor = newObject("Teleport Pad","StaticShape","jailStand",true);
CreatejailportSimSet();
addToSet("MissionCleanup/jailports", %sensor);
addToSet("MissionCleanup", %sensor);
GameBase::setTeam(%sensor,GameBase::getTeam(%player));
%pos = Vector::add(GameBase::getPosition(%player), "0 3 81");
GameBase::setPosition(%sensor,%pos);
Gamebase::setMapName(%sensor,%name);


%sensor.disabled = false;
playSound(SoundPickupBackpack,$los::position);

%beam = newObject("","StaticShape",ElectricalBeamBig,true);
addToSet("MissionCleanup", %beam);
GameBase::setTeam(%beam,GameBase::getTeam(%player));
GameBase::setPosition(%beam,%pos);
%sensor.beam1 = %beam;
playSound(SoundPickupBackpack,$los::position);


newObject("releasepad",SimSet);
CreatereleasepadSimSet();
addToSet("MissionCleanup/releasepad", %sensor);
addToSet("MissionCleanup", %sensor);
%sensor = newObject("releasepad","StaticShape","jailStandTop",true);

addToSet("MissionCleanup/releasepad", %sensor);
GameBase::setTeam(%sensor,GameBase::getTeam(%player));
%pos = Vector::add(GameBase::getPosition(%player), "0 3 86.30");

GameBase::setPosition(%sensor,%pos);
Gamebase::setMapName(%sensor,%name);


%sensor.disabled = false;


$TeamItemCount[GameBase::getTeam(%sensor) @ "jailpack"]++;
echo("MSG: ",%client," deployed a Jail Cell");
Client::sendMessage(%client,0,%item.description @ " deployed 250' Up");
return true;
}
function CreatereleasepadSimSet()
{
%teleset = nameToID("MissionCleanup/releasepad");
if(%teleset == -1)
{
newObject("releasepad",SimSet);
addToSet("MissionCleanup","releasepad");
}
}








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  HACKING  :::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}






function checkHackable(%name, %shape)
{ 
	if(%shape == "generator" ||
	%shape == "Generator" ||
	%shape == "generator_p" ||
	%shape == "solar_med" ||
	%shape == "inventory_sta" ||
	%shape == "elevator_4x4" ||
	%shape == "elevator_6x6" ||
	%shape == "elevator_6x6_octagon" ||
	%shape == "elevator_8x4" ||
	%shape == "elevator_8x6" ||
	%shape == "elevator_9x9" ||
	%shape == "elevator16x16_octo" ||
	%shape == "elevator6X4" ||
	%shape == "elevator_6x5" ||
	%shape == "elevator_8x8" ||
	%shape == "elevator6x4thin" ||
	%shape == "elevator6x6thin" ||
	%shape == "elevator_5x5" ||
	%shape == "elevator_4x5" ||
	%shape == "door_top" ||
	%shape == "door_bot" ||
	%shape == "newdoor1_l" ||
	%shape == "newdoor1_r" ||
	%shape == "newdoor2_l" ||
	%shape == "newdoor2_r" ||
	%shape == "newdoor3_l" ||
	%shape == "newdoor3_r" ||
	%shape == "newdoor4_l" ||
	%shape == "newdoor4_r" ||
	%shape == "newdoor6_l" ||
	%shape == "newdoor6_r" ||
	%shape == "door_8x8_l" ||
	%shape == "door_8x8_r" ||
	%shape == "forcefield" ||
	%shape == "forcefield_3x4" ||
	%shape == "forcefield_4x17" ||
	%shape == "newdoor3_r" ||
	%shape == "newdoor4_l" || 
	%shape == "newdoor4_r" || 
	%shape == "newdoor6_l" ||
	%shape == "newdoor6_r"	||
	%shape == "forcefield_4x14" ||
	%shape == "forcefield_4x8" ||
	%shape == "forcefield_5x5" || 
	%shape == "door_4x4_diagonal" ||
	%shape == "tower" ||
	%shape == "camera" ||
	%shape == "hellfiregun" ||
	%shape == "indoorgun" ||
	%shape == "mortar_turret" ||
	%shape == "ammounit" || 
	%shape == "sensor_pulse_med" ||
	%shape == "station_cmdpnl" ||
	%shape == "missileturret" ||
	%shape == "cmdpnl" ||
	%shape == "radar" ||
	%shape == "anten_lava" ||
      %shape == "newdoor5" ||
	%shape == "vehi_pur_poles")
	{
		return 0;
	}

	return 1;
}

function hackingItem(%target, %pTeam, %pName, %tName, %name, %team, %time, %client)
{
%shape = (GameBase::getDataName(%target)).shapeFile;
if ($debug) 
echo  ("Hacking");
if(%time > 0)
{
if($hacking[%client] == "true")
{		
schedule("hackingItem('" @ %target @ "','" @ %pTeam @ "','" @ %pName @ "','" @ %tName @ "','" @ %name @ "','" @ %team @ "','" @ %time - 1 @ "','" @ %client @ "');", 1);
return;
}
}
else 
if ((%time < 0 || %time == 0) && $hacking[%client] == "true")
{
if ($debug) 
echo ("PT - " @ %pteam @ "");
if ($debug) 
echo ("TT - " @ %team @ "");
if ($debug) 
echo ("HK - " @ $hacking[%client] @ "");
if ($debug) 
echo ("TG - " @ %target @ "");
if ($debug) 
echo ("Tm - " @ %time @ "");
if($hacking[%client] == "true")
{
if(%team == %pTeam)
{
if ($debug) echo ("infecting");
%target.infected = "true";
schedule ("playSound(TargetingMissile,GameBase::getPosition(" @ %target @ "));",0.1);
Client::sendMessage(%client,1,"Your " @ %name @ " is now protected by viral infection, from hacking.");
return;
}
else
{
if (%target.infected == "true")
{
%rnd = floor(getRandom() * 100);	
if (%rnd > 50)
{
schedule ("playSound(TargetingMissile,GameBase::getPosition(" @ %target @ "));",0.2);
Client::sendMessage(%client,1,"You disarm the protection virus in the " @ %name @ ", but it costs you!!!");
%player = Client::getOwnedObject(%client);
Player::blowUp(%this);
GameBase::applyDamage(%player,$FlashDamageType,0.90,GameBase::getPosition(%player),"0 0 0","0 0 0",%target);
%target.infected = "false";
return;
}
else
{
schedule ("playSound(TargetingMissile,GameBase::getPosition(" @ %target @ "));",0.2);
Client::sendMessage(%client,1,"You safely disarm the protection virus in the " @ %name @ ".");
%target.infected = "false";
return;
}
}
if(%name == "False" && %shape == "magcargo")
{
%rnd = floor(getRandom() * 10);
if(%rnd == 1)
{	
Client::sendMessage(%client,1,"OOPS! You cut the wrong wire...");
Mine::Detonate(" @ %this @ ");
return;
}
else
{	
Client::sendMessage(%client,1,"You disarm the DetPack.");
%client.score = %client.score + 2;
Game::refreshClientScore(%client);
deleteObject(%target);
}
}
else
{
TeamMessages(1, %pTeam, %pName @ " hacked into the " @ %tName @ "'s " @ %name @ "!");
TeamMessages(1, %team, %pName @ " hacked into your teams " @ %name @ "!");
GameBase::setTeam(%target,%pTeam);
if($Shifter::HackedTime > 0)
{
schedule("GameBase::setTeam('" @ %target @ "','" @ $origTeam[%target] @ "');", $Shifter::HackedTime);
}
if(%target < $minHacked || $minHacked == -1)
{
$minHacked = %target;
}
if(%target > $maxHacked || $maxHacked == -1)
{
$maxHacked = %target;
}
}
}
}
}
}


ItemImageData HackitImage
{
	shapeFile = "repairgun";
	mountPoint = 0;

	weaponType = 2; // Sustained
	projectileType = "HackBolt";
	minEnergy = 5;
	maxEnergy = 12;
	
	lightType   = 3;  // Weapon Fire
	lightRadius = 1;
	lightTime   = 1;
	lightColor  = { 0.25, 1, 0.25 };

	sfxFire     = SoundRepairItem;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Hackit
{
	description   = "Engineer Hack-Gun";
	className     = "Tool";
	shapeFile     = "repairgun";
	hudIcon       = "targetlaser";
    	heading = "tTools";
	shadowDetailMask = 4;
	imageType     = HackitImage;
	price         = 1000;
	showWeaponBar = true;
};



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::  ARBITOR BOX PACK  ::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData ArbitorBoxPackImage
{
	shapeFile = "magcargo";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData ArbitorBoxPack
{
	description = "Arbitor Device";
	shapeFile = "magcargo";
	className = "Backpack";
   heading = "hDeployable Base Objects";
	imageType = ArbitorBoxPackImage;
	shadowDetailMask = 4;
	mass = 2.5;
	elasticity = 0.2;
	price = 1350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};


function ArbitorBoxPack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item)
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else
{
Player::deployItem(%player,%item);
}
}

function ArbitorBoxPack::onDeploy(%player,%item,%pos)
{
if (ArbitorBoxPack::deployShape(%player,%item))
{
Player::decItemCount(%player,%item);
}
}

function ArbitorBoxPack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
{
if (GameBase::getLOSInfo(%player,10000))
{
%obj = "InteriorShape";
if (%obj == "InteriorShape")
{
if (Vector::dot($los::normal,"0 0 1") > 0.7)
{
if(checkDeployArea(%client,Vector::add($los::position, "0.2 0.2 0")))
{
%rot = GameBase::getRotation(%player); 
%turret = newObject("ArbitorBox","Turret",ArbitorBox,true);
addToSet("MissionCleanup", %turret);
GameBase::setTeam(%turret,GameBase::getTeam(%player));
GameBase::setPosition(%turret,$los::position);
GameBase::setRotation(%turret,%rot);
Gamebase::setMapName(%turret,"Arbitor Device " @ Client::getName(%client));
Client::sendMessage(%client,0,"Arbitor Device deployed");
playSound(SoundPickupBackpack,$los::position);
//$TeamItemCount[GameBase::getTeam(%player) @ "ArbitorBoxPack"]++;
echo("MSG: ",%client," deployed an Arbitor Box");
//	Remote turrets - kill points to player that deploy them
// Client::setOwnedObject(%client, %turret); 
// Client::setOwnedObject(%client, %player);
if(Player::getMountedItem(%player, $BackpackSlot) == SCVPack)
GameBase::setDamageLevel(%turret, 0.7 * ArbitorBox.maxDamage);
return true;
}
}
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
}
else 
Client::sendMessage(%client,0,"Can only deploy in buildings");
}
else 
Client::sendMessage(%client,0,"Deploy position out of range");
}
else															
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "es");
return false;
}






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  SEED PACK  :::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemData TreePack
{
	description = "Seed Pack";
	shapeFile = "jetpack";
	className = "Backpack";
   heading = "hDeployable Base Objects";
	imageType = TreePackImage;
	shadowDetailMask = 4;
	mass = 0.5;
	elasticity = 0.1;
	price = 50;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function TreePack::onUse(%player,%item)
{
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{
Player::mountItem(%player,%item,$BackpackSlot);
}
else 
{
Player::deployItem(%player,%item);
}
}

function TreePack::onDeploy(%player,%item,%pos)
{
if (TreePack::deployShape(%player,%item))
{
//Player::decItemCount(%player,%item); //thus infinite trees to plant
}
}

function TreePack::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
{
if (GameBase::getLOSInfo(%player,15000))
{
%obj = getObjectType($los::object);
%rot = GameBase::getRotation(%player);
%rand = floor(getRandom() * 6);
if(%rand == 0) %type = "TreeShapeTwo";
else if(%rand == 1) %type = "TreeShape"; 
//else if(%rand == 3) %type = "PlantOne"; 
else if(%rand == 2) %type = "PlantTwo";
else if(%rand == 3) %type = "Cactus1"; 
else if(%rand == 4) %type = "Cactus2"; 
else %type = "Cactus3"; 

%tree = newObject("A Tree","StaticShape",%type,true);
addToSet("MissionCleanup", %tree);
GameBase::setTeam(%tree,GameBase::getTeam(%player));
GameBase::setPosition(%tree,$los::position);
GameBase::setRotation(%tree,%rot);
Gamebase::setMapName(%tree,"Tree " @ Client::getName(%client));
Client::sendMessage(%client,0,"Seed Planted");
playSound(SoundPickupBackpack,$los::position);
$TeamItemCount[GameBase::getTeam(%player) @ "TreePack"]++;
echo("MSG: ",%client," planted a seed");
//	Remote turrets - kill points to player that deploy them
Client::setOwnedObject(%client, %tree); 
Client::setOwnedObject(%client, %player);
return true;
}
else 
Client::sendMessage(%client,0,"Deploy position out of range");
}
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description);
return false;
}
 








//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]                  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//:::::::::::::::::::::::::::::::::::[  VEHICLE  PACKS  ]:::::::::::::::::::::::::::::::::
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[                  [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
//[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  SCOUT  VEHICLE  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData bomberPackImage
 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData bomberPack
 
{ 
description = "Scout Pack"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "kDeployable Vehicles"; 
imageType = bomberPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function bomberPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function bomberPack::onDeploy(%player,%item,%pos) 
{ 
if (bomberPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function bomberPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 

if($TeamItemCount[GameBase::getTeam(%player) @ "ScoutVehicle"] < $TeamItemMax[ScoutVehicle]) 
{ 
%obj = "SimTerrain";
%set = newObject("set",SimSet); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
if(%obj == "SimTerrain") 
{
%playerPos = GameBase::getPosition(%player);
%rot = GameBase::getRotation(%player); 
%phase = newObject("",flier,Scout,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,%playerPos); 
GameBase::setRotation(%phase,%rot); 
Client::sendMessage(%client,0,"Piloting Scout"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "ScoutVehicle"]++;echo("MSG: ",%client," deployed a Scout");  
return true; 
} 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  WRAITH  VEHICLE  ::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData cloakjetPackImage
 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData cloakjetPack
 
{ 
description = "Wraith Pack"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "kDeployable Vehicles"; 
imageType = cloakjetPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function cloakjetPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function cloakjetPack::onDeploy(%player,%item,%pos) 
{ 
if (cloakjetPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function cloakjetPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 

if($TeamItemCount[GameBase::getTeam(%player) @ "WraithVehicle"] < $TeamItemMax[WraithVehicle]) 
{ 
%obj = "SimTerrain";
%set = newObject("set",SimSet); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
if(%obj == "SimTerrain") 
{
%playerPos = GameBase::getPosition(%player);
%rot = GameBase::getRotation(%player); 
%phase = newObject("",flier,Wraith,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,%playerPos); 
GameBase::setRotation(%phase,%rot); 
Client::sendMessage(%client,0,"Piloting Wraith"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "WraithVehicle"]++;echo("MSG: ",%client," deployed a Wraith");  
return true; 
} 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  INTERCEPTOR  VEHICLE  :::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData MechPackImage
 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData MechPack
 
{ 
description = "Interceptor Pack"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "kDeployable Vehicles"; 
imageType = MechPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function MechPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function MechPack::onDeploy(%player,%item,%pos) 
{ 
if (MechPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function MechPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 

if($TeamItemCount[GameBase::getTeam(%player) @ "JetVehicle"] < $TeamItemMax[JetVehicle]) 
{ 
%obj = "SimTerrain";
%set = newObject("set",SimSet); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
%playerPos = GameBase::getPosition(%player);
%rot = GameBase::getRotation(%player); 
%phase = newObject("",flier,Jet,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,%playerPos); 
GameBase::setRotation(%phase,%rot); 
Client::sendMessage(%client,0,"Piloting Interceptor"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "JetVehicle"]++;echo("MSG: ",%client," deployed an Interceptor");  
return true; 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::  LAPC  VEHICLE  :::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemImageData BigBomberPackImage
 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData BigBomberPack
 
{ 
description = "LAPC Pack"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "kDeployable Vehicles"; 
imageType = BigBomberPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function BigBomberPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function BigBomberPack::onDeploy(%player,%item,%pos) 
{ 
if (BigBomberPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function BigBomberPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 

if($TeamItemCount[GameBase::getTeam(%player) @ "LAPCVehicle"] < $TeamItemMax[LAPCVehicle]) 
{ 
%obj = "SimTerrain";
%set = newObject("set",SimSet); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
if(%obj == "SimTerrain") 
{
%playerPos = GameBase::getPosition(%player);
%rot = GameBase::getRotation(%player); 
%phase = newObject("",flier,LAPC,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,%playerPos); 
GameBase::setRotation(%phase,%rot); 
Client::sendMessage(%client,0,"Piloting LAPC"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "LAPCVehicle"]++;echo("MSG: ",%client," deployed a LAPC");  
return true; 
} 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  HAPC  VEHICLE  ::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemImageData DetPackImage
 
{ 
shapeFile = "ammounit_remote"; 
mountPoint = 2; 
mountOffset = { 0, -0.03, 0 }; 
mass = 2.5; 
firstPerson = false; 
}; 

ItemData DetPack
 
{ 
description = "HAPC Pack"; 
shapeFile = "ammounit_remote"; 
className = "Backpack"; 
heading = "kDeployable Vehicles"; 
imageType = DetPackImage; 
shadowDetailMask = 4; 
mass = 1.5; 
elasticity = 0.2; 
price = 600; 
hudIcon = "deployable"; 
showWeaponBar = true; 
hiliteOnActive = true; 
}; 

function DetPack::onUse(%player,%item) 
{ 
if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
{ 
Player::mountItem(%player,%item,$BackpackSlot); 
} 
else 
{ 
Player::deployItem(%player,%item); 
} 
} 

function DetPack::onDeploy(%player,%item,%pos) 
{ 
if (DetPack::deployShape(%player,%item)) 
{ 
//Player::decItemCount(%player,%item); 
} 
} 

function DetPack::deployShape(%player,%item) 
{ 
%client = Player::getClient(%player); 

if($TeamItemCount[GameBase::getTeam(%player) @ "HAPCVehicle"] < $TeamItemMax[HAPCVehicle]) 
{ 
%obj = "SimTerrain";
%set = newObject("set",SimSet); 
deleteObject(%set); 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
if(%obj == "SimTerrain") 
{
%playerPos = GameBase::getPosition(%player);
%rot = GameBase::getRotation(%player); 
%phase = newObject("",flier,HAPC,true); 
addToSet("MissionCleanup", %phase); 
GameBase::setTeam(%phase,GameBase::getTeam(%player)); 
GameBase::setPosition(%phase,%playerPos ); 
GameBase::setRotation(%phase,%rot); 
Client::sendMessage(%client,0,"Piloting HAPC"); 
GameBase::startFadeIn(%phase); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%player) @ "HAPCVehicle"]++;echo("MSG: ",%client," deployed a HAPC");  
return true; 
} 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

function Item::deployShape(%player,%name,%shape,%item) 
{ 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7) 
{ 
if(checkDeployArea(%client,$los::position)) 
{ 
%sensor = newObject("","Sensor",%shape,true); 
addToSet("MissionCleanup", %sensor); 
GameBase::setTeam(%sensor,GameBase::getTeam(%player)); 
GameBase::setPosition(%sensor,$los::position); 
Gamebase::setMapName(%sensor,%name); 
Client::sendMessage(%client,0,%item.description @ " deployed"); 
playSound(SoundPickupBackpack,$los::position); 
echo("MSG: ",%client," deployed a ",%name); 
return true; 
} 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
else 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
else 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %name @ "s"); 
return false; 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  REPAIR  KIT  :::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


$AutoUse[RepairKit] = false; 

ItemData RepairKit 
{ 
description = "Repair Kit"; 
shapeFile = "armorKit"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 35; 
}; 
function RepairKit::onUse(%player,%item) 
{ 
Player::decItemCount(%player,%item); 
GameBase::repairDamage(%player,0.2); 
%c = Player::getClient(%player); 
$poisonTime[%c] = 0; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::  ARMOR  MINES  ::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemData MineAmmo 
{ 
description = "Mine"; 
shapeFile = "mineammo"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 10; 
className = "HandAmmo"; 
}; 

function MineAmmo::onUse(%player,%item) 
{ 
if($matchStarted) 
{ 
if(%player.throwTime < getSimTime() ) 
{ 
Player::decItemCount(%player,%item); 
%armor = Player::getArmor(%player); 
%client = Player::getClient(%player); 
if (%armor == "dmarmor" || %armor == "dmfemale") 
%obj = newObject("","Mine","DMMine"); 
else 
{ 
%obj = newObject("","Mine","antipersonelMine"); 
GameBase::setTeam (%obj,GameBase::getTeam (%client)); 
} 
addToSet("MissionCleanup", %obj); 
GameBase::throw(%obj,%player,15 * %client.throwStrength,false); 
%player.throwTime = getSimTime() + 0.5; 
} 
} 
} 








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::  ARMOR  GRENADES  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemData Grenade 
{ 
description = "Grenade"; 
shapeFile = "grenade"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 5; 
className = "HandAmmo"; 
}; 

function Grenade::onUse(%player,%item) 
{ 
if($matchStarted) 
{ 
if(%player.throwTime < getSimTime() ) 
{ 
Player::decItemCount(%player,%item); 
%armor = Player::getArmor(%player); 
if (%armor == "larmor" || %armor == "lfemale") 
%obj = newObject("","Mine","HoloMine"); 
if(%armor == "earmor" || %armor == "efemale") 
%obj = newObject("","Mine","Shockgrenade"); 
if (%armor == "sarmor" || %armor == "sfemale") 
%obj = newObject("","Mine","Firebomb"); 
if (%armor == "spyarmor" || %armor == "spyfemale") 
{ 
Client::sendMessage(Player::getClient(%player),1, "Plastique Explosive will explode in 15 seconds"); 
%obj = newObject("","Mine","Nukebomb"); 
} 
if (%armor == "marmor" || %armor == "mfemale") 
%obj = newObject("","Mine","Handgrenade"); 
if (%armor == "aarmor" || %armor == "afemale") 
%obj = newObject("","Mine","Tranqgrenade"); 
if (%armor == "harmor") 
%obj = newObject("","Mine","Nukebomb"); 
if (%armor == "barmor" || %armor == "bfemale") 
%obj = newObject("","Mine","Suicidebomb2"); 
if (%armor == "darmor") 
%obj = newObject("","Mine","Mortarbomb"); 
if (%armor == "dmarmor" || %armor == "dmfemale") 
{ 
%clientId = Player::getClient(%player); 
if($modeTime[%clientId] == 1) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Plastique Explosive will explode in 15 seconds"); 
%obj = newObject("","Mine","Nukebomb"); 
} 
else 
if($modeTime[%clientId] == 2) 
{ 
%obj = newObject("","Mine","Concussion"); 
} 
else 
if($modeTime[%clientId] == 3) 
{ 
%obj = newObject("","Mine","Shockgrenade"); 
} 
else 
if($modeTime[%clientId] == 4) 
{ 
%obj = newObject("","Mine","Tranqgrenade"); 
} 
else 
if($modeTime[%clientId] == 5) 
{ 
%obj = newObject("","Mine","Mortarbomb"); 
} 
else 
if($modeTime[%clientId] == 6) 
{ 
%obj = newObject("","Mine","Firebomb"); 
} 
else 
%obj = newObject("","Mine","Handgrenade"); 
} 
addToSet("MissionCleanup", %obj); 
%client = Player::getClient(%player); 
GameBase::throw(%obj,%player,15 * %client.throwStrength,false); 
%player.throwTime = getSimTime() + 0.5; 
GameBase::setTeam (%obj,GameBase::getTeam (%client));
} 
} 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  ARMOR  BEACON  ::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemData Beacon 
{ 
description = "Beacon"; 
shapeFile = "sensor_small"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 5; 
className = "HandAmmo"; 
}; 

function Beacon::onUse(%player,%item) 
{ 
%armor = Player::getArmor(%player); %clientId = Player::getClient(%player); 
if (%armor == "larmor" || %armor == "lfemale") 
{ 
SniperJammer(%clientId, %player, %item); 
} 
if(%armor == "earmor" || %armor == "efemale") 
DeployableInvPack(%clientId, %player, %item); 

if (%armor == "sarmor" || %armor == "sfemale") 
{ 
ScoutSensor(%clientId, %player, %item); 
} 
if (%armor == "spyarmor" || %armor == "spyfemale") 
{ 
DeploySatchel(%clientId, %player, %item); 
} 
if (%armor == "marmor" || %armor == "mfemale") 
{ 
if($matchStarted) 
{ 
if(%player.throwTime < getSimTime() ) 
{ 
%obj = newObject("","Mine","Booster"); 
addToSet("MissionCleanup", %obj); 
%client = Player::getClient(%player); 
GameBase::throw(%obj,%player,15 * %client.throwStrength,false); 
%player.throwTime = getSimTime() + 0.5; 
Client::sendMessage(Player::getClient(%player),0, "You use a Speed Booster."); 
Player::decItemCount(%player,%item); 
} 
} 
} 
if (%armor == "aarmor" || %armor == "afemale") 
{ 
Renegades_startCloak(%clientId, %player); 
Player::decItemCount(%player,%item); 
} 
if 
(%armor == "harmor") %obj = newObject("","Mine","Nukebomb"); 
if (%armor == "barmor" || %armor == "bfemale") 
{ 
Renegades_startStim(%clientId, %player); 
Player::decItemCount(%player,%item); 
} 
if (%armor == "darmor")
{ 
Renegades_startShield(%clientId, %player); 
Player::decItemCount(%player,%item); 
}
} 







function Renegades_startStim(%clientId, %player) 
{ 
Client::sendMessage(%clientId,0,"Run Forrest Run!!"); 
%this = "RepairPatch"; 
Item::playPickupSound(%this); 
%armor = Player::getArmor(%player); 
%armor.maxForwardSpeed = %armor.maxForwardSpeed + 25;
%armor.maxBackwardSpeed = %armor.maxBackwardSpeed + 25;
Player::setDamageFlash(%player,1.0); 
GameBase::applyDamage(%player,$LandingDamageType,0.020,GameBase::getPosition(%player),"0 0 0","0 0 0",%player); 
if($stimTime[%clientId] == 0) 
{ 
$stimTime[%clientId] = 20; 
checkPlayerStim(%clientId, %player); 
} 
else $StimTime[%clientId] = 20; 
} 



function checkPlayerStim(%clientId, %player) 
{ 
if($StimTime[%clientId] > 0) 
{ 
$StimTime[%clientId] -= 2; 
if (!Player::isDead(%player)) 
{ } 
else 
{ 
$StimTime[%clientId] = 0; 
%armor.maxForwardSpeed = 9;
%armor.maxBackwardSpeed = 9;

} 
schedule("checkPlayerStim(" @ %clientId @ ", " @ %player @ ");",2,%player); 
} 
else 
{ 
Client::sendMessage(%clientId,0,"......and so I just kept on running"); 
%armor = Player::getArmor(%player); 
%armor.maxForwardSpeed = 10;
%armor.maxBackwardSpeed = 10;
} 
} 




function Renegades_startShield(%clientId, %player) 
{ 
Client::sendMessage(%clientId,0,"Emergency Force Shields Activated"); GameBase::playSound(%player,ForceFieldOpen,0); 
%player.shieldStrength = 0.006; 
if($shieldTime[%clientId] == 0) 
{ 
$shieldTime[%clientId] = 20; 
checkPlayerShield(%clientId, %player); 
} 
else 
$shieldTime[%clientId] = 20; 
} 





function checkPlayerShield(%clientId, %player) 
{ 
%armor = Player::getArmor(%player); 
if($shieldTime[%clientId] > 0) 
{ 
$shieldTime[%clientId] -= 2; 
if ((!Player::isDead(%player)) && (%armor == "darmor" || %armor == "dfemale")) 
{ 
if (Player::isDead(%player)) 
{ } 
} 
else 
{ 
$shieldTime[%clientId] = 0; 
} 
schedule("checkPlayerShield(" @ %clientId @ ", " @ %player @ ");",2,%player); 
} 
else 
{ 
Client::sendMessage(%clientId,0,"Emergency Force Shields Exausted"); 
%player.shieldStrength = 0; 
GameBase::playSound(%player,ForceFieldOpen,0); 
} 
} 





function Renegades_startCloak(%clientId, %player) 
{ 
%armor = Player::getArmor(%player); 
Client::sendMessage(%clientId,0,"Cloaking On"); 
GameBase::playSound(%player,ForceFieldOpen,0); 
GameBase::startFadeout(%player); 
%rate = Player::getSensorSupression(%player) + 3; Player::setSensorSupression(%player,%rate); 
if($cloakTime[%clientId] == 0) 
{ 
$cloakTime[%clientId] = 30; 
checkPlayerCloak(%clientId, %player); 
} 
else 
$cloakTime[%clientId] = 30; 
} 




function checkPlayerCloak(%clientId, %player) 
{ 
%armor = Player::getArmor(%player); 
if($cloakTime[%clientId] > 0) 
{ 
$cloakTime[%clientId] -= 2; 
if ( (!Player::isDead(%player)) && (%armor == "aarmor" || %armor == "afemale") ) 
{ } 
else 
{ 
$cloakTime[%clientId] = 0; 
} 
schedule("checkPlayerCloak(" @ %clientId @ ", " @ %player @ ");",2,%player); 
} 
else 
{ 
Client::sendMessage(%clientId,0,"Cloaking Off"); 
GameBase::playSound(%player,ForceFieldOpen,0); 
GameBase::startFadein(%player); 
%rate = Player::getSensorSupression(%player) - 5; Player::setSensorSupression(%player,0); 
} 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::  SATCHEL  CHARGE  :::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function DeploySatchel( %clientId, %player, %bec) 
{ 
%item = "SatchelPack"; 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = getObjectType($los::object); 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) { %rot = "3.14159 0 " @ %zRot; 
} 
else { %rot = Vector::getRotation($los::normal); 
} 
} 

%camera = newObject("Camera","Turret",DeployableSatchel,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"Satchel Charge#"@ $totalNumCameras++ @ " " @ Client::getName(%client)); 
Client::sendMessage(%client,0,"Satchel Charge#"@ $totalNumCameras @ " deployed. Set it off from within the Commander Screen."); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "SatchelPack"]++; 
echo("MSG: ",%client," deployed a Satchel Charge."); Player::decItemCount(%player,%bec); 
return true; 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for Satchel Charges"); 
return false; 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::  DEPLOYABLE  INVENTORY  PACK  :::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function DeployableInvPack( %clientId, %player, %bec) 
{ 
%item = "DeployableInvPack"; 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain" ; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
if (Vector::dot($los::normal,"0 0 1") > 0.7)  
{ 
%inv = newObject("ammounit_remote","StaticShape","DeployableInvStation",true); 
addToSet("MissionCleanup", %inv); 
%rot = GameBase::getRotation(%player); 
GameBase::setTeam(%inv,GameBase::getTeam(%player)); 
GameBase::setPosition(%inv,$los::position); 
GameBase::setRotation(%inv,%rot); 
Gamebase::setMapName(%inv,%name); 
Client::sendMessage(%client,0,"Inventory Station deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%inv) @ "DeployableInvPack"]++; 
echo("MSG: ",%client," deployed an Inventory Station");
//Player::decItemCount(%player,%bec);  
return true;  
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on flat surfaces"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); return false; 
} 






//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  ENGINEER  CAMERA  ::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function EngCamera(%clientId, %player, %bec) 
{ 
%item = "CameraPack"; 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain"; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) { %rot = "3.14159 0 " @ %zRot; 
} 
else { %rot = Vector::getRotation($los::normal); 
} 
} 
if(checkDeployArea(%client,$los::position)) 
{ 
%camera = newObject("Camera","Turret",CameraTurret,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); 
GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"Camera#"@ $totalNumCameras++ @ " " @ Client::getName(%client)); 
Client::sendMessage(%client,0,"Camera deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "CameraPack"]++; 
echo("MSG: ",%client," deployed a Camera"); 
Player::decItemCount(%player,%bec); return true; 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else 
Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 







//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  SNIPERS  SENSOR  JAMMER  :::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function SniperJammer(%clientId, %player, %bec) 
{ 
%item = "DeployableSensorJammerPack"; 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain"; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} 
else 
{ 
%rot = Vector::getRotation($los::normal); 
} 
} 
if(checkDeployArea(%client,$los::position)) 
{ 
%camera = newObject("sensor_jammer","Sensor",DeployableSensorJammer,true); 
addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"SensorJammer"); 
Client::sendMessage(%client,0,"SensorJammer deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "DeployableSensorJammerPack"]++; 
echo("MSG: ",%client," deployed a Sensor Jammer"); 
Player::decItemCount(%player,%bec); 
return true; 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  SCOUTS  PULSE  SENSOR  ::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function ScoutSensor(%clientId, %player, %bec) 
{ 
%item = "PulseSensorPack"; 
%client = Player::getClient(%player); 
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
{ 
if (GameBase::getLOSInfo(%player,10000)) 
{ 
%obj = "SimTerrain"; 
if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") 
{ 
%prot = GameBase::getRotation(%player); 
%zRot = getWord(%prot,2); 
if (Vector::dot($los::normal,"0 0 1") > 0.6) 
{ 
%rot = "0 0 " @ %zRot; 
} 
else 
{ 
if (Vector::dot($los::normal,"0 0 -1") > 0.6) 
{ 
%rot = "3.14159 0 " @ %zRot; 
} 
else 
{ 
%rot = Vector::getRotation($los::normal); 
} 
} 
if(checkDeployArea(%client,$los::position)) 
{ 
%camera = newObject("radar_small","Sensor",DeployablePulseSensor,true); addToSet("MissionCleanup", %camera); 
GameBase::setTeam(%camera,GameBase::getTeam(%player)); GameBase::setRotation(%camera,%rot); 
GameBase::setPosition(%camera,$los::position); 
Gamebase::setMapName(%camera,"Pulse Sensor"); 
Client::sendMessage(%client,0,"Pulse Sensor deployed"); 
playSound(SoundPickupBackpack,$los::position); 
$TeamItemCount[GameBase::getTeam(%camera) @ "PulseSensorPack"]++; 
echo("MSG: ",%client," deployed a Pulse Sensor"); 
Player::decItemCount(%player,%bec); 
return true; 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Can only deploy on terrain or buildings"); 
} 
} 
else 
{ 
Client::sendMessage(%client,0,"Deploy position out of range"); 
} 
} 
else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s"); 
return false; 
} 








//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::  MERCENARRY  SPEED  BOOST  ::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


ItemData Boost 
{ 
description = "Bot"; 
shapeFile = "sensor_small"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 5; 
className = "HandAmmo"; 
}; 

function Boost::onUse(%player,%item) 
{ 
%client = Player::getClient(%player); 
Training::setupAI(%client); 
} 

ItemData Plastique 
{ 
description = "Grenade Mode"; 
shapeFile = "sensor_small"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 5; 
className = "HandAmmo"; 
}; 

function Plastique::onUse(%player,%item) 
{ 
if($matchStarted) 
{ 
if(%player.throwTime < getSimTime() ) 
{ 
%player.throwTime = getSimTime() + 0.5; 
%clientId = Player::getClient(%player); 

if( ($modeTime[%clientId] != 1) && ($modeTime[%clientId] != 2) && ($modeTime[%clientId] != 3) && ($modeTime[%clientId] != 4) && ($modeTime[%clientId] != 5) && ($modeTime[%clientId] != 6) ) { 
$modeTime[%clientId] = 0; 
} 
if($modeTime[%clientId] == 0) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Normal"); 
$modeTime[%clientId] = 1; 
} 
if($modeTime[%clientId] == 1) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Fire"); 
$modeTime[%clientId] = 2; 
} 
else 
if($modeTime[%clientId] == 2) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Shock"); 
$modeTime[%clientId] = 3; 
} 
else 
if($modeTime[%clientId] == 3) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Poison"); 
$modeTime[%clientId] = 4; 
} 
else 
if($modeTime[%clientId] == 4) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Mortar"); 
$modeTime[%clientId] = 5; 
} 
else 
if($modeTime[%clientId] == 5) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Concussion"); 
$modeTime[%clientId] = 6; 
} 
else 
if($modeTime[%clientId] == 6) 
{ 
Client::sendMessage(Player::getClient(%player),1, "Grenade Type: Plastique Explosives"); $modeTime[%clientId] = 1; 
} 
} 
} 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::  REPAIR  PATCH  ::::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



ItemData RepairPatch 
{ 
description = "Repair Patch"; 
className = "Repair"; 
shapeFile = "armorPatch"; 
heading = "dArmor Items"; 
shadowDetailMask = 4; 
price = 2; 
}; 

function RepairPatch::onCollision(%this,%object) 
{ 
if (getObjectType(%object) == "Player") 
{ 
if(GameBase::getDamageLevel(%object)) 
{ 
GameBase::repairDamage(%object,0.125); 
%c = Player::getClient(%object); 
$poisonTime[%c] = 0; 
%item = Item::getItemData(%this); 
Item::playPickupSound(%this); 
Item::respawn(%this); 
} 
} 
} 

function RepairPatch::onUse(%player,%item) 
{ 
Player::decItemCount(%player,%item); 
GameBase::repairDamage(%player,0.1); 
} 





//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::  REMOTE  GIVE  ALL  :::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



function remoteGiveAll(%clientId) 
{ 
if ($TestCheats) 
{ 
Player::setItemCount(%clientId,Blaster,1); 
Player::setItemCount(%clientId,Chaingun,1); 
Player::setItemCount(%clientId,PlasmaGun,1); 
Player::setItemCount(%clientId,GrenadeLauncher,1); 
Player::setItemCount(%clientId,DiscLauncher,1); 
Player::setItemCount(%clientId,LaserRifle,1); 
Player::setItemCount(%clientId,EnergyRifle,1); 
Player::setItemCount(%clientId,TargetingLaser,1); 
Player::setItemCount(%clientId,Mortar,1); 
Player::setItemCount(%clientId,BulletAmmo,200); 
Player::setItemCount(%clientId,PlasmaAmmo,200); 
Player::setItemCount(%clientId,GrenadeAmmo,200); 
Player::setItemCount(%clientId,DiscAmmo,200); 
Player::setItemCount(%clientId,MortarAmmo,200); 
Player::setItemCount(%clientId,Grenade, 200); 
Player::setItemCount(%clientId,MineAmmo, 200); 
Player::setItemCount(%clientId,Beacon, 200); 
Player::setItemCount(%clientId,RepairKit,200); 
} 
else 
if($ServerCheats) 
{ 
%armor = Player::getArmor(%clientId); 
Player::setItemCount(%clientId,BulletAmmo,$ItemMax[%armor, BulletAmmo]); 
Player::setItemCount(%clientId,PlasmaAmmo,$ItemMax[%armor, PlasmaAmmo]); 
Player::setItemCount(%clientId,GrenadeAmmo,$ItemMax[%armor, GrenadeAmmo]); 
Player::setItemCount(%clientId,DiscAmmo,$ItemMax[%armor, DiscAmmo]); 
Player::setItemCount(%clientId,MortarAmmo,$ItemMax[%armor, MortarAmmo]); 
Player::setItemCount(%clientId,Grenade, $ItemMax[%armor, Grenade]); Player::setItemCount(%clientId,MineAmmo,$ItemMax[%armor, MineAmmo]); Player::setItemCount(%clientId,Beacon,$ItemMax[%armor, Beacon]); Player::setItemCount(%clientId,RepairKit,1); 
} 
} 

//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::::  CHECK  MAX  :::::::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function checkMax(%client,%armor) 
{ 
%weaponflag = 0; 
%numweapon = Player::getItemClassCount(%client,"Weapon"); 
if (%numweapon > $MaxWeapons[%armor]) 
{ 
%weaponflag = %numweapon - $MaxWeapons[%armor]; 
} 
%max = getNumItems(); 
for (%i = 0; %i < %max; %i = %i + 1) 
{ 
%item = getItemData(%i); 
%maxnum = $ItemMax[%armor, %item]; 
if(%maxnum != "") 
{ 
%numsell = 0; 
%count = Player::getItemCount(%client,%item); 
if(%count > %maxnum) 
{ 
%numsell = %count - %maxnum; 
} 
if (%count > 0 && %weaponflag && %item.className == Weapon) 
{ 
%numsell = 1; 
%weaponflag = %weaponflag - 1; 
} 
if(%numsell > 0) 
{ 
Client::sendMessage(%client,0,"SOLD " @ %numsell @ " " @ %item); teamEnergyBuySell(Client::getOwnedObject(%client),(%item.price * %numsell)); 
Player::setItemCount(%client, %item, %count - %numsell); updateBuyingList(%client); 
} 
} 
} 
} 




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//:::::::::::::::::::::::::::::::::  CHECK  PLAYER  CASH  :::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}


function checkPlayerCash(%client) 
{ 
%team = Client::getTeam(%client); 
if($TeamEnergy[%team] != "Infinite") 
{ 
if(%client.teamEnergy > ($InitialPlayerEnergy * -1) ) 
{ 
if(%client.teamEnergy >= 0) 
%diff = $InitialPlayerEnergy; 
else 
%diff = $InitialPlayerEnergy + %client.teamEnergy; 
$TeamEnergy[%team] -= %diff; 
} 
} 
} 



//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
//::::::::::::::::::::::::::::::::  REINITIATE  DATA  :::::::::::::::::::::::::::::::::::
//}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



function Mission::reinitData() 
{
$TeamItemCount[0 @ ArbitorBoxPack] = 0;
$TeamItemCount[1 @ ArbitorBoxPack] = 0;
$TeamItemCount[2 @ ArbitorBoxPack] = 0;
$TeamItemCount[3 @ ArbitorBoxPack] = 0;
$TeamItemCount[4 @ ArbitorBoxPack] = 0;
$TeamItemCount[5 @ ArbitorBoxPack] = 0;
$TeamItemCount[6 @ ArbitorBoxPack] = 0;
$TeamItemCount[7 @ ArbitorBoxPack] = 0; 


$TeamItemCount[0 @ DeployableInvPack] = 0; 
$TeamItemCount[1 @ DeployableInvPack] = 0; 
$TeamItemCount[2 @ DeployableInvPack] = 0; 
$TeamItemCount[3 @ DeployableInvPack] = 0; 
$TeamItemCount[4 @ DeployableInvPack] = 0;
$TeamItemCount[5 @ DeployableInvPack] = 0; 
$TeamItemCount[6 @ DeployableInvPack] = 0; 
$TeamItemCount[7 @ DeployableInvPack] = 0; 



$TeamItemCount[0 @ DeployablevhclPack] = 0; 
$TeamItemCount[1 @ DeployablevhclPack] = 0; 
$TeamItemCount[2 @ DeployablevhclPack] = 0; 
$TeamItemCount[3 @ DeployablevhclPack] = 0; 
$TeamItemCount[4 @ DeployablevhclPack] = 0;
$TeamItemCount[5 @ DeployablevhclPack] = 0; 
$TeamItemCount[6 @ DeployablevhclPack] = 0; 
$TeamItemCount[7 @ DeployablevhclPack] = 0; 


$TeamItemCount[0 @ DeployableAmmoPack] = 0; 
$TeamItemCount[1 @ DeployableAmmoPack] = 0; 
$TeamItemCount[2 @ DeployableAmmoPack] = 0; 
$TeamItemCount[3 @ DeployableAmmoPack] = 0; 
$TeamItemCount[4 @ DeployableAmmoPack] = 0;
$TeamItemCount[5 @ DeployableAmmoPack] = 0; 
$TeamItemCount[6 @ DeployableAmmoPack] = 0; 
$TeamItemCount[7 @ DeployableAmmoPack] = 0; 



$TeamItemCount[0 @ DeployableComPack] = 0; 
$TeamItemCount[1 @ DeployableComPack] = 0; 
$TeamItemCount[2 @ DeployableComPack] = 0; 
$TeamItemCount[3 @ DeployableComPack] = 0; 
$TeamItemCount[4 @ DeployableComPack] = 0; 
$TeamItemCount[5 @ DeployableComPack] = 0; 
$TeamItemCount[6 @ DeployableComPack] = 0; 
$TeamItemCount[7 @ DeployableComPack] = 0; 




$TeamItemCount[0 @ TurretPack] = 0; 
$TeamItemCount[1 @ TurretPack] = 0;
$TeamItemCount[2 @ TurretPack] = 0; 
$TeamItemCount[3 @ TurretPack] = 0; 
$TeamItemCount[4 @ TurretPack] = 0;
$TeamItemCount[5 @ TurretPack] = 0; 
$TeamItemCount[6 @ TurretPack] = 0; 
$TeamItemCount[7 @ TurretPack] = 0; 

$TeamItemCount[0 @ CameraPack] = 0; 
$TeamItemCount[1 @ CameraPack] = 0; 
$TeamItemCount[2 @ CameraPack] = 0; 
$TeamItemCount[3 @ CameraPack] = 0; 
$TeamItemCount[4 @ CameraPack] = 0;
$TeamItemCount[5 @ CameraPack] = 0; 
$TeamItemCount[6 @ CameraPack] = 0; 
$TeamItemCount[7 @ CameraPack] = 0; 

$TeamItemCount[0 @ DeployableSensorJammerPack] = 0; 
$TeamItemCount[1 @ DeployableSensorJammerPack] = 0; 
$TeamItemCount[2 @ DeployableSensorJammerPack] = 0; 
$TeamItemCount[3 @ DeployableSensorJammerPack]= 0; 
$TeamItemCount[4 @ DeployableSensorJammerPack]= 0;
$TeamItemCount[5 @ DeployableSensorJammerPack]= 0; 
$TeamItemCount[6 @ DeployableSensorJammerPack]= 0; 
$TeamItemCount[7 @ DeployableSensorJammerPack]= 0; 

$TeamItemCount[0 @ PulseSensorPack] = 0; 
$TeamItemCount[1 @ PulseSensorPack] = 0; 
$TeamItemCount[2 @ PulseSensorPack] = 0; 
$TeamItemCount[3 @ PulseSensorPack] = 0; 
$TeamItemCount[4 @ PulseSensorPack] = 0;
$TeamItemCount[5 @ PulseSensorPack] = 0; 
$TeamItemCount[6 @ PulseSensorPack] = 0; 
$TeamItemCount[7 @ PulseSensorPack] = 0; 

$TeamItemCount[0 @ MotionSensorPack] = 0; 
$TeamItemCount[1 @ MotionSensorPack] = 0; 
$TeamItemCount[2 @ MotionSensorPack] = 0; 
$TeamItemCount[3 @ MotionSensorPack] = 0; 
$TeamItemCount[4 @ MotionSensorPack] = 0;
$TeamItemCount[5 @ MotionSensorPack] = 0; 
$TeamItemCount[6 @ MotionSensorPack] = 0; 
$TeamItemCount[7 @ MotionSensorPack] = 0; 



$TeamItemCount[0 @ Beacon] = 0; 
$TeamItemCount[1 @ Beacon] = 0; 
$TeamItemCount[2 @ Beacon] = 0; 
$TeamItemCount[3 @ Beacon] = 0; 
$TeamItemCount[4 @ Beacon] = 0;
$TeamItemCount[5 @ Beacon] = 0; 
$TeamItemCount[6 @ Beacon] = 0; 
$TeamItemCount[7 @ Beacon] = 0; 

$TeamItemCount[0 @ mineammo] = 0; 
$TeamItemCount[1 @ mineammo] = 0; 
$TeamItemCount[2 @ mineammo] = 0; 
$TeamItemCount[3 @ mineammo] = 0; 
$TeamItemCount[4 @ mineammo] = 0;
$TeamItemCount[5 @ mineammo] = 0; 
$TeamItemCount[6 @ mineammo] = 0; 
$TeamItemCount[7 @ mineammo] = 0; 




$TeamItemCount[0 @ ScoutVehicle] = 0; 
$TeamItemCount[1 @ ScoutVehicle] = 0; 
$TeamItemCount[2 @ ScoutVehicle] = 0; 
$TeamItemCount[3 @ ScoutVehicle] = 0; 
$TeamItemCount[4 @ ScoutVehicle] = 0;
$TeamItemCount[5 @ ScoutVehicle] = 0; 
$TeamItemCount[6 @ ScoutVehicle] = 0; 
$TeamItemCount[7 @ ScoutVehicle] = 0; 

$TeamItemCount[0 @ WraithVehicle] = 0; 
$TeamItemCount[1 @ WraithVehicle] = 0; 
$TeamItemCount[2 @ WraithVehicle] = 0; 
$TeamItemCount[3 @ WraithVehicle] = 0; 
$TeamItemCount[4 @ WraithVehicle] = 0; 
$TeamItemCount[5 @ WraithVehicle] = 0; 
$TeamItemCount[6 @ WraithVehicle] = 0; 
$TeamItemCount[7 @ WraithVehicle] = 0; 

$TeamItemCount[0 @ JetVehicle] = 0; 
$TeamItemCount[1 @ JetVehicle] = 0; 
$TeamItemCount[2 @ JetVehicle] = 0; 
$TeamItemCount[3 @ JetVehicle] = 0; 
$TeamItemCount[4 @ JetVehicle] = 0; 
$TeamItemCount[5 @ JetVehicle] = 0; 
$TeamItemCount[6 @ JetVehicle] = 0; 
$TeamItemCount[7 @ JetVehicle] = 0; 

$TeamItemCount[0 @ LAPCVehicle] = 0; 
$TeamItemCount[1 @ LAPCVehicle] = 0; 
$TeamItemCount[2 @ LAPCVehicle] = 0; 
$TeamItemCount[3 @ LAPCVehicle] = 0; 
$TeamItemCount[4 @ LAPCVehicle] = 0;
$TeamItemCount[5 @ LAPCVehicle] = 0; 
$TeamItemCount[6 @ LAPCVehicle] = 0; 
$TeamItemCount[7 @ LAPCVehicle] = 0; 

$TeamItemCount[0 @ HAPCVehicle] = 0; 
$TeamItemCount[1 @ HAPCVehicle] = 0; 
$TeamItemCount[2 @ HAPCVehicle] = 0; 
$TeamItemCount[3 @ HAPCVehicle] = 0; 
$TeamItemCount[4 @ HAPCVehicle] = 0;
$TeamItemCount[5 @ HAPCVehicle] = 0; 
$TeamItemCount[6 @ HAPCVehicle] = 0; 
$TeamItemCount[7 @ HAPCVehicle] = 0; 




$TeamItemCount[0 @ RocketPack] = 0; 
$TeamItemCount[1 @ RocketPack] = 0; 
$TeamItemCount[2 @ RocketPack] = 0; 
$TeamItemCount[3 @ RocketPack] = 0; 
$TeamItemCount[4 @ RocketPack] = 0; 
$TeamItemCount[5 @ RocketPack] = 0; 
$TeamItemCount[6 @ RocketPack] = 0; 
$TeamItemCount[7 @ RocketPack] = 0; 


$TeamItemCount[0 @ LaserPack] = 0; 
$TeamItemCount[1 @ LaserPack] = 0; 
$TeamItemCount[2 @ LaserPack] = 0; 
$TeamItemCount[3 @ LaserPack] = 0; 
$TeamItemCount[4 @ LaserPack] = 0; 
$TeamItemCount[5 @ LaserPack] = 0; 
$TeamItemCount[6 @ LaserPack] = 0; 
$TeamItemCount[7 @ LaserPack] = 0; 


$TeamItemCount[0 @ LaserTurret] = 0; 
$TeamItemCount[1 @ LaserTurret] = 0; 
$TeamItemCount[2 @ LaserTurret] = 0; 
$TeamItemCount[3 @ LaserTurret] = 0; 
$TeamItemCount[4 @ LaserTurret] = 0; 
$TeamItemCount[5 @ LaserTurret] = 0; 
$TeamItemCount[6 @ LaserTurret] = 0; 
$TeamItemCount[7 @ LaserTurret] = 0; 

$TeamItemCount[0 @ DeployableTeleport] = 0; 
$TeamItemCount[1 @ DeployableTeleport] = 0; 
$TeamItemCount[2 @ DeployableTeleport] = 0; 
$TeamItemCount[3 @ DeployableTeleport] = 0; 
$TeamItemCount[4 @ DeployableTeleport] = 0;
$TeamItemCount[5 @ DeployableTeleport] = 0; 
$TeamItemCount[6 @ DeployableTeleport] = 0; 
$TeamItemCount[7 @ DeployableTeleport] = 0; 



$TeamItemCount[0 @ ShockPack] = 0; 
$TeamItemCount[1 @ ShockPack] = 0; 
$TeamItemCount[2 @ ShockPack] = 0; 
$TeamItemCount[3 @ ShockPack] = 0; 
$TeamItemCount[4 @ ShockPack] = 0; 
$TeamItemCount[5 @ ShockPack] = 0; 
$TeamItemCount[6 @ ShockPack] = 0; 
$TeamItemCount[7 @ ShockPack] = 0; 


$TeamItemCount[0 @ ForceFieldPack] = 0; 
$TeamItemCount[1 @ ForceFieldPack] = 0; 
$TeamItemCount[2 @ ForceFieldPack] = 0; 
$TeamItemCount[3 @ ForceFieldPack] = 0; 
$TeamItemCount[4 @ ForceFieldPack] = 0; 
$TeamItemCount[5 @ ForceFieldPack] = 0; 
$TeamItemCount[6 @ ForceFieldPack] = 0; 
$TeamItemCount[7 @ ForceFieldPack] = 0; 

$TeamItemCount[0 @ LargeForceFieldPack] = 0; 
$TeamItemCount[1 @ LargeForceFieldPack] = 0; 
$TeamItemCount[2 @ LargeForceFieldPack] = 0; 
$TeamItemCount[3 @ LargeForceFieldPack] = 0; 
$TeamItemCount[4 @ LargeForceFieldPack] = 0; 
$TeamItemCount[5 @ LargeForceFieldPack] = 0; 
$TeamItemCount[6 @ LargeForceFieldPack] = 0; 
$TeamItemCount[7 @ LargeForceFieldPack] = 0; 


$TeamItemCount[0 @ TripwirePack] = 0; 
$TeamItemCount[1 @ TripwirePack] = 0; 
$TeamItemCount[2 @ TripwirePack] = 0; 
$TeamItemCount[3 @ TripwirePack] = 0; 
$TeamItemCount[4 @ TripwirePack] = 0; 
$TeamItemCount[5 @ TripwirePack] = 0; 
$TeamItemCount[6 @ TripwirePack] = 0; 
$TeamItemCount[7 @ TripwirePack] = 0; 




$TeamItemCount[0 @ PlatformPack] = 0; 
$TeamItemCount[1 @ PlatformPack] = 0; 
$TeamItemCount[2 @ PlatformPack] = 0; 
$TeamItemCount[3 @ PlatformPack] = 0; 
$TeamItemCount[4 @ PlatformPack] = 0; 
$TeamItemCount[5 @ PlatformPack] = 0; 
$TeamItemCount[6 @ PlatformPack] = 0; 
$TeamItemCount[7 @ PlatformPack] = 0; 

$TeamItemCount[0 @ TreePack] = 0; 
$TeamItemCount[1 @ TreePack] = 0; 
$TeamItemCount[2 @ TreePack] = 0; 
$TeamItemCount[3 @ TreePack] = 0; 
$TeamItemCount[4 @ TreePack] = 0; 
$TeamItemCount[5 @ TreePack] = 0; 
$TeamItemCount[6 @ TreePack] = 0; 
$TeamItemCount[7 @ TreePack] = 0; 


$TeamItemCount[0 @ TargetPack] = 0; 
$TeamItemCount[1 @ TargetPack] = 0; 
$TeamItemCount[2 @ TargetPack] = 0; 
$TeamItemCount[3 @ TargetPack] = 0; 
$TeamItemCount[4 @ TargetPack] = 0; 
$TeamItemCount[5 @ TargetPack] = 0; 
$TeamItemCount[6 @ TargetPack] = 0; 
$TeamItemCount[7 @ TargetPack] = 0; 

$TeamItemCount[0 @ SpringPack] = 0; 
$TeamItemCount[1 @ SpringPack] = 0; 
$TeamItemCount[2 @ SpringPack] = 0; 
$TeamItemCount[3 @ SpringPack] = 0; 
$TeamItemCount[4 @ SpringPack] = 0; 
$TeamItemCount[5 @ SpringPack] = 0; 
$TeamItemCount[6 @ SpringPack] = 0; 
$TeamItemCount[7 @ SpringPack] = 0; 

$TeamItemCount[0 @ hologram] = 0; 
$TeamItemCount[1 @ hologram] = 0; 
$TeamItemCount[2 @ hologram] = 0; 
$TeamItemCount[3 @ hologram] = 0; 
$TeamItemCount[4 @ hologram] = 0; 
$TeamItemCount[5 @ hologram] = 0; 
$TeamItemCount[6 @ hologram] = 0; 
$TeamItemCount[7 @ hologram] = 0; 

$TeamItemCount[0 @ SatchelPack] = 0; 
$TeamItemCount[1 @ SatchelPack] = 0; 
$TeamItemCount[2 @ SatchelPack] = 0; 
$TeamItemCount[3 @ SatchelPack] = 0; 
$TeamItemCount[4 @ SatchelPack] = 0; 
$TeamItemCount[5 @ SatchelPack] = 0; 
$TeamItemCount[6 @ SatchelPack] = 0; 
$TeamItemCount[7 @ SatchelPack] = 0; 

$TeamItemCount[0 @ BigInvPack] = 0; 
$TeamItemCount[1 @ BigInvPack] = 0; 
$TeamItemCount[2 @ BigInvPack] = 0; 
$TeamItemCount[3 @ BigInvPack] = 0; 
$TeamItemCount[4 @ BigInvPack] = 0; 
$TeamItemCount[5 @ BigInvPack] = 0; 
$TeamItemCount[6 @ BigInvPack] = 0; 
$TeamItemCount[7 @ BigInvPack] = 0; 

$TeamItemCount[0 @ RailTurret] = 0; 
$TeamItemCount[1 @ RailTurret] = 0; 
$TeamItemCount[2 @ RailTurret] = 0; 
$TeamItemCount[3 @ RailTurret] = 0; 
$TeamItemCount[4 @ RailTurret] = 0; 
$TeamItemCount[5 @ RailTurret] = 0; 
$TeamItemCount[6 @ RailTurret] = 0; 
$TeamItemCount[7 @ RailTurret] = 0; 

$TeamItemCount[0 @ VulcanTurret] = 0; 
$TeamItemCount[1 @ VulcanTurret] = 0; 
$TeamItemCount[2 @ VulcanTurret] = 0; 
$TeamItemCount[3 @ VulcanTurret] = 0; 
$TeamItemCount[4 @ VulcanTurret] = 0; 
$TeamItemCount[5 @ VulcanTurret] = 0; 
$TeamItemCount[6 @ VulcanTurret] = 0; 
$TeamItemCount[7 @ VulcanTurret] = 0;



$TeamItemCount[0 @ LrgPltPack] = 0; 
$TeamItemCount[1 @ LrgPltPack] = 0; 
$TeamItemCount[2 @ LrgPltPack] = 0; 
$TeamItemCount[3 @ LrgPltPack] = 0; 
$TeamItemCount[4 @ LrgPltPack] = 0; 
$TeamItemCount[5 @ LrgPltPack] = 0; 
$TeamItemCount[6 @ LrgPltPack] = 0; 
$TeamItemCount[7 @ LrgPltPack] = 0;



$TeamItemCount[0 @ jailpack] = 0; 
$TeamItemCount[1 @ jailpack] = 0; 
$TeamItemCount[2 @ jailpack] = 0; 
$TeamItemCount[3 @ jailpack] = 0; 
$TeamItemCount[4 @ jailpack] = 0; 
$TeamItemCount[5 @ jailpack] = 0; 
$TeamItemCount[6 @ jailpack] = 0; 
$TeamItemCount[7 @ jailpack] = 0;





$TeamItemCount[0 @ JailCapPack] = 0; 
$TeamItemCount[1 @ JailCapPack] = 0; 
$TeamItemCount[2 @ JailCapPack] = 0; 
$TeamItemCount[3 @ JailCapPack] = 0; 
$TeamItemCount[4 @ JailCapPack] = 0; 
$TeamItemCount[5 @ JailCapPack] = 0; 
$TeamItemCount[6 @ JailCapPack] = 0; 
$TeamItemCount[7 @ JailCapPack] = 0;






$TeamItemCount[0 @ AntiAirPack] = 0; 
$TeamItemCount[1 @ AntiAirPack] = 0; 
$TeamItemCount[2 @ AntiAirPack] = 0; 
$TeamItemCount[3 @ AntiAirPack] = 0; 
$TeamItemCount[4 @ AntiAirPack] = 0; 
$TeamItemCount[5 @ AntiAirPack] = 0; 
$TeamItemCount[6 @ AntiAirPack] = 0; 
$TeamItemCount[7 @ AntiAirPack] = 0;




$TeamItemCount[0 @ DeployableElfTurret] = 0; 
$TeamItemCount[1 @ DeployableElfTurret] = 0; 
$TeamItemCount[2 @ DeployableElfTurret] = 0; 
$TeamItemCount[3 @ DeployableElfTurret] = 0; 
$TeamItemCount[4 @ DeployableElfTurret] = 0; 
$TeamItemCount[5 @ DeployableElfTurret] = 0; 
$TeamItemCount[6 @ DeployableElfTurret] = 0; 
$TeamItemCount[7 @ DeployableElfTurret] = 0;



$TeamItemCount[0 @ IndoorPack] = 0; 
$TeamItemCount[1 @ IndoorPack] = 0; 
$TeamItemCount[2 @ IndoorPack] = 0; 
$TeamItemCount[3 @ IndoorPack] = 0; 
$TeamItemCount[4 @ IndoorPack] = 0; 
$TeamItemCount[5 @ IndoorPack] = 0; 
$TeamItemCount[6 @ IndoorPack] = 0; 
$TeamItemCount[7 @ IndoorPack] = 0;





for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ BlastDoorPack] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}



for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ doorthreebyfourForceFieldPack] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}




for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ doorfourbyeightForceFieldPack] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}





for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ doorfourbyfourteenForceFieldPack] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}







for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ doorfourbyseventeenForceFieldPack] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}






for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ doorfivebyfiveForceFieldPack] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}






for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ newdoorone] = 0;

}




for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ newdoortwo] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}










for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ newdoorthree] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}










for(%i = 0; %i < 8; %i++)
{
        $TeamItemCount[%i @ newdoorfour] = 0;
        $TeamEnergy[%i] = $DefaultTeamEnergy;
}


	$TeamItemCount[0 @ BaseAlarm] = 0;
	$TeamItemCount[1 @ BaseAlarm] = 0;
	$TeamItemCount[2 @ BaseAlarm] = 0;
	$TeamItemCount[3 @ BaseAlarm] = 0;
	$TeamItemCount[4 @ BaseAlarm] = 0;
	$TeamItemCount[5 @ BaseAlarm] = 0;
	$TeamItemCount[6 @ BaseAlarm] = 0;
	$TeamItemCount[7 @ BaseAlarm] = 0;

 $totalNumCameras = 0; 
$totalNumTurrets = 0; 



for(%i = -1; %i < 8 ; %i++) 
$TeamEnergy[%i] = $DefaultTeamEnergy; 
} 
