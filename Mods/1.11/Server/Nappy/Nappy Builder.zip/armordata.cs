

$ItemMax[earmor,	Hackit] = 1;
$ItemMax[efemale,	Hackit] = 1;
$ItemMax[aarmor,	Hackit] = 1;
$ItemMax[afemale,	Hackit] = 1;









$ItemMax[darmor, newdoorone] = 1;
$ItemMax[earmor, newdoorone] = 1;
$ItemMax[efemale, newdoorone] = 1;
$ItemMax[afemale, newdoorone] = 1;
$ItemMax[aarmor, newdoorone] = 1;




$ItemMax[darmor, newdoortwo] = 1;
$ItemMax[earmor, newdoortwo] = 1;
$ItemMax[efemale, newdoortwo] = 1;
$ItemMax[afemale, newdoortwo] = 1;
$ItemMax[aarmor, newdoortwo] = 1;




$ItemMax[darmor, newdoorthree] = 1;
$ItemMax[earmor, newdoorthree] = 1;
$ItemMax[efemale, newdoorthree] = 1;
$ItemMax[afemale, newdoorthree] = 1;
$ItemMax[aarmor, newdoorthree] = 1;





$ItemMax[darmor, newdoorfour] = 1;
$ItemMax[earmor, newdoorfour] = 1;
$ItemMax[efemale, newdoorfour] = 1;
$ItemMax[afemale, newdoorfour] = 1;
$ItemMax[aarmor, newdoorfour] = 1;












$ItemMax[earmor, doorthreebyfourForceFieldPack] = 1;
$ItemMax[efemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[afemale, doorthreebyfourForceFieldPack] = 1;
$ItemMax[aarmor, doorthreebyfourForceFieldPack] = 1;



$ItemMax[earmor, doorfourbyeightForceFieldPack] = 1;
$ItemMax[efemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[afemale, doorfourbyeightForceFieldPack] = 1;
$ItemMax[aarmor, doorfourbyeightForceFieldPack] = 1;


$ItemMax[earmor, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[efemale, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[afemale, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[aarmor, doorfourbyfourteenForceFieldPack] = 1;


$ItemMax[earmor, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[efemale, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[afemale, doorfourbyseventeenForceFieldPack] = 1;
$ItemMax[aarmor, doorfourbyseventeenForceFieldPack] = 1;


$ItemMax[earmor, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[efemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[afemale, doorfivebyfiveForceFieldPack] = 1;
$ItemMax[aarmor, doorfivebyfiveForceFieldPack] = 1;










$ItemMax[earmor, BlastDoorPack] = 1;
$ItemMax[efemale, BlastDoorPack] = 1;
$ItemMax[aarmor, BlastDoorPack] = 1;
$ItemMax[afemale, BlastDoorPack] = 1;





$ItemMax[earmor, IndoorPack] = 1; 
$ItemMax[efemale, IndoorPack] = 1; 
 



$ItemMax[earmor, DeployableElfTurret ] = 1; 
$ItemMax[efemale, DeployableElfTurret ] = 1; 
$ItemMax[darmor, DeployableElfTurret ] = 1; 




$ItemMax[earmor, AntiAirPack] = 1; 
$ItemMax[efemale, AntiAirPack] = 1; 
$ItemMax[darmor, AntiAirPack] = 1; 




$ItemMax[darmor, jailpack] = 1;
$ItemMax[earmor, jailpack] = 1;
$ItemMax[efemale, jailpack] = 1;
$ItemMax[afemale, jailpack] = 1;
$ItemMax[aarmor, jailpack] = 1;





$ItemMax[larmor, JailGun] = 1;
$ItemMax[marmor, JailGun] = 1;
$ItemMax[lfemale, JailGun] = 1;
$ItemMax[mfemale, JailGun] = 1;
$ItemMax[sarmor, JailGun] = 1;
$ItemMax[darmor, JailGun] = 1;
$ItemMax[barmor, JailGun] = 1;
$ItemMax[sfemale, JailGun] = 1;
$ItemMax[bfemale, JailGun] = 1;
$ItemMax[spyarmor, JailGun] = 1;
$ItemMax[spyfemale, JailGun] = 1;
$ItemMax[earmor, JailGun] = 1;
$ItemMax[efemale, JailGun] = 1;
$ItemMax[afemale, JailGun] = 1;
$ItemMax[aarmor, JailGun] = 1;











$ItemMax[larmor, JailCapPack] = 0;
$ItemMax[sarmor, JailCapPack] = 0;
$ItemMax[barmor, JailCapPack] = 1;
$ItemMax[harmor, JailCapPack] = 0;
$ItemMax[darmor, JailCapPack] = 1;
$ItemMax[marmor, JailCapPack] = 0;
$ItemMax[mfemale, JailCapPack] = 0;
$ItemMax[earmor, JailCapPack] = 1;
$ItemMax[efemale, JailCapPack] = 1;
$ItemMax[lfemale, JailCapPack] = 0;
$ItemMax[sfemale, JailCapPack] = 0;
$ItemMax[bfemale, JailCapPack] = 1;
$ItemMax[spyarmor, JailCapPack] = 0;
$ItemMax[female, JailCapPack] = 1;
$ItemMax[adarmor, JailCapPack] = 0;
$ItemMax[aarmor, JailCapPack] = 1;
$ItemMax[parmor, JailCapPack] = 0;






$ItemMax[earmor, LrgPltPack] = 1;
$ItemMax[efemale, LrgPltPack] = 1; 
$ItemMax[aarmor, LrgPltPack] = 1;
$ItemMax[afemale, LrgPltPack] = 1;   
 





$ItemMax[darmor, BaseAlarm] = 1;
$ItemMax[earmor, BaseAlarm] = 1;
$ItemMax[efemale, BaseAlarm] = 1;
$ItemMax[afemale, BaseAlarm] = 1;
$ItemMax[aarmor, BaseAlarm] = 1;










$ItemMax[earmor, DeployablevhclPack] = 1;
$ItemMax[efemale, DeployablevhclPack] = 1;




$ItemMax[larmor, BigBomberPack] = 1;
$ItemMax[lfemale, BigBomberPack] = 1;
$ItemMax[sarmor, BigBomberPack] = 1;
$ItemMax[sfemale, BigBomberPack] = 1;
$ItemMax[spyarmor, BigBomberPack] = 1;
$ItemMax[spyfemale, BigBomberPack] = 1;
$ItemMax[earmor, BigBomberPack] = 1;
$ItemMax[efemale, BigBomberPack] = 1;



$ItemMax[larmor, cloakjetPack] = 1;
$ItemMax[lfemale, cloakjetPack] = 1;
$ItemMax[sarmor, cloakjetPack] = 1;
$ItemMax[sfemale, cloakjetPack] = 1;
$ItemMax[spyarmor, cloakjetPack] = 1;
$ItemMax[spyfemale, cloakjetPack] = 1;
$ItemMax[earmor, cloakjetPack] = 1;
$ItemMax[efemale, cloakjetPack] = 1;



$ItemMax[larmor, bomberPack] = 1;
$ItemMax[lfemale, bomberPack] = 1;
$ItemMax[sarmor, bomberPack] = 1;
$ItemMax[sfemale, bomberPack] = 1;
$ItemMax[spyarmor, bomberPack] = 1;
$ItemMax[spyfemale, bomberPack] = 1;
$ItemMax[earmor, bomberPack] = 1;
$ItemMax[efemale, bomberPack] = 1;



$ItemMax[larmor, MechPack] = 1;
$ItemMax[lfemale, MechPack] = 1;
$ItemMax[sarmor, MechPack] = 1;
$ItemMax[sfemale, MechPack] = 1;
$ItemMax[spyarmor, MechPack] = 1;
$ItemMax[spyfemale, MechPack] = 1;
$ItemMax[earmor, MechPack] = 1;
$ItemMax[efemale, MechPack] = 1;


$ItemMax[larmor, DetPack] = 1;
$ItemMax[lfemale, DetPack] = 1;
$ItemMax[sarmor, DetPack] = 1;
$ItemMax[sfemale, DetPack] = 1;
$ItemMax[spyarmor, DetPack] = 1;
$ItemMax[spyfemale, DetPack] = 1;
$ItemMax[earmor, DetPack] = 1;
$ItemMax[efemale, DetPack] = 1;






$ItemMax[larmor, ArbitorBoxPack] = 0;
$ItemMax[lfemale, ArbitorBoxPack] = 0;
$ItemMax[marmor, ArbitorBoxPack] = 0;
$ItemMax[mfemale, ArbitorBoxPack] = 0;
$ItemMax[harmor, ArbitorBoxPack] = 1;
$ItemMax[sarmor, ArbitorBoxPack] = 0;
$ItemMax[sfemale, ArbitorBoxPack] = 0;
$ItemMax[spyarmor, ArbitorBoxPack] = 0;
$ItemMax[spyfemale, ArbitorBoxPack] = 0;
$ItemMax[barmor, ArbitorBoxPack] = 0;
$ItemMax[bfemale, ArbitorBoxPack] = 0;
$ItemMax[earmor, ArbitorBoxPack] = 1;
$ItemMax[efemale, ArbitorBoxPack] = 1;
$ItemMax[aarmor, ArbitorBoxPack] = 1;
$ItemMax[afemale, ArbitorBoxPack] = 1;
$ItemMax[darmor, ArbitorBoxPack] = 0;
$ItemMax[tarmor, ArbitorBoxPack] = 0;
$ItemMax[scvarmor, ArbitorBoxPack] = 0;



$ItemMax[larmor, TreePack] = 1;
$ItemMax[sarmor, TreePack] = 1;
$ItemMax[barmor, TreePack] = 1;
$ItemMax[harmor, TreePack] = 1;
$ItemMax[darmor, TreePack] = 1;
$ItemMax[tarmor, TreePack] = 1;
$ItemMax[lfemale, TreePack] = 1;
$ItemMax[sfemale, TreePack] = 1;
$ItemMax[bfemale, TreePack] = 1;
$ItemMax[spyarmor, TreePack] = 1;
$ItemMax[spyfemale, TreePack] = 1;
$ItemMax[scvarmor, TreePack] = 1;





//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]






$DamageScale[sarmor, $LandingDamageType] = 0.0; 
$DamageScale[sarmor, $ImpactDamageType] = 0.0; 
$DamageScale[sarmor, $CrushDamageType] = 0.0; 
$DamageScale[sarmor, $BulletDamageType] = 0.0; 
$DamageScale[sarmor, $PlasmaDamageType] = 0.0; 
$DamageScale[sarmor, $EnergyDamageType] = 0.0; 
$DamageScale[sarmor, $ExplosionDamageType] = 0.0; 
$DamageScale[sarmor, $MissileDamageType] = 0.0; 
$DamageScale[sarmor, $DebrisDamageType] = 0.0; 
$DamageScale[sarmor, $ShrapnelDamageType] = 0.0; 
$DamageScale[sarmor, $LaserDamageType] = 0.0; 
$DamageScale[sarmor, $MortarDamageType] = 0.0; 
$DamageScale[sarmor, $BlasterDamageType] = 0.0; 
$DamageScale[sarmor, $ElectricityDamageType] = 0.0; 
$DamageScale[sarmor, $MineDamageType] = 0.0; 
$DamageScale[sarmor, $SniperDamageType] = 0.0; 
$DamageScale[sarmor, $FlashDamageType] = 0.0; 

$ItemMax[sarmor, Blaster] = 1; 
$ItemMax[sarmor, Chaingun] = 1; 
$ItemMax[sarmor, Disclauncher] = 1; 
$ItemMax[sarmor, GrenadeLauncher] = 1; 
$ItemMax[sarmor, Mortar] = 0; 
$ItemMax[sarmor, PlasmaGun] = 1; 
$ItemMax[sarmor, LaserRifle] = 1; 
$ItemMax[sarmor, EnergyRifle] = 1; 
$ItemMax[sarmor, TargetingLaser] = 1; 
$ItemMax[sarmor, MineAmmo] = 3; 
$ItemMax[sarmor, Grenade] = 5; 
$ItemMax[sarmor, Beacon] = 6; 
$ItemMax[sarmor, Boost] = 5; 
$ItemMax[sarmor, Plastique] = 0; 
$ItemMax[sarmor, RocketLauncher] = 0; 
$ItemMax[sarmor, SniperRifle] = 0; 
$ItemMax[sarmor, WaveGun] = 0; 
$ItemMax[sarmor, Railgun] = 0; 
$ItemMax[sarmor, Gaussgun] = 0; 
$ItemMax[sarmor, Vulcan] = 0; 
$ItemMax[sarmor, Silencer] = 0; 
$ItemMax[sarmor, Flamer] = 0; 
$ItemMax[sarmor, IonGun] = 1; 
$ItemMax[sarmor, Omega] = 0; 
$ItemMax[sarmor, TranqGun] = 0; 
$ItemMax[sarmor, HyperB] = 1; 
$ItemMax[sarmor, Fixit] = 0; 
$ItemMax[sarmor, Bolt] = 0; 
$ItemMax[sarmor, BulletAmmo] = 100; 
$ItemMax[sarmor, PlasmaAmmo] = 30; 
$ItemMax[sarmor, DiscAmmo] = 15; 
$ItemMax[sarmor, GrenadeAmmo] = 10; 
$ItemMax[sarmor, MortarAmmo] = 10; 
$ItemMax[sarmor, RocketAmmo] = 5; 
$ItemMax[sarmor, SniperAmmo] = 25; 
$ItemMax[sarmor, RailAmmo] = 10; 
$ItemMax[sarmor, SilencerAmmo] = 25; 
$ItemMax[sarmor, VulcanAmmo] = 200; 
$ItemMax[sarmor, TranqAmmo] = 20; 
$ItemMax[sarmor, EnergyPack] = 1; 
$ItemMax[sarmor, RepairPack] = 1; 
$ItemMax[sarmor, ShieldPack] = 1; 
$ItemMax[sarmor, SensorJammerPack] = 1; 
$ItemMax[sarmor, MotionSensorPack] = 1; 
$ItemMax[sarmor, PulseSensorPack] = 1; 
$ItemMax[sarmor, DeployableSensorJammerPack] = 1; 
$ItemMax[sarmor, CameraPack] = 1; 
$ItemMax[sarmor, TurretPack] = 0; 
$ItemMax[sarmor, AmmoPack] = 1; 
$ItemMax[sarmor, RepairKit] = 1; 
$ItemMax[sarmor, DeployableInvPack] = 0; 
$ItemMax[sarmor, DeployableAmmoPack] = 0; 
$ItemMax[sarmor, DeployableComPack] = 0; 
$ItemMax[sarmor, LaserTurret] = 0; 
$ItemMax[sarmor, ForceFieldPack] = 1; 
$ItemMax[sarmor, RocketPack] = 0; 
$ItemMax[sarmor, LaserPack] = 0; 
$ItemMax[sarmor, CloakingDevice] = 0; 
$ItemMax[sarmor, StealthShieldPack] = 0; 
$ItemMax[sarmor, TargetPack] = 0; 
$ItemMax[sarmor, Laptop] = 0; 
$ItemMax[sarmor, ShockPack] = 0; 
$ItemMax[sarmor, TeleportPack] = 0; 
$ItemMax[sarmor, TripwirePack] = 0; 
$ItemMax[sarmor, TreePack] = 0; 
$ItemMax[sarmor, SpringPack] = 0; 
$ItemMax[sarmor, SuicidePack] = 0; 
$ItemMax[sarmor, HoloPack] = 1; 
$ItemMax[sarmor, RegenerationPack] = 0; 
$ItemMax[sarmor, LightningPack] = 0; 
$ItemMax[sarmor, OpticPack] = 0; 
$ItemMax[sarmor, SMRPack] = 0; 
$ItemMax[sarmor, RailTurret] = 0; 
$ItemMax[sarmor, VulcanTurret] = 0; 
$MaxWeapons[sarmor] = 2; 



$DamageScale[sfemale, $LandingDamageType] = 0.0; 
$DamageScale[sfemale, $ImpactDamageType] = 0.0; 
$DamageScale[sfemale, $CrushDamageType] = 0.0; 
$DamageScale[sfemale, $BulletDamageType] = 0.0; 
$DamageScale[sfemale, $PlasmaDamageType] = 0.0; 
$DamageScale[sfemale, $EnergyDamageType] = 0.0; 
$DamageScale[sfemale, $ExplosionDamageType] = 0.0; 
$DamageScale[sfemale, $MissileDamageType] = 0.0; 
$DamageScale[sfemale, $ShrapnelDamageType] = 0.0; 
$DamageScale[sfemale, $DebrisDamageType] = 0.0; 
$DamageScale[sfemale, $LaserDamageType] = 0.0; 
$DamageScale[sfemale, $MortarDamageType] = 0.0; 
$DamageScale[sfemale, $BlasterDamageType] = 0.0; 
$DamageScale[sfemale, $ElectricityDamageType] = 0.0; 
$DamageScale[sfemale, $MineDamageType] = 0.0; 
$DamageScale[sfemale, $SniperDamageType] = 0.0; 
$DamageScale[sfemale, $FlashDamageType] = 0.0; 

$ItemMax[sfemale, Blaster] = 1; 
$ItemMax[sfemale, Chaingun] = 1; 
$ItemMax[sfemale, Disclauncher] = 1; 
$ItemMax[sfemale, GrenadeLauncher] = 1; 
$ItemMax[sfemale, Mortar] = 0; 
$ItemMax[sfemale, PlasmaGun] = 1; 
$ItemMax[sfemale, LaserRifle] = 1; 
$ItemMax[sfemale, EnergyRifle] = 1; 
$ItemMax[sfemale, TargetingLaser] = 1; 
$ItemMax[sfemale, MineAmmo] = 3; 
$ItemMax[sfemale, Grenade] = 5; 
$ItemMax[sfemale, Beacon] = 1; 
$ItemMax[sfemale, Boost] = 3; 
$ItemMax[sfemale, Plastique] = 0; 
$ItemMax[sfemale, SniperRifle] = 0; 
$ItemMax[sfemale, RocketLauncher] = 0; 
$ItemMax[sfemale, WaveGun] = 0; 
$ItemMax[sfemale, Railgun] = 0; 
$ItemMax[sfemale, Gaussgun] = 0; 
$ItemMax[sfemale, Vulcan] = 0; 
$ItemMax[sfemale, Silencer] = 0; 
$ItemMax[sfemale, Flamer] = 0; 
$ItemMax[sfemale, IonGun] = 1; 
$ItemMax[sfemale, Omega] = 0; 
$ItemMax[sfemale, TranqGun] = 0; 
$ItemMax[sfemale, HyperB] = 1; 
$ItemMax[sfemale, Fixit] = 0; 
$ItemMax[sfemale, Bolt] = 0; 
$ItemMax[sfemale, BulletAmmo] = 100; 
$ItemMax[sfemale, PlasmaAmmo] = 30; 
$ItemMax[sfemale, DiscAmmo] = 15; 
$ItemMax[sfemale, GrenadeAmmo] = 10; 
$ItemMax[sfemale, MortarAmmo] = 10; 
$ItemMax[sfemale, SniperAmmo] = 25; 
$ItemMax[sfemale, RocketAmmo] = 5; 
$ItemMax[sfemale, RailAmmo] = 10; 
$ItemMax[sfemale, SilencerAmmo] = 25; 
$ItemMax[sfemale, VulcanAmmo] = 200; 
$ItemMax[sfemale, TranqAmmo] = 20; 
$ItemMax[sfemale, EnergyPack] = 1; 
$ItemMax[sfemale, RepairPack] = 1; 
$ItemMax[sfemale, ShieldPack] = 1; 
$ItemMax[sfemale, SensorJammerPack] = 1; 
$ItemMax[sfemale, MotionSensorPack] = 1; 
$ItemMax[sfemale, PulseSensorPack] = 1; 
$ItemMax[sfemale, DeployableSensorJammerPack] = 1; 
$ItemMax[sfemale, CameraPack] = 1; 
$ItemMax[sfemale, TurretPack] = 0; 
$ItemMax[sfemale, AmmoPack] = 1; 
$ItemMax[sfemale, RepairKit] = 1; 
$ItemMax[sfemale, DeployableInvPack] = 0; 
$ItemMax[sfemale, DeployableAmmoPack] = 0; 
$ItemMax[sfemale, DeployableComPack] = 0; 
$ItemMax[sfemale, LaserTurret] = 0; 
$ItemMax[sfemale, ForceFieldPack] = 1; 
$ItemMax[sfemale, RocketPack] = 0; 
$ItemMax[sfemale, LaserPack] = 0; 
$ItemMax[sfemale, CloakingDevice] = 0; 
$ItemMax[sfemale, StealthShieldPack] = 0; 
$ItemMax[sfemale, TargetPack] = 0; 
$ItemMax[sfemale, Laptop] = 0; 
$ItemMax[sfemale, ShockPack] = 0; 
$ItemMax[sfemale, TeleportPack] = 0; 
$ItemMax[sfemale, TripwirePack] = 0; 
$ItemMax[sfemale, TreePack] = 0; 
$ItemMax[sfemale, SpringPack] = 0; 
$ItemMax[sfemale, SuicidePack] = 0; 
$ItemMax[sfemale, HoloPack] = 1; 
$ItemMax[sfemale, RegenerationPack] = 0; 
$ItemMax[sfemale, LightningPack] = 0; 
$ItemMax[sfemale, OpticPack] = 0; 
$ItemMax[sfemale, SMRPack] = 0; 
$ItemMax[sfemale, RailTurret] = 0; 
$ItemMax[sfemale, VulcanTurret] = 0; 
$MaxWeapons[sfemale] = 2; 



//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]






$DamageScale[spyarmor, $LandingDamageType] = 0.3; 
$DamageScale[spyarmor, $ImpactDamageType] = 0.3; 
$DamageScale[spyarmor, $CrushDamageType] = 1.0; 
$DamageScale[spyarmor, $BulletDamageType] = 0.5; 
$DamageScale[spyarmor, $PlasmaDamageType] = 1.2; 
$DamageScale[spyarmor, $EnergyDamageType] = 1.3; 
$DamageScale[spyarmor, $ExplosionDamageType] = 1.2; 
$DamageScale[spyarmor, $MissileDamageType] = 1.3; 
$DamageScale[spyarmor, $DebrisDamageType] = 1.3; 
$DamageScale[spyarmor, $ShrapnelDamageType] = 1.3; 
$DamageScale[spyarmor, $LaserDamageType] = 1.0; 
$DamageScale[spyarmor, $MortarDamageType] = 1.3; 
$DamageScale[spyarmor, $BlasterDamageType] = 1.3; 
$DamageScale[spyarmor, $ElectricityDamageType] = 1.0; 
$DamageScale[spyarmor, $MineDamageType] = 1.2; 
$DamageScale[spyarmor, $SniperDamageType] = 1.0; 
$DamageScale[spyarmor, $FlashDamageType] = 1.0; 

$ItemMax[spyarmor, Blaster] = 1; 
$ItemMax[spyarmor, Chaingun] = 1; 
$ItemMax[spyarmor, Disclauncher] = 1; 
$ItemMax[spyarmor, GrenadeLauncher] = 1; 
$ItemMax[spyarmor, Mortar] = 0; 
$ItemMax[spyarmor, PlasmaGun] = 1; 
$ItemMax[spyarmor, LaserRifle] = 1; 
$ItemMax[spyarmor, EnergyRifle] = 1; 
$ItemMax[spyarmor, TargetingLaser] = 1; 
$ItemMax[spyarmor, MineAmmo] = 5; 
$ItemMax[spyarmor, Grenade] = 8; 
$ItemMax[spyarmor, Beacon] = 10; 
$ItemMax[spyarmor, Boost] = 3; 
$ItemMax[spyarmor, Plastique] = 0; 
$ItemMax[spyarmor, RocketLauncher] = 0; 
$ItemMax[spyarmor, SniperRifle] = 0; 
$ItemMax[spyarmor, WaveGun] = 0; 
$ItemMax[spyarmor, Railgun] = 0; 
$ItemMax[spyarmor, Gaussgun] = 0; 
$ItemMax[spyarmor, Vulcan] = 0; 
$ItemMax[spyarmor, Silencer] = 1; 
$ItemMax[spyarmor, Flamer] = 0; 
$ItemMax[spyarmor, IonGun] = 0; 
$ItemMax[spyarmor, Omega] = 0; 
$ItemMax[spyarmor, TranqGun] = 1; 
$ItemMax[spyarmor, HyperB] = 0; 
$ItemMax[spyarmor, Fixit] = 0; 
$ItemMax[spyarmor, Bolt] = 0; 
$ItemMax[spyarmor, BulletAmmo] = 300; 
$ItemMax[spyarmor, PlasmaAmmo] = 50; 
$ItemMax[spyarmor, DiscAmmo] = 35; 
$ItemMax[spyarmor, GrenadeAmmo] = 20; 
$ItemMax[spyarmor, MortarAmmo] = 10; 
$ItemMax[spyarmor, RocketAmmo] = 5; 
$ItemMax[spyarmor, SniperAmmo] = 25; 
$ItemMax[spyarmor, RailAmmo] = 10; 
$ItemMax[spyarmor, SilencerAmmo] = 30; 
$ItemMax[spyarmor, VulcanAmmo] = 200; 
$ItemMax[spyarmor, TranqAmmo] = 25; 
$ItemMax[spyarmor, EnergyPack] = 1; 
$ItemMax[spyarmor, RepairPack] = 1; 
$ItemMax[spyarmor, ShieldPack] = 1; 
$ItemMax[spyarmor, SensorJammerPack] = 1; 
$ItemMax[spyarmor, MotionSensorPack] = 1; 
$ItemMax[spyarmor, PulseSensorPack] = 1; 
$ItemMax[spyarmor, DeployableSensorJammerPack] = 1; 
$ItemMax[spyarmor, CameraPack] = 1; 
$ItemMax[spyarmor, TurretPack] = 0; 
$ItemMax[spyarmor, AmmoPack] = 1; 
$ItemMax[spyarmor, RepairKit] = 1; 
$ItemMax[spyarmor, DeployableInvPack] = 0; 
$ItemMax[spyarmor, DeployableAmmoPack] = 0; 
$ItemMax[spyarmor, DeployableComPack] = 0; 
$ItemMax[spyarmor, LaserTurret] = 1; 
$ItemMax[spyarmor, ForceFieldPack] = 1; 
$ItemMax[spyarmor, RocketPack] = 0; 
$ItemMax[spyarmor, LaserPack] = 1; 
$ItemMax[spyarmor, CloakingDevice] = 1; 
$ItemMax[spyarmor, StealthShieldPack] = 1; 
$ItemMax[spyarmor, Laptop] = 1; 
$ItemMax[spyarmor, TargetPack] = 0; 
$ItemMax[spyarmor, ShockPack] = 0; 
$ItemMax[spyarmor, TeleportPack] = 0; 
$ItemMax[spyarmor, TripwirePack] = 0; 
$ItemMax[spyarmor, TreePack] = 0; 
$ItemMax[spyarmor, SpringPack] = 0; 
$ItemMax[spyarmor, SuicidePack] = 0; 
$ItemMax[spyarmor, HoloPack] = 1; 
$ItemMax[spyarmor, RegenerationPack] = 0; 
$ItemMax[spyarmor, LightningPack] = 0; 
$ItemMax[spyarmor, OpticPack] = 0; 
$ItemMax[spyarmor, SMRPack] = 0; 
$ItemMax[spyarmor, RailTurret] = 0; 
$ItemMax[spyarmor, VulcanTurret] = 0; 
$MaxWeapons[spyarmor] = 3; 









$DamageScale[spyfemale, $LandingDamageType] = 0.3; 
$DamageScale[spyfemale, $ImpactDamageType] = 0.3; 
$DamageScale[spyfemale, $CrushDamageType] = 1.0; 
$DamageScale[spyfemale, $BulletDamageType] = 0.5; 
$DamageScale[spyfemale, $PlasmaDamageType] = 1.2; 
$DamageScale[spyfemale, $EnergyDamageType] = 1.3; 
$DamageScale[spyfemale, $ExplosionDamageType] = 1.2; 
$DamageScale[spyfemale, $MissileDamageType] = 1.3; 
$DamageScale[spyfemale, $DebrisDamageType] = 1.3; 
$DamageScale[spyfemale, $ShrapnelDamageType] = 1.3; 
$DamageScale[spyfemale, $LaserDamageType] = 1.0; 
$DamageScale[spyfemale, $MortarDamageType] = 1.3; 
$DamageScale[spyfemale, $BlasterDamageType] = 1.3; 
$DamageScale[spyfemale, $ElectricityDamageType] = 1.0; 
$DamageScale[spyfemale, $MineDamageType] = 1.2; 
$DamageScale[spyfemale, $SniperDamageType] = 1.0; 
$DamageScale[spyfemale, $FlashDamageType] = 1.0; 

$ItemMax[spyfemale, Blaster] = 1; 
$ItemMax[spyfemale, Chaingun] = 1; 
$ItemMax[spyfemale, Disclauncher] = 1; 
$ItemMax[spyfemale, GrenadeLauncher] = 1; 
$ItemMax[spyfemale, Mortar] = 0; 
$ItemMax[spyfemale, PlasmaGun] = 1; 
$ItemMax[spyfemale, LaserRifle] = 1; 
$ItemMax[spyfemale, EnergyRifle] = 1; 
$ItemMax[spyfemale, TargetingLaser] = 1; 
$ItemMax[spyfemale, MineAmmo] = 3; 
$ItemMax[spyfemale, Grenade] = 3; 
$ItemMax[spyfemale, Beacon] = 3; 
$ItemMax[spyfemale, Boost] = 3; 
$ItemMax[spyfemale, Plastique] = 0; 
$ItemMax[spyfemale, RocketLauncher] = 0; 
$ItemMax[spyfemale, SniperRifle] = 0; 
$ItemMax[spyfemale, WaveGun] = 0; 
$ItemMax[spyfemale, Railgun] = 0; 
$ItemMax[spyfemale, Gaussgun] = 0; 
$ItemMax[spyfemale, Vulcan] = 0; 
$ItemMax[spyfemale, Silencer] = 1; 
$ItemMax[spyfemale, Flamer] = 0; 
$ItemMax[spyfemale, IonGun] = 0; 
$ItemMax[spyfemale, Omega] = 0; 
$ItemMax[spyfemale, TranqGun] = 0; 
$ItemMax[spyfemale, HyperB] = 0; 
$ItemMax[spyfemale, Fixit] = 0; 
$ItemMax[spyfemale, Bolt] = 0; 
$ItemMax[spyfemale, BulletAmmo] = 100; 
$ItemMax[spyfemale, PlasmaAmmo] = 30; 
$ItemMax[spyfemale, DiscAmmo] = 15; 
$ItemMax[spyfemale, GrenadeAmmo] = 10; 
$ItemMax[spyfemale, MortarAmmo] = 10; 
$ItemMax[spyfemale, RocketAmmo] = 5; 
$ItemMax[spyfemale, SniperAmmo] = 25; 
$ItemMax[spyfemale, RailAmmo] = 10; 
$ItemMax[spyfemale, SilencerAmmo] = 25; 
$ItemMax[spyfemale, VulcanAmmo] = 200; 
$ItemMax[spyfemale, TranqAmmo] = 20; 
$ItemMax[spyfemale, EnergyPack] = 1; 
$ItemMax[spyfemale, RepairPack] = 1; 
$ItemMax[spyfemale, ShieldPack] = 1; 
$ItemMax[spyfemale, SensorJammerPack] = 1; 
$ItemMax[spyfemale, MotionSensorPack] = 1; 
$ItemMax[spyfemale, PulseSensorPack] = 1; 
$ItemMax[spyfemale, DeployableSensorJammerPack] = 1; 
$ItemMax[spyfemale, CameraPack] = 1; 
$ItemMax[spyfemale, TurretPack] = 0; 
$ItemMax[spyfemale, AmmoPack] = 1; 
$ItemMax[spyfemale, RepairKit] = 1; 
$ItemMax[spyfemale, DeployableInvPack] = 0; 
$ItemMax[spyfemale, DeployableAmmoPack] = 0; 
$ItemMax[spyfemale, DeployableComPack] = 0; 
$ItemMax[spyfemale, LaserTurret] = 0; 
$ItemMax[spyfemale, ForceFieldPack] = 1; 
$ItemMax[spyfemale, RocketPack] = 0; 
$ItemMax[spyfemale, LaserPack] = 1; 
$ItemMax[spyfemale, CloakingDevice] = 1; 
$ItemMax[spyfemale, StealthShieldPack] = 0; 
$ItemMax[spyfemale, Laptop] = 1; 
$ItemMax[spyfemale, TargetPack] = 0; 
$ItemMax[spyfemale, ShockPack] = 0; 
$ItemMax[spyfemale, TeleportPack] = 0; 
$ItemMax[spyfemale, TripwirePack] = 0; 
$ItemMax[spyfemale, TreePack] = 0; 
$ItemMax[spyfemale, SpringPack] = 0; 
$ItemMax[spyfemale, SuicidePack] = 0; 
$ItemMax[spyfemale, HoloPack] = 1; 
$ItemMax[spyfemale, RegenerationPack] = 0; 
$ItemMax[spyfemale, LightningPack] = 0; 
$ItemMax[spyfemale, OpticPack] = 0; 
$ItemMax[spyfemale, SMRPack] = 0; 
$ItemMax[spyfemale, RailTurret] = 0; 
$ItemMax[spyfemale, VulcanTurret] = 0; 
$MaxWeapons[spyfemale] = 3; 





//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]



																										
$DamageScale[larmor, $LandingDamageType] = 1.0; 
$DamageScale[larmor, $ImpactDamageType] = 1.0; 
$DamageScale[larmor, $CrushDamageType] = 1.0; 
$DamageScale[larmor, $BulletDamageType] = 1.2; 
$DamageScale[larmor, $PlasmaDamageType] = 1.0; 
$DamageScale[larmor, $EnergyDamageType] = 1.3; 
$DamageScale[larmor, $ExplosionDamageType] = 1.0; 
$DamageScale[larmor, $MissileDamageType] = 1.0; 
$DamageScale[larmor, $DebrisDamageType] = 1.2; 
$DamageScale[larmor, $ShrapnelDamageType] = 1.2; 
$DamageScale[larmor, $LaserDamageType] = 1.0; 
$DamageScale[larmor, $MortarDamageType] = 1.3; 
$DamageScale[larmor, $BlasterDamageType] = 1.3; 
$DamageScale[larmor, $ElectricityDamageType] = 1.0; 
$DamageScale[larmor, $MineDamageType] = 1.2; 
$DamageScale[larmor, $SniperDamageType] = 1.0; 
$DamageScale[larmor, $FlashDamageType] = 1.0; 

$ItemMax[larmor, Blaster] = 1; 
$ItemMax[larmor, Chaingun] = 1; 
$ItemMax[larmor, Disclauncher] = 1; 
$ItemMax[larmor, GrenadeLauncher] = 1; 
$ItemMax[larmor, Mortar] = 0; 
$ItemMax[larmor, PlasmaGun] = 1; 
$ItemMax[larmor, LaserRifle] = 1; 
$ItemMax[larmor, EnergyRifle] = 1; 
$ItemMax[larmor, TargetingLaser] = 1; 
$ItemMax[larmor, MineAmmo] = 3; 
$ItemMax[larmor, Grenade] = 3; 
$ItemMax[larmor, Beacon] = 1; 
$ItemMax[larmor, Boost] = 3; 
$ItemMax[larmor, Plastique] = 0; 
$ItemMax[larmor, RocketLauncher] = 0; 
$ItemMax[larmor, SniperRifle] = 1; 
$ItemMax[larmor, WaveGun] = 0; 
$ItemMax[larmor, Railgun] = 1; 
$ItemMax[larmor, Vulcan] = 0; 
$ItemMax[larmor, Silencer] = 0; 
$ItemMax[larmor, Flamer] = 0; 
$ItemMax[larmor, IonGun] = 0; 
$ItemMax[larmor, Omega] = 0; 
$ItemMax[larmor, TranqGun] = 1; 
$ItemMax[larmor, HyperB] = 0; 
$ItemMax[larmor, Fixit] = 0; 
$ItemMax[larmor, Bolt] = 0; 
$ItemMax[larmor, BulletAmmo] = 100; 
$ItemMax[larmor, PlasmaAmmo] = 30; 
$ItemMax[larmor, DiscAmmo] = 15; 
$ItemMax[larmor, GrenadeAmmo] = 10; 
$ItemMax[larmor, MortarAmmo] = 10; 
$ItemMax[larmor, RocketAmmo] = 5; 
$ItemMax[larmor, SniperAmmo] = 15; 
$ItemMax[larmor, RailAmmo] = 10; 
$ItemMax[larmor, SilencerAmmo] = 25; 
$ItemMax[larmor, VulcanAmmo] = 200; 
$ItemMax[larmor, TranqAmmo] = 20; 
$ItemMax[larmor, EnergyPack] = 1; 
$ItemMax[larmor, RepairPack] = 1; 
$ItemMax[larmor, ShieldPack] = 1; 
$ItemMax[larmor, SensorJammerPack] = 1; 
$ItemMax[larmor, MotionSensorPack] = 1; 
$ItemMax[larmor, PulseSensorPack] = 1; 
$ItemMax[larmor, DeployableSensorJammerPack] = 1; 
$ItemMax[larmor, CameraPack] = 1; 
$ItemMax[larmor, TurretPack] = 0; 
$ItemMax[larmor, AmmoPack] = 1; 
$ItemMax[larmor, RepairKit] = 1; 
$ItemMax[larmor, DeployableInvPack] = 0; 
$ItemMax[larmor, DeployableAmmoPack] = 0; 
$ItemMax[larmor, DeployableComPack] = 0; 
$ItemMax[larmor, LaserTurret] = 0; 
$ItemMax[larmor, ForceFieldPack] = 1; 
$ItemMax[larmor, RocketPack] = 0; 
$ItemMax[larmor, LaserPack] = 0; 
$ItemMax[larmor, CloakingDevice] = 0; 
$ItemMax[larmor, StealthShieldPack] = 0; 
$ItemMax[larmor, TreePack] = 1; 
$ItemMax[larmor, TargetPack] = 0; 
$ItemMax[larmor, Laptop] = 0; 
$ItemMax[larmor, ShockPack] = 0; 
$ItemMax[larmor, SpringPack] = 0; 
$ItemMax[larmor, TeleportPack] = 0; 
$ItemMax[larmor, TripwirePack] = 0; 
$ItemMax[larmor, SuicidePack] = 0; 
$ItemMax[larmor, HoloPack] = 1; 
$ItemMax[larmor, RegenerationPack] = 0; 
$ItemMax[larmor, LightningPack] = 0; 
$ItemMax[larmor, OpticPack] = 1; 
$ItemMax[larmor, SMRPack] = 0; 
$ItemMax[larmor, RailTurret] = 0; 
$ItemMax[larmor, VulcanTurret] = 0; 
$MaxWeapons[larmor] = 3; 






$DamageScale[lfemale, $LandingDamageType] = 1.0; 
$DamageScale[lfemale, $ImpactDamageType] = 1.0; 
$DamageScale[lfemale, $CrushDamageType] = 1.0; 
$DamageScale[lfemale, $BulletDamageType] = 1.2; 
$DamageScale[lfemale, $PlasmaDamageType] = 1.0; 
$DamageScale[lfemale, $EnergyDamageType] = 1.3; 
$DamageScale[lfemale, $ExplosionDamageType] = 1.0; 
$DamageScale[lfemale, $MissileDamageType] = 1.0; 
$DamageScale[lfemale, $ShrapnelDamageType] = 1.2; 
$DamageScale[lfemale, $DebrisDamageType] = 1.2; 
$DamageScale[lfemale, $LaserDamageType] = 1.0; 
$DamageScale[lfemale, $MortarDamageType] = 1.3; 
$DamageScale[lfemale, $BlasterDamageType] = 1.3; 
$DamageScale[lfemale, $ElectricityDamageType] = 1.0; 
$DamageScale[lfemale, $MineDamageType] = 1.2; 
$DamageScale[lfemale, $SniperDamageType] = 1.0; 
$DamageScale[lfemale, $FlashDamageType] = 1.0; 

$ItemMax[lfemale, Blaster] = 1; 
$ItemMax[lfemale, Chaingun] = 1; 
$ItemMax[lfemale, Disclauncher] = 1; 
$ItemMax[lfemale, GrenadeLauncher] = 1; 
$ItemMax[lfemale, Mortar] = 0; 
$ItemMax[lfemale, PlasmaGun] = 1; 
$ItemMax[lfemale, LaserRifle] = 1; 
$ItemMax[lfemale, EnergyRifle] = 1; 
$ItemMax[lfemale, TargetingLaser] = 1; 
$ItemMax[lfemale, MineAmmo] = 3; 
$ItemMax[lfemale, Grenade] = 3; 
$ItemMax[lfemale, Beacon] = 1; 
$ItemMax[lfemale, Boost] = 3; 
$ItemMax[lfemale, Plastique] = 0; 
$ItemMax[lfemale, SniperRifle] = 1; 
$ItemMax[lfemale, RocketLauncher] = 0; 
$ItemMax[lfemale, WaveGun] = 0; 
$ItemMax[lfemale, Railgun] = 0; 
$ItemMax[lfemale, Gaussgun] = 0; 
$ItemMax[lfemale, Vulcan] = 0; 
$ItemMax[lfemale, Silencer] = 0; 
$ItemMax[lfemale, Flamer] = 0; 
$ItemMax[lfemale, IonGun] = 0; 
$ItemMax[lfemale, Omega] = 0; 
$ItemMax[lfemale, TranqGun] = 1; 
$ItemMax[lfemale, HyperB] = 0; 
$ItemMax[lfemale, Fixit] = 0; 
$ItemMax[lfemale, Bolt] = 0; 
$ItemMax[lfemale, BulletAmmo] = 100; 
$ItemMax[lfemale, PlasmaAmmo] = 30; 
$ItemMax[lfemale, DiscAmmo] = 15; 
$ItemMax[lfemale, GrenadeAmmo] = 10; 
$ItemMax[lfemale, MortarAmmo] = 10; 
$ItemMax[lfemale, SniperAmmo] = 15; 
$ItemMax[lfemale, RocketAmmo] = 5; 
$ItemMax[lfemale, RailAmmo] = 10; 
$ItemMax[lfemale, SilencerAmmo] = 25; 
$ItemMax[lfemale, VulcanAmmo] = 200; 
$ItemMax[lfemale, TranqAmmo] = 20; 
$ItemMax[lfemale, EnergyPack] = 1; 
$ItemMax[lfemale, RepairPack] = 1; 
$ItemMax[lfemale, ShieldPack] = 1; 
$ItemMax[lfemale, SensorJammerPack] = 1; 
$ItemMax[lfemale, MotionSensorPack] = 1; 
$ItemMax[lfemale, PulseSensorPack] = 1; 
$ItemMax[lfemale, DeployableSensorJammerPack] = 1; 
$ItemMax[lfemale, CameraPack] = 1; 
$ItemMax[lfemale, TurretPack] = 0; 
$ItemMax[lfemale, AmmoPack] = 1; 
$ItemMax[lfemale, RepairKit] = 1; 
$ItemMax[lfemale, DeployableInvPack] = 0; 
$ItemMax[lfemale, DeployableAmmoPack] = 0; 
$ItemMax[lfemale, DeployableComPack] = 0; 
$ItemMax[lfemale, LaserTurret] = 0; 
$ItemMax[lfemale, ForceFieldPack] = 1; 
$ItemMax[lfemale, RocketPack] = 0; 
$ItemMax[lfemale, LaserPack] = 0; 
$ItemMax[lfemale, CloakingDevice] = 0; 
$ItemMax[lfemale, StealthShieldPack] = 0; 
$ItemMax[lfemale, TreePack] = 1; 
$ItemMax[lfemale, TargetPack] = 0; 
$ItemMax[lfemale, Laptop] = 0; 
$ItemMax[lfemale, ShockPack] = 0; 
$ItemMax[lfemale, TeleportPack] = 0; 
$ItemMax[lfemale, TripwirePack] = 0; 
$ItemMax[lfemale, SpringPack] = 0; 
$ItemMax[lfemale, SuicidePack] = 0; 
$ItemMax[lfemale, HoloPack] = 1; 
$ItemMax[lfemale, RegenerationPack] = 0; 
$ItemMax[lfemale, LightningPack] = 0; 
$ItemMax[lfemale, OpticPack] = 1; 
$ItemMax[lfemale, SMRPack] = 0; 
$ItemMax[lfemale, RailTurret] = 0; 
$ItemMax[lfemale, VulcanTurret] = 0; 
$MaxWeapons[lfemale] = 3; 






//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]











$DamageScale[marmor, $LandingDamageType] = 1.0; 
$DamageScale[marmor, $ImpactDamageType] = 1.0; 
$DamageScale[marmor, $CrushDamageType] = 1.0; 
$DamageScale[marmor, $BulletDamageType] = 1.0; 
$DamageScale[marmor, $PlasmaDamageType] = 1.0; 
$DamageScale[marmor, $EnergyDamageType] = 1.0; 
$DamageScale[marmor, $ExplosionDamageType] = 1.0; 
$DamageScale[marmor, $MissileDamageType] = 1.0; 
$DamageScale[marmor, $ShrapnelDamageType] = 1.0; 
$DamageScale[marmor, $DebrisDamageType] = 1.0; 
$DamageScale[marmor, $LaserDamageType] = 1.0; 
$DamageScale[marmor, $MortarDamageType] = 1.0; 
$DamageScale[marmor, $BlasterDamageType] = 1.0; 
$DamageScale[marmor, $ElectricityDamageType] = 1.0; 
$DamageScale[marmor, $MineDamageType] = 1.0; 
$DamageScale[marmor, $SniperDamageType] = 1.0; 
$DamageScale[marmor, $FlashDamageType] = 1.0; 

$ItemMax[marmor, Blaster] = 1; 
$ItemMax[marmor, Chaingun] = 1; 
$ItemMax[marmor, Disclauncher] = 1; 
$ItemMax[marmor, GrenadeLauncher] = 1; 
$ItemMax[marmor, Mortar] = 1; 
$ItemMax[marmor, PlasmaGun] = 1; 
$ItemMax[marmor, LaserRifle] = 1; 
$ItemMax[marmor, EnergyRifle] = 1; 
$ItemMax[marmor, RocketLauncher] = 1; 
$ItemMax[marmor, SniperRifle] = 1; 
$ItemMax[marmor, WaveGun] = 0; 
$ItemMax[marmor, Railgun] = 1; 
$ItemMax[marmor, Vulcan] = 1; 
$ItemMax[marmor, Silencer] = 1; 
$ItemMax[marmor, Flamer] = 0; 
$ItemMax[marmor, IonGun] = 1; 
$ItemMax[marmor, Omega] = 1; 
$ItemMax[marmor, TranqGun] = 1; 
$ItemMax[marmor, HyperB] = 1; 
$ItemMax[marmor, Bolt] = 1; 

$ItemMax[marmor, TargetingLaser] = 1; 
$ItemMax[marmor, Fixit] = 0; 

$ItemMax[marmor, RepairKit] = 1; 
$ItemMax[marmor, MineAmmo] = 500; 
$ItemMax[marmor, Grenade] = 500; 
$ItemMax[marmor, Beacon] = 500; 
$ItemMax[marmor, Boost] = 4; 
$ItemMax[marmor, Plastique] = 0; 
$ItemMax[marmor, BulletAmmo] = 500; 
$ItemMax[marmor, PlasmaAmmo] = 500; 
$ItemMax[marmor, DiscAmmo] = 500; 
$ItemMax[marmor, GrenadeAmmo] = 500; 
$ItemMax[marmor, MortarAmmo] = 500; 
$ItemMax[marmor, RocketAmmo] = 500; 
$ItemMax[marmor, SniperAmmo] = 500; 
$ItemMax[marmor, RailAmmo] = 500; 
$ItemMax[marmor, SilencerAmmo] = 500; 
$ItemMax[marmor, VulcanAmmo] = 500; 
$ItemMax[marmor, TranqAmmo] = 500; 

$ItemMax[marmor, EnergyPack] = 1; 
$ItemMax[marmor, RepairPack] = 1; 
$ItemMax[marmor, ShieldPack] = 1; 
$ItemMax[marmor, SensorJammerPack] = 1; 
$ItemMax[marmor, AmmoPack] = 1; 
$ItemMax[marmor, RocketPack] = 0; 
$ItemMax[marmor, LaserPack] = 0; 
$ItemMax[marmor, CloakingDevice] = 0; 
$ItemMax[marmor, StealthShieldPack] = 0; 
$ItemMax[marmor, Laptop] = 0; 
$ItemMax[marmor, SuicidePack] = 0; 
$ItemMax[marmor, RegenerationPack] = 0; 
$ItemMax[marmor, LightningPack] = 0; 
$ItemMax[marmor, OpticPack] = 0; 
$ItemMax[marmor, SMRPack] = 0; 

$ItemMax[marmor, MotionSensorPack] = 1; 
$ItemMax[marmor, PulseSensorPack] = 1; 
$ItemMax[marmor, DeployableSensorJammerPack] = 1; 
$ItemMax[marmor, CameraPack] = 1; 

$ItemMax[marmor, DeployableInvPack] = 0; 
$ItemMax[marmor, DeployableAmmoPack] = 1; 
$ItemMax[marmor, DeployableComPack] = 0; 

$ItemMax[marmor, TurretPack] = 1; 
$ItemMax[marmor, LaserTurret] = 0; 
$ItemMax[marmor, TargetPack] = 0; 
$ItemMax[marmor, ShockPack] = 0; 
$ItemMax[marmor, RailTurret] = 0; 
$ItemMax[marmor, VulcanTurret] = 0; 

$ItemMax[marmor, MechPack] = 0; 
$ItemMax[marmor, DetPack] = 0; 

$ItemMax[marmor, ForceFieldPack] = 1; 
$ItemMax[marmor, TeleportPack] = 0; 
$ItemMax[marmor, TripwirePack] = 0; 
$ItemMax[marmor, TreePack] = 0; 
$ItemMax[marmor, SpringPack] = 0; 
$ItemMax[marmor, HoloPack] = 1; 
$MaxWeapons[marmor] = 18; 






$DamageScale[mfemale, $LandingDamageType] = 0.0; 
$DamageScale[mfemale, $ImpactDamageType] = 0.0; 
$DamageScale[mfemale, $CrushDamageType] = 1.0; 
$DamageScale[mfemale, $BulletDamageType] = 1.0; 
$DamageScale[mfemale, $EnergyDamageType] = 1.0; 
$DamageScale[mfemale, $PlasmaDamageType] = 1.0; 
$DamageScale[mfemale, $ExplosionDamageType] = 1.0; 
$DamageScale[mfemale, $MissileDamageType] = 1.0; 
$DamageScale[mfemale, $ShrapnelDamageType] = 1.0; 
$DamageScale[mfemale, $DebrisDamageType] = 1.0; 
$DamageScale[mfemale, $LaserDamageType] = 1.0; 
$DamageScale[mfemale, $MortarDamageType] = 1.0; 
$DamageScale[mfemale, $BlasterDamageType] = 1.0; 
$DamageScale[mfemale, $ElectricityDamageType] = 1.0; 
$DamageScale[mfemale, $MineDamageType] = 1.0; 
$DamageScale[mfemale, $SniperDamageType] = 1.0; 
$DamageScale[mfemale, $FlashDamageType] = 1.0; 

$ItemMax[mfemale, Blaster] = 1; 
$ItemMax[mfemale, Chaingun] = 1; 
$ItemMax[mfemale, Disclauncher] = 1; 
$ItemMax[mfemale, GrenadeLauncher] = 1; 
$ItemMax[mfemale, Mortar] = 1; 
$ItemMax[mfemale, PlasmaGun] = 1; 
$ItemMax[mfemale, LaserRifle] = 1; 
$ItemMax[mfemale, EnergyRifle] = 1; 
$ItemMax[mfemale, TargetingLaser] = 1; 
$ItemMax[mfemale, MineAmmo] = 500; 
$ItemMax[mfemale, Grenade] = 500; 
$ItemMax[mfemale, Beacon] = 500; 
$ItemMax[mfemale, Boost] = 4; 
$ItemMax[mfemale, Plastique] = 0; 
$ItemMax[mfemale, RocketLauncher] = 1; 
$ItemMax[mfemale, SniperRifle] = 1; 
$ItemMax[mfemale, WaveGun] = 0; 
$ItemMax[mfemale, Railgun] = 1; 
$ItemMax[mfemale, Gaussgun] = 0; 
$ItemMax[mfemale, Vulcan] = 1; 
$ItemMax[mfemale, Silencer] = 1; 
$ItemMax[mfemale, Flamer] = 0; 
$ItemMax[mfemale, IonGun] = 1; 
$ItemMax[mfemale, Omega] = 1; 
$ItemMax[mfemale, TranqGun] = 1; 
$ItemMax[mfemale, HyperB] = 1; 
$ItemMax[mfemale, Fixit] = 0; 
$ItemMax[mfemale, Bolt] = 1; 
$ItemMax[mfemale, BulletAmmo] = 150; 
$ItemMax[mfemale, PlasmaAmmo] = 35; 
$ItemMax[mfemale, DiscAmmo] = 15; 
$ItemMax[mfemale, GrenadeAmmo] = 10; 
$ItemMax[mfemale, MortarAmmo] = 10; 
$ItemMax[mfemale, SniperAmmo] = 15; 
$ItemMax[mfemale, RocketAmmo] = 5; 
$ItemMax[mfemale, RailAmmo] = 10; 
$ItemMax[mfemale, SilencerAmmo] = 25; 
$ItemMax[mfemale, VulcanAmmo] = 300; 
$ItemMax[mfemale, TranqAmmo] = 20; 
$ItemMax[mfemale, EnergyPack] = 1; 
$ItemMax[mfemale, RepairPack] = 1; 
$ItemMax[mfemale, ShieldPack] = 1; 
$ItemMax[mfemale, SensorJammerPack] = 1; 
$ItemMax[mfemale, MotionSensorPack] = 1; 
$ItemMax[mfemale, PulseSensorPack] = 1; 
$ItemMax[mfemale, DeployableSensorJammerPack] = 1; 
$ItemMax[mfemale, CameraPack] = 0; 
$ItemMax[mfemale, TurretPack] = 1; 
$ItemMax[mfemale, AmmoPack] = 1; 
$ItemMax[mfemale, RepairKit] = 1; 
$ItemMax[mfemale, DeployableInvPack] = 0; 
$ItemMax[mfemale, DeployableAmmoPack] = 1; 
$ItemMax[mfemale, DeployableComPack] = 0; 
$ItemMax[mfemale, LaserTurret] = 0; 
$ItemMax[mfemale, ForceFieldPack] = 1; 
$ItemMax[mfemale, RocketPack] = 0; 
$ItemMax[mfemale, LaserPack] = 0; 
$ItemMax[mfemale, CloakingDevice] = 0; 
$ItemMax[mfemale, StealthShieldPack] = 0; 
$ItemMax[mfemale, TargetPack] = 0; 
$ItemMax[mfemale, MechPack] = 0; 
$ItemMax[mfemale, Laptop] = 0; 
$ItemMax[mfemale, ShockPack] = 0; 
$ItemMax[mfemale, TeleportPack] = 0; 
$ItemMax[mfemale, TripwirePack] = 0; 
$ItemMax[mfemale, TreePack] = 0; 
$ItemMax[mfemale, SpringPack] = 0; 
$ItemMax[mfemale, SuicidePack] = 0; 
$ItemMax[mfemale, DetPack] = 0; 
$ItemMax[mfemale, HoloPack] = 1; 
$ItemMax[mfemale, RegenerationPack] = 0; 
$ItemMax[mfemale, LightningPack] = 0; 
$ItemMax[mfemale, OpticPack] = 0; 
$ItemMax[mfemale, SMRPack] = 0; 
$ItemMax[mfemale, RailTurret] = 0; 
$ItemMax[mfemale, VulcanTurret] = 0; 
$MaxWeapons[mfemale] = 18; 





//[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]





$DamageScale[barmor, $LandingDamageType] = 1.0; 
$DamageScale[barmor, $ImpactDamageType] = 1.0; 
$DamageScale[barmor, $CrushDamageType] = 1.0; 
$DamageScale[barmor, $BulletDamageType] = 1.3; 
$DamageScale[barmor, $PlasmaDamageType] = 0.1; 
$DamageScale[barmor, $EnergyDamageType] = 1.1; 
$DamageScale[barmor, $ExplosionDamageType] = 0.5; 
$DamageScale[barmor, $MissileDamageType] = 0.5; 
$DamageScale[barmor, $ShrapnelDamageType] = 0.5; 
$DamageScale[barmor, $DebrisDamageType] = 1.0; 
$DamageScale[barmor, $LaserDamageType] = 1.2; 
$DamageScale[barmor, $MortarDamageType] = 0.5; 
$DamageScale[barmor, $BlasterDamageType] = 1.2; 
$DamageScale[barmor, $ElectricityDamageType] = 1.0; 
$DamageScale[barmor, $MineDamageType] = 0.5; 
$DamageScale[barmor, $SniperDamageType] = 1.0; 
$DamageScale[barmor, $FlashDamageType] = 1.0; 

$ItemMax[barmor, Blaster] = 0; 
$ItemMax[barmor, Chaingun] = 0; 
$ItemMax[barmor, Disclauncher] = 1; 
$ItemMax[barmor, GrenadeLauncher] = 1; 
$ItemMax[barmor, Mortar] = 1; 
$ItemMax[barmor, PlasmaGun] = 1; 
$ItemMax[barmor, LaserRifle] = 0; 
$ItemMax[barmor, EnergyRifle] = 0; 
$ItemMax[barmor, TargetingLaser] = 1; 
$ItemMax[barmor, MineAmmo] = 6; 
$ItemMax[barmor, Grenade] = 6; 
$ItemMax[barmor, Beacon] = 1; 
$ItemMax[barmor, Boost] = 4; 
$ItemMax[barmor, Plastique] = 0; 
$ItemMax[barmor, RocketLauncher] = 1; 
$ItemMax[barmor, SniperRifle] = 0; 
$ItemMax[barmor, WaveGun] = 0; 
$ItemMax[barmor, Railgun] = 0; 
$ItemMax[barmor, Vulcan] = 0; 
$ItemMax[barmor, Silencer] = 0; 
$ItemMax[barmor, Flamer] = 0; 
$ItemMax[barmor, IonGun] = 0; 
$ItemMax[barmor, Omega] = 0; 
$ItemMax[barmor, TranqGun] = 0; 
$ItemMax[barmor, HyperB] = 0; 
$ItemMax[barmor, Fixit] = 0; 
$ItemMax[barmor, Bolt] = 0; 
$ItemMax[barmor, BulletAmmo] = 150; 
$ItemMax[barmor, PlasmaAmmo] = 50; 
$ItemMax[barmor, DiscAmmo] = 30; 
$ItemMax[barmor, GrenadeAmmo] = 20; 
$ItemMax[barmor, MortarAmmo] = 5; 
$ItemMax[barmor, RocketAmmo] = 10; 
$ItemMax[barmor, SniperAmmo] = 15; 
$ItemMax[barmor, RailAmmo] = 10; 
$ItemMax[barmor, SilencerAmmo] = 25; 
$ItemMax[barmor, VulcanAmmo] = 300; 
$ItemMax[barmor, TranqAmmo] = 20; 
$ItemMax[barmor, EnergyPack] = 1; 
$ItemMax[barmor, RepairPack] = 1; 
$ItemMax[barmor, ShieldPack] = 1; 
$ItemMax[barmor, SensorJammerPack] = 1; 
$ItemMax[barmor, MotionSensorPack] = 1; 
$ItemMax[barmor, PulseSensorPack] = 1; 
$ItemMax[barmor, DeployableSensorJammerPack] = 1; 
$ItemMax[barmor, CameraPack] = 1; 
$ItemMax[barmor, TurretPack] = 0; 
$ItemMax[barmor, AmmoPack] = 1; 
$ItemMax[barmor, RepairKit] = 1; 
$ItemMax[barmor, DeployableInvPack] = 0; 
$ItemMax[barmor, DeployableAmmoPack] = 1; 
$ItemMax[barmor, DeployableComPack] = 0; 
$ItemMax[barmor, LaserTurret] = 0; 
$ItemMax[barmor, ForceFieldPack] = 1; 
$ItemMax[barmor, RocketPack] = 1; 
$ItemMax[barmor, LaserPack] = 0; 
$ItemMax[barmor, CloakingDevice] = 0; 
$ItemMax[barmor, StealthShieldPack] = 0; 
$ItemMax[barmor, TargetPack] = 0; 
$ItemMax[barmor, MechPack] = 0; 
$ItemMax[barmor, Laptop] = 0; 
$ItemMax[barmor, ShockPack] = 0; 
$ItemMax[barmor, TeleportPack] = 0; 
$ItemMax[barmor, TripwirePack] = 0;
$ItemMax[barmor, TreePack] = 0; 
$ItemMax[barmor, SpringPack] = 0; 
$ItemMax[barmor, SuicidePack] = 1; 
$ItemMax[barmor, DetPack] = 0; 
$ItemMax[barmor, HoloPack] = 1; 
$ItemMax[barmor, RegenerationPack] = 0; 
$ItemMax[barmor, LightningPack] = 0; 
$ItemMax[barmor, OpticPack] = 0; 
$ItemMax[barmor, SMRPack] = 0; 
$ItemMax[barmor, RailTurret] = 0; 
$ItemMax[barmor, VulcanTurret] = 0; 
$MaxWeapons[barmor] = 4; 




$DamageScale[bfemale, $LandingDamageType] = 1.0; 
$DamageScale[bfemale, $ImpactDamageType] = 1.0; 
$DamageScale[bfemale, $CrushDamageType] = 1.0; 
$DamageScale[bfemale, $BulletDamageType] = 1.3; 
$DamageScale[bfemale, $PlasmaDamageType] = 0.1; 
$DamageScale[bfemale, $EnergyDamageType] = 1.1; 
$DamageScale[bfemale, $ExplosionDamageType] = 0.5; 
$DamageScale[bfemale, $MissileDamageType] = 0.5; 
$DamageScale[bfemale, $ShrapnelDamageType] = 0.5; 
$DamageScale[bfemale, $DebrisDamageType] = 1.0; 
$DamageScale[bfemale, $LaserDamageType] = 1.2; 
$DamageScale[bfemale, $MortarDamageType] = 0.5; 
$DamageScale[bfemale, $BlasterDamageType] = 1.2; 
$DamageScale[bfemale, $ElectricityDamageType] = 1.0; 
$DamageScale[bfemale, $MineDamageType] = 0.5; 
$DamageScale[bfemale, $SniperDamageType] = 1.0; 
$DamageScale[bfemale, $FlashDamageType] = 1.0; 

$ItemMax[bfemale, Blaster] = 0; 
$ItemMax[bfemale, Chaingun] = 0; 
$ItemMax[bfemale, Disclauncher] = 1; 
$ItemMax[bfemale, GrenadeLauncher] = 1; 
$ItemMax[bfemale, Mortar] = 1; 
$ItemMax[bfemale, PlasmaGun] = 1; 
$ItemMax[bfemale, LaserRifle] = 0; 
$ItemMax[bfemale, EnergyRifle] = 0; 
$ItemMax[bfemale, TargetingLaser] = 1; 
$ItemMax[bfemale, MineAmmo] = 6; 
$ItemMax[bfemale, Grenade] = 6; 
$ItemMax[bfemale, Beacon] = 1; 
$ItemMax[bfemale, Boost] = 4; 
$ItemMax[bfemale, Plastique] = 0; 
$ItemMax[bfemale, RocketLauncher] = 1; 
$ItemMax[bfemale, SniperRifle] = 0; 
$ItemMax[bfemale, WaveGun] = 0; 
$ItemMax[bfemale, Railgun] = 0; 
$ItemMax[bfemale, Vulcan] = 0; 
$ItemMax[bfemale, Silencer] = 0; 
$ItemMax[bfemale, Flamer] = 0; 
$ItemMax[bfemale, IonGun] = 0; 
$ItemMax[bfemale, Omega] = 0; 
$ItemMax[bfemale, TranqGun] = 0; 
$ItemMax[bfemale, HyperB] = 0; 
$ItemMax[bfemale, Fixit] = 0; 
$ItemMax[bfemale, Bolt] = 0; 
$ItemMax[bfemale, BulletAmmo] = 0; 
$ItemMax[bfemale, PlasmaAmmo] = 50; 
$ItemMax[bfemale, DiscAmmo] = 30; 
$ItemMax[bfemale, GrenadeAmmo] = 20; 
$ItemMax[bfemale, MortarAmmo] = 5; 
$ItemMax[bfemale, RocketAmmo] = 10; 
$ItemMax[bfemale, SniperAmmo] = 15; 
$ItemMax[bfemale, RailAmmo] = 10; 
$ItemMax[bfemale, SilencerAmmo] = 25; 
$ItemMax[bfemale, VulcanAmmo] = 200; 
$ItemMax[bfemale, TranqAmmo] = 20; 
$ItemMax[bfemale, EnergyPack] = 1; 
$ItemMax[bfemale, RepairPack] = 1; 
$ItemMax[bfemale, ShieldPack] = 1; 
$ItemMax[bfemale, SensorJammerPack] = 1; 
$ItemMax[bfemale, MotionSensorPack] = 1; 
$ItemMax[bfemale, PulseSensorPack] = 1; 
$ItemMax[bfemale, DeployableSensorJammerPack] = 1; 
$ItemMax[bfemale, CameraPack] = 1; 
$ItemMax[bfemale, TurretPack] = 0; 
$ItemMax[bfemale, AmmoPack] = 1; 
$ItemMax[bfemale, RepairKit] = 1; 
$ItemMax[bfemale, DeployableInvPack] = 0; 
$ItemMax[bfemale, DeployableAmmoPack] = 1; 
$ItemMax[bfemale, DeployableComPack] = 0; 
$ItemMax[bfemale, LaserTurret] = 0; 
$ItemMax[bfemale, ForceFieldPack] = 1; 
$ItemMax[bfemale, RocketPack] = 1; 
$ItemMax[bfemale, LaserPack] = 0; 
$ItemMax[bfemale, CloakingDevice] = 0; 
$ItemMax[bfemale, StealthShieldPack] = 0; 
$ItemMax[bfemale, TargetPack] = 0; 
$ItemMax[bfemale, MechPack] = 0; 
$ItemMax[bfemale, Laptop] = 0; 
$ItemMax[bfemale, ShockPack] = 0; 
$ItemMax[bfemale, TeleportPack] = 0; 
$ItemMax[bfemale, TripwirePack] = 0; 
$ItemMax[bfemale, TreePack] = 0; 
$ItemMax[bfemale, SpringPack] = 0; 
$ItemMax[bfemale, SuicidePack] = 1; 
$ItemMax[bfemale, DetPack] = 0; 
$ItemMax[bfemale, HoloPack] = 1; 
$ItemMax[bfemale, RegenerationPack] = 0; 
$ItemMax[bfemale, LightningPack] = 0; 
$ItemMax[bfemale, OpticPack] = 0; 
$ItemMax[bfemale, SMRPack] = 0; 
$ItemMax[bfemale, RailTurret] = 0; 
$ItemMax[bfemale, VulcanTurret] = 0; 
$MaxWeapons[bfemale] = 4; 












$DamageScale[earmor, $LandingDamageType] = 0.0; 
$DamageScale[earmor, $ImpactDamageType] = 0.0; 
$DamageScale[earmor, $CrushDamageType] = 0.0; 
$DamageScale[earmor, $BulletDamageType] = 0.0; 
$DamageScale[earmor, $PlasmaDamageType] = 0.0; 
$DamageScale[earmor, $EnergyDamageType] = 0.0; 
$DamageScale[earmor, $ExplosionDamageType] = 0.0; 
$DamageScale[earmor, $MissileDamageType] = 0.0; 
$DamageScale[earmor, $ShrapnelDamageType] = 0.0; 
$DamageScale[earmor, $DebrisDamageType] = 0.0; 
$DamageScale[earmor, $LaserDamageType] = 0.0; 
$DamageScale[earmor, $MortarDamageType] = 0.0; 
$DamageScale[earmor, $BlasterDamageType] = 0.0; 
$DamageScale[earmor, $ElectricityDamageType] = 0.0; 
$DamageScale[earmor, $MineDamageType] = 0.0; 
$DamageScale[earmor, $SniperDamageType] = 0.0; 
$DamageScale[earmor, $FlashDamageType] = 0.0; 

$ItemMax[earmor, Blaster] = 1; 
$ItemMax[earmor, Chaingun] = 1; 
$ItemMax[earmor, Disclauncher] = 1; 
$ItemMax[earmor, GrenadeLauncher] = 1; 
$ItemMax[earmor, Mortar] = 0; 
$ItemMax[earmor, PlasmaGun] = 1; 
$ItemMax[earmor, LaserRifle] = 0; 
$ItemMax[earmor, EnergyRifle] = 1; 
$ItemMax[earmor, TargetingLaser] = 1; 
$ItemMax[earmor, MineAmmo] = 15; 
$ItemMax[earmor, Grenade] = 20; 
$ItemMax[earmor, Beacon] = 3; 
$ItemMax[earmor, Boost] = 4; 
$ItemMax[earmor, Plastique] = 0; 
$ItemMax[earmor, RocketLauncher] = 1; 
$ItemMax[earmor, SniperRifle] = 0; 
$ItemMax[earmor, WaveGun] = 0; 
$ItemMax[earmor, Railgun] = 1; 
$ItemMax[earmor, Gaussgun] = 0; 
$ItemMax[earmor, Vulcan] = 1; 
$ItemMax[earmor, Silencer] = 0; 
$ItemMax[earmor, Flamer] = 0; 
$ItemMax[earmor, IonGun] = 0; 
$ItemMax[earmor, Omega] = 0; 
$ItemMax[earmor, TranqGun] = 0; 
$ItemMax[earmor, HyperB] = 0; 
$ItemMax[earmor, Fixit] = 1; 
$ItemMax[earmor, Bolt] = 0; 
$ItemMax[earmor, BulletAmmo] = 500; 
$ItemMax[earmor, PlasmaAmmo] = 80; 
$ItemMax[earmor, DiscAmmo] = 35; 
$ItemMax[earmor, GrenadeAmmo] = 20; 
$ItemMax[earmor, MortarAmmo] = 10; 
$ItemMax[earmor, RocketAmmo] = 10; 
$ItemMax[earmor, SniperAmmo] = 15; 
$ItemMax[earmor, RailAmmo] = 25; 
$ItemMax[earmor, VulcanAmmo] = 500; 
$ItemMax[earmor, TranqAmmo] = 20; 
$ItemMax[earmor, EnergyPack] = 1; 
$ItemMax[earmor, RepairPack] = 1; 
$ItemMax[earmor, ShieldPack] = 1; 
$ItemMax[earmor, SensorJammerPack] = 1; 
$ItemMax[earmor, MotionSensorPack] = 1; 
$ItemMax[earmor, PulseSensorPack] = 1; 
$ItemMax[earmor, DeployableSensorJammerPack] = 1; 
$ItemMax[earmor, CameraPack] = 1; 
$ItemMax[earmor, TurretPack] = 1; 
$ItemMax[earmor, AmmoPack] = 1; 
$ItemMax[earmor, RepairKit] = 1; 
$ItemMax[earmor, DeployableInvPack] = 1; 
$ItemMax[earmor, DeployableAmmoPack] = 1; 
$ItemMax[earmor, DeployableComPack] = 1; 
$ItemMax[earmor, LaserTurret] = 1; 
$ItemMax[earmor, ForceFieldPack] = 1; 
$ItemMax[earmor, LargeForceFieldPack] = 1; 
$ItemMax[earmor, RocketPack] = 1; 
$ItemMax[earmor, LaserPack] = 1; 
$ItemMax[earmor, CloakingDevice] = 0; 
$ItemMax[earmor, StealthShieldPack] = 0; 
$ItemMax[earmor,TeleportPack] = 1; 
$ItemMax[earmor,TripwirePack] = 1; 
$ItemMax[earmor, Laptop] = 1; 
$ItemMax[earmor, ShockPack] = 1; 
$ItemMax[earmor, PlatformPack] = 1; 
$ItemMax[earmor, TreePack] = 1; 
$ItemMax[earmor, TargetPack] = 1; 
$ItemMax[earmor, SuicidePack] = 0; 
$ItemMax[earmor, HoloPack] = 1; 
$ItemMax[earmor, RegenerationPack] = 0; 
$ItemMax[earmor, LightningPack] = 0; 
$ItemMax[earmor, SpringPack] = 1; 
$ItemMax[earmor, OpticPack] = 0; 
$ItemMax[earmor, SMRPack] = 0; 
$ItemMax[earmor, RailTurret] = 1; 
$ItemMax[earmor, VulcanTurret] = 1; 
$MaxWeapons[earmor] = 5; 




$DamageScale[efemale, $LandingDamageType] = 1.0; 
$DamageScale[efemale, $ImpactDamageType] = 1.0; 
$DamageScale[efemale, $CrushDamageType] = 1.0; 
$DamageScale[efemale, $BulletDamageType] = 1.0; 
$DamageScale[efemale, $EnergyDamageType] = 1.0; 
$DamageScale[efemale, $PlasmaDamageType] = 1.0; 
$DamageScale[efemale, $ExplosionDamageType] = 1.0; 
$DamageScale[efemale, $MissileDamageType] = 1.0; 
$DamageScale[efemale, $ShrapnelDamageType] = 1.0; 
$DamageScale[efemale, $DebrisDamageType] = 1.0; 
$DamageScale[efemale, $LaserDamageType] = 1.0; 
$DamageScale[efemale, $MortarDamageType] = 1.0; 
$DamageScale[efemale, $BlasterDamageType] = 1.0; 
$DamageScale[efemale, $ElectricityDamageType] = 1.0; 
$DamageScale[efemale, $MineDamageType] = 1.0; 
$DamageScale[efemale, $SniperDamageType] = 1.0; 
$DamageScale[efemale, $FlashDamageType] = 1.0; 

$ItemMax[efemale, Blaster] = 1; 
$ItemMax[efemale, Chaingun] = 1; 
$ItemMax[efemale, Disclauncher] = 1; 
$ItemMax[efemale, GrenadeLauncher] = 1; 
$ItemMax[efemale, Mortar] = 0; 
$ItemMax[efemale, PlasmaGun] = 1; 
$ItemMax[efemale, LaserRifle] = 0; 
$ItemMax[efemale, EnergyRifle] = 1; 
$ItemMax[efemale, TargetingLaser] = 1; 
$ItemMax[efemale, MineAmmo] = 3; 
$ItemMax[efemale, Grenade] = 6; 
$ItemMax[efemale, Beacon] = 1; 
$ItemMax[efemale, Boost] = 4; 
$ItemMax[efemale, Plastique] = 0; 
$ItemMax[efemale, RocketLauncher] = 1; 
$ItemMax[efemale, SniperRifle] = 0; 
$ItemMax[efemale, WaveGun] = 0; 
$ItemMax[efemale, Railgun] = 1; 
$ItemMax[efemale, Gaussgun] = 0; 
$ItemMax[efemale, Vulcan] = 1; 
$ItemMax[efemale, Silencer] = 0; 
$ItemMax[efemale, Flamer] = 0; 
$ItemMax[efemale, IonGun] = 0; 
$ItemMax[efemale, Omega] = 0; 
$ItemMax[efemale, TranqGun] = 0; 
$ItemMax[efemale, HyperB] = 0; 
$ItemMax[efemale, Fixit] = 1; 
$ItemMax[efemale, Bolt] = 0; 
$ItemMax[efemale, BulletAmmo] = 150; 
$ItemMax[efemale, PlasmaAmmo] = 35; 
$ItemMax[efemale, DiscAmmo] = 15; 
$ItemMax[efemale, GrenadeAmmo] = 10; 
$ItemMax[efemale, MortarAmmo] = 10; 
$ItemMax[efemale, SniperAmmo] = 15; 
$ItemMax[efemale, RocketAmmo] = 5; 
$ItemMax[efemale, RailAmmo] = 10; 
$ItemMax[efemale, VulcanAmmo] = 200; 
$ItemMax[efemale, TranqAmmo] = 20; 
$ItemMax[efemale, EnergyPack] = 1; 
$ItemMax[efemale, RepairPack] = 1; 
$ItemMax[efemale, ShieldPack] = 1; 
$ItemMax[efemale, SensorJammerPack] = 1; 
$ItemMax[efemale, MotionSensorPack] = 1; 
$ItemMax[efemale, PulseSensorPack] = 1; 
$ItemMax[efemale, DeployableSensorJammerPack] = 1; 
$ItemMax[efemale, CameraPack] = 1; 
$ItemMax[efemale, TurretPack] = 1; 
$ItemMax[efemale, AmmoPack] = 1; 
$ItemMax[efemale, RepairKit] = 1; 
$ItemMax[efemale, DeployableInvPack] = 1; 
$ItemMax[efemale, DeployableAmmoPack] = 1; 
$ItemMax[efemale, DeployableComPack] = 1; 
$ItemMax[efemale, LaserTurret] = 1; 
$ItemMax[efemale, ForceFieldPack] = 1; 
$ItemMax[efemale, LargeForceFieldPack] = 1; 
$ItemMax[efemale, RocketPack] = 1; 
$ItemMax[efemale, LaserPack] = 1; 
$ItemMax[efemale, CloakingDevice] = 0; 
$ItemMax[efemale, StealthShieldPack] = 0; 
$ItemMax[efemale,TeleportPack] = 1; 
$ItemMax[efemale,TripwirePack] = 1; 
$ItemMax[efemale, Laptop] = 1; 
$ItemMax[efemale, ShockPack] = 1; 
$ItemMax[efemale, PlatformPack] = 1; 
$ItemMax[efemale, TreePack] = 1; 
$ItemMax[efemale, TargetPack] = 1; 
$ItemMax[efemale, MechPack] = 0; 
$ItemMax[efemale, SuicidePack] = 0; 
$ItemMax[efemale, HoloPack] = 1; 
$ItemMax[efemale, SpringPack] = 1; 
$ItemMax[efemale, RegenerationPack] = 0; 
$ItemMax[efemale, LightningPack] = 0; 
$ItemMax[efemale, OpticPack] = 0; 
$ItemMax[efemale, SMRPack] = 0; 
$ItemMax[efemale, RailTurret] = 1; 
$ItemMax[efemale, VulcanTurret] = 1; 
$MaxWeapons[efemale] = 3; 



$DamageScale[aarmor, $LandingDamageType] = 0.5; 
$DamageScale[aarmor, $ImpactDamageType] = 1.0; 
$DamageScale[aarmor, $CrushDamageType] = 1.0; 
$DamageScale[aarmor, $BulletDamageType] = 1.0; 
$DamageScale[aarmor, $PlasmaDamageType] = 2.0; 
$DamageScale[aarmor, $EnergyDamageType] = 1.0; 
$DamageScale[aarmor, $ExplosionDamageType] = 1.0; 
$DamageScale[aarmor, $MissileDamageType] = 1.0; 
$DamageScale[aarmor, $ShrapnelDamageType] = 1.0; 
$DamageScale[aarmor, $DebrisDamageType] = 1.0; 
$DamageScale[aarmor, $LaserDamageType] = 0.5; 
$DamageScale[aarmor, $MortarDamageType] = 1.2; 
$DamageScale[aarmor, $BlasterDamageType] = 0.5; 
$DamageScale[aarmor, $ElectricityDamageType] = 0.5; 
$DamageScale[aarmor, $MineDamageType] = 1.0; 
$DamageScale[aarmor, $SniperDamageType] = 1.0; 
$DamageScale[aarmor, $FlashDamageType] = 2.0; 

//========================================Weapons
$ItemMax[aarmor, Blaster] = 1; 
$ItemMax[aarmor, Chaingun] = 1; 
$ItemMax[aarmor, Disclauncher] = 1; 
$ItemMax[aarmor, GrenadeLauncher] = 0; 
$ItemMax[aarmor, Mortar] = 0; 
$ItemMax[aarmor, PlasmaGun] = 0; 
$ItemMax[aarmor, LaserRifle] = 0; 
$ItemMax[aarmor, EnergyRifle] = 0; 
$ItemMax[aarmor, TargetingLaser] = 1; 
$ItemMax[aarmor, RocketLauncher] = 0; 
$ItemMax[aarmor, SniperRifle] = 1; 
$ItemMax[aarmor, WaveGun] = 1; 
$ItemMax[aarmor, Railgun] = 0; 
$ItemMax[aarmor, Vulcan] = 0; 
$ItemMax[aarmor, Silencer] = 0; 
$ItemMax[aarmor, Flamer] = 0; 
$ItemMax[aarmor, IonGun] = 0; 
$ItemMax[aarmor, Omega] = 0; 
$ItemMax[aarmor, TranqGun] = 0; 
$ItemMax[aarmor, HyperB] = 1; 
$ItemMax[aarmor, Fixit] = 1; 
$ItemMax[aarmor, Bolt] = 0; 

//========================================Armor Items
$ItemMax[aarmor, MineAmmo] = 10; 
$ItemMax[aarmor, Grenade] = 10; 
$ItemMax[aarmor, Beacon] = 6; 
$ItemMax[aarmor, Boost] = 4; 
$ItemMax[aarmor, Plastique] = 0; 
$ItemMax[aarmor, RepairKit] = 2; 

//=========================================Ammo Max
$ItemMax[aarmor, BulletAmmo] = 300; 
$ItemMax[aarmor, PlasmaAmmo] = 40; 
$ItemMax[aarmor, DiscAmmo] = 25; 
$ItemMax[aarmor, GrenadeAmmo] = 10; 
$ItemMax[aarmor, MortarAmmo] = 10; 
$ItemMax[aarmor, RocketAmmo] = 5; 
$ItemMax[aarmor, SniperAmmo] = 25; 
$ItemMax[aarmor, RailAmmo] = 10; 
$ItemMax[aarmor, SilencerAmmo] = 25; 
$ItemMax[aarmor, VulcanAmmo] = 300; 
$ItemMax[aarmor, TranqAmmo] = 20; 

//=========================================Back Packs
$ItemMax[aarmor, EnergyPack] = 1; 
$ItemMax[aarmor, RepairPack] = 1; 
$ItemMax[aarmor, ShieldPack] = 1; 
$ItemMax[aarmor, SensorJammerPack] = 0; 
$ItemMax[aarmor, MotionSensorPack] = 1; 
$ItemMax[aarmor, PulseSensorPack] = 1; 
$ItemMax[aarmor, DeployableSensorJammerPack] = 1; 
$ItemMax[aarmor, AmmoPack] = 1; 
$ItemMax[aarmor, CloakingDevice] = 0; 
$ItemMax[aarmor, StealthShieldPack] = 1; 
$ItemMax[aarmor, Laptop] = 1; 
$ItemMax[aarmor, RegenerationPack] = 1; 
$ItemMax[aarmor, LightningPack] = 0; 
$ItemMax[aarmor, OpticPack] = 0; 
$ItemMax[aarmor, SMRPack] = 0; 
$ItemMax[aarmor, SuicidePack] = 1; 

//==========================================Turrets
$ItemMax[aarmor, CameraPack] = 1; 
$ItemMax[aarmor, TurretPack] = 0; 
$ItemMax[aarmor, LaserTurret] = 0; 
$ItemMax[aarmor, RocketPack] = 0; 
$ItemMax[aarmor, LaserPack] = 0; 
$ItemMax[aarmor, TargetPack] = 0; 
$ItemMax[aarmor, ShockPack] = 0; 
$ItemMax[aarmor, RailTurret] = 0; 
$ItemMax[aarmor, VulcanTurret] = 0; 

//==========================================Deploayables
$ItemMax[aarmor, DeployableInvPack] = 1; 
$ItemMax[aarmor, DeployableAmmoPack] = 1; 
$ItemMax[aarmor, DeployableComPack] = 1; 
$ItemMax[aarmor, ForceFieldPack] = 1; 
$ItemMax[aarmor, LargeForceFieldPack] = 1; 
$ItemMax[aarmor, TeleportPack] = 1; 
$ItemMax[aarmor, TripwirePack] = 1; 
$ItemMax[aarmor, TreePack] = 1; 
$ItemMax[aarmor, SpringPack] = 1; 
$ItemMax[aarmor, HoloPack] = 1; 
$ItemMax[aarmor, FlagstandPack] = 1;
$ItemMax[aarmor, PlatformPack] = 1;
 
//==========================================Deployable Vehicles
$ItemMax[aarmor, MechPack] = 0;
$ItemMax[aarmor, DetPack] = 0; 
$MaxWeapons[aarmor] = 4; 



$DamageScale[afemale, $LandingDamageType] = 0.5; 
$DamageScale[afemale, $ImpactDamageType] = 1.0; 
$DamageScale[afemale, $CrushDamageType] = 1.0; 
$DamageScale[afemale, $BulletDamageType] = 1.0; 
$DamageScale[afemale, $PlasmaDamageType] = 2.0; 
$DamageScale[afemale, $EnergyDamageType] = 1.0; 
$DamageScale[afemale, $ExplosionDamageType] = 1.0; 
$DamageScale[afemale, $MissileDamageType] = 1.0; 
$DamageScale[afemale, $ShrapnelDamageType] = 1.0; 
$DamageScale[afemale, $DebrisDamageType] = 1.0; 
$DamageScale[afemale, $LaserDamageType] = 0.5; 
$DamageScale[afemale, $MortarDamageType] = 1.2; 
$DamageScale[afemale, $BlasterDamageType] = 0.5; 
$DamageScale[afemale, $ElectricityDamageType] = 0.5; 
$DamageScale[afemale, $MineDamageType] = 1.0; 
$DamageScale[afemale, $SniperDamageType] = 1.0; 
$DamageScale[afemale, $FlashDamageType] = 2.0; 


//========================================Weapons
$ItemMax[afemale, Blaster] = 1; 
$ItemMax[afemale, Chaingun] = 1; 
$ItemMax[afemale, Disclauncher] = 1; 
$ItemMax[afemale, GrenadeLauncher] = 0; 
$ItemMax[afemale, Mortar] = 0; 
$ItemMax[afemale, PlasmaGun] = 0; 
$ItemMax[afemale, LaserRifle] = 0; 
$ItemMax[afemale, EnergyRifle] = 0; 
$ItemMax[afemale, TargetingLaser] = 1; 
$ItemMax[afemale, RocketLauncher] = 0; 
$ItemMax[afemale, SniperRifle] = 1; 
$ItemMax[afemale, WaveGun] = 1; 
$ItemMax[afemale, Railgun] = 0; 
$ItemMax[afemale, Vulcan] = 0; 
$ItemMax[afemale, Silencer] = 0; 
$ItemMax[afemale, Flamer] = 0; 
$ItemMax[afemale, IonGun] = 0; 
$ItemMax[afemale, Omega] = 0; 
$ItemMax[afemale, TranqGun] = 0; 
$ItemMax[afemale, HyperB] = 1; 
$ItemMax[afemale, Fixit] = 1; 
$ItemMax[afemale, Bolt] = 0; 
$ItemMax[afemale, PlatformPack] = 1;

//========================================Armor Items
$ItemMax[afemale, MineAmmo] = 10; 
$ItemMax[afemale, Grenade] = 10; 
$ItemMax[afemale, Beacon] = 6; 
$ItemMax[afemale, Boost] = 4; 
$ItemMax[afemale, Plastique] = 0; 
$ItemMax[afemale, RepairKit] = 2; 

//=========================================Ammo Max
$ItemMax[afemale, BulletAmmo] = 300; 
$ItemMax[afemale, PlasmaAmmo] = 40; 
$ItemMax[afemale, DiscAmmo] = 25; 
$ItemMax[afemale, GrenadeAmmo] = 10; 
$ItemMax[afemale, MortarAmmo] = 10; 
$ItemMax[afemale, RocketAmmo] = 5; 
$ItemMax[afemale, SniperAmmo] = 25; 
$ItemMax[afemale, RailAmmo] = 10; 
$ItemMax[afemale, SilencerAmmo] = 25; 
$ItemMax[afemale, VulcanAmmo] = 300; 
$ItemMax[afemale, TranqAmmo] = 20; 

//=========================================Back Packs
$ItemMax[afemale, EnergyPack] = 1; 
$ItemMax[afemale, RepairPack] = 1; 
$ItemMax[afemale, ShieldPack] = 1; 
$ItemMax[afemale, SensorJammerPack] = 0; 
$ItemMax[afemale, MotionSensorPack] = 1; 
$ItemMax[afemale, PulseSensorPack] = 1; 
$ItemMax[afemale, DeployableSensorJammerPack] = 1; 
$ItemMax[afemale, AmmoPack] = 1; 
$ItemMax[afemale, CloakingDevice] = 0; 
$ItemMax[afemale, StealthShieldPack] = 1; 
$ItemMax[afemale, Laptop] = 1; 
$ItemMax[afemale, RegenerationPack] = 1; 
$ItemMax[afemale, LightningPack] = 0; 
$ItemMax[afemale, OpticPack] = 0; 
$ItemMax[afemale, SMRPack] = 0; 
$ItemMax[afemale, SuicidePack] = 1; 

//==========================================Turrets
$ItemMax[afemale, CameraPack] = 1; 
$ItemMax[afemale, TurretPack] = 0; 
$ItemMax[afemale, LaserTurret] = 0; 
$ItemMax[afemale, RocketPack] = 0; 
$ItemMax[afemale, LaserPack] = 0; 
$ItemMax[afemale, TargetPack] = 0; 
$ItemMax[afemale, ShockPack] = 0; 
$ItemMax[afemale, RailTurret] = 0; 
$ItemMax[afemale, VulcanTurret] = 0; 

//==========================================Deploayables
$ItemMax[afemale, DeployableInvPack] = 1; 
$ItemMax[afemale, DeployableAmmoPack] = 1; 
$ItemMax[afemale, DeployableComPack] = 1; 
$ItemMax[afemale, ForceFieldPack] = 1; 
$ItemMax[afemale, LargeForceFieldPack] = 1; 
$ItemMax[afemale, TeleportPack] = 1; 
$ItemMax[afemale, TripwirePack] = 1; 
$ItemMax[afemale, TreePack] = 1; 
$ItemMax[afemale, SpringPack] = 1; 
$ItemMax[afemale, HoloPack] = 1; 
$ItemMax[afemale, FlagstandPack] = 1;

//==========================================Deployable Vehicles
$ItemMax[afemale, MechPack] = 0;
$ItemMax[afemale, DetPack] = 0; 
$MaxWeapons[afemale] = 4; 








$DamageScale[darmor, $LandingDamageType] = 0.8; 
$DamageScale[darmor, $ImpactDamageType] = 0.8; 
$DamageScale[darmor, $CrushDamageType] = 0.8; 
$DamageScale[darmor, $BulletDamageType] = 0.5; 
$DamageScale[darmor, $PlasmaDamageType] = 0.7; 
$DamageScale[darmor, $EnergyDamageType] = 0.7; 
$DamageScale[darmor, $ExplosionDamageType] = 0.6; 
$DamageScale[darmor, $MissileDamageType] = 0.6; 
$DamageScale[darmor, $DebrisDamageType] = 0.8; 
$DamageScale[darmor, $ShrapnelDamageType] = 0.8; 
$DamageScale[darmor, $LaserDamageType] = 0.6; 
$DamageScale[darmor, $MortarDamageType] = 0.7; 
$DamageScale[darmor, $BlasterDamageType] = 0.7; 
$DamageScale[darmor, $ElectricityDamageType] = 0.8; 
$DamageScale[darmor, $MineDamageType] = 0.8; 
$DamageScale[darmor, $SniperDamageType] = 0.6; 
$DamageScale[darmor, $FlashDamageType] = 1.0; 

$ItemMax[darmor, Blaster] = 1; 
$ItemMax[darmor, Chaingun] = 1; 
$ItemMax[darmor, Disclauncher] = 1; 
$ItemMax[darmor, GrenadeLauncher] = 1; 
$ItemMax[darmor, Mortar] = 1; 
$ItemMax[darmor, PlasmaGun] = 1; 
$ItemMax[darmor, LaserRifle] = 0; 
$ItemMax[darmor, EnergyRifle] = 1; 
$ItemMax[darmor, TargetingLaser] = 1; 
$ItemMax[darmor, MineAmmo] = 25; 
$ItemMax[darmor, Grenade] = 10; 
$ItemMax[darmor, Beacon] = 5; 
$ItemMax[darmor, Boost] = 5; 
$ItemMax[darmor, Plastique] = 0; 
$ItemMax[darmor, RocketLauncher] = 1; 
$ItemMax[darmor, SniperRifle] = 0; 
$ItemMax[darmor, WaveGun] = 1; 
$ItemMax[darmor, Railgun] = 0; 
$ItemMax[darmor, Vulcan] = 1; 
$ItemMax[darmor, Silencer] = 0; 
$ItemMax[darmor, Flamer] = 0; 
$ItemMax[darmor, IonGun] = 0; 
$ItemMax[darmor, Omega] = 0; 
$ItemMax[darmor, TranqGun] = 0; 
$ItemMax[darmor, HyperB] = 0; 
$ItemMax[darmor, Fixit] = 0; 
$ItemMax[darmor, Bolt] = 1; 
$ItemMax[darmor, BulletAmmo] = 150; 
$ItemMax[darmor, PlasmaAmmo] = 50; 
$ItemMax[darmor, DiscAmmo] = 15; 
$ItemMax[darmor, GrenadeAmmo] = 15; 
$ItemMax[darmor, MortarAmmo] = 10; 
$ItemMax[darmor, RocketAmmo] = 10; 
$ItemMax[darmor, SniperAmmo] = 15; 
$ItemMax[darmor, RailAmmo] = 10; 
$ItemMax[darmor, SilencerAmmo] = 25; 
$ItemMax[darmor, VulcanAmmo] = 400; 
$ItemMax[darmor, TranqAmmo] = 20; 
$ItemMax[darmor, EnergyPack] = 1; 
$ItemMax[darmor, RepairPack] = 1; 
$ItemMax[darmor, ShieldPack] = 0; 
$ItemMax[darmor, SensorJammerPack] = 0; 
$ItemMax[darmor, MotionSensorPack] = 1; 
$ItemMax[darmor, PulseSensorPack] = 1; 
$ItemMax[darmor, DeployableSensorJammerPack] = 1; 
$ItemMax[darmor, CameraPack] = 1; 
$ItemMax[darmor, TurretPack] = 1; 
$ItemMax[darmor, AmmoPack] = 1; 
$ItemMax[darmor, RepairKit] = 1; 
$ItemMax[darmor, DeployableInvPack] = 0; 
$ItemMax[darmor, DeployableAmmoPack] = 1; 
$ItemMax[darmor, DeployableComPack] = 1; 
$ItemMax[darmor, LaserTurret] = 1; 
$ItemMax[darmor, ForceFieldPack] = 1; 
$ItemMax[darmor, RocketPack] = 0; 
$ItemMax[darmor, LaserPack] = 0; 
$ItemMax[darmor, CloakingDevice] = 0; 
$ItemMax[darmor, StealthShieldPack] = 1; 
$ItemMax[darmor, FgcPack] = 1; 
$ItemMax[darmor, TargetPack] = 0; 
$ItemMax[darmor, MechPack] = 0; 
$ItemMax[darmor, Laptop] = 0; 
$ItemMax[darmor, ShockPack] = 0; 
$ItemMax[darmor, TeleportPack] = 0; 
$ItemMax[darmor, TripwirePack] = 0; 
$ItemMax[darmor, TreePack] = 0; 
$ItemMax[darmor, SpringPack] = 0; 
$ItemMax[darmor, SuicidePack] = 0; 
$ItemMax[darmor, DetPack] = 0; 
$ItemMax[darmor, HoloPack] = 1; 
$ItemMax[darmor, RegenerationPack] = 0; 
$ItemMax[darmor, LightningPack] = 0; 
$ItemMax[darmor, OpticPack] = 0; 
$ItemMax[darmor, SMRPack] = 1; 
$ItemMax[darmor, RailTurret] = 0; 
$ItemMax[darmor, VulcanTurret] = 0; 
$MaxWeapons[darmor] = 6; 


























//==========================================DEFENDER/SUPER SAJIN

$DamageScale[defarmor, $LandingDamageType] = 0.8; 
$DamageScale[defarmor, $ImpactDamageType] = 0.8; 
$DamageScale[defarmor, $CrushDamageType] = 0.8; 
$DamageScale[defarmor, $BulletDamageType] = 0.5; 
$DamageScale[defarmor, $PlasmaDamageType] = 0.7; 
$DamageScale[defarmor, $EnergyDamageType] = 0.7; 
$DamageScale[defarmor, $ExplosionDamageType] = 0.6; 
$DamageScale[defarmor, $MissileDamageType] = 0.6; 
$DamageScale[defarmor, $DebrisDamageType] = 0.8; 
$DamageScale[defarmor, $ShrapnelDamageType] = 0.8; 
$DamageScale[defarmor, $LaserDamageType] = 0.6; 
$DamageScale[defarmor, $MortarDamageType] = 0.7; 
$DamageScale[defarmor, $BlasterDamageType] = 0.7; 
$DamageScale[defarmor, $ElectricityDamageType] = 0.8; 
$DamageScale[defarmor, $MineDamageType] = 0.8; 
$DamageScale[defarmor, $SniperDamageType] = 0.6; 
$DamageScale[defarmor, $FlashDamageType] = 1.0; 



//=========================================ARMOR ITEMS
$ItemMax[defarmor, MineAmmo] = 25; 
$ItemMax[defarmor, Grenade] = 10; 
$ItemMax[defarmor, Beacon] = 1; 
$ItemMax[defarmor, Boost] = 5; 
$ItemMax[defarmor, Plastique] = 0; 
$ItemMax[defarmor, RepairKit] = 1; 

//=========================================WEAPONS
$ItemMax[defarmor, RocketLauncher] = 1; 
$ItemMax[defarmor, SniperRifle] = 0; 
$ItemMax[defarmor, WaveGun] = 1; 
$ItemMax[defarmor, Railgun] = 0; 
$ItemMax[defarmor, Vulcan] = 1; 
$ItemMax[defarmor, Silencer] = 0; 
$ItemMax[defarmor, Flamer] = 0; 
$ItemMax[defarmor, IonGun] = 0; 
$ItemMax[defarmor, Omega] = 0; 
$ItemMax[defarmor, TranqGun] = 0; 
$ItemMax[defarmor, HyperB] = 0; 
$ItemMax[defarmor, Fixit] = 0; 
$ItemMax[defarmor, Bolt] = 1; 
$ItemMax[defarmor, Blaster] = 1; 
$ItemMax[defarmor, Chaingun] = 1; 
$ItemMax[defarmor, Disclauncher] = 1; 
$ItemMax[defarmor, GrenadeLauncher] = 1; 
$ItemMax[defarmor, Mortar] = 1; 
$ItemMax[defarmor, PlasmaGun] = 1; 
$ItemMax[defarmor, LaserRifle] = 0; 
$ItemMax[defarmor, EnergyRifle] = 1; 
$ItemMax[defarmor, TargetingLaser] = 1; 



//=========================================AMMO
$ItemMax[defarmor, BulletAmmo] = 700; 
$ItemMax[defarmor, PlasmaAmmo] = 100; 
$ItemMax[defarmor, DiscAmmo] = 75; 
$ItemMax[defarmor, GrenadeAmmo] = 50; 
$ItemMax[defarmor, MortarAmmo] = 50; 
$ItemMax[defarmor, RocketAmmo] = 50; 
$ItemMax[defarmor, SniperAmmo] = 15; 
$ItemMax[defarmor, RailAmmo] = 10; 
$ItemMax[defarmor, SilencerAmmo] = 25; 
$ItemMax[defarmor, VulcanAmmo] = 700; 
$ItemMax[defarmor, TranqAmmo] = 20; 


//=========================================BACK PACKS
$ItemMax[defarmor, EnergyPack] = 1; 
$ItemMax[defarmor, RepairPack] = 1; 
$ItemMax[defarmor, ShieldPack] = 0; 
$ItemMax[defarmor, SensorJammerPack] = 0; 
$ItemMax[defarmor, AmmoPack] = 1; 
$ItemMax[defarmor, SuicidePack] = 0; 
$ItemMax[defarmor, HoloPack] = 1; 
$ItemMax[defarmor, RegenerationPack] = 0; 
$ItemMax[defarmor, LightningPack] = 0; 
$ItemMax[defarmor, OpticPack] = 0; 
$ItemMax[defarmor, SMRPack] = 1; 
$ItemMax[defarmor, CloakingDevice] = 0; 
$ItemMax[defarmor, StealthShieldPack] = 1; 
$ItemMax[defarmor, FgcPack] = 1; 
$ItemMax[defarmor, Laptop] = 0; 


//=========================================STATIONS
$ItemMax[defarmor, DeployableInvPack] = 0; 
$ItemMax[defarmor, DeployableAmmoPack] = 0; 
$ItemMax[defarmor, DeployableComPack] = 0; 

//=========================================DEPLOYABLES
$ItemMax[defarmor, ForceFieldPack] = 1; 
$ItemMax[defarmor, TeleportPack] = 0; 
$ItemMax[defarmor, TripwirePack] = 0; 
$ItemMax[defarmor, TreePack] = 0; 
$ItemMax[defarmor, SpringPack] = 0; 


//=========================================VEHICLES
$ItemMax[defarmor, DetPack] = 0; 
$ItemMax[defarmor, MechPack] = 0;

//=========================================SENSORS
$ItemMax[defarmor, MotionSensorPack] = 1; 
$ItemMax[defarmor, PulseSensorPack] = 1; 
$ItemMax[defarmor, DeployableSensorJammerPack] = 1; 

//=========================================TURRETS
$ItemMax[defarmor, CameraPack] = 1; 
$ItemMax[defarmor, TurretPack] = 1; 
$ItemMax[defarmor, LaserTurret] = 1; 
$ItemMax[defarmor, ShockPack] = 0; 
$ItemMax[defarmor, RailTurret] = 0; 
$ItemMax[defarmor, VulcanTurret] = 0; 
$ItemMax[defarmor, RocketPack] = 0; 
$ItemMax[defarmor, LaserPack] = 0; 
$ItemMax[defarmor, TargetPack] = 0; 
 


$MaxWeapons[defarmor] = 6; 




//===============================================================








$DamageScale[harmor, $LandingDamageType] = 0.7; 
$DamageScale[harmor, $ImpactDamageType] = 0.5; 
$DamageScale[harmor, $CrushDamageType] = 1.0; 
$DamageScale[harmor, $BulletDamageType] = 0.3; 
$DamageScale[harmor, $PlasmaDamageType] = 0.1; 
$DamageScale[harmor, $EnergyDamageType] = 0.7; 
$DamageScale[harmor, $ExplosionDamageType] = 0.6; 
$DamageScale[harmor, $MissileDamageType] = 0.3; 
$DamageScale[harmor, $DebrisDamageType] = 0.5; 
$DamageScale[harmor, $ShrapnelDamageType] = 0.5; 
$DamageScale[harmor, $LaserDamageType] = 0.6; 
$DamageScale[harmor, $MortarDamageType] = 0.7; 
$DamageScale[harmor, $BlasterDamageType] = 0.7; 
$DamageScale[harmor, $ElectricityDamageType] = 1.5; 
$DamageScale[harmor, $MineDamageType] = 0.8; 
$DamageScale[harmor, $SniperDamageType] = 0.6; 
$DamageScale[harmor, $FlashDamageType] = 1.0; 

$ItemMax[harmor, Blaster] = 1; 
$ItemMax[harmor, Chaingun] = 1; 
$ItemMax[harmor, Disclauncher] = 1; 
$ItemMax[harmor, GrenadeLauncher] = 1; 
$ItemMax[harmor, Mortar] = 1; 
$ItemMax[harmor, PlasmaGun] = 1; 
$ItemMax[harmor, LaserRifle] = 0; 
$ItemMax[harmor, EnergyRifle] = 1; 
$ItemMax[harmor, TargetingLaser] = 1; 
$ItemMax[harmor, MineAmmo] = 3; 
$ItemMax[harmor, Grenade] = 1; 
$ItemMax[harmor, Beacon] = 5; 
$ItemMax[harmor, Boost] = 5; 
$ItemMax[harmor, Plastique] = 0; 
$ItemMax[harmor, RocketLauncher] = 0; 
$ItemMax[harmor, SniperRifle] = 0; 
$ItemMax[harmor, WaveGun] = 0; 
$ItemMax[harmor, Railgun] = 0; 
$ItemMax[harmor, Vulcan] = 1; 
$ItemMax[harmor, Silencer] = 0; 
$ItemMax[harmor, Flamer] = 0; 
$ItemMax[harmor, IonGun] = 0; 
$ItemMax[harmor, Omega] = 1; 
$ItemMax[harmor, TranqGun] = 0; 
$ItemMax[harmor, HyperB] = 0; 
$ItemMax[harmor, Fixit] = 0; 
$ItemMax[harmor, Bolt] = 0; 
$ItemMax[harmor, BulletAmmo] = 200; 
$ItemMax[harmor, PlasmaAmmo] = 50; 
$ItemMax[harmor, DiscAmmo] = 15; 
$ItemMax[harmor, GrenadeAmmo] = 15; 
$ItemMax[harmor, MortarAmmo] = 10; 
$ItemMax[harmor, RocketAmmo] = 5; 
$ItemMax[harmor, SniperAmmo] = 15; 
$ItemMax[harmor, RailAmmo] = 10; 
$ItemMax[harmor, SilencerAmmo] = 25; 
$ItemMax[harmor, VulcanAmmo] = 400; 
$ItemMax[harmor, TranqAmmo] = 20; 
$ItemMax[harmor, EnergyPack] = 1; 
$ItemMax[harmor, RepairPack] = 1; 
$ItemMax[harmor, ShieldPack] = 1; 
$ItemMax[harmor, SensorJammerPack] = 1; 
$ItemMax[harmor, MotionSensorPack] = 1; 
$ItemMax[harmor, PulseSensorPack] = 1; 
$ItemMax[harmor, DeployableSensorJammerPack] = 1; 
$ItemMax[harmor, CameraPack] = 0; 
$ItemMax[harmor, TurretPack] = 1; 
$ItemMax[harmor, AmmoPack] = 1; 
$ItemMax[harmor, RepairKit] = 1; 
$ItemMax[harmor, DeployableInvPack] = 0; 
$ItemMax[harmor, DeployableAmmoPack] = 1; 
$ItemMax[harmor, DeployableComPack] = 1; 
$ItemMax[harmor, LaserTurret] = 0; 
$ItemMax[harmor, ForceFieldPack] = 1; 
$ItemMax[harmor, RocketPack] = 0; 
$ItemMax[harmor, LaserPack] = 0; 
$ItemMax[harmor, CloakingDevice] = 0; 
$ItemMax[harmor, StealthShieldPack] = 0; 
$ItemMax[harmor, TargetPack] = 0; 
$ItemMax[harmor, MechPack] = 0; 
$ItemMax[harmor, Laptop] = 0; 
$ItemMax[harmor, ShockPack] = 0; 
$ItemMax[harmor, TeleportPack] = 0; 
$ItemMax[harmor, TripwirePack] = 0; 
$ItemMax[harmor, TreePack] = 0; 
$ItemMax[harmor, SpringPack] = 0; 
$ItemMax[harmor, SuicidePack] = 0; 
$ItemMax[harmor, DetPack] = 0; 
$ItemMax[harmor, HoloPack] = 1; 
$ItemMax[harmor, RegenerationPack] = 1; 
$ItemMax[harmor, LightningPack] = 0; 
$ItemMax[harmor, OpticPack] = 0; 
$ItemMax[harmor, SMRPack] = 0; 
$ItemMax[harmor, RailTurret] = 0; 
$ItemMax[harmor, VulcanTurret] = 0; 
$MaxWeapons[harmor] = 5; 









$DamageScale[dmarmor, $LandingDamageType] = 1.0; 
$DamageScale[dmarmor, $ImpactDamageType] = 1.0; 
$DamageScale[dmarmor, $CrushDamageType] = 1.0; 
$DamageScale[dmarmor, $BulletDamageType] = 1.0; 
$DamageScale[dmarmor, $PlasmaDamageType] = 1.0; 
$DamageScale[dmarmor, $EnergyDamageType] = 1.0; 
$DamageScale[dmarmor, $ExplosionDamageType] = 1.0; 
$DamageScale[dmarmor, $MissileDamageType] = 1.0; 
$DamageScale[dmarmor, $ShrapnelDamageType] = 1.0; 
$DamageScale[dmarmor, $DebrisDamageType] = 1.0; 
$DamageScale[dmarmor, $LaserDamageType] = 1.0; 
$DamageScale[dmarmor, $MortarDamageType] = 1.0; 
$DamageScale[dmarmor, $BlasterDamageType] = 1.0; 
$DamageScale[dmarmor, $ElectricityDamageType] = 1.0; 
$DamageScale[dmarmor, $MineDamageType] = 1.0; 
$DamageScale[dmarmor, $SniperDamageType] = 1.0; 
$DamageScale[dmarmor, $FlashDamageType] = 1.0; 

$ItemMax[dmarmor, Blaster] = 1; $ItemMax[dmarmor, Chaingun] = 1; $ItemMax[dmarmor, Disclauncher] = 1; $ItemMax[dmarmor, GrenadeLauncher] = 1; $ItemMax[dmarmor, Mortar] = 0; $ItemMax[dmarmor, PlasmaGun] = 1; $ItemMax[dmarmor, LaserRifle] = 1; $ItemMax[dmarmor, EnergyRifle] = 1; $ItemMax[dmarmor, TargetingLaser] = 1; $ItemMax[dmarmor, MineAmmo] = 3; $ItemMax[dmarmor, Grenade] = 6; $ItemMax[dmarmor, Beacon] = 1; $ItemMax[dmarmor, Boost] = 4; $ItemMax[dmarmor, Plastique] = 1; $ItemMax[dmarmor, RocketLauncher] = 1; $ItemMax[dmarmor, SniperRifle] = 0; $ItemMax[dmarmor, WaveGun] = 0; $ItemMax[dmarmor, Railgun] = 1; $ItemMax[dmarmor, Vulcan] = 1; $ItemMax[dmarmor, Silencer] = 0; $ItemMax[dmarmor, Flamer] = 1; $ItemMax[dmarmor, IonGun] = 1; $ItemMax[dmarmor, Omega] = 1; $ItemMax[dmarmor, TranqGun] = 1; $ItemMax[dmarmor, HyperB] = 1; $ItemMax[dmarmor, Fixit] = 0; $ItemMax[dmarmor, Bolt] = 1; $ItemMax[dmarmor, BulletAmmo] = 150; $ItemMax[dmarmor, PlasmaAmmo] = 40; $ItemMax[dmarmor, DiscAmmo] = 15; $ItemMax[dmarmor, GrenadeAmmo] = 10; $ItemMax[dmarmor, MortarAmmo] = 10; $ItemMax[dmarmor, RocketAmmo] = 5; $ItemMax[dmarmor, SniperAmmo] = 15; $ItemMax[dmarmor, RailAmmo] = 10; $ItemMax[dmarmor, SilencerAmmo] = 25; $ItemMax[dmarmor, VulcanAmmo] = 200; $ItemMax[dmarmor, TranqAmmo] = 10; $ItemMax[dmarmor, EnergyPack] = 1; $ItemMax[dmarmor, RepairPack] = 1; $ItemMax[dmarmor, ShieldPack] = 1; $ItemMax[dmarmor, SensorJammerPack] = 0; $ItemMax[dmarmor, MotionSensorPack] = 0; $ItemMax[dmarmor, PulseSensorPack] = 0; $ItemMax[dmarmor, DeployableSensorJammerPack] = 0; $ItemMax[dmarmor, CameraPack] = 0; $ItemMax[dmarmor, TurretPack] = 0; $ItemMax[dmarmor, AmmoPack] = 1; $ItemMax[dmarmor, RepairKit] = 1; $ItemMax[dmarmor, DeployableInvPack] = 1; $ItemMax[dmarmor, DeployableAmmoPack] = 0; $ItemMax[dmarmor, DeployableComPack] = 0; $ItemMax[dmarmor, LaserTurret] = 1; $ItemMax[dmarmor, ForceFieldPack] = 1; $ItemMax[dmarmor, RocketPack] = 0; $ItemMax[dmarmor, LaserPack] = 0; $ItemMax[dmarmor, CloakingDevice] = 0; $ItemMax[dmarmor, StealthShieldPack] = 0; $ItemMax[dmarmor, TargetPack] = 0; $ItemMax[dmarmor, MechPack] = 0; $ItemMax[dmarmor, Laptop] = 0; $ItemMax[dmarmor, ShockPack] = 0; $ItemMax[dmarmor, TeleportPack] = 1; $ItemMax[dmarmor, TripwirePack] = 0; $ItemMax[dmarmor, TreePack] = 0; $ItemMax[dmarmor, SpringPack] = 1; $ItemMax[dmarmor, SuicidePack] = 0; $ItemMax[dmarmor, DetPack] = 0; $ItemMax[dmarmor, HoloPack] = 1; $ItemMax[dmarmor, RegenerationPack] = 1; $ItemMax[dmarmor, LightningPack] = 1; $ItemMax[dmarmor, OpticPack] = 1; $ItemMax[dmarmor, SMRPack] = 1; $ItemMax[dmarmor, RailTurret] = 1; $ItemMax[dmarmor, VulcanTurret] = 1; $ItemMax[dmarmor, PlatformPack] = 1; $MaxWeapons[dmarmor] = 4; 



$DamageScale[dmfemale, $LandingDamageType] = 1.0; 
$DamageScale[dmfemale, $ImpactDamageType] = 1.0; 
$DamageScale[dmfemale, $CrushDamageType] = 1.0; 
$DamageScale[dmfemale, $BulletDamageType] = 1.0; 
$DamageScale[dmfemale, $PlasmaDamageType] = 1.0; 
$DamageScale[dmfemale, $EnergyDamageType] = 1.0; 
$DamageScale[dmfemale, $ExplosionDamageType] = 1.0; 
$DamageScale[dmfemale, $MissileDamageType] = 1.0; 
$DamageScale[dmfemale, $ShrapnelDamageType] = 1.0; 
$DamageScale[dmfemale, $DebrisDamageType] = 1.0; 
$DamageScale[dmfemale, $LaserDamageType] = 1.0; 
$DamageScale[dmfemale, $MortarDamageType] = 1.0; 
$DamageScale[dmfemale, $BlasterDamageType] = 1.0; 
$DamageScale[dmfemale, $ElectricityDamageType] = 1.0; 
$DamageScale[dmfemale, $MineDamageType] = 1.0; 
$DamageScale[dmfemale, $SniperDamageType] = 1.0; 
$DamageScale[dmfemale, $FlashDamageType] = 1.0; 

$ItemMax[dmfemale, Blaster] = 1; $ItemMax[dmfemale, Chaingun] = 1; $ItemMax[dmfemale, Disclauncher] = 1; $ItemMax[dmfemale, GrenadeLauncher] = 1; $ItemMax[dmfemale, Mortar] = 0; $ItemMax[dmfemale, PlasmaGun] = 1; $ItemMax[dmfemale, LaserRifle] = 1; $ItemMax[dmfemale, EnergyRifle] = 1; $ItemMax[dmfemale, TargetingLaser] = 1; $ItemMax[dmfemale, MineAmmo] = 3; $ItemMax[dmfemale, Grenade] = 6; $ItemMax[dmfemale, Beacon] = 1; $ItemMax[dmfemale, Boost] = 4; $ItemMax[dmfemale, Plastique] = 1; $ItemMax[dmfemale, RocketLauncher] = 1; $ItemMax[dmfemale, SniperRifle] = 0; $ItemMax[dmfemale, WaveGun] = 0; $ItemMax[dmfemale, Railgun] = 1; $ItemMax[dmfemale, Vulcan] = 1; $ItemMax[dmfemale, Silencer] = 0; $ItemMax[dmfemale, Flamer] = 1; $ItemMax[dmfemale, IonGun] = 1; $ItemMax[dmfemale, Omega] = 1; $ItemMax[dmfemale, TranqGun] = 1; $ItemMax[dmfemale, HyperB] = 1; $ItemMax[dmfemale, Fixit] = 0; $ItemMax[dmfemale, Bolt] = 1; $ItemMax[dmfemale, BulletAmmo] = 150; $ItemMax[dmfemale, PlasmaAmmo] = 40; $ItemMax[dmfemale, DiscAmmo] = 15; $ItemMax[dmfemale, GrenadeAmmo] = 10; $ItemMax[dmfemale, MortarAmmo] = 10; $ItemMax[dmfemale, RocketAmmo] = 3; $ItemMax[dmfemale, SniperAmmo] = 15; $ItemMax[dmfemale, RailAmmo] = 10; $ItemMax[dmfemale, SilencerAmmo] = 25; $ItemMax[dmfemale, VulcanAmmo] = 200; $ItemMax[dmfemale, TranqAmmo] = 10; $ItemMax[dmfemale, EnergyPack] = 1; $ItemMax[dmfemale, RepairPack] = 1; $ItemMax[dmfemale, ShieldPack] = 1; $ItemMax[dmfemale, SensorJammerPack] = 0; $ItemMax[dmfemale, MotionSensorPack] = 0; $ItemMax[dmfemale, PulseSensorPack] = 0; $ItemMax[dmfemale, DeployableSensorJammerPack] = 0; $ItemMax[dmfemale, CameraPack] = 0; $ItemMax[dmfemale, TurretPack] = 0; $ItemMax[dmfemale, AmmoPack] = 1; $ItemMax[dmfemale, RepairKit] = 1; $ItemMax[dmfemale, DeployableInvPack] = 1; $ItemMax[dmfemale, DeployableAmmoPack] = 0; $ItemMax[dmfemale, DeployableComPack] = 0; $ItemMax[dmfemale, LaserTurret] = 1; $ItemMax[dmfemale, ForceFieldPack] = 1; $ItemMax[dmfemale, RocketPack] = 0; $ItemMax[dmfemale, LaserPack] = 0; $ItemMax[dmfemale, CloakingDevice] = 0; $ItemMax[dmfemale, StealthShieldPack] = 0; $ItemMax[dmfemale, TargetPack] = 0; $ItemMax[dmfemale, MechPack] = 0; $ItemMax[dmfemale, Laptop] = 0; $ItemMax[dmfemale, ShockPack] = 0; $ItemMax[dmfemale, TeleportPack] = 1; $ItemMax[dmfemale, TripwirePack] = 0; $ItemMax[dmfemale, TreePack] = 0; $ItemMax[dmfemale, SpringPack] = 1; $ItemMax[dmfemale, SuicidePack] = 0; $ItemMax[dmfemale, DetPack] = 0; $ItemMax[dmfemale, HoloPack] = 1; $ItemMax[dmfemale, RegenerationPack] = 1; $ItemMax[dmfemale, LightningPack] = 1; $ItemMax[dmfemale, OpticPack] = 1; $ItemMax[dmfemale, SMRPack] = 1; $ItemMax[dmfemale, RailTurret] = 1; $ItemMax[dmfemale, VulcanTurret] = 1; $ItemMax[dmfemale, PlatformPack] = 1; $MaxWeapons[dmfemale] = 4; 






DamageSkinData armorDamageSkins { 
bmpName[0] = "dskin1_armor"; 
bmpName[1] = "dskin2_armor"; 
bmpName[2] = "dskin3_armor"; 
bmpName[3] = "dskin4_armor"; 
bmpName[4] = "dskin5_armor"; 
bmpName[5] = "dskin6_armor"; 
bmpName[6] = "dskin7_armor"; 
bmpName[7] = "dskin8_armor"; 
bmpName[8] = "dskin9_armor"; 
bmpName[9] = "dskin10_armor"; 
}; 











//=====================================================================
//:::::::::::::::::::::::::::::SCOUT:::::::::::::::::::::::::::::::::::
//=====================================================================

PlayerData sarmor 
{ 
className = "Armor"; 
shapeFile = "larmor"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
flameShapeName = "lflame"; 
shieldShapeName = "shield"; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
canCrouch = true; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 150; 
minJetEnergy = 1; 
jetForce = 450; 
jetEnergyDrain = 0.1; 
maxDamage = 0.66; 
maxForwardSpeed = 10; 
maxBackwardSpeed = 10; 
maxSideSpeed = 10; 
groundForce = 40 * 9.0; 
mass = 9.0; 
groundTraction = 4.0; 
maxEnergy = 30; 
drag = 1.0; 
density = 1.2; 
minDamageSpeed = 125; 
damageScale = 0.005; 
jumpImpulse = 95; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft }; lFootSounds = { SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft }; footPrints = { 0, 1 }; boxWidth = 0.5; boxDepth = 0.5; boxNormalHeight = 2.2; boxCrouchHeight = 1.8; boxNormalHeadPercentage = 0.83; boxNormalTorsoPercentage = 0.53; boxCrouchHeadPercentage = 0.6666; boxCrouchTorsoPercentage = 0.3333; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 



//=====================================================================
//:::::::::::::::::::::::::::::SCOUT::FEMALE:::::::::::::::::::::::::::
//=====================================================================

PlayerData sfemale 
{ 
className = "Armor"; 
shapeFile = "lfemale"; 
flameShapeName = "lflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
canCrouch = true; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 150; 
minJetEnergy = 1; 
jetForce = 450; 
jetEnergyDrain = 0.1; 
maxDamage = 0.66; 
maxForwardSpeed = 10; 
maxBackwardSpeed = 10; 
maxSideSpeed = 10; 
groundForce = 40 * 9.0; 
mass = 9.0; 
groundTraction = 4.0; 
maxEnergy = 60; 
drag = 1.0; 
density = 1.2; 
minDamageSpeed = 125; 
damageScale = 0.005; 
jumpImpulse = 95; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft }; lFootSounds = { SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft }; footPrints = { 0, 1 }; boxWidth = 0.5; boxDepth = 0.5; boxNormalHeight = 2.2; boxCrouchHeight = 1.8; boxNormalHeadPercentage = 0.85; boxNormalTorsoPercentage = 0.53; boxCrouchHeadPercentage = 0.88; boxCrouchTorsoPercentage = 0.35; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 



//=====================================================================
//:::::::::::::::::::::::::::::SPY:::::::::::::::::::::::::::::::::::::
//=====================================================================

PlayerData spyarmor 
{ 
className = "Armor"; 
shapeFile = "larmor"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
flameShapeName = "lflame"; 
shieldShapeName = "shield"; 
shadowDetailMask = 1; 
visibleToSensor = false; 
mapFilter = 1; 
mapIcon = "M_player"; 
canCrouch = true; 
maxJetSideForceFactor = 1.2; 
maxJetForwardVelocity = 142; 
minJetEnergy = 1; 
jetForce = 250; 
jetEnergyDrain = 0.5; 
maxDamage = 0.66; 
maxForwardSpeed = 25; 
maxBackwardSpeed = 25; 
maxSideSpeed = 25; 
groundForce = 40 * 9.0; 
mass = 7.0; 
groundTraction = 19.0; 
maxEnergy = 30; 
drag = 1.0; 
density = 1.2; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 80; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft }; lFootSounds = { SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft }; footPrints = { 0, 1 }; boxWidth = 0.5; boxDepth = 0.5; boxNormalHeight = 2.2; boxCrouchHeight = 1.8; boxNormalHeadPercentage = 0.83; boxNormalTorsoPercentage = 0.53; boxCrouchHeadPercentage = 0.6666; boxCrouchTorsoPercentage = 0.3333; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 





//=====================================================================
//:::::::::::::::::::::::::::::SPY::FEMALE:::::::::::::::::::::::::::::
//=====================================================================


PlayerData spyfemale 
{ 
className = "Armor"; 
shapeFile = "lfemale"; 
flameShapeName = "lflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = false; 
mapFilter = 1; 
mapIcon = "M_player"; 
canCrouch = true; 
maxJetSideForceFactor = 1.2; 
maxJetForwardVelocity = 142; 
minJetEnergy = 1; 
jetForce = 250; 
jetEnergyDrain = 0.5; 
maxDamage = 0.66; 
maxForwardSpeed = 25; 
maxBackwardSpeed = 25; 
maxSideSpeed = 25; 
groundForce = 40 * 9.0; 
mass = 7.0; 
groundTraction = 19.0; 
maxEnergy = 30; 
drag = 1.0; 
density = 1.2; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 80; 
jumpSurfaceMinDot = 0.2; 

animData[0] = { "root", none, 1, true, true, true, false, 0 }; animData[1] = { "run", none, 1, true, false, true, false, 3 }; animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft }; lFootSounds = { SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft }; footPrints = { 0, 1 }; boxWidth = 0.5; boxDepth = 0.5; boxNormalHeight = 2.2; boxCrouchHeight = 1.8; boxNormalHeadPercentage = 0.85; boxNormalTorsoPercentage = 0.53; boxCrouchHeadPercentage = 0.88; boxCrouchTorsoPercentage = 0.35; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 





//=====================================================================
//:::::::::::::::::::::::::::::SNIPER::::::::::::::::::::::::::::::::::
//=====================================================================






PlayerData larmor { 
className = "Armor"; 
shapeFile = "larmor"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
flameShapeName = "lflame"; 
shieldShapeName = "shield"; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
canCrouch = true; 
maxJetSideForceFactor = 12; 
maxJetForwardVelocity = 22; 
minJetEnergy = 1; 
jetForce = 236; 
jetEnergyDrain = 1.4; 
maxDamage = 0.66; 
maxForwardSpeed = 20; 
maxBackwardSpeed = 20; 
maxSideSpeed = 20; 
groundForce = 40 * 9.0; 
mass = 9.0; 
groundTraction = 3.0; 
maxEnergy = 125; 
drag = 1.0; 
density = 1.2; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 120; 
jumpSurfaceMinDot = 0.2; 
animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 

jetSound = SoundJetLight; 
rFootSounds = { 
SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft 
}; 
lFootSounds = 
{ 
SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft 
};
 footPrints = { 0, 1 }; 
boxWidth = 0.5; 
boxDepth = 0.5; 
boxNormalHeight = 2.2; 
boxCrouchHeight = 1.8; 
boxNormalHeadPercentage = 0.83; 
boxNormalTorsoPercentage = 0.53; 
boxCrouchHeadPercentage = 0.6666; 
boxCrouchTorsoPercentage = 0.3333; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
}; 



PlayerData lfemale 
{ 
className = "Armor"; 
shapeFile = "lfemale"; 
flameShapeName = "lflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
canCrouch = true; 
maxJetSideForceFactor = 12; 
maxJetForwardVelocity = 22; 
minJetEnergy = 1; 
jetForce = 236; 
jetEnergyDrain = 1.4; 
maxDamage = 0.66; 
maxForwardSpeed = 20; 
maxBackwardSpeed = 20; 
maxSideSpeed = 20; 
groundForce = 40 * 9.0; 
mass = 9.0; 
groundTraction = 3.0; 
maxEnergy = 125; 
drag = 1.0; 
density = 1.2; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 120; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; animData[1] = { "run", none, 1, true, false, true, false, 3 }; animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft }; lFootSounds = { SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft }; footPrints = { 0, 1 }; boxWidth = 0.5; boxDepth = 0.5; boxNormalHeight = 2.2; boxCrouchHeight = 1.8; boxNormalHeadPercentage = 0.85; boxNormalTorsoPercentage = 0.53; boxCrouchHeadPercentage = 0.88; boxCrouchTorsoPercentage = 0.35; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 







PlayerData marmor 
{ 
className = "Armor"; 
shapeFile = "marmor"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
canCrouch = false; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 325; 
jetEnergyDrain = 1.0; 
maxDamage = 10.0; 
maxForwardSpeed = 9.0; 
maxBackwardSpeed = 7.0; 
maxSideSpeed = 7.0; 
groundForce = 35 * 13.0; 
mass = 13.0; 
groundTraction = 3.0; 
maxEnergy = 90; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2; 

animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; 
animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; 
animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; 
animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 
jetSound = SoundJetLight; 
rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; 
lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; 
footPrints = { 2, 3 }; 
boxWidth = 0.7; 
boxDepth = 0.7; 
boxNormalHeight = 2.4; 
boxNormalHeadPercentage = 0.95; 
boxNormalTorsoPercentage = 0.49; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
}; 




PlayerData mfemale 
{ 
className = "Armor"; 
shapeFile = "mfemale"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 325; 
jetEnergyDrain = 1.0; 
canCrouch = false; 
maxDamage = 10.0; 
maxForwardSpeed = 9.0; 
maxBackwardSpeed = 7.0; 
maxSideSpeed = 7.0; 
groundForce = 35 * 13.0; 
mass = 13.0; 
groundTraction = 3.0; 
maxEnergy = 90; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2; 

animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; 
animData[7] = { "crouch root", none, 1, true, false, true, false, 3 }; 
animData[8] = { "crouch root", none, 1, true, false, true, false, 3 }; 
animData[9] = { "crouch root", none, -1, true, false, true, false, 3 }; 
animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; 
animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 
jetSound = SoundJetLight; 
rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; 
lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; 
footPrints = { 2, 3 }; 
boxWidth = 0.7; 
boxDepth = 0.7; 
boxNormalHeight = 2.4; 
boxNormalHeadPercentage = 0.95; 
boxNormalTorsoPercentage = 0.55; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
}; 




//=====================================================================
//:::::::::::::::::::::::::::::BURSTER:::::::::::::::::::::::::::::::::
//=====================================================================

PlayerData barmor 
{ 
className = "Armor"; 
shapeFile = "marmor"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
canCrouch = false; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 77; 
minJetEnergy = 1; 
jetForce = 400; 
jetEnergyDrain = 1.0; 
maxDamage = 1.0; 
maxForwardSpeed = 8.0; 
maxBackwardSpeed = 7.0; 
maxSideSpeed = 7.0; 
groundForce = 35 * 13.0; 
mass = 16.0; 
groundTraction = 3.0; 
maxEnergy = 90; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; 
animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 
jetSound = SoundJetLight; 
rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; 
lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; 
footPrints = { 2, 3 }; 
boxWidth = 0.7; 
boxDepth = 0.7; 
boxNormalHeight = 2.4; 
boxNormalHeadPercentage = 0.83; 
boxNormalTorsoPercentage = 0.49; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
}; 



//=====================================================================
//:::::::::::::::::::::::::::::BURSTER::FEMALE:::::::::::::::::::::::::
//=====================================================================

PlayerData bfemale 
{ 
className = "Armor"; 
shapeFile = "mfemale"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 77; 
minJetEnergy = 1; 
jetForce = 400; 
jetEnergyDrain = 1.0; 
canCrouch = false; 
maxDamage = 1.0; 
maxForwardSpeed = 8.0; 
maxBackwardSpeed = 7.0; 
maxSideSpeed = 7.0; 
groundForce = 35 * 13.0; 
mass = 16.0; 
groundTraction = 3.0; 
maxEnergy = 90; 
mass = 16.0; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, false, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, false, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, false, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; 
rFootSounds = 
{ 
SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft 
}; 
lFootSounds = 
{ 
SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; footPrints = { 2, 3 }; 
boxWidth = 0.7; 
boxDepth = 0.7; 
boxNormalHeight = 2.4; 
boxNormalHeadPercentage = 0.84; 
boxNormalTorsoPercentage = 0.55; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
}; 


//=====================================================================
//:::::::::::::::::::::::::::::ENGINEER::::::::::::::::::::::::::::::::
//=====================================================================

PlayerData earmor 
{ 
className = "Armor"; 
shapeFile = "marmor"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
canCrouch = false; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 425; 
jetEnergyDrain = 0.0; 
maxDamage = 1.0; 
maxForwardSpeed = 8.0; 
maxBackwardSpeed = 7.0; 
maxSideSpeed = 7.0; 
groundForce = 35 * 13.0; 
mass = 13.0; 
groundTraction = 3.0; 
maxEnergy = 90; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2;

 
animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; 
animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; 
animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; 
animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; 
animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; 
animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; 
animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; 
animData[21] = { "throw", none, 1, true, false, false, false, 3 }; 
animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; 
animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; 
animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; 
animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; 
animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; 
animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; 
animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; 
animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; 
animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 
jetSound = SoundJetLight; 
rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; footPrints = { 2, 3 }; boxWidth = 0.7; boxDepth = 0.7; boxNormalHeight = 2.4; boxNormalHeadPercentage = 0.83; boxNormalTorsoPercentage = 0.49; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 
























//=====================================================================
//:::::::::::::::::::::::::::::ENGINEER::FEMALE::::::::::::::::::::::::
//=====================================================================

PlayerData efemale 
{ 
className = "Armor"; 
shapeFile = "mfemale"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 325; 
jetEnergyDrain = 1.0; 
canCrouch = true; 
maxDamage = 1.0; 
maxForwardSpeed = 8.0; 
maxBackwardSpeed = 7.0; 
maxSideSpeed = 7.0; 
groundForce = 35 * 13.0; 
mass = 13.0; 
groundTraction = 3.0; 
maxEnergy = 90; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2; 

animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; 
animData[7] = { "crouch root", none, 1, true, false, true, false, 3 }; 
animData[8] = { "crouch root", none, 1, true, false, true, false, 3 }; 
animData[9] = { "crouch root", none, -1, true, false, true, false, 3 }; 
animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; footPrints = { 2, 3 }; boxWidth = 0.7; boxDepth = 0.7; boxNormalHeight = 2.4; boxNormalHeadPercentage = 0.84; boxNormalTorsoPercentage = 0.55; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 



//=====================================================================
//:::::::::::::::::::::::::::::FLAG:MOVER::::::::::::::::::::::::::::::
//=====================================================================

PlayerData aarmor 
{ 
className = "Armor"; 
shapeFile = "marmor"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
canCrouch = true; 
visibleToSensor = False; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 325; 
jetEnergyDrain = 1.2; 
maxDamage = 1.0; 
maxForwardSpeed = 9.0; 
maxBackwardSpeed = 8.0; 
maxSideSpeed = 8.0; 
groundForce = 35 * 13.0; 
mass = 15.0; 
groundTraction = 3.0; 
maxEnergy = 200; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2; 

animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; footPrints = { 2, 3 }; boxWidth = 0.7; boxDepth = 0.7; boxNormalHeight = 2.4; boxNormalHeadPercentage = 0.83; boxNormalTorsoPercentage = 0.49; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 




//=====================================================================
//:::::::::::::::::::::::::FLAG:MOVER::FEMALE::::::::::::::::::::::::::
//=====================================================================

PlayerData afemale 
{ 
className = "Armor"; 
shapeFile = "mfemale"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 325; 
jetEnergyDrain = 1.2; 
canCrouch = true; 
maxDamage = 1.0; 
maxForwardSpeed = 9.0; 
maxBackwardSpeed = 8.0; 
maxSideSpeed = 8.0; 
groundForce = 35 * 13.0; 
mass = 15.0; 
groundTraction = 3.0; 
maxEnergy = 200; 
drag = 1.0; 
density = 1.5; 
minDamageSpeed = 25; 
damageScale = 0.005; 
jumpImpulse = 110; 
jumpSurfaceMinDot = 0.2;
 
animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; 
animData[7] = { "crouch root", none, 1, true, false, true, false, 3 }; 
animData[8] = { "crouch root", none, 1, true, false, true, false, 3 }; 
animData[9] = { "crouch root", none, -1, true, false, true, false, 3 }; 
animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; 
animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; 
animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; 
animData[21] = { "throw", none, 1, true, false, false, false, 3 }; 
animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; 
animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; 
animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; 
animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; 
animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; 
animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; 
animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; 
animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; 
animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 
jetSound = SoundJetLight; 
rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; 
lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; 
footPrints = { 2, 3 }; 
boxWidth = 0.7; 
boxDepth = 0.7; 
boxNormalHeight = 2.4; 
boxNormalHeadPercentage = 0.84; 
boxNormalTorsoPercentage = 0.55; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
}; 



//=====================================================================
//:::::::::::::::::::::::::::::CYBORG::::::::::::::::::::::::::::::::::
//=====================================================================

PlayerData darmor 
{ 
className = "Armor"; 
shapeFile = "harmor"; 
flameShapeName = "hflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 30; 
minJetEnergy = 1; 
jetForce = 395; 
jetEnergyDrain = 1.1; 
maxDamage = 1.60; 
maxForwardSpeed = 6.0; 
maxBackwardSpeed = 5.0; 
maxSideSpeed = 4.0; 
groundForce = 35 * 18.0; 
groundTraction = 4.5; 
mass = 19.0; 
maxEnergy = 300; 
drag = 1.0; 
density = 2.5; 
canCrouch = false; 
minDamageSpeed = 25; 
damageScale = 0.006; 
jumpImpulse = 200; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; 
animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; 
animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; 
animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; 
animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; 
animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; 
animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; 
animData[21] = { "throw", none, 1, true, false, false, false, 3 }; 
animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; 
animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; 
animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; 
animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; 
animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; 
animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; 
animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; 
animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; 
animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 
jetSound = SoundJetHeavy; 
rFootSounds = { SoundHFootRSoft, SoundHFootRHard, SoundHFootRSoft, SoundHFootRHard, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRHard, SoundHFootRSnow, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft }; 
lFootSounds = { SoundHFootLSoft, SoundHFootLHard, SoundHFootLSoft, SoundHFootLHard, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLHard, SoundHFootLSnow, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft }; 
footPrints = { 4, 5 }; 
boxWidth = 0.8; 
boxDepth = 0.8; 
boxNormalHeight = 2.6; 
boxNormalHeadPercentage = 0.70; 
boxNormalTorsoPercentage = 0.45; 
boxHeadLeftPercentage = 0.48; 
boxHeadRightPercentage = 0.70; 
boxHeadBackPercentage = 0.48; 
boxHeadFrontPercentage = 0.60; 
}; 




































PlayerData harmor 
{ 
className = "Armor"; 
shapeFile = "harmor"; 
flameShapeName = "hflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 12; 
minJetEnergy = 1; 
jetForce = 390; 
jetEnergyDrain = 1.1; 
maxDamage = 1.32; 
maxForwardSpeed = 6.0; 
maxBackwardSpeed = 5.0; 
maxSideSpeed = 4.0; 
groundForce = 35 * 18.0; 
groundTraction = 4.5; 
mass = 18.0; 
maxEnergy = 140; 
drag = 1.0; 
density = 2.5; 
canCrouch = false; 
minDamageSpeed = 25; 
damageScale = 0.006; 
jumpImpulse = 150; 
jumpSurfaceMinDot = 0.2; 
animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetHeavy; rFootSounds = { SoundHFootRSoft, SoundHFootRHard, SoundHFootRSoft, SoundHFootRHard, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRHard, SoundHFootRSnow, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft }; lFootSounds = { SoundHFootLSoft, SoundHFootLHard, SoundHFootLSoft, SoundHFootLHard, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLHard, SoundHFootLSnow, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft }; footPrints = { 4, 5 }; boxWidth = 0.8; boxDepth = 0.8; boxNormalHeight = 2.6; boxNormalHeadPercentage = 0.70; boxNormalTorsoPercentage = 0.45; boxHeadLeftPercentage = 0.48; boxHeadRightPercentage = 0.70; boxHeadBackPercentage = 0.48; boxHeadFrontPercentage = 0.60; }; 






















PlayerData dmarmor { className = "Armor"; shapeFile = "marmor"; flameShapeName = "mflame"; shieldShapeName = "shield"; damageSkinData = "armorDamageSkins"; debrisId = playerDebris; shadowDetailMask = 1; canCrouch = true; visibleToSensor = True; mapFilter = 1; mapIcon = "M_player"; maxJetSideForceFactor = 0.8; maxJetForwardVelocity = 17; minJetEnergy = 1; jetForce = 325; jetEnergyDrain = 1.0; maxDamage = 1.0; maxForwardSpeed = 15.0; maxBackwardSpeed = 12.0; maxSideSpeed = 12.0; groundForce = 35 * 13.0; mass = 13.0; groundTraction = 3.0; maxEnergy = 90; drag = 1.0; density = 1.5; minDamageSpeed = 25; damageScale = 0.005; jumpImpulse = 115; jumpSurfaceMinDot = 0.2; animData[0] = { "root", none, 1, true, true, true, false, 0 }; animData[1] = { "run", none, 1, true, false, true, false, 3 }; animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; jetSound = SoundJetLight; rFootSounds = { SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft }; lFootSounds = { SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft }; footPrints = { 2, 3 }; boxWidth = 0.7; boxDepth = 0.7; boxNormalHeight = 2.4; boxNormalHeadPercentage = 0.83; boxNormalTorsoPercentage = 0.49; boxHeadLeftPercentage = 0; boxHeadRightPercentage = 1; boxHeadBackPercentage = 0; boxHeadFrontPercentage = 1; }; 

PlayerData dmfemale { 
className = "Armor"; 
shapeFile = "mfemale"; 
flameShapeName = "mflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 0.8; 
maxJetForwardVelocity = 17; 
minJetEnergy = 1; 
jetForce = 325; 
jetEnergyDrain = 1.0; 
maxDamage = 1.0; maxForwardSpeed = 15.0; maxBackwardSpeed = 12.0; maxSideSpeed = 12.0; groundForce = 35 * 13.0; mass = 13.0; groundTraction = 3.0; maxEnergy = 90; drag = 1.0; density = 1.5; minDamageSpeed = 25; damageScale = 0.005; jumpImpulse = 115; jumpSurfaceMinDot = 0.2; animData[0] = { "root", none, 1, true, true, true, false, 0 }; animData[1] = { "run", none, 1, true, false, true, false, 3 }; animData[2] = { "runback", none, 1, true, false, true, false, 3 }; animData[3] = { "side left", none, 1, true, false, true, false, 3 }; animData[4] = { "side left", none, -1, true, false, true, false, 3 }; animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; animData[7] = { "crouch root", none, 1, true, false, true, false, 3 }; animData[8] = { "crouch root", none, 1, true, false, true, false, 3 }; animData[9] = { "crouch root", none, -1, true, false, true, false, 3 }; animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; animData[14] = { "fall", none, 1, true, true, true, false, 3 }; animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; animData[19] = { "jet", none, 1, true, true, true, false, 3 }; animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; animData[21] = { "throw", none, 1, true, false, false, false, 3 }; animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; animData[24] = { "apc root", none, 1, false, false, false, false, 3 }; animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 

jetSound = SoundJetLight; 

rFootSounds = 
{ 
SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRHard, SoundMFootRSnow, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft, SoundMFootRSoft 
}; 
lFootSounds = 
{ 
SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLHard, SoundMFootLSnow, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft, SoundMFootLSoft 
}; 
footPrints = { 2, 3 }; 
boxWidth = 0.7; 
boxDepth = 0.7; 
boxNormalHeight = 2.4; 
boxNormalHeadPercentage = 0.84; 
boxNormalTorsoPercentage = 0.55; 
boxHeadLeftPercentage = 0; 
boxHeadRightPercentage = 1; 
boxHeadBackPercentage = 0; 
boxHeadFrontPercentage = 1; 
};









//=====================================================================
//:::::::::::::::::::::::::::::DEFENDER::::::::::::::::::::::::::::::::
//=====================================================================

PlayerData defarmor 
{ 
className = "Armor"; 
shapeFile = "harmor"; 
flameShapeName = "hflame"; 
shieldShapeName = "shield"; 
damageSkinData = "armorDamageSkins"; 
debrisId = playerDebris; 
shadowDetailMask = 1; 
visibleToSensor = True; 
mapFilter = 1; 
mapIcon = "M_player"; 
maxJetSideForceFactor = 1; 
maxJetForwardVelocity = 1; 
minJetEnergy = 1; 
jetForce = 250; 
jetEnergyDrain = 1.1; 
maxDamage = 1.60; 
maxForwardSpeed = 1.0; 
maxBackwardSpeed = 1.0; 
maxSideSpeed = 1.0; 
groundForce = 35 * 18.0; 
groundTraction = 4.5; 
mass = 19.0; 
maxEnergy = 150; 
drag = 1.0; 
density = 2.5; 
canCrouch = false; 
minDamageSpeed = 25; 
damageScale = 0.006; 
jumpImpulse = 200; 
jumpSurfaceMinDot = 0.2; 


animData[0] = { "root", none, 1, true, true, true, false, 0 }; 
animData[1] = { "run", none, 1, true, false, true, false, 3 }; 
animData[2] = { "runback", none, 1, true, false, true, false, 3 }; 
animData[3] = { "side left", none, 1, true, false, true, false, 3 }; 
animData[4] = { "side left", none, -1, true, false, true, false, 3 }; 
animData[5] = { "jump stand", none, 1, true, false, true, false, 3 }; 
animData[6] = { "jump run", none, 1, true, false, true, false, 3 }; 
animData[7] = { "crouch root", none, 1, true, true, true, false, 3 }; 
animData[8] = { "crouch root", none, 1, true, true, true, false, 3 }; 
animData[9] = { "crouch root", none, -1, true, true, true, false, 3 }; 
animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 }; 
animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 }; 
animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 }; 
animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 }; 
animData[14] = { "fall", none, 1, true, true, true, false, 3 }; 
animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 }; 
animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 }; 
animData[18] = { "tumble end", none, 1, true, false, false, false, 3 }; 
animData[19] = { "jet", none, 1, true, true, true, false, 3 }; 
animData[20] = { "PDA access", none, 1, true, false, false, false, 3 }; 
animData[21] = { "throw", none, 1, true, false, false, false, 3 }; 
animData[22] = { "flyer root", none, 1, false, false, false, false, 3 }; 
animData[23] = { "apc root", none, 1, true, true, true, false, 3 }; 
animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 }; 
animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 }; animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 }; 
animData[38] = { "sign over here", none, 1, true, false, false, false, 2 }; 
animData[39] = { "sign point", none, 1, true, false, false, true, 1 }; 
animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 }; 
animData[41] = { "sign stop", none, 1, true, false, false, true, 1 }; 
animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 
animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 }; 
animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 }; 
animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 }; 
animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 }; 
animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 }; 
animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 }; 
animData[49] = { "pose stand", none, 1, true, false, false, true, 1 }; 
animData[50] = { "wave", none, 1, true, false, false, true, 1 }; 


jetSound = SoundJetHeavy; rFootSounds = 
{ 
SoundHFootRSoft, SoundHFootRHard, SoundHFootRSoft, SoundHFootRHard, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRHard, SoundHFootRSnow, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft, SoundHFootRSoft 
}; 
lFootSounds = 
{ 
SoundHFootLSoft, SoundHFootLHard, SoundHFootLSoft, SoundHFootLHard, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLHard, SoundHFootLSnow, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft, SoundHFootLSoft 
}; 
footPrints = { 4, 5 }; 
boxWidth = 0.8; 
boxDepth = 0.8; 
boxNormalHeight = 2.6; 
boxNormalHeadPercentage = 0.70; 
boxNormalTorsoPercentage = 0.45; 
boxHeadLeftPercentage = 0.48; 
boxHeadRightPercentage = 0.70; 
boxHeadBackPercentage = 0.48; 
boxHeadFrontPercentage = 0.60; 
}; 




 