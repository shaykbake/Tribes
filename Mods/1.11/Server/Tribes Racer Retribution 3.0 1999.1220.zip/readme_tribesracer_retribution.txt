
----------------------------------------------------------------
Name: Tribes Racer - Retribution
Version: 3.0
Date: 20 December 1999
Author: Josef Jahn
Email: werewolf@playspoon.com
URL :http://www.playspoon.com
Purpose: Third edition of the racing game for Tribes
Requirements: TRIBES v1.3 or higher


Notes:   Please feel free to host this mod admins, and if you have time, drop me a line where its at so i can come play :)
---------------------------------------------------------------


v3.0??? Well, I dicovered that the Gameplay of v1.0 wasn't exciting enough, so I added even more nasty things...







 Installation
--------------



Client Install: None needed. 





Server Install: 
	Unzip the archive with pathnames.


When installed The Files Should be here: 
 Tribes\base\missions\TribesRacer.dsc
 Tribes\base\missions\TribesRacer.mis
 Tribes\base\missions\TribesRacer_Retribution.dsc
 Tribes\base\missions\TribesRacer_Retribution.mis
 Tribes\base\TribesRacer.cs



Check out any updates at www.playspoon.com
and email me at werewolf@playspoon.com if you experience any problems.


---------------------------------------------------------------










 Overview
----------

Tribes Racer is my version of a racing game for Tribes. You start at a vehicle station where you have to buy a Scout.
The you race through 2 lap points before you return to the start. Every round is counted as 1 Point,
the player with the most completed rounds is the "Leader", and his name will be broadcasted to all other players.
You need to finish 10 rounds to win.

When you kill a player, you will also gaina "round", whereas the killed player's rounds are decreased by one.
So, in order to keep someone from winnning the game, all you have to do is kill him because then he'll have to do one more round.

New in v2.0 is also the various turrets which you can take control of to kill the others. But beware, the command stations are
placed at visible points, so don't spend too much time there.

New in v3.0:

x) Scout is two times faster (you now have a chance to dodge missiles)
x) Scout fires chaingun
x) LPC fires missiles
x) HPC fires heavy mortar shells





Please send any questions or comments or ideas to me at werewolf@playspoon.com

Also, if you would have a server and would like to host this mod, feel free! Just please let me know where your server is at so I can come play sometime! 






----------------------------------------------------------------
Disclaimer: I am not responsible for any damage this game modification may cause you or anything having to do 
	    with you. I also am not responsible for any hardware failures or software problems that may arise
	    in TRIBES, your computer, or life in general.
	    If your computer dies, it's not my fault.
	    If your dog dies, it's not my fault.

	    If you would like to host this mod.. feel free.
	    if you like, or hate this mod, or have any ideas, please drop me a line.

	    Thank you!
----------------------------------------------------------------

