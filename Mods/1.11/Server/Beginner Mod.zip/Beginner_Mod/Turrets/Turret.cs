ItemImageData TurretPackImage {
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};
ItemData TurretPack {
	description = "Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
	heading = "dDeployables";
	imageType = TurretPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};
function TurretPack::onUse(%player, %item){
	if(Player::getMountedItem(%player,$BackpackSlot) != %item) Player::mountItem(%player, %item, $BackpackSlot);
	else Player::deployItem(%player, %item);
}
function TurretPack::onDeploy(%player, %item, %pos){
	deployItemX(%player, %item, "Turret", DeployableTurret, "Any", "SimTerrain InteriorShape", 3, true, true);
}

TurretData DeployableTurret {
	className = "Turret";
	shapeFile = "remoteturret";
	validateShape = true;
	validateMaterials = true;
	projectileType = MiniFusionBolt;
	maxDamage = 0.65;
	maxEnergy = 60;
	minGunEnergy = 6;
	maxGunEnergy = 5;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	reloadDelay = 0.4;
	speed = 4.0;
	speedModifier = 1.5;
	range = 30;
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	fireSound = SoundRemoteTurretFire;
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
	description = "Remote Turret";
	damageSkinData = "objectDamageSkins";
};
function DeployableTurret::onAdd(%this){
	Schedule("DeployableTurret::deploy("@ %this @");", 1, %this);
	GameBase::setRechargeRate(%this, 5);
	%this.shieldStrength = 0;
	if(GameBase::getMapName(%this) == "") GameBase::setMapName (%this, "Remote Turret");
}
function DeployableTurret::deploy(%this){ GameBase::playSequence(%this, 1, "deploy"); }
function DeployableTurret::onEndSequence(%this, %thread){ GameBase::setActive(%this, true); }
function DeployableTurret::onDestroyed(%this){
	Turret::onDestroyed(%this);
	$TeamItemCount[GameBase::getTeam(%this) @"TurretPack"]--;
}
function DeployableTurret::onPower(%this,%power,%generator){}
function DeployableTurret::onEnabled(%this){
	GameBase::setRechargeRate(%this,5);
	GameBase::setActive(%this,true);
}	