createDeployable(CameraPack, 1, 2, "1 1 1", 15);
createDeployable(TurretPack, 1, 1, "0 1 1", 10);