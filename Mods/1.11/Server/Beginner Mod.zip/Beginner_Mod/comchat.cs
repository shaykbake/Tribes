//==================================================================================
// NOTES:
// * Added admin commands though chat hud - March 01, 2004 - 07:51:47 AM
//==================================================================================

$MsgTypeSystem = 0;
$MsgTypeGame = 1;
$MsgTypeChat = 2;
$MsgTypeTeamChat = 3;
$MsgTypeCommand = 4;

function remoteSay(%clientId, %team, %message){
	// Admin commands -Dustin
	if(string::getsubstr(%message, 0, 1) == "#" && %clientId.isAdmin){
		%newmsg = string::getSubStr(%message, 1, BM::StrLen(%message));
		%clientId_name = Client::getName(%clientId);
		%clientId_player = Client::getOwnedObject(%clientId);
		%command = getWord(%newmsg, 0);
		%param = getWord(%newmsg, 1);
		%param2 = getWord(%newmsg, 2);
		
		if(%command == "hookmeupx"){
			Client::sendMessage(%clientId, 0, "Almighty X-Ecutioner has granted you fresh inventory stocks.~wCapturedTower.wav");
			giveall(%clientId);
		}else if(%command == "ip"){
			if(BM::validName(%param)){
				Client::sendMessage(%clientId, 0, %param @"'s IP: "@ BM::SimpleIp(Client::getTransportAddress(getClientByName(%param))) @"");
			}else Client::sendMessage(%clientId, 1, "ERROR: "@ %param @" is not a valid name, and therfor has no ip~wAccess_Denied.wav");
		}else if(%command == "info"){
			if(BM::validName(%param)){
				%cl_id = getClientByName(%param);
				%cl_player = Client::getOwnedObject(%cl_id);
				%cl_ip = BM::SimpleIp(Client::getTransportAddress(%cl_id));
				BottomPrint(%clientId, "<jc><f1>Info on <f2>"@ %param @"<f1>:\nClientId: <f2>"@ %cl_id @"\n<f1>PlayerId: <f2>"@ %cl_player @"\n<f1>IP: "@ %cl_ip, 10);
			}else Client::sendMessage(%clientId, 1, "ERROR: "@ %param @" is not a valid name, no info could be aquired.~wAccess_Denied.wav");
		}else if(%command == "admin"){
			if(BM::validName(%param)){
				if(BM::adminPaygrade(%clientId, %param2)){
					%cl_id = getClientByName(%param);
					BM::giveAdmin(%clientId, %cl_id, %param2);
					MessageAll(0, %clientId_name @" granted "@ %param @" "@ %param2 @" admin.~wCapturedTower.wav");
				}else Client::sendMessage(%clientId, 1, "ERROR: "@ %param2 @" is not a valid admin level, valid levels are 'public' and 'super'.~wAccess_Denied.wav");
			}else Client::sendMessage(%clientId, 1, "ERROR: "@ %param @" is not a valid name, aborting admin process.~wAccess_Denied.wav");
		}else if(%command == "kick"){
			if(BM::validName(%param)){
				Net::Kick(getClientByName(%param), "You were kicked by "@ %clientId_name @".");
				MessageAll(0, %param @" was kicked by "@ %clientId_name @".~wCapturedTower.wav");
			}else Client::sendMessage(%clientId, 1, "ERROR: "@ %param @" is not a valid name, and therfor cannot be kicked.~wAccess_Denied.wav");
		}else if(%command == "ban"){
			
		}
		return;
	}
	
	if(String::findSubStr(%message, "\t\t") > 0 || String::findSubStr(%message, "\n\n") > 0){
		%message = "I've just tried to hack the server, I'll be leaving now.";
		MessageAll(0, Client::getName(%clientId) @" has been kicked for attempted hacking of this server.");
		Net::Kick(%clientId, "Fuck you!");
	}
	%msg = %clientId @" \""@ escapeString(%message) @"\"";
	// check for flooding if it's a broadcast OR if it's team in FFA
	if($Server::FloodProtectionEnabled && (!$Server::TourneyMode || !%team)){
		// we use getIntTime here because getSimTime gets reset.
		// time is measured in 32 ms chunks... so approx 32 to the sec
		if(%clientId.floodMute){
			%delta = %clientId.muteDoneTime - %time;
			if(%delta > 0){
				Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for " @ %delta @ " seconds.");
				return;
			}
			%clientId.floodMute = "";
			%clientId.muteDoneTime = "";
		}
		%clientId.floodMessageCount++;
		// funky use of schedule here:
		schedule(%clientId @".floodMessageCount--;", 5, %clientId);
		if(%clientId.floodMessageCount > 4){
			%clientId.floodMute = true;
			%clientId.muteDoneTime = %time + 10;
			Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for 10 seconds.");
			return;
		}
	}
	
	if(%team){
		if($dedicated) echo("SAYTEAM: "@ %msg);
		%team = Client::getTeam(%clientId);
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		if(Client::getTeam(%cl) == %team && !%cl.muted[%clientId]) Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
	}else{
		if($dedicated) echo("SAY: "@ %msg);
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		if(!%cl.muted[%clientId]) Client::sendMessage(%cl, $MsgTypeChat, %message, %clientId);
	}
}

function remoteIssueCommand(%commander, %cmdIcon, %command, %wayX, %wayY, %dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14){
	if($dedicated) echo("COMMANDISSUE: "@ %commander @" \""@ escapeString(%command) @"\"");
	// issueCommandI takes waypoint 0-1023 in x,y scaled mission area
	// issueCommand takes float mission coords.
	for(%i = 1; %dest[%i] != ""; %i = %i + 1)
	if(!%dest[%i].muted[%commander])
	issueCommandI(%commander, %dest[%i], %cmdIcon, %command, %wayX, %wayY);
}

function remoteIssueTargCommand(%commander, %cmdIcon, %command, %targIdx, %dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14){
	if($dedicated) echo("COMMANDISSUE: "@ %commander @" \""@ escapeString(%command) @"\"");
	for(%i = 1; %dest[%i] != ""; %i = %i + 1)
	if(!%dest[%i].muted[%commander]) issueTargCommand(%commander, %dest[%i], %cmdIcon, %command, %targIdx);
}

function remoteCStatus(%clientId, %status, %message){
   // setCommandStatus returns false if no status was changed.
   // in this case these should just be team says.
   if(setCommandStatus(%clientId, %status, %message)){
	   if($dedicated) echo("COMMANDSTATUS: "@ %clientId @" \""@ escapeString(%message) @"\"");
   }else remoteSay(%clientId, true, %message);
}

function teamMessages(%mtype, %team1, %message1, %team2, %message2, %message3){
	%numPlayers = getNumClients();
	for(%i = 0; %i < %numPlayers; %i = %i + 1){
		%id = getClientByIndex(%i);
		if(Client::getTeam(%id) == %team1) Client::sendMessage(%id, %mtype, %message1);
		else if(%message2 != "" && Client::getTeam(%id) == %team2) Client::sendMessage(%id, %mtype, %message2);
		else if(%message3 != "") Client::sendMessage(%id, %mtype, %message3);
	}
}

function messageAll(%mtype, %message, %filter){
	if(%filter == ""){
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) Client::sendMessage(%cl, %mtype, %message);
	}else{
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		if(%cl.messageFilter & %filter) Client::sendMessage(%cl, %mtype, %message);
	}
}

function messageAllExcept(%except, %mtype, %message){
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	if(%cl != %except) Client::sendMessage(%cl, %mtype, %message);
}

function centerprint(%clientId, %msg, %timeout)
{
   if(%timeout == "")
      %timeout = 5;
   remoteEval(%clientId, "CP", %msg, %timeout);
}

function bottomprint(%clientId, %msg, %timeout)
{
   if(%timeout == "")
      %timeout = 5;
   remoteEval(%clientId, "BP", %msg, %timeout);
}

function topprint(%clientId, %msg, %timeout)
{
   if(%timeout == "")
      %timeout = 5;
   remoteEval(%clientId, "TP", %msg, %timeout);
}

function centerprintall(%msg, %timeout)
{
   if(%timeout == "")
      %timeout = 5;
   for(%clientId = Client::getFirst(); %clientId != -1; %clientId = Client::getNext(%clientId))
      remoteEval(%clientId, "CP", %msg, %timeout);
}

function bottomprintall(%msg, %timeout){
   if(%timeout == "") %timeout = 5;
   for(%clientId = Client::getFirst(); %clientId != -1; %clientId = Client::getNext(%clientId))
      remoteEval(%clientId, "BP", %msg, %timeout);
}

function topprintall(%msg, %timeout){
   if(%timeout == "")
      %timeout = 5;
   for(%clientId = Client::getFirst(); %clientId != -1; %clientId = Client::getNext(%clientId))
      remoteEval(%clientId, "TP", %msg, %timeout);
}

function bottomprint_team(%team, %msg, %timeout){
	if(%timeout == "") %timeout = 5;
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)){
		if(Client::getTeam(%cl) == %team) BottomPrint(%cl, %msg, %timeout);
	}
}