//-----------------------------------------
// Special_Functs.cs
// Author: Dustin Bruce Aka X-Ecutioner
// Started: August 8th, 2003 2:57pm
//-----------------------------------------
DamageSkinData objectDamageSkins {
   bmpName[0] = "dobj1_object";
   bmpName[1] = "dobj2_object";
   bmpName[2] = "dobj3_object";
   bmpName[3] = "dobj4_object";
   bmpName[4] = "dobj5_object";
   bmpName[5] = "dobj6_object";
   bmpName[6] = "dobj7_object";
   bmpName[7] = "dobj8_object";
   bmpName[8] = "dobj9_object";
   bmpName[9] = "dobj10_object";
};
//==========================================================================================
// Defaults and referencing variables, don't touch.
$AmmoPack::num = 0;
$ReInit::num = 0;
$Armor::num = 0;
$newWord[SimTerrain] = "Terrain";
$newWord[InteriorShape] = "Buildings";
$newWord[StaticShape] = "Deployed Objects";
//==========================================================================================
//
//
//==========================================================================================
// createArmor(%genderM, %genderF, %description, %price, %armorName)
//  %genderM: The armors male datablock. ex:
//    larmor
// 
//  %genderF: The armors female datablock. ex:
//    lfemale
//  
//  %description: Name used in inventories.
//  
//  %price: Price of the armor.
//
//  %armorName: Item Datablock name of the armor. ex:
//    LightArmor
//    MediumArmor
//    HeavyArmor
//
// NOTE:
//  This function sets each armor up with a number, numbers are assigned in the order in which
//  the armors were passed through this function. It DOES NOT setup a seperate number for
//  male\female datablocks, but for each individual armor.
function createArmor(%genderM, %genderF, %description, %price, %armorName){
   $ArmorType[Male, %armorName] = %genderM;
   $ArmorType[Female, %armorName] = %genderF;
    
   $ArmorName[$ArmorType[Male, %armorName]] = %armorName;
   $ArmorName[$ArmorType[Female, %armorName]] = %armorName;
   
   $BM::Armor[$Armor::num] = %armorName;
   
   %ItemData = "ItemData "@ %armorName @" {"@
   "    heading = \"aArmor\";"@
   "    description = \""@ %description @"\";"@
   "    className = \"Armor\";"@
   "    price = "@ %price @";"@
   "};"; 
   eval(%ItemData);
   $Armor::num += 1;
}
//==========================================================================================
//
//
//==========================================================================================
// createWeapon(%weapon, %ammo, %inv, %remote, %autoUse, %sellAmmo, %wmax, %amax)
//  %weapon: Datablock name of weapon.
//
//  %ammo: Datablock name of ammo.
//
//  %inv: Number, ex:
//    0 = Not in inventory
//    1 = In inventory
//
//  %remote: Number, ex:
//    0 = Not in remote inventory
//    1 = In remote inventory
//
//  %autoUse: sets the $AutoUse variable, ex:
//    true = Autoswitch to weapon when leaving inventory, or apon picking it up.
//    false = don't
//
//  %sellAmmo: How much ammo to get rid of each time you sell it's ammo to invs or remote invs.
//
//  %wmax: This has multiple arguments in it, seperated by spaces, used to define the weapon max
//  for every armor. ex:
//    createWeapon(Blaster,"",1,1,false,"","1 1 1");// We have 3 armors so three 1's are there.
//  Count through the arguments, you'll see that "1 1 1" is called for %wmax, which will set armors 1 2 and 3
//  with access to this item. Armors are givin a number starting with 0 in the order in which they were added.
//  So the first 1 there will set our light armor with access, second 1 will set medium armor, and third 1 sets
//  heavy armor's access, add spaces and numbers for each new armor you add.
//    0 = Inaccessable
//    1 = Accessable
//
//  %amax: This has multiple arguments as well, exactly the same as %wmax, but this is for how
//  much ammo each armor can carry.
//
function createWeapon(%weapon, %ammo, %inv, %remote, %autoUse, %sellAmmo, %wmax, %amax){
	$AutoUse[%weapon] = %autoUse;
	
	if(%ammo == "") $WeaponAmmo[%weapon] = "";
	else{
		$WeaponAmmo[%weapon] = %ammo;
		$SellAmmo[%ammo] = %sellAmmo;
		
		for(%x = 0; %x < $Armor::num; %x++){
			$ItemMax[$ArmorType[Male, $BM::Armor[%x]], %ammo] = getWord(%amax, %x);
			$ItemMax[$ArmorType[Female, $BM::Armor[%x]], %ammo] = getWord(%amax, %x);
		}
		
		$InvList[%ammo] = %inv;
		$RemoteInvList[%ammo] = %remote;
	}
	
	for(%x = 0; %x < $Armor::num; %x++){
		$ItemMax[$ArmorType[Male, $BM::Armor[%x]], %weapon] = getWord(%wmax, %x);
		$ItemMax[$ArmorType[Female, $BM::Armor[%x]], %weapon] = getWord(%wmax, %x);
	}
	
	$InvList[%weapon] = %inv;
	$RemoteInvList[%weapon] = %remote;
	addWeapon(%weapon);
}
//==========================================================================================
//
//
//==========================================================================================
// createBackPack(%pack, %inv, %remote, %armorMax)
//  %pack: ItemData block name. ex:
//    AmmoPack
//
//  %inv: Number, ex:
//    0 = Don't include it in inventory.
//    1 = Include it.
//
//  %remote: Number, ex:
//    0 = Don't include it in remote inventory.
//    1 = Include it.
//
//  %armorMax: This argument is exactly the same as %wmax for the createWeapon function.
function createBackPack(%pack, %inv, %remote, %armorMax){
	$InvList[%pack] = %inv;
	$RemoteInvList[%pack] = %remote;
	
	for(%x = 0; %x < $Armor::num; %x++){
		$ItemMax[$ArmorType[Male, $BM::Armor[%x]], %pack] = getWord(%armorMax, %x);
		$ItemMax[$ArmorType[Female, $BM::Armor[%x]], %pack] = getWord(%armorMax, %x);
	}
}
//==========================================================================================
//
//
//==========================================================================================
// createMisc(%misc, %autouse, %inv, %remote, %misc_max, %sellAmmo, %tim)
//  %misc: Datablock name of item.
//
//  %autouse: bah, just call it as false.
//
//  %inv: Number, ex:
//    0 = Don't include it in inventory.
//    1 = Include it.
//
//  %remote: Number, ex:
//    0 = Don't include it in remote inventory.
//    1 = Include it.
//
//  %misc_max: This argument is exactly the same as %wmax for the createWeapon function.
//
//  %sellAmmo: How much to get rid of each time you sell to invs or remote invs. (optional)
//
//  %tim: How many items perteam can be used. (optional)
function createMisc(%misc, %autouse, %inv, %remote, %misc_max, %sellAmmo, %tim){
	if(%autouse != "") $AutoUse[%misc] = %autouse;
	
	$InvList[%misc] = %inv;
	$RemoteInvList[%misc] = %remote;
	
	for(%x = 0; %x < $Armor::num; %x++){
		$ItemMax[$ArmorType[Male, $BM::Armor[%x]], %misc] = getWord(%misc_max, %x);
		$ItemMax[$ArmorType[Female, $BM::Armor[%x]], %misc] = getWord(%misc_max, %x);
	}
	
	if(%sellAmmo != "") $SellAmmo[%misc] = %sellAmmo;
	if(%tim != ""){
		$TeamItemMax[%misc] = %tim;
		ReInit::Add(%misc);
	}
}
//==========================================================================================
//
//
//==========================================================================================
// createDeployable(%deployable, %inv, %remote, %dMax, %tim)
//  %deployable: Datablock name of item.
//
//  %inv: Number, ex:
//    0 = Don't include it in inventory.
//    1 = Include it.
//
//  %remote: Number, ex:
//    0 = Don't include it in remote inventory.
//    1 = Include it.
//
//  %dMax: This argument is exactly the same as %wmax for the createWeapon function.
// 
//  %tim: How many items perteam can be used.
function createDeployable(%deployable, %inv, %remote, %dMax, %tim){
	$InvList[%deployable] = %inv;
	$RemoteInvList[%deployable] = %remote;
	
	for(%x = 0; %x < $Armor::num; %x++){
		$ItemMax[$ArmorType[Male, $BM::Armor[%x]], %deployable] = getWord(%dMax, %x);
		$ItemMax[$ArmorType[Female, $BM::Armor[%x]], %deployable] = getWord(%dMax, %x);
	}
	
	$TeamItemMax[%deployable] = %tim;
	ReInit::Add(%deployable);
}
//==========================================================================================
//
//
//==========================================================================================
// AmmoPack::addAmmo(%item, %extra)
//  %item: Ammo to fill, use the ammo's datablock name.
// 
//  %extra: How many more of the item should be givin?
//
function AmmoPack::addAmmo(%item, %extra){
	$AmmoPackItems[$AmmoPack::num] = %item;
	$AmmoPackMax[%item] = %extra;
	$AmmoPack::num += 1;
}
//==========================================================================================
//
//
//==========================================================================================
// ReInit::Add(%item)
//  %item: Item Datablock name.
//
function ReInit::Add(%item){
	$ReInit::Item[$ReInit::num] = %item;
	$ReInit::num += 1;
}
//==========================================================================================
//
//
//==========================================================================================
// deployItemX(%player, %item, %class, %shape, %angle, %terrain, %dplRange, %range, %breakable)
//  %player: Player object doing the deploying.
//
//  %item: Item being deployed.
//
//  %class: Type of object. ex:
//    "StaticShape"
//    "Sensor"
//    "Turret"
//
//  %shape: ItemDatablock name of the item.
//
//  %angle: Angle to deploy this item at. ex:
//    true = Only on flat surfaces.
//    "Player" = Use players rotation.
//    "Flat" = Deploy the item flat (good for laying a blast wall flat for example).
//    "Any" = Self Explanitory.
//
//  %terrain: Allowable terrains. You can call this with one of these options:
//    "All" = Deployable on anything.
//    "SimTerrain" = Deployable on terrain (the ground)
//    "InteriorShape" = Deployable on Interiorshapes (buildings, etc..)
//    "StaticShape" = Deployable on deployed objects.
//  You may also call this with more than one terrain, ex:
//    "SimTerrain InteriorShape"
//    "StaticShape InteriorShape"
//
//  %dplRange: Maximum distance away from the player that this item can be deployed. ex:
//    3 = won't allow you to deploy past 3 meters from the player.
//
//  %range: true or false:
//    true = check the immediate area for objects, if found no deploying.
//    false = let it go.
//
//  %breakable: Would you like this item to delete once it's destroyed or stay around?
//    true = delete once it's completely disaled
//    false = keep it around, so someone can repair it later.
//
function deployItemX(%player, %item, %class, %shape, %angle, %terrain, %dplRange, %range, %breakable){
	%client = Player::getClient(%player);
	if(!GameBase::getLOSInfo(%player, %dplRange)){
		Client::sendMessage(%client, 0, "Deploy position out of range");
		return false;
	}
	
	if(%angle == true){
		if(Vector::dot($los::normal, "0 0 1") > 0.7){
			%prot = GameBase::getRotation(%player);
			%zRot = getWord(%prot, 2);
			if(Vector::dot($los::normal, "0 0 1") > 0.6) %rot = "0 0 "@ %zRot;
			else{
				if(Vector::dot($los::normal,"0 0 -1") > 0.6) %rot = "3.14159 0 "@ %zRot;
				else %rot = Vector::getRotation($los::normal);
			}
		}else{
			Client::sendMessage(%client, 0, "Can only deploy on flat surfaces");
			return false;
		}
	}
	else if(%angle == "Player") %rot = GameBase::getRotation(%player);
	else if(%angle == "Flat") %rot = "-1.54564 0.02591 -3.09105";
	else if(%angle == "Any"){
		%prot = GameBase::getRotation(%player);
		%zRot = getWord(%prot, 2);
		if(Vector::dot($los::normal,"0 0 1") > 0.6){
			%rot = "0 0 "@ %zRot;
		}else{
			if(Vector::dot($los::normal, "0 0 -1") > 0.6) %rot = "3.14159 0 "@ %zRot;
			else %rot = Vector::getRotation($los::normal);
		}
	}
	
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] >= $TeamItemMax[%item]){
		Client::sendMessage(%client, 0, "Deployable Item limit reached for "@ %item.description @"s.");
		return false;
	}
	
	if(%terrain != "" && %terrain != false){
		if(%terrain == "All"){
			if(%obj != "SimTerrain" && %obj != "InteriorShape" && %obj != "StaticShape"){
				Client::sendMessage(%client, 0, "Can only deploy on terrain, buildings and deployed objects.");
				return false;
			}
		}else{
			%terrainA = getWord(%terrain, 0);
			%terrainB = getWord(%terrain, 1);
			%obj = getObjectType($los::object);
			
			if(%terrainB != ""){
				if(%obj != %terrainA && %obj != %terrainB){
					Client::sendMessage(%client, 0, "Can only deploy on "@ $newWord[%terrainA] @" or "@ $newWord[%terrainB] @".");
					return false;
				}
			}else{
				if(%obj != %terrain){
					Client::sendMessage(%client, 0, "Can only deploy on "@ $newWord[%terrain] @".");
					return false;
				}
			}
		}
	}
	
	if(%range == true){
		if(!checkDeployArea(%client, $los::position)) return false;
	}
	%obj = newObject(%item.description, %class, %shape, %breakable);
	%obj.Item = %item;
	addToSet("MissionCleanup", %obj);
	GameBase::setTeam(%obj, GameBase::getTeam(%player));
	GameBase::setRotation(%obj, %rot);
	GameBase::setPosition(%obj, $los::position);
	$TeamItemCount[GameBase::getTeam(%obj) @ %item]++;
	Gamebase::setMapName(%obj, Client::getName(%client) @" - "@ %item.description @" #"@ $TeamItemCount[GameBase::getTeam(%player) @ %item] @"");
	Client::sendMessage(%client, 0, %item.description @" deployed");
	playSound(SoundPickupBackpack, $los::position);
	Echo("Deploy: \""@ %item.description @"\" - "@ Client::getName(%client) @"("@ %client @")");
	Player::decItemCount(%player, %item);
	return true;
}
//==========================================================================================
//
//
//==========================================================================================
// Misc Goodie Functions:
function BM::StrLen(%string){ 
	for(%i = 0; String::getSubStr(%string, %i, 1) != ""; %i++) %length = %i; 
	%length++; 
	return %length; 
}
function BM::validName(%name){
	for(%i = Client::getFirst(); %i != -1; Client::getNext(%i)){
		if(Client::getName(%i) == %name) return true;
	}
	return false;
}
function BM::SimpleIp(%transport){
	if(String::getSubStr(%transport,0,8) == "LOOPBACK") return "LOCAL";
	%trnsport = String::getSubStr(%transport, 3, 20);
	while(String::getSubStr(%trnsport, %len, 1) != ":" && %len < 20) %len++;
	return String::getSubStr(%trnsport, 0, %len);
}
function BM::whoison(%mode){
	%int = 0;
	echo("WhoIsOn:");
	echo("=================================================");
	for(%cl = Client::getFirst(); %cl !=-1; %cl = Client::getNext(%cl)){
		echo(%int @" "@ Client::getName(%cl) @"("@ %cl @")'s IP: "@ BM::SimpleIp(Client::getTransportAddress(%cl)));
		%int++;
	}
	echo("=================================================");
}
function BM::adminPaygrade(%admin, %payGrade){
	if(%admin.isadmin && %payGrade == "public") return true;
	else if(%admin.isSuperAdmin && %payGrade == "super") return true;
	return false;
}
function BM::giveAdmin(%admin, %client, %level){
	if(!%admin.isAdmin) return;
	%client.isAdmin = true;
	if(%level == "super") %client.isSuperAdmin = true;
}
function BM::checkPower(%this, %destroyer){
	if(GameBase::getDamageState(%this) == Destroyed){
		bottomprint_team(Client::getTeam(%destroyer), "<jl><bitem_damaged.bmp> <f1>"@ Client::getName(%destroyer) @" disabled one of the "@ getTeamName(GameBase::getTeam(%this)) @" generators!", 5);
	}
}
//==========================================================================================