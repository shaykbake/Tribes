createDeployable(DeployableAmmoPack, 1, 0, "0 1 1", 7);
createDeployable(DeployableInvPack, 1, 0, "0 1 1", 7);
createDeployable(DeployableSensorJammerPack, 1, 1, "1 1 1", 8);
createDeployable(MotionSensorPack, 1, 1, "1 1 1", 15);
createDeployable(PulseSensorPack, 1, 1, "1 1 1", 15);
