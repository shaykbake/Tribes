createMisc(Beacon, "", 1, 0, "3 3 3", 5, 40);
AmmoPack::addAmmo(Beacon, 10);

createMisc(Grenade, "", 1, 1, "5 6 8", 8, "");
AmmoPack::addAmmo(Grenade, 10);

createMisc(MineAmmo, false, 1, 1, "3 3 3", 1, 35);
AmmoPack::addAmmo(MineAmmo, 5);

createMisc(RepairKit, false, 1, 1, "1 1 1");