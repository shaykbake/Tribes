createWeapon(Blaster,"",1,1,false,"","1 1 1 1");

createWeapon(Chaingun, BulletAmmo, 1, 1, false, 25, "1 1 1", "100 150 200");
AmmoPack::addAmmo(BulletAmmo, 150);

createWeapon(DiscLauncher, DiscAmmo, 1, 1, false, 5, "1 1 1", "15 20 25");
AmmoPack::addAmmo(DiscAmmo, 15);

createWeapon(EnergyRifle, "", 1, 1, false, "", "1 1 1");

createWeapon(GrenadeLauncher, GrenadeAmmo, 1, 1, false, 5, "1 1 1", "10 10 15");
AmmoPack::addAmmo(GrenadeAmmo, 15);

createWeapon(LaserRifle, "", 1, 1, false, "", "1 0 0");

createWeapon(Mortar, MortarAmmo, 1, 1, false, 5, "0 0 1", "0 0 10");
AmmoPack::addAmmo(MortarAmmo, 10);

createWeapon(PlasmaGun, PlasmaAmmo, 1, 1, false, 5, "1 1 1", "30 40 50");
AmmoPack::addAmmo(PlasmaAmmo, 30);

createWeapon(RepairGun, "", 0, 0, false, "", "1 1 1");

createWeapon(TargetingLaser, "", 1, 1, false, "", "1 1 1");