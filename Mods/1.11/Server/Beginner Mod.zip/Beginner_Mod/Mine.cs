function Mine::onDamage(%this,%type,%value,%pos,%vec,%mom,%object){
   if(%type == $MineDamageType) %value = %value * 0.25;
   %damageLevel = GameBase::getDamageLevel(%this);
   GameBase::setDamageLevel(%this,%damageLevel + %value);
}
function Mine::Detonate(%this){
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);
}