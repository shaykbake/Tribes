createBackPack(AmmoPack, 1, 1, "1 1 1");
createBackPack(EnergyPack, 1, 1, "1 1 1");
createBackPack(RepairPack, 1, 1, "1 1 1");
createBackPack(ShieldPack, 1, 1, "1 1 1 1");
createBackPack(SensorJammerPack, 1, 1, "1 1 1 1");