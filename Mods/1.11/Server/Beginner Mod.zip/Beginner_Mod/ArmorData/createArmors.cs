// These three armors must be called in order as they are now, mess up the order and you mess up the mod.
createArmor(larmor, lfemale, "Light Armor", 175, LightArmor);
createArmor(marmor, mfemale, "Medium Armor", 250, MediumArmor);
createArmor(harmor, harmor, "Heavy Armor", 400, HeavyArmor);