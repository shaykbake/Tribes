//=========================================================================================
//===============              ChatMenu for TAC                 ===========================
//=========================================================================================
//
//
//            Edit the saying data if you so wish
//
//            The writers of this script take no responsibility for its use.
//
//=========================================================================================



//==================Saying Data==============================================
Say::New( TACIncomingAPC,           "incom2",       "Incoming APC!");
Say::New( TACEyesFront,           	"incom2",   	"Eyes Front...We got incoming!");
Say::New( TACRepairShip,            "needrep",      "Repair the APC");
Say::New( TACRepairPilot,           "needrep",      "Repair the Pilot");
Say::New( TACEject,      			"moveout", 		"EJECT EJECT EJECT");
Say::New( TACWaypoint,				"needtgt",		"Come on - set your pilot a waypoint");
Say::New( TACClearDefence,          "attenem", 		"Clear the Enemy Defences");
Say::New( TACOrbital,	      		"", 			"Orbital assault. One side fire, one side repair");
Say::New( TACFlyLevel,      		"wait1",       	"Please fly more level I cant get a shot at the enemy");
Say::New( TACReturntobase,        	"needamo",      "Need Ammo - Return to Base");
Say::New( TACGunnerReady,         	"attac2",       "Gunner in Position, Lets Ride!");
Say::New( TACMineFlag,         		"mineflg",      "Mine the flag and get back here");
Say::New( TACDefenceAPC,	        "waitpas",      "Defence APC Ready");
Say::New( TACOffenceAPC,           	"waitpas",      "Offence APC Ready");
Say::New( TACPilotNeeded,      		"boarda",      	"APC Ready - Pilot Needed");
Say::New( TACGunnerNeeded,     		"boarda",      	"APC Ready - Gunner Needed");
Say::New( TACCapperNeeded,     		"boarda",      	"APC Ready - Capper Needed");
Say::New( TACHoldUp,				"wait1",		"Hold up guys. Wait for me");
Say::New( TACStranded,	           	"help",    		"Stranded APC! Need replacement pilot quick!");
Say::New( TACReturning,      		"needdef",    	"Defence APC leaving position. Please Defend");




//=========================Chat Menu=========================================
//
//	Menu::AddTeamChat - these items will be broadcast to your whole team
//	Menu::AddAPCChat - will display the message to the players on the same apc, or,
//			If not on an apc, to your whole team.


Menu::New(menuTAC, "TAC - Team Aerial Combat");
	Menu::AddAPCChat(menuTAC,"i", TACIncomingAPC);
	Menu::AddAPCChat(menuTAC,"f", TACEyesFront);
	Menu::AddAPCChat(menuTAC,"s", TACRepairShip);
	Menu::AddAPCChat(menuTAC,"r", TACRepairPilot);
	Menu::AddAPCChat(menuTAC,"e", TACEject);
	Menu::AddAPCChat(menuTAC,"w", TACWaypoint);
	Menu::AddAPCChat(menuTAC,"m", TACMineFlag);
	Menu::AddAPCChat(menuTAC,"z", TACClearDefence);
	Menu::AddAPCChat(menuTAC,"o", TACOrbital);
	Menu::AddAPCChat(menuTAC,"l", TACFlyLevel);
	Menu::AddAPCChat(menuTAC,"a", TACReturntobase);
	Menu::AddAPCChat(menuTAC,"n", TACGunnerReady);
	Menu::AddTeamChat(menuTAC,"d", TACDefenceAPC);
	Menu::AddTeamChat(menuTAC,"o", TACOffenceAPC);
	Menu::AddTeamChat(menuTAC,"p", TACPilotNeeded);
	Menu::AddTeamChat(menuTAC,"g", TACGunnerNeeded);
	Menu::AddTeamChat(menuTAC,"c", TACCapperNeeded);
	Menu::AddTeamChat(menuTAC,"h", TACHoldUp);
	Menu::AddTeamChat(menuTAC,"x", TACStranded);
	Menu::AddTeamChat(menuTAC,"b", TACReturning);



Menu::AddMenu(menuChat,$TACClient::TACChatkey, menuTAC);

