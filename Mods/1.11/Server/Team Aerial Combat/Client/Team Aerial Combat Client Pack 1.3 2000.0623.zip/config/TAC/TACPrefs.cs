//----------------------------------------------------------------
//---------     TAC Client Pak Preferences      ------------------
//----------------------------------------------------------------
//
//    	This script is for use with Team Aerial Combat v 1.3 or later
//    	You MUST have Prestopack v 0.93 or later installed to run this script.
//
//
//    	The writers of this script take no responsibility for its use.
//
//
//		Change the settings in this file to suit yourself.
//
//
//----------------------------------------------------------------
//---------------     TAC Chat Menu      -------------------------
//----------------------------------------------------------------
//
// If you do not wish to use the TAC chat menu put false instead of true.

$TACClient::TACChat = true;


//	Put the key that you wish the chat menu to be bound to here   eg. v-b

$TACClient::TACChatkey = "b";



//----------------------------------------------------------------
//------------------     TAC Pilot Views     ---------------------
//----------------------------------------------------------------
//

//	If you dont want to use the TAC Pilot views put false here.

$TACClient::PilotViews = true;


//  Enter the keys for the left, rear and right pilot views respectively.
//		NOTE: Please check they are not bound to something else already
//
//	If you wish to alter these settings once the script has been originally
//	run please also remove the appropriate settings from _lastPrestoPrefs.cs


$PrestoPref::[PilotLeftView] = "f2";
$PrestoPref::[PilotRearView] = "f3";
$PrestoPref::[PilotRightView] = "f4";


//----------------------------------------------------------------
//------------------    TAC Passenger HUD    ---------------------
//----------------------------------------------------------------
//

//	If you dont want to use the TAC Passenger HUD put false here.

$TACClient::PassengerHUD = true;


//----------------------------------------------------------------
//------------------      TAC Pilot HUD      ---------------------
//----------------------------------------------------------------
//

//	If you dont want to use the TAC Pilot HUD put false here.

$TACClient::PilotHUD = true;

