$TAC::league = "Anzac Gamers League";
$TAC::allowCustomSkins = "true";
$TAC::controlledTourneyMode = "true";
$TAC::matchTimeLimit = 25;
$TAC::teamDamageScale = 1;
$TAC::teamScoreLimit = "";
$TAC::noLlamaSwap = "true";
$TAC::reportScores = "true";
$TAC::messageLog = "true";
$TAC::adminlog = "true";
$TAC::intelliKick = 2;
$TAC::AutoAntiTK = "true";
$TAC::TKFrequency = 240;
$TAC::ReverseDamageTK = 3;
$TAC::PurgatoryTK = 4;
$TAC::PunishmentTime = 300;
$TAC::ReverseFactor = 1.0;
$TAC::KeepSmurfLog = "true";
$TAC::AdminSmurfApp = "true";
$TAC::VoiceSpamLimit = 7;

// Vote disabling

$TAC::voteDisable[kick] = "false";
$TAC::voteDisable[purg] = "false";
$TAC::voteDisable[admin] = "true";
$TAC::voteDisable[cmission] = "false";
$TAC::voteDisable[tourney] = "true";
$TAC::voteDisable[ffa] = "false";
$TAC::voteDisable[etd] = "false";
$TAC::voteDisable[dtd] = "false";
$TAC::voteDisable[rape] = "false";
$TAC::voteDisable[norape] = "false";

// AdminGeneral Lockouts
$TAC::AdminDisable[cteam] = "false";
$TAC::AdminDisable[cmission] = "false";
$TAC::AdminDisable[warn] = "false";
$TAC::AdminDisable[purg] = "false";
$TAC::AdminDisable[depurg] = "false";
$TAC::AdminDisable[kick] = "false";
$TAC::AdminDisable[gag] = "false";
$TAC::AdminDisable[etd] = "false";
$TAC::AdminDisable[dtd] = "false";
$TAC::AdminDisable[rape] = "false";
$TAC::AdminDisable[norape] = "false";
$TAC::AdminDisable[score] = "false";
$TAC::AdminDisable[time] = "false";
$TAC::AdminDisable[hurtdisp] = "false";



// - Tribe Names

// Base Tribes (1)
$TAC::numberOfD1Tribes = 8;

$TAC::d1Tribe[1] = "Blood Eagle";
$TAC::d1TribeSkin[1] = "beagle";
$TAC::d1Tribe[2] = "Diamond Sword";
$TAC::d1TribeSkin[2] = "dsword";
$TAC::d1Tribe[3] = "Children of the Phoenix";
$TAC::d1TribeSkin[3] = "cphoenix";
$TAC::d1Tribe[4] = "Starwolf";
$TAC::d1TribeSkin[4] = "swolf";
$TAC::d1Tribe[5] = "Red";
$TAC::d1Tribe[6] = "Blue";
$TAC::d1Tribe[7] = "Gold";
$TAC::d1Tribe[8] = "Green";

// Tribes A-D (2)
$TAC::numberOfD2Tribes = 6;

$TAC::d2Tribe[1] = "[52nd]";
$TAC::d2TribeSkin[1] = "52nd";
$TAC::d2Tribe[2] = "{AWH}";
$TAC::d2TribeSkin[2] = "awh";
$TAC::d2Tribe[3] = "<AvA>";
$TAC::d2TribeSkin[3] = "ava";
$TAC::d2Tribe[4] = "[BD]";
$TAC::d2TribeSkin[4] = "bd";
$TAC::d2Tribe[5] = "[BA]";
$TAC::d2TribeSkin[5] = "ba";
$TAC::d2Tribe[6] = "[DH]";
$TAC::d2TribeSkin[6] = "clandh";




// Tribes E-L (3)
$TAC::numberOfD3Tribes = 7;

$TAC::d3Tribe[1] = "|:E:|";
$TAC::d3TribeSkin[1] = "sdk";
$TAC::d3Tribe[2] = "[EL]";
$TAC::d3TribeSkin[2] = "el";
$TAC::d3Tribe[3] = "[FX]";
$TAC::d3TribeSkin[3] = "fxb";
$TAC::d3Tribe[4] = "|GTP|";
$TAC::d3TribeSkin[4] = "gtp";
$TAC::d3Tribe[5] = "-HC-";
$TAC::d3Tribe[6] = "]I[";
$TAC::d3TribeSkin[6] = "IS";
$TAC::d3Tribe[7] = "=2K=";
$TAC::d3TribeSkin[7] = "2kclan";





// Tribes M-S (4)
$TAC::numberOfD4Tribes = 8;

$TAC::d4Tribe[1] = "[Malks]";
$TAC::d4TribeSkin[1] = "malks";
$TAC::d4Tribe[2] = "[MOM]";
$TAC::d4Tribe[3] = "=M=";
$TAC::d4TribeSkin[3] = "m";
$TAC::d4Tribe[4] = "<NV>";
$TAC::d4TribeSkin[4] = "novacula";
$TAC::d4Tribe[5] = "obot";
$TAC::d4Tribe[6] = "|ODT|";
$TAC::d4TribeSkin[6] = "odt";
$TAC::d4Tribe[7] = "]|sh|[";
$TAC::d4TribeSkin[7] = "sh";
$TAC::d4Tribe[8] = "|SpS|";
$TAC::d4TribeSkin[8] = "sp1";



// Tribes T-Z (5)
$TAC::numberOfD5Tribes = 5;

$TAC::d5Tribe[1] = "|THAT|";
$TAC::d5TribeSkin[1] = "THATArmorIII";
$TAC::d5Tribe[2] = "{VS}";
$TAC::d5TribeSkin[2] = "Vs";
$TAC::d5Tribe[3] = "[VH]";
$TAC::d5Tribe[4] = "[WK]";
$TAC::d5Tribe[5] = "zX-";



// Default Tribe Skins

$TAC::defaultTribeSkin[0] = "beagle";
$TAC::defaultTribeSkin[1] = "dsword";
$TAC::defaultTribeSkin[2] = "cphoenix";
$TAC::defaultTribeSkin[3] = "swolf";

// Passwords

$TAC::numberOfPass = 5;

$TAC::Pass[1] = match;
$TAC::Pass[2] = pass;
$TAC::Pass[3] = scrim;
$TAC::Pass[4] = prac;
$TAC::Pass[5] = priv;

