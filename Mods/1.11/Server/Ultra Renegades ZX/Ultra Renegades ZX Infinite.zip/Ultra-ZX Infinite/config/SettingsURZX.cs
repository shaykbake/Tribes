$mega::BanKickTime = "999999999999999999999999";
$mega::fairTeams = "true";
$mega::PABan = "false";
$mega::PAKick = "true";
$mega::PAMission = "true";
$mega::PAModOptions = "false";
$mega::PAResetDefaults = "false";
$mega::PATeamChange = "true";
$mega::PATeamDamage = "true";
$mega::PATeamInfo = "false";
$mega::PATimelimit = "true";
$mega::PATourneyMode = "false";
$mega::PAVote = "false";
$mega::tkClientLvl = "0";
$mega::tkLimit = "5";
$mega::tkMultiple = "3";
$mega::tkServerLvl = "1";

$Admin::KickMessage = "For being a complete Idiot, and total moron.....\n\n You are being kicked off of this server. \n\n Come back when you no longer have an attack of the dumbass.";

$PA::noKick = "True";  //if set to true, public admins cant be kicked by a vote

$PublicPassword = "change";  //public admin sad code
$AdminPassword = "change";   //super admin sad code
$OwnerPassword = "change";   //GOD Code! Only For trusted

$TelnetPassword = "betterchangemenow"; // Password for telnet connection
$TelnetPort = "2000"; // Port for telnet connection

$UltraZX::Infinite::Boost = "true"; // If set to True, boosts are infinite
$UltraZX::Infinite::Brake = "true"; // If set to True, brakes are infinite
$UltraZX::Infinite::RepairKit = "true"; // If set to True, repair kits are infinite