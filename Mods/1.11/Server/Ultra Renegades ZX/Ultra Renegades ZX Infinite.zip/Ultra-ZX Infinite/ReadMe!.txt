UltraZX Infinite by {TAS}KINDS

Installation Instructions:

1. Put the files in the 'config' folder into your Tribes/config folder.
2. Put the folder UltraZX_Infinite into your Tribes folder as it is.

For a dedicated server, right click the infinitespawn.exe file and click Create Shortcut. Right click the shortcut and 
click properties, add: 

		*tribes +exec ServerPrefs.cs +exec URZX.cs -mod UltraZX_Infinite -dedicated

For a non-dedicated server, right click Tribes.exe and click Create Shortcut, then right click the shortcut and click 
properties and add:

		+exec ServerPrefs.cs +exec URZX.cs -mod UltraZX_Infinite

Enjoy the mod! Infinite Boosts, Brakes and Repair Kits!