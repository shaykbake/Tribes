___________________________________________________
Ultra Renegades 4
___________________________________________________
By Dr. NoRtOn
___________________________________________________
Credits:

	Thrash for working on the original ur3, which is what I based this on.  

	George W. for helping me out with many of questions, and late night thinking sessions, and many bug fixes...

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	******YOU WILL NEED A SERVER RUNNING 1.11 TO USE THIS, AND CLIENTS WILL NEED 1.11 TO CONNECT******

	Just place the scripts.vol in a folder named Ultra Renegades4 or something, and place the ultra_renegades.cs file into your config folder along with serverconfig.cs.  To run a listen server, just make a shortcut to tribes and change the command line to:
 <tribes directory>\tribes.exe -mod Ultra Renegades4 +exec ultra_renegades.cs +exec serverConfig.cs.  
	To run a dedicated server just change the command line to:
 <tribes directory>\InfiniteSpawn.exe *tribes +exec serverConfig.cs +exec ultra_renegades.cs -mod Ultra Renegades4 -dedicated


Changes:
New Admin options, You can restart and lock the server from the tab menu...
Lag less beacons and air brakes.
Plasma Rifle
Explosive Chain
IX-2000 has no bug
ghetto blaster
2 point flag kills
mini plasma turrets
rocket turrets
cannot have spawn turrets etc
other things i  cannot think of..

feel free to email me xxgmanxx@home.com or icq 16164448

-Grayson
Dr. NoRtOn

*Disclaimer*
I am not responsible.