Ultra Renegades 3 League Mod readme.
Version 1.5 by ($A$)FSB-Deacon
15OCT00
www.ultrarenegades.com

1) Setting up a server.  

	******YOU WILL NEED A SERVER RUNNING 1.11 patch for Tribes. TO USE THIS, AND CLIENTS WILL NEED 1.11 TO CONNECT******

	Just place the scripts.vol in a folder named ultra_renegades3_league15. Place the ultra_renegades.cs file into your config folder.  To run a listen server, just make a shortcut to tribes and change the command line to:
 C:\Dynamix\Tribes\tribes.exe -mod ultra_renegades3_league15 +exec ultra_renegades.cs +exec serverconfig.cs.  
	To run a dedicated server just change the command line to:
 C:\Dynamix\Tribes\InfiniteSpawn.exe *tribes +exec serverConfig.cs +exec ultra_renegades.cs -mod ultra_renegades3_league15 -dedicated

If it doesn't work, you screwed up somewhere.  Smack yourself in the head a few times and hit your computer to work out any bugs and/or feelings of frustration, and try again.

2) Changes in League 1.5 version:
  -New improved beacon(booster) reliability. Adjustments to Booster speed.
  -New Altimeter (shows distance above and below your flag) Altimeter button assigned to Grenade Button.
  -Fixed Model Cheats. No more Llamas using happy flags and altered dts files.
  -Fix from 1.4 for Medium armor boost (dead stop)
  -Added a few VX weapons (by request of BoomBeef)
  -Added a maximum velocity cap on Heavies. (Meaning: Less people using Heavies as a flag runner.)
  -Removed ELF pull from version 1.4 (It was insane)


3) Credits:

	-The Dynamix Dev team.  95% of this code came from them.  Thanks for the great game.
	-*IX*Savage1 - Maker of the Insomniax and Insomniax admin mods (this mod uses a large portion of modified IXAdmin code).  His contribution to modding cannot be understated.  For more info on his work, go to www.insomniax.net/mods
	-LabRat - A number of his unofficial bug fixes are used in this mod, such as the ELF spam, heavy in a scout, and prev/next weapon lag.  For more info about his work, go to http://labrat1.simplenet.com/sstribes/
	-Snake Eyez - For his amazing beta testing and bug finding abilities (THAT'S FUCKING GAY!!!!) :)
	-My clanmates - some of the coolest people I know, always bouncing ideas off me (some of which sucked, but hey...) :P
	-Keyser, Celtic Legend, and sLaM - These guys gave UR a fair go, and are damn good at it.  
	-BoomBeef - Suggested the inclusion of certain VX weapons, to give those who like that mod something similar in this one.


($A$)FSB-Deacon
deacon@ultrarenegades.com