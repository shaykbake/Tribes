Created by: {187}George W. & Dr.NoRtOn
Original Mod by: ($A$)FSB-Deacon

Additions from 1.6:

-More balanced airbrakes
-Anti Spawn Kill
-Anti KPack Features
-Faster Gunfire
-Height Limitation with or without flag
-Resupply Pack
-Spy Satellite
-More Boosters, Less Brakes
-No more Pick Skin on join, Auto Custon Skin.
-Upon match countdown, "Attack!" in Male 4 voice is heard.
-Less velocities, meaning less lag.

Available at:
http://www.187clan.net/files/UR3League17.zip

It should be hosted at UltraRenegades.com ASAP.

Installation:

Extract "scripts.vol" to the folder named ultra_renegades3_league17 in the Tribes folder. If you are installing over 1.6, make sure you change the target:

ultra_renegades3_league16

Change to:

ultra_renegades3_league17

** IT IS VERY IMPORTANT THAT YOU UPDATE YOUR TARGET IN YOUR COMMAND LINE FOR THE SERVER OR IT WILL RUN BASE **

