// Ultra_Renagades_GZHQ
//===========================================================================================
// Server Parameters
$Server::HostName = "Server Name";	// Server Name
$Server::Port = "28001";					// Port used for client connections to server (usually 28001)
$Server::HostPublicGame = true;			// Server is shown in MasterServer List
$Server::Password = "";						// Password needed to join server
$AdminPassword = "YourMainSad";							// Local SuperAdmin password - CHANGE THIS
$pref::LastMission = "Blastside";		// This sets the first map in rotate when server launches (make sure it is spelled correctly)

//===========================================================================================
// Server Info Parameters (<jc> = center justified, <f1> = tan font, <f2> = white font, <f3> = orange font, \n = new line)
$Server::Info = "Ultra_Renagades_GZHQ\nAdmin: You\nEmail: Yours\nwww.TeamHybrid.org\nwww.GZHQ.net";	// Server information listed on MasterServer List	
$Server::MODInfo = "<jc><f2>www.TeamHybrid.org\n<f1>Welcome to Your Server Message\n<f1>Visit www.GZHQ.net";	// Information listed on server join screen
$Server::JoinMOTD = "<jc><f3>www.TeamHybrid.org\n<f1>Welcome to <f3>Ultra_Renagades_GZHQ<f1> Spank your mouse to join the game";	// Message of the day listed once connected to the server

//===========================================================================================
// Telnet (Console) Parameters
// If you want telnet access, set the port number to the desired port (23 is normal)
// BE SURE TO SET A PASSWORD THAT IS HARD TO GUESS
$TelnetPort="";								// Port for telnet connections
$TelnetPassword="";							// Password for telnet connections

//===========================================================================================
// Server Connection Parameters
$pref::PacketRate = 12;						// Packet rate for client connections
$pref::PacketSize = 200;					// Packet size for client connections

//===========================================================================================
// Annihilation Parameters
$UltraGZHQ::NetMask = "IP:192.168";	// This is used to increase server player limit when local LAN players connect.
$UltraGZHQ::IncreaseMax = true;		// If true, will increase player limit on server if IP of client connect matches NetMask.
$UltraGZHQ::GiveLocalAdmin = true;	// If true, will give SuperAdmin status to players who are on the same machine as the server.
$UltraGZHQ::ShoppingList = true;		// Set to true to limit item shopping list to display only items available for current armor.
$UltraGZHQ::ResetServer = false;		// Set to true to rotate server to next map in list when last player leaves.
$UltraGZHQ::KickTime = 180;			// Time (in seconds) for kicks.
$UltraGZHQ::BanTime = 1800;			// Time (in seconds) for bans.
$UltraGZHQ::StationTime = 200;		// Time allowed for Station Access.

//===========================================================================================
// Public Voting Parameters
$UltraGZHQ::VoteAdmin = false;		// Allow Voting a Public Admin in.
$UltraGZHQ::PVKick = true;				// Allow Public Kick Voting.
$UltraGZHQ::PVChangeMission = true;	// Allow Public Mission Voting.
$UltraGZHQ::PVTeamDamage = true;		// Allow Public Team Damage Voting.
$UltraGZHQ::PVTourneyMode = true;	// Allow Public Tournament Mode Voting.
$Server::AdminMinVotes = 4;				// Minimum number of votes needed to vote admin
$Server::MinVotes = 1;						// Minimum number of votes needed to pass
$Server::MinVotesPct = 0.5;				// Percentage of available votes needed to pass a vote
$Server::MinVoteTime = 25;					// Time allotted for voting
$Server::VoteAdminWinMargin = 0.8;		// Ratio of Yes to No votes needed to pass
$Server::VoteFailTime = 30; 				// 30 seconds if your vote fails + $Server::MinVoteTime
$Server::VoteWinMargin = 0.6;				// Ratio of Yes to No votes needed to pass
$Server::VotingTime = 20;					// Length of votes if people are voting.

//===========================================================================================
// SuperAdmin Passwords, Up to 100 are available
$UltraGZHQ::SADPassword[1] = "someSad";
$UltraGZHQ::SADPassword[2] = "";
$UltraGZHQ::SADPassword[3] = "";
$UltraGZHQ::SADPassword[4] = "";
$UltraGZHQ::SADPassword[5] = "";
// SuperAdmin Parameters
$UltraGZHQ::SADBan = 	true;				// Allow Super Admins to Ban.
$UltraGZHQ::SADGiveAdmin = 	true;		// Allow Super Admins to Give Public Admin to other players.
$UltraGZHQ::SADForceVote = 	true;		// Allow Super Admins to Force Votes to Pass/Fail.

//===========================================================================================
// Public Admin Passwords, Up to 100 are available
$UltraGZHQ::PAPassword[1] = "ArmsGod";
$UltraGZHQ::PAPassword[2] = "";
$UltraGZHQ::PAPassword[3] = "";
$UltraGZHQ::PAPassword[4] = "";
$UltraGZHQ::PAPassword[5] = "";
// Public Admin Parameters
$UltraGZHQ::PAKick = 	true;				// Allow Public Admins to Kick.
$UltraGZHQ::PATeamChange = 	true;		// Allow Public Admins to Change other Players Teams.
$UltraGZHQ::PAChangeMission= true;	// Allow Public Admins to Change the Mission.
$UltraGZHQ::PATeamDamage = 	true;		// Allow Public Admins to Enable/Disable Team Damage.
$UltraGZHQ::PATourneyMode = 	true;	// Allow Public Admins to Enable/Disable Tournament Mode.

//===========================================================================================
// Other Parameters
$UltraGZHQ::AutoAdmin = true; 	
	// Uses the UltraGZHQAdminList.cs in config, edit to your liking.

$UltraGZHQ::ResetSettings = true;	// Resets server settings from this file on map change.

$UltraGZHQ::FairTeams = true;			// Prevent team changing to the larger team

$UltraGZHQ::UsePersonalSkin = true;	// Allows use of Personal Skins

$UltraGZHQ::SafeBase = false;		
	// Base damage. True for safe (undestroyable) station and generators.

$UltraGZHQ::BaseHeal = false;	
	// Base healing. True for regenerating (self healing) station and generators.

$UltraGZHQ::VoteBuild = false;		// Allow voting on builder mode.

$UltraGZHQ::obsAlert = true;		
	// Observer alert, notifies player who is watching them in observer.

$UltraGZHQ::OutOfArea = false;		// Allow players out of bounds.

$UltraGZHQ::QuickInv = false;		// inventory without stations
$UltraGZHQ::ExtendedInvs = true;		// Extended Inventories, multiple use inventory stations.
$UltraGZHQ::Zappy = true;	
	// uses electro beams to verify Extended Inventories aren't covered with blastwalls, force fields etc..

$IpLogger = true;	//logs names by ip to UltraGZHQInfo.cs, and much more.
//===========================================================================================
// Player Parameters
$Server::MaxPlayers = "10";				// Maximum number of client connections allowed
$Server::AutoAssignTeams = true;			// Server assigned teams
$Server::RespawnTime = 2; 					// Number of seconds before a respawn is allowed
$Server::TimeLimit = 20;					// Mission time limit in minutes
$Server::WarmupTime = 0;					// Time (in seconds) players are left standing before movement is allowed
$Server::TeamDamageScale = 0;				// Team damage, 0 = Off, 1 = On
$Server::TourneyMode = false;				// Tournament mode

//===========================================================================================
// Team Parameters
$Server::teamName[0] = "[www.TeamHybrid.org]";		// Team 1 Name
$Server::teamSkin[0] = "Hybrid";			// Team 1 Skin
$Server::teamName[1] = "[www.GZHQ.net]";	// Team 2 Name
$Server::teamSkin[1] = "base";			// Team 2 Skin
$Server::teamName[2] = "Subversion";	// Team 3 Name
$Server::teamSkin[2] = "cphoenix";		// Team 3 Skin
$Server::teamName[3] = "Downfall";		// Team 4 Name
$Server::teamSkin[3] = "swolf";			// Team 4 Skin
$Server::teamName[4] = "Generic 1";		// Team 5 Name
$Server::teamSkin[4] = "base";			// Team 5 Skin
$Server::teamName[5] = "Generic 2";		// Team 6 Name
$Server::teamSkin[5] = "base";			// Team 6 Skin
$Server::teamName[6] = "Generic 3";		// Team 7 Name
$Server::teamSkin[6] = "base";			// Team 7 Skin
$Server::teamName[7] = "Generic 4";		// Team 8 Name
$Server::teamSkin[7] = "base";			// Team 8 Skin

//===========================================================================================
// Console Parameters
$Console::LogMode = "1"; 	// Log the console to a log file.

//===========================================================================================
