I just want to say a little about copyright laws, and this program. 

COPYRIGHT LAW U.S.C. ACT 17 SECTION 102 (a) SAYS (in retard form)

  AS SOON AS ANYTHING AT ALL IS ORIGINAL AND IS PUT IN THE FORM OF A TANGIBLE MEDIUM
  IT IS AUTO COPYRIGHTED FOR 70 YEARS. YOU DON'T NEED AN OFFICIAL COPYRIGHT FROM THE 
  GOVERNMENT, OR ANYTHING LIKE THAT. 

  -Original: This means it is a new idea, aka: a mod, script, file, conversation, picture 
             video, ect...
  
  -Tangible Medium: This means the Original Idea is in a physical form, (pretty much anything
   that is not just an idea, or in your head) so as soon as the idea is put on paper, or on 
   a hard drive or anything else, IT IS COPYRIGHT. 

 HOW THIS EFFECTS YOU:  BY DOWNLOADING THIS MOD, YOU ACKNOWLEDGE THAT IT IS ILLEGAL FOR YOU TO 
 CHANGE, ALTER, OR OTHERWISE MODIFY ANYTHING CONTAINED HERE-IN OR FOUND IN ANY OF XCALIBURS .cs FILES OR ANY XCALIBUR RELATED FILES.
 UNLESS YOU HAVE THE EXPRESSED WRITTEN CONSENT OF +]-[+WorstAim (ME). 

 IF I HAVE ANY PROBABLE CAUSE TO BELIEVE THAT ANY OF THESE LAWS HAVE BEEN BROKEN, I WILL 
 (at my discretion (+]-[+WorstAim) ) PURSUE YOU TO THE FULL EXTENT OF NATIONAL AND INTERNATIONAL LAW.

Find out more about copyright laws here:
http://www.WhatIsCopyRight.Org



Thanks For Downloading XCalibur.  First, I Want To Give Credit To All
That Deserve It.  I Give Credit To The Following People.

- |*|w00|*|Grey   I Learned How To Script By Reading Through GreyBOT's 
		  Scripts Over And Over, So I Give Grey Lots Of Credit
		  As Well As Anyone Else That Helped With GreyBOT.

- VRWarper        Anytime I Had A Question He Always Answered And
		  Helped Me Out A Lot.

- [GL]JadaCyrus   I Stripped The Whereis Function Straight From CoreMAN
		  And Give Jada Full Credit For It.

Now Onto The Commands

All You Have To Do Is Type These In Where You Would Normally Type To Chat.

*****************
*Public Commands*
*****************
	Command			Function

	Typing Nothing Into The Message Box Will Clear All Center, Top, and Bottom Printed Messages

        !XCalibur          	"Gives Server Stats"
        !XCredits          	"Gives Credit As Show Above"
	!YourClanTag       	"Gives Info About Your Clan Tag" NOTE: You Must Fill In $ClanTag For This To Work.
	!whereis personsname	"Sets A Waypoint To The Person Specified"
	!listadmins		"Lists All The Admins Currently In The Server"
	!stop 			"Stops You From Moving, Like An AirBreak"
	!killbug		"Reloads Swarmer. Works Only If You Are Hosting Meltdown Classic"
	!pmsg personsname	"Sends A Private Message To The Name Specified"
	!urgent			"Sends An Urgent Message To Server Host In A File Called Urgent.txt"

****************
*Admin Commands*
****************
Admin Type	Command			Function

(PublicAdmin)	!playerlimit            "Sets How Many People Can Connect"
(PublicAdmin)	!cleanup  		"Kicks All But Admins"
(PublicAdmin) 	!PA Message		"Sends A Message To All Other Public Admins"
(SuperAdmin)	!ServerPass Password	"Sets The Server Password"
(SuperAdmin)    !ClearServerPass        "Clears The Server Password"
(SuperAdmin)	!cloak			"Cloaks You Until You Type !cloak Again, And Than It Times Down 30 Seconds, And Uncloaks You"
(SuperAdmin)	!SA Message		"Sends A Message To All Other Super Admins"
(SuperAdmin)    !centerprintall	Message	"Allows You To Type A Message And Have It Center Printed To Everyone (you can use <F0>, <F1>, <F2>, <jl>, <jc>, and <jr> before the message you type, but after the ! command"
(SuperAdmin)    !topprintall Message	"Allows You To Type A Message And Have It Top Printed To Everyone (you can use <F0>, <F1>, <F2>, <jl>, <jc>, and <jr> before the message you type, but after the ! command"
(SuperAdmin)    !bottomprintall	Message	"Allows You To Type A Message And Have It Bottom Printed To Everyone (you can use <F0>, <F1>, <F2>, <jl>, <jc>, and <jr> before the message you type, but after the ! command"
(SuperAdmin)    !cmsg Message 		"Allows You To Talk Anonymously With Color (!cmsg type message)(type can be any number 0 - 4)
(SuperAdmin)   	!msg Message		"Allows You To Talk Through XCalibur"
(SuperAdmin)    !FindIP ExactClientName "Allows You To Find The IP Of The Name Of The Person You Put In.  They Do Not Have To Be In The Game.  From Their You Can Use Them In A Recent Player Option Which Appears Under The Server Options Option Once The !FindIP Command Has Been Used"
(MasterAdmin)	!MA Message		"Sends A Message To All Other Master Admins"
(XCaliburs)	!DXISTRUE          	"Allows You To De-XCalibur Other XCaliburs, The Option Is Added To Your XCalibur Options Menu"
(XCaliburs)	!immortal		"Makes You Immortal Until You Type !immortal Again, And Than It Times Down 30 Seconds, And Makes You Mortal Again"
(XCaliburs)     !XA Message		"Sends A Message To All Other XCaliburs"

****************
* Admin Logins *
****************

XCalibur Does Not Let You Get Admin Via The Console (No More sad("") )
Now You Have To Type It In As Specified Below.

To Login As A Public Admin:

	!PublicAdmin yourpublicadminpassword

To Login As A Super Admin:

	!SuperAdmin yoursuperadminpassword

To Login As A Master Admin: 

	!MasterAdmin yourmasteradminpassword

To Login As An XCalibur:

	!XAdmin yourXCaliburpassword

NOTE: YOU CANNOT Type !PublicAdmin And Type A SuperAdmin Password.  It Won't Work.
You Can Only Use The Password Corresponding To The Type Of ! Admin Login Command 
You Are Using.

There are More Commands, Relating To Kicking And Banning, As Well As More Relating To The X-List
They Will Be Explained As You Try To Use Them.

CLAN CHAT:

If You Turn Clan Chat On, If You Are In The Clan Specified In $ClanTag, Any Message Sent By Anyone Else
In The Clan Will Be Sent To Anyone In The Clan, And No One Else. You Will Not Be Able To Respond Any Other 
Way Until ClanChat Is Turned Off. Clan Chat Can Be Turned On Only By MasterAdmins And XCaliburs.  It Is Turned
On Through The Tab Menu Under Admin Menu.

Recordings:

XCalibur Records And Exports All Crash Attempts Made On Your Server To A File Called CrashAttempts.txt
XCalibur Records And Exports Everything Said In Your Server To A File Called chat.txt
XCalibur Records And Exports All Commands Used In Your Server To A File Called commands.txt
XCalibur Records And Exports All Connections Made To Your Server To A File Called Connections.txt (Don't worry about the other connection files.  You Can Open Them, But Don't Change Them Because It Could Cause The Alias Option To Not Function)
XCalibur Records And Exports All Reasons For Kicks And Bans, As Well As Ban Messages And Kick Messages And The Person That Did The Kick/Ban.  Same With X-List Related Stuff.
XCalibur Records And Exports All X-List Related Stuff. You Can Open The Files (MPW.cs, PPW.cs, SPW.cs, XPW.cs, MNames.cs, XNames.cs, SNames.cs, PNames.cs) But Don't Touch Anything In Them Unless You Know What Your Doing
XCalibur Records And Exports All Successful Admin Logins To A File Called AdminLog.txt All Unsuccessful Logins Go To A File Called Attempts.txt
If Someone Is An Imposter, XCalibur Records And Exports Their Info To A File Called imposters.txt
If Someone Is A Tagless Member, XCalibur Records And Exports Their Info To A File Called Tagless.txt

X-List:

The XCalibur X-List Was Created Entirly By Me (  WorstAim  ) And So Were All Its Functions.  
The X-List Allows You To Modify And Access All Information Relating To Admins and Bans Through The Tab Menu.
You Can Have As Many Admins Added To It, Same Goes With Bans, But, It Only Allows Access To 7 Players Of Each 
Type Of Admin, And Of Each Type Of Ban.  The Reason For This Is It Takes A Very Long Time To Make Each Menu, And 
Its Options Since Everyone Is A Completely Different One For Each Name.  7 Names = about 70 Or So Pages Of Code.
I Just Didn't Want To Make More Menus.  It Would Take To Long.  So Don't Complain.

Thats About It. Hope You Like It.

PLEASE DO NOT DELETE, CHANGE, OR MODIFY IN ANY WAY, ANY THING IN THIS FILE.  I WORKED VERY HARD AT IT, AND WOULD NOT
LIKE MY WORK CHANGED, AT ALL. ALSO, DON'T TAKE MY LIST CODE, AND SAY YOU CAME UP WITH IT, OR THE IDEA. IF YOU DO TAKE THE 
CODE PLEASE PLEASE PLEASE GIVE ME CREDIT. LAST:

*******************************************************************************************************************************

 XCALIBUR IS COPYRIGHTED. BELIEVE IT OR NOT, UNDER COPYRIGHT LAW: 17 U.S.C. 102(a). SO DO NOT CHANGE IT (November 12th, 2003). 

*******************************************************************************************************************************

-   WorstAim    -

XCalibur�  Is CopyRighted Under Copyright Law 17 U.S.C. 102(a)