Jinzo's PB Map Pack

====================================================================
Install Instrustions:

Uzip the files to this (C:/Dynamix/Tribes/base/Missions) 

And Fire Up tribes And Rock and Roll
====================================================================
If you have any problems with my maps or something here is my stats

Game Name:+]-[+{jInZo}+
AIM:TeRrAvEgAnCe
email:jinzo@666clan.org

 I'd Like to give thanks to my bros in the +]-[+. Especially +]-[+Armageddon and +]-[+WorstAim.(He did the pb_arena map). 



Hybrid website 
www.teamhybrid.org



\\\\\\\CREDITS & THANKS///////////////

+]-[+Armageddon -Thanks bro for help with my many questions and stupid shit i came up with :).
+]-[+WorstAim- Thanks for all the help.
+]-[+WhIzAtIt-Thanks for being a server host of my maps. 
+]-[+HaWk-Thanks for being a swell server host.
{-o-}Plasmatic- Without this guys tutroil ive wouldve never learn to make maps.
.:(A):.Kevin:.-thanks for all the advice and help bro.

ALL MAPS ARE PROTECTED BY COPYRIGHT LAW U.S.C. Act 17 Section 102 (a) �  . You May not change ANY part of these maps without the expressed written consent of +]-[+{jInZo}+,+]-[+WorstAim, or +]-[+Armageddon.

And you think you can take my stuff and make it your own. Try and im coming after your ass.

