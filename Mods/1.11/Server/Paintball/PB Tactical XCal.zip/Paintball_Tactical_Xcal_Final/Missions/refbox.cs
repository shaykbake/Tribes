function GroupTrigger::onEnter(%this, %object)
{
	%client = Player::getClient(%object);
	if(%this.num == "Main2")
	{
		if(%client.isAdmin)
		{
			centerprint(%client, "<jc><F1>WELCOME TO THE REF BOX", 5);
			Strip(%client);
			Immortal(%client);
      			%positionIn = "-225.492 454.592 132.891";
      			%positionOut = "";
		}
   	}
      	else if(%this.num == "Main1")
	{
		UImmortal(%client);
		centerprint(%client, "<jc><F1>WELCOME BACK TO THE GAME", 5);
      		%positionIn = "-183.416 559.992 71.5056";
      		%positionOut = "";
   	}
   	else if(%this.num == "Main3")
	{
      		%positionIn = "-305.484 221.298 1000.27";
      		%positionOut = "";
   	}
    	else if(%this.num == "Main4")
	{
      		%positionIn = "-197.286 360.78 -60.7411";
      		%positionOut = "";
   	}		
  	if(%this.in)
	{ 
         	GameBase::setPosition(%client, %positionIn);
         	//messageAll(0, "~wshieldhit.wav");
	   	Client::SendMessage(%client,0,"~wshieldhit.wav");
      	}
      	else if(%this.out)
	{
         	GameBase::setPosition(%client, %positionOut);
         	//messageAll(0, "~wshieldhit.wav");
         	Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
}
function Immortal(%client)
{
	%client1 = Player::getClient(%client);
	Admin::Immortal(%client, %client1);
}
function Strip(%client)
{
	if(%client.observerMode == "" || %client.observerMode == "pregame")
	{
			%numweapon = Player::getItemClassCount(%client,"Weapon");
			%max = getNumItems(); 
			for (%i = 0; %i < %max; %i = %i + 1)
			{
				%item = getItemData(%i);
				%count = Player::getItemCount(%client,%item); 
				if(%count)
				{
					Player::setItemCount(%client,%item,0); 
				}
			}
	}
}
function Admin::Immortal(%client1, %player)
{
	%player = Client::getOwnedObject(%client1);
	Player::setDamageFlash(%player, 75);
	GameBase::playSound(%player,ForceFieldOpen,0);
        %player.shieldStrength = 999.3;
}
function UImmortal(%client)
{
	%client1 = Player::getClient(%client);
	UMortal(%client, %client1);
}
function UMortal(%client1, %player)
{
	%player = Client::getOwnedObject(%client1);
	%player.shieldStrength = 0;
}