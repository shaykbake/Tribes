//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
//												           *
//					       						                   |
//	PAINTBALL V. *TACTICAL_XCAL*				                                           *		
//													   |
// � Paintball V. *Tactical_XCal* �  By +]-[+DT (Hybird Development Team): +]-[+Armageddon+, +]-[+WorstAim *
//                                                                                                         |
//   COPYRIGHT 1998 - 2004 By +]-[+Armageddon+, +]-[+WorstAim                                              *          
//	                                                                                                   |
//   � PROTECTED BY COPYRIGHT LAW U.S.C. Act 17 Section 102 (a) �                                          *
//                                                      						   |				           
//   For all you numbnuts out there, this means DO NOT UNDER ANY CIRCUMSTANCES CHANGE ALTER, OR OTHERWISE  *
//   MODIFY ANYTHING CONTAINED IN THIS, OR ANY OTHER OF HYBRIDS CODE, UNLESS GIVEN THE EXPRESSED WRITTEN   |
//   CONSENT OF +]-[+Armageddon+ and +]-[+WorstAim                                                         *
//									                                   |     
//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* 

//**************************
//* Installation
//**************************

1a.Place The PBTactical.cs File into your Tribes Config Folder.
1b.Place The Scripts.vol File Into A Folder Called PBTactical In Your Tribes Folder (If The PBTactical Folder Does Not Exist, Create It)

2.Create a ShortCut from your C:\Dynamix\Tribes Folder to your Desktop.

(Dedicated Server Setup)
3a.Right Click your new ShortCut and Choose Properties,You will find a text area
   called "Target Line" For a dedicated server add this line to the "Target Line"
   Field: C:\Dynamix\Tribes\InfiniteSpawn.exe TRIBES +exec PBTactical.cs -mod PBTactical -dedicated
(Non-Dedicated Server Setup)
3b.Right Click your new ShortCut and Choose Properties,You will find a text area
   called "Target Line" For a dedicated server add this line to the "Target Line"
   Field: C:\Dynamix\Tribes\Tribes.exe +exec PBTactical.cs -mod PBTactical 

4.Before starting your server open the file called PBTactical.cs that you have placed in your
  Config folder, Inside you will find all of your serverprefs, Change them to fit your
  Needs.

//**************************
//* Need Help?
//**************************

Feel free to E-mail or Instant Message Any of the following people.

+]-[+Armageddon+ - Lead Programmer/Development Team Leader
E-mail: ArmageddonHatesU@Aol.Com
AIM: ArmageddonHatesU

+]-[+WorstAim - Xcalibur Programmer/Secondary Programmer/Admin Help/Server Help
E-mail: andrewlc168@cswebmail.com
AIM: DiStUrBeD394

+]-[+WhIzAtIt+ - Server Help
E-mail BDelony@sport.rr.com
AIM: WhIzAtWeRk

+]-[+{jInZo}+ - Leader of +]-[+/ Head Mapper for Tactical/ Server Help
E-Mail: RichaFer9@aol.com 
AIM: TeRrAvEnGaNcE

If your problem can't be solved by these guys then head here for more help on the forum
http://www.TeamHybrid.Org

//**************************
//* Credits
//**************************

For the first time in  History I was not the only one to work on this project.
These people below gave alot of there time and skill to make Paintball V. *Tactical_XCal* the best Paintball Mod
out. I'd like to personally thank WorstAim for his hard work and help on this.
Thanks!

Armageddon - Lead Programmer of Paintball V. *Tactical_XCal* Mod 1998-2004 (Now Retired From Tribes1)
WorstAim - Administration Programmer and Secondary Programmer of Paintball V. *Tactical_XCal* Mod 2003-2004 (Also Retired From Tribes1 Finally :) )
WhIzAtIt - Complete ASS! ya know i love ya bro :)
jInZo- Main Mapper 