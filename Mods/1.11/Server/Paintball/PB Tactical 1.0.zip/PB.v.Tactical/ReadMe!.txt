//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-		
//													   |
// � Paintball .vTactical �  By +]-[+DT (Hybird Development Team): +]-[+Armageddon+  +]-[+WorstAim+        *
//                                                                                                         |
//   COPYRIGHT 2004 By +]-[+Armageddon+   +]-[+WorstAim+                                  *          
//	                                                                                                   |
//   � PROTECTED BY COPYRIGHT LAW U.S.C. Act 17 Section 102 (a) �                                          *
//                                                      						   |				           
//   For all you numbnuts out there, this means DO NOT UNDER ANY CIRCUMSTANCES CHANGE ALTER, OR OTHERWISE  *
//   MODIFY ANYTHING CONTAINED IN THIS, OR ANY OTHER OF HDTs CODE, UNLESS GIVEN THE EXPRESSED WRITTEN      |
//   CONSENT OF +]-[+Armageddon+  +]-[+WorstAim+                                             *
//									                                   |     
//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* 

//**************************
//* Installation
//**************************

1.Place The Paintball.cs File & scripts.vol into your Tribes Config Folder.

2.Create a ShortCut from your C:\Dynamix\Tribes Folder to your Desktop.

(Dedicated Server Setup)
3a.Right Click your new ShortCut and Choose Properties,You will find a text area
   called "Target Line" For a dedicated server add this line to the "Target Line"
   Field: C:\Dynamix\Tribes\InfiniteSpawn.exe TRIBES +exec Paintball.cs -mod Paintball -dedicated
(Non-Dedicated Server Setup)
3b.Right Click your new ShortCut and Choose Properties,You will find a text area
   called "Target Line" For a dedicated server add this line to the "Target Line"
   Field: C:\Dynamix\Tribes\Tribes.exe +exec Paintball.cs -mod Paintball 

4.Before starting your server open the file called Paintball.cs that you have placed in your
  Config folder, Inside you will find all of your serverprefs, Change them to fit your
  Needs.

//**************************
//* Need Help?
//**************************

Feel free to E-mail or Instant Message Any of the following people.

+]-[+Armageddon+ - Lead Programmer/Development Team Leader
E-mail: ArmageddonHatesU@Aol.Com
AIM: ArmageddonHatesU

+]-[+WorstAim - Xcalibur Programmer/Admin Help/Server Help
E-mail: andrewlc168@cswebmail.com
AIM: DiStUrBeD394

+]-[+WhIzAtIt+ - Server Help
E-mail BDelony@sport.rr.com
AIM: WhIzAtWeRk

If your problem can't be solved by these guys then head here for more help on the forum
http://www.TeamHybrid.Org

//**************************
//* Credits
//**************************

Armageddon - Programmer of Paintball v.Tactical Mod 2004
WorstAim - Programmer of Paintball v.Tactical Mod 2004
JinZo - Main Tactical Mapper
WhIzAtIt - Complete ASS! ya know i love ya bro :)