Jinzo's PB Map Pack

====================================================================
Install Instrustions:

Uzip the files to this (C:/Dynamix/Tribes/base/Missions) 

And Fire Up tribes And Rock and Roll
====================================================================
If you have any problems with my maps or something here is my stats

Game Name:+]-[+{jInZo}+
AIM:darkmagician5519
email:jinzo@666clan.org

 I'd Like to give thanks to my bros in the +]-[+. Especially +]-[+Armageddon and +]-[+WorstAim.(He did the pb_arena map). 



Hybrid website 
www.teamhybrid.org