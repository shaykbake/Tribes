$Server::Address = "IP:24.242.46.222:64238";
$Server::AutoAssignTeams = "true";
$Server::CurrentMaster = "0";
$Server::FloodProtectionEnabled = "false";
$Server::HostName = "+]-[+Paintball+]-[+";
$Server::HostPublicGame = "true";
$Server::Info = "<jc><F2>+]-[ybrid+ <F1> Paintball\n<F2>Admin: <F1>+]-[+Armageddon+\n<F2>Email: <F1>ArmageddonHatesU@Aol.Com\n<F2>www.TeamHybrid.org";
$Server::JoinMOTD = "<jc><f1>Message of the Day:\nWelcome to <f2>Paintball!\n\nFire to spawn.";
$Server::Master1 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";
$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "Tribes Master";
$Server::MasterName1 = "UK Tribes Master";
$Server::MasterName2 = "Australian Tribes Master";
$Server::MaxPlayers = "12";
$Server::MinVotes = "1";
$Server::MinVotesPct = "0.5";
$Server::MinVoteTime = "45";
$Server::numMasters = "3";
$Server::Port = "28001";
$Server::respawnTime = "2";
$Server::TeamDamageScale = "0";
$Server::teamName0 = "Red";
$Server::teamName1 = "Blue";
$Server::teamName2 = "Green";
$Server::teamName3 = "Orange";
$Server::teamName4 = "Generic 1";
$Server::teamName5 = "Generic 2";
$Server::teamName6 = "Generic 3";
$Server::teamName7 = "Generic 4";
$Server::teamSkin0 = "beagle";
$Server::teamSkin1 = "blue";
$Server::teamSkin2 = "green";
$Server::teamSkin3 = "orange";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";
$Server::timeLimit = "0";
$Server::TourneyMode = "false";
$Server::VoteAdminWinMargin = "0.659999";
$Server::VoteFailTime = "30";
$Server::VoteWinMargin = "0.699999";
$Server::VotingTime = "20";
$Server::warmupTime = "5";
$Server::XLMaster1 = "IP:198.74.38.23:28000";
$Server::XLMaster2 = "IP:Broadcast:28001";
$Server::XLMasterN0 = "IP:198.74.32.55:28000";
$Server::XLMasterN1 = "IP:198.74.35.10:28000";
$Server::XLMasterN2 = "IP:198.74.40.67:28000";
$pref::LastMission = "PB_IceCold_TH";

//==============================
// Start New PB Admin Options
//==============================

//Ban time in seconds
$Paintball::BanKickTime = "5000";

//Auto assign new players to teams to make it fair
$Paintball::fairTeams = "true";

//Number of seconds the player is allow to be outside of the mission area
$Paintball::LeaveAreaTime = "20";

//Players are allowed to change teams
$Paintball::ChangeTeams = "true";

//Number of seconds a player can be in an inventory station before being ejected
$Paintball::StationKickTime = "20";

//Public Admin options
$Paintball::PABan = "false";
$Paintball::PAKick = "true";
$Paintball::PAGag = "true";
$Paintball::PAMission = "false";
$Paintball::PAModOptions = "false";
$Paintball::PAResetDefaults = "false";
$Paintball::PATeamChange = "false";
$Paintball::PATeamDamage = "false";
$Paintball::PATeamInfo = "false";
$Paintball::PATimelimit = "false";
$Paintball::PATourneyMode = "false";
//Is public admin votable
$Paintball::PAVote = "false";

//Are players permitted to use personal skins
$Paintball::PersonalSkins = "true";

//Public voting options
$Paintball::PVKick = "true";
$Paintball::PVMission = "false";
$Paintball::PVTeamDamage = "false";
$Paintball::PVTourneyMode = "false";

//What the client can do to TK'ers (0=vote, 1=kick)
$Paintball::tkClientLvl = "0";

//Number of TK's a player can recieve before being punished
$Paintball::tkLimit = "3";

//Number of TK's after tkLimit to retry tkServerLvl action
$Paintball::tkMultiple = "3";

//What the server does to TK'ers (0=log, 1=vote, 2=vote until kicked, 3=auto-kick)
$Paintball::tkServerLvl = "3";

//Super Admin password
$AdminPassword = "insertpasswordhere";

//Public Admin password
$RegularAdminPassword = "adminme";

//Telnet port for things such as EZConsole
$TelnetPort = 28100;

//Telnet password for things such as EZConsole
$TelnetPassword = "insertpasswordhere";

//Force the clients to use this many packets per second (8 recommended)
$pref::PacketRate = 8;

//Force the client to use packets of this size (200 recommended)
$pref::PacketSize = 200;

//Auto-kick morons by name (maximum of 5 names)
$Paintball::AutoKickDumbass[0] = "Tribes_sucks";
$Paintball::AutoKickDumbass[1] = "";
$Paintball::AutoKickDumbass[2] = "";
$Paintball::AutoKickDumbass[3] = "";
$Paintball::AutoKickDumbass[4] = "";
