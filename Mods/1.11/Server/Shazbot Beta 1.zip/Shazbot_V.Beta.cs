$TelnetPort = "28001";
$TelnetPassword = "asdfas";
$AdminPassword = "JinzoX";
