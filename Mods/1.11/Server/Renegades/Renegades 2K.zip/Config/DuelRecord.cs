$Duel::RecordHolder = "{PaGaN}Scavenger";
$Duel::RecordNum = "10";
$Duel::RecordTime = "2.50399";
$Duel::RecordTimeHolder = "Squirrl";
$Duel::RecordTimeLoser = "bugg218";
