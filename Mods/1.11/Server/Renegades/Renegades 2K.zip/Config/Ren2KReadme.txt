Renegades 2K v1.3

Extract the files into the appropriate directories:

tribes/renegades <--should remain completely empty, it is only used to hold the name Renegades

tribes/2K
	scripts.vol	<--This should be the only file in this folder

tribes/config
	ixUserList.cs
	DuelRecord.cs
	ServerPrefs.cs
	stats.cs

tribes/base/missions
	TheMountain.dsc
	TheMountain.mis
	
Sample command line to use with infinitespawn:

C:\Tribes\InfiniteSpawn.exe *tribes.exe  -mod 2k -mod Renegades +exec serverConfig -dedicated