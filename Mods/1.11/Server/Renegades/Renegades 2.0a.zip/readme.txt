************************Renegades 2.0 server fix***********************

    This is the same vol. files used for Renegades 2.0 with two minor
 adjustments that should lower the server lag and crashes. Alot of poeple have complained about these issues pertaining to this mod.

   The vulcan and Interceptors rate of fire is still the same, but you
will notice that the effects have been taken out,replaced by magnum bullets to free up some server resources. This will not effect the rate of damage. When you get too many Interceptors and vulcans firing at one time, It seriously drops the resources of the server,causes lag and even crashes the server. Im hoping this will remedy this problem a little bit.  Anyone running 1.3 should not use this file without upgrading to Renegades2.0 first. 

 Special thanks go's to <SSA>Dirje for creating the fix and allowing the release of it. Also thanks go's out to Secret Society Assassins for testing the fix on thier servers. 

Server Install: Unzip the scripts.vol file into Tribes\renegades

For full Renegades mod installation please download Renegades2.0
and read the txt. file. If you have questions or comments,direct them to zandog@whyweb.com

Disclaimer: This file is to be used at your own risk. I am not responsible for any damage this game modification may cause you or anything having to do with you. If your computer explodes because
you microwave this file, it is purely your responsibility.I also am not responsible for any hardware failures or software problems that may arise in TRIBES, your computer, or life in general.  If you would like to host this mod.. feel free. <SSA>QueenRecon                                  www.members.home.net/secretsociety 

*************Secret Society Assassins� / Fire Team Alpha�**************