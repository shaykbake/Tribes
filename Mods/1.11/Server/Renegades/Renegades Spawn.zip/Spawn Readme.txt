Put together by [CkH] ZOD with Duel and Arena Mission types built in.

INSTALLATION:

1. Create a folder under your Tribes Directory named "RenegadesSpawn" without the quotes.
2. Unzip the contents of this zip file into that folder.
3. Edit the ixUserList.cs and ixAdmin.cs files to suit your needs.
4. Create a shortcut on your desktop to InfiniteSpawn.exe
5. Right click the shortcut and choose "Properties" from the menu:

Where it says "Target:" Type in the box "C:\Dynamix\Tribes\InfiniteSpawn.exe *Tribes -mod RenegadesSpawn +exec serverConfig" 
without quotes. Where its says "Start in:" Type the path to your Tribes folder, i.e. "C:\Dynamix\Tribes" and click on the "apply" button.
Now click on the "OK" button. Double click the shortcut to start your server.

NOTE:If your Tribes is not installed in the default location on your hard drive you must adjust accordingly all paths.

Included is a batch file and shortcut you could move to your desktop that will do exactly what the shortcut does.
It is setup for the default Tribes installation.

Happy Spawn Rushing!


