$Server::respawnInvulnerableTime = 6; // 6 second invulnerable period
$Insomniax::BanKickTime = "600";
$Insomniax::fairteams = "false";
$Insomniax::LeaveAreaTime = "20";
$insomniax::PABan = "false";
$insomniax::PAFairTeams = "true";
$insomniax::PAGag = "true";
$insomniax::PAKick = "true";
$Insomniax::PAMission = "true";
$insomniax::PAModOptions = "true";
$insomniax::PAResetDefaults = "true";
$insomniax::PATeamChange = "true";
$insomniax::PATeamDamage = "true";
$Insomniax::PATeamInfo = "true";
$Insomniax::PATimeLimit = "true";
$insomniax::PATourneyMode = "true";
$Insomniax::PAVote = "true";
$insomniax::PSkin = "true";
$insomniax::PVFairTeams = "true";
$insomniax::PVKick = "true";
$insomniax::PVMission = "true";
$insomniax::PVTeamDamage = "true";
$insomniax::PVTourneyMode = "true";
$Insomniax::SafeStation = "true";
$Insomniax::StationTime = "20";
$Insomniax::tkClientLvl = "0";
$Insomniax::tkLimit = "3";
$Insomniax::tkMultiple = "2";
$Insomniax::tkServerLvl = "2";
$DefaultTeamEnergy = "Infinite";

//super admin sad code
$AdminPassword = "changeme";

//log people who are kicked by admins, to config\\KickList.log
$ExportAKicks = true; 

//log people who are kicked by the computer, to config\\KickList.log
$ExportCKicks = true;
