****************************************************
HaVoC Duel and Duel Tournament for base servers BETA
****************************************************

These are 2 mission types for Tribes.  They do not modify any part
of base Tribes (except for allowing different types of observing).
To install simply unzip into your Tribes folder.  Files will be 
placed as follows:

Tribes\base\duelmatch.cs
Tribes\base\duelmod.cs
Tribes\base\Mine.cs
Tribes\base\observer.cs
Tribes\base\resetduel.cs

All .WAV files will be placed in your Tribes\base folder.  All other
files will be placed in the Tribes\base\missions folder.

Now just start your server and change to a Duel or Duel tournament map!


Besides giving you just the 2 new mission types, you also get:

* Support for any number of mission types on the TAB menu.
* The D&D and CTF versions of the map ObsidianNight_2.
* The ability to use different observer modes.


*******
CREDITS
*******
While Duel Tournament was written entirely by myself, the original Tribes 
code for Duel was written by Drink|Kaluhua.  I have since rewritten the 
code to add new features and fix bugs.  Much thanks go out to him for 
letting me work on this great project!!!

Enjoy!


Nathan Sweet
[HvC]NaTeDoGG
natedone@hotmail.com
http://havoc.sirris.com


Note: The HaVoC mod comes with Duel and Duel Tournament integrated into 
it.  DO NOT INSTALL DUEL FOR BASE SERVERS ON A HAVOC SERVER.  You'll screw
stuff up.  =)