StaticShapeData VehiclePad
{
   description = "www.haLoMaTriX.com";
	shapeFile = "inventory_sta";
	className = "Station";
	visibleToSensor = true;
	maxDamage = 1000.0;
	debrisId = flashDebrisLarge;
	mapFilter = 4;
	mapIcon = "M_station";
	damageSkinData = "objectDamageSkins";
	shadowDetailMask = 16;
	triggerRadius = 1.5;
   explosionId = flashExpLarge;
};


