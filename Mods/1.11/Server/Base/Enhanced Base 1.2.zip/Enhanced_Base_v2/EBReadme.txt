//////////////////////
//Enhanced Base v1.1//
//  By Timer[TiZ]   //
// �Copyright 2000  //
//////////////////////

Great thanks from the TiZ team (me) >=) for downloading
Enhanced Base v1.0, for Starsiege Tribes

CONTENTS:

  i)  Changes, modifications
 ii)  Installation
iii)  Copyright, yada-yada-yada


I) CHANGES:

FOR LIGHT ARMOR:

- Can no longer carry the laser rifle or grenade launcher
- Female armor is faster but weaker

FOR MEDIUM ARMOR:

- Can carry the laser rifle
- Can now carry 5 weapons

FOR HEAVY ARMOR:

- Can now carry 6 items
- Can carry 2 repair kits
- Slower, stronger [Discs are practically worthless]

FOR AMMO / WEAPONS:

- Laser Rifle now can kill with a headshot
- Normal mortar is as strong as Mortar Turret
- Chaingun Aim deflection is decreased (More accurate)
- Chaingun does more damage
- Blaster does more damage (Now, it's USEFUL [!!!})
- Plasma does more damage
- ELF Gun range increased
- Repair Pack can repair something 50-odd meters away (!!)
- Energy pack restores more energy and faster

LIGHT ARMOR AMMO:

15 discs
30 plas. bolts
150 bullets
5 hand grenades
2 mines

MEDIUM ARMOR AMMO:

20 discs
35 plas. bolts
175 bullets
6 hand grenades
3 mines

HEAVY ARMOR AMMO:

25 discs
40 plas. bolts
200 bullets
12 hand grenades
8 mines

LIGHT ARMOR WEAPONS:

Disc launcher
plasma gun
chaingun
blaster
ELF gun
Targeting laser

MEDIUM ARMOR WEAPONS:

Blaster
Plasma Gun
Chaingun
Disc Launcher
Grenade Launcher
Laser Rifle
Targeting Laser

HEAVY ARMOR WEAPONS:

Blaster
Plasma Gun
Chaingun
Disc Launcher
Mortar
Grenade Launcher
ELF Gun
Targeting Laser

II) INSTALLATION

1) Extract the files to your Tribes directory, into a folder
called "EnhancedBase_v2"
(i.e. by default it should be 
'C:\dynamix\tribes\EnhancedBase_v2)

2) Create a shortcut to Tribes.exe, and right click on it --
then goto properties

3) In the new window, there is a 'target' text box. It will
state the directory of your tribes.exe file

4) After tribes.exe, type in: " -mod EnhancedBase_v2"

5) Activate the shortcut to play!

III) Copyright, yada-yada-yada

�Copyright 2000-2002 All Right Reserved
*Visit the main page at www.homestead.com/tiz_mod/EBase.html

NOTE: I am not responsible for whatever happens to your computer,
should something happen while you are playing Tribes.

For suggestions, mail me at Timer2k@hotmail.com