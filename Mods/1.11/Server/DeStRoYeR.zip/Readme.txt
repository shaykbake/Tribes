Extract Scripts.vol to Tribes\DeStRoYeR
Extract DeStRoYeR.cs to Tribes\Config