// Destroyer Mod by {SOF} Snake eye
$ShoppingList = 1;

$SADPassword[1] = "Password"; // Super Admin Passwords, Up to 90 are available

$PAPPassword[1] = "Password"; // Public Admin Passwords, Up to 90 are available

//===========================================================================================
// Server Parameters
$Server::HostName = "Destroyer Server";			// Server Name
$Server::Port = "28001";				// Port used for client connections to server (usually 28001)
$Server::HostPublicGame = true;				// Server is shown in MasterServer List
$Server::Password = "";					// Password needed to join server
$AdminPassword = "Password";				// Local SuperAdmin password - CHANGE THIS
$pref::LastMission = "Raindance";			// This sets the first map in rotate when server launches (make sure it is spelled correctly)

//===========================================================================================
// Server Info Parameters (<jc> = center justified, <f1> = tan font, <f2> = white font, <f3> = orange font, \n = new line)
$Server::Info = "DeStRoYeR Mod\nAdmin: {SOF}Snake eye\nEmail: rdsnakeeye@Yahoo.com";	// Server information listed on MasterServer List
$Server::JoinMOTD = "<jc><f1>Welcome, Visit http://rdtribesmaps.cjb.net for mod related info\n<f3>Click to Join... <f2>ENJOY";	// Message of the day listed once connected to the server

//===========================================================================================
// Telnet (Console) Parameters
// If you want telnet access, set the port number to the desired port (23 is normal)
// BE SURE TO SET A PASSWORD THAT IS HARD TO GUESS
$TelnetPort="23";								// Port for telnet connections
$TelnetPassword="password";							// Password for telnet connections

//===========================================================================================
// Server Connection Parameters
$pref::PacketRate = 12;						// Packet rate for client connections
$pref::PacketSize = 200;					// Packet size for client connection

//===========================================================================================
// Voting Parameters
$Server::AdminMinVotes = 5;				// Minimum number of votes needed to vote admin
$Server::MinVotes = 1;						// Minimum number of votes needed to pass
$Server::MinVotesPct = 0.5;				// Percentage of available votes needed to pass a vote
$Server::MinVoteTime = 25;					// Time allotted for voting
$Server::VoteAdminWinMargin = 0.8;		// Ratio of Yes to No votes needed to pass
$Server::VoteFailTime = 30; 				// 30 seconds if your vote fails + $Server::MinVoteTime
$Server::VoteWinMargin = 0.6;				// Ratio of Yes to No votes needed to pass
$Server::VotingTime = 20;					// Length of votes if people are voting.

//===========================================================================================
// Player Parameters
$Server::MaxPlayers = "8";				// Maximum number of client connections allowed
$Server::AutoAssignTeams = true;			// Server assigned teams
$Server::RespawnTime = 2; 					// Number of seconds before a respawn is allowed
$Server::TimeLimit = 30;					// Mission time limit in minutes
$Server::WarmupTime = 15;					// Time (in seconds) players are left standing before movement is allowed
$Server::TeamDamageScale = 0;				// Team damage, 0 = Off, 1 = On
$Server::TourneyMode = false;				// Tournament mode

//===========================================================================================
// Team Parameters
$Server::teamName[0] = "Psycics";		// Team 1 Name
$Server::teamSkin[0] = "beagle";			// Team 1 Skin
$Server::teamName[1] = "Mortals";	// Team 2 Name
$Server::teamSkin[1] = "dsword";			// Team 2 Skin
$Server::teamName[2] = "Immortals";	// Team 3 Name
$Server::teamSkin[2] = "cphoenix";		// Team 3 Skin
$Server::teamName[3] = "UnDead";		// Team 4 Name
$Server::teamSkin[3] = "swolf";			// Team 4 Skin
$Server::teamName[4] = "Generic 1";		// Team 5 Name
$Server::teamSkin[4] = "base";			// Team 5 Skin
$Server::teamName[5] = "Generic 2";		// Team 6 Name
$Server::teamSkin[5] = "base";			// Team 6 Skin
$Server::teamName[6] = "Generic 3";		// Team 7 Name
$Server::teamSkin[6] = "base";			// Team 7 Skin
$Server::teamName[7] = "Generic 4";		// Team 8 Name
$Server::teamSkin[7] = "base";			// Team 8 Skin

//===========================================================================================
// Console Parameters
$Console::LogMode = "1"; 					// Log the console to a log file.