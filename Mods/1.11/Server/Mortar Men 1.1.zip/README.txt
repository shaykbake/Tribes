Mortar Men v.1.1 Vol
====================
Developed by: IntauraMODs

Lead Programmer: Michael Wales

If you have Questions, Comments, Bug Reports, or anything else please Email me at: Mr_Help4@planetstarsiege.com
====================

================
Changes in v.1.1
================

 * Made Heavies a little lighter. For some reason they did fine while jeting, but dropped liek a rock afterwards.
 * Disc Launcher reload time faster.
 * A few minor coding chnages used t oreduce lag, and take care of some bugs.

==============
Changes in v.1
==============

 * Only Heavies are allowed.
 * The following weapons have faster reload times:
    - Mortar
    - Grenade Launcher
    - Mortar Turret
 * I have increased the heavy Armors speed.
 * Due to the Heavy Armors slower speed, I have decreased the "sight" range on Pulse Sensors.    This gives the Heavy Armor more time to get near the enemy base before detection.


==========
Thanks to:
==========
Mephisto of Renegades and
Savage1 of Insomniax for providing me with the desire to push on. I look up to both of you and admire your skill.

Paradox
You've become a good friend and I enjoy working with you. I hope we can work on many more prjects to come.

All the posters on the TribesPlayers Message Boards. I have enjoyed talking to all of you, and have met many devoted TRIBES players through these Forums. I thank you lal for the good, and the bad, replies to all of my projects.


========================
What to look forward to:
========================
IntauraMODs will be cranking out some more position-specific MODs, similar to Mortar Men. We will be making a Snipe City, and we are hoping on making a Piloting and a Construction MOD soon.

One of our biggest projects is Unbalo MOD. This will be a MOD similar to Renegades or Insomniax except we don't boast great balanced play. We know ours in unbalanced and guess what? We're proud!

But, our biggest project will definitely Medieval. This MOD is not official so don't start spouting off rumors about it. We need Modellers and Skinners before we will ever start creating this MOD. We also need a few more Coders.


============================
What not to look forward to:
============================
If we don't hurry up and get some real hosting, IntauraMODs will be kapoot! I'm not going to try to cram a website and all of our files into some free hosting service with pop-up windows (like GeoShities and Xoom). So if you are reading this file, and you like our MODs, suggest us to your favorite Starsiege TRIBES Newsie (Planet-Tribes, PlanetStarSiege, etc.). 


I saved this for last. This is an extension to the Thanks area.

We would all like to say thanks to you. Without you none of this would be possible. All of you gave us your ideas, without that none of this would be possible. Without you downloading this file and considering it to be on your server this would not be possible.

Tell us what you think.
"All criticism, whether good or bad, is constructive criticism."


Thank you again!
 --  IntauaraMOD Team


===================
The IntauarMOD Team
===================
Evicerator
Paradox


=======================
The Mortar Men v.1 Team
=======================
Evicerator




..