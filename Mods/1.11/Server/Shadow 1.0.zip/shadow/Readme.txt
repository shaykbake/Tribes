SHaDoW v1.0

CoDeR: VoOdOo
EmAiL: voodoo@clanfoo.org
WeBPaGE: unknown

This MOD has been created to make a new experience like no other. it will change your whole perspective on what a
MOD can do to a game. it will bring you into the... SHaDoW

|---VERSION HISTORY--|
| 1.0 - Initial Release
|--------------------|

|---INSTALLATION---|
| extract files using WinZip or another zip program to your <Tribes> directory. if you want to play offline, this
| create a shortcut to Tribes.exe and add this:
|      " -mod shadow"
| to the shortcuts TARGET line in its properties. 
|
| to create a dedicated server, add this:
|      " -mod shadow -dedicated"
| to the shortcuts TARGET line in its properties.
|__________________|

|---FEATURES---|
| new armors
|
| new weapons
|
| new packs
|
| new deployables
|
| new models and skins???
|______________|

(/) = partially done
(-) = done

|---ARMORS---|
| (-)Soul: light armor that can move at astonishing speeds. max 3 weapons.
|
| (-)Ghost: medium armor that moves at a moderate speed. max 4 weapons.
|
| (-)Demon: heavy armor that moves at slow speeds. max 5 weapons.
|____________|

|---WEAPONS---|
| (-)Blaster: shoots a small blast of plasma. drains energy. does minimal damage.
|
| (-)Chaingun: chaingun that shoots a straight laser. lasers accuracy is not bad, but not good. does
|	minimal damage per laser.
|
| (-)Plasma Gun: shoots plasma bolts medium range at a high rate. does moderate radius damage.
|
| (-)Shotgun: fires a volley of bullets in random spots. it's a shotgun. does ton o' close up damage, far away
|	targets are useless to try and hit. ghost only.
|
| (-)Disc Launcher: shoots a highly explosive disc through the air exploding on contact. does moderate radius
|	damage.
|
| (-)Grenade Launcher: shoots a grenade large distances that explodes on contact only if 3 seconds has passed. does
|	moderate radius damage.
|
| (-)Timed Grenade Launcher: shoots a timed grenade large distances. does moderate radius damage.
|
| (-)Mortar: fires a massive sized bomb far distances that explodes on contact only if 5 seconds has passed. does
|	massive radius damage. demon only.
|
| (-)EMP Rocket: temporarily disables all player electrical components and generators within blast range.
|	does no damage. ghost and demon only.
|
| (-)Laser Rifle: shoots a laser through the air with dead on precision. it does damage according to spot hit.
|	soul only.
|
| (-)ELF Gun: drains energy from player. does minimal damage.
|_____________|

|---MINES---|
| (-)Mine: explosive that waits until something touches it then explodes. does massive radius damage.
|
| (-)EMP Mine: temporarily disables all player electrical components and generators within blast range.
|	does no damage.
|
| (-)Sticky Mine: a normal mine that sticks ANYWHERE. does massive radius damage.
|___________|


|---GRENADES---|
| (-)Hand Grenade: timed grenade thrown short distances. does radius damage.
|
| (-)Concussion Grenade: blasts player away from center of explosion. does no damage.
|
| (-)Flash Grenade: temporarily blinds a player from seeing. does no damage.
|______________|

|---PACKS---|
| (-)Energy Pack: refills your energy up at a faster rate.
|
| (-)Winged Pack - allows for faster flying and jumping speeds and refills energy up at fast rate.
|
| (/)Hover Pack: allows you to hover in mid-air.
|
| (-)Anti-ELF Pack: when being ELF'd, you gain energy and don't lose health.
|
| (-)Repair Pack: rapirs an object at a moderate speed.
|
| (-)Shield Pack: puts a force field around the player.
|
| (-)Sensor Jammer Pack: hides player from enemy sensors.
|
| (-)Ammo Pack: allowd player to hold more ammo.
|___________|

|---DEPLOYABLES---|
| (-)Remote Inventory Station: deploys a small inventory station that has a limited amount of supplies.
|	ghost and demon only.
|
| (-)Remote Ammo Station: deploys a small ammo refill station that refills players. ghost and demon only.
|
| (-)Motion Sensor: deployable that detects any movement within its radius.
|
| (-)Pulse Sensor: deployable that detects any enemy in it's radius.
|
| (-)Sensor Jammer: deployable that jams the enemy sensor so you appear to not be there.
|
| (-)Camera: deployable that allows a player to see what is going on where the camera is deployed.
|
| (-)Remote Turret: deployable turret that shoots small plasma charges at an enemy. does moderate damage per hit.
|	ghost and demon only.
|
| (-)Laser Turret: deployable turret that shoots a laser at the enemy. has moderate attack range. does enough to
|	make player run, not enough to kill. ghost and demon only.
|_________________|

|---MISC---|
| (-)Beacon: marks the spot where it is placed and tells you how far you are away from it.
|
| (-)Repair Kit: repairs a moderate amount of life to the player. heals current player.
|
| (-)Targeting Laser: shoots a laser straight ahead that shows how far something is away from them. does no damage.
|__________|