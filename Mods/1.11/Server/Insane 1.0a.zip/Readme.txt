--------------------------------------------------
Name: INSANE mod for Starsiege Tribes 
Version: 1.0a
Date: 3-10-99
Email: Bobsquad1@hotmail.com soon to be kevin@tribesland.com
URL: http://members.tripod.com/strib/ soon to be moving to      http://insane.tribesland.com/
Notes: I will happily accept any comments, suggestions, and bug reports. PLEASE e-mail me with any of those.
Known Bugs:I dont know of any.
Creator: [PLA]KeViN
--------------------------------------------------
-------------------Installation-------------------
--------------------------------------------------
1. Unzip INSANEv1.0a.zip into default Tribes Directory
 (Where tribes.exe is - UNZIP WITH PATH INFORMATION)
2. Then make a shortcut to your tribes.exe. Then right click on the shortcut you just made and (in the target bar) after where it say  Tribes\tribes.exe add -mod INSANE. 
(It will now say tribes\tribes.exe -mod INSANE)

For dedicated server info go to
http://www.tribesplayers.com/tribesplayers/server-index.html

Installed The Files Should be here: 

Tribes\INSANE\ (all the other files should be here)
Tribes\INSANE\Readme.txt
Tribes\config\INSANE.cs
If these files are not in these folders, put them there.

--------------------------------------------------
-----------------Special Thanks-------------------
--------------------------------------------------
 I would like to thank renegades for making this mod possible, and I would also like to thank all the people that gave me suggestions!! Some of those people are.. CLS, Wolverine, Desperado, GI Joe, CHE~FLY.(if I forgot anyone, sorry. just email me and I'll add you!)