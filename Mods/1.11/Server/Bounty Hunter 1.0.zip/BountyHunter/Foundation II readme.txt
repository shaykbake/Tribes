########################### Foundatio Mod II by ProtoManX ###################################
#                   Credits: these are people that provide code for my mod                  #
#             Ice(Devastor Mod): biggest contributer to some the functions here             #
#                  Nicodemus: used foundation mod as base for Foundation II                 #
#                    Thanx to who ever made the armor specific inventory                    #
#############################################################################################

Now on to what is so special about Foundation Mod II
firstly what it is designed for and that is new coders to make new items
with a bit less headache and questions so how does it do this well let me
break this down as best i can

you have these functions to aid your modding:

setDamageScale(Damage Type, Light Armor Scale, Medium Armor Scale, Heavy Armor Scale, Scout Scale, APC Scale, HAPC Scale)
              -you do this for any new damage types and it will set the damagescale
               for each armor and vehicle
              -you can add new armors and vehicles to the function just add thier
               variable to the function where ever you like so long as when called the
               values corespond

setArmorItemMax(Item(Pack/Weapon/Ammo) Name, Light Armor Max, Medium Armor Max, Heavy Armor Max)
               -you do this for any new items and it will set the max quantity for
                each armor
               -you can add new armors to the function just add thier variable to
                the function where ever you like so long as when called the values
                corespond

addAmmo(Weapon, Ammo Name, Quanity Bought/Sold, Ammo Pack Max)
               -for ammo based weapons use this function to set the quantities for
                the ammo pack and the quantity bought or sold at once

addToInv(Item(Pack/Weapon/Ammo) Name, Static Station, Remote Station)
               -sets if the station sells the item or not(0 or 1) for the Item

dataReinit(Item Name)
               -this creates a list of items that at the begining of a map needs to
                be zeroed out becuase only a limited number can be in play

Item::universalDeploy(%player,%item,%dist,%terr,%BxMxLn,%BxMxWd,%BxMxHt,%BxMnLn,%BxMnWd,%BxMnHt,%mib,%flat,%shape,%type,%kill)
               -for this it will be simpler to explain each value
                %player -> this is the player id of the person attempting the deploy
                %item -> this is the item attempting to be deployed(the pack)
                %dist -> this is the maximum distance from player it can be deployed
                %terr -> this is the type of terrain it can be deployed on there are
                         4 types(ALL, OBJECTS, LAND, and OUTSIDE)
                         ALL -> means it can go on anything
                         OBJECTS -> means it can go only on an object
                         LAND -> means it can go on anything but object
                         OUTSIDE -> same as LAND but must be placed out side of a
                                    building
                %BxMxWd -> Max width of the box for getting the number of the type in box
                %BxMxHt -> Max height of the box for getting the number of the type in box
                %BxMxLn -> Max length of the box for getting the number of the type in box
                %BxMnWd -> Min width of the box for proximity to another of same type
                %BxMnHt -> Min height of the box for proximity to another of same type
                %BxMnLn -> Min length of the box for proximity to another of same type
                %mib -> Max number of same type object in box from %BxMxWd, %BxMxHt, %BxMxLn
                %flat -> True or False if it can be on angled surfaces
                %shape -> the item to be deployed(item was the pack %shape is the deployable)
                %type -> the deployable objects type(Turret, StaticShape, etc..)
                %dod -> delete on destroy meaning once it is takin maximum damage it blows up
                        and goes away

$DamageToLaser[Laser Weapon Name]        = Correct Damage Type;
               -this fixes the small bug where when you give a Laserdata a new damage
                type and tribes defualts it to $LaserDamageType this will change it to
                the damagetype you want

$HeadVal[Heavy, Damage Type] and $HeadVal[Damage Type]
               -those are variable to figure the head shot value i found it works much better
                also the one with Heavy in it is for Heavy armor you do not need to change the
                word Heavy to your armors just add them in Player.cs

getTransFix(Player Id)
               -this is a function that will fix the off set of spawned projectiles so they
                aim acurately all you send it the Player Id it returns the trans so use this
                instead of GameBase::getMuzzleTransform(%player)
