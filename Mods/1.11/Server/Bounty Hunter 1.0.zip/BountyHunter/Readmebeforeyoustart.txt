Welcome to the bounty hunter open souce.
You can find the full credits in bountyhuntermod.txt, but i am going to 
give a brief intro to this:

This mod was written by TANK, with a lot of help from other sources....
He apparently got tired of it/lost interest/got too busy to do anything with it.
So he then offered it to me, which i then took it, added this file, and hosted it on the ftp you downloaded it from.

If you decide to finsih this mod, make changes, or do anything to it, please leave credit where it is due. Nobody likes to see their orignal idea compltely debadged into somthing else.

Ok, that should be enought for the intro to this deal.

//E-DoG