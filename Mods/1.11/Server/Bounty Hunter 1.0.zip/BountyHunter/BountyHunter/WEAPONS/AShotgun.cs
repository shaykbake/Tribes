//--------------------------------------

addAmmo(aShotgun,aShotgunAmmo,5,15);

addToInv(aShotgun,1,1);
addToInv(aShotgunAmmo,1,1);

setArmorItemMax(aShotgun,1,1,1);
setArmorItemMax(aShotgunAmmo,20,25,30);

//--------------------------------------
BulletData aShotgunBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.105;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.015;
   muzzleVelocity     = 450.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData aShotgunAmmo
{
        description = "AutoShotgun Shells";
        className = "Ammo";
        shapeFile = "ammo2";
   heading = $InvCatAmmo;
        shadowDetailMask = 4;
        price = 2;
};

//----------------------------------------------------------------------------

ItemImageData aShotgunImage
{
        shapeFile = "shotgun";
        mountPoint = 0;

 	weaponType = 0; // Single Shot
	reloadTime = 0.1;
	fireTime = 0.2;

        sfxFire = SoundFireMortar;
        sfxActivate = SoundPickUpWeapon;
        sfxReload = SoundDryFire;
};

ItemData aShotgun
{
        description = "AutoShotgun";
        className = "Weapon";
        shapeFile = "shotgun";
        hudIcon = "ammopack";
   heading = $InvCatWeapons[All];
        shadowDetailMask = 4;
        imageType = aShotgunImage;
        price = 150;
        showWeaponBar = true;
};

function aShotgunImage::onFire(%player, %slot)
{
        %client = Player::getClient(%player);
        %ammo = Player::getItemCount(%player,aShotgunAmmo);
        if(%ammo > 0) {
                %trans = getTransFix(%player);
                %vel = Item::getVelocity(%player);
                for(%projnum = 8; %projnum > 0; %projnum--) {
                        Projectile::spawnProjectile(aShotgunBullet,%trans,%player,%vel);
                }
                Player::decItemCount(%player,aShotgunAmmo,1);
        }
}

$MountMSG[aShotgun] = "<JC><F2>Auto Shotgun <F0>- <F1>12 gauge shot gun that is exelent for close range objects, Fully automatic.";

AddWeapon(aShotgun);
