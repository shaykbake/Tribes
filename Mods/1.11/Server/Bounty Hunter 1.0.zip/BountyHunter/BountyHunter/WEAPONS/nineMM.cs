//--------------------------------------

$AutoUse[nine] = True;
addAmmo(nine,nineAmmo,25,150);

addToInv(nine,1,1);
addToInv(nineAmmo,1,1);

setArmorItemMax(nine,1,1,1);
setArmorItemMax(nineAmmo,200,250,300);

//--------------------------------------

BulletData nineBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 0.1;
   damageType	      = $BulletDamageType;

   aimDeflection      = 0.01;
   muzzleVelocity     = 425.0;
   totalTime	      = 1.5;
   liveTime	      = 1.0;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData nineAmmo
{
	description = "9mmBullets";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 10;
};

//--------------------------------------

ItemImageData nineImage
{
	shapeFile = "paintgun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 0.5;

	ammoType = nineAmmo;
	projectileType = nineBullet;
	accuFire = true;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFireChaingun;
	sfxActivate = SoundPickUpWeapon;
};

ItemData nine
{
	description = "9mm";
	className = "Weapon";
	shapeFile = "paintgun";
   validateShape = true;
	hudIcon = "sniper";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = nineImage;
	price = 100;
	showWeaponBar = true;
};

$MountMSG[nine] = "<JC><F2>9mm <F0>- <F1>Short distance side arm.";

AddWeapon(nine);
