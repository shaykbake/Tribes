//--------------------------------------

$AutoUse[rl] = True;
addAmmo(rl,FlierAmmo,4,8);

addToInv(rl,1,1);
addToInv(flierAmmo,1,1);

setArmorItemMax(rl,1,1,1);
setArmorItemMax(FlierAmmo,10,20,30);

//--------------------------------------

RocketData FlierRocket
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass 	    = 2.0;

   damageClass	    = 1;       // 0 impact, 1, radius
   damageValue	    = 2;
   damageType	    = $MissileDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 250.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime	    = 10.0;
   liveTime	    = 11.0;
   lightRange	    = 5.0;
   lightColor	    = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;		   // smoke trail
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;

   soundId = SoundJetHeavy;
};

//--------------------------------------

ItemData FlierAmmo
{
	description = "Rockets";
	className = "Ammo";
   heading = $InvCatAmmo;
	shapeFile = "mortarammo";
	shadowDetailMask = 4;
	price = 5;
};

//---------------------------------------

ItemImageData r2Image
{
   shapeFile  = "mortargun";
        mountPoint = 0;
        mountRotation = { 0, 0, 0 };
        mountOffset = { 0, 0.4, 0};

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData r2
{
   heading = $InvCatWeapons[All];
        description = "M4AssultRifle";
        className = "Weapon";
   shapeFile  = "mortargun";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = r2Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData rlImage
{
	shapeFile = "mortargun";
	mountPoint = 0;
	mountRotation = { 0, 0, 0 };
        mountOffset = { 0, -0.09, 0};

	weaponType = 0; // Single Shot
	ammoType = FlierAmmo;
	projectileType = FlierRocket;
	accuFire = false;
	reloadTime = 0.1;
	fireTime = 2;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireFlierRocket;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
	sfxReady = SoundMortarIdle;
};

ItemData rl
{
	description = "RocketLauncher";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "mortar";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = rlImage;
	price = 375;
	showWeaponBar = true;
   validateShape = true;
};

function rl::onMount(%player,%item)
{
        Player::mountItem(%player,r2,$ExtraSlotA);
}

function rl::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
}

$MountMSG[rl] = "<JC><F2>Rocket Launcher <F0>- <F1>Fires unguided rockets.";

AddWeapon(rl);
