//--------------------------------------

$AutoUse[twentyCal] = True;
addAmmo(twentyCal,twoAmmo,25,150);

addToInv(twentyCal,1,1);
addToInv(twoAmmo,1,1);

setArmorItemMax(twentyCal,1,1,1);
setArmorItemMax(twoAmmo,10,15,20);

//--------------------------------------

BulletData twoBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 0.5;
   damageType	      = $BulletDamageType;

   muzzleVelocity     = 700.0;
   totalTime	      = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData twoAmmo
{
	description = "22Cal Clip";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 50;
};

//--------------------------------------

ItemImageData t2Image
{
   shapeFile  = "paintgun";
        mountPoint = 0;
        mountRotation = { 0, 0, 0 };
        mountOffset = { 0, 0, 0.1};

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData t2
{
   heading = $InvCatWeapons[All];
        description = "22Cal";
        className = "Weapon";
   shapeFile  = "paintgun";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = s2Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData twentyCalImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 2;
	fireTime = 0.0001;

	ammoType = twoAmmo;
	projectileType = twoBullet;
	accuFire = true;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFirelaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData twentyCal
{
	description = "22Cal";
	className = "Weapon";
	shapeFile = "sniper";
   validateShape = true;
	hudIcon = "sniper";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = twentyCalImage;
	price = 2000;
	showWeaponBar = true;
};

function twentyCal::onMount(%player,%item)
{
        Player::mountItem(%player,t2,$ExtraSlotA);
}

function twentyCal::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
}

$MountMSG[twentyCal] = "<JC><F2>22Cal <F0>- <F1>Low power sniper rifle.";

AddWeapon(twentyCal);
