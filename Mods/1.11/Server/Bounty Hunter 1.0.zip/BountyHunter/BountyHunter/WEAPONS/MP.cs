//--------------------------------------

$AutoUse[MP] = True;
addAmmo(MP,MPAmmo,25,150);

addToInv(MP,1,1);
addToInv(MPAmmo,1,1);

setArmorItemMax(MP,1,1,1);
setArmorItemMax(MPAmmo,100,150,200);

//--------------------------------------

BulletData MPBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 0.2;
   damageType	      = $BulletDamageType;

   aimDeflection      = 0.035;
   muzzleVelocity     = 425.0;
   totalTime	      = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData MPAmmo
{
	description = "MP5 Clip";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 25;
};

//--------------------------------------

ItemImageData MPImage
{
	shapeFile = "plasma";
	mountPoint = 0;
	mountRotation = { 0,3.14, 0 };

	weaponType = 1; // Spinning
	reloadTime = 0;
	spinUpTime = 0.0;
	spinDownTime = 0;
	fireTime = 0.125;

	ammoType = MPAmmo;
	projectileType = MPBullet;
	accuFire = false;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFirechaingun;
	sfxActivate = SoundPickUpWeapon;
};

ItemData MP
{
	description = "MP5";
	className = "Weapon";
	shapeFile = "plasma";
   validateShape = true;
	hudIcon = "chain";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = MPImage;
	price = 700;
	showWeaponBar = true;
};

$MountMSG[MP] = "<JC><F2>MP5 <F0>- <F1>SWAT edition MP5, modderate rate of fire, modderate damage rate.";

AddWeapon(MP);
