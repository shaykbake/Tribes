//--------------------------------------

addAmmo(Shotgun,ShotgunAmmo,5,15);

addToInv(Shotgun,1,1);
addToInv(ShotgunAmmo,1,1);

setArmorItemMax(Shotgun,1,1,1);
setArmorItemMax(ShotgunAmmo,20,25,30);

//--------------------------------------
BulletData ShotgunBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.105;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.015;
   muzzleVelocity     = 450.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData ShotgunAmmo
{
        description = "Shotgun Shells";
        className = "Ammo";
        shapeFile = "ammo2";
   heading = $InvCatAmmo;
        shadowDetailMask = 4;
        price = 2;
};

//----------------------------------------------------------------------------

ItemImageData ShotgunImage
{
        shapeFile = "shotgun";
        mountPoint = 0;

        weaponType = 0;
        ammoType = ShotgunAmmo;
        accuFire = true;
        reloadTime = 0.4;
        fireTime = 0.2;

        sfxFire = SoundFireMortar;
        sfxActivate = SoundPickUpWeapon;
        sfxReload = SoundDryFire;
};

ItemData Shotgun
{
        description = "Shotgun";
        className = "Weapon";
        shapeFile = "shotgun";
        hudIcon = "ammopack";
   heading = $InvCatWeapons[All];
        shadowDetailMask = 4;
        imageType = ShotgunImage;
        price = 150;
        showWeaponBar = true;
};

function ShotgunImage::onFire(%player, %slot)
{
        %client = Player::getClient(%player);
        %ammo = Player::getItemCount(%player,ShotgunAmmo);
        if(%ammo > 0) {
                %trans = getTransFix(%player);
                %vel = Item::getVelocity(%player);
                for(%projnum = 8; %projnum > 0; %projnum--) {
                        Projectile::spawnProjectile(ShotgunBullet,%trans,%player,%vel);
                }
                Player::decItemCount(%player,ShotgunAmmo,1);
        }
}

$MountMSG[Shotgun] = "<JC><F2>Shotgun <F0>- <F1>12 gauge shot gun that is exelent for close range objects.";

AddWeapon(Shotgun);
