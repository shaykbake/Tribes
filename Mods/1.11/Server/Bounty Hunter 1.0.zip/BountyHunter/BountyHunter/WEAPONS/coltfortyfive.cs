//--------------------------------------

$AutoUse[fortyfive] = True;
addAmmo(fortyfive,cfiveAmmo,20,150);

addToInv(fortyfive,1,1);
addToInv(cfiveAmmo,1,1);

setArmorItemMax(fortyfive,1,1,1);
setArmorItemMax(cfiveAmmo,20,40,60);

//--------------------------------------

BulletData cfiveBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 0.2;
   damageType	      = $BulletDamageType;

   aimDeflection      = 0.01;
   muzzleVelocity     = 425.0;
   totalTime	      = 1.5;
   liveTime	      = 2.0;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData cfiveAmmo
{
	description = "cfiveBullets";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 20;
};

//--------------------------------------

ItemImageData fortyfiveImage
{
	shapeFile = "paintgun";
	mountPoint = 0;
        mountRotation = { 0,4.71, 0 };

	weaponType = 0; // Single Shot
	reloadTime = 0.5;

	ammoType = cfiveAmmo;
	projectileType = cfiveBullet;
	accuFire = true;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFireChaingun;
	sfxActivate = SoundPickUpWeapon;
};

ItemData fortyfive
{
	description = "Colt 45";
	className = "Weapon";
	shapeFile = "paintgun";
   validateShape = true;
	hudIcon = "sniper";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = fortyfiveImage;
	price = 200;
	showWeaponBar = true;
};

$MountMSG[fortyfive] = "<JC><F2>Colt 45 <F0>- <F1>Short distance side arm, moderate power.";

AddWeapon(fortyfive);
