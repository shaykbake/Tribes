//--------------------------------------

$AutoUse[fiftyCal] = True;
addAmmo(fiftycal,sniperAmmo,25,150);

addToInv(fiftycal,1,1);
addToInv(sniperAmmo,1,1);

setArmorItemMax(fiftyCal,1,1,1);
setArmorItemMax(sniperAmmo,10,15,20);

//--------------------------------------

BulletData sniperBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 3.0;
   damageType	      = $BulletDamageType;

   muzzleVelocity     = 700.0;
   totalTime	      = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData sniperAmmo
{
	description = "50Cal Clip";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 50;
};

//--------------------------------------

ItemImageData s2Image
{
   shapeFile  = "paintgun";
        mountPoint = 0;
        mountRotation = { 0, 0, 0 };
        mountOffset = { 0, 0, 0.1};

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData s2
{
   heading = $InvCatWeapons[All];
        description = "M4AssultRifle";
        className = "Weapon";
   shapeFile  = "paintgun";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = s2Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData fiftycalImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 2;
	fireTime = 0.0001;

	ammoType = sniperAmmo;
	projectileType = sniperBullet;
	accuFire = true;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFirelaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData fiftyCal
{
	description = "50Cal";
	className = "Weapon";
	shapeFile = "sniper";
   validateShape = true;
	hudIcon = "sniper";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = fiftycalImage;
	price = 2500;
	showWeaponBar = true;
};

function fiftycal::onMount(%player,%item)
{
        Player::mountItem(%player,s2,$ExtraSlotA);
}

function fiftycal::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
}

$MountMSG[fiftycal] = "<JC><F2>50Cal <F0>- <F1>High power sniper rifle.";

AddWeapon(fiftyCal);
