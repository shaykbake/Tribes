//--------------------------------------

$AutoUse[de] = True;
addAmmo(de,deAmmo,20,150);

addToInv(de,1,1);
addToInv(deAmmo,1,1);

setArmorItemMax(de,1,1,1);
setArmorItemMax(deAmmo,20,40,60);

//--------------------------------------

BulletData deBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 1;
   damageType	      = $BulletDamageType;

   aimDeflection      = 0;
   muzzleVelocity     = 425.0;
   totalTime	      = 1.5;
   liveTime	      = 4.0;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData deAmmo
{
	description = "deBullets";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 20;
};

//--------------------------------------

ItemImageData deImage
{
	shapeFile = "energygun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 1;

	ammoType = deAmmo;
	projectileType = deBullet;
	accuFire = true;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFireChaingun;
	sfxActivate = SoundPickUpWeapon;
};

ItemData de
{
	description = "Desert Eagle";
	className = "Weapon";
	shapeFile = "energygun";
   validateShape = true;
	hudIcon = "sniper";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = deImage;
	price = 600;
	showWeaponBar = true;
};

$MountMSG[de] = "<JC><F2>Desert Eagle <F0>- <F1>High power medium distance side arm.";

AddWeapon(de);
