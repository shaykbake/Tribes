//--------------------------------------

$AutoUse[akgun] = True;
addAmmo(akgun,akAmmo,25,150);

addToInv(akgun,1,1);
addToInv(akAmmo,1,1);

setArmorItemMax(akgun,1,1,1);
setArmorItemMax(akAmmo,200,250,300);

//--------------------------------------

BulletData akBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 0.25;
   damageType	      = $BulletDamageType;

   aimDeflection      = 0.015;
   muzzleVelocity     = 500.0;
   totalTime	      = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData akAmmo
{
	description = "AK Clip";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 200;
};

//--------------------------------------

ItemImageData ak3Image
{
   shapeFile  = "paintgun";
        mountPoint = 0;
        mountRotation = { 0, 3.14, 0 };
        mountOffset = { 0, 1.2, -0.002 };

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData ak3
{
   heading = $InvCatWeapons[All];
        description = "AK AssultRifle";
        className = "Weapon";
   shapeFile  = "paintgun";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = ak3Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData ak2Image
{
   shapeFile  = "plasma";
        mountPoint = 0;
        mountRotation = { 0, 0, 0 };
        mountOffset = { 0, 0, 0 };

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData ak2
{
   heading = $InvCatWeapons[All];
        description = "AK AssultRifle";
        className = "Weapon";
   shapeFile  = "plasma";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = ak2Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData akgunImage
{
	shapeFile = "sniper";
	mountPoint = 0;
	mountOffset = { 0, 0.4, 0 };

	weaponType = 1; // Spinning
	reloadTime = 0;
	spinUpTime = 0;
	spinDownTime = 0;
	fireTime = 0.1;

	ammoType = akAmmo;
	projectileType = akBullet;
	accuFire = true;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFireChaingun;
	sfxActivate = SoundPickUpWeapon;
};

ItemData akgun
{
	description = "AK AssultRifle";
	className = "Weapon";
	shapeFile = "sniper";
   validateShape = true;
	hudIcon = "chain";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = akgunImage;
	price = 2500;
	showWeaponBar = true;
};

function akgun::onMount(%player,%item)
{
        Player::mountItem(%player,ak2,$ExtraSlotA);
        Player::mountItem(%player,ak3,$ExtraSlotB);
}

function akgun::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
        Player::unmountItem(%player,$ExtraSlotB);
}

$MountMSG[akgun] = "<JC><F2>AK Assult Rifle <F0>- <F1>AK Assult Rifle, full auto.";

AddWeapon(akgun);
