//--------------------------------------

$AutoUse[fcalgun] = True;
addAmmo(fcalgun,fcalAmmo,25,150);

addToInv(fcalgun,1,1);
addToInv(fcalAmmo,1,1);

setArmorItemMax(fcalgun,1,1,1);
setArmorItemMax(fcalAmmo,200,250,300);

//--------------------------------------

BulletData fcalBullet
{
   bulletShapeName    = "bullet.dts";
   validateShape      = true;
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass 	      = 0.05;
   bulletHoleIndex    = 0;

   damageClass	      = 0;	 // 0 impact, 1, radius
   damageValue	      = 2.0;
   damageType	      = $BulletDamageType;

   aimDeflection      = 0.03;
   muzzleVelocity     = 425.0;
   totalTime	      = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible	      = False;

   tracerPercentage   = 1.0;
   tracerLength       = 30;
};

//----------------------------------------------------------------------------

ItemData fcalAmmo
{
	description = "50CalClip";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 200;
};

//--------------------------------------

ItemImageData f3Image
{
   shapeFile  = "grenammo";
        mountPoint = 0;
        mountRotation = { 0, 0, 1.57 };
        mountOffset = { -0.2, 0, -0.1};

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData f3
{
   heading = $InvCatWeapons[All];
        description = "50CalMachineGun";
        className = "Weapon";
   shapeFile  = "grenammo";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = f3Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData f2Image
{
   shapeFile  = "sniper";
        mountPoint = 0;
        mountRotation = { 0, 0, 0 };
        mountOffset = { 0, 0.2, -0.01};

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;

        accuFire = true;
};

ItemData f2
{
   heading = $InvCatWeapons[All];
        description = "50CalMachineGun";
        className = "Weapon";
   shapeFile  = "sniper";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = f2Image;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData fcalgunImage
{
	shapeFile = "chaingun";
	mountPoint = 0;
	mountRotation = { 0, 3.14, 0 };
        mountOffset = { 0, 0, 0};
	
	weaponType = 1; // Spinning
	reloadTime = 0;
	spinUpTime = 0;
	spinDownTime = 0;
	fireTime = 0.1;

	ammoType = fcalAmmo;
	projectileType = fcalBullet;
	accuFire = false;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };

	sfxFire = SoundFireChaingun;
	sfxActivate = SoundPickUpWeapon;
};

ItemData fcalgun
{
	description = "50CalMachineGun";
	className = "Weapon";
	shapeFile = "chaingun";
   validateShape = true;
	hudIcon = "chain";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = fcalgunImage;
	price = 2500;
	showWeaponBar = true;
};

function fcalgun::onMount(%player,%item)
{
        Player::mountItem(%player,f2,$ExtraSlotA);
        Player::mountItem(%player,f3,$ExtraSlotB);
}

function fcalgun::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
        Player::unmountItem(%player,$ExtraSlotB);
}

$MountMSG[fcalgun] = "<JC><F2>50Cal Machine Gun <F0>- <F1>Powerull machinegun that fires .50 caliber bullets.";

AddWeapon(fcalgun);
