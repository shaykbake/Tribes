//                              Custom Server Settings:
//===========================================================================================
// Allow Custom Skins.
$BountyHunter::customSkins = true;

// Allow Voting Admin.
$BountyHunter::VoteAdmin = False;

// Allow Voting To Kick.
$BountyHunter::VoteKick = true;

// Kick/Ban Times:
$BountyHunter::KickTime = 180;
$BountyHunter::BanTime = 2000;

// Cheats:(admins only cheats)
$FoundationII::CheatsForAdmins = true;

// SuperAdmin Passwords:
$BountyHunter::Super[0] = "245522";
$Foundation::Super[1] = "747";
$FoundationII::Super[2] = "17";
$BountyHunter::Super[3] = "3";
$BountyHunter::Super[4] = "2";
$BountyHunter::Super[5] = "1";


// PublicAdmin Passwords:
$BountyHunter::Public[0] = "630";
$BountyHunter::Public[1] = "";
$BountyHunter::Public[2] = "";
$BountyHunter::Public[3] = "";
$BountyHunter::Public[4] = "";
$BountyHunter::Public[5] = "";

//Number of tries a player has to attempt admin passwords -1 ie 2 = 3 tries
$StrikeLimit = 2;

// Allow Public Admins To Kick.
$BountyHunter::PublicKick = true;

// Allow Public Admins To Change Mission.
$FBountyHunter::PublicChngMission = true;

// Allow Public Admins To View\Change Server Options.
$BountyHunter::PublicSvrOpts = false;
//===========================================================================================

//                             General Server Settings:
//===========================================================================================
// Server Name, Shown In The Servers List.
$Server::HostName = "BountyHunter";

// Port Of Server, Usually 28001.
$Server::Port = "28011";

// Allow People To Connect To Your Server(true = yes | false = no).
$Server::HostPublicGame = true;

// Maximum Allowed Players.
$Server::MaxPlayers = "4";

// Leave Blank Unless You Want People To Enter A Password To Join Your Server.
$Server::Password = "bang";

// Set This To The Mission You Would Like The Server To Start On(Check Spelling).
$pref::LastMission = "Raindance";

// When You Highlight A Server, Then Click Info..You'll See This Screen.
$Server::Info = "Bounty Hunter server TESTING\nAdmin: TANK\nEmail: killerdwarf3000@earthlink.net";

// Message To Display When You First Join The Server(After The Loading Screen).
$Server::JoinMOTD = "<jc><f1>TESTING Email mod suggestions to killerdwarf3000@earthlink.net";

// Port for telnet connections.
$TelnetPort = "28001";

// Password for telnet connections.
$TelnetPassword = "bangrang";

// Packet rate for client connections(recommended for cable)
$pref::PacketRate = 30;

// Packet size for client connections(recommended for cable)
$pref::PacketSize = 500;

// Minimum Allowed Votes To Succeed.
$Server::MinVotes = "2";

// ??
$Server::MinVotesPct = "0.5";

// Minimum Allowed Time To Vote.
$Server::MinVoteTime = "45";

// This Is The Delay Time After You Are Killed B4 You Can Spawn.
$Server::respawnTime = "2";

// Team Damage: (1 = on | 0 = off).
$Server::TeamDamageScale = "0";

// Mission time limit in minutes.
$Server::TimeLimit       = 999999999;

// Warmup Time B4 Match Starts.
$Server::WarmupTime      = 0;

// Start In Tournament Mode(true = yes | false = no).
$Server::TourneyMode = "false";

// ??
$Server::VoteAdminWinMargin = "0.66";

// ??
$Server::VoteFailTime = "30";

// ??
$Server::VoteWinMargin = "0.55";

// Overall Time For Vote.
$Server::VotingTime = "20";

// Time B4 Match Starts On Each New Mission.
$Server::warmupTime = "20";

// Auto-Set Teams When People Connect Or Let Them Pick(true = auto-assign | false = don't).
$Server::AutoAssignTeams = "true";


// Team Names & Team Skins:
$Server::teamName0 = "Blue";
$Server::teamSkin0 = "blue";

$Server::teamName1 = "Purple";
$Server::teamSkin1 = "purple";

$Server::teamName2 = "Base";
$Server::teamSkin2 = "base";

$Server::teamName3 = "Green";
$Server::teamSkin3 = "green";

$Server::teamName4 = "BountyHunters";
$Server::teamSkin4 = "BountyHunters";

$Server::teamName5 = "Diamond Sword";
$Server::teamSkin5 = "dsword";

$Server::teamName6 = "Starwolf";
$Server::teamSkin6 = "swolf";

$Server::teamName7 = "Children of the Phoenix";
$Server::teamSkin7 = "cphoenix";
