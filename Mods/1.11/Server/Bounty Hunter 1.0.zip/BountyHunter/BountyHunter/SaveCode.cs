//<==================================>//
//==>Save Code By: ICE<==\\
$Save::Item[Shotgun] = "held";
$Save::Item[ShotgunAmmo] = "held";
$Save::Item[gatgun] = "held";
$Save::Item[gatAmmo] = "held";
$Save::Item[akgun] = "held";
$Save::Item[akAmmo] = "held";
$Save::Item[aShotgun] = "held";
$Save::Item[aShotgunAmmo] = "held";
$Save::Item[fortyfive] = "held";
$Save::Item[cfiveAmmo] = "held";
$Save::Item[de] = "held";
$Save::Item[deAmmo] = "held";
$Save::Item[fcalgun] = "held";
$Save::Item[fcalAmmo] = "held";
$Save::Item[mgun] = "held";
$Save::Item[m4Ammo] = "held";
$Save::Item[MP] = "held";
$Save::Item[MPAmmo] = "held";
$Save::Item[nine] = "held";
$Save::Item[nineAmmo] = "held";
$Save::Item[rl] = "held";
$Save::Item[FlierAmmo] = "held";
$Save::Item[fiftycal] = "held";
$Save::Item[sniperAmmo] = "held";
$Save::Item[twentycal] = "held";
$Save::Item[twoAmmo] = "held";
$Save::Item[GrenadeLauncher] = "held";
$Save::Item[GrenadeAmmo] = "held";
$Save::Item[Grenade] = "held";
$Save::Item[Mine] = "held";
$Save::Item[RepairKit] = "held";
$Save::Item[RepairPack] = "held";
$Save::Item[ShiedPack] = "held";
$Save::Item[EnergyPack] = "held";
$Save::Item[SensorJammerPack] = "held";
$Save::Item[AmmoPack] = "held";
$Save::Item[larmor] = "held";
$Save::Item[marmor] = "held";
$Save::Item[harmor] = "held";

include("temp\\");

function Save(%ClientId,%item)
{
	if(%clientId == "all") 
	{
		if(Client::getFirst() < 2049)
			return;
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
			Save(%cl);
		return;
	}
	else if(%clientId < 2049)
		return;
	%player = Client::getOwnedObject(%clientId);
	if(%player < 8000 || getObjectType(%player) != "Player" || Player::isDead(%player) || %player.outArea)
		return false;
	DW::getInventory(%clientId);
	%Name = DW::ChangeSymbols(Client::getName(%ClientId));
	%file = "DW_Stats["@%Name@"].cs";
	$ClientInfo[%clientId,time] += (getSimTime() - $JoinTime[%clientId]);
	$JoinTime[%clientId] = getSimTime();
	$DW::Save["[\""@%Name@"\",\"Pos\"]"] = GameBase::getPosition(%Player);
	$DW::Save["[\""@%Name@"\",\"Rot\"]"] = GameBase::getRotation(%Player);
	$DW::Save["[\""@%Name@"\",\"IP\"]"] = Client::getTransportAddress(%ClientId);
	$DW::Save["[\""@%Name@"\",\"jCnt\"]"] = $ClientInfo[%clientId,jCnt];
	$DW::Save["[\""@%Name@"\",\"time\"]"] = $ClientInfo[%clientId,time];
	$DW::Save["[\""@%Name@"\",\"Items\",\"num\"]"] = $ClientInfo[%clientId,Items,num];
	$DW::Save["[\""@%Name@"\",\"Cash\",\"Cash\"]"] = %Client[34,Cash];
	%exportTo = "temp\\" @ %file;
	if(isFile(%exportTo))
		File::delete(%exportTo);
	if(%clientId > 2048)
		export("DW::Save[\""@%Name@"\",*", "Temp\\"@%file, false);
}

function LoadStats(%ClientId)
{
	if(%clientId < 2049)
		return;
	%Name = DW::ChangeSymbols(Client::getName(%ClientId));
	%file = "BH_Stats["@%Name@"].cs";
	if(isFile("temp\\" @ %file))
		exec(%file);
	else {
		%file = "BH_Stats["@%Name@"].cs";
		if(isFile("temp\\" @ %file)) {
			exec(%file);
			%Name = DW::ChangeSymbols(Client::getName(%ClientId));
		}
	}
	if($DW::Save[%Name,"time"] > 0 && $DW::Save[%Name,"jCnt"] > 0) 
	{
	    $ClientInfo[%ClientID,Cash] = $Dw::Save[%Name,"Cash"];
		$ClientInfo[%clientId,time] = $DW::Save[%Name,"time"];
		$ClientInfo[%clientId,jCnt] = $DW::Save[%Name,"jCnt"]+1;
		$DW::Save[%clientId,Items,"num"] = $ClientInfo[%name,"Items","num"];
		%num = 0;
		for(%i = 1; %i <= $ClientInfo[%clientId,Items,"num"]; %i++) 
		{
			%item = getWord($DW::Save[%name,Items,%i],0);
			%count = getWord($DW::Save[%names,Items,%i],1);
			if(%count > 0)
			$ClientInfo[%clientId,Items,%num++] = %item@" "@%count;
		}
	}
	else{
		$ClientInfo[%clientId,jCnt] = 1;
		$ClientInfo[%clientId,time] = 0;
		$ClientInfo[%clientId,items,1] = "beacon 1";
		$ClientInfo[%clientId,items,2] = "RepairKit 1";
		$ClientInfo[%clientId,items,"num"] = 2;
		$ClientInfo[%ClientId,Cash, "num"] = %cash;
		Save(%ClientId);
   	}
}

function DW::getInventory(%clientId,%items)
{
	if(%clientId > 2048) 
	{
		%Name = DW::ChangeSymbols(Client::getName(%ClientId));
		%player = Client::getOwnedObject(%clientId);
		if(%player < 8000 || Player::isDead(%player))
			return;
		player::setitemcount(%clientId,beacon,1);
		player::setitemcount(%clientId,RepairKit,1);
		%num = 0;
		%max = getNumItems();
		%ownd = 0;
		for(%i = 0; %i < %max; %i++) 
		{
			%data = getItemData(%i);
			%count = Player::getItemCount(%player,%data);
			if(%count > 0) 
			{
				%info = %data@" "@%count;
				$DW::Save["[\""@%name@"\",\"Items\",\""@%num++@"\"]"] = %info;
				%clientId.invNum[%data] = %num;
				$ClientInfo[%clientId,Items,%num] = %info;
			}
		}
		$ClientInfo[%clientId,Items,"num"] = %num;
		if(%items == true) {
			%file = "BH_Stats["@%Name@"].cs"; 
			File::delete("temp\\" @ %file);
			Export("BH::Save[\""@%name@"\",*","temp\\" @ %file,false);	
		}
	}
	else
		return;
}

function String::len(%str)
{
	%inc = 10;
	%len = 0;
	for(%i = 0; String::getSubStr(%str,%i,1) != ""; %i += %inc)
	%len += %inc;
	%len -= %inc;
	%nst = String::getSubStr(%str,%len,900);
	for(%k = 0; String::getSubStr(%nst,%k,1) != ""; %k++)
	%len++;
	if(%len == -%inc)
	%len = 0;
	return %len;
}

function String::replace(%str,%a,%b)
{
	%pos = String::findSubStr(%str,%a);
	for(%pos; %pos != -1; %i++) {
	%strLen = String::len(%str);
	%oldLen = String::len(%a);
	%part1 = String::getSubStr(%str,0,%pos);
	%part2 = String::getSubStr(%str,%pos+%oldLen,%strLen-%pos-%oldLen);
	%str = %part1@%b@%part2;
	%pos = String::findSubStr(%str,%a);
	}
	return %str;
}

function DW::ChangeSymbols(%Name)
{
   %Name = String::convertSpaces(%Name);
   %Name = String::replace(%Name, "!", "A1");
   %Name = String::replace(%Name, "@", "A2");
   %Name = String::replace(%Name, "#", "A3");
   %Name = String::replace(%Name, "$", "A4");
   %Name = String::replace(%Name, "%", "A5");
   %Name = String::replace(%Name, "^", "A6");
   %Name = String::replace(%Name, "&", "A7");
   %Name = String::replace(%Name, "*", "A8");
   %Name = String::replace(%Name, "(", "A9");
   %Name = String::replace(%Name, ")", "B1");
   %Name = String::replace(%Name, "+", "B2");
   %Name = String::replace(%Name, "=", "B3");
   %Name = String::replace(%Name, ":", "B4");
   %Name = String::replace(%Name, "\"", "B5");
   %Name = String::replace(%Name, ";", "B6");
   %Name = String::replace(%Name, ">", "B7");
   %Name = String::replace(%Name, "<", "B8");
   %Name = String::replace(%Name, ",", "B9");
   %Name = String::replace(%Name, "?", "C1");
   %Name = String::replace(%Name, "/", "C2");
   %Name = String::replace(%Name, "~", "C3");
   %Name = String::replace(%Name, "`", "C4");
   %Name = String::replace(%Name, "|", "C5");
   %Name = String::replace(%Name, "[", "C6");
   %Name = String::replace(%Name, "]", "C7");
   %Name = String::replace(%Name, "}", "C8");
   %Name = String::replace(%Name, "{", "C9");
   return %name;
}

$GW::Save = 5.0;

function Global::Save()
{
	schedule("Global::Save();",5); // Sechedualed for every 5 seconds, need to make the On::killed(); save event work.
	if(getSimTime() >= ($GW::LastSave + $GW::Save)) 
	{
		Save("all");
		$GW::LastSave = getSimTime();
	}
}

function savekilled()
{
	Save("all");
}

function money()
{
%ClientId[34,Cash] = 2000;
 {
 if(%ClientId[34,Cash] = 0;
  {
 else(%clientId[34,Cash] = 2000;
  }
 }
}