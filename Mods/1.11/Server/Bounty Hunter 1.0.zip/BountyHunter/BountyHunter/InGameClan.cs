function clanmake(%leader,%clan)
{
%ClientID = %leader;
Client::sendMessage(%clientId, $MSGTypeGame, "Type in your Clan name into the Local Chat");
if(%clientid.nochat = true){return;}
get(%clientID, $MSGTypeLocal, " @ %Clan @ ");
Save::Clan(%leader,%clan);
}

function Save::Clan(%leader,%clan)
{
	if(%clientId == "all") 
	{
		if(Client::getFirst() < 2049)
			return;
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
			Save(%cl);
		return;
	}
	else if(%clientId < 2049)
		return;
	%file = "BH_Stats["@%Name@"].cs";
	$BH::Save["[\""@%Name@"\",\"Clan\"]"] = $ClientInfo[%clientId,Clan];
	$BH::Save["[\""@%Name@"\",\"Leader\"]"] = $ClientInfo[%clientId,Leader];
	%exportTo = "temp\\" @ %file;
	if(isFile(%exportTo))
		File::delete(%exportTo);
	if(%clientId > 2048)
		export("BH::Save[\""@%Name@"\",*", "Temp\\"@%file, false);
}

function Load::memeber(%ClientID,%clan)
{
%ClientID.clan = %clan;
	if(%clientId < 2049)
		return;
	%file = "BH_Stats["@%Name@"].cs";
	if(isFile("temp\\" @ %file))
		exec(%file);
	else {
		%file = "BH_Stats["@%Name@"].cs";
		if(isFile("temp\\" @ %file)) {
			exec(%file);
		}
	}
	{
	$ClientInfo[%ClientID,Clan] = $BH::Save[%Name,"Clan"];
	$ClientInfo[%ClientID,Leader] = $BH::Save[%Name,"Leader"];
	}
	else{
	$ClientInfo[%clientId,Clan] = "None";
	$ClientInfo[%clientId,Leader] = "None";
	}
}

