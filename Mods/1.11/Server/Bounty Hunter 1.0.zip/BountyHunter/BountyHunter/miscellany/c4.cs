//--------------------------------------

$SellAmmo[cfour] = 5;
addAPack(cfour,1);

addToInv(cfour,1,1);

setArmorItemMax(cfour,5,5,5);

//--------------------------------------

ItemData cfour
{
   description = "C4 PlasticExplosive";
   shapeFile = "sensor_small";
   heading = $InvCatMisc;
   shadowDetailMask = 4;
   price = 5;
	className = "HandAmmo";
   validateShape = true;
   //validateMaterials = true;
};

function cfour::onUse(%player,%item)
{
	if($matchStarted && %player.throwTime < getSimTime()) {
		%armor = $ArmorName[Player::getArmor(%player)];
		eval(%armor @ "::oncfour(" @ %player @ ", " @ %item @ ");");
	}
}

// Normal Hand cfour-----------------

MineData cfour
{
   mass = 0.5;
   drag = 1.0;
   density = 2.0;
	elasticity = 0;
	friction = 300.0;
	className = "Handgrenade";
   description = "C4 ElasticExplosive";
   shapeFile = "sensor_small";
   shadowDetailMask = 4;
   explosionId = grenadeExp;
	explosionRadius = 25.0;
	damageValue = 4;
	damageType = $ShrapnelDamageType;
	kickBackStrength = 200;
	triggerRadius = 0.5;
	maxDamage = 2;
};

function cfour::onAdd(%this)
 { 
      %data = GameBase::getDataName(%this); 
      schedule("Mine::Detonate(" @ %this @ ");",2.0,%this); 
 } 