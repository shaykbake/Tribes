DBZ_3k Mod Installation
Unzip all files into a directory in your tribes directory called DBZ_3k
and then go to MS-DOS prompt 
(if your tribes dir is this C:/dynamix/tribes/tribes.exe)
Then your it should look like this 

C:/dynamix/tribes/Tribes -mod DBZ_3k