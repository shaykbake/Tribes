//Main Server Settings
$ServerName = "Modx Server";
$ServerInfo = "Forum: CMX.CJB.NET\nAdmin: ?";
$TeamNameOne = "Team 1";
$TeamNameTwo = "Team 2";
$MaxPlayers = "8";
$ServerPort = "28001";
$JoinMOTD = "<jc><f1>Message of the Day:\nWelcome to TRIBES!\n\nFire to spawn.";

//Best not to mess with options:  DONT TAMPER WITH THESE.
$loadunleashed = true;            #Its best to not mess with this as it will disable a lot of stuff... But not all of it
$DeployAirbase = true;            #If u dont want the airbase, then u dont have to have it, Best left on
$loadunleashedweapons = true;     #Adds a few of my own custom weapons... Best to leave on

//Football Options
$footballenabled = false;         #Enable and Disable Football mod
$TacklingEnabled = false;         #Tired of being tackled? Then cut the shit off, Reenable it in the tab menu

//Password THinges
$CapacityLocking = false;         #Setting this to false will disable server locking under capacity
$ServerPassword = "y2k";          #The password used to the server
$Passworded = false;              #Set to true if password is enabled fulltime

//Admin Options
$LocalAdmin = true;               #Gives Local GoD on Non-Dedicated server
$AdminEnabled = true;             #Set to false to Disable ALL Admin. Peroid. Can be very useful eh?

//Admin OtherInfo Password Options
$OtherInfoPass = false;           #Set to true to enable otherinfo passwords
$GodPassword = "GodPassword";     #Set this to the password you must have in your otherinfo to recieve GodAdmin.
$SuperPassword = "SuperPassword"; #Set this to the password you must have in your otherinfo to recieve SuperAdmin.
$AdminPassword = "AdminPassword"; #Set this to the password you must have in your otherinfo to recieve PubAdmin.

//Admin SAD password options
$SADEnabled = false;              #Enable/Disable SAD passwords
$SADGodPassword = "";             #Sad God Password
$SADSuperPassword = "";           #Sad Super Password
$SADAdminPassword = "";           #Sad Pub Password

//Clan Options
$ModxClanServer = false;          #To ENable the clan server options, set to true
$clanname = "";                   #This is what team0(The clan team) will be called
$clantag = "";                    #This tag must be in a clanmemebers name to be on clan team

//Misc OPtions
$VotingEnabled = true;            #Voting toggle true/false
$RpEnabled = true;                #Set this to false to disable rpmode in the server.
$BotsEnabled = true;              #Bots Enabled/Disabled.
$BaseModDamage = true;            #Damage allowed in base mod
$AllowSmurfs = false;             #Set to true to allow smurfs.
$ShowTutorial = false;            #Show the tutorial to new players
$JetsEnabled = true;            #Enable/Disable jets in basemod

//Tool Options
$DeployablePowerRange = 300;      #range the creater will work
$DeployGunRange = 250;            #Range creater will work
$DeletorGunRange = 250;           #Range deleter will work
$MoverGunRange = 250;             #range manipulator will work
$VehicleStationRange = 35;        #working distance from vehicle pad to vehicle station

//Deploy OPtions
$DeployFloodProtect = true;       #flood protection on/off = true/false
$DeployFloodProtectTime = 10;     #Seconds to disable deploying when flood is active
$DeployFloodProtectFrequency = 6; #How many objects that must be deployed at once to activate deploy flooding.
$ModXHelpDelay = 100000;          #seconds until a help popup will popup, arrgh i hate those things....
$MaximumDeployCap = 900;          #Maximum amount of deploys allowed.
$ObjectRestoreDelay = "0.06";     #Delay between loading objects when restoring slots. Smaller = more lag, quicker loads.

//Object OPtions
$Waterenabled = true;             #Disable water effects


// In-Game Messages
// Where Used: %1 = Admin's Name, %2 = Victim's Name
$SlayMessage[1] = "You've had your head shoved in your ass by %1.";
$SlapMessage[1] = "You've been Bitch-Slapped Across the face by %1!";

$ToggleToolsMessage[0] = "You've had your Tool-Usage Access enabled by %1.";
$ToggleToolsMessage[1] = "You've had your Tool-Usage Access disabled by %1!";

$GagMessage[0] = "You have been Gagged.";   //Message when a client has been gagged
$GagMessage[1] = "You have been ungagged.";   //Message when a client has been ungagged

$LlamaMessage[0] = "You have been llamad.";   //Message when a client has been llamad
$LlamaMessage[1] = "You have been un-llamad";   //Message when a client has been unllamad

$LlamaMsg[0]  = "I Love Unleashed!";
$LlamaMsg[1]  = "Thank You E-DoG =D";           //Any String
$LlamaMsg[2]  = "Please Support Modx Unleashed";
$LlamaMsg[3]  = "Goto cmx.cjb.net";
$LlamaMsg[4]  = "Three Cheers To E-DoG";
$LlamaMsg[5]  = "Modx Is The Best Building mod EVER";
$LlamaMsg[6]  = "You can visit the modx website at cmx.cjb.net";
$LlamaMsgs = 7;                     //Total Messages in the LlamaMsg Array

//Admins moved to modxadmins.cs
