//Set Your Own Admins, 4 blank lines provided for you, to add more just copy the blank line, change the number up one
//the first line(ex. $admins[0] = "";) is the admins name
//the second line(ex. $Adminsdisplay[0] = ""; is what you would like the display on the tab menu to read for this player

//GODADMIN - only give this out to people you know and trust, becuase it is the ultimate power to have
$godadmins[0] = "";
$godadminsdisplay[0] = "";

$godadmins[1] = "";
$godadminsdisplay[1] = "";

$godadmins[2] = "";
$godadminsdisplay[2] = "";

$godadmins[3] = "";
$godadminsdisplay[3] = "";

$godadmins[4] = "";
$godadminsdisplay[4] = "";

$godadmins[5] = "";
$godadminsdisplay[5] = "";

//SUPERADMIN - Only for very good trustworthy admins... it is still a power to be reckoned with
$superadmins[0] = "";
$superadminsdisplay[0] = "";

$superadmins[1] = "";
$superadminsdisplay[1] = "";

$superadmins[2] = "";
$superadminsdisplay[2] = "";

$superadmins[3] = "";
$superadminsdisplay[3] = "";

$superadmins[4] = "";
$superadminsdisplay[4] = "";

$superadmins[5] = "";
$superadminsdisplay[5] = "";

//ADMINS - Just regular old admin... same options as revisited
$admins[0] = "";
$adminsdisplay[0] = "";

$admins[1] = "";
$adminsdisplay[1] = "";

$admins[2] = "";
$adminsdisplay[2] = "";

$admins[3] = "";
$adminsdisplay[3] = "";

$admins[4] = "";
$adminsdisplay[4] = "";

$admins[5] = "";
$adminsdisplay[5] = "";
//If you have any probs setting this up, read the readme
