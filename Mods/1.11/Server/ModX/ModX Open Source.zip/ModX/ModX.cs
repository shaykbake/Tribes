// |\/| _  _|\/
// |  |(_)(_|/\ Is under copyright, all rights reserved.
// Creator:     Vage aka Jacob B. Gohlke
// Website:     http://modx.cjb.net/
//
// Any Code included within the 'Scripts.Vol' is within this copyright
// unless otherwise stated.
//
// Build Date:  11-14-04
// Version 3.0R2
//
// Recommended Font: Terminal, FixedSys, Courier, or Lucidia Console
//
//
//       _/      _/                  _/  _/      _/
//      _/_/  _/_/    _/_/      _/_/_/    _/  _/
//     _/  _/  _/  _/    _/  _/    _/      _/
//    _/      _/  _/    _/  _/    _/    _/  _/
//   _/      _/    _/_/      _/_/_/  _/      _/
//
//  _____________________________________________/
// /                                        -JBG-

// Server Settings
$ModXServerLANOnly = false;         //set to true to have a LAN only server.

// Options
$DeployablePowerRange = 300;        //meters
$DeployGunRange = 150;              //meters
$VehicleStationRange = 35;          //meters

$DeployFloodProtect = true;         //boolean
$DeployFloodProtectTime = 10;       //seconds
$DeployFloodProtectFrequency = 6;   //interval

$ModXHelpDelay = 120;               //seconds

$MaximumDeployCap = 750;            //Safe Value, anything over your on your own!

// In-Game Messages
// Where Used: %1 = Admin's Name, %2 = Victim's Name
$LlamaMsg[0]  = "BLEEAAAT!";
$LlamaMsg[1]  = "ORGLE!";           //Any String
$LlamaMsg[2]  = "MOO... UM, BLEAT!";
$LlamaMsgs = 3;                     //Total Messages in the LlamaMsg Array

$SlayMessage[1] = "You've been slayed by %1.";

$SlapMessage[1] = "You've been slapped by %1!";

$BlindMessage[1] = "You've been blinded by %1! Normal sight will return... Eventually.";
$BlindTime = 30;                    //seconds

$ContKillMessage[1] = "You've been stuck in the blender by %1, you'll get out soon!";
$ContKillTime = 60;                 //seconds

$ToggleToolsMessage[0] = "You've had your Tool-Usage Access enabled by %1.";
$ToggleToolsMessage[1] = "You've had your Tool-Usage Access disabled by %1!";

$GagMessage[0] = "Your vocal cords have been surgically replaced by %1.";
$GagMessage[1] = "Your vocal cords have been torn out by %1!";

$LlamaMessage[0] = "Your vocal cords have been replaced to original form by %1.";
$LlamaMessage[1] = "Your vocal cords have been changed into a Llama's by %1!";

// Admins
// About 'Other Info' Codes...
// These codes are for admins that you don't want to deisgnate with an account.
// Make sure that they have these 'Codes' in thier 'Other Info' and that you have
// thier name in the Admins or SuperAdmins array.
// I recommend that you use 1's l's and I's because these appear the same on
// the standard TRIBES font.
$AdminPassword = "1Il";
$SuperAdminPassword = "lI1";

$Admins[0] = "";
$Admins[1] = "";

$SuperAdmins[0] = "Vage";
$SuperAdmins[1] = "";
