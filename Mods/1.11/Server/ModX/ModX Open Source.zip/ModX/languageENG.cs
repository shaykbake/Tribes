//----------------------------------------------------------------------------//
//                                                                            //
// |\/| _  _|\/                                                               //
// |  |(_)(_|/\ Language Pack                                                 //
//                                                                            //
//                                                                            //
//      Locale      : English                                                 //
//      Date        : 10-12-04                                                //
//      Author      : Jacob 'Vage' Gohlke                                     //
//      Website     : http://modx.cjb.net/                                    //
//      Description : Basic English ModX Language File                        //
//                    Use as a base for other language files...               //
//                                                                            //
//                                                                            //
//----------------------------------------------------------------------------//

Language::addLocale("English");

$Language["English", "changeMissionMenu"] = "Pick Mission Type";
$Language["English", "MenuCMType"] = "Pick Mission";
$Language["English", "CMission"] = "%1 changed the mission to %2 (%3)";
$Language["English", "CMissionVote"] = "change the mission to %1 (%2)";
$Language["English", "SetTimeLimit"] = "%1 changed the time limit to %2 minute(s).";
$Language["English", "SetTimeLimitDis"] = "%1 disabled the time limit.";
$Language["English", "SetInfoRemote"] = "Team %1 is now \" %2 \" with skin: %3 courtesy of %4. Changes will take effect next mission.";
$Language["English", "Banned"] = "banned";
$Language["English", "Kicked"] = "kicked";
$Language["English", "Ban"] = "Ban";
$Language["English", "Kick"] = "Kick";
$Language["English", "Admin"] = "Admin";
$Language["English", "Revoke"] = "Revoke";
$Language["English", "Grant"] = "Grant";
$Language["English", "AdminKickFail"] = "A super admin cannot be %1.";
$Language["English", "AdminKickCL"] = "You were %2 by %3";
$Language["English", "AdminKick"] = "%1 was %2 by %3";
$Language["English", "Consensus"] = "consensus";
$Language["English", "VotePass"] = "Vote to %1 passed: %2 to %3.";
$Language["English", "VoteFail"] = "Vote to %1 did not pass: %2 to %3 with %4 abstentions.";
$Language["English", "StartVoteFail1"] = "You can't start another vote for %1 seconds.";
$Language["English", "StartVoteFail2"] = "Voting already in progress.";
$Language["English", "StartVote"] = "%1 initiated a vote to %2";
$Language["English", "Options"] = "Options";
$Language["English", "VKick"] = "Vote to kick %1";
$Language["English", "AdminTorture"] = "Admin Punishment";
$Language["English", "AdminOptions"] = "Admin Functions";
$Language["English", "Mute"] = "Mute";
$Language["English", "Unmute"] = "Unmute";
$Language["English", "Observe"] = "Observe";
$Language["English", "ChangeTeamMenu"] = "Change Teams/Observe";
$Language["English", "ModXObjOptMenu"] = "ModX Object Options";
$Language["English", "UndoLast"] = "Undo Last Deploy";
$Language["English", "RedoLast"] = "Redo Last Undo";
$Language["English", "AcctMgmt"] = "Account Management";
$Language["English", "VoteYesTo"] = "Vote YES to";
$Language["English", "VoteNoTo"] = "Vote NO to";
$Language["English", "Vote"] = "Vote";
$Language["English", "PlayerInd"] = "Player Index";
$Language["English", "PlayerInfo"] = "Player Info for";
$Language["English", "RealName"] = "Real Name";
$Language["English", "Email"] = "Email";
$Language["English", "Next"] = "Next";
$Language["English", "ChangeTeam"] = "Change Team";
$Language["English", "DestAllClObj"] = "Destroy all client's objects";
$Language["English", "ToolAccess"] = "Tool Access";
$Language["English", "Enable"] = "Enable";
$Language["English", "Disable"] = "Disable";
$Language["English", "Slap"] = "Slap";
$Language["English", "Slay"] = "Slay";
$Language["English", "Blind"] = "Blind";
$Language["English", "ContinuousSlay"] = "Continuous Slay";
$Language["English", "Disable"] = "Disable";
$Language["English", "UngagPL"] = "Ungag Player";
$Language["English", "GagPL"] = "Gag Player";
$Language["English", "Player"] = "Player";
$Language["English", "Yes"] = "Yes";
$Language["English", "No"] = "No";
$Language["English", "Confirm"] = "Confirm";
$Language["English", "Menu"] = "Menu";
$Language["English", "PickTeam"] = "Pick a team";
$Language["English", "Observer"] = "Observer";
$Language["English", "Automatic"] = "Automatic";
$Language["English", "ResetSrvDfl"] = "Reset Server Defaults";
$Language["English", "DestAll"] = "Destroy All Objects";
$Language["English", "DisTag"] = "Automatic";
$Language["English", "EnTag"] = "Enable Laser Tag";
$Language["English", "EnTagTeam"] = "Enable Team Laser Tag";
$Language["English", "Account"] = "Account";

