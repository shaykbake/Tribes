//----------------------------------------------------------------------------
// Recon Armor
//----------------------------------------------------------------------------

$ItemMax[rarmor, Blaster] = 1;
$ItemMax[rarmor, SuperBlaster] = 0;
$ItemMax[rarmor, Chaingun] = 1;
$ItemMax[rarmor, Disclauncher] = 1;
$ItemMax[rarmor, GrenadeLauncher] = 1;
$ItemMax[rarmor, Mortar] = 0;
$ItemMax[rarmor, PlasmaGun] = 1;
$ItemMax[rarmor, BotGun] = 1;
$ItemMax[rarmor, LavaGun] = 0;
$ItemMax[rarmor, RadiationGun] = 1;
$ItemMax[rarmor, BotGunX] = 0;
$ItemMax[rarmor, LaserRifle] = 1;
$ItemMax[rarmor, SniperRifle] = 1;
$ItemMax[rarmor, EnergyRifle] = 1;
$ItemMax[rarmor, TargetingLaser] = 1;
$ItemMax[rarmor, MineAmmo] = 3;
$ItemMax[rarmor, Grenade] = 5;
$ItemMax[rarmor, Beacon]  = 3;

$ItemMax[rarmor, BulletAmmo] = 100;
$ItemMax[rarmor, PowerCell] = 400;
$ItemMax[rarmor, PlasmaAmmo] = 300;
$ItemMax[rarmor, LavaAmmo] = 30;
$ItemMax[rarmor, RadiationAmmo] = 100;
$ItemMax[rarmor, DiscAmmo] = 15;
$ItemMax[rarmor, SniperAmmo] = 15;
$ItemMax[rarmor, BotAmmo] = 1;
$ItemMax[rarmor, GrenadeAmmo] = 10;
$ItemMax[rarmor, MortarAmmo] = 10;

$ItemMax[rarmor, EnergyPack] = 1;
$ItemMax[rarmor, RepairPack] = 1;
$ItemMax[rarmor, ShieldPack] = 1;
$ItemMax[rarmor, SensorJammerPack] = 1;
$ItemMax[rarmor, MotionSensorPack] = 1;
$ItemMax[rarmor, PulseSensorPack] = 1;
$ItemMax[rarmor, DeployableSensorJammerPack] = 1;
$ItemMax[rarmor, CameraPack] = 1;
$ItemMax[rarmor, TurretPack] = 0;
$ItemMax[rarmor, ZapperPack] = 0;
$ItemMax[rarmor, AmmoPack] = 1;
$ItemMax[rarmor, RepairKit] = 1;
$ItemMax[rarmor, DeployableInvPack] = 0;
$ItemMax[rarmor, DeployableAmmoPack] = 0;

$MaxWeapons[rarmor] = 3;

//----------------------------------------------------------------------------
// Light Armor
//----------------------------------------------------------------------------

$ItemMax[larmor, Blaster] = 1;
$ItemMax[larmor, SuperBlaster] = 1;
$ItemMax[larmor, Chaingun] = 1;
$ItemMax[larmor, Disclauncher] = 1;
$ItemMax[larmor, GrenadeLauncher] = 1;
$ItemMax[larmor, Mortar] = 0;
$ItemMax[larmor, PlasmaGun] = 1;
$ItemMax[larmor, BotGun] = 1;
$ItemMax[larmor, LavaGun] = 1;
$ItemMax[larmor, RadiationGun] = 1;
$ItemMax[larmor, BotGunX] = 1;
$ItemMax[larmor, LaserRifle] = 1;
$ItemMax[larmor, SniperRifle] = 1;
$ItemMax[larmor, EnergyRifle] = 1;
$ItemMax[larmor, TargetingLaser] = 1;
$ItemMax[larmor, MineAmmo] = 3;
$ItemMax[larmor, Grenade] = 5;
$ItemMax[larmor, Beacon]  = 3;

$ItemMax[larmor, BulletAmmo] = 100;
$ItemMax[larmor, PowerCell] = 400;
$ItemMax[larmor, PlasmaAmmo] = 30;
$ItemMax[larmor, DiscAmmo] = 25;
$ItemMax[larmor, SniperAmmo] = 25;
$ItemMax[larmor, BotAmmo] = 5;
$ItemMax[larmor, LavaAmmo] = 300;
$ItemMax[larmor, RadiationAmmo] = 50;
$ItemMax[larmor, GrenadeAmmo] = 10;
$ItemMax[larmor, MortarAmmo] = 10;

$ItemMax[larmor, EnergyPack] = 1;
$ItemMax[larmor, RepairPack] = 1;
$ItemMax[larmor, ShieldPack] = 1;
$ItemMax[larmor, SensorJammerPack] = 1;
$ItemMax[larmor, MotionSensorPack] = 1;
$ItemMax[larmor, PulseSensorPack] = 1;
$ItemMax[larmor, DeployableSensorJammerPack] = 1;
$ItemMax[larmor, CameraPack] = 1;
$ItemMax[larmor, TurretPack] = 0;
$ItemMax[larmor, ZapperPack] = 0;
$ItemMax[larmor, AmmoPack] = 1;
$ItemMax[larmor, RepairKit] = 1;
$ItemMax[larmor, DeployableInvPack] = 0;
$ItemMax[larmor, DeployableAmmoPack] = 0;

$MaxWeapons[larmor] = 3;


//----------------------------------------------------------------------------
// light Female Armor
//----------------------------------------------------------------------------

$ItemMax[lfemale, Blaster] = 1;
$ItemMax[lfemale, SuperBlaster] = 1;
$ItemMax[lfemale, Chaingun] = 1;
$ItemMax[lfemale, Disclauncher] = 1;
$ItemMax[lfemale, GrenadeLauncher] = 1;
$ItemMax[lfemale, Mortar] = 0;
$ItemMax[lfemale, PlasmaGun] = 1;
$ItemMax[lfemale, BotGun] = 1;
$ItemMax[lfemale, LavaGun] = 1;
$ItemMax[lfemale, RadiationGun] = 1;
$ItemMax[lfemale, BotGunX] = 1;
$ItemMax[lfemale, LaserRifle] = 1;
$ItemMax[lfemale, SniperRifle] = 1;
$ItemMax[lfemale, EnergyRifle] = 1;
$ItemMax[lfemale, TargetingLaser] = 1;
$ItemMax[lfemale, MineAmmo] = 3;
$ItemMax[lfemale, Grenade] = 5;
$ItemMax[lfemale, Beacon] = 3;

$ItemMax[lfemale, BulletAmmo] = 100;
$ItemMax[lfemale, PowerCell] = 500;
$ItemMax[lfemale, PlasmaAmmo] = 30;
$ItemMax[lfemale, DiscAmmo] = 25;
$ItemMax[lfemale, SniperAmmo] = 25;
$ItemMax[lfemale, BotAmmo] = 5;
$ItemMax[lfemale, LavaAmmo] = 50;
$ItemMax[lfemale, RadiationAmmo] = 100;
$ItemMax[lfemale, GrenadeAmmo] = 10;
$ItemMax[lfemale, MortarAmmo] = 10;

$ItemMax[lfemale, EnergyPack] = 1;
$ItemMax[lfemale, RepairPack] = 1;
$ItemMax[lfemale, ShieldPack] = 1;
$ItemMax[lfemale, SensorJammerPack] = 1;
$ItemMax[lfemale, MotionSensorPack] = 1;
$ItemMax[lfemale, PulseSensorPack] = 1;
$ItemMax[lfemale, DeployableSensorJammerPack] = 1;
$ItemMax[lfemale, CameraPack] = 1;
$ItemMax[lfemale, TurretPack] = 0;
$ItemMax[lfemale, ZapperPack] = 0;
$ItemMax[lfemale, AmmoPack] = 1;
$ItemMax[lfemale, RepairKit] = 1;
$ItemMax[lfemale, DeployableInvPack] = 0;
$ItemMax[lfemale, DeployableAmmoPack] = 0;

$MaxWeapons[lfemale] = 3;

//----------------------------------------------------------------------------
// recon Female Armor
//----------------------------------------------------------------------------

$ItemMax[rfemale, Blaster] = 1;
$ItemMax[rfemale, SuperBlaster] = 0;
$ItemMax[rfemale, Chaingun] = 1;
$ItemMax[rfemale, Disclauncher] = 1;
$ItemMax[rfemale, GrenadeLauncher] = 1;
$ItemMax[rfemale, Mortar] = 0;
$ItemMax[rfemale, PlasmaGun] = 1;
$ItemMax[rfemale, BotGun] = 1;
$ItemMax[rfemale, LavaGun] = 0;
$ItemMax[rfemale, RadiationGun] = 1;
$ItemMax[rfemale, RadiationGun] = 1;
$ItemMax[rfemale, BotGunX] = 0;
$ItemMax[rfemale, LaserRifle] = 1;
$ItemMax[rfemale, SniperRifle] = 1;
$ItemMax[rfemale, EnergyRifle] = 1;
$ItemMax[rfemale, TargetingLaser] = 1;
$ItemMax[rfemale, MineAmmo] = 3;
$ItemMax[rfemale, Grenade] = 5;
$ItemMax[rfemale, Beacon] = 3;

$ItemMax[rfemale, BulletAmmo] = 100;
$ItemMax[rfemale, PowerCell] = 200;
$ItemMax[rfemale, PlasmaAmmo] = 30;
$ItemMax[rfemale, DiscAmmo] = 15;
$ItemMax[rfemale, SniperAmmo] = 15;
$ItemMax[rfemale, BotAmmo] = 1;
$ItemMax[rfemale, LavaAmmo] = 25;
$ItemMax[rfemale, RadiationAmmo] = 100;
$ItemMax[rfemale, GrenadeAmmo] = 10;
$ItemMax[rfemale, MortarAmmo] = 10;

$ItemMax[rfemale, EnergyPack] = 1;
$ItemMax[rfemale, RepairPack] = 1;
$ItemMax[rfemale, ShieldPack] = 1;
$ItemMax[rfemale, SensorJammerPack] = 1;
$ItemMax[rfemale, MotionSensorPack] = 1;
$ItemMax[rfemale, PulseSensorPack] = 1;
$ItemMax[rfemale, DeployableSensorJammerPack] = 1;
$ItemMax[rfemale, CameraPack] = 1;
$ItemMax[rfemale, TurretPack] = 0;
$ItemMax[rfemale, ZapperPack] = 0;
$ItemMax[rfemale, AmmoPack] = 1;
$ItemMax[rfemale, RepairKit] = 1;
$ItemMax[rfemale, DeployableInvPack] = 0;
$ItemMax[rfemale, DeployableAmmoPack] = 0;

$MaxWeapons[rfemale] = 3;

//----------------------------------------------------------------------------
// Medium Armor
//----------------------------------------------------------------------------

$ItemMax[marmor, Blaster] = 1;
$ItemMax[marmor, SuperBlaster] = 0;
$ItemMax[marmor, Chaingun] = 1;
$ItemMax[marmor, Disclauncher] = 1;
$ItemMax[marmor, GrenadeLauncher] = 1;
$ItemMax[marmor, Mortar] = 0;
$ItemMax[marmor, PlasmaGun] = 1;
$ItemMax[marmor, BotGun] = 1;
$ItemMax[marmor, LavaGun] = 1;
$ItemMax[marmor, RadiationGun] = 1;
$ItemMax[marmor, BotGunX] = 0;
$ItemMax[marmor, LaserRifle] = 0;
$ItemMax[marmor, SniperRifle] = 0;
$ItemMax[marmor, EnergyRifle] = 1;
$ItemMax[marmor, TargetingLaser] = 1;
$ItemMax[marmor, MineAmmo] = 3;
$ItemMax[marmor, Grenade] = 6;
$ItemMax[marmor, Beacon] = 3;

$ItemMax[marmor, BulletAmmo] = 150;
$ItemMax[marmor, PowerCell] = 600;
$ItemMax[marmor, PlasmaAmmo] = 40;
$ItemMax[marmor, DiscAmmo] = 15;
$ItemMax[marmor, SniperAmmo] = 15;
$ItemMax[marmor, BotAmmo] = 8;
$ItemMax[marmor, LavaAmmo] = 500;
$ItemMax[marmor, RadiationAmmo] = 100;
$ItemMax[marmor, GrenadeAmmo] = 10;
$ItemMax[marmor, MortarAmmo] = 10;

$ItemMax[marmor, EnergyPack] = 1;
$ItemMax[marmor, RepairPack] = 1;
$ItemMax[marmor, ShieldPack] = 1;
$ItemMax[marmor, SensorJammerPack] = 1;
$ItemMax[marmor, MotionSensorPack] = 1;
$ItemMax[marmor, PulseSensorPack] = 1;
$ItemMax[marmor, DeployableSensorJammerPack] = 1;
$ItemMax[marmor, CameraPack] = 1;
$ItemMax[marmor, TurretPack] = 1;
$ItemMax[marmor, ZapperPack] = 1;
$ItemMax[marmor, AmmoPack] = 1;
$ItemMax[marmor, RepairKit] = 1;
$ItemMax[marmor, DeployableInvPack] = 1;
$ItemMax[marmor, DeployableAmmoPack] = 1;

$MaxWeapons[marmor] = 4;

//----------------------------------------------------------------------------
// Medium Female Armor
//----------------------------------------------------------------------------

$ItemMax[mfemale, Blaster] = 1;
$ItemMax[mfemale, SuperBlaster] = 0;
$ItemMax[mfemale, Chaingun] = 1;
$ItemMax[mfemale, Disclauncher] = 1;
$ItemMax[mfemale, GrenadeLauncher] = 1;
$ItemMax[mfemale, Mortar] = 0;
$ItemMax[mfemale, PlasmaGun] = 1;
$ItemMax[mfemale, BotGun] = 1;
$ItemMax[mfemale, LavaGun] = 1;
$ItemMax[mfemale, RadiationGun] = 1;
$ItemMax[mfemale, BotGunX] = 0;
$ItemMax[mfemale, LaserRifle] = 0;
$ItemMax[mfemale, SniperRifle] = 0;
$ItemMax[mfemale, EnergyRifle] = 1;
$ItemMax[mfemale, TargetingLaser] = 1;
$ItemMax[mfemale, MineAmmo] = 3;
$ItemMax[mfemale, Grenade] = 6;
$ItemMax[mfemale, Beacon] = 3;

$ItemMax[mfemale, BulletAmmo] = 150;
$ItemMax[mfemale, PowerCell] = 600;
$ItemMax[mfemale, PlasmaAmmo] = 40;
$ItemMax[mfemale, DiscAmmo] = 15;
$ItemMax[mfemale, SniperAmmo] = 15;
$ItemMax[mfemale, BotAmmo] = 8;
$ItemMax[mfemale, LavaAmmo] = 500;
$ItemMax[mfemale, RadiationAmmo] = 100;
$ItemMax[mfemale, GrenadeAmmo] = 10;
$ItemMax[mfemale, MortarAmmo] = 10;

$ItemMax[mfemale, EnergyPack] = 1;
$ItemMax[mfemale, RepairPack] = 1;
$ItemMax[mfemale, ShieldPack] = 1;
$ItemMax[mfemale, SensorJammerPack] = 1;
$ItemMax[mfemale, MotionSensorPack] = 1;
$ItemMax[mfemale, PulseSensorPack] = 1;
$ItemMax[mfemale, DeployableSensorJammerPack] = 1;
$ItemMax[mfemale, CameraPack] = 1;
$ItemMax[mfemale, TurretPack] = 1;
$ItemMax[mfemale, ZapperPack] = 1;
$ItemMax[mfemale, AmmoPack] = 1;
$ItemMax[mfemale, RepairKit] = 1;
$ItemMax[mfemale, DeployableInvPack] = 1;
$ItemMax[mfemale, DeployableAmmoPack] = 1;

$MaxWeapons[mfemale] = 4;

//----------------------------------------------------------------------------
// Heavy Armor
//----------------------------------------------------------------------------


$ItemMax[harmor, Blaster] = 1;
$ItemMax[harmor, SuperBlaster] = 1;
$ItemMax[harmor, Chaingun] = 1;
$ItemMax[harmor, Disclauncher] = 1;
$ItemMax[harmor, GrenadeLauncher] = 1;
$ItemMax[harmor, Mortar] = 1;
$ItemMax[harmor, PlasmaGun] = 1;
$ItemMax[harmor, BotGun] = 0;
$ItemMax[harmor, LavaGun] = 1;
$ItemMax[harmor, RadiationGun] = 1;
$ItemMax[harmor, BotGunX] = 1;
$ItemMax[harmor, LaserRifle] = 0;
$ItemMax[harmor, SniperRifle] = 0;
$ItemMax[harmor, EnergyRifle] = 1;
$ItemMax[harmor, TargetingLaser] = 1;
$ItemMax[harmor, MineAmmo] = 3;
$ItemMax[harmor, Grenade] = 8;
$ItemMax[harmor, Beacon] = 3;

$ItemMax[harmor, BulletAmmo] = 200;
$ItemMax[harmor, PowerCell] = 950;
$ItemMax[harmor, PlasmaAmmo] = 50;
$ItemMax[harmor, DiscAmmo] = 15;
$ItemMax[harmor, SniperAmmo] = 15;
$ItemMax[harmor, BotAmmo] = 10;
$ItemMax[harmor, LavaAmmo] = 200;
$ItemMax[harmor, RadiationAmmo] = 100;
$ItemMax[harmor, GrenadeAmmo] = 15;
$ItemMax[harmor, MortarAmmo] = 10;

$ItemMax[harmor, EnergyPack] = 1;
$ItemMax[harmor, RepairPack] = 1;
$ItemMax[harmor, ShieldPack] = 1;
$ItemMax[harmor, SensorJammerPack] = 1;
$ItemMax[harmor, MotionSensorPack] = 1;
$ItemMax[harmor, PulseSensorPack] = 1;
$ItemMax[harmor, DeployableSensorJammerPack] = 1;
$ItemMax[harmor, CameraPack] = 1;
$ItemMax[harmor, TurretPack] = 1;
$ItemMax[harmor, ZapperPack] = 1;
$ItemMax[harmor, AmmoPack] = 1;
$ItemMax[harmor, RepairKit] = 1;
$ItemMax[harmor, DeployableInvPack] = 1;
$ItemMax[harmor, DeployableAmmoPack] = 1;

$MaxWeapons[harmor] = 5;


//----------------------------------------------------------------------------
// Floater Armor
//----------------------------------------------------------------------------


$ItemMax[farmor, Blaster] = 0;
$ItemMax[farmor, SuperBlaster] = 0;
$ItemMax[farmor, Chaingun] = 0;
$ItemMax[farmor, Disclauncher] = 1;
$ItemMax[farmor, GrenadeLauncher] = 1;
$ItemMax[farmor, Mortar] = 1;
$ItemMax[farmor, PlasmaGun] = 1;
$ItemMax[farmor, BotGun] = 1;
$ItemMax[farmor, LavaGun] = 0;
$ItemMax[farmor, RadiationGun] = 1;
$ItemMax[farmor, BotGunX] = 0;
$ItemMax[farmor, LaserRifle] = 0;
$ItemMax[farmor, SniperRifle] = 0;
$ItemMax[farmor, EnergyRifle] = 1;
$ItemMax[farmor, TargetingLaser] = 1;
$ItemMax[farmor, MineAmmo] = 20;
$ItemMax[farmor, Grenade] = 30;
$ItemMax[farmor, Beacon] = 5;

$ItemMax[farmor, BulletAmmo] = 200;
$ItemMax[farmor, PowerCell] = 400;
$ItemMax[farmor, PlasmaAmmo] = 50;
$ItemMax[farmor, DiscAmmo] = 15;
$ItemMax[farmor, SniperAmmo] = 15;
$ItemMax[farmor, BotAmmo] = 5;
$ItemMax[farmor, LavaAmmo] = 100;
$ItemMax[farmor, RadiationAmmo] = 100;
$ItemMax[farmor, GrenadeAmmo] = 15;
$ItemMax[farmor, MortarAmmo] = 10;

$ItemMax[farmor, EnergyPack] = 1;
$ItemMax[farmor, RepairPack] = 0;
$ItemMax[farmor, ShieldPack] = 1;
$ItemMax[farmor, SensorJammerPack] = 0;
$ItemMax[farmor, MotionSensorPack] = 0;
$ItemMax[farmor, PulseSensorPack] = 0;
$ItemMax[farmor, DeployableSensorJammerPack] = 1;
$ItemMax[farmor, CameraPack] = 0;
$ItemMax[farmor, TurretPack] = 0;
$ItemMax[farmor, ZapperPack] = 1;
$ItemMax[farmor, AmmoPack] = 0;
$ItemMax[farmor, RepairKit] = 15;
$ItemMax[farmor, DeployableInvPack] = 0;
$ItemMax[farmor, DeployableAmmoPack] = 1;

$MaxWeapons[farmor] = 5;


//----------------------------------------------------------------------------
// Bot Lord Armor
//----------------------------------------------------------------------------


$ItemMax[barmor, Blaster] = 0;
$ItemMax[barmor, SuperBlaster] = 0;
$ItemMax[barmor, Chaingun] = 1;
$ItemMax[barmor, Disclauncher] = 0;
$ItemMax[barmor, GrenadeLauncher] = 0;
$ItemMax[barmor, Mortar] = 0;
$ItemMax[barmor, PlasmaGun] = 1;
$ItemMax[barmor, BotGun] = 1;
$ItemMax[barmor, LavaGun] = 1;
$ItemMax[barmor, RadiationGun] = 1;
$ItemMax[barmor, BotGunX] = 1;
$ItemMax[barmor, LaserRifle] = 0;
$ItemMax[barmor, SniperRifle] = 0;
$ItemMax[barmor, EnergyRifle] = 1;
$ItemMax[barmor, TargetingLaser] = 1;
$ItemMax[barmor, MineAmmo] = 20;
$ItemMax[barmor, Grenade] = 30;
$ItemMax[barmor, Beacon] = 5;

$ItemMax[barmor, BulletAmmo] = 200;
$ItemMax[barmor, PowerCell] = 800;
$ItemMax[barmor, PlasmaAmmo] = 50;
$ItemMax[barmor, DiscAmmo] = 35;
$ItemMax[barmor, SniperAmmo] = 15;
$ItemMax[barmor, BotAmmo] = 30;
$ItemMax[barmor, LavaAmmo] = 200;
$ItemMax[barmor, RadiationAmmo] = 100;
$ItemMax[barmor, GrenadeAmmo] = 15;
$ItemMax[barmor, MortarAmmo] = 10;

$ItemMax[barmor, EnergyPack] = 1;
$ItemMax[barmor, RepairPack] = 0;
$ItemMax[barmor, ShieldPack] = 1;
$ItemMax[barmor, SensorJammerPack] = 0;
$ItemMax[barmor, MotionSensorPack] = 0;
$ItemMax[barmor, PulseSensorPack] = 0;
$ItemMax[barmor, DeployableSensorJammerPack] = 1;
$ItemMax[barmor, CameraPack] = 0;
$ItemMax[barmor, TurretPack] = 0;
$ItemMax[barmor, ZapperPack] = 5;
$ItemMax[barmor, AmmoPack] = 0;
$ItemMax[barmor, RepairKit] = 15;
$ItemMax[barmor, DeployableInvPack] = 0;
$ItemMax[barmor, DeployableAmmoPack] = 1;

$MaxWeapons[barmor] = 3;


//----------------------------------------------------------------------------
// Anti-Aircraft Armor
//----------------------------------------------------------------------------


$ItemMax[aarmor, Blaster] = 1;
$ItemMax[aarmor, SuperBlaster] = 1;
$ItemMax[aarmor, Chaingun] = 1;
$ItemMax[aarmor, Disclauncher] = 0;
$ItemMax[aarmor, GrenadeLauncher] = 0;
$ItemMax[aarmor, Mortar] = 0;
$ItemMax[aarmor, PlasmaGun] = 1;
$ItemMax[aarmor, BotGun] = 0;
$ItemMax[aarmor, LavaGun] = 0;
$ItemMax[aarmor, RadiationGun] = 1;
$ItemMax[aarmor, BotGunX] = 0;
$ItemMax[aarmor, LaserRifle] = 0;
$ItemMax[aarmor, SniperRifle] = 0;
$ItemMax[aarmor, EnergyRifle] = 1;
$ItemMax[aarmor, TargetingLaser] = 1;
$ItemMax[aarmor, MineAmmo] = 20;
$ItemMax[aarmor, Grenade] = 30;
$ItemMax[aarmor, Beacon] = 5;

$ItemMax[aarmor, BulletAmmo] = 200;
$ItemMax[aarmor, PowerCell] = 800;
$ItemMax[aarmor, PlasmaAmmo] = 50;
$ItemMax[aarmor, DiscAmmo] = 35;
$ItemMax[aarmor, SniperAmmo] = 15;
$ItemMax[aarmor, BotAmmo] = 30;
$ItemMax[aarmor, RadiationAmmo] = 100;
$ItemMax[aarmor, LavaAmmo] = 200;
$ItemMax[aarmor, GrenadeAmmo] = 15;
$ItemMax[aarmor, MortarAmmo] = 10;

$ItemMax[aarmor, EnergyPack] = 1;
$ItemMax[aarmor, RepairPack] = 0;
$ItemMax[aarmor, ShieldPack] = 1;
$ItemMax[aarmor, SensorJammerPack] = 0;
$ItemMax[aarmor, MotionSensorPack] = 0;
$ItemMax[aarmor, PulseSensorPack] = 0;
$ItemMax[aarmor, DeployableSensorJammerPack] = 1;
$ItemMax[aarmor, CameraPack] = 0;
$ItemMax[aarmor, TurretPack] = 0;
$ItemMax[aarmor, ZapperPack] = 1;
$ItemMax[aarmor, AmmoPack] = 0;
$ItemMax[aarmor, RepairKit] = 15;
$ItemMax[aarmor, DeployableInvPack] = 0;
$ItemMax[aarmor, DeployableAmmoPack] = 1;

$MaxWeapons[aarmor] = 6;


