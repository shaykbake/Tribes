focusServer
setcat missionName $1 ".mis"
loadMission $missionName
focusClient

$FriendlyTurretTeam = 0;
