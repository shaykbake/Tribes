//___________________________________________________________________________________________________________________________________________________
//---------------------------------------------------------------------------------------------------------------------------------------------------\
// THIS CODE IS USED TO CREATE THE USE OF PURCHASE MSG'S IN GAME, ANYONE WHO STEALS, OR USES THIS CODE WITHOUT MY PERMISSTION WILL BE SHOT AND EATEN  |
//___________________________________________________________________________________________________________________________________________________/
// COPYRIGHT 2002 "CT(R)" //|
//------------------------//|
// Ice / FishinSC@aolcom //|
//==========================|
// Font<f0> = ORANGE
// Font<f1> = PALE YELLOW
// Font<f2> = WHITE

//Armor::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[LightArmor]   = "<jc><f2>Pilot Armor:\n";
$WeapBuyMSG[PantherArmor] = "<jc><f2>Strider Armor:\n";
$WeapBuyMSG[SniperArmor]  = "<jc><f2>Sniper Armor:\n";
$WeapBuyMSG[SpecialArmor] = "<jc><f2>Specialist Armor:\n";
$WeapBuyMSG[MediumArmor]  = "<jc><f2>Engineer Armor:\n";
$WeapBuyMSG[PyroArmor]    = "<jc><f2>Pyro Armor:\n";
$WeapBuyMSG[HeavyArmor]   = "<jc><f2>Heavy Infantry Armor:\n";
$WeapBuyMSG[TigerArmor]   = "<jc><f2>Titan Armor:\n";
$WeapBuyMSG[PsychoArmor]  = "<jc><f2>Psycho Armor:\n";

//Packs:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[DeployableAmmoPack] 	= "<f2>PACK: Resupply Station, ";
$WeapBuyMSG[DeployableInvPack]		= "<f2>PACK: Inventory Station, ";
$WeapBuyMSG[DeployableSensorJammerPack] = "<f2>PACK: Sensor Jammer, ";
$WeapBuyMSG[PulseSensorPack]		= "<f2>PACK: Pulse Sensor, ";
$WeapBuyMSG[MotionSensorPack]		= "<f2>PACK: Motion Sensor, ";
$WeapBuyMSG[LaserPack]			= "<f2>PACK: Long-Rng Laser Turret, ";
$WeapBuyMSG[Laser2Pack]			= "<f2>PACK: Short-Rng Laser Turret, ";
$WeapBuyMSG[DTurretPack]		= "<f2>PACK: Disc Turret, ";
$WeapBuyMSG[CTurretPack]		= "<f2>PACK: Chain Turret, ";
$WeapBuyMSG[TurretPack]			= "<f2>PACK: Turret, ";
$WeapBuyMSG[CameraPack]			= "<f2>PACK: Camera, ";
$WeapBuyMSG[WingBuddyPack]		= "<f2>PACK: Turret-Buddy Turret, ";
$WeapBuyMSG[DEPack]			= "<f2>PACK: Decoy Laser, ";
$WeapBuyMSG[VehPack]			= "<f2>PACK: Vehicle Station, ";
$WeapBuyMSG[PadPack]			= "<f2>PACK: Vehicle Pad, ";
$WeapBuyMSG[PerInv]			= "<f2>PACK: Personal Inventory, ";
$WeapBuyMSG[SolarPack]			= "<f2>PACK: Solar Generator, ";
$WeapBuyMSG[ControlPack]		= "<f2>PACK: Remote Vehicle, ";
$WeapBuyMSG[GunBuddyPack]		= "<f2>PACK: Gun Buddy Decoy, ";
$WeapBuyMSG[AAMinePack]			= "<f2>PACK: AA Mine Silo, ";
$WeapBuyMSG[ForceFloorPack]		= "<f2>PACK: Plasma Deck Floor, ";
$WeapBuyMSG[ForceFieldPack]		= "<f2>PACK: ForceField, ";
$WeapBuyMSG[BlastWallPack]		= "<f2>PACK: BlastWall, ";
$WeapBuyMSG[BunkerPack]			= "<f2>PACK: Bunker, ";
$WeapBuyMSG[M350Pack]			= "<f2>PACK: M-350 Explosives Pack, ";
$WeapBuyMSG[SuicidePack]		= "<f2>PACK: Suicide Pack, ";
$WeapBuyMSG[FTPack]			= "<f2>PACK: Fuel Pack, ";
$WeapBuyMSG[FreezePack]			= "<f2>PACK: Liquid Nitrogen Pack, ";
$WeapBuyMSG[AGPack]			= "<f2>PACK: Acid Containment Pack, ";
$WeapBuyMSG[TGPack]			= "<f2>PACK: Booster Pack, ";
$WeapBuyMSG[PTPack]			= "<f2>PACK: Pilot Pack, ";
$WeapBuyMSG[RepairPack]			= "<f2>PACK: Medic Pack, ";
$WeapBuyMSG[ShieldPack]			= "<f2>PACK: Flight Pack, ";
$WeapBuyMSG[CSDPack]			= "<f2>PACK: Weapon Enhancement Pack, ";
$WeapBuyMSG[CDPack]			= "<f2>PACK: Cloaking Device, ";
$WeapBuyMSG[PCDPack]			= "<f2>PACK: Distraction Pack, ";
$WeapBuyMSG[TLPack]			= "<f2>PACK: Laser Site, ";
$WeapBuyMSG[AmmoPack]			= "<f2>PACK: Ammo Pack, ";

//Items:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[MineAmmo]  = "<f2>Mines, ";
$WeapBuyMSG[Grenade]   = "<f2>Grenades, ";
$WeapBuyMSG[RepairKit] = "<f2>Repair Kit, ";
$WeapBuyMSG[Beacon]    = "<f2>Beacons, ";
$WeapBuyMSG[Antidote]  = "<f2>Viral Antidote, ";

//Weapon:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[EL]		     = "<f2>Nuclear Fission Emitter, ";
$WeapBuyMSG[LP]		     = "<f2>Laser Pistol, ";
$WeapBuyMSG[RL]		     = "<f2>Rocket Launcher, ";
$WeapBuyMSG[MG]		     = "<f2>Minigun, ";
$WeapBuyMSG[FP]		     = "<f2>Plasma Pistol, ";
$WeapBuyMSG[PC]		     = "<f2>Hellfire Cannon, ";
$WeapBuyMSG[SP]		     = "<f2>Silenced Pistol, ";
$WeapBuyMSG[BH]		     = "<f2>Disruptor Cannon, ";
$WeapBuyMSG[Blaster]	     = "<f2>Adv. blaster, ";
$WeapBuyMSG[Shotgun1]	     = "<f2>Adv. Shotgun, ";
$WeapBuyMSG[DiscLauncher]    = "<f2>Adv. Disc launcher, ";
$WeapBuyMSG[GrenadeLauncher] = "<f2>Adv. Grenade Launcher, ";
$WeapBuyMSG[AR]		     = "<f2>Assault Rifle, ";
$WeapBuyMSG[SR]		     = "<f2>Sniper Rifle, ";
$WeapBuyMSG[Sword]	     = "<f2>Flame Sword, ";
$WeapBuyMSG[PAttack]	     = "<f2>!Rage�, ";
$WeapBuyMSG[Mortar]	     = "<f2>Mortar, ";
$WeapBuyMSG[FreezeGun]	     = "<f2>Freeze Gun, ";
$WeapBuyMSG[Flamethrower]    = "<f2>FlameThrower, ";
$WeapBuyMSG[AG]		     = "<f2>Acid Gun, ";
$WeapBuyMSG[Funk]	     = "<f2>Party Gun, ";
$WeapBuyMSG[EnergyRifle]     = "<f2>Confetti Launcher, ";
$WeapBuyMSG[Multi]	     = "<f2>Multi-Rocket, ";
$WeapBuyMSG[Beam]	     = "<f2>Beam Cannon, ";
$WeapBuyMSG[Shock]	     = "<f2>Shockwave Rifle, ";
$WeapBuyMSG[SmokeLauncher]   = "<f2>Smoke Launcher, ";
$WeapBuyMSG[PGL]	     = "<f2>Proton Grenade Launcher, ";
$WeapBuyMSG[R]		     = "<f2>Raptor, ";
$WeapBuyMSG[V]		     = "<f2>Viral Uploader, ";
$WeapBuyMSG[Syn]	     = "<f2>Syndicate, ";
$WeapBuyMSG[Tazer]	     = "<f2>Tazer, ";
$WeapBuyMSG[GR]		     = "<f2>RPG Rifle, ";
$WeapBuyMSG[HG]		     = "<f2>Hostage Gun, ";
$WeapBuyMSG[KEG]	     = "<f2>Keg, ";

//Clips:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[PistolClip]			= "<f2>Pistol Clips, ";
$WeapBuyMSG[SniperClip]			= "<f2>Sniper Rifle Clips, ";
$WeapBuyMSG[AssaultClip]		= "<f2>Assault Rifle Clips, ";
$WeapBuyMSG[ShotgunClip]		= "<f2>Shotgun Clips, ";

//Ammo:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[RLAmmo]			= "<f2>Rocket Shells, ";
$WeapBuyMSG[MGAmmo]			= "<f2>Minigun Rounds, ";
$WeapBuyMSG[FPAmmo]			= "<f2>Plasma Pistol Ammo, ";
$WeapBuyMSG[SPAmmo]			= "<f2>Pistol Rounds, ";
$WeapBuyMSG[Shotgun1Ammo]		= "<f2>Shotgun Shells, ";
$WeapBuyMSG[ARAmmo]			= "<f2>Assault Rifle Rounds, ";
$WeapBuyMSG[SRAmmo]			= "<f2>Sniper Rifle Rounds, ";
$WeapBuyMSG[DiscAmmo]			= "<f2>Adv. Disc Ammo, ";
$WeapBuyMSG[GrenadeLauncherAmmo]	= "<f2>Adv. Grenade Shells, ";
$WeapBuyMSG[MortarAmmo]			= "<f2>Mortar Shells, ";
$WeapBuyMSG[MultiAmmo]			= "<f2>Multi-Rocket Shells, ";
$WeapBuyMSG[SmokeAmmo]                  = "<f2>Smoke Rounds, ";
$WeapBuyMSG[PGLAmmo]			= "<f2>Proton Grenade Shells, ";
$WeapBuyMSG[RAmmo]			= "<f2>Raptor Shells, ";
$WeapBuyMSG[SynAmmo]			= "<f2>Syndicate Ammo, ";
$WeapBuyMSG[GRAmmo]			= "<f2>RPG Shells, ";
$WeapBuyMSG[HGAmmo]			= "<f2>Hostage Gun Ammo, ";
$WeapBuyMSG[FAmmo]			= "<f2>Flare Shells, ";

//Tools::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
$WeapBuyMSG[THPack]	    = "<f2>MTG, ";
$WeapBuyMSG[F]		    = "<f2>Flare Gun, ";
$WeapBuyMSG[FL]		    = "<f2>Flashlight, ";
$WeapBuyMSG[TB]		    = "<f2>ToolBox, ";
$WeapBuyMSG[TargetingLaser] = "<f2>Targeting Laser, ";

