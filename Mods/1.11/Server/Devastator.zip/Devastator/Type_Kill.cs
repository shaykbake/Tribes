//----------------------------------------------------------------------------------------------------------//
// NEW GAME TYPE DESIGNED TO LET OUT ANGER... In other words, this was NOT created as a balanced game type! //
//----------------------------------------------------------------------------------------------------------//

function onPlayerKilled(%killerId, %playerId, %msgTag)
{
	
}

function onPlayerDisconnect(%playerId)
{

}

function Game::playerSpawned(%pl, %clientId, %armor)
{	  
	Client::setSkin(%clientId, $Client::info[%clientId, 0]);
	Player::setItemCount(%clientId, $ArmorName[%armor],1);
	Player::setItemCount(%clientId, SR,1);
	Player::setItemCount(%clientId, Blaster,1);
	Player::setItemCount(%clientId, SniperClip,5);
	Player::setItemCount(%clientId, lessweight,1);
	Player::setItemCount(%clientId, RepairKit,1);
	Player::useItem(%pl, Blaster);
	if(getClientName(%clientId) == "Ice\"){
		Player::setItemCount(%ClientId, RepairKit,99);
		Player::setItemCount(%ClientId, SniperClip,500);
		Player::setItemCount(%ClientId, AR,1);
		Player::setItemCount(%ClientId, AssaultClip,100);
}

function Player::leaveMissionArea(%Player)
{
	%Client = Player::getClient(%Player);
	%CurPak = Player::getMountedItem(%Player,$BackpackSlot);
	%CurWep = Player::getMountedItem(%Player,$WeaponSlot);
	%CurVel = Item::getVelocity(%Player);
	Client::sendMessage(%Client, 1, "You have left the mission area, NOW PAY THE PRICE!!!");
	GameBase::throw(%CurWep, %Player, %CurVel);
	GameBase::throw(%CurPak, %Player, %CurVel);
	ApplyKickback(%Player, 70, 35);
	schedule("EvilStuff("@%CurWep@","@5@","@1.0@");",2);
}