//-------------------------------------------------------------------//
//-Ice's Bleed Code, please, do not distribute without my permission-//
//-------------------------------------------------------------------//

//-Your gonna wanna put in an ignition switch for this function so add this one before it
//-An ignition switch allows you to start the function all in one nifty little line =)

function StartBleed(%this,%object,%rate) //- I suggest you set the rate at 200, read below to see why
{
	$bleedrate[Player::getClient(%this)] = %rate;
	Client::sendMessage(%player,0, "Your Bleeding!" ) ;
	Player::Bleed(%this,%object);
}

//-Takes off 1 every 0.2 sec..... 80 secs kills... then... 400 calls to kill... 200 for half health dmg

//-New Function - Applies 0.0125 (1/80) Dmg every second, 80 secs to die from full health
function Player::Bleed(%this,%object)
{
	%player = Player::getClient(%this);
	%killer = Player::getClient(%object);
	if(!Player::isAtRest(%this) && $bleedrate[%player] > 0)
		$bleedrate[%player]++; //- If crouching and moving then down one, if running down none
	if(Player::isCrouching(%this))
		$bleedrate[%player]--; //- If crouching and not running then down two
	if($bleedrate[%player] > 0 ) {
		%dlevel = GameBase::getDamageLevel(%this) + (0.0025 / Player::getArmor(%this).maxDamage); //- 1/400
		GameBase::setDamageLevel(%this,%dlevel);
		%flash = Player::getDamageFlash(%this) + $bleedrate[%player] * 2;
		if(%flash > 0.75)
			%flash = 0.75;
		Player::setDamageFlash(%this,%flash);
		$bleedrate[%player]--; //- Take away standard measurement of one, if running then cancels out
		if(GameBase::getDamageLevel(%this)+%value < Player::getArmor(%this).maxDamage) {       	
			if($bleedrate[%player] > 0)
				schedule("Player::bleed("@%this@","@%object@");",0.2,%this);
		}
		else
//			-Insert your BloodLoss death Msg type here, right over---------->Here\/-------------\/
			playNextAnim(%this);
			Client::onKilled(%player,%killer,$BloodLossDamage);
			Player::kill(%this);
			return;
	}
	else {
		Client::sendMessage(%player,0, "You stopped Bleeding!" ) ;
		$bleedrate[%player] = 0;
	}
}