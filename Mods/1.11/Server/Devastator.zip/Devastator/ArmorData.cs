//----------------------------------//
// ARMOR THROW STRENGTH CODE BY ICE //
//----------------------------------//

//- 1.0 is normal strength and the default strength
$ThrowStrength[larmor] = 1.0;
$ThrowStrength[qarmor] = 1.0;
$ThrowStrength[srarmor] = 1.0;
$ThrowStrength[sarmor] = 1.0;
$ThrowStrength[marmor] = 1.0;
$ThrowStrength[parmor] = 1.0;
$ThrowStrength[harmor] = 1.0;
$ThrowStrength[tarmor] = 1.0;
$ThrowStrength[psarmor] = 1.5;
$ThrowStrength[psfemale] = 1.5;
$ThrowStrength[lfemale] = 1.0;
$ThrowStrength[qfemale] = 1.0;
$ThrowStrength[srfemale] = 1.0;
$ThrowStrength[sfemale] = 1.0;
$ThrowStrength[mfemale] = 1.0;
$ThrowStrength[pfemale] = 1.0;

//-----------------------------//
// DAMAGE SCALE FOR ALL ARMORS //
//-----------------------------//

$DamageScale[All, $StingerADamageType] = 1.2;
$DamageScale[All, $StingerBDamageType] = 1.2;
$DamageScale[All, $MGBurnDamageType] = 1.0;

//----------------------------------------------------------------------------
// Light Armor
//----------------------------------------------------------------------------

$DamageScale[larmor, $LandingDamageType] = 1.0;
$DamageScale[larmor, $ImpactDamageType] = 1.0;
$DamageScale[larmor, $CrushDamageType] = 1.0;
$DamageScale[larmor, $BulletDamageType] = 1.2;
$DamageScale[larmor, $PlasmaDamageType] = 1.0;
$DamageScale[larmor, $EnergyDamageType] = 1.3;
$DamageScale[larmor, $MissileDamageType] = 1.0;
$DamageScale[larmor, $DebrisDamageType] = 1.2;
$DamageScale[larmor, $ShrapnelDamageType] = 1.2;
$DamageScale[larmor, $LaserDamageType] = 1.0;
$DamageScale[larmor, $MortarDamageType] = 1.3;
$DamageScale[larmor, $ElectricityDamageType] = 1.0;
$DamageScale[larmor, $MineDamageType] = 1.2;
$DamageScale[larmor, $SBulletDamageType] = 1.0;
$DamageScale[larmor, $PBulletDamageType] = 1.0;
$DamageScale[larmor, $FreezeDamageType] = 1.0;
$DamageScale[larmor, $FlashDamageType] = 1.0; 
$DamageScale[larmor, $MiniDamageType] = 1.0;
$DamageScale[larmor, $FunkDamageType] = 1.0;
$DamageScale[larmor, $ConfettiDamageType] = 1.0;
$DamageScale[larmor, $SniperDamageType] = 0.5;
$DamageScale[qarmor, $SniperDamageType] = 0.5;
$DamageScale[srarmor, $SniperDamageType] = 1.0;
$DamageScale[sarmor, $SniperDamageType] = 0.7;
$DamageScale[marmor, $SniperDamageType] = 0.7;
$DamageScale[parmor, $SniperDamageType] = 0.7;
$DamageScale[harmor, $SniperDamageType] = 0.7;
$DamageScale[tarmor, $SniperDamageType] = 0.7;
$DamageScale[lfemale, $SniperDamageType] = 0.7;
$DamageScale[qfemale, $SniperDamageType] = 0.7;
$DamageScale[srfemale, $SniperDamageType] = 1.0;
$DamageScale[sfemale, $SniperDamageType] = 0.7;
$DamageScale[mfemale, $SniperDamageType] = 0.7;
$DamageScale[pfemale, $SniperDamageType] = 0.7;

$ItemMax[larmor, Blaster] = 1;
$ItemMax[larmor, Funk] = 0;
$ItemMax[larmor, FreezeGun] = 0;
$ItemMax[larmor, Disclauncher] = 0;
$ItemMax[larmor, GrenadeLauncher] = 0;
$ItemMax[larmor, Mortar] = 0;
$ItemMax[larmor, Flamethrower] = 0;
$ItemMax[larmor, EnergyRifle] = 0;
$ItemMax[larmor, TargetingLaser] = 1;
$ItemMax[larmor, MineAmmo] = 3;
$ItemMax[larmor, Grenade] = 5;
$ItemMax[larmor, Beacon]  = 3;
$ItemMax[larmor, LP]  = 1;
$ItemMax[larmor, RL]  = 0;
$ItemMax[larmor, MG]  = 0;
$ItemMax[larmor, FL]  = 1;
$ItemMax[larmor, FP]  = 0;
$ItemMax[larmor, PC]  = 0;
$ItemMax[larmor, SP]  = 0;
$ItemMax[larmor, BH]  = 0;
$ItemMax[larmor, Shotgun1] = 0;
$ItemMax[larmor, AR] = 0;
$ItemMax[larmor, SR] = 0;
$ItemMax[larmor, TB] = 1;
$ItemMax[larmor, F] = 1;
$ItemMax[larmor, EL] = 0;
$ItemMax[larmor, AG] = 0;

$ItemMax[larmor, DiscAmmo] = 15;
$ItemMax[larmor, GrenadeAmmo] = 10;
$ItemMax[larmor, MortarAmmo] = 10;
$ItemMax[larmor, RLAmmo] = 10;
$ItemMax[larmor, MGAmmo] = 500;
$ItemMax[larmor, SPAmmo] = 9;
$ItemMax[larmor, Shotgun1Ammo] = 2;
$ItemMax[larmor, ARAmmo] = 30;
$ItemMax[larmor, SRAmmo] = 5;
$ItemMax[larmor, FAmmo] = 10;
$ItemMax[larmor, ELAmmo] = 1;

$ItemMax[larmor, SolarPack] = 0;
$ItemMax[larmor, FreezePack] = 0;
$ItemMax[larmor, PadPack] = 0;
$ItemMax[larmor, VehPack] = 0;
$ItemMax[larmor, RepairPack] = 1;
$ItemMax[larmor, ShieldPack] = 0;
$ItemMax[larmor, SensorJammerPack] = 1;
$ItemMax[larmor, MotionSensorPack] = 1;
$ItemMax[larmor, PulseSensorPack] = 1;
$ItemMax[larmor, DeployableSensorJammerPack] = 1;
$ItemMax[larmor, CameraPack] = 1;
$ItemMax[larmor, TurretPack] = 0;
$ItemMax[larmor, AmmoPack] = 1;
$ItemMax[larmor, RepairKit] = 1;
$ItemMax[larmor, DeployableInvPack] = 0;
$ItemMax[larmor, DeployableAmmoPack] = 0;
$ItemMax[larmor, LaserPack] = 0;
$ItemMax[larmor, Laser2Pack] = 0;
$ItemMax[larmor, CDPack] = 1;
$ItemMax[larmor, CSDPack] = 0;
$ItemMax[larmor, TLPack] = 0;
$ItemMax[larmor, PCDPack] = 1;
$ItemMax[larmor, DTurretPack] = 0;
$ItemMax[larmor, DEPack] = 0;
$ItemMax[larmor, ForceFieldPack] = 0;
$ItemMax[larmor, CTurretPack] = 0;
$ItemMax[larmor, FTPack] = 0;
$ItemMax[larmor, TGPack] = 0;
$ItemMax[larmor, M350Pack] = 0;
$ItemMax[larmor, PTPack] = 1;

$MaxWeapons[larmor] = 3;

//----------------------------------------------------------------------------
// Pan. Armor
//----------------------------------------------------------------------------

$DamageScale[qarmor, $LandingDamageType] = 1.0;
$DamageScale[qarmor, $ImpactDamageType] = 1.0;
$DamageScale[qarmor, $CrushDamageType] = 1.0;
$DamageScale[qarmor, $BulletDamageType] = 1.2;
$DamageScale[qarmor, $PlasmaDamageType] = 1.0;
$DamageScale[qarmor, $EnergyDamageType] = 1.3;
$DamageScale[qarmor, $MissileDamageType] = 1.0;
$DamageScale[qarmor, $DebrisDamageType] = 1.2;
$DamageScale[qarmor, $ShrapnelDamageType] = 1.2;
$DamageScale[qarmor, $LaserDamageType] = 1.0;
$DamageScale[qarmor, $MortarDamageType] = 1.3;
$DamageScale[qarmor, $ElectricityDamageType] = 1.0;
$DamageScale[qarmor, $MineDamageType] = 1.2;
$DamageScale[qarmor, $SBulletDamageType] = 1.0;
$DamageScale[qarmor, $PBulletDamageType] = 1.2;
$DamageScale[qarmor, $FreezeDamageType] = 1.0;  
$DamageScale[qarmor, $FlashDamageType] = 1.0; 
$DamageScale[qarmor, $MiniDamageType] = 1.0;         
$DamageScale[qarmor, $FunkDamageType] = 1.0;
$DamageScale[qarmor, $ConfettiDamageType] = 1.0;         

$ItemMax[qarmor, Blaster] = 1;
$ItemMax[qarmor, Funk] = 1;
$ItemMax[qarmor, FreezeGun] = 0;
$ItemMax[qarmor, Disclauncher] = 1;
$ItemMax[qarmor, GrenadeLauncher] = 1;
$ItemMax[qarmor, Mortar] = 0;
$ItemMax[qarmor, Flamethrower] = 0;
$ItemMax[qarmor, EnergyRifle] = 1;
$ItemMax[qarmor, TargetingLaser] = 1;
$ItemMax[qarmor, MineAmmo] = 3;
$ItemMax[qarmor, Grenade] = 5;
$ItemMax[qarmor, Beacon]  = 3;
$ItemMax[qarmor, LP]  = 1;
$ItemMax[qarmor, RL]  = 0;
$ItemMax[qarmor, MG]  = 0;
$ItemMax[qarmor, FL]  = 1;
$ItemMax[qarmor, FP]  = 0;
$ItemMax[qarmor, PC]  = 0;
$ItemMax[qarmor, SP]  = 0;
$ItemMax[qarmor, BH]  = 0;
$ItemMax[qarmor, Shotgun1] = 0;
$ItemMax[qarmor, AR] = 0;
$ItemMax[qarmor, SR] = 0;
$ItemMax[qarmor, TB] = 0;
$ItemMax[qarmor, F] = 1;
$ItemMax[qarmor, EL] = 0;
$ItemMax[qarmor, AG] = 0;

$ItemMax[qarmor, DiscAmmo] = 15;
$ItemMax[qarmor, GrenadeAmmo] = 10;
$ItemMax[qarmor, MortarAmmo] = 10;
$ItemMax[qarmor, RLAmmo] = 10;
$ItemMax[qarmor, MGAmmo] = 500;
$ItemMax[qarmor, SPAmmo] = 9;
$ItemMax[qarmor, Shotgun1Ammo] = 2;
$ItemMax[qarmor, ARAmmo] = 30;
$ItemMax[qarmor, SRAmmo] = 5;
$ItemMax[qarmor, FAmmo] = 10;
$ItemMax[qarmor, ELAmmo] = 1;

$ItemMax[qarmor, RepairPack] = 1;
$ItemMax[qarmor, SolarPack] = 0;
$ItemMax[qarmor, FreezePack] = 0;
$ItemMax[qarmor, PadPack] = 0;
$ItemMax[qarmor, VehPack] = 0;
$ItemMax[qarmor, ShieldPack] = 1;
$ItemMax[qarmor, SensorJammerPack] = 1;
$ItemMax[qarmor, MotionSensorPack] = 1;
$ItemMax[qarmor, PulseSensorPack] = 1;
$ItemMax[qarmor, DeployableSensorJammerPack] = 1;
$ItemMax[qarmor, CameraPack] = 1;
$ItemMax[qarmor, TurretPack] = 0;
$ItemMax[qarmor, AmmoPack] = 1;
$ItemMax[qarmor, RepairKit] = 1;
$ItemMax[qarmor, DeployableInvPack] = 0;
$ItemMax[qarmor, DeployableAmmoPack] = 0;
$ItemMax[qarmor, LaserPack] = 0;
$ItemMax[qarmor, Laser2Pack] = 0;
$ItemMax[qarmor, CDPack] = 1;
$ItemMax[qarmor, CSDPack] = 0;
$ItemMax[qarmor, TLPack] = 0;
$ItemMax[qarmor, PCDPack] = 1;
$ItemMax[qarmor, DTurretPack] = 0;
$ItemMax[qarmor, DEPack] = 0;
$ItemMax[qarmor, ForceFieldPack] = 0;
$ItemMax[qarmor, BlastWallPack] = 0;
$ItemMax[qarmor, CTurretPack] = 0;
$ItemMax[qarmor, FTPack] = 0;
$ItemMax[qarmor, TGPack] = 0;
$ItemMax[qarmor, M350Pack] = 0;
$ItemMax[qarmor, PTPack] = 0;

$MaxWeapons[qarmor] = 3;

//----------------------------------------------------------------------------
// Sniper Armor
//----------------------------------------------------------------------------

$DamageScale[srarmor, $LandingDamageType] = 1.0;
$DamageScale[srarmor, $ImpactDamageType] = 1.0;
$DamageScale[srarmor, $CrushDamageType] = 1.0;
$DamageScale[srarmor, $BulletDamageType] = 1.2;
$DamageScale[srarmor, $PlasmaDamageType] = 1.0;
$DamageScale[srarmor, $EnergyDamageType] = 1.3;
$DamageScale[srarmor, $MissileDamageType] = 1.0;
$DamageScale[srarmor, $DebrisDamageType] = 1.2;
$DamageScale[srarmor, $ShrapnelDamageType] = 1.2;
$DamageScale[srarmor, $LaserDamageType] = 1.0;
$DamageScale[srarmor, $MortarDamageType] = 1.3;
$DamageScale[srarmor, $ElectricityDamageType] = 1.0;
$DamageScale[srarmor, $MineDamageType] = 1.2;
$DamageScale[srarmor, $SBulletDamageType] = 1.0;
$DamageScale[srarmor, $PBulletDamageType] = 1.0;
$DamageScale[srarmor, $FreezeDamageType] = 1.0; 
$DamageScale[srarmor, $FlashDamageType] = 1.0; 
$DamageScale[srarmor, $MiniDamageType] = 1.0;
$DamageScale[srarmor, $FunkDamageType] = 1.0;
$DamageScale[srarmor, $ConfettiDamageType] = 1.0;

$ItemMax[srarmor, Blaster] = 0;
$ItemMax[srarmor, Funk] = 0;
$ItemMax[srarmor, FreezeGun] = 0;
$ItemMax[srarmor, Disclauncher] = 1;
$ItemMax[srarmor, GrenadeLauncher] = 0;
$ItemMax[srarmor, Mortar] = 0;
$ItemMax[srarmor, Flamethrower] = 0;
$ItemMax[srarmor, EnergyRifle] = 0;
$ItemMax[srarmor, TargetingLaser] = 1;
$ItemMax[srarmor, MineAmmo] = 3;
$ItemMax[srarmor, Grenade] = 5;
$ItemMax[srarmor, Beacon]  = 3;
$ItemMax[srarmor, LP]  = 1;
$ItemMax[srarmor, RL]  = 0;
$ItemMax[srarmor, MG]  = 0;
$ItemMax[srarmor, FL]  = 1;
$ItemMax[srarmor, FP]  = 0;
$ItemMax[srarmor, PC]  = 0;
$ItemMax[srarmor, SP]  = 1;
$ItemMax[srarmor, BH]  = 0;
$ItemMax[srarmor, Shotgun1] = 0;
$ItemMax[srarmor, AR] = 0;
$ItemMax[srarmor, SR] = 1;
$ItemMax[srarmor, TB] = 0;
$ItemMax[srarmor, F] = 1;
$ItemMax[srarmor, EL] = 0;
$ItemMax[srarmor, AG] = 1;

$ItemMax[srarmor, DiscAmmo] = 15;
$ItemMax[srarmor, GrenadeAmmo] = 10;
$ItemMax[srarmor, MortarAmmo] = 10;
$ItemMax[srarmor, RLAmmo] = 10;
$ItemMax[srarmor, MGAmmo] = 500;
$ItemMax[srarmor, SPAmmo] = 9;
$ItemMax[srarmor, Shotgun1Ammo] = 2;
$ItemMax[srarmor, ARAmmo] = 30;
$ItemMax[srarmor, SRAmmo] = 5;
$ItemMax[srarmor, FAmmo] = 10;
$ItemMax[srarmor, ELAmmo] = 1;

$ItemMax[srarmor, RepairPack] = 1;
$ItemMax[srarmor, SolarPack] = 0;
$ItemMax[srarmor, FreezePack] = 0;
$ItemMax[srarmor, PadPack] = 0;
$ItemMax[srarmor, VehPack] = 0;
$ItemMax[srarmor, ShieldPack] = 0;
$ItemMax[srarmor, SensorJammerPack] = 1;
$ItemMax[srarmor, MotionSensorPack] = 1;
$ItemMax[srarmor, PulseSensorPack] = 1;
$ItemMax[srarmor, DeployableSensorJammerPack] = 1;
$ItemMax[srarmor, CameraPack] = 1;
$ItemMax[srarmor, TurretPack] = 0;
$ItemMax[srarmor, AmmoPack] = 1;
$ItemMax[srarmor, RepairKit] = 1;
$ItemMax[srarmor, DeployableInvPack] = 0;
$ItemMax[srarmor, DeployableAmmoPack] = 0;
$ItemMax[srarmor, LaserPack] = 0;
$ItemMax[srarmor, Laser2Pack] = 0;
$ItemMax[srarmor, CDPack] = 1;
$ItemMax[srarmor, CSDPack] = 0;
$ItemMax[srarmor, TLPack] = 1;
$ItemMax[srarmor, PCDPack] = 1;
$ItemMax[srarmor, DTurretPack] = 0;
$ItemMax[srarmor, DEPack] = 1;
$ItemMax[srarmor, ForceFieldPack] = 0;
$ItemMax[srarmor, BlastWallPack] = 0;
$ItemMax[srarmor, CTurretPack] = 0;
$ItemMax[srarmor, FTPack] = 0;
$ItemMax[srarmor, TGPack] = 0;
$ItemMax[srarmor, M350Pack] = 0;
$ItemMax[srarmor, PTPack] = 0;

$MaxWeapons[srarmor] = 3;

//----------------------------------------------------------------------------
// Specialist Armor
//----------------------------------------------------------------------------

$DamageScale[sarmor, $LandingDamageType] = 1.0;
$DamageScale[sarmor, $ImpactDamageType] = 1.0;
$DamageScale[sarmor, $CrushDamageType] = 1.0;
$DamageScale[sarmor, $BulletDamageType] = 1.2;
$DamageScale[sarmor, $PlasmaDamageType] = 1.0;
$DamageScale[sarmor, $EnergyDamageType] = 1.3;
$DamageScale[sarmor, $MissileDamageType] = 1.0;
$DamageScale[sarmor, $DebrisDamageType] = 1.2;
$DamageScale[sarmor, $ShrapnelDamageType] = 1.2;
$DamageScale[sarmor, $LaserDamageType] = 1.0;
$DamageScale[sarmor, $MortarDamageType] = 1.3;
$DamageScale[sarmor, $ElectricityDamageType] = 1.0;
$DamageScale[sarmor, $MineDamageType] = 1.2;
$DamageScale[sarmor, $SBulletDamageType] = 1.0;
$DamageScale[sarmor, $PBulletDamageType] = 1.0;
$DamageScale[sarmor, $FreezeDamageType] = 1.0;
$DamageScale[sarmor, $FlashDamageType] = 1.0; 
$DamageScale[sarmor, $MiniDamageType] = 1.0;           
$DamageScale[sarmor, $FunkDamageType] = 1.0; 
$DamageScale[sarmor, $ConfettiDamageType] = 1.0;          

$ItemMax[sarmor, Blaster] = 0;
$ItemMax[sarmor, Funk] = 0;
$ItemMax[sarmor, FreezeGun] = 0;
$ItemMax[sarmor, Disclauncher] = 1;
$ItemMax[sarmor, GrenadeLauncher] = 1;
$ItemMax[sarmor, Mortar] = 0;
$ItemMax[sarmor, Flamethrower] = 0;
$ItemMax[sarmor, EnergyRifle] = 0;
$ItemMax[sarmor, TargetingLaser] = 1;
$ItemMax[sarmor, MineAmmo] = 3;
$ItemMax[sarmor, Grenade] = 5;
$ItemMax[sarmor, Beacon]  = 3;
$ItemMax[sarmor, LP]  = 1;
$ItemMax[sarmor, RL]  = 0;
$ItemMax[sarmor, MG]  = 0;
$ItemMax[sarmor, FL]  = 1;
$ItemMax[sarmor, FP]  = 0;
$ItemMax[sarmor, PC]  = 0;
$ItemMax[sarmor, SP]  = 1;
$ItemMax[sarmor, BH]  = 0;
$ItemMax[sarmor, Shotgun1] = 0;
$ItemMax[sarmor, AR] = 1;
$ItemMax[sarmor, SR] = 0;
$ItemMax[sarmor, TB] = 0;
$ItemMax[sarmor, F] = 1;
$ItemMax[sarmor, EL] = 0;
$ItemMax[sarmor, AG] = 0;

$ItemMax[sarmor, DiscAmmo] = 15;
$ItemMax[sarmor, GrenadeAmmo] = 10;
$ItemMax[sarmor, MortarAmmo] = 10;
$ItemMax[sarmor, RLAmmo] = 10;
$ItemMax[sarmor, MGAmmo] = 500;
$ItemMax[sarmor, SPAmmo] = 9;
$ItemMax[sarmor, Shotgun1Ammo] = 2;
$ItemMax[sarmor, ARAmmo] = 30;
$ItemMax[sarmor, SRAmmo] = 5;
$ItemMax[sarmor, FAmmo] = 10;
$ItemMax[sarmor, ELAmmo] = 1;

$ItemMax[sarmor, RepairPack] = 1;
$ItemMax[sarmor, ShieldPack] = 0;
$ItemMax[sarmor, SolarPack] = 0;
$ItemMax[sarmor, FreezePack] = 0;
$ItemMax[sarmor, PadPack] = 0;
$ItemMax[sarmor, VehPack] = 0;
$ItemMax[sarmor, SensorJammerPack] = 1;
$ItemMax[sarmor, MotionSensorPack] = 1;
$ItemMax[sarmor, PulseSensorPack] = 1;
$ItemMax[sarmor, DeployableSensorJammerPack] = 1;
$ItemMax[sarmor, CameraPack] = 1;
$ItemMax[sarmor, TurretPack] = 0;
$ItemMax[sarmor, AmmoPack] = 1;
$ItemMax[sarmor, RepairKit] = 1;
$ItemMax[sarmor, DeployableInvPack] = 0;
$ItemMax[sarmor, DeployableAmmoPack] = 0;
$ItemMax[sarmor, LaserPack] = 0;
$ItemMax[sarmor, Laser2Pack] = 0;
$ItemMax[sarmor, CDPack] = 1;
$ItemMax[sarmor, CSDPack] = 1;
$ItemMax[sarmor, TLPack] = 0;
$ItemMax[sarmor, PCDPack] = 1;
$ItemMax[sarmor, DTurretPack] = 0;
$ItemMax[sarmor, DEPack] = 0;
$ItemMax[sarmor, ForceFieldPack] = 0;
$ItemMax[sarmor, BlastWallPack] = 0;
$ItemMax[sarmor, CTurretPack] = 0;
$ItemMax[sarmor, FTPack] = 0;
$ItemMax[sarmor, TGPack] = 0;
$ItemMax[sarmor, M350Pack] = 0;
$ItemMax[sarmor, PTPack] = 0;

$MaxWeapons[sarmor] = 3;

//----------------------------------------------------------------------------
// Engineer Armor
//----------------------------------------------------------------------------
$DamageScale[marmor, $LandingDamageType] = 1.0;
$DamageScale[marmor, $ImpactDamageType] = 1.0;
$DamageScale[marmor, $CrushDamageType] = 1.0;
$DamageScale[marmor, $BulletDamageType] = 1.0;
$DamageScale[marmor, $PlasmaDamageType] = 0.6;
$DamageScale[marmor, $EnergyDamageType] = 1.0;
$DamageScale[marmor, $MissileDamageType] = 1.0;
$DamageScale[marmor, $ShrapnelDamageType] = 1.0;
$DamageScale[marmor, $DebrisDamageType] = 1.0;
$DamageScale[marmor, $LaserDamageType] = 1.0;
$DamageScale[marmor, $MortarDamageType] = 1.0;
$DamageScale[marmor, $ElectricityDamageType] = 1.0;
$DamageScale[marmor, $MineDamageType] = 1.0;
$DamageScale[marmor, $SBulletDamageType] = 1.0;
$DamageScale[marmor, $PBulletDamageType] = 1.0;
$DamageScale[marmor, $FreezeDamageType] = 1.0;
$DamageScale[marmor, $FlashDamageType] = 1.0; 
$DamageScale[marmor, $MiniDamageType] = 1.0;           
$DamageScale[marmor, $FunkDamageType] = 1.0;
$DamageScale[marmor, $ConfettiDamageType] = 1.0;           

$ItemMax[marmor, Blaster] = 1;
$ItemMax[marmor, Funk] = 0;
$ItemMax[marmor, FreezeGun] = 0;
$ItemMax[marmor, Disclauncher] = 1;
$ItemMax[marmor, GrenadeLauncher] = 1;
$ItemMax[marmor, Mortar] = 0;
$ItemMax[marmor, Flamethrower] = 0;
$ItemMax[marmor, EnergyRifle] = 0;
$ItemMax[marmor, TargetingLaser] = 1;
$ItemMax[marmor, MineAmmo] = 3;
$ItemMax[marmor, Grenade] = 6;
$ItemMax[marmor, Beacon] = 3;
$ItemMax[marmor, LP] = 1;
$ItemMax[marmor, RL] = 1;
$ItemMax[marmor, MG] = 0;
$ItemMax[marmor, FL] = 1;
$ItemMax[marmor, FP] = 0;
$ItemMax[marmor, PC] = 0;
$ItemMax[marmor, SP] = 0;
$ItemMax[marmor, BH] = 0;
$ItemMax[marmor, Shotgun1] = 1;
$ItemMax[marmor, AR] = 0;
$ItemMax[marmor, SR] = 0;
$ItemMax[marmor, TB] = 1;
$ItemMax[marmor, F] = 1;
$ItemMax[marmor, EL] = 0;
$ItemMax[marmor, AG] = 0;

$ItemMax[marmor, DiscAmmo] = 15;
$ItemMax[marmor, GrenadeAmmo] = 10;
$ItemMax[marmor, MortarAmmo] = 10;
$ItemMax[marmor, RLAmmo] = 10;
$ItemMax[marmor, MGAmmo] = 500;
$ItemMax[marmor, SPAmmo] = 9;
$ItemMax[marmor, Shotgun1Ammo] = 2;
$ItemMax[marmor, ARAmmo] = 30;
$ItemMax[marmor, SRAmmo] = 5;
$ItemMax[marmor, FAmmo] = 10;
$ItemMax[marmor, ELAmmo] = 1;

$ItemMax[marmor, RepairPack] = 1;
$ItemMax[marmor, ShieldPack] = 0;
$ItemMax[marmor, SolarPack] = 1;
$ItemMax[marmor, FreezePack] = 0;
$ItemMax[marmor, PadPack] = 1;
$ItemMax[marmor, VehPack] = 1;
$ItemMax[marmor, SensorJammerPack] = 1;
$ItemMax[marmor, MotionSensorPack] = 1;
$ItemMax[marmor, PulseSensorPack] = 1;
$ItemMax[marmor, DeployableSensorJammerPack] = 1;
$ItemMax[marmor, CameraPack] = 1;
$ItemMax[marmor, TurretPack] = 1;
$ItemMax[marmor, AmmoPack] = 1;
$ItemMax[marmor, RepairKit] = 1;
$ItemMax[marmor, DeployableInvPack] = 1;
$ItemMax[marmor, DeployableAmmoPack] = 1;
$ItemMax[marmor, LaserPack] = 1;
$ItemMax[marmor, Laser2Pack] = 1;
$ItemMax[marmor, CDPack] = 1;
$ItemMax[marmor, CSDPack] = 0;
$ItemMax[marmor, TLPack] = 0;
$ItemMax[marmor, PCDPack] = 1;
$ItemMax[marmor, DTurretPack] = 1;
$ItemMax[marmor, DEPack] = 1;
$ItemMax[marmor, ForceFieldPack] = 1;
$ItemMax[marmor, BlastWallPack] = 1;
$ItemMax[marmor, CTurretPack] = 1;
$ItemMax[marmor, FTPack] = 0;
$ItemMax[marmor, TGPack] = 0;
$ItemMax[marmor, M350Pack] = 0;
$ItemMax[marmor, PTPack] = 0;
$ItemMax[marmor, BunkerPack] = 1;

$MaxWeapons[marmor] = 4;

//----------------------------------------------------------------------------
// Pyro Armor
//----------------------------------------------------------------------------
$DamageScale[parmor, $LandingDamageType] = 1.0;
$DamageScale[parmor, $ImpactDamageType] = 1.0;
$DamageScale[parmor, $CrushDamageType] = 1.0;
$DamageScale[parmor, $BulletDamageType] = 1.0;
$DamageScale[parmor, $PlasmaDamageType] = 0.6;
$DamageScale[parmor, $EnergyDamageType] = 1.0;
$DamageScale[parmor, $MissileDamageType] = 1.0;
$DamageScale[parmor, $ShrapnelDamageType] = 1.0;
$DamageScale[parmor, $DebrisDamageType] = 1.0;
$DamageScale[parmor, $LaserDamageType] = 1.0;
$DamageScale[parmor, $MortarDamageType] = 1.0;
$DamageScale[parmor, $ElectricityDamageType] = 1.0;
$DamageScale[parmor, $MineDamageType] = 1.0;
$DamageScale[parmor, $SBulletDamageType] = 1.0;
$DamageScale[parmor, $PBulletDamageType] = 1.0;
$DamageScale[parmor, $FreezeDamageType] = 1.0;
$DamageScale[parmor, $FlashDamageType] = 1.0; 
$DamageScale[parmor, $MiniDamageType] = 1.0;           
$DamageScale[parmor, $FunkDamageType] = 1.0;
$DamageScale[parmor, $ConfettiDamageType] = 1.0;           

$ItemMax[parmor, Blaster] = 1;
$ItemMax[parmor, Funk] = 0;
$ItemMax[parmor, FreezeGun] = 1;
$ItemMax[parmor, Disclauncher] = 1;
$ItemMax[parmor, GrenadeLauncher] = 1;
$ItemMax[parmor, Mortar] = 0;
$ItemMax[parmor, Flamethrower] = 1;
$ItemMax[parmor, EnergyRifle] = 0;
$ItemMax[parmor, TargetingLaser] = 1;
$ItemMax[parmor, MineAmmo] = 3;
$ItemMax[parmor, Grenade] = 6;
$ItemMax[parmor, Beacon] = 3;
$ItemMax[parmor, LP] = 1;
$ItemMax[parmor, RL] = 0;
$ItemMax[parmor, MG] = 0;
$ItemMax[parmor, FL] = 1;
$ItemMax[parmor, FP] = 1;
$ItemMax[parmor, PC] = 0;
$ItemMax[parmor, SP] = 0;
$ItemMax[parmor, BH] = 0;
$ItemMax[parmor, Shotgun1] = 0;
$ItemMax[parmor, AR] = 0;
$ItemMax[parmor, SR] = 0;
$ItemMax[parmor, TB] = 0;
$ItemMax[parmor, F] = 1;
$ItemMax[parmor, EL] = 0;
$ItemMax[parmor, AG] = 0;

$ItemMax[parmor, DiscAmmo] = 15;
$ItemMax[parmor, GrenadeAmmo] = 10;
$ItemMax[parmor, MortarAmmo] = 10;
$ItemMax[parmor, RLAmmo] = 10;
$ItemMax[parmor, MGAmmo] = 500;
$ItemMax[parmor, SPAmmo] = 9;
$ItemMax[parmor, ARAmmo] = 30;
$ItemMax[parmor, SRAmmo] = 5;
$ItemMax[parmor, FAmmo] = 10;
$ItemMax[parmor, ELAmmo] = 1;

$ItemMax[parmor, RepairPack] = 1;
$ItemMax[parmor, ShieldPack] = 0;
$ItemMax[parmor, SolarPack] = 0;
$ItemMax[parmor, FreezePack] = 1;
$ItemMax[parmor, PadPack] = 0;
$ItemMax[parmor, VehPack] = 0;
$ItemMax[parmor, SensorJammerPack] = 1;
$ItemMax[parmor, MotionSensorPack] = 1;
$ItemMax[parmor, PulseSensorPack] = 1;
$ItemMax[parmor, DeployableSensorJammerPack] = 1;
$ItemMax[parmor, CameraPack] = 1;
$ItemMax[parmor, TurretPack] = 1;
$ItemMax[parmor, AmmoPack] = 1;
$ItemMax[parmor, RepairKit] = 1;
$ItemMax[parmor, DeployableInvPack] = 1;
$ItemMax[parmor, DeployableAmmoPack] = 1;
$ItemMax[parmor, LaserPack] = 1;
$ItemMax[parmor, Laser2Pack] = 1;
$ItemMax[parmor, CDPack] = 1;
$ItemMax[parmor, CSDPack] = 0;
$ItemMax[parmor, TLPack] = 0;
$ItemMax[parmor, PCDPack] = 1;
$ItemMax[parmor, DTurretPack] = 0;
$ItemMax[parmor, DEPack] = 0;
$ItemMax[parmor, ForceFieldPack] = 0;
$ItemMax[parmor, BlastWallPack] = 0;
$ItemMax[parmor, CTurretPack] = 0;
$ItemMax[parmor, FTPack] = 1;
$ItemMax[parmor, TGPack] = 0;
$ItemMax[parmor, M350Pack] = 0;
$ItemMax[parmor, PTPack] = 0;

$MaxWeapons[parmor] = 4;

//----------------------------------------------------------------------------
// Heavy Armor
//----------------------------------------------------------------------------
$DamageScale[harmor, $LandingDamageType] = 1.0;
$DamageScale[harmor, $ImpactDamageType] = 1.0;
$DamageScale[harmor, $CrushDamageType] = 1.0;
$DamageScale[harmor, $BulletDamageType] = 0.6;
$DamageScale[harmor, $PlasmaDamageType] = 0.4;
$DamageScale[harmor, $EnergyDamageType] = 0.7;
$DamageScale[harmor, $MissileDamageType] = 0.6;
$DamageScale[harmor, $DebrisDamageType] = 0.8;
$DamageScale[harmor, $ShrapnelDamageType] = 0.8;
$DamageScale[harmor, $LaserDamageType] = 0.6;
$DamageScale[harmor, $MortarDamageType] = 0.7;
$DamageScale[harmor, $ElectricityDamageType] = 1.0;
$DamageScale[harmor, $MineDamageType] = 0.8;
$DamageScale[harmor, $SBulletDamageType] = 1.0;
$DamageScale[harmor, $PBulletDamageType] = 0.6;
$DamageScale[harmor, $FreezeDamageType] = 1.0;
$DamageScale[harmor, $FlashDamageType] = 1.0; 
$DamageScale[harmor, $MiniDamageType] = 1.0;           
$DamageScale[harmor, $FunkDamageType] = 1.0;
$DamageScale[harmor, $ConfettiDamageType] = 1.0;           

$ItemMax[harmor, Blaster] = 1;
$ItemMax[harmor, Funk] = 0;
$ItemMax[harmor, Disclauncher] = 1;
$ItemMax[harmor, FreezeGun] = 0;
$ItemMax[harmor, GrenadeLauncher] = 1;
$ItemMax[harmor, Mortar] = 1;
$ItemMax[harmor, Flamethrower] = 0;
$ItemMax[harmor, EnergyRifle] = 0;
$ItemMax[harmor, TargetingLaser] = 1;
$ItemMax[harmor, MineAmmo] = 3;
$ItemMax[harmor, Grenade] = 8;
$ItemMax[harmor, Beacon] = 3;
$ItemMax[harmor, LP] = 1;
$ItemMax[harmor, RL] = 1;
$ItemMax[harmor, MG] = 1;
$ItemMax[harmor, FL] = 1;
$ItemMax[harmor, FP] = 0;
$ItemMax[harmor, PC] = 1;
$ItemMax[harmor, SP] = 0;
$ItemMax[harmor, BH] = 0;
$ItemMax[harmor, Shotgun1] = 1;
$ItemMax[harmor, AR] = 1;
$ItemMax[harmor, TB] = 0;
$ItemMax[harmor, SR] = 0;
$ItemMax[harmor, F] = 1;
$ItemMax[harmor, EL] = 1;
$ItemMax[harmor, AG] = 1;

$ItemMax[harmor, DiscAmmo] = 15;
$ItemMax[harmor, GrenadeAmmo] = 15;
$ItemMax[harmor, MortarAmmo] = 10;
$ItemMax[harmor, RLAmmo] = 10;
$ItemMax[harmor, MGAmmo] = 500;
$ItemMax[harmor, SPAmmo] = 9;
$ItemMax[harmor, Shotgun1Ammo] = 2;
$ItemMax[harmor, ARAmmo] = 30;
$ItemMax[harmor, SRAmmo] = 5;
$ItemMax[harmor, FAmmo] = 10;
$ItemMax[harmor, ELAmmo] = 1;

$ItemMax[harmor, RepairPack] = 1;
$ItemMax[harmor, ShieldPack] = 0;
$ItemMax[harmor, SolarPack] = 0;
$ItemMax[harmor, FreezePack] = 0;
$ItemMax[harmor, PadPack] = 0;
$ItemMax[harmor, VehPack] = 0;
$ItemMax[harmor, SensorJammerPack] = 1;
$ItemMax[harmor, MotionSensorPack] = 1;
$ItemMax[harmor, PulseSensorPack] = 1;
$ItemMax[harmor, DeployableSensorJammerPack] = 1;
$ItemMax[harmor, CameraPack] = 1;
$ItemMax[harmor, TurretPack] = 1;
$ItemMax[harmor, AmmoPack] = 1;
$ItemMax[harmor, RepairKit] = 1;
$ItemMax[harmor, DeployableInvPack] = 1;
$ItemMax[harmor, DeployableAmmoPack] = 1;
$ItemMax[harmor, LaserPack] = 0;
$ItemMax[harmor, Laser2Pack] = 0;
$ItemMax[harmor, CDPack] = 1;
$ItemMax[harmor, CSDPack] = 0;
$ItemMax[harmor, TLPack] = 0;
$ItemMax[harmor, PCDPack] = 1;
$ItemMax[harmor, DTurretPack] = 0;
$ItemMax[harmor, DEPack] = 0;
$ItemMax[harmor, ForceFieldPack] = 0;
$ItemMax[harmor, BlastWallPack] = 0;
$ItemMax[harmor, CTurretPack] = 0;
$ItemMax[harmor, FTPack] = 0;
$ItemMax[harmor, TGPack] = 0;
$ItemMax[harmor, M350Pack] = 1;
$ItemMax[harmor, PTPack] = 0;

$MaxWeapons[harmor] = 5;

//----------------------------------------------------------------------------
// Heavy Armor
//---------------------------------------------------------------------------
$DamageScale[tarmor, $LandingDamageType] = 1.0;
$DamageScale[tarmor, $ImpactDamageType] = 1.0;
$DamageScale[tarmor, $CrushDamageType] = 1.0;
$DamageScale[tarmor, $BulletDamageType] = 0.6;
$DamageScale[tarmor, $PlasmaDamageType] = 0.4;
$DamageScale[tarmor, $EnergyDamageType] = 0.7;
$DamageScale[tarmor, $MissileDamageType] = 0.6;
$DamageScale[tarmor, $DebrisDamageType] = 0.8;
$DamageScale[tarmor, $ShrapnelDamageType] = 0.8;
$DamageScale[tarmor, $LaserDamageType] = 0.6;
$DamageScale[tarmor, $MortarDamageType] = 0.7;
$DamageScale[tarmor, $ElectricityDamageType] = 1.0;
$DamageScale[tarmor, $MineDamageType] = 0.8;
$DamageScale[tarmor, $SBulletDamageType] = 1.0;
$DamageScale[tarmor, $PBulletDamageType] = 0.6;
$DamageScale[tarmor, $FreezeDamageType] = 1.0;
$DamageScale[tarmor, $FlashDamageType] = 1.0; 
$DamageScale[tarmor, $MiniDamageType] = 1.0;           
$DamageScale[tarmor, $FunkDamageType] = 1.0;
$DamageScale[tarmor, $ConfettiDamageType] = 1.0;           

$ItemMax[tarmor, Blaster] = 1;
$ItemMax[tarmor, Funk] = 0;
$ItemMax[tarmor, Disclauncher] = 1;
$ItemMax[tarmor, FreezeGun] = 0;
$ItemMax[tarmor, GrenadeLauncher] = 1;
$ItemMax[tarmor, Mortar] = 1;
$ItemMax[tarmor, Flamethrower] = 0;
$ItemMax[tarmor, EnergyRifle] = 0;
$ItemMax[tarmor, TargetingLaser] = 1;
$ItemMax[tarmor, MineAmmo] = 3;
$ItemMax[tarmor, Grenade] = 8;
$ItemMax[tarmor, Beacon] = 3;
$ItemMax[tarmor, LP] = 1;
$ItemMax[tarmor, RL] = 1;
$ItemMax[tarmor, MG] = 1;
$ItemMax[tarmor, FL] = 1;
$ItemMax[tarmor, FP] = 0;
$ItemMax[tarmor, PC] = 1;
$ItemMax[tarmor, SP] = 0;
$ItemMax[tarmor, BH] = 1;
$ItemMax[tarmor, Shotgun1] = 1;
$ItemMax[tarmor, AR] = 0;
$ItemMax[tarmor, TB] = 0;
$ItemMax[tarmor, SR] = 0;
$ItemMax[tarmor, F] = 1;
$ItemMax[tarmor, EL] = 1;
$ItemMax[tarmor, AG] = 0;

$ItemMax[tarmor, DiscAmmo] = 15;
$ItemMax[tarmor, GrenadeAmmo] = 15;
$ItemMax[tarmor, MortarAmmo] = 10;
$ItemMax[tarmor, RLAmmo] = 10;
$ItemMax[tarmor, MGAmmo] = 500;
$ItemMax[tarmor, SPAmmo] = 9;
$ItemMax[tarmor, Shotgun1Ammo] = 2;
$ItemMax[tarmor, ARAmmo] = 30;
$ItemMax[tarmor, SRAmmo] = 5;
$ItemMax[tarmor, FAmmo] = 10;
$ItemMax[tarmor, ELAmmo] = 1;

$ItemMax[tarmor, RepairPack] = 1;
$ItemMax[tarmor, SolarPack] = 0;
$ItemMax[tarmor, FreezePack] = 0;
$ItemMax[tarmor, PadPack] = 0;
$ItemMax[tarmor, VehPack] = 0;
$ItemMax[tarmor, ShieldPack] = 0;
$ItemMax[tarmor, SensorJammerPack] = 1;
$ItemMax[tarmor, MotionSensorPack] = 1;
$ItemMax[tarmor, PulseSensorPack] = 1;
$ItemMax[tarmor, DeployableSensorJammerPack] = 1;
$ItemMax[tarmor, CameraPack] = 1;
$ItemMax[tarmor, TurretPack] = 1;
$ItemMax[tarmor, AmmoPack] = 1;
$ItemMax[tarmor, RepairKit] = 1;
$ItemMax[tarmor, DeployableInvPack] = 1;
$ItemMax[tarmor, DeployableAmmoPack] = 1;
$ItemMax[tarmor, LaserPack] = 0;
$ItemMax[tarmor, Laser2Pack] = 0;
$ItemMax[tarmor, CDPack] = 1;
$ItemMax[tarmor, CSDPack] = 0;
$ItemMax[tarmor, TLPack] = 0;
$ItemMax[tarmor, PCDPack] = 1;
$ItemMax[tarmor, DTurretPack] = 0;
$ItemMax[tarmor, DEPack] = 0;
$ItemMax[tarmor, ForceFieldPack] = 0;
$ItemMax[tarmor, BlastWallPack] = 0;
$ItemMax[tarmor, CTurretPack] = 0;
$ItemMax[tarmor, FTPack] = 0;
$ItemMax[tarmor, TGPack] = 1;
$ItemMax[tarmor, M350Pack] = 0;
$ItemMax[tarmor, PTPack] = 0;

$MaxWeapons[tarmor] = 5;

//----------------------------------------------------------------------------
// light Female Armor
//----------------------------------------------------------------------------
$DamageScale[lfemale, $LandingDamageType] = 1.0;
$DamageScale[lfemale, $ImpactDamageType] = 1.0;	
$DamageScale[lfemale, $CrushDamageType] = 1.0;	
$DamageScale[lfemale, $BulletDamageType] = 1.2;
$DamageScale[lfemale, $PlasmaDamageType] = 1.0;
$DamageScale[lfemale, $EnergyDamageType] = 1.3;
$DamageScale[lfemale, $MissileDamageType] = 1.0;
$DamageScale[lfemale, $ShrapnelDamageType] = 1.2;
$DamageScale[lfemale, $DebrisDamageType] = 1.2;
$DamageScale[lfemale, $LaserDamageType] = 1.0;
$DamageScale[lfemale, $MortarDamageType] = 1.3;
$DamageScale[lfemale, $ElectricityDamageType] = 1.0;
$DamageScale[lfemale, $MineDamageType] = 1.2;
$DamageScale[lfemale, $SBulletDamageType] = 1.0;
$DamageScale[lfemale, $PBulletDamageType] = 1.0;
$DamageScale[lfemale, $FreezeDamageType] = 1.0;
$DamageScale[lfemale, $FlashDamageType] = 1.0; 
$DamageScale[lfemale, $MiniDamageType] = 1.0;           
$DamageScale[lfemale, $FunkDamageType] = 1.0;
$DamageScale[lfemale, $ConfettiDamageType] = 1.0;           

$ItemMax[lfemale, Blaster] = 1;
$ItemMax[lfemale, Funk] = 0;
$ItemMax[lfemale, Disclauncher] = 0;
$ItemMax[lfemale, FreezeGun] = 0;
$ItemMax[lfemale, GrenadeLauncher] = 0;
$ItemMax[lfemale, Mortar] = 0;
$ItemMax[lfemale, Flamethrower] = 0;
$ItemMax[lfemale, EnergyRifle] = 0;
$ItemMax[lfemale, TargetingLaser] = 1;
$ItemMax[lfemale, MineAmmo] = 3;
$ItemMax[lfemale, Grenade] = 5;
$ItemMax[lfemale, Beacon] = 3;
$ItemMax[lfemale, LP] = 1;
$ItemMax[lfemale, RL] = 0;
$ItemMax[lfemale, MG] = 0;
$ItemMax[lfemale, FL] = 1;
$ItemMax[lfemale, FP] = 0;
$ItemMax[lfemale, PC] = 0;
$ItemMax[lfemale, SP] = 0;
$ItemMax[lfemale, BH] = 0;
$ItemMax[lfemale, Shotgun1] = 0;
$ItemMax[lfemale, AR] = 0;
$ItemMax[lfemale, SR] = 0;
$ItemMax[lfemale, TB] = 0;
$ItemMax[lfemale, F] = 1;
$ItemMax[lfemale, EL] = 0;
$ItemMax[lfemale, AG] = 0;

$ItemMax[lfemale, DiscAmmo] = 15;
$ItemMax[lfemale, GrenadeAmmo] = 10;
$ItemMax[lfemale, MortarAmmo] = 10;
$ItemMax[lfemale, RLAmmo] = 10;
$ItemMax[lfemale, MGAmmo] = 500;
$ItemMax[lfemale, SPAmmo] = 9;
$ItemMax[lfemale, Shotgun1Ammo] = 2;
$ItemMax[lfemale, ARAmmo] = 30;
$ItemMax[lfemale, SRAmmo] = 5;
$ItemMax[lfemale, FAmmo] = 10;
$ItemMax[lfemale, ELAmmo] = 1;

$ItemMax[lfemale, RepairPack] = 1;
$ItemMax[lfemale, ShieldPack] = 0;
$ItemMax[lfemale, SolarPack] = 0;
$ItemMax[lfemale, FreezePack] = 0;
$ItemMax[lfemale, PadPack] = 0;
$ItemMax[lfemale, VehPack] = 0;
$ItemMax[lfemale, SensorJammerPack] = 1;
$ItemMax[lfemale, MotionSensorPack] = 1;
$ItemMax[lfemale, PulseSensorPack] = 1;
$ItemMax[lfemale, DeployableSensorJammerPack] = 1;
$ItemMax[lfemale, CameraPack] = 1;
$ItemMax[lfemale, TurretPack] = 0;
$ItemMax[lfemale, AmmoPack] = 1;
$ItemMax[lfemale, RepairKit] = 1;
$ItemMax[lfemale, DeployableInvPack] = 0;
$ItemMax[lfemale, DeployableAmmoPack] = 0;
$ItemMax[lfemale, LaserPack] = 0;
$ItemMax[lfemale, Laser2Pack] = 0;
$ItemMax[lfemale, CDPack] = 1;
$ItemMax[lfemale, CSDPack] = 0;
$ItemMax[lfemale, TLPack] = 0;
$ItemMax[lfemale, PCDPack] = 1;
$ItemMax[lfemale, DTurretPack] = 0;
$ItemMax[lfemale, DEPack] = 0;
$ItemMax[lfemale, ForceFieldPack] = 0;
$ItemMax[lfemale, BlastWallPack] = 0;
$ItemMax[lfemale, CTurretPack] = 0;
$ItemMax[lfemale, FTPack] = 0;
$ItemMax[lfemale, TGPack] = 0;
$ItemMax[lfemale, M350Pack] = 0;
$ItemMax[lfemale, PTPack] = 1;

$MaxWeapons[lfemale] = 3;

//----------------------------------------------------------------------------
// Panther Female Armor
//---------------------------------------------------------------------------
$DamageScale[qfemale, $LandingDamageType] = 1.0;
$DamageScale[qfemale, $ImpactDamageType] = 1.0;	
$DamageScale[qfemale, $CrushDamageType] = 1.0;	
$DamageScale[qfemale, $BulletDamageType] = 1.2;
$DamageScale[qfemale, $PlasmaDamageType] = 1.0;
$DamageScale[qfemale, $EnergyDamageType] = 1.3;
$DamageScale[qfemale, $MissileDamageType] = 1.0;
$DamageScale[qfemale, $ShrapnelDamageType] = 1.2;
$DamageScale[qfemale, $DebrisDamageType] = 1.2;
$DamageScale[qfemale, $LaserDamageType] = 1.0;
$DamageScale[qfemale, $MortarDamageType] = 1.3;
$DamageScale[qfemale, $ElectricityDamageType] = 1.0;
$DamageScale[qfemale, $MineDamageType] = 1.2;
$DamageScale[qfemale, $SBulletDamageType] = 1.0;
$DamageScale[qfemale, $PBulletDamageType] = 1.2;
$DamageScale[qfemale, $FreezeDamageType] = 1.0;
$DamageScale[qfemale, $FlashDamageType] = 1.0; 
$DamageScale[qfemale, $MiniDamageType] = 1.0;            
$DamageScale[qfemale, $FunkDamageType] = 1.0;
$DamageScale[qfemale, $ConfettiDamageType] = 1.0;               

$ItemMax[qfemale, Blaster] = 1;
$ItemMax[qfemale, Funk] = 1;
$ItemMax[qfemale, FreezeGun] = 0;
$ItemMax[qfemale, Disclauncher] = 0;
$ItemMax[qfemale, GrenadeLauncher] = 0;
$ItemMax[qfemale, Mortar] = 0;
$ItemMax[qfemale, Flamethrower] = 0;
$ItemMax[qfemale, EnergyRifle] = 1;
$ItemMax[qfemale, TargetingLaser] = 1;
$ItemMax[qfemale, MineAmmo] = 3;
$ItemMax[qfemale, Grenade] = 5;
$ItemMax[qfemale, Beacon] = 3;
$ItemMax[qfemale, LP] = 1;
$ItemMax[qfemale, RL] = 0;
$ItemMax[qfemale, MG] = 0;
$ItemMax[qfemale, FL] = 1;
$ItemMax[qfemale, FP] = 0;
$ItemMax[qfemale, PC] = 0;
$ItemMax[qfemale, SP] = 0;
$ItemMax[qfemale, BH] = 0;
$ItemMax[qfemale, Shotgun1] = 0;
$ItemMax[qfemale, AR] = 0;
$ItemMax[qfemale, SR] = 0;
$ItemMax[qfemale, TB] = 0;
$ItemMax[qfemale, F] = 1;
$ItemMax[qfemale, EL] = 0;
$ItemMax[qfemale, AG] = 0;

$ItemMax[qfemale, DiscAmmo] = 15;
$ItemMax[qfemale, GrenadeAmmo] = 10;
$ItemMax[qfemale, MortarAmmo] = 10;
$ItemMax[qfemale, RLAmmo] = 10;
$ItemMax[qfemale, MGAmmo] = 500;
$ItemMax[qfemale, SPAmmo] = 9;
$ItemMax[qfemale, Shotgun1Ammo] = 2;
$ItemMax[qfemale, ARAmmo] = 30;
$ItemMax[qfemale, SRAmmo] = 5;
$ItemMax[qfemale, FAmmo] = 10;
$ItemMax[qfemale, ELAmmo] = 1;

$ItemMax[qfemale, RepairPack] = 1;
$ItemMax[qfemale, ShieldPack] = 1;
$ItemMax[qfemale, SolarPack] = 0;
$ItemMax[qfemale, FreezePack] = 0;
$ItemMax[qfemale, PadPack] = 0;
$ItemMax[qfemale, VehPack] = 0;
$ItemMax[qfemale, SensorJammerPack] = 1;
$ItemMax[qfemale, MotionSensorPack] = 1;
$ItemMax[qfemale, PulseSensorPack] = 1;
$ItemMax[qfemale, DeployableSensorJammerPack] = 1;
$ItemMax[qfemale, CameraPack] = 1;
$ItemMax[qfemale, TurretPack] = 0;
$ItemMax[qfemale, AmmoPack] = 1;
$ItemMax[qfemale, RepairKit] = 1;
$ItemMax[qfemale, DeployableInvPack] = 0;
$ItemMax[qfemale, DeployableAmmoPack] = 0;
$ItemMax[qfemale, LaserPack] = 0;
$ItemMax[qfemale, Laser2Pack] = 0;
$ItemMax[qfemale, CDPack] = 1;
$ItemMax[qfemale, CSDPack] = 0;
$ItemMax[qfemale, TLPack] = 0;
$ItemMax[qfemale, PCDPack] = 1;
$ItemMax[qfemale, DTurretPack] = 0;
$ItemMax[qfemale, DEPack] = 0;
$ItemMax[qfemale, ForceFieldPack] = 0;
$ItemMax[qfemale, BlastWallPack] = 0;
$ItemMax[qfemale, CTurretPack] = 0;
$ItemMax[qfemale, FTPack] = 0;
$ItemMax[qfemale, TGPack] = 0;
$ItemMax[qfemale, M350Pack] = 0;
$ItemMax[qfemale, PTPack] = 0;

$MaxWeapons[qfemale] = 3;

//----------------------------------------------------------------------------
// Sniper Female Armor
//----------------------------------------------------------------------------
$DamageScale[srfemale, $LandingDamageType] = 1.0;
$DamageScale[srfemale, $ImpactDamageType] = 1.0;	
$DamageScale[srfemale, $CrushDamageType] = 1.0;	
$DamageScale[srfemale, $BulletDamageType] = 1.2;
$DamageScale[srfemale, $PlasmaDamageType] = 1.0;
$DamageScale[srfemale, $EnergyDamageType] = 1.3;
$DamageScale[srfemale, $MissileDamageType] = 1.0;
$DamageScale[srfemale, $ShrapnelDamageType] = 1.2;
$DamageScale[srfemale, $DebrisDamageType] = 1.2;
$DamageScale[srfemale, $LaserDamageType] = 1.0;
$DamageScale[srfemale, $MortarDamageType] = 1.3;
$DamageScale[srfemale, $ElectricityDamageType] = 1.0;
$DamageScale[srfemale, $MineDamageType] = 1.2;
$DamageScale[srfemale, $SBulletDamageType] = 1.0;
$DamageScale[srfemale, $PBulletDamageType] = 1.0;
$DamageScale[srfemale, $FreezeDamageType] = 1.0;
$DamageScale[srfemale, $FlashDamageType] = 1.0; 
$DamageScale[srfemale, $MiniDamageType] = 1.0;            
$DamageScale[srfemale, $FunkDamageType] = 1.0;
$DamageScale[srfemale, $ConfettiDamageType] = 1.0;               

$ItemMax[srfemale, Blaster] = 0;
$ItemMax[srfemale, Funk] = 0;
$ItemMax[srfemale, Disclauncher] = 1;
$ItemMax[srfemale, FreezeGun] = 0;
$ItemMax[srfemale, GrenadeLauncher] = 1;
$ItemMax[srfemale, Mortar] = 0;
$ItemMax[srfemale, Flamethrower] = 0;
$ItemMax[srfemale, EnergyRifle] = 0;
$ItemMax[srfemale, TargetingLaser] = 1;
$ItemMax[srfemale, MineAmmo] = 3;
$ItemMax[srfemale, Grenade] = 5;
$ItemMax[srfemale, Beacon] = 3;
$ItemMax[srfemale, LP] = 1;
$ItemMax[srfemale, RL] = 0;
$ItemMax[srfemale, MG] = 0;
$ItemMax[srfemale, FL] = 1;
$ItemMax[srfemale, FP] = 0;
$ItemMax[srfemale, PC] = 0;
$ItemMax[srfemale, SP] = 0;
$ItemMax[srfemale, BH] = 0;
$ItemMax[srfemale, Shotgun1] = 0;
$ItemMax[srfemale, AR] = 0;
$ItemMax[srfemale, SR] = 1;
$ItemMax[srfemale, TB] = 0;
$ItemMax[srfemale, F] = 1;
$ItemMax[srfemale, EL] = 0;
$ItemMax[srfemale, AG] = 1;

$ItemMax[srfemale, DiscAmmo] = 15;
$ItemMax[srfemale, GrenadeAmmo] = 10;
$ItemMax[srfemale, MortarAmmo] = 10;
$ItemMax[srfemale, RLAmmo] = 10;
$ItemMax[srfemale, MGAmmo] = 500;
$ItemMax[srfemale, SPAmmo] = 9;
$ItemMax[srfemale, Shotgun1Ammo] = 2;
$ItemMax[srfemale, ARAmmo] = 30;
$ItemMax[srfemale, SRAmmo] = 5;
$ItemMax[srfemale, FAmmo] = 10;
$ItemMax[srfemale, ELAmmo] = 1;

$ItemMax[srfemale, RepairPack] = 1;
$ItemMax[srfemale, SolarPack] = 0;
$ItemMax[srfemale, FreezePack] = 0;
$ItemMax[srfemale, PadPack] = 0;
$ItemMax[srfemale, VehPack] = 0;
$ItemMax[srfemale, ShieldPack] = 0;
$ItemMax[srfemale, SensorJammerPack] = 1;
$ItemMax[srfemale, MotionSensorPack] = 1;
$ItemMax[srfemale, PulseSensorPack] = 1;
$ItemMax[srfemale, DeployableSensorJammerPack] = 1;
$ItemMax[srfemale, CameraPack] = 1;
$ItemMax[srfemale, TurretPack] = 0;
$ItemMax[srfemale, AmmoPack] = 1;
$ItemMax[srfemale, RepairKit] = 1;
$ItemMax[srfemale, DeployableInvPack] = 0;
$ItemMax[srfemale, DeployableAmmoPack] = 0;
$ItemMax[srfemale, LaserPack] = 0;
$ItemMax[srfemale, Laser2Pack] = 0;
$ItemMax[srfemale, CDPack] = 1;
$ItemMax[srfemale, CSDPack] = 0;
$ItemMax[srfemale, TLPack] = 1;
$ItemMax[srfemale, PCDPack] = 1;
$ItemMax[srfemale, DTurretPack] = 0;
$ItemMax[srfemale, DEPack] = 1;
$ItemMax[srfemale, ForceFieldPack] = 0;
$ItemMax[srfemale, BlastWallPack] = 0;
$ItemMax[srfemale, CTurretPack] = 0;
$ItemMax[srfemale, FTPack] = 0;
$ItemMax[srfemale, TGPack] = 0;
$ItemMax[srfemale, M350Pack] = 0;
$ItemMax[srfemale, PTPack] = 0;

$MaxWeapons[srfemale] = 3;

//----------------------------------------------------------------------------
// Special Female Armor
//---------------------------------------------------------------------------
$DamageScale[sfemale, $LandingDamageType] = 1.0;
$DamageScale[sfemale, $ImpactDamageType] = 1.0;	
$DamageScale[sfemale, $CrushDamageType] = 1.0;	
$DamageScale[sfemale, $BulletDamageType] = 1.2;
$DamageScale[sfemale, $PlasmaDamageType] = 1.0;
$DamageScale[sfemale, $EnergyDamageType] = 1.3;
$DamageScale[sfemale, $MissileDamageType] = 1.0;
$DamageScale[sfemale, $ShrapnelDamageType] = 1.2;
$DamageScale[sfemale, $DebrisDamageType] = 1.2;
$DamageScale[sfemale, $LaserDamageType] = 1.0;
$DamageScale[sfemale, $MortarDamageType] = 1.3;
$DamageScale[sfemale, $ElectricityDamageType] = 1.0;
$DamageScale[sfemale, $MineDamageType] = 1.2;
$DamageScale[sfemale, $SBulletDamageType] = 1.0;
$DamageScale[sfemale, $PBulletDamageType] = 1.0;
$DamageScale[sfemale, $FreezeDamageType] = 1.0;
$DamageScale[sfemale, $FlashDamageType] = 1.0; 
$DamageScale[sfemale, $MiniDamageType] = 1.0;            
$DamageScale[sfemale, $FunkDamageType] = 1.0;
$DamageScale[sfemale, $ConfettiDamageType] = 1.0;               

$ItemMax[sfemale, Blaster] = 0;
$ItemMax[sfemale, Funk] = 0;
$ItemMax[sfemale, Disclauncher] = 1;
$ItemMax[sfemale, FreezeGun] = 0;
$ItemMax[sfemale, GrenadeLauncher] = 1;
$ItemMax[sfemale, Mortar] = 0;
$ItemMax[sfemale, Flamethrower] = 0;
$ItemMax[sfemale, EnergyRifle] = 0;
$ItemMax[sfemale, TargetingLaser] = 1;
$ItemMax[sfemale, MineAmmo] = 3;
$ItemMax[sfemale, Grenade] = 5;
$ItemMax[sfemale, Beacon] = 3;
$ItemMax[sfemale, LP] = 1;
$ItemMax[sfemale, RL] = 0;
$ItemMax[sfemale, MG] = 0;
$ItemMax[sfemale, FL] = 1;
$ItemMax[sfemale, FP] = 0;
$ItemMax[sfemale, PC] = 0;
$ItemMax[sfemale, SP] = 1;
$ItemMax[sfemale, BH] = 0;
$ItemMax[sfemale, Shotgun1] = 0;
$ItemMax[sfemale, AR] = 1;
$ItemMax[sfemale, SR] = 0;
$ItemMax[sfemale, TB] = 0;
$ItemMax[sfemale, F] = 1;
$ItemMax[sfemale, EL] = 0;
$ItemMax[sfemale, AG] = 0;

$ItemMax[sfemale, DiscAmmo] = 15;
$ItemMax[sfemale, GrenadeAmmo] = 10;
$ItemMax[sfemale, MortarAmmo] = 10;
$ItemMax[sfemale, RLAmmo] = 10;
$ItemMax[sfemale, MGAmmo] = 500;
$ItemMax[sfemale, SPAmmo] = 9;
$ItemMax[sfemale, Shotgun1Ammo] = 2;
$ItemMax[sfemale, ARAmmo] = 30;
$ItemMax[sfemale, SRAmmo] = 5;
$ItemMax[sfemale, FAmmo] = 10;
$ItemMax[sfemale, ELAmmo] = 1;

$ItemMax[sfemale, RepairPack] = 1;
$ItemMax[sfemale, ShieldPack] = 0;
$ItemMax[sfemale, SolarPack] = 0;
$ItemMax[sfemale, FreezePack] = 0;
$ItemMax[sfemale, PadPack] = 0;
$ItemMax[sfemale, VehPack] = 0;
$ItemMax[sfemale, SensorJammerPack] = 1;
$ItemMax[sfemale, MotionSensorPack] = 1;
$ItemMax[sfemale, PulseSensorPack] = 1;
$ItemMax[sfemale, DeployableSensorJammerPack] = 1;
$ItemMax[sfemale, CameraPack] = 1;
$ItemMax[sfemale, TurretPack] = 0;
$ItemMax[sfemale, AmmoPack] = 1;
$ItemMax[sfemale, RepairKit] = 1;
$ItemMax[sfemale, DeployableInvPack] = 0;
$ItemMax[sfemale, DeployableAmmoPack] = 0;
$ItemMax[sfemale, LaserPack] = 0;
$ItemMax[sfemale, Laser2Pack] = 0;
$ItemMax[sfemale, CDPack] = 1;
$ItemMax[sfemale, CSDPack] = 0;
$ItemMax[sfemale, TLPack] = 0;
$ItemMax[sfemale, PCDPack] = 1;
$ItemMax[sfemale, DTurretPack] = 0;
$ItemMax[sfemale, DEPack] = 0;
$ItemMax[sfemale, ForceFieldPack] = 0;
$ItemMax[sfemale, BlastWallPack] = 0;
$ItemMax[sfemale, CTurretPack] = 0;
$ItemMax[sfemale, FTPack] = 0;
$ItemMax[sfemale, TGPack] = 0;
$ItemMax[sfemale, M350Pack] = 0;
$ItemMax[sfemale, PTPack] = 0;

$MaxWeapons[sfemale] = 3;


//----------------------------------------------------------------------------
// Medium Female Armor
//----------------------------------------------------------------------------
$DamageScale[mfemale, $LandingDamageType] = 1.0;
$DamageScale[mfemale, $ImpactDamageType] = 1.0;
$DamageScale[mfemale, $CrushDamageType] = 1.0;
$DamageScale[mfemale, $BulletDamageType] = 1.0;
$DamageScale[mfemale, $EnergyDamageType] = 1.0;
$DamageScale[mfemale, $PlasmaDamageType] = 0.6;
$DamageScale[mfemale, $MissileDamageType] = 1.0;
$DamageScale[mfemale, $ShrapnelDamageType] = 1.0;
$DamageScale[mfemale, $DebrisDamageType] = 1.0;
$DamageScale[mfemale, $LaserDamageType] = 1.0;
$DamageScale[mfemale, $MortarDamageType] = 1.0;
$DamageScale[mfemale, $ElectricityDamageType] = 1.0;
$DamageScale[mfemale, $MineDamageType] = 1.0;
$DamageScale[mfemale, $SBulletDamageType] = 1.0;
$DamageScale[mfemale, $PBulletDamageType] = 1.0;
$DamageScale[mfemale, $FreezeDamageType] = 1.0;
$DamageScale[mfemale, $FlashDamageType] = 1.0; 
$DamageScale[mfemale, $MiniDamageType] = 1.0;            
$DamageScale[mfemale, $FunkDamageType] = 1.0;
$DamageScale[mfemale, $ConfettiDamageType] = 1.0;               

$ItemMax[mfemale, Blaster] = 1;
$ItemMax[mfemale, Funk] = 0;
$ItemMax[mfemale, Disclauncher] = 1;
$ItemMax[mfemale, FreezeGun] = 0;
$ItemMax[mfemale, GrenadeLauncher] = 1;
$ItemMax[mfemale, Mortar] = 0;
$ItemMax[mfemale, Flamethrower] = 0;
$ItemMax[mfemale, EnergyRifle] = 0;
$ItemMax[mfemale, TargetingLaser] = 1;
$ItemMax[mfemale, MineAmmo] = 3;
$ItemMax[mfemale, Grenade] = 6;
$ItemMax[mfemale, Beacon] = 3;
$ItemMax[mfemale, LP] = 0;
$ItemMax[mfemale, RL] = 1;
$ItemMax[mfemale, MG] = 0;
$ItemMax[mfemale, FL] = 1;
$ItemMax[mfemale, FP] = 0;
$ItemMax[mfemale, PC] = 0;
$ItemMax[mfemale, SP] = 0;
$ItemMax[mfemale, BH] = 0;
$ItemMax[mfemale, Shotgun1] = 1;
$ItemMax[mfemale, AR] = 0;
$ItemMax[mfemale, SR] = 0;
$ItemMax[mfemale, TB] = 1;
$ItemMax[mfemale, F] = 1;
$ItemMax[mfemale, EL] = 0;
$ItemMax[mfemale, AG] = 0;

$ItemMax[mfemale, DiscAmmo] = 15;
$ItemMax[mfemale, GrenadeAmmo] = 10;
$ItemMax[mfemale, MortarAmmo] = 10;
$ItemMax[mfemale, RLAmmo] = 10;
$ItemMax[mfemale, MGAmmo] = 500;
$ItemMax[mfemale, SPAmmo] = 9;
$ItemMax[mfemale, Shotgun1Ammo] = 2;
$ItemMax[mfemale, ARAmmo] = 30;
$ItemMax[mfemale, SRAmmo] = 5;
$ItemMax[mfemale, FAmmo] = 10;
$ItemMax[mfemale, ELAmmo] = 1;

$ItemMax[mfemale, RepairPack] = 1;
$ItemMax[mfemale, ShieldPack] = 0;
$ItemMax[mfemale, SolarPack] = 1;
$ItemMax[mfemale, FreezePack] = 0;
$ItemMax[mfemale, PadPack] = 1;
$ItemMax[mfemale, VehPack] = 1;
$ItemMax[mfemale, SensorJammerPack] = 1;
$ItemMax[mfemale, MotionSensorPack] = 1;
$ItemMax[mfemale, PulseSensorPack] = 1;
$ItemMax[mfemale, DeployableSensorJammerPack] = 1;
$ItemMax[mfemale, CameraPack] = 1;
$ItemMax[mfemale, TurretPack] = 1;
$ItemMax[mfemale, AmmoPack] = 1;
$ItemMax[mfemale, RepairKit] = 1;
$ItemMax[mfemale, DeployableInvPack] = 1;
$ItemMax[mfemale, DeployableAmmoPack] = 1;
$ItemMax[mfemale, LaserPack] = 1;
$ItemMax[mfemale, Laser2Pack] = 1;
$ItemMax[mfemale, CDPack] = 1;
$ItemMax[mfemale, CSDPack] = 0;
$ItemMax[mfemale, TLPack] = 0;
$ItemMax[mfemale, PCDPack] = 1;
$ItemMax[mfemale, DTurretPack] = 1;
$ItemMax[mfemale, DEPack] = 1;
$ItemMax[mfemale, ForceFieldPack] = 1;
$ItemMax[mfemale, BlastWallPack] = 1;
$ItemMax[mfemale, CTurretPack] = 1;
$ItemMax[mfemale, FTPack] = 0;
$ItemMax[mfemale, TGPack] = 0;
$ItemMax[mfemale, M350Pack] = 0;
$ItemMax[mfemale, PTPack] = 0;
$ItemMax[mfemale, BunkerPack] = 1;

$MaxWeapons[mfemale] = 4;


//----------------------------------------------------------------------------
// Pyro Female Armor
//----------------------------------------------------------------------------
$DamageScale[pfemale, $LandingDamageType] = 1.0;
$DamageScale[pfemale, $ImpactDamageType] = 1.0;
$DamageScale[pfemale, $CrushDamageType] = 1.0;
$DamageScale[pfemale, $BulletDamageType] = 1.0;
$DamageScale[pfemale, $EnergyDamageType] = 1.0;
$DamageScale[pfemale, $PlasmaDamageType] = 0.6;
$DamageScale[pfemale, $MissileDamageType] = 1.0;
$DamageScale[pfemale, $ShrapnelDamageType] = 1.0;
$DamageScale[pfemale, $DebrisDamageType] = 1.0;
$DamageScale[pfemale, $LaserDamageType] = 1.0;
$DamageScale[pfemale, $MortarDamageType] = 1.0;
$DamageScale[pfemale, $ElectricityDamageType] = 1.0;
$DamageScale[pfemale, $MineDamageType] = 1.0;
$DamageScale[pfemale, $SBulletDamageType] = 1.0;
$DamageScale[pfemale, $PBulletDamageType] = 1.0;
$DamageScale[pfemale, $FreezeDamageType] = 1.0;
$DamageScale[pfemale, $FlashDamageType] = 1.0; 
$DamageScale[pfemale, $MiniDamageType] = 1.0;            
$DamageScale[pfemale, $FunkDamageType] = 1.0;
$DamageScale[pfemale, $ConfettiDamageType] = 1.0;               

$ItemMax[pfemale, Blaster] = 1;
$ItemMax[pfemale, Funk] = 0;
$ItemMax[pfemale, Disclauncher] = 1;
$ItemMax[pfemale, FreezeGun] = 1;
$ItemMax[pfemale, GrenadeLauncher] = 1;
$ItemMax[pfemale, Mortar] = 0;
$ItemMax[pfemale, Flamethrower] = 1;
$ItemMax[pfemale, EnergyRifle] = 0;
$ItemMax[pfemale, TargetingLaser] = 1;
$ItemMax[pfemale, MineAmmo] = 3;
$ItemMax[pfemale, Grenade] = 6;
$ItemMax[pfemale, Beacon] = 3;
$ItemMax[pfemale, LP] = 0;
$ItemMax[pfemale, RL] = 0;
$ItemMax[pfemale, MG] = 0;
$ItemMax[pfemale, FL] = 1;
$ItemMax[pfemale, FP] = 1;
$ItemMax[pfemale, PC] = 0;
$ItemMax[pfemale, SP] = 0;
$ItemMax[pfemale, BH] = 0;
$ItemMax[pfemale, Shotgun1] = 1;
$ItemMax[pfemale, AR] = 0;
$ItemMax[pfemale, SR] = 0;
$ItemMax[pfemale, TB] = 0;
$ItemMax[pfemale, F] = 1;
$ItemMax[pfemale, EL] = 0;
$ItemMax[pfemale, AG] = 1;

$ItemMax[pfemale, DiscAmmo] = 15;
$ItemMax[pfemale, GrenadeAmmo] = 10;
$ItemMax[pfemale, MortarAmmo] = 10;
$ItemMax[pfemale, RLAmmo] = 10;
$ItemMax[pfemale, MGAmmo] = 500;
$ItemMax[pfemale, SPAmmo] = 9;
$ItemMax[pfemale, Shotgun1Ammo] = 2;
$ItemMax[pfemale, ARAmmo] = 30;
$ItemMax[pfemale, SRAmmo] = 5;
$ItemMax[pfemale, FAmmo] = 10;
$ItemMax[pfemale, ELAmmo] = 1;

$ItemMax[pfemale, RepairPack] = 1;
$ItemMax[pfemale, ShieldPack] = 0;
$ItemMax[pfemale, SolarPack] = 0;
$ItemMax[pfemale, FreezePack] = 1;
$ItemMax[pfemale, PadPack] = 0;
$ItemMax[pfemale, VehPack] = 0;
$ItemMax[pfemale, SensorJammerPack] = 1;
$ItemMax[pfemale, MotionSensorPack] = 1;
$ItemMax[pfemale, PulseSensorPack] = 1;
$ItemMax[pfemale, DeployableSensorJammerPack] = 1;
$ItemMax[pfemale, CameraPack] = 1;
$ItemMax[pfemale, TurretPack] = 1;
$ItemMax[pfemale, AmmoPack] = 1;
$ItemMax[pfemale, RepairKit] = 1;
$ItemMax[pfemale, DeployableInvPack] = 1;
$ItemMax[pfemale, DeployableAmmoPack] = 1;
$ItemMax[pfemale, LaserPack] = 1;
$ItemMax[pfemale, Laser2Pack] = 1;
$ItemMax[pfemale, CDPack] = 1;
$ItemMax[pfemale, CSDPack] = 0;
$ItemMax[pfemale, TLPack] = 0;
$ItemMax[pfemale, PCDPack] = 1;
$ItemMax[pfemale, DTurretPack] = 0;
$ItemMax[pfemale, DEPack] = 0;
$ItemMax[pfemale, ForceFieldPack] = 0;
$ItemMax[pfemale, BlastWallPack] = 0;
$ItemMax[pfemale, CTurretPack] = 0;
$ItemMax[pfemale, FTPack] = 1;
$ItemMax[pfemale, TGPack] = 0;
$ItemMax[pfemale, M350Pack] = 0;
$ItemMax[pfemale, PTPack] = 0;

$MaxWeapons[pfemale] = 4;

//------------------------------------------------------------------
// Pilot data:
//------------------------------------------------------------------

DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};

PlayerData larmor
{
	className = "Armor";
	shapeFile = "larmor";
	damageSkinData = "armorDamageSkins";
	debrisId = PilotDebris;
	flameShapeName = "lflame";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.8;
	maxJetForwardVelocity = 22;
	minJetEnergy = 1;
	jetForce = 236;
	jetEnergyDrain = 0.8;
	maxDamage = 0.66;
	maxForwardSpeed = 11;
	maxBackwardSpeed = 10;
	maxSideSpeed = 10;
	groundForce = 40 * 9.0;
	mass = 9.0;
	groundTraction = 3.0;
	maxEnergy = 60;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 75;
	jumpSurfaceMinDot = 0.2;

	// animation data:
	// animation name, one shot, direction, firstPerson, chaseCam, thirdPerson, signalThread
	//-Signal Roots are:
		// 0 = Root
		// 1 = Play and don't go back to root until movement occurs
		// 2 = Play and then go back to root when finished
		// 3 = Movement Animations and positions
		// 4 = Death animation
		//- Keep all false except: root,run,runback,side left,crouch roots,fall,jet
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, false, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, false, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, true, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, true, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
   animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Panther armor data:
//------------------------------------------------------------------

PlayerData qarmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = PantherDebris;
   flameShapeName = "fusionex";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 23;
   minJetEnergy = 1;
   jetForce = 350;
   jetEnergyDrain = 0.7;

	maxDamage = 0.50;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 13;
   maxSideSpeed = 14;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.002;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, true, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, true, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
   animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};


//------------------------------------------------------------------
// Sniper armor data:
//------------------------------------------------------------------

PlayerData srarmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = SniperDebris;
   flameShapeName = "shield";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Special armor data:
//------------------------------------------------------------------

PlayerData sarmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = PlayerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;

   visibleToSensor = false;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[8] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[9] = { "flyer root", none, -1, false, false, false, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = "SoundSpecialFoot";
   rFootSounds = 
   {
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot"
  }; 
   lFootSounds =
   {
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot"
  }; 

   footPrints = { 0, 0 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium Armor data:
//------------------------------------------------------------------

PlayerData marmor
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

   maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
	maxEnergy = 80;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Pyro Armor data:
//------------------------------------------------------------------

PlayerData parmor
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "plasmaex";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = plasmaDebris;
   shadowDetailMask = 1;

   canCrouch = false;
   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

	maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	
	maxEnergy = 80;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Heavy Armor data:
//------------------------------------------------------------------

PlayerData harmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = HeavyDebris;
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 12;
   minJetEnergy = 1;
   jetForce = 385;
   jetEnergyDrain = 1.1;

	maxDamage = 1.32;
   maxForwardSpeed = 5.0;
   maxBackwardSpeed = 4.0;
   maxSideSpeed = 4.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 110;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, tfalse, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, true, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
   animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// Tiger Armor data:
//------------------------------------------------------------------

PlayerData tarmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "smoke";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = TitanDebris;
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 10;
   minJetEnergy = 1;
   jetForce = 400;
   jetEnergyDrain = 1.3;

	maxDamage = 1.50;
   maxForwardSpeed = 4.0;
   maxBackwardSpeed = 3.0;
   maxSideSpeed = 3.0;
   groundForce = 35 * 18.0;
   groundTraction = 4.5;
   mass = 18.0;
	maxEnergy = 200;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, true, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, true, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
   animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundFlyerActive;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// Pilot female data:
//------------------------------------------------------------------

PlayerData lfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = PilotDebris;
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;
   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.85;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.88;
   boxCrouchTorsoPercentage = 0.35;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Panther female data:
//------------------------------------------------------------------

PlayerData qfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "fusionex";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = PantherDebris;
   shadowDetailMask = 1;

visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 23;
   minJetEnergy = 1;
   jetForce = 336;
   jetEnergyDrain = 0.7;

	maxDamage = 0.50;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 13;
   maxSideSpeed = 14;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.002;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Sniper female data:
//------------------------------------------------------------------

PlayerData srfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "shield";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = SniperDebris;
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;
   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.85;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.88;
   boxCrouchTorsoPercentage = 0.35;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Specialist female data:
//------------------------------------------------------------------

PlayerData sfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = false;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;
   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 22;
   minJetEnergy = 1;
   jetForce = 236;
   jetEnergyDrain = 0.8;

	maxDamage = 0.66;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 60;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[8] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[9] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, false, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = "SoundSpecialFoot";
   rFootSounds = 
   {
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot"
  }; 
   lFootSounds =
   {
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot",
     "SoundSpecialFoot"
  }; 

   footPrints = { 0, 0 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.85;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.88;
   boxCrouchTorsoPercentage = 0.35;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium female data:
//------------------------------------------------------------------

PlayerData mfemale
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

   canCrouch = false;
	maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	maxEnergy = 80;
   mass = 13.0;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Pyro female data:
//------------------------------------------------------------------

PlayerData pfemale
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "plasmaex";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = PlasmaDebris;
   shadowDetailMask = 1;

   visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 320;
   jetEnergyDrain = 1.0;

   canCrouch = false;
	maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 13.0;
   groundTraction = 3.0;
	maxEnergy = 80;
   mass = 13.0;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundF1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundF1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------------//
//PSYCHO-ARMOR------------------------------------------------------------//
//------------------------------------------------------------------------//
//PSYCHO MALE//
//-----------//

$DamageScale[psarmor, $LandingDamageType] = 1.0;
$DamageScale[psarmor, $ImpactDamageType] = 1.0;
$DamageScale[psarmor, $CrushDamageType] = 1.0;
$DamageScale[psarmor, $PlasmaDamageType] = 0.5;
$DamageScale[psarmor, $EnergyDamageType] = 0.7;
$DamageScale[psarmor, $MissileDamageType] = 1.0;
$DamageScale[psarmor, $DebrisDamageType] = 0.7;
$DamageScale[psarmor, $ElectricityDamageType] = 1.0;
$DamageScale[psarmor, $SBulletDamageType] = 1.0;
$DamageScale[psarmor, $PBulletDamageType] = 1.0;
$DamageScale[psarmor, $FreezeDamageType] = 1.0;
$DamageScale[psarmor, $FunkDamageType] = 0.0;
$DamageScale[psarmor, $ConfettiDamageType] = 0.0;
$DamageScale[psarmor, $SniperDamageType] = 0.5;

$ItemMax[psarmor, Blaster] = 1;
$ItemMax[psarmor, Tazer] = 0;
$ItemMax[psarmor, Funk] = 1;
$ItemMax[psarmor, FreezeGun] = 0;
$ItemMax[psarmor, Disclauncher] = 0;
$ItemMax[psarmor, GrenadeLauncher] = 0;
$ItemMax[psarmor, Mortar] = 0;
$ItemMax[psarmor, Flamethrower] = 0;
$ItemMax[psarmor, EnergyRifle] = 1;
$ItemMax[psarmor, LP]  = 0;
$ItemMax[psarmor, RL]  = 0;
$ItemMax[psarmor, MG]  = 0;
$ItemMax[psarmor, FL]  = 0;
$ItemMax[psarmor, FP]  = 0;
$ItemMax[psarmor, PC]  = 0;
$ItemMax[psarmor, SP]  = 0;
$ItemMax[psarmor, BH]  = 0;
$ItemMax[psarmor, Shotgun1] = 0;
$ItemMax[psarmor, AR] = 0;
$ItemMax[psarmor, SR] = 0;
$ItemMax[psarmor, TB] = 0;
$ItemMax[psarmor, F] = 0;
$ItemMax[psarmor, EL] = 1;
$ItemMax[psarmor, Beam] = 1;
$ItemMax[psarmor, Sword] = 1;
$ItemMax[psarmor, Multi] = 1;
$ItemMax[psarmor, HG] = 0;
$ItemMax[psarmor, PGL] = 0;
$ItemMax[psarmor, SmokeLauncher] = 0;
$ItemMax[psarmor, Shock] = 1;
$ItemMax[psarmor, V] = 0;
$ItemMax[psarmor, TargetingLaser] = 1;

$ItemMax[psarmor, AirMineAmmo] = 2;
$ItemMax[psarmor, MineAmmo] = 2;
$ItemMax[psarmor, Grenade] = 10;
$ItemMax[psarmor, Beacon]  = 1;
$ItemMax[psarmor, RepairKit] = 1;

$ItemMax[psarmor, HGAmmo] = 10;
$ItemMax[psarmor, SmokeAmmo] = 0;
$ItemMax[psarmor, MultiAmmo] = 10;
$ItemMax[psarmor, DiscAmmo] = 0;
$ItemMax[psarmor, GrenadeAmmo] = 0;
$ItemMax[psarmor, MortarAmmo] = 0;
$ItemMax[psarmor, RLAmmo] = 0;
$ItemMax[psarmor, MGAmmo] = 0;
$ItemMax[psarmor, SPAmmo] = 9;
$ItemMax[psarmor, Shotgun1Ammo] = 2;
$ItemMax[psarmor, ARAmmo] = 30;
$ItemMax[psarmor, SRAmmo] = 5;
$ItemMax[psarmor, FAmmo] = 0;
$ItemMax[psarmor, ELAmmo] = 1;
$ItemMax[psarmor, PGLAmmo] = 10;

$ItemMax[psarmor, BeamPack] = 1;
$ItemMax[psarmor, DemiPack] = 0;
$ItemMax[psarmor, SuperPack1] = 0;
$ItemMax[psarmor, SuperPack2] = 0;
$ItemMax[psarmor, THPack] = 0;
$ItemMax[psarmor, ControlPack] = 0;
$ItemMax[psarmor, SolarPack] = 0;
$ItemMax[psarmor, FreezePack] = 0;
$ItemMax[psarmor, PadPack] = 0;
$ItemMax[psarmor, VehPack] = 0;
$ItemMax[psarmor, RepairPack] = 1;
$ItemMax[psarmor, ShieldPack] = 0;
$ItemMax[psarmor, SensorJammerPack] = 1;
$ItemMax[psarmor, MotionSensorPack] = 1;
$ItemMax[psarmor, PulseSensorPack] = 1;
$ItemMax[psarmor, DeployableSensorJammerPack] = 1;
$ItemMax[psarmor, CameraPack] = 1;
$ItemMax[psarmor, TurretPack] = 0;
$ItemMax[psarmor, AmmoPack] = 1;
$ItemMax[psarmor, DeployableInvPack] = 0;
$ItemMax[psarmor, DeployableAmmoPack] = 0;
$ItemMax[psarmor, LaserPack] = 0;
$ItemMax[psarmor, Laser2Pack] = 0;
$ItemMax[psarmor, CDPack] = 1;
$ItemMax[psarmor, CSDPack] = 0;
$ItemMax[psarmor, TLPack] = 0;
$ItemMax[psarmor, PCDPack] = 1;
$ItemMax[psarmor, DTurretPack] = 0;
$ItemMax[psarmor, DEPack] = 0;
$ItemMax[psarmor, ForceFieldPack] = 0;
$ItemMax[psarmor, CTurretPack] = 0;
$ItemMax[psarmor, FTPack] = 0;
$ItemMax[psarmor, TGPack] = 0;
$ItemMax[psarmor, M350Pack] = 0;
$ItemMax[psarmor, PTPack] = 0;

$MaxWeapons[psarmor] = 3;

PlayerData psarmor
{
	className = "Armor";
	shapeFile = "marmor";
	damageSkinData = "armorDamageSkins";
	debrisId = PsychoDebris;
	flameShapeName = "shockwave_large";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = false;
	maxJetSideForceFactor = 1.0;
	maxJetForwardVelocity = 18;
	minJetEnergy = 1;
	jetForce = 430;
	jetEnergyDrain = 1.0;
	maxDamage = 1.0;
	maxForwardSpeed = 9.0;
	maxBackwardSpeed = 9.0;
	maxSideSpeed = 9.0;
	groundForce = 35 * 13.0;
	mass = 13.0;
	groundTraction = 4.0;
	maxEnergy = 90;
	drag = 1.0;
	density = 1.5;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 110;
	jumpSurfaceMinDot = 0.2;

	// animation data:
	// animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   //animData[19] = { "jet", none, 1, true, true, true, false, 3 };
   animData[19] = { "Fall controlled", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, true, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, true, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
   animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

   // Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//--------------------------------------------------------------------------
//PSYCHO FEMALE//
//-------------//

$DamageScale[psfemale, $LandingDamageType] = 1.0;
$DamageScale[psfemale, $ImpactDamageType] = 1.0;
$DamageScale[psfemale, $CrushDamageType] = 1.0;
$DamageScale[psfemale, $PlasmaDamageType] = 0.5;
$DamageScale[psfemale, $EnergyDamageType] = 0.7;
$DamageScale[psfemale, $MissileDamageType] = 1.0;
$DamageScale[psfemale, $DebrisDamageType] = 0.7;
$DamageScale[psfemale, $LaserDamageType] = 1.0;
$DamageScale[psfemale, $ElectricityDamageType] = 1.0;
$DamageScale[psfemale, $SBulletDamageType] = 1.0;
$DamageScale[psfemale, $PBulletDamageType] = 1.0;
$DamageScale[psfemale, $FreezeDamageType] = 1.0;
$DamageScale[psfemale, $FlashDamageType] = 1.0; 
$DamageScale[psfemale, $MiniDamageType] = 1.0;
$DamageScale[psfemale, $FunkDamageType] = 0.0;
$DamageScale[psfemale, $ConfettiDamageType] = 0.0;
$DamageScale[psfemale, $SniperDamageType] = 0.5;

$ItemMax[psfemale, Blaster] = 1;
$ItemMax[psfemale, Tazer] = 0;
$ItemMax[psfemale, Funk] = 1;
$ItemMax[psfemale, FreezeGun] = 0;
$ItemMax[psfemale, Disclauncher] = 0;
$ItemMax[psfemale, GrenadeLauncher] = 0;
$ItemMax[psfemale, Mortar] = 0;
$ItemMax[psfemale, Flamethrower] = 0;
$ItemMax[psfemale, EnergyRifle] = 1;
$ItemMax[psfemale, LP]  = 0;
$ItemMax[psfemale, RL]  = 0;
$ItemMax[psfemale, MG]  = 0;
$ItemMax[psfemale, FL]  = 0;
$ItemMax[psfemale, FP]  = 0;
$ItemMax[psfemale, PC]  = 0;
$ItemMax[psfemale, SP]  = 0;
$ItemMax[psfemale, BH]  = 0;
$ItemMax[psfemale, Shotgun1] = 0;
$ItemMax[psfemale, AR] = 0;
$ItemMax[psfemale, SR] = 0;
$ItemMax[psfemale, TB] = 0;
$ItemMax[psfemale, F] = 0;
$ItemMax[psfemale, EL] = 1;
$ItemMax[psfemale, Beam] = 1;
$ItemMax[psfemale, Sword] = 1;
$ItemMax[psfemale, Multi] = 1;
$ItemMax[psfemale, HG] = 0;
$ItemMax[psfemale, PGL] = 0;
$ItemMax[psfemale, SmokeLauncher] = 0;
$ItemMax[psfemale, Shock] = 1;
$ItemMax[psfemale, V] = 0;
$ItemMax[psfemale, TargetingLaser] = 1;

$ItemMax[psfemale, AirMineAmmo] = 2;
$ItemMax[psfemale, MineAmmo] = 2;
$ItemMax[psfemale, Grenade] = 10;
$ItemMax[psfemale, Beacon]  = 1;
$ItemMax[psfemale, RepairKit] = 1;

$ItemMax[psfemale, HGAmmo] = 10;
$ItemMax[psfemale, SmokeAmmo] = 0;
$ItemMax[psfemale, MultiAmmo] = 10;
$ItemMax[psfemale, DiscAmmo] = 0;
$ItemMax[psfemale, GrenadeAmmo] = 0;
$ItemMax[psfemale, MortarAmmo] = 0;
$ItemMax[psfemale, RLAmmo] = 0;
$ItemMax[psfemale, MGAmmo] = 0;
$ItemMax[psfemale, SPAmmo] = 9;
$ItemMax[psfemale, Shotgun1Ammo] = 2;
$ItemMax[psfemale, ARAmmo] = 30;
$ItemMax[psfemale, SRAmmo] = 5;
$ItemMax[psfemale, FAmmo] = 0;
$ItemMax[psfemale, ELAmmo] = 1;
$ItemMax[psfemale, PGLAmmo] = 10;

$ItemMax[psfemale, BeamPack] = 1;
$ItemMax[psfemale, DemiPack] = 0;
$ItemMax[psfemale, SuperPack1] = 0;
$ItemMax[psfemale, SuperPack2] = 0;
$ItemMax[psfemale, THPack] = 0;
$ItemMax[psfemale, ControlPack] = 0;
$ItemMax[psfemale, SolarPack] = 0;
$ItemMax[psfemale, FreezePack] = 0;
$ItemMax[psfemale, PadPack] = 0;
$ItemMax[psfemale, VehPack] = 0;
$ItemMax[psfemale, RepairPack] = 1;
$ItemMax[psfemale, ShieldPack] = 0;
$ItemMax[psfemale, SensorJammerPack] = 1;
$ItemMax[psfemale, MotionSensorPack] = 1;
$ItemMax[psfemale, PulseSensorPack] = 1;
$ItemMax[psfemale, DeployableSensorJammerPack] = 1;
$ItemMax[psfemale, CameraPack] = 1;
$ItemMax[psfemale, TurretPack] = 0;
$ItemMax[psfemale, AmmoPack] = 1;
$ItemMax[psfemale, DeployableInvPack] = 0;
$ItemMax[psfemale, DeployableAmmoPack] = 0;
$ItemMax[psfemale, LaserPack] = 0;
$ItemMax[psfemale, Laser2Pack] = 0;
$ItemMax[psfemale, CDPack] = 1;
$ItemMax[psfemale, CSDPack] = 0;
$ItemMax[psfemale, TLPack] = 0;
$ItemMax[psfemale, PCDPack] = 1;
$ItemMax[psfemale, DTurretPack] = 0;
$ItemMax[psfemale, DEPack] = 0;
$ItemMax[psfemale, ForceFieldPack] = 0;
$ItemMax[psfemale, CTurretPack] = 0;
$ItemMax[psfemale, FTPack] = 0;
$ItemMax[psfemale, TGPack] = 0;
$ItemMax[psfemale, M350Pack] = 0;
$ItemMax[psfemale, PTPack] = 0;

$MaxWeapons[psfemale] = 3;

PlayerData psfemale
{
	className = "Armor";
	shapeFile = "mfemale";
	damageSkinData = "armorDamageSkins";
	debrisId = PsychoDebris;
	flameShapeName = "shockwave_large";
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = true;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = false;
	maxJetSideForceFactor = 1.0;
	maxJetForwardVelocity = 18;
	minJetEnergy = 1;
	jetForce = 430;
	jetEnergyDrain = 1.0;
	maxDamage = 1.0;
	maxForwardSpeed = 9.0;
	maxBackwardSpeed = 9.0;
	maxSideSpeed = 9.0;
	groundForce = 35 * 13.0;
	mass = 13.0;
	groundTraction = 4.0;
	maxEnergy = 90;
	drag = 1.0;
	density = 1.5;
	minDamageSpeed = 25;
	damageScale = 0.005;
	jumpImpulse = 110;
	jumpSurfaceMinDot = 0.2;

	// animation data:
	// animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, false, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, false, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, false, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, false, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, false, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, false, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, false, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, false, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, false, false, false, false, 3 };
   //animData[19] = { "jet", none, 1, true, true, true, false, 3 };
   animData[19] = { "Fall controlled", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, false, false, false, false, 3 };
   animData[21] = { "throw", none, 1, false, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, false, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundM1PlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundM1PlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
   animData[38] = { "sign over here",  none, 1, false, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, false, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, false, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, false, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, false, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, false, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, false, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, false, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, false, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, false, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, false, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, false, false, false, true, 1 };

   // Bonus wave
   animData[50] = { "wave", none, 1, false, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//--------------------------------------------------------------------------