--------------------
UltraVX for Tribes2
Installation Guide
--------------------
----------------------------------------------
UltraVXAuthor
HTTP://PlanetTribes.com/UltraVX
UltraVXAuthor@PlanetTribes.com
----------------------------------------------

UltraVX Installation instructions:

1.Unzip the UltraVX folder to the Tribes2\GameData folder
In other words,these files should exist
Tribes2\GameData\UltraVX\scripts.vl2
and
Tribes2\GameData\UltraVX\prefs\ServerPrefs.cs

2.Make a shortcut to the mod
//------------------------------------------------------------------------------
  For dedicated servers-
//------------------------------------------------------------------------------
Make a shortcut to your "Tribes2\GameData\ispawn.exe" file by right clicking
on it and "Create Shortcut"

Then,right click on this newly created shortcut and "Properties"

You should see a "Target" line highlighted and it will look similar to
"C:\Program Files\Tribes2\GameData\ispawn.exe"

Add this to the end of that "Target" line
 28000 Tribes2 -dedicated -mod UltraVX
 
It should look like
"C:\Program Files\Tribes2\GameData\ispawn.exe" 28000 Tribes2 -dedicated -mod UltraVX

or if your "Target" line does not have quotes "" it will look like
C:\Program Files\Tribes2\GameData\ispawn.exe 28000 Tribes2 -dedicated -mod UltraVX

//------------------------------------------------------------------------------
  For nondedicated servers-
//------------------------------------------------------------------------------
Make a shortcut to your "Tribes2\GameData\Tribes2.exe" file by right clicking
on it and "Create Shortcut"

Then,right click on this newly created shortcut and "Properties"

You should see a "Target" line highlighted and it will look similar to
"C:\Program Files\Tribes2\GameData\Tribes2.exe"

Add this to the end of that "Target" line
 -online -mod UltraVX
 
It should look like
"C:\Program Files\Tribes2\GameData\Tribes2.exe" -online -mod UltraVX

or if your "Target" line does not have quotes "" it will look like
C:\Program Files\Tribes2\GameData\Tribes2.exe -online -mod UltraVX

3.Run the mod shortcut by double clicking on it

No-Rail-No-Fog is also included.This is a server side CTF map
created by UltraVXAuthor and MLK Sexy Dexy
----------------------------------------------
UltraVXAuthor
HTTP://PlanetTribes.com/UltraVX
UltraVXAuthor@PlanetTribes.com
----------------------------------------------