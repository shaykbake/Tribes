$Host::allowAdminPlayerVotes = 0;
$Host::GameName = "UltraVX Tribes 2";
$Host::Info = "MOD:PlanetTribes.com/UltraVX";
$Host::MaxPlayers = 16;
