function AdminLogFile::addEntry(%admin, %phrase) {
	AdminLogFile::addEntryInternal(%phrase @ " - " @ Client::getIdentifierText(%admin));
}

function AdminLogFile::addEntry2(%admin, %client, %phrase) {
	AdminLogFile::addEntryInternal(%phrase @ " - admin: " @ Client::getIdentifierText(%admin) @ " client: " @ Client::getIdentifierText(%client));
}

// for use by hosts or remote admins
function AdminLogFile::clear() {
	$AdminLogFile::entry = "(cleared)";
	export("$AdminLogFile::entry", "config\\adminLog.cs", false);
}

function Client::getIdentifierText(%instance) {
	return Client::getName(%instance) @ " (" @ Client::getTransportAddress(%instance) @ ")";
}

function AdminLogFile::addEntryInternal(%text) {
	$AdminLogFile::entry = %text;
	export("$AdminLogFile::entry", "config\\adminLog.cs", true);
}
