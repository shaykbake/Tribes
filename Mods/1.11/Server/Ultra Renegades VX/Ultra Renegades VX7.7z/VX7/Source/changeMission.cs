focusServer
setcat missionName $1 ".mis"
loadMission $missionName
focusClient
