$AnonymousNameList::loadedFromDisk = false;

function AnonymousNameList::loadFromDisk() {
	exec("VX7AnonymousNameList.cs");
}

function AnonymousNameList::reloadFromDisk() {
	AnonymousNameList::clear();
	AnonymousNameList::loadFromDisk();
}

function AnonymousNameList::clear() {
	echo("Clearing in-memory list.");

	%i = 0;
	while ($AnonymousNameList::array[%i] != "") {
		$AnonymousNameList::array[%i] = "";
		%i++;
	}
}

function AnonymousNameList::getAddress(%name) {
	if (!$AnonymousNameList::loadedFromDisk) {
		AnonymousNameList::loadFromDisk();
		$AnonymousNameList::loadedFromDisk = true;
	}

	%persistentName = String::toPersistentString(%name);
	%i = 0;
	while ((%s = $AnonymousNameList::array[%i]) != "") {
		if (String::compare(getWord(%s, 0), %persistentName) == 0) {
			if ((%address = getWord(%s, 1)) != -1) {
				return %address;
			}
		}
		%i++;
	}

	return "";
}
