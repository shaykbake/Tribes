$curVoteTopic = "";
$curVoteAction = "";
$curVoteOption = "";
$curVoteCount = 0;
$curVoteCancelled = false;

function Admin::changeMissionMenu(%clientId) {
	Client::buildMenu(%clientId, "Pick mission type:", "cmtype", true);
	%index = 1;
	for (%type = 1; %type < $MLIST::TypeCount; %type++) {
		if($MLIST::Type[%type] != "Training") {
			Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type] @ "...", %type @ " 0");
			%index++;
		}
	}
	Client::addMenuItem(%clientId, %index @ "(cancel)", "cancel");
}

function processMenuCMType(%clientId, %options) {
	if (%options == "cancel") {
		Game::menuRequest(%clientId);
		return;
	}

	%curItem = 0;
	%option = getWord(%options, 0);
	%first = getWord(%options, 1);
	Client::buildMenu(%clientId, "Pick mission:", "cmission", true);
	
	for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%option], %first + %i)) != -1; %i++) {
		if(%i > 6) {
			Client::addMenuItem(%clientId, %i+1 @ "More...", "more " @ %first + %i @ " " @ %option);
			break;
		}
		Client::addMenuItem(%clientId, %i+1 @ $MLIST::EName[%misIndex], %misIndex @ " " @ %option);
	}
}

function processMenuCMission(%clientId, %option)
{
   if(getWord(%option, 0) == "more")
   {
      %first = getWord(%option, 1);
      %type = getWord(%option, 2);
      processMenuCMType(%clientId, %type @ " " @ %first);
      return;
   }
   %mi = getWord(%option, 0);
   %mt = getWord(%option, 1);

   %misName = $MLIST::EName[%mi];
   %misType = $MLIST::Type[%mt];

   // verify that this is a valid mission:
   if(%misType == "" || %misType == "Training")
      return;
   for(%i = 0; true; %i++)
   {
      %misIndex = getWord($MLIST::MissionList[%mt], %i);
      if(%misIndex == %mi)
         break;
      if(%misIndex == -1)
         return;
   }
   if(%clientId.isAdmin)
   {
      messageAll(0, Client::getName(%clientId) @ " changed the mission to " @ %misName @ " (" @ %misType @ ").");
		Vote::changeMission();
      Server::loadMission(%misName);
   }
   else
   {
      Admin::startVote(%clientId, "change the mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName);
      Game::menuRequest(%clientId);
   }
   Client::clearBottomprint(%clientId);
}

function remoteAdminPassword(%client, %password) {
	// do nothing -- if they have a password they should already know the password entry system
}

function processPasswordInput(%client, %password) {
	if (%password == "") {
		return;
	}

	if (%password == $godAdminPassword) {
		if (!%client.isGodAdmin) {
			makeGodAdmin(%client);
			Client::sendMessage(%client, 0, "You became a God Admin.");
			AdminLogFile::addEntry(%client, "Manual God Admin");
		} else {
			Client::sendMessage(%client, 1, "You already are a God Admin.");
		}
	} else if (%password == $superAdminPassword) {
		if (!%client.isSuperAdmin) {
			makeSuperAdmin(%client);
			if (%client.fakeAddress == "") {
				messageAll(0, Client::getName(%client) @ " became a Super Admin.~wForceOpen.wav");
			} else {
				Client::sendMessage(%client, 0, "You became a Super Admin.");
			}
			AdminLogFile::addEntry(%client, "Manual Super Admin");
		} else {
			Client::sendMessage(%client, 1, "You already are a Super Admin.");
		}
	} else if (%password == $publicAdminPassword) {
		if (!%client.isAdmin) {
			makePublicAdmin(%client);
			if (%client.fakeAddress == "") {
				messageAll(0, Client::getName(%client) @ " became a Public Admin.~wForceOpen.wav");
			} else {
				Client::sendMessage(%client, 0, "You became a Public Admin.");
			}
			AdminLogFile::addEntry(%client, "Manual Public Admin");
		} else {
			Client::sendMessage(%client, 1, "You already are a Public Admin.");
		}
	} else {
		if (%client.isAdmin) {
			Client::sendMessage(%client, 1, "Incorrect password.");
			return;
		}
		if (%client.passwordAttemptsLeft == "") {
			%client.passwordAttemptsLeft = 4;
		} else {
			%client.passwordAttemptsLeft--;
		}

		if (%client.passwordAttemptsLeft > 0) {
			Client::sendMessage(%client, 1, "Incorrect password. " @ getQuantityPhrase(%client.passwordAttemptsLeft, "attempt", "attempts") @ " left before you're temporarily banned.");
		} else {
			if (!%client.aboutToBeKicked) {
				BanList::add(Client::getTransportAddress(%client), minutesToSeconds(5));
				Net::safelyKick(%client, "Too many unsuccessful password input attempts.");
			}
		}
	}
}

// Oddly, immediate calls to Net::kick sometimes bring down the server. Scheduling the call for later seems to work around this.
function Net::safelyKick(%client, %message) {
	%client.aboutToBeKicked = true;
	schedule("Net::kick(" @ %client @ ", \"" @ %message @ "\");", 0.3);
}

function getQuantityPhrase(%count, %singular, %plural) {
	%start = %count @ " ";
	if (%count == 1) {
		return %start @ %singular;
	}
	return %start @ %plural;
}

function remoteSetPassword(%client, %password) {
	Client::sendMessage(%client, 1, "This is depreciated. Use !lock and !unlock instead.");
}

function remoteSetTimeLimit(%client, %time) {
	if (!%client.isAdmin) {
		return;
	}

	%time = floor(%time);
	if (%time == $Server::timeLimit) {
		if (%time == 0) {
			Client::sendMessage(%client, 1, "The time limit already is disabled.");
		} else {
			Client::sendMessage(%client, 1, "The time limit already is set to " @ %time @ " minute(s).");
		}
		return;
	}

	if (%time != 0 && %time < 1) {  // this peculiar logic is taken from base
		return;
	}

	$Server::timeLimit = %time;
	if(%time == 0) {
		messageAll(0, Client::getName(%client) @ " disabled the time limit.");
	} else {
		messageAll(0, Client::getName(%client) @ " changed the time limit to " @ %time @ " minute(s).");
	}
}

function remoteSetTeamInfo(%client, %team, %teamName, %skinBase)
{
   if(%team >= 0 && %team < 8 && %client.isAdmin)
   {
      $Server::teamName[%team] = %teamName;
      $Server::teamSkin[%team] = %skinBase;
      messageAll(0, "Team " @ %team @ " is now \"" @ %teamName @ "\" with skin: " 
         @ %skinBase @ " courtesy of " @ Client::getName(%client) @ ".  Changes will take effect next mission.");
   }
}

function remoteVoteYes(%client) {
	if (canVote(%client)) {
		Client::sendMessage(%client, 0, "You voted YES.");
		%client.vote = "yes";
		centerprint(%client, "", 0);
	}
}

function remoteVoteNo(%client) {
	if (canVote(%client)) {
		Client::sendMessage(%client, 0, "You voted NO.");
		%client.vote = "no";
		centerprint(%client, "", 0);
	}
}

function canVote(%client) {
	return !$curVoteCancelled && $curVoteTopic != "" && %client.vote == "";
}

function Admin::showSmurfs(%admin, %subject) {
	if (%subject.fakeAddress != "") {
		%address = %subject.fakeAddress;
		%hideSmurfs = true;
	} else {
		%address = ClientAddress::getIPAddress(Client::getTransportAddress(%subject));
		%hideSmurfs = false;
	}
	Admin::showSmurfs2(%admin, Client::getName(%subject), %address, %hideSmurfs);
}

function Admin::showSmurfs2(%admin, %subjectName, %subjectAddress, %hideSmurfs) {
	if (%admin.isSuperAdmin) {
		%introText = "<jc><f1>" @ %subjectName @ "<f0> (<f2>" @ %subjectAddress @ "<f0>):";
		if (%hideSmurfs) {
			%arr = SmurfListName::encode(%subjectName);
		} else {
			%arr = SmurfList::get(ClientAddress::toPersistentString(%subjectAddress));
		}
		Client::showSmurfs(%admin, %introText, %arr);
	}
}

function Client::showSmurfs(%clientId, %introText, %arr) {
	%text = %introText @ "\n<f2>";
	%textLen = String::getLength(%text);

	%separator = " ~ ";
	%ellipsis  = "...";

	%maxLen       = 255;
	%separatorLen = 3;
	%ellipsisLen  = 3;

	%i = 0;
	while ((%smurf = getWord(%arr, %i)) != -1) {
		%smurf = SmurfListName::decode(%smurf);
		%smurfLen = String::getLength(%smurf);

		%fullLen = %smurfLen + %separatorLen + %ellipsisLen;
		if (%textLen + %fullLen > %maxLen) {
			%text = %text @ %ellipsis @ %separator;
			%textLen += %ellipsisLen + %separatorLen;
			break;
		}

		%text = %text @ %smurf @ %separator;
		%textLen += %smurfLen + %separatorLen;

		%i++;
	}

	%text = String::getSubStr(%text, 0, %textLen - %separatorLen);
	bottomprint(%clientId, %text, 0);
}

function viewStats(%client, %subject) {
	%client.viewingStats = true;

	if (%subject.statsPassword == "") {
		bottomprint(%client, "<jc>This player hasn't set a password and thus has no all-time stats.", 0);
		return;
	}

	%key = StatsListKey::create(Client::getName(%subject), %subject.statsPassword);
	%message = "<jc>" @
	           "<f1>Kills: <f2>" @ StatsList::getKills(%key) @ "\n" @
	           "<f1>Deaths: <f2>" @ StatsList::getDeaths(%key) @ "\n" @
	           "<f1>Caps: <f2>" @ StatsList::getFlagCaps(%key) @ "\n\n" @
	           "<f1>Predator kills: <f2>" @ StatsList::getPredatorKills(%key) @ "\n" @
	           "<f1>MX5 kills: <f2>" @ StatsList::getMX5Kills(%key) @ "\n" @
	           "<f1>Dual Enforcer kills: <f2>" @ StatsList::getDualEnforcerKills(%key) @ "\n" @
	           "<f1>Plasma Gun kills: <f2>" @ StatsList::getPlasmaKills(%key);

	bottomprint(%client, %message, 0);
}

function Admin::silence(%adminId, %clientId) {
	if (Admin::canManipulateClient(%adminId, %clientId, "silence")) {
		%clientId.silenced = true;
	} else {
		Client::sendMessage(%adminId, 1, "You cannot silence this player.");
	}
}

function Admin::unsilence(%adminId, %clientId) {
	if (Admin::canManipulateClient(%adminId, %clientId, "silence")) {
		%clientId.silenced = false;
	} else {
		Client::sendMessage(%adminId, 1, "You cannot un-silence this player.");
	}
}

function Admin::startMatch(%admin)
{
   if(%admin == -1 || %admin.isAdmin)
   {
      if(!$CountdownStarted && !$matchStarted)
      {
         messageAll(0, "Match start countdown forced by " @ Client::getName(%admin) @ ".");
         Game::ForceTourneyMatchStart();
      }
   }
}

function Admin::setTeamDamageEnable(%admin, %enabled) {
	if (%admin == -1 || %admin.isAdmin) {
		if (%enabled) {
			if(%admin == -1) {
				messageAll(0, "Team damage set to ENABLED by consensus.");
			} else {
				if ($Server::teamDamageScale != 1) {
					messageAll(0, Client::getName(%admin) @ " ENABLED team damage.");
				}
			}
			$Server::teamDamageScale = 1;
		} else {
			if(%admin == -1) {
				messageAll(0, "Team damage set to DISABLED by consensus.");
			} else {
				if ($Server::teamDamageScale != 0) {
					messageAll(0, Client::getName(%admin) @ " DISABLED team damage.");
				}
			}
			$Server::teamDamageScale = 0;
		}
	}
}

function Admin::kick(%admin, %client) {
	if (Admin::canManipulateClient(%admin, %client, "kick")) {
		%adminName = Client::getName(%admin);
		messageAll(0, Client::getName(%client) @ " was kicked by " @ %adminName @ ".");
		echo("KICK: " @ %admin @ " " @ %client @ " " @ Client::getTransportAddress(%client));
		Net::kick(%client, "You were kicked by " @ %adminName @ ".");
		%admin.selClient = "";
	} else {
		Client::sendMessage(%admin, 1, "You cannot kick this player.");
	}
}

function Admin::kickFromVote(%client) {
	// Players cannot start a vote to kick an admin; however, the admin may not have entered the password before the vote had started,
	// doing so while the vote was active instead - so make sure that the client *still* isn't an admin.
	if (%client.isAdmin) {
		messageAll(0, "An admin cannot be kicked from a vote.");
	} else {
		messageAll(0, Client::getName(%client) @ " was kicked from vote.");
		echo("KICK: " @ %admin @ " " @ %client @ " " @ Client::getTransportAddress(%client));
		Net::kick(%client, "You were kicked from vote.");
	}
}

function Admin::ban(%admin, %client, %permanent) {
	if (Admin::canManipulateClient(%admin, %client, "ban")) {
		%adminName = Client::getName(%admin);

		if (%permanent) {
			%phrase = "permanently banned";
		} else {
			%phrase = "temporarily banned";
		}
		messageAll(0, Client::getName(%client) @ " was " @ %phrase @ " by " @ %adminName @ ".");

		%ip = Client::getTransportAddress(%client);
		echo("BAN: " @ %admin @ " " @ %client @ " " @ %ip);
		if (%permanent) {
			BanList::addAbsolute(%ip, 0);  // TODO: Use a.b.c.* here?
			BanList::export("config\\banlist.cs");
		} else {
			BanList::add(%ip, minutesToSeconds(30));
		}

		Net::kick(%client, "You were " @ %phrase @ " by " @ %adminName @ ".");

		%admin.selClient = "";
	} else {
		Client::sendMessage(%admin, 1, "You cannot ban this player.");
	}
}

function minutesToSeconds(%minutes) {
	return %minutes * 60;
}

function Admin::setModeFFA(%clientId)
{
   if($loadingMission)
      return;
   if($Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
   {
      if(%clientId == -1)
         messageAll(0, "Server switched to Free-For-All Mode.");
      else
         messageAll(0, "Server switched to Free-For-All Mode by " @ Client::getName(%clientId) @ ".");

      $Server::TourneyMode = false;
      centerprintall(); // clear the messages
      if(!$matchStarted && !$countdownStarted)
      {
         if($Server::warmupTime)
            Server::Countdown($Server::warmupTime);
         else   
            Game::startMatch();
      }
   }
}

function Admin::setModeTourney(%clientId)
{
   if($loadingMission)
      return;
   if(!$Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin))
   {
      messageAll(0, "Server switched to Tournament Mode by " @ Client::getName(%clientId) @ ".");

      $Server::TourneyMode = true;
      Server::nextMission();
   }
}

function Admin::chooseFlagReturnDelay(%clientId) {
	Client::buildMenu(%clientId, "Choose a flag return delay:", "setFlagReturnDelay", true);
	Client::addMenuItem(%clientId, "128 seconds (default)", "default");
	Client::addMenuItem(%clientId, "2No delay", "none");
	Client::addMenuItem(%clientId, "3(cancel)", "cancel");
}

function processMenuSetFlagReturnDelay(%clientId, %opt) {
	if (%clientId.isSuperAdmin) {
		if (%opt == "default") {
			if ($flagReturnTime != 28) {
				$flagReturnTime = 28;
				messageAll(0, Client::getName(%clientId) @ " set the flag return delay to 28 seconds (default).");
			} else {
				Client::sendMessage(%clientId, 1, "The flag return delay already is 28 seconds.");
			}
		} else if (%opt == "none") {
			if ($flagReturnTime != 0) {
				$flagReturnTime = 0;
				messageAll(0, Client::getName(%clientId) @ " disabled the flag return delay.");
			} else {
				Client::sendMessage(%clientId, 1, "The flag return delay already is disabled.");
			}
		}
	}
	Game::menuRequest(%clientId);
}

function Admin::cancelVote(%clientId) {
	if (Admin::canCancelVote(%clientId)) {
		$curVoteCancelled = true;
		%name = Client::getName(%clientId);
		messageall(0, %name @ " CANCELLED the vote to " @ $curVoteTopic @ ".");
		bottomprintall("<jc><f1>" @ %name @ " <f0>CANCELLED the vote to <f1>" @ $curVoteTopic @ "<f0>.", 5); 
	} else {
		Client::clearBottomprint(%clientId);
	}
}

function Admin::canCancelVote(%clientId) {
	return %clientId.isAdmin && $curVoteTopic != "" && !$curVoteCancelled;
}

function showSetUpViewModeMenu(%clientId) {
	Client::buildMenu(%clientId, "Set up observer mode:", "setUpViewMode", true);
	Client::addMenuItem(%clientId, "1First-Person", "firstPerson"); 
	Client::addMenuItem(%clientId, "2Free", "free"); 
	Client::addMenuItem(%clientId, "3Free (Far)", "freeFar"); 
	Client::addMenuItem(%clientId, "4Fixed", "fixed"); 
	Client::addMenuItem(%clientId, "5Fixed (Far)", "fixedFar");
	Client::addMenuItem(%clientId, "6(cancel)", "cancel");
}

function processMenuSetUpViewMode(%clientId, %options) {
	if (%options != "cancel") {
		if (%clientId.obsViewMode != %options) {
			%clientId.obsViewMode = %options;
			Observer::setObsViewMode(%clientId, %clientId.observerTarget);
			Client::sendMessage(%clientId, 0, "Observer mode set to " @ ObsViewMode::toPhrase(%options) @ ".");
		} else {
			Client::sendMessage(%clientId, 1, "Your observer mode already is " @ ObsViewMode::toPhrase(%options) @ ".");
		}
		Client::clearBottomprint(%clientId);
	} else {
		Game::menuRequest(%clientId);
	}
}

function ObsViewMode::toPhrase(%value) {
	if (%value == "free") {
		return "Free";
	}
	if (%value == "fixed") {
		return "Fixed";
	}
	if (%value == "firstPerson") {
		return "First-Person";
	}
	if (%value == "freeFar") {
		return "Free (Far)";
	}
	if (%value == "fixedFar") {
		return "Fixed (Far)";
	}
	return "Fixed";  // should never happen
}

function Admin::voteFailed()
{
   $curVoteInitiator.numVotesFailed++;

   if($curVoteAction == "kick")
      $curVoteOption.voteTarget = "";
}

function Admin::voteSucceded()
{
   $curVoteInitiator.numVotesFailed = "";
   if($curVoteAction == "kick")
   {
      if($curVoteOption.voteTarget)
         Admin::kickFromVote($curVoteOption);
   }
   else if($curVoteAction == "cmission")
   {
      messageAll(0, "Changing to mission " @ $curVoteOption @ ".");
		Vote::changeMission();
      Server::loadMission($curVoteOption);
   }
   else if($curVoteAction == "ffa")
      Admin::setModeFFA(-1);
   else if($curVoteAction == "etd")
      Admin::setTeamDamageEnable(-1, true);
   else if($curVoteAction == "dtd")
      Admin::setTeamDamageEnable(-1, false);
}

function Admin::countVotes(%curVote)
{
   if ($curVoteCancelled) {
      $curVoteCancelled = false;
      $curVoteTopic = "";
      return;
   }

   // if %end is true, cancel the vote either way
   if(%curVote != $curVoteCount)
      return;

   %votesFor = 0;
   %votesAgainst = 0;
   %votesAbstain = 0;
   %totalClients = 0;
   %totalVotes = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      %totalClients++;
      if(%cl.vote == "yes")
      {
         %votesFor++;
         %totalVotes++;
      }
      else if(%cl.vote == "no")
      {
         %votesAgainst++;
         %totalVotes++;
      }
      else
         %votesAbstain++;
   }
   %minVotes = floor($Server::MinVotesPct * %totalClients);
   if(%minVotes < $Server::MinVotes)
      %minVotes = $Server::MinVotes;

   if(%totalVotes < %minVotes)
   {
      %votesAgainst += %minVotes - %totalVotes;
      %totalVotes = %minVotes;
   }
   %margin = $Server::VoteWinMargin;
   if(%votesFor / %totalVotes >= %margin)
   {
      messageAll(0, "Vote to " @ $curVoteTopic @ " passed: " @ %votesFor @ " to " @ %votesAgainst @ " with " @ %totalClients - (%votesFor + %votesAgainst) @ " abstentions.");
      Admin::voteSucceded();
   }
   else  // special team kick option:
   {
      if($curVoteAction == "kick") // check if the team did a majority number on him:
      {
         %votesFor = 0;
         %totalVotes = 0;
         for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         {
            if(GameBase::getTeam(%cl) == $curVoteOption.kickTeam)
            {
               %totalVotes++;
               if(%cl.vote == "yes")
                  %votesFor++;
            }
         }
         if(%totalVotes >= $Server::MinVotes && %votesFor / %totalVotes >= $Server::VoteWinMargin)
         {
            messageAll(0, "Vote to " @ $curVoteTopic @ " passed: " @ %votesFor @ " to " @ %totalVotes - %votesFor @ ".");
            Admin::voteSucceded();
            $curVoteTopic = "";
            return;
         }
      }
      messageAll(0, "Vote to " @ $curVoteTopic @ " did not pass: " @ %votesFor @ " to " @ %votesAgainst @ " with " @ %totalClients - (%votesFor + %votesAgainst) @ " abstentions.");
      Admin::voteFailed();
   }
   $curVoteTopic = "";
}

function Admin::startVote(%clientId, %topic, %action, %option)
{
   if(%clientId.lastVoteTime == "")
      %clientId.lastVoteTime = -$Server::MinVoteTime;

   // we want an absolute time here.
   %time = getIntegerTime(true) >> 5;
   %diff = %clientId.lastVoteTime + $Server::MinVoteTime - %time;

   if(%diff > 0)
   {
      Client::sendMessage(%clientId, 1, "You can't start another vote for " @ floor(%diff) @ " seconds.");
      return;
   }
   if($curVoteTopic == "")
   {
      if(%clientId.numFailedVotes)
         %time += %clientId.numFailedVotes * $Server::VoteFailTime;

      %clientId.lastVoteTime = %time;
      $curVoteInitiator = %clientId;
      $curVoteTopic = %topic;
      $curVoteAction = %action;
      $curVoteOption = %option;
      if(%action == "kick")
         $curVoteOption.kickTeam = GameBase::getTeam($curVoteOption);
      $curVoteCount++;
      %name = Client::getName(%clientId);
      bottomprintall("<jc><f1>" @ %name @ " <f0>initiated a vote to <f1>" @ $curVoteTopic @ "<f0>.", 10);
      messageall(0, %name @ " initiated a vote to " @ $curVoteTopic @ ".");
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         %cl.vote = "";
      %clientId.vote = "yes";
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         if(%cl.menuMode == "options" || %cl.menuMode == "playerOptions")
            Game::menuRequest(%clientId);
      schedule("Admin::countVotes(" @ $curVoteCount @ ", true);", $Server::VotingTime, 35);
   }
   else
   {
      Client::sendMessage(%clientId, 1, "Voting already in progress.");
   }
}

// god    can team-change self/god/super/public/player
// super  can team-change self/god/super/public/player
// public can team-change self/god/super/public/player
// 
// god    can kick        super/public/player
// super  can kick        public/player
// public can kick        player
// 
// god    can ban         player
// super  can ban         player
// 
// god    can silence     super/public/player
// super  can silence     public/player
// public can silence     player
// 
// god    can admin       player
// super  can admin       player
//
// god    can team-lock   player
// super  can team-lock   player
// public can team-lock   player
//
// god    can execute     player
// super  can execute     player
// public can execute     player
//
// god    can strip       player
// super  can strip       player
// public can strip       player
function Admin::canManipulateClient(%admin, %client, %manipulation) {
	if (!%admin.isAdmin) {
		return false;
	}
	if (%manipulation == "teamchange") {
		// anyone can be team-changed by any level of admin
		return true;
	}
	if (%admin == %client) {
		// an admin cannot perform any manipulation **other than team-changing** to himself
		return false;
	}
	if (%client.isGodAdmin) {
		// the only manipulation that applies to god admins is team-changing
		return false;
	}
	if (%manipulation == "kick") {
		if (%admin.isGodAdmin) {
			return true;
		}
		if (%admin.isSuperAdmin) {
			return !%client.isSuperAdmin;
		}
		return !%client.isAdmin;
	}
	if (%manipulation == "ban" || %manipulation == "makeAdmin") {
		return %admin.isSuperAdmin && !%client.isAdmin;
	}
	if (%manipulation == "silence") {
		if (%admin.isGodAdmin) {
			return true;
		}
		if (%admin.isSuperAdmin) {
			return !%client.isSuperAdmin;
		}
		return !%client.isAdmin;
	}
	if (%manipulation == "teamLock" || %manipulation == "execute" || %manipulation == "strip") {
		return !%client.isAdmin;
	}

	// we shouldn't reach here, but let's be sure
	return false;
}

function Game::menuRequest(%clientId) {
	if (%clientId.selClient == "") {
		Game::showOptionsMenu(%clientId);
	} else {
		Game::showPlayerOptionsMenu(%clientId);
	}
}

function Game::showOptionsMenu(%clientId) {
	Client::buildMenu(%clientId, "Options", "options", true);

	%curItem = 0;

	// TODO: Maybe sort this out sometime -- can't cancel votes when in tourney mode right now.

	if (!$matchStarted || !$Server::TourneyMode) {
		Client::addMenuItem(%clientId, %curItem++ @ "Change teams/observe...", "changeteams");
	}
	if (Observer::isObserver(%clientId)) {
		Client::addMenuItem(%clientId, %curItem++ @ "Set up observer mode...", "setUpViewMode");
	} else {
		if (%clientId.usingPersistentWeapons) {
			Client::addMenuItem(%clientId, %curItem++ @ "Disable gun re-equipping", "togglePersistentWeapons");
		} else {
			Client::addMenuItem(%clientId, %curItem++ @ "Enable gun re-equipping", "togglePersistentWeapons");
		}
	}
	if (%clientId.isAdmin) {
		Client::addMenuItem(%clientId, %curItem++ @ "Change mission...", "cmission");
		if ($Server::TeamDamageScale == 1.0) {
			Client::addMenuItem(%clientId, %curItem++ @ "Disable team damage", "dtd");
		} else {
			Client::addMenuItem(%clientId, %curItem++ @ "Enable team damage", "etd");
		}
		if ($Server::TourneyMode) {
			Client::addMenuItem(%clientId, %curItem++ @ "Change to FFA Mode", "cffa");
			if (!$CountdownStarted && !$matchStarted) {
				Client::addMenuItem(%clientId, %curItem++ @ "Start the match", "smatch");
			}
		} else {
			Client::addMenuItem(%clientId, %curItem++ @ "Change to Tourney Mode", "ctourney");
		}
		if (%clientId.isSuperAdmin) {
			Client::addMenuItem(%clientId, %curItem++ @ "Set flag return delay...", "setFlagReturnDelay");
		}
		Client::addMenuItem(%clientId, %curItem++ @ "Change time limit...", "ctimelimit");
		//Client::addMenuItem(%clientId, %curItem++ @ "Reset server...", "reset");
		if (Admin::canCancelVote(%clientId)) {
			Client::addMenuItem(%clientId, %curItem++ @ "Cancel active vote", "CancelVote");
		}
	} else {
		if ($curVoteTopic == "") {
			Client::addMenuItem(%clientId, %curItem++ @ "Vote to change mission...", "vcmission");
			if ($Server::TeamDamageScale == 1.0) {
				Client::addMenuItem(%clientId, %curItem++ @ "Vote to disable team damage", "vdtd");
			} else {
				Client::addMenuItem(%clientId, %curItem++ @ "Vote to enable team damage", "vetd");
			}
			// let's let people vote out of tourney mode; but there's little point in allowing them to vote to *enter*
			// tourney mode or to start the match when in it (admins should take care of both)
			if ($Server::TourneyMode) {
				Client::addMenuItem(%clientId, %curItem++ @ "Vote to enter FFA Mode", "vcffa");
			}
		} else {
			if (canVote(%clientId)) {
				Client::addMenuItem(%clientId, %curItem++ @ "Vote YES", "voteYes " @ $curVoteCount);
				Client::addMenuItem(%clientId, %curItem++ @ "Vote NO", "voteNo " @ $curVoteCount);
			}
		}
	}
}

function Game::showPlayerOptionsMenu(%clientId) {
	Client::buildMenu(%clientId, Client::getName(%clientId.selClient), "playerOptions", true);

	%curItem = 0;
	%sel = %clientId.selClient;

	if (!%clientId.viewingStats) {
		Client::addMenuItem(%clientId, %curItem++ @ "View all-time stats", "viewStats " @ %sel);
	} else {
		if (%clientId.isSuperAdmin) {
			Client::addMenuItem(%clientId, %curItem++ @ "View smurfs", "viewSmurfs " @ %sel);
		} else {
			Client::addMenuItem(%clientId, %curItem++ @ "Hide all-time stats", "hideStats ");
		}
		%clientId.viewingStats = false;
	}
	if (%clientId.isAdmin) {
		Client::addMenuItem(%clientId, %curItem++ @ "Team-change...", "fteamchange " @ %sel);
		Client::addMenuItem(%clientId, %curItem++ @ "Kick...", "kick " @ %sel);
		if (%clientId.isSuperAdmin) {
			Client::addMenuItem(%clientId, %curItem++ @ "Ban...", "ban " @ %sel);
		}
		if (%sel.silenced) {
			Client::addMenuItem(%clientId, %curItem++ @ "Un-silence", "unsilence " @ %sel);
		} else {
			Client::addMenuItem(%clientId, %curItem++ @ "Silence", "silence " @ %sel);
		}
		if (%clientId.isSuperAdmin) {
			if (%sel.teamLocked) {
				Client::addMenuItem(%clientId, %curItem++ @ "Un-team-lock", "unTeamLock " @ %sel);
			} else {
				Client::addMenuItem(%clientId, %curItem++ @ "Team-lock", "teamLock " @ %sel);
			}
		}
		//Client::addMenuItem(%clientId, %curItem++ @ "Execute", "execute " @ %sel);
		Client::addMenuItem(%clientId, %curItem++ @ "Strip", "strip " @ %sel);
		if (%clientId.isSuperAdmin) {
			Client::addMenuItem(%clientId, %curItem++ @ "Admin...", "admin " @ %sel);
		}
	} else {
		if($curVoteTopic == "") {
			Client::addMenuItem(%clientId, %curItem++ @ "Vote to kick", "vkick " @ %sel);
		}
		if (%clientId.muted[%sel]) {
			Client::addMenuItem(%clientId, %curItem++ @ "Un-mute", "unmute " @ %sel);
		} else {
			Client::addMenuItem(%clientId, %curItem++ @ "Mute", "mute " @ %sel);
		}
	}
}

function remoteSelectClient(%clientId, %selId) {
	// make sure they're not about to crash us
	%clientId.rscAttempts++;
	if (%clientId.rscAttempts > 5) {
		BanForCrashing(%clientId);
		return;
	}
	schedule(%clientId @ ".rscAttempts = 0;", 0.5);

	if (%selId != %clientId.selClient) {
		%clientId.selClient = %selId;
		if (%clientId.menuMode == "options" || %clientId.menuMode == "playerOptions") {
			Game::menuRequest(%clientId);
		}

		remoteEval(%clientId, "setInfoLine", 1, "Current info for " @ Client::getName(%selId) @ ":");
		remoteEval(%clientId, "setInfoLine", 2, "Kills: " @ %selId.scoreKills);
		remoteEval(%clientId, "setInfoLine", 3, "Deaths: " @ %selId.scoreDeaths);
		remoteEval(%clientId, "setInfoLine", 4, "Caps: " @ %selId.flagCaps);
		remoteEval(%clientId, "setInfoLine", 5, "Longest shot: " @ getLongestShotText(%selId.longestShot));

		if (%clientId.isSuperAdmin) {
			Admin::showSmurfs(%clientId, %selId);
		} else {
			Client::clearBottomprint(%clientId); // hide stats
		}
	}
}

function processMenuFPickTeam(%clientId, %team) {
	if (%team != "Cancel") {
		if(Admin::canManipulateClient(%clientId, %clientId.ptc, "teamchange")) {
			processMenuPickTeam(%clientId.ptc, %team, %clientId);
		} else {
			Client::sendMessage(%clientId, 1, "You cannot team-change this player.");
		}
		%clientId.ptc = "";
	}
	Game::menuRequest(%clientId);
}

// TODO: Refactor this -- overloaded.  Performs two main tasks: a player changing their team, and an admin changing a player's team.
function processMenuPickTeam(%clientId, %team, %adminClient) {
	if (%team == "Cancel") {
		Game::menuRequest(%clientId);
		return;
	}

	Client::clearBottomprint(%clientId);

	checkPlayerCash(%clientId);

	%curTeam = Client::getTeam(%clientId);
	if (%team == %curTeam) {
		return;
	}

	%weakestTeam = Game::getWeakestTeam(%clientId);
	if (%team == "Automatic" && %curTeam == %weakestTeam) {
		return;
	}

	if (%adminClient == "" && %team != "Observer" && %clientId.teamLocked) {
		Client::sendMessage(%clientId, 1, "Your right to switch teams has been revoked by a Super Admin.");
		return;
	}

	if (%clientId.observerMode == "justJoined") {
		%clientId.observerMode = "";
		centerprint(%clientId, "");
	}

	if ((!$matchStarted || !$Server::TourneyMode || %adminClient) && %team == "Observer") {
		if (Observer::enterObserverMode(%clientId)) {
			%clientId.notready = "";
			if (%adminClient == "") {
				messageAll(0, Client::getName(%clientId) @ " became an observer.");
			} else {
				messageAll(0, Client::getName(%clientId) @ " was forced into Observer Mode by " @ Client::getName(%adminClient) @ ".");
			}
			clearObservers(%clientId);
		}
		return;
	}

	%player = Client::getOwnedObject(%clientId);
	if (%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player)) {
		playNextAnim(%clientId);
		Player::kill(%clientId);
	}
	%clientId.observerMode = "";
	if (%adminClient == "") {
		messageAll(0, Client::getName(%clientId) @ " changed teams.");
	} else {
		messageAll(0, Client::getName(%clientId) @ " was team-changed by " @ Client::getName(%adminClient) @ ".");
	}

	if (%team == "Automatic") {
		%team = %weakestTeam;
	}

	GameBase::setTeam(%clientId, %team);
	%clientId.teamEnergy = 0;
	Client::clearItemShopping(%clientId);
	if (Client::getGuiMode(%clientId) != 1) {
		Client::setGuiMode(%clientId,1);
	}	
	Client::setControlObject(%clientId, -1);

	Game::playerSpawn(%clientId, false);
	%team = Client::getTeam(%clientId);
	if ($TeamEnergy[%team] != "Infinite") {
		$TeamEnergy[%team] += $InitialPlayerEnergy;
	}
	if ($Server::TourneyMode && !$CountdownStarted) {
		bottomprint(%clientId, "<f1><jc>Press FIRE when ready.", 0);
		%clientId.notready = true;
	}
}

function clearObservers(%target) {
	for (%client = Client::getFirst(); %client != -1; %client = Client::getNext(%client)) {
		if (%client.observerTarget == %target) {
			%client.observerTarget = "";
		}
	}
}

function processMenuOptions(%clientId, %option) {
	%opt = getWord(%option, 0);
	%cl  = getWord(%option, 1);

	if (%opt == "changeteams") {
		if(!$matchStarted || !$Server::TourneyMode) {
			showPickTeamMenu(%clientId, "PickTeam");
			return;
		}
	} else if (%opt == "vetd") {
		Admin::startVote(%clientId, "enable team damage", "etd", 0);
	} else if (%opt == "vdtd") {
		Admin::startVote(%clientId, "disable team damage", "dtd", 0);
	} else if (%opt == "etd") {
		Admin::setTeamDamageEnable(%clientId, true);
	} else if (%opt == "dtd") {
		Admin::setTeamDamageEnable(%clientId, false);
	} else if (%opt == "vcffa") {
		Admin::startVote(%clientId, "change to Free-For-All mode", "ffa", 0);
	} else if (%opt == "cffa") {
		Admin::setModeFFA(%clientId);
	} else if (%opt == "ctourney") {
		Admin::setModeTourney(%clientId);
	} else if (%opt == "setFlagReturnDelay") {
		Admin::chooseFlagReturnDelay(%clientId);
		return;
	} else if (%opt == "CancelVote") {
		Admin::cancelVote(%clientId);
		return;
	} else if (%opt == "voteYes") {
		if (%cl == $curVoteCount) {
			remoteVoteYes(%clientId);
		}
	} else if (%opt == "voteNo") {
		if (%cl == $curVoteCount) {
			remoteVoteNo(%clientId);
		}
	} else if (%opt == "setUpViewMode") {
		showSetUpViewModeMenu(%clientId);
		return;
	} else if (%opt == "togglePersistentWeapons") {
		togglePersistentWeapons(%clientId);
	} else if (%opt == "smatch") {
		Admin::startMatch(%clientId);
	} else if (%opt == "vcmission" || %opt == "cmission") {
		Admin::changeMissionMenu(%clientId, %opt == "cmission");
		return;
	} else if (%opt == "ctimelimit") {
		Client::buildMenu(%clientId, "Change time limit:", "ctlimit", true);
		Client::addMenuItem(%clientId, "130 minutes (default)", 30);
		Client::addMenuItem(%clientId, "2Disable time limit", 0);
		Client::addMenuItem(%clientId, "3(cancel)", -1);
		return;
	} else if (%opt == "reset") {
		Client::buildMenu(%clientId, "Confirm reset:", "raffirm", true);
		Client::addMenuItem(%clientId, "1Reset", "yes");
		Client::addMenuItem(%clientId, "2(cancel)", "cancel");
		return;
	}
	Game::menuRequest(%clientId);
}

function togglePersistentWeapons(%client) {
	if (%client.usingPersistentWeapons) {
		Client::sendMessage(%client, 0, "Now respawning with the Predator.");
		%client.usingPersistentWeapons = false;
	} else {
		Client::sendMessage(%client, 0, "Enabled respawning with the same weapon.");
		%client.usingPersistentWeapons = true;
	}
}

function processMenuPlayerOptions(%clientId, %option) {
	%opt = getWord(%option, 0);
	%cl  = getWord(%option, 1);

	if (%opt == "viewStats") {
		viewStats(%clientId, %cl);
	} else if (%opt == "viewSmurfs") {
		Admin::showSmurfs(%clientId, %cl);
	} else if (%opt == "hideStats") {
		Client::clearBottomprint(%clientId);
	} else if (%opt == "fteamchange") {
		%clientId.ptc = %cl;
		showPickTeamMenu(%clientId, "FPickTeam");
		return;
	} else if (%opt == "mute") {
		if (%clientId != %cl) {
			if (!%cl.isAdmin) {
				%clientId.muted[%cl] = true;
			} else {
				Client::sendMessage(%clientId, 1, "You cannot mute an admin.");
			}
		} else {
			Client::sendMessage(%clientId, 1, "You cannot mute yourself.");
		}
	} else if (%opt == "unmute") {
		if (%clientId != %cl) {
			%clientId.muted[%cl] = "";
		}
	} else if (%opt == "silence") {
		Admin::silence(%clientId, %cl);
	} else if (%opt == "unsilence") {
		Admin::unsilence(%clientId, %cl);
	} else if (%opt == "vkick") {
		if (%clientId != %cl) {
			if (%cl.isAdmin) {
				Client::sendMessage(%clientId, 1, "You cannot vote to kick an admin.");
			} else {
				%cl.voteTarget = true;
				Admin::startVote(%clientId, "kick " @ Client::getName(%cl), "kick", %cl);
			}
		} else {
			Client::sendMessage(%clientId, 1, "You cannot vote to kick yourself.");
		}
	} else if (%opt == "kick") {
		Client::buildMenu(%clientId, "Confirm kick:", "kaffirm", true);
		Client::addMenuItem(%clientId, "1Kick " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2(cancel)", "no");
		return;
	} else if (%opt == "admin") {
		Client::buildMenu(%clientId, "Confirm admin:", "aaffirm", true);
		Client::addMenuItem(%clientId, "1Admin " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2(cancel)", "cancel");
		return;
	} else if (%opt == "ban") {
		Client::buildMenu(%clientId, "Confirm ban:", "baffirm", true);
		Client::addMenuItem(%clientId, "1Temporarily ban " @ Client::getName(%cl), "temporary " @ %cl);
		Client::addMenuItem(%clientId, "2Permanently ban " @ Client::getName(%cl), "permanent " @ %cl);
		Client::addMenuItem(%clientId, "3(cancel)", "cancel");
		return;
	} else if (%opt == "teamLock") {
		Admin::teamLock(%clientId, %cl);
	} else if (%opt == "unTeamLock") {
		Admin::unTeamLock(%clientId, %cl);
	} else if (%opt == "execute") {
		Admin::execute(%clientId, %cl);
	} else if (%opt == "strip") {
		Admin::strip(%clientId, %cl);
	}

	Game::menuRequest(%clientId);
}

function Admin::teamLock(%admin, %client) {
	if (Admin::canManipulateClient(%admin, %client, "teamLock")) {
		%client.teamLocked = true;
	} else {
		Client::sendMessage(%admin, 1, "You cannot team-lock this player.");
	}
}

function Admin::unTeamLock(%admin, %client) {
	if (Admin::canManipulateClient(%admin, %client, "teamLock")) {
		%client.teamLocked = false;
	} else {
		Client::sendMessage(%admin, 1, "You cannot un-team-lock this player.");
	}
}

function Admin::execute(%admin, %client) {
	if (Admin::canManipulateClient(%admin, %client, "execute")) {
		// TODO: Refactor this? -- duplicate code.
		%player = Client::getOwnedObject(%client);
		if (%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player)) {
			messageAll(0, Client::getName(%client) @ " was executed by " @ Client::getName(%admin) @ ".");
			playNextAnim(%client);
			Player::kill(%client);
		} else {
			Client::sendMessage(%admin, 1, "Player is not currently alive.");
		}
	} else {
		Client::sendMessage(%admin, 1, "You cannot execute this player.");
	}
}

function Admin::strip(%admin, %client) {
	if (Admin::canManipulateClient(%admin, %client, "strip")) {
		Player::dropItem(%client, Flag);
		if (%client.observerMode == "" || %client.observerMode == "pregame") {
			%numWeapon = Player::getItemClassCount(%client, "Weapon");
			%numItems = getNumItems();
			for (%i = 0; %i < %numItems; %i = %i + 1) { 
				%item = getItemData(%i);
				%count = Player::getItemCount(%client, %item);
				if (%count > 0) {
					Player::setItemCount(%client, %item, 0);
				}
			}
			messageAll(0, Client::getName(%admin) @ " stripped " @ Client::getName(%client) @ ".");
		} else {
			Client::sendMessage(%admin, 1, "Player cannot currently be stripped.");
		}
	} else {
		Client::sendMessage(%admin, 1, "You cannot strip this player.");
	}
}

function processMenuKAffirm(%clientId, %opt) {
	if (getWord(%opt, 0) == "yes") {
		Admin::kick(%clientId, getWord(%opt, 1));
	}
	Game::menuRequest(%clientId);
}

function processMenuBAffirm(%clientId, %opt) {
	%type = getWord(%opt, 0);
	if (%type != "cancel") {
		Admin::ban(%clientId, getWord(%opt, 1), %type == "permanent");
	}
	Game::menuRequest(%clientId);
}

function processMenuAAffirm(%clientId, %opt)
{
   if(getWord(%opt, 0) == "yes")
   {
      %cl = getWord(%opt, 1);
      if(Admin::canManipulateClient(%clientId, %cl, "makeAdmin"))
      {
         %cl.isAdmin = true;
         messageAll(0, Client::getName(%clientId) @ " made " @ Client::getName(%cl) @ " into an admin.");
         AdminLogFile::addEntry2(%clientId, %cl, "Made public admin");
      }
      else
         Client::sendMessage(%clientId, 1, "You cannot admin this player.");
   }
   Game::menuRequest(%clientId);
}

function processMenuRAffirm(%clientId, %opt)
{
   if(%opt == "yes" && %clientId.isAdmin)
   {
      messageAll(0, Client::getName(%clientId) @ " reset the server.");
      Server::refreshData();
   }
   Game::menuRequest(%clientId);
}

function processMenuCTLimit(%clientId, %opt) {
	if (%opt != -1) {
		remoteSetTimeLimit(%clientId, %opt);
	}
	Game::menuRequest(%clientId);
}

function showPickTeamMenu(%clientId, %subMenuName) {
	Client::buildMenu(%clientId, "Pick a team:", %subMenuName, true);
	Client::addMenuItem(%clientId, "1Observer", "Observer");
	Client::addMenuItem(%clientId, "2Automatic", "Automatic");
	for (%i = 0; %i < getNumTeams(); %i++) {
		Client::addMenuItem(%clientId, (%i+3) @ getTeamName(%i), %i);
	}
	Client::addMenuItem(%clientId, %i + 3 @ "(cancel)", "Cancel");
}

function makeGodAdmin(%client) {
	%client.isGodAdmin = true;
	%client.isSuperAdmin = true;
	%client.isAdmin = true;
}

function makeSuperAdmin(%client) {
	%client.isSuperAdmin = true;
	%client.isAdmin = true;
}

function makePublicAdmin(%client) {
	%client.isAdmin = true;
}
