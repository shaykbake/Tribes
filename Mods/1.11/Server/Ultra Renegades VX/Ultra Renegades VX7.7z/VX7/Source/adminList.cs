$AdminList::loadedFromDisk = false;

function AdminList::loadFromDisk() {
	exec("VX7AdminList.cs");
}

function AdminList::reloadFromDisk() {
	AdminList::clear();
	AdminList::loadFromDisk();
}

function AdminList::clear() {
	echo("Clearing in-memory list.");

	%i = 0;
	while ($AdminList::array[%i] != "") {
		$AdminList::array[%i] = "";
		%i++;
	}
}

function AdminList::getLevel(%ipAddress, %name) {
	if (!$AdminList::loadedFromDisk) {
		AdminList::loadFromDisk();
		$AdminList::loadedFromDisk = true;
	}

	%persistentName = String::toPersistentString(%name);
	%i = 0;
	while ((%s = $AdminList::array[%i]) != "") {
		if (String::compare(getWord(%s, 0), %ipAddress) == 0) {  // musn't use the equality operator here -- it converts the addresses to decimal numbers for the comparison
			%storedName = getWord(%s, 1);
			if (%storedName == "*" || String::iCompare(%persistentName, %storedName) == 0) {
				%level = getWord(%s, 2);
				if (%level == "god" || %level == "super" || %level == "public") {
					return %level;
				}
			}
		}
		%i++;
	}

	return "";
}
