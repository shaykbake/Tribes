$StatsList::fileName = "stats.cs";
$StatsList::loadedFromDisk = false;
$StatsList::unsavedChangesExist = false;

function StatsList::getKills(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 0, 0);
}
function StatsList::getDeaths(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 1, 0);
}
function StatsList::getFlagCaps(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 2, 0);
}
function StatsList::getPredatorKills(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 3, 0);
}
function StatsList::getMX5Kills(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 4, 0);
}
function StatsList::getDualEnforcerKills(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 5, 0);
}
function StatsList::getPlasmaKills(%key) {
	StatsList::ensureLoadedFromDisk();
	return getWordOr($StatsList::array[%key], 6, 0);
}

function StatsList::incrementKills(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key) + 1        , " ",
	                          StatsList::getDeaths(%key)           , " ",
	                          StatsList::getFlagCaps(%key)         , " ",
	                          StatsList::getPredatorKills(%key)    , " ",
	                          StatsList::getMX5Kills(%key)         , " ",
	                          StatsList::getDualEnforcerKills(%key), " ",
	                          StatsList::getPlasmaKills(%key)
	                          );
}
function StatsList::incrementDeaths(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key)            , " ",
	                          StatsList::getDeaths(%key) + 1       , " ",
	                          StatsList::getFlagCaps(%key)         , " ",
	                          StatsList::getPredatorKills(%key)    , " ",
	                          StatsList::getMX5Kills(%key)         , " ",
	                          StatsList::getDualEnforcerKills(%key), " ",
	                          StatsList::getPlasmaKills(%key)
	                          );
}
function StatsList::incrementFlagCaps(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key)            , " ",
	                          StatsList::getDeaths(%key)           , " ",
	                          StatsList::getFlagCaps(%key) + 1     , " ",
	                          StatsList::getPredatorKills(%key)    , " ",
	                          StatsList::getMX5Kills(%key)         , " ",
	                          StatsList::getDualEnforcerKills(%key), " ",
	                          StatsList::getPlasmaKills(%key)
	                          );
}
function StatsList::incrementPredatorKills(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key)            , " ",
	                          StatsList::getDeaths(%key)           , " ",
	                          StatsList::getFlagCaps(%key)         , " ",
	                          StatsList::getPredatorKills(%key) + 1, " ",
	                          StatsList::getMX5Kills(%key)         , " ",
	                          StatsList::getDualEnforcerKills(%key), " ",
	                          StatsList::getPlasmaKills(%key)
	                          );
}
function StatsList::incrementMX5Kills(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key)            , " ",
	                          StatsList::getDeaths(%key)           , " ",
	                          StatsList::getFlagCaps(%key)         , " ",
	                          StatsList::getPredatorKills(%key)    , " ",
	                          StatsList::getMX5Kills(%key) + 1     , " ",
	                          StatsList::getDualEnforcerKills(%key), " ",
	                          StatsList::getPlasmaKills(%key)
	                          );
}
function StatsList::incrementDualEnforcerKills(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key)                , " ",
	                          StatsList::getDeaths(%key)               , " ",
	                          StatsList::getFlagCaps(%key)             , " ",
	                          StatsList::getPredatorKills(%key)        , " ",
	                          StatsList::getMX5Kills(%key)             , " ",
	                          StatsList::getDualEnforcerKills(%key) + 1, " ",
	                          StatsList::getPlasmaKills(%key)
	                          );
}
function StatsList::incrementPlasmaKills(%username, %password) {
	$StatsList::unsavedChangesExist = true;

	%key = StatsListKey::create(%username, %password);
	$StatsList::array[%key] = strcat(
	                          StatsList::getKills(%key)            , " ",
	                          StatsList::getDeaths(%key)           , " ",
	                          StatsList::getFlagCaps(%key)         , " ",
	                          StatsList::getPredatorKills(%key)    , " ",
	                          StatsList::getMX5Kills(%key)         , " ",
	                          StatsList::getDualEnforcerKills(%key), " ",
	                          StatsList::getPlasmaKills(%key) + 1
	                          );
}

function StatsList::loadFromDisk() {
	exec($StatsList::fileName);
}
function StatsList::saveToDisk() {
	if ($StatsList::unsavedChangesExist) {
		export("$StatsList::array*", "config\\" @ $StatsList::fileName, false);
	}
}

function StatsList::ensureLoadedFromDisk() {
	if (!$StatsList::loadedFromDisk) {
		StatsList::loadFromDisk();
		$StatsList::loadedFromDisk = true;
	}
}

function getWordOr(%string, %index, %alternative) {
	%word = getWord(%string, %index);
	if (%word == -1) {
		return %alternative;
	}
	return %word;
}

function StatsListKey::create(%username, %password) {
	%key = %username @ %password;
	%key = String::getSubStr(%key, 0, 30);  // make sure it's not huge
	return StatsListKey::replaceInvalidChars(%key);
}

function StatsListKey::replaceInvalidChars(%string) {
	%result = "";
	for (%i = 0; (%cur = String::getSubStr(%string, %i, 1)) != ""; %i++) {
		if (StatsListKey::isValidChar(%cur)) {
			%result = %result @ %cur;
		} else {
			%result = %result @ "_";
		}
	}
	return %result;
}

function StatsListKey::isValidChar(%char) {
	return Char::isAlphaNumeric(%char);
}

function Char::isAlphaNumeric(%char) {
	return (%char >= "A" && %char <= "Z") ||
	       (%char >= "a" && %char <= "z") ||
	       (%char >  "0" && %char <= "9");  // must do **greater than** "0" here because "." == "0" evaluates to true for some reason
}
