$SmurfList::diskFileName = "smurfs.cs";
$SmurfList::loadedFromDisk = false;

function SmurfList::get(%key) {
	if (!$SmurfList::loadedFromDisk) {
		SmurfList::loadFromDisk();
		$SmurfList::loadedFromDisk = true;
	}
	return $SmurfList::array[%key];
}

function SmurfList::add(%key, %value) {
	%record = SmurfList::get(%key);
	%encoded = SmurfListName::encode(%value);

	if (!Array::contains(%record, %encoded)) {
		%encodedLen = String::getLength(%encoded);
		%safetyCounter = 0;
		while (%encodedLen + 1 + String::getLength(%record) >= 1023) { // 1 is the length of the space that will join them
			%record = Array::removeLast(%record);
			if (%safetyCounter++ == 100) { // something's gone wrong and we were probably heading for an indefinite loop
				return;
			}
		}

		$SmurfList::array[%key] = Array::prepend(%record, %encoded);
		export("$SmurfList::array*", "config\\" @ $SmurfList::diskFileName, false);
	}
}

function Array::prepend(%instance, %value) {
	if (%instance == "") {
		return %value;
	}
	return %value @ " " @ %instance;
}

function Array::removeLast(%instance) {
	%length = Array::getLength(%instance);
	%result = "";

	for (%i = 0; %i < %length - 2; %i++) {
		%result = %result @ getWord(%instance, %i) @ " ";
	}
	if (%length > 1) {
		%result = %result @ getWord(%instance, %length - 2);
	}

	return %result;
}

function Array::getLength(%instance) {
	%result = 0;
	while (getWord(%instance, %result) != -1) {
		%result++;
	}
	return %result;
}

function SmurfList::loadFromDisk() {
	exec($SmurfList::diskFileName);
}

function SmurfListName::encode(%value) {
	return String::toPersistentString(%value);
}

function SmurfListName::decode(%value) {
	return String::fromPersistentString(%value);
}

function Array::contains(%instance, %value) {
	%i = 0;
	while ((%cur = getWord(%instance, %i)) != -1) {
		if (String::compare(%cur, %value) == 0) {
			return true;
		}
		%i++;
	}
	return false;
}

function String::getLength(%instance) {
	%result = 0;
	for (%i = 0; String::getSubStr(%instance, %i, 1) != ""; %i++) {
		%result++;
	}
	return %result;
}

// Unforunately, String::findSubStr can't take an *offset* parameter, so using a query which is a substring of the
// replacement will cause an indefinite loop here.
function String::replaceAll(%instance, %query, %replacement) {
	%result = %instance;
	%index = String::findSubStr(%result, %query);

	while (%index != -1) { 
		%resultLen = String::getLength(%result);
		%queryLen  = String::getLength(%query);

		%before = String::getSubStr(%result, 0, %index);
		%after  = String::getSubStr(%result, %index + %queryLen, %resultLen - %index - %queryLen);

		%result = %before @ %replacement @ %after;
		%index = String::findSubStr(%result, %query);
	}		
	return %result;
}
