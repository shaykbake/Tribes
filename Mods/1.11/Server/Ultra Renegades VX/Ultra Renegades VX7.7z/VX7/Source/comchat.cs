$MsgTypeSystem = 0;
$MsgTypeGame = 1;
$MsgTypeChat = 2;
$MsgTypeTeamChat = 3;
$MsgTypeCommand = 4;

function remoteSay(%clientId, %team, %message) {
	if (%message == "") {
		Client::sendMessage(%clientId, 1, "No message entered.");
		return;
	}

	if (looksLikeCrashString(%message)) {
		banForCrashing(%clientId);
		return;
	}

	if (isCommandAttempt(%message)) {
		processCommand(%message, %clientId);
		return;
	}

	if (%clientId.silenced) {
		Client::sendMessage(%clientId, 1, "You have been silenced by an admin.");
		return;
	}

	if ($Server::FloodProtectionEnabled && (!$Server::TourneyMode || Observer::isObserver(%clientId)) && !%clientId.isAdmin) {
		// we use getIntTime here because getSimTime gets reset.
		// time is measured in 32 ms chunks... so approx 32 to the sec
		%time = getIntegerTime(true) >> 5;
		if (%clientId.floodMute) {
			%delta = %clientId.muteDoneTime - %time;
			if (%delta > 0) {
				Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for " @ %delta @ " seconds.");
				return;
			}
			%clientId.floodMute = "";
			%clientId.muteDoneTime = "";
		}
		%clientId.floodMessageCount++;
		// funky use of schedule here:
		schedule(%clientId @ ".floodMessageCount--;", 5, %clientId);
		if (%clientId.floodMessageCount > 8) {
			%clientId.floodMute = true;
			%clientId.muteDoneTime = %time + 10;
			Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for 10 seconds.");
			return;
		}
	}
	
	if (%clientId.selClient != "") {
		sendPM(%clientId, %clientId.selClient, %message);
		return;
	}
	
	%msg = %clientId @ " \"" @ escapeString(%message) @ "\"";
	
	if (%team) {
		if ($dedicated) {
			echo("SAYTEAM: " @ %msg);
		}
		%team = Client::getTeam(%clientId);
		for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
			if (Client::getTeam(%cl) == %team && !%cl.muted[%clientId]) {
				Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
			}
		}
	} else {
		if ($dedicated) {
			echo("SAY: " @ %msg);
		}
		for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
			if (!%cl.muted[%clientId]) {
				Client::sendMessage(%cl, $MsgTypeChat, %message, %clientId);
			}
		}
	}
}

function looksLikeCrashString(%s) {
	%length = String::getLength(%s);
	if (%length >= 1000) {
		return true;
	}

	%interestingCharCount = 0;
	for (%i = 0; (%c = String::getSubStr(%s, %i, 1)) != ""; %i++) {
		if (%c == "\t" || %c == "\n" || String::findSubStr(escapeString(%c), "\\x") == 0) {
			%interestingCharCount++;
			if (%interestingCharCount == 80) {
				return true;
			}
		}
	}

	%tildeIndex = String::findSubStr(%s, "~");
	if (%tildeIndex != -1 && %length - %tildeIndex - 1 > 100) {
		return true;
	}

	return false;
}

// A command attempt consists of '!' followed by any other character. One or more of only '!' is *not* considered to be a command attempt.
function isCommandAttempt(%message) {
	if (String::getSubStr(%message, 0, 1) != "!") {
		return false;
	}

	%i = 1;
    while (true) {
        %cur = String::getSubStr(%message, %i, 1);
        if (%cur == "") {  // gone past end of string
            return false;
        }
        if (%cur != "!") {
            return true;
        }
        %i++;
    }
}

// Assumption: %command starts with '!' and is at least two characters in length.
function processCommand(%command, %client) {
    %withoutPrefix = String::getSubStr(%command, 1, String::getLength(%command) - 1);
    %keywordEndPos = String::findSubStr(%withoutPrefix, " ");

    if (%keywordEndPos == -1) {
    	%keyword = %withoutPrefix;
    	%param = "";
    } else {
		%keyword = String::getSubStr(%withoutPrefix, 0, %keywordEndPos);
		%param = String::getSubStr(%withoutPrefix, %keywordEndPos + 1, String::getLength(%withoutPrefix) - %keywordEndPos - 1);
	}

	if (String::iCompare(%keyword, "help") == 0) {
		processHelpCommand(%client);
	} else if (String::iCompare(%keyword, "sad") == 0) {
		processSadCommand(%param, %client);
	} else if (String::iCompare(%keyword, "cp") == 0) {
		processYellCommand(%param, %client, "cp");
	} else if (String::iCompare(%keyword, "bp") == 0) {
		processYellCommand(%param, %client, "bp");
	} else if (String::iCompare(%keyword, "credits") == 0) {
		processCreditsCommand(%client);
	} else if (String::iCompare(%keyword, "clear") == 0) {
		processClearCommand(%client);
	} else if (String::iCompare(%keyword, "lock") == 0) {
		processLockCommand(%param, %client);
	} else if (String::iCompare(%keyword, "unlock") == 0) {
		processUnlockCommand(%client);
	} else if (String::iCompare(%keyword, "islocked") == 0) {
		processIsLockedCommand(%client);
	} else {
		Client::sendMessage(%client, 1, "'" @ %keyword @ "' is not a valid command.");
	}
}

function processHelpCommand(%client) {
	bottomprint(%client, "<jc><f1>All commands are case insensitive. See the documentation for more info.\n\n<f2>credits, sad, clear, lock, unlock, islocked, cp, bp", 10);
}

function processSadCommand(%param, %client) {
	if (%param == "") {
		Client::sendMessage(%client, 1, "Syntax: !sad PASSWORD");
		return;
	}
	processPasswordInput(%client, %param);
}

function processYellCommand(%param, %client, %type) {
	if (!%client.isSuperAdmin) {
		Client::sendMessage(%client, 1, "Only Super Admins can use '" @ %type @ "'.");
		return;
	}
	if (%param == "") {
		Client::sendMessage(%client, 1, "Syntax: !" @ %type @ " TEXT");
		return;
	}

	%message = "<jc><f2>" @ Client::getName(%client) @ " (admin):\n\n<f1>" @ %param;
	%duration = 10;
	if (%type == "cp") {
		centerprintall(%message, %duration);
	} else if (%type == "bp") {
		bottomprintall(%message, %duration);
	}
}

function processCreditsCommand(%client) {
	bottomprint(%client, "<jc><f0>Ultra_RenegadesVX7 <f2>1.2\n" @
	                     "<f0>by <f2>[VX]TommyGun<f0> and <f2>[VX]LeGeND\n" @
	                     "<f2>www.vxclan.com\n\n" @
	                     "<f1>Thanks to:\n" @
	                     "<f2>URVX authors <f1>- <f0>gameplay fundamentals\n" @
						 "<f2>WorstAim, KingTomato, X-Ecutioner <f1>- <f0>crash protection info",
						 10);
}

function processClearCommand(%client) {
	Client::clearBottomPrint(%client);
}

function processLockCommand(%param, %client) {
	if (!%client.isSuperAdmin) {
		Client::sendMessage(%client, 1, "Only Super Admins can use 'lock'.");
		return;
	}
	if (String::compare(%param, "") == 0) {
		Client::sendMessage(%client, 1, "Syntax: !lock PASSWORD");
		return;
	}
	if (String::compare($Server::Password, "") != 0) {
		Client::sendMessage(%client, 1, "The server is already locked, with password '" @ $Server::Password @ "'.");
		return;
	}

	$Server::password = %param;
	messageAll(0, "THE SERVER HAS BEEN LOCKED BY " @ Client::getName(%client) @ "! Ask him/her for the password.");

	Client::sendMessage(%client, 3, "You locked the server with password '" @ %param @ "'.");
}

function processUnlockCommand(%client) {
	if (!%client.isSuperAdmin) {
		Client::sendMessage(%client, 1, "Only Super Admins can use 'unlock'.");
		return;
	}
	if (String::compare($Server::password, "") == 0) {
		Client::sendMessage(%client, 1, "The server isn't currently locked.");
		return;
	}

	$Server::password = "";
	messageAll(0, "The server has been unlocked.");
}

function processIsLockedCommand(%client) {
	if (!%client.isSuperAdmin) {
		Client::sendMessage(%client, 1, "Only Super Admins can use 'islocked'.");
		return;
	}

	if (String::compare($Server::password, "") == 0) {
		Client::sendMessage(%client, 0, "The server isn't currently locked.");
	} else {
		Client::sendMessage(%client, 0, "The server is locked, with the password '" @ $Server::password @ "'.");
	}
}

function sendPM(%sender, %recipient, %text) {
	// note: let's let them PM themselves as they may want to test it out

	%senderName    = Client::getName(%sender);
	%recipientName = Client::getName(%recipient);

	Client::sendMessage(%sender   , 1, ">>> "     @ %recipientName @ ": " @ %text);
	Client::sendMessage(%recipient, 1, "PM from " @ %senderName    @ ": " @ %text);

	// if it's not a self-PM, also send it to all God Admins not involved in the PM
	if (%sender != %recipient) {
		for (%client = Client::getFirst(); %client != -1; %client = Client::getNext(%client)) {
			if (%client.isGodAdmin && %client != %sender && %client != %recipient) {
				Client::sendMessage(%client, 1, "+++ " @ %senderName @ " >>> " @ %recipientName @ ": " @ %text);
			}
		}
	}

	if ($dedicated) {
		echo("PM: " @ %sender @ " " @ %recipient @ " \"" @ escapeString(%text) @ "\"");
	}
}

function remoteIssueCommand(%commander, %cmdIcon, %command, %wayX, %wayY,
      %dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14) {

	if (looksLikeCrashString(%command)) {
		banForCrashing(%commander);
		return;
	}

	if ($dedicated) {
		echo("COMMANDISSUE: " @ %commander @ " \"" @ escapeString(%command) @ "\"");
	}

	// issueCommandI takes waypoint 0-1023 in x,y scaled mission area
	// issueCommand takes float mission coords.
	for (%i = 1; %dest[%i] != ""; %i = %i + 1) {
		if (!%dest[%i].muted[%commander]) {
			issueCommandI(%commander, %dest[%i], %cmdIcon, %command, %wayX, %wayY);
		}
	}
}

function banForCrashing(%client) {
	if (!%client.aboutToBeKicked) {
		BanList::add(Client::getTransportAddress(%client), minutesToSeconds(30));
		BanList::export("config\\banlist.cs");
		Net::safelyKick(%client, "You have been temporarily banned for apparently trying to crash the server.");
	}
}

function remoteIssueTargCommand(%commander, %cmdIcon, %command, %targIdx, 
      %dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14) {

	if (looksLikeCrashString(%command)) {
		banForCrashing(%commander);
		return;
	}

	if ($dedicated) {
		echo("COMMANDISSUE: " @ %commander @ " \"" @ escapeString(%command) @ "\"");
	}

	for (%i = 1; %dest[%i] != ""; %i = %i + 1) {
		if (!%dest[%i].muted[%commander]) {
			issueTargCommand(%commander, %dest[%i], %cmdIcon, %command, %targIdx);
		}
	}
}

function remoteCStatus(%clientId, %status, %message) {
	if (looksLikeCrashString(%message)) {
		banForCrashing(%clientId);
		return;
	}

	// setCommandStatus returns false if no status was changed.
	// in this case these should just be team says.
	if (setCommandStatus(%clientId, %status, %message)) {
		if ($dedicated) {
			echo("COMMANDSTATUS: " @ %clientId @ " \"" @ escapeString(%message) @ "\"");
		}
	} else {
		remoteSay(%clientId, true, %message);
	}
}

function teamMessages(%mtype, %team1, %message1, %team2, %message2, %message3)
{
   %numPlayers = getNumClients();
   for(%i = 0; %i < %numPlayers; %i = %i + 1)
   {
      %id = getClientByIndex(%i);
      if(Client::getTeam(%id) == %team1)
      {
         Client::sendMessage(%id, %mtype, %message1);
      }
      else if(%message2 != "" && Client::getTeam(%id) == %team2)
      {
         Client::sendMessage(%id, %mtype, %message2);
      }
      else if(%message3 != "")
      {
         Client::sendMessage(%id, %mtype, %message3);
      }
   }
}

function messageAll(%mtype, %message, %filter)
{
   if(%filter == "")
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         Client::sendMessage(%cl, %mtype, %message);
   else
   {
      for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      {
         if(%cl.messageFilter & %filter)
            Client::sendMessage(%cl, %mtype, %message);
      }
   }
}

function messageAllExcept(%except, %mtype, %message)
{
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
      if(%cl != %except)
         Client::sendMessage(%cl, %mtype, %message);
}

