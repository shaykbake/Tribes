%i = -1;

// Here, you can specify names with which players can hide from the smurf tracker.  Anyone using
// such a name will have a blank smurf history shown for him, along with a specific IP address.
// 
// The format is as follows:
// 
// NAME [space] ADDRESS
// 
// Use the tilde character ~ to represent any spaces in the name.
// 
// Example:
// 
//     $anonymousNameList::array[%i++] = "First~Name 1.2.3.4";
//     $anonymousNameList::array[%i++] = "Second 5.6.7.8";

