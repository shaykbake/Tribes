%i = -1;

// Here, you can specify a database of players who are to automatically aquire admin rights on joining the server.
// 
// The format is as follows:
// 
// ADDRESS [space] NAME [space] LEVEL
// 
// If absolutely any name connecting with the specified address is to gain the admin level, then use an asterisk *
// as the name.  Otherwise, specify the name, using the tilde character ~ to represent any spaces in it.
// 
// The level must be either god, super, or public.
// 
// Example:
// 
//     $adminList::array[%i++] = "1.2.3.4 * super";
// 
//         This gives Super Admin to anyone connecting with the address 1.2.3.4.
// 
//     $adminList::array[%i++] = "5.6.7.8 A~Nice~Name public";
// 
//         This gives Public Admin to someone connecting with the address 5.6.7.8 and the name A Nice Name.
// 
// Multiple names cannot be used in a single record; however, multiple records with the same address in each 
// but a different name each time achieves the same thing.
// 
// Example:
// 
//     $adminList::array[%i++] = "6.6.6.6 Satan god";
//     $adminList::array[%i++] = "6.6.6.6 Jesus public";
// 
//         Here, Satan and Jesus at address 6.6.6.6 get admin on each connection, Satan getting God Admin and Jesus getting Public Admin.

