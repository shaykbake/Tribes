//////////////////////////////////////////////////////////////

$TelnetPassword      = "CHANGE TO SOMETHING UNIQUE!";

$godAdminPassword    = "CHANGE TO SOMETHING UNIQUE!";
$superAdminPassword  = "CHANGE TO SOMETHING UNIQUE!";
$publicAdminPassword = "CHANGE TO SOMETHING UNIQUE!";

$Server::HostName = "UltraVX7 Server";

//////////////////////////////////////////////////////////////

$Server::Password = "";
$Server::HostPublicGame = "true";
$Server::MaxPlayers = "12";

//////////////////////////////////////////////////////////////

$pref::PacketRate = 30;
$pref::PacketSize = 500;

//////////////////////////////////////////////////////////////

$TelnetPort = 2001;
$Server::Port = "28001";

$pref::LastMission = "Raindance";

$Server::AutoAssignTeams = "true";
$Server::FloodProtectionEnabled = "true";

$Server::respawnTime = "0";
$Server::TeamDamageScale = "0";

$Server::timeLimit = "30";
$Server::TourneyMode = "false";

//////////////////////////////////////////////////////////////

$Server::teamName0 = "[VX]"; 
$Server::teamName1 = "Others";
$Server::teamName2 = "Shock";
$Server::teamName3 = "Photon";
$Server::teamName4 = "Generic 1";
$Server::teamName5 = "Generic 2";
$Server::teamName6 = "Generic 3";
$Server::teamName7 = "Generic 4";

$Server::teamSkin0 = "beagle";
$Server::teamSkin1 = "dsword";
$Server::teamSkin2 = "cphoenix";
$Server::teamSkin3 = "swolf";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";

//////////////////////////////////////////////////////////////

$Server::VoteAdminWinMargin = "0.699999";
$Server::VoteFailTime = "25";
$Server::VoteWinMargin = "0.600000";
$Server::VotingTime = "10";
$Server::warmupTime = "5";

//////////////////////////////////////////////////////////////
