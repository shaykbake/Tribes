//////////Disabled//////////////////////////
// remove // to enable a line
////////////////////////////////////////////
//$TelnetPort = 8888;
//$TelnetPassword = "BetterChangeMe";
////////////////////////////////////////////
////HIGHEST NETWORK PREF
//$pref::PacketRate = 30; 
//$pref::PacketSize = 500;
///////////////////////////////////////////
$Server::Password = "";
$AdminPassword = "BetterChangeMe"; 
$pref::PacketRate = 10; 
$pref::PacketSize = 200;