//////////Disabled//////////////////////////
// remove // to enable a line
////////////////////////////////////////////
//$TelnetPort = 9444;
//$TelnetPassword = "BetterChangeMe";
//
//$Server::Address = "IP:LOOPBACK:28001";//only used for LAN games
//$Server::Password = "";//join password leave blank for none
////////////////////////////////////////////
$Server::HostName = "NOTOR VX (name Here)";
$Server::Info = "NOTOR VX (name Here) \nPlanetstarsiege.com/UltraVX/\nVXNOTORLadder.Homestead.com";
$Server::MaxPlayers = "14";
$AdminPassword = "BetterChangeMe"; 
$pref::PacketRate = 15;  //recommend 10-30 higher values equal more bandwdith
$pref::PacketSize = 300; //recommend 200-500 higher values equal more bandwidth