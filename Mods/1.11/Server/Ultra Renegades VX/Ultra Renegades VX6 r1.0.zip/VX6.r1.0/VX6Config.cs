// ================================================================================
//         U L T R A   R E N E G A D E S   V X 6   I N F I N I T E    +]-[+  
// ================================================================================
// Copyright � 2005 +]-[+Armageddon+ & +]-[+WorstAim. List of credits in credits.txt
// Website @ www.HDT.Gnu-Design.Com Check Out Our Other Wicked Mods & Addons


// ================================================================================
// Telnet  
// ================================================================================
// (Used to allow users / yourself to connect to your server using a remote server program)

$TelnetPort = 6666;  // Telnet Port can be any #
$TelnetPassword = "changeme";  // Choose the password used to remotely connect to your server.

// ================================================================================
// Network Settings: To use a preset Network setting remove ##
// ================================================================================
// (Based on your connection speed, choose how much information can be sent to the server)


////HIGHEST [Cable/T1+] NETWORK PREF
////  15 kbytes/sec (120 kbits/sec) SERVER UPLOAD per player 12-16 slots
$pref::PacketFrame = 32;
$pref::PacketRate = 30; 
$pref::PacketSize = 500;

////RECOMMENDED [DSL] NETWORK PREF 
////9.6 kbytes/sec (76.8 kbits/sec) SERVER UPLOAD per player 8-10 slots
##$pref::PacketFrame = 32;
##$pref::PacketRate = 24; 
##$pref::PacketSize = 400;

////LOWEST [56K] NETWORK PREF Dial Up Server 2-4 slots
##$pref::PacketFrame = 96;
##$pref::PacketRate = 10; 
##$pref::PacketSize = 200;


// ================================================================================
// Server Settings
// ================================================================================
// (Edit to your likeing)

// Admin Passwords
$Admin::PublicPassword[0] = "public"; //Change
$Admin::SuperPassword[0] = "super"; //Change
$Admin::MasterPassword[0] = "master"; //Change
$Admin::OwnerPassword[0] = "owner"; //Change

$Server::AutoAssignTeams = "true"; // Recommend you leave this TRUE
$Server::FloodProtectionEnabled = "false"; // If True, stops players from constantly spamming
$Server::HostName = "My VX6 Server"; // Put your server's name inside the ""
$Server::HostPublicGame = "true"; // Keep TRUE or others won't be able to find your server
$Server::Info = "<JC><F1>-<F2>= <F3>Hosted By: <f1>YourName <f2>=<F1>-\n<F1>-<F2>= <f3>*<F1>ServerName<f3>* <f2>=<F1>-\n<F1>-<F2>= <F3>Admin: <F1>YourName <f2>=<F1>-\n<F1>-<F2>= <F3>Clan Site: <F1>www.YourSite.Com <f2>=<F1>-\n<F2>CHECK FORUM DAILY!";
$Server::JoinMOTD = "<JC><F1>-<F2>= <F3>Hosted By: <f1>YourName <f2>=<F1>-\n<F1>-<F2>= <f3>*<F1>ServerName<f3>* <f2>=<F1>-\n<F1>-<F2>= <F3>Admin: <F1>YourName <f2>=<F1>-\n<F1>-<F2>= <F3>Clan Site: <F1>www.YourSite.Com <f2>=<F1>-\n<F2>CHECK FORUM DAILY!";
$Server::MaxPlayers = "32"; // Maximum amount of players your server can hold
$Server::respawnTime = "0"; // Time it takes to return to life
$Server::TeamDamageScale = "0"; // 0 = No Team Damage, 1 = Team Damage
$Server::timeLimit = "30"; // Server Mission Time Limit in Minutes
$Server::TourneyMode = "false";  // True = Tournament Mode, False = Free for all mode
$Server::VoteAdminWinMargin = "0.699999"; // 
$Server::VoteFailTime = "25";  // Time for the vote to complete 
$Server::VoteWinMargin = "0.600000"; // Percentage of votes for required for vote to pass
$Server::VotingTime = "10"; // How much time vote is displayed for
$Server::warmupTime = "5"; // Time before match initially starts
$Server::VotingEnabled = "true"; // Enable Voting
$Server::ClanMatchTotalPoints = "500"; //Up to how many points possible would you like clan matches to be to?

// ================================================================================
// Team Settings
// ================================================================================
// (Edit to your likeing)

$Server::teamName0 = "+]-[+"; 
$Server::teamName1 = "+]-[DT+";
$Server::teamName2 = "Shock";
$Server::teamName3 = "Photon";
$Server::teamName4 = "Generic 1";
$Server::teamName5 = "Generic 2";
$Server::teamName6 = "Generic 3";
$Server::teamName7 = "Generic 4";

$Server::teamSkin0 = "beagle";
$Server::teamSkin1 = "dsword";
$Server::teamSkin2 = "cphoenix";
$Server::teamSkin3 = "swolf";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";

$pref::LastMission = "No-Rail-No-Fog"; // Map that is first run when a server is put up