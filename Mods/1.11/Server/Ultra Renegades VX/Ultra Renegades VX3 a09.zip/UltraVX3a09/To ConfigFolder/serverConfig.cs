//////////Disabled//////////////////////////
// remove // to enable a line
////////////////////////////////////////////
//$TelnetPort = 8888;
//$TelnetPassword = "BetterChangeMe";
//
//$Server::Address = "IP:LOOPBACK:28001";
////////////////////////////////////////////
$Server::Password = "";
$AdminPassword = "BetterChangeMe"; 
$pref::PacketRate = 10; 
$pref::PacketSize = 200; 