Unzip the UltraVX folder to your Tribes2\GameData folder.
Run the provided "Dedicated.bat" file to run a dedicated server.
Full release (with installer application) is scheduled for May 1,2001.

UltraVXAuthor
http://PlanetTribes.com/UltraVX
mailto:kissie@speakeasy.org



Quick command line faq

Dedicated Server via Command Line
Chewtoy[QA]
03/30/2001 06:47pm

Order is somewhat importaint.  A typical command line goes like this:

tribes2 -dedicated -mission katabatic ctf -mod foo -bot 8

This command line will launch a dedicated server, mission katabatic ctf, in a mod named foo (more on this later) with 8 bots.

-dedicated tells it to run a dedicated server (duh).

-mission has two args, the mission name (filename) and the game type.  Valid game types are CTF CnH Hunters TeamHunters Bounty DM Siege.  If you make a mistake matching a mission with a game type, it will load katabatic ctf as default.

-mod loads the files from a directory in the GameData directory (the one base is located in)  In the example -mod foo will load eveything in the directory Tribes2/GameData/foo and (theoreticaly) overide any script in the base directory.

-bot loads bots.  If you load bots on a non bot enabled mission you will spawn at (0 0 300) along with a bunch of brain dead bots.  I don\'t recommend doing this (unless you like shooting brainless bots).  The number of bots can be from 1 to 16.  Any number greater than that will load 16 bots.

I hope this helps. =)

Chewtoy[QA]

Dedicated Server via Command Line
UnionCarbideBANGG|
04/09/2001 09:24pm

"Order is somewhat importaint.  A typical command line goes like this:"

Also note that for a LAN server, -nologin must come before all other args

