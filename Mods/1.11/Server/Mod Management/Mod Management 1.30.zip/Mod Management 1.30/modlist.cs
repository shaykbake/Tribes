//  Add the mods here
modmgtAddServerMod(AutoAdmin);
modmgtAddServerMod(votectrl);
//modmgtAddMissionMod(fairteams);
modmgtAddServerMod(teleport);
modmgtAddServerMod(sentinel);
modmgtAddMissionMod(WhosOn);
modmgtAddMissionMod(nooutside);
modmgtAddMissionMod(antitk);
modmgtAddMissionMod(teleportMission);
modmgtAddMissionMod(SentinelMission);
