//---------------------------------------------------------------------------------
// General Controls
//---------------------------------------------------------------------------------

$AdminCon::RandomMission = false;	//Allow True Random Missions
$AdminCon::AutoTeam = false;		//Only Allow Automatic Team Selection
$AdminCon::LowTeam = false;		//Only Allow Team Switch to Low Team
$AdminCon::NoPlayerScore = true;	//Turn Personal scores On/Off
$AdminCon::UseCustomSkins = true;	//Allow Personal Skins
$AdminCon::OutOfMissionDamage = true;	//Turn on Out of Mission Damage
$AdminCon::warncount = 3;		//Each count adds roughly 3.3 seconds
$AdminCon::TrueDeath = false;		//Turn TrueDeath On/Off
$AdminCon::deathlimit = 5;		//Number Of Deaths before sending to Observer Mode


//---------------------------------------------------------------------------------
// Vote Controls
//---------------------------------------------------------------------------------
$AdminCon::allowadmin = True;		//Allow Voting in an Admin
$AdminCon::allowkick = True;		//Allow Voting on a Kick
$AdminCon::allowmissionchange = True;	//Allow Vote to Change Mission
$AdminCon::allowchangeTD = True;	//Allow Vote to Change Team Damage
$AdminCon::allowTourneyFFA = True;	//Allow Vote to change Tourney / FFA Mode


//---------------------------------------------------------------------------------
// Team Energy Controls
//---------------------------------------------------------------------------------
// Energy each team is given at beginning of game
//---------------------------------------------------------------------------------
$AdminCon::setdefaultteamenergy = "Infinite";
//---------------------------------------------------------------------------------
// MAX amount team energy can reach
//---------------------------------------------------------------------------------
$AdminCon::setmaxteamenergy = 700000;
//---------------------------------------------------------------------------------
// Amount to inc team energy every ($secTeamEnergy) seconds
//---------------------------------------------------------------------------------
$AdminCon::setincteamenergy = 700;
//---------------------------------------------------------------------------------
// (Rate is sec's) Set how often TeamEnergy is incremented
//---------------------------------------------------------------------------------
$AdminCon::setsecTeamEnergy = 30;

//---------------------------------------------------------------------------------
//Respawn automatically after X sec's -  If 0..no respawn
//---------------------------------------------------------------------------------
$AdminCon::setAutoRespawn = 0;

//---------------------------------------------------------------------------------
//Random Mission List
//---------------------------------------------------------------------------------
$numrandmis = 37;			//Number of missions in list

$mname[0] = "Valhalla";
$mname[1] = "SeekAndDestroy";
$mname[2] = "Scarabrae";
$mname[3] = "SandStorm";
$mname[4] = "Rollercoaster";
$mname[5] = "Raindance";
$mname[6] = "Peekaboo";
$mname[7] = "PeakPerformance";
$mname[8] = "NoQuarter";
$mname[9] = "NoMan'sLand";
$mname[10] = "Mudslide";
$mname[11] = "TripleThreat";
$mname[12] = "LuckySeven";
$mname[13] = "KingUnderTheHill";
$mname[14] = "IceRidge";
$mname[15] = "HammerDown";
$mname[16] = "FreeForAll";
$mname[17] = "FourWayDance";
$mname[18] = "FogOfWar";
$mname[19] = "Fallen";
$mname[20] = "Desert_Of_Death";
$mname[21] = "DeathKnell";
$mname[22] = "Towers";
$mname[23] = "DangerousCrossing";
$mname[24] = "CrissCross";
$mname[25] = "Citadels";
$mname[26] = "Broadside";
$mname[27] = "BloodyVengeance";
$mname[28] = "BloodRunsCold";
$mname[29] = "AntHill";
$mname[30] = "ADishBestServedCold";
$mname[31] = "TheRedSands";
$mname[32] = "TempleOfDoom";
$mname[33] = "StrungOut";
$mname[34] = "Stonehenge";
$mname[35] = "Snowblind";
$mname[36] = "Siege"; 


function randommission()
{	
return ($mname[(floor(getRandom() * $numrandmis))]);
}