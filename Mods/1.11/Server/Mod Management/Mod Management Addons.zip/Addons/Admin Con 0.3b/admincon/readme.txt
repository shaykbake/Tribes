----------------------------------------------------------------
Name: Admin Control MOD
Version: 0.3b Beta (For TRIBES Version 1.3)
Date: 3-7-99
Author: Harold Brown (LabRat
Email: LabRat@interx.net
URL: http://labrat1.simplenet.com/sstribes/
Purpose: To provide more flexible Administration
         controls for server admins.

Current Addititions: 
        TrueDeath: On/Off (With variable Death Limit)
        Personal Skins: On/Off
        Out of Mission Area Damage: On/Off (With Variable # of warnings)
        Personal Score: On/Off
        AutoTeam Assignment: On/Off
        Only join/switch to Losing Team: On/Off
        Random Missions: On/Off
      
      Vote Controls
      --------------
        Vote in an Admin: On/Off
        Vote on a kick: On/Off
        Vote on Mission Chage: On/Off
	Vote to change Team Damage: On/Off
	Vote to Change Tourney / FFA Mode: On/Off        

Notes: Some people feel they have the right to take code from any
       MOD and use it as their own to distribute.  I do not agree
       with this and request that full recognition for any code used	
       is given.  
       
Known Bugs: NONE

Possible Bugs: 	May or may not work with other MODs depending on
		what files were changed to make that MOD.  
		
Credits:
  Thanks to these people for Information and Ideas:
    *IX*Savage1 - Who I shamelessly stole the format of this documentation
  		from.
    Kaptain KickAss - Who showed me how to keep track of player information even
  		when they quit and rejoin.
    KillerBunny - For Providing alot of useful information that I may or may not have
  		used when doing this MOD.
    Shrike - For providing some interesting ideas.  Some of the options I added were done
  	 	so after seeing what people requested and what shrike provided in the Server Corps 
  		Message Board.
    The DEV Team - The people who every MOD author HAS to rip code from in one way or another.
   		
---------------------------------------------------------------

Client Install: NONE. 

Client Information: To use Personal skins (if they are active) press
	[TAB] and there will be a menu option to use personal skin, when
	selected it will change to allow you to choose to use Team Skin.


Server Install: 
	1. Unzip AdminCon03b.zip into default Tribes Dir.
	   (where tribes.exe resides - UNZIP WITH PATH INFORMATION)
	2. Command line to run the mod. 	
	   Just add "-mod admincon" to your current Server Command Line.
	   For Example:
		tribes.exe -mod admincon
	   If you have problems running a server please go to 
	   http://www.tribesplayers.com/
	   all the info you need is there.

When installed The Files Should be here: 
 Tribes\admincon\admincon.cs
 Tribes\admincon\scripts\admin.cs
 Tribes\admincon\scripts\game.cs
 Tribes\admincon\scripts\objectives.cs
 Tribes\admincon\scripts\dm.cs
 Tribes\admincon\Readme.txt
 

NOTE: If these files are not in these folders ..put them there.
      

---------------------------------------------------------------

  Please post any and all feedback on the MOD/Scripts Message board 
  on my web site. http://labrat1.simplenet.com/sstribes/.  This mod is still
  being created at this time. Bugs and suggestions will be worked
  on. Thanks.
  	-LabRat

---------------------------------------------------------------
Current Additions:
---------------------------------------------------------------
NOTE:   When the Options Menu is mentioned it is refering to the Menu 
	you access by pressing [TAB] While in the game. 
	When "Super Admin" is mentioned it is refering to the Admin
	with the SAD Password or a player Hosting the game.
	When refering to a Public Admin it is refering to someone who 
	has either been appointed Admin by a Super Admin(See below) 
	or has been Voted into being Administrator. 


--------------------------------------------
 Limiting Team Swapping
--------------------------------------------
Default Server Variables:
	$AdminCon::AutoTeam = false;
	$AdminCon::LowTeam = false;
	
	These two options basically perform the same function.  They
     both only allow you to join the team with either the lowest score or
     lowest number of players (or the team with both). 
	
  	$AdminCon::AutoTeam = false;
  	  Doesn't show what team you can join so its a blind choice.
	$AdminCon::LowTeam = false;
	  Shows what team you will join so you can decide not to change
	teams if you wish.
  
--------------------------------------------
 TrueDeath
--------------------------------------------
Default Server Variables:
	$AdminCon::TrueDeath = False;
	$AdminCon::deathlimit = 5;
	
	
    TrueDeath as a server option may be better suited for Tribe Matches,
  But regardless of when this option is set it will track player deaths 
  and when the number of player deaths are equal to "$AdminCon::deathlimit"
  the player will be put into observer mode until the start of the next mission.
  
    Players who attempt to bypass this by quitting and rejoining the server will
  find that their deaths will be tracked and they will be sent back to observer 
  mode if they join a team.  Player Deaths will be reset at the start of a new mission.
  
    An additional funtion of this MOD is that players are asked which team they wish to
  join when they connect to the server and at the start of every mission. 

--------------------------------------------
 Out of Mission Area damage
--------------------------------------------
Default Server Variables: 
	$AdminCon::OutOfMissionDamage = false;
	$AdminCon::warncount = 3;

    The Out of Mission Area damage is a server option that is not on by default but 
  may be enabled by the server admin.  When turned on if a player leaves the mission 
  area they will be warned "$AdminCon::warncount" number of times. At that point they
  will begin to take damage.
  
  Each warning is equal to roughly 3.3 seconds

--------------------------------------------
 Toggle Voting Controls
--------------------------------------------
Default Server Variables:
	$AdminCon::allowadmin = True;
	$AdminCon::allowkick = True;
	$AdminCon::allowmissionchange = True;
	$AdminCon::allowchangeTD = True;
	$AdminCon::allowTourneyFFA = True;

   These controls activate or deactivate the option to initiate a vote.

	$AdminCon::allowadmin = True;
	  Allow vote to be initiated to make a player a public admin.
	  
	$AdminCon::allowkick = True;
	  Allow vote to be initiated to kick a player.
	  
	$AdminCon::allowmissionchange = True;
	  Allow vote to be initiated to change the mission.
	  
	$AdminCon::allowchangeTD = True;
	  Allow vote to be initiated to change Team Damage
	$AdminCon::allowTourneyFFA = True;
	  Allow vote to be initiated to Switch to or from Tournament Mode

--------------------------------------------
 Appoint Public Admin
--------------------------------------------
Default Server Variables:
	None.

    Any super admin has the power to Appoint a player to be an Admin. 
  The "Appointed Admin" has the same power as a "Public Admin". Which
  is the same as being voted Admin. The "Appointed Admin" is subject
  to the Public Admin Lockouts. (Explained Below). To use this option
  select the player name from the option menu and select "Admin <player>"

--------------------------------------------
 Allow Personal Skins
--------------------------------------------
Default Server Variables: 
	$AdminCon::UseCustomSkins = false;

  Allows players to switch between personal and Team skin by using the Options Menu

--------------------------------------------
 Turn Off Personal Score
--------------------------------------------
Server Variables:
	$AdminCon::NoPlayerScore = false;

     Allows players to view personal scores in the Options Menu

--------------------------------------------
 Turn on Random Mission
--------------------------------------------
Server Variables:
	$AdminCon::RandomMission = false;
	$numrandmis = 37;
	$mname[0] = "Valhalla";
	$mname[1] = "SeekAndDestroy";
	$mname[2] = "Scarabrae";
	$mname[3] = "SandStorm";
	....

     Turns on true random missions.  No more having to run only CTF missions, or having
   the players know exactly what will be the next mission.
   
  $numrandmis = 4;
     Number of missions in the random mission list.  Number should be one more then the last
  $mname[#] variable.    

  $mname[0] = "Valhalla"; 
  $mname[1] = "SeekAndDestroy";
  $mname[2] = "Scarabrae";
  $mname[3] = "SandStorm";
  
    Array Missions to include in the Random Mission function.  Missions can be of any type.
    


---------------------------------------------------------------
Possible Future Additions:
---------------------------------------------------------------

  Anything I can think of that might prove useful to a Server Admin.
  Or that people request me to add (if it's possible and doesn't change 
  the balance of the game).
    -LabRat

----------------------------------------------------------------
Disclaimer: I am not responsable for any damage this game 
	    modification may cause you or anything having to do 
	    with you. If you lose your job because you play this
	    game nite and day, it is purely your responsibility.
	    I also am not responsable for any hardware failures 
	    or software problems that may arise in TRIBES. For 
	    problems of that nature contact the game manufacturer.
	    If you believe this modification has problems please 
	    report them to me so that I may look into it. -LabRat
----------------------------------------------------------------