//  Mod to keep players on even teams
//
//  Uses ModMgt by Shane Hyde
//  Download it from http://www.users.bigpond.net.au/shyde/tribes/
//

//  Name & version
//

$modmgtModName = "SHFairteams2";
$modmgtModVers = "1.30";

function SHResetStats()
{
    echo("Executing reset stats");

    %numteams = getNumTeams();
    %numPLayers = getNumClients();

    for(%i = 0; %i < %numTeams; %i = %i + 1)
    {
        $SHNumTeamPlayers[%i] = 0;
        $SHMinTeamScore[%i] = 0;
    }

    $SHMinTeamPlayers = 9999;
	$SHMaxTeamScore = 9999;

    for(%i = 0; %i < %numPlayers; %i = %i + 1)
    {
        %pl = getClientByIndex(%i);
        %team = Client::getTeam(%pl);
        $SHNumTeamPlayers[%team] = $SHNumTeamPlayers[%team] + 1;
        if(%pl.SHAddOrder  > $SHMinTeamScore[%team])
        {
            $SHMinTeamScore[%team] = %pl.SHAddOrder ;
            $SHMinTeamClient[%team] = %pl;
        }
    }
    for(%i=0;%i<%numteams;%i++)
    {
        if($SHNumTeamPlayers[%i] < $SHMinTeamPlayers)
        {
            $SHMinTeamPlayers = $SHNumTeamPlayers[%i];
        }
	if($TeamScore[%i] < $SHMaxTeamScore)
	{
		$SHMaxTeamScore = $teamScore[%i];
	}
    }
}

function DumpStats()
{
    %numteams = getNumTeams();
    echo("MinTeamPlayers " @ $SHMinTeamPlayers);
	echo("MinTeamScore " @ $SHMaxteamScore);
    for(%i=0;%i<%numteams;%i++)
    {
        echo("Team " @ %i);
        echo("Player count " @ $SHNumTeamPlayers[%i]);
        echo("MinClient " @ $SHMinTeamClient[%i]);
        echo("MinClientScore " @ $SHMinTeamScore[%i]);
    }
}

function CheckTeamsAreEven()
{
	if($SHAddOrder == "")
		$SHAddOrder = 1;

    %numPLayers = getNumClients();
    for(%i = 0; %i < %numPlayers; %i = %i + 1)
    {
        %pl = getClientByIndex(%i);
	if(%pl.SHAddOrder == "")
	{
		%pl.SHAddOrder = $SHAddOrder;
		$SHAddOrder++;
	}
    }
    SHResetStats();
//    DumpStats();

	if($SHFairTeams == "")
	{
	    schedule("CheckteamsAreEven();",30);
		return;
	}

    %numteams = getNumTeams();
    for(%i = 0; %i < %numTeams; %i = %i + 1)
    {
        if(($SHNumTeamPlayers[%i]-1 > $SHMinTeamPlayers || 
		($SHNumTeamPlayers[%i] > $SHMinTeamPlayers && %teamscore[%i] > $SHMaxTeamScore ))
		&& $SHNumTeamPlayers[%i] > 3)
        {
            if(%numteams == 2)
            {
                if($SHNumTeamPLayers[%i] > $SHNumTeamPlayers[1-%i]+1)
                {
                    processmenuPickTeam($SHMinTeamClient[%i],1-%i,"");
                    schedule("CheckteamsAreEven();",30);
                    return;
                }
                else
                    processMenuPickTeam($SHMinTeamClient[%i],-2,"");
            }
            else
                processMenuPickTeam($SHMinTeamClient[%i],-2,"");
        }
    }

    schedule("CheckteamsAreEven();",30);
}

schedule("CheckteamsAreEven();",30);
$SHFairTeams = 1;

echo($modmgtModName @ " v" @ $modmgtModVers @ " loaded");
