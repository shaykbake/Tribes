//  Mod to keep players from changing to the winning team
//
//  Uses ModMgt by Shane Hyde
//  Download it from http://www.users.bigpond.net.au/shyde/tribes/
//

//  Name & version
//

$modmgtModName = "SHFairteams";
$modmgtModVers = "1.30";

function processMenuOptions(%clientId, %option)
{
   %opt = getWord(%option, 0);
   %cl = getWord(%option, 1);

   if(%opt == "fteamchange")
   {
      %clientId.ptc = %cl;
      Client::buildMenu(%clientId, "Pick a team:", "FPickTeam", true);
      Client::addMenuItem(%clientId, "0Observer", -2);
      Client::addMenuItem(%clientId, "1Automatic", -1);
      for(%i = 0; %i < getNumTeams(); %i = %i + 1)
         Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
      return;
   }      
   else if(%opt == "changeteams")
   {
      if(!$matchStarted || !$Server::TourneyMode)
      {
         Client::buildMenu(%clientId, "Pick a team:", "PickTeam", true);
         Client::addMenuItem(%clientId, "0Observer", -2);
         Client::addMenuItem(%clientId, "1Automatic", -1);

		%name = Client::getName(%clientId);

		%numTeams = getNumTeams();
		%numPlayers = getNumClients();
		echo("Number of teams/players " @ %numteams @ "/" @ %numplayers);

      	for(%i = 0; %i < %numTeams; %i = %i + 1)
         		%numTeamPlayers[%i] = 0;

      	for(%i = 0; %i < %numPlayers; %i = %i + 1)
      	{
         		%pl = getClientByIndex(%i);
         		if(%pl != %clientId)
         		{
            		%team = Client::getTeam(%pl);
            		%numTeamPlayers[%team] = %numTeamPlayers[%team] + 1;
         		}
      	}

    		%mostPlayers = 0;
      	%mostTeam = -1;

		if(%numteams == 2)
		{
			if(%numteamplayers[0] > %numteamplayers[1] + 1)
				%mostteam = 0;
			else
			{
				if(%numteamplayers[0]+1 < %numteamplayers[1])
				{
					%mostteam = 1;
				}
			}
		}
				
      	for(%i = 0; %i < %numTeams; %i = %i + 1)
      	{
			echo("Team " @ %i @ " " @getteamname(%i) @ " has " @ %numTeamPlayers[%i] @ " and score " @ $teamScore[%mostTeam]);
      	}

		echo("Most team is team " @ %mostteam @ " " @ getteamname(%mostteam));

         	for(%i = 0; %i < getNumTeams(); %i = %i + 1)
		{
			if(%mostteam != %i || %mostteam == -1)
            		Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i);
		}

         return;
      }
   }
   else if(%opt == "mute")
      %clientId.muted[%cl] = true;
   else if(%opt == "unmute")
      %clientId.muted[%cl] = "";
   else if(%opt == "vkick")
   {
      %cl.voteTarget = true;
      Admin::startVote(%clientId, "kick " @ Client::getName(%cl), "kick", %cl);
   }
   else if(%opt == "vadmin")
   {
      %cl.voteTarget = true;
      Admin::startVote(%clientId, "admin " @ Client::getName(%cl), "admin", %cl);
   }
   else if(%opt == "vsmatch")
      Admin::startVote(%clientId, "start the match", "smatch", 0);
   else if(%opt == "vetd")
      Admin::startVote(%clientId, "enable team damage", "etd", 0);
   else if(%opt == "vdtd")
      Admin::startVote(%clientId, "disable team damage", "dtd", 0);
   else if(%opt == "etd")
      Admin::setTeamDamageEnable(%clientId, true);
   else if(%opt == "dtd")
      Admin::setTeamDamageEnable(%clientId, false);
   else if(%opt == "vcffa")
      Admin::startVote(%clientId, "change to Free For All mode", "ffa", 0);
   else if(%opt == "vctourney")
      Admin::startVote(%clientId, "change to Tournament mode", "tourney", 0);
   else if(%opt == "cffa")
      Admin::setModeFFA(%clientId);
   else if(%opt == "ctourney")
      Admin::setModeTourney(%clientId);
   else if(%opt == "voteYes" && %cl == $curVoteCount)
   {
      %clientId.vote = "yes";
      centerprint(%clientId, "", 0);
   }
   else if(%opt == "voteNo" && %cl == $curVoteCount)
   {
      %clientId.vote = "no";
      centerprint(%clientId, "", 0);
   }
   else if(%opt == "kick")
   {
      Client::buildMenu(%clientId, "Confirm kick:", "kaffirm", true);
      Client::addMenuItem(%clientId, "1Kick " @ Client::getName(%cl), "yes " @ %cl);
      Client::addMenuItem(%clientId, "2Don't kick " @ Client::getName(%cl), "no " @ %cl);
      return;
   }
   else if(%opt == "admin")
   {
      Client::buildMenu(%clientId, "Confirm admim:", "aaffirm", true);
      Client::addMenuItem(%clientId, "1Admin " @ Client::getName(%cl), "yes " @ %cl);
      Client::addMenuItem(%clientId, "2Don't admin " @ Client::getName(%cl), "no " @ %cl);
      return;
   }
   else if(%opt == "ban")
   {
      Client::buildMenu(%clientId, "Confirm Ban:", "baffirm", true);
      Client::addMenuItem(%clientId, "1Ban " @ Client::getName(%cl), "yes " @ %cl);
      Client::addMenuItem(%clientId, "2Don't ban " @ Client::getName(%cl), "no " @ %cl);
      return;
   }
   else if(%opt == "smatch")
         Admin::startMatch(%clientId);
   else if(%opt == "vcmission" || %opt == "cmission")
   {
      Admin::changeMissionMenu(%clientId, %opt == "cmission");
      return;
   }
   else if(%opt == "ctimelimit")
   {
       Client::buildMenu(%clientId, "Change Time Limit:", "ctlimit", true);
       Client::addMenuItem(%clientId, "110 Minutes", 10);
       Client::addMenuItem(%clientId, "215 Minutes", 15);
       Client::addMenuItem(%clientId, "320 Minutes", 20);
       Client::addMenuItem(%clientId, "425 Minutes", 25);
       Client::addMenuItem(%clientId, "530 Minutes", 30);
       Client::addMenuItem(%clientId, "645 Minutes", 45);
       Client::addMenuItem(%clientId, "760 Minutes", 60);
       Client::addMenuItem(%clientId, "8No Time Limit", 0);
       return;
    }
    else if(%opt == "reset")
    {
       Client::buildMenu(%clientId, "Confirm Reset:", "raffirm", true);
       Client::addMenuItem(%clientId, "1Reset", "yes");
       Client::addMenuItem(%clientId, "2Don't Reset", "no");
       return;
   }
   else if(%opt == "observe")
   {
      Observer::setTargetClient(%clientId, %cl);
      return;
   }
   Game::menuRequest(%clientId);
}

echo($modmgtModName @ " v" @ $modmgtModVers @ " loaded");
