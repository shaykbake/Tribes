//  Mod to keep players from Team Killing
//
//  Uses ModMgt by Shane Hyde
//

//  Name & version
//
$modmgtModName = "SHAntiTK";
$modmgtModVers = "1.30";

if($SHAntiTeamKillWarnKills == "")
	$SHAntiTeamKillWarnKills = 1;
if($SHAntiTeamKillBanTime == "")
	$SHAntiTeamKillBanTime = 600;
if($SHAntiTeamKillMaxKills == "")
	$SHAntiTeamKillMaxKills = 2;
if($SHAntiTeamKillProximity == "")
    $SHAntiTeamKillProximity = 50;

function Client::onKilled(%playerId, %killerId, %damageType)
{
   echo("GAME: kill " @ %killerId @ " " @ %playerId @ " " @ %damageType);

   %playerId.guiLock = true;
   Client::setGuiMode(%playerId, $GuiModePlay);
	if(!String::ICompare(Client::getGender(%playerId), "Male"))
   {
      %playerGender = "his";
   }
	else
	{
		%playerGender = "her";
	}
	%ridx = floor(getRandom() * ($numDeathMsgs - 0.01));
	%victimName = Client::getName(%playerId);


   if(!%killerId)
   {
      messageAll(0, strcat(%victimName, " dies."), $DeathMessageMask);
      %playerId.scoreDeaths++;
  }
   else if(%killerId == %playerId)
   {
	  %oopsMsg = sprintf($deathMsg[-2, %ridx], %victimName, %playerGender);
      messageAll(0, %oopsMsg, $DeathMessageMask);
      %playerId.scoreDeaths++;
      %playerId.score--;
      Game::refreshClientScore(%playerId);
   }
   else
   {
		if(!String::ICompare(Client::getGender(%killerId), "Male"))
		{
			%killerGender = "his";
		}
		else
		{
			%killerGender = "her";
		}
      if($teamplay && (Client::getTeam(%killerId) == Client::getTeam(%playerId)))
      {
          if(%damageType != $MineDamageType)
              messageAll(0, strcat(Client::getName(%killerId),
              " mows down ", %killerGender, " teammate, ", %victimName), $DeathMessageMask);
          else
              messageAll(0, strcat(Client::getName(%killerId),
              " killed ", %killerGender, " teammate, ", %victimName ," with a mine."), $DeathMessageMask);
          %killerId.scoreDeaths++;
         %playerId.score--;
         Game::refreshClientScore(%killerId);

         CheckTeamKiller(%killerId,%playerId,%damagetype);

      }
      else
      {
	     %obitMsg = sprintf($deathMsg[%damageType, %ridx], Client::getName(%killerId),
	       %victimName, %killerGender, %playerGender);
         messageAll(0, %obitMsg, $DeathMessageMask);
         %killerId.scoreKills++;
         %playerId.scoreDeaths++;  // test play mode
         %killerId.score++;
         Game::refreshClientScore(%killerId);
         Game::refreshClientScore(%playerId);
      }
   }
   Game::clientKilled(%playerId, %killerId);
}

function Game::resetScores(%client)
{
	if(%client == "") {
	   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
	      %cl.scoreKills = 0;
   	   %cl.scoreDeaths = 0;
			%cl.ratio = 0;
      	%cl.score = 0;
		%cl.TKCount = 0;
		}
	}
	else {
      %client.scoreKills = 0;
  	   %client.scoreDeaths = 0;
		%client.ratio = 0;
     	%client.score = 0;
	}
}

function CheckTeamKiller(%killerId,%playerId,%damagetype)
{
    if(%damagetype != $MineDamageType && %damagetype != $MortarDamageType)
    {
	%ppos = %playerid.TKDeathPos;
        for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
        {
		if($teamplay && (Client::getTeam(%killerId) != Client::getTeam(%cl)))
		{
			if(%cl != %playerId && %cl != %killerId)
			{
	      	      %pppos = GameBase::getPosition(%cl);

      	      	%dist = Vector::getDistance(%ppos,%pppos);
	
      	      	echo(CLient::getName(%cl) @ " was " @ %dist @ " from " @ Client::getName(%playerId));
				echo(%dist @ " " @ $SHAntiTeamKillProximity);

		            if(%dist < $SHAntiTeamKillProximity)
      		      {
            		    echo("Another player was close, kill is ok");
		                return;
      		      }
			}
		}
        }
	
        messageAll(0, "***" @ Client::getName(%killerId) @ " TeamKilled***");
        if(%killerid.TKCount == "")
        {
                %killerid.TKCount = 1;
        }
        else
        {
            %killerid.TKCount = %killerid.TKCount + 1;
            if(%killerid.TKCount > $SHAntiTeamKillMaxKills)
            {
                    %ip = Client::getTransportAddress(%killerId);
//                    BanList::add(%ip, $SHAntiTeamKillBanTime);
                    %killer = Client::getOwnedObject(%killerId);
                    messageAll(0, Client::getName(%killerId) @ " was kickbanned for teamkilling");
                    Net::kick(%killerId,"You have been kickbanned for team killing, i hope you enjoyed it.");
            }
            else
            if(%killerid.TKCount > $SHAntiTeamKillWarnKills)
            {
                Client::sendMessage(%killerId, 1, "You have killed " @ %killerId.TKCount @ " teammates. If you continue you will be kickbanned.");
            }
        }
    }
}

function Player::onKilled(%this)
{
	%cl = GameBase::getOwnerClient(%this);
	%cl.dead = 1;
	if($AutoRespawn > 0)
		schedule("Game::autoRespawn(" @ %cl @ ");",$AutoRespawn,%cl);
	if(%this.outArea==1)	
		leaveMissionAreaDamage(%cl);
	Player::setDamageFlash(%this,0.75);
	for (%i = 0; %i < 8; %i = %i + 1) {
		%type = Player::getMountedItem(%this,%i);
		if (%type != -1) {
			if (%i != $WeaponSlot || !Player::isTriggered(%this,%i) || getRandom() > "0.5") 
				Player::dropItem(%this,%type);
		}
	}

   if(%cl != -1)
   {
		if(%this.vehicle != "")	{
			if(%this.driver != "") {
				%this.driver = "";
        	 	Client::setControlObject(Player::getClient(%this), %this);
        	 	Player::setMountObject(%this, -1, 0);
			}
			else {
				%this.vehicle.Seat[%this.vehicleSlot-2] = "";
				%this.vehicleSlot = "";
			}
			%this.vehicle = "";		
		}
	%cl.TKDeathPos = GameBase::getPosition(%this);
	echo("Death pos = " @ %cl.TKDeathPos);

      schedule("GameBase::startFadeOut(" @ %this @ ");", $CorpseTimeoutValue, %this);
      Client::setOwnedObject(%cl, -1);
      Client::setControlObject(%cl, Client::getObserverCamera(%cl));
      Observer::setOrbitObject(%cl, %this, 5, 5, 5);
      schedule("deleteObject(" @ %this @ ");", $CorpseTimeoutValue + 2.5, %this);
      %cl.observerMode = "dead";
      %cl.dieTime = getSimTime();
   }
}

echo($modmgtModName @ " v" @ $modmgtModVers @ " loaded");
