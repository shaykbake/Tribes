//  Mod to create a deployable teleport pad
//
//  Uses ModMgt by Shane Hyde
//  Download it from http://www.users.bigpond.net.au/shyde/tribes/
//

//  Name & version
//
$modmgtModName = "SHTeleportMiss";
$modmgtModVers = "1.30";

$TeamItemCount[0 @ DeployableTeleport] = 0;
$TeamItemCount[1 @ DeployableTeleport] = 0;
$TeamItemCount[2 @ DeployableTeleport] = 0;
$TeamItemCount[3 @ DeployableTeleport] = 0;
$TeamItemCount[4 @ DeployableTeleport] = 0;
$TeamItemCount[5 @ DeployableTeleport] = 0;
$TeamItemCount[6 @ DeployableTeleport] = 0;
$TeamItemCount[7 @ DeployableTeleport] = 0;

echo($modmgtModName @ " v" @ $modmgtModVers @ " loaded");
