$FireModes[PlasmaGun] = 3;
//--------------------------------------

$AutoUse[PlasmaGun] = True;
addAmmo(PlasmaGun,PlasmaAmmo,5,30);

addToInv(PlasmaGun,1,1);
addToInv(PlasmaAmmo,1,1);

setArmorItemMax(PlasmaGun,1,1,1);
setArmorItemMax(PlasmaAmmo,30,40,50);

//--------------------------------------

GrenadeData PlasMalFuncBomb
{
   bulletShapeName    = "force.dts";
   explosionTag       = plasmaExp3;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass 	      = 5.0;
   elasticity	      = 0.1;

   damageClass	      = 1;	 // 0 impact, 1, radius
   damageValue	      = 0.075;
   damageType	      = $PlasMalFuncDamageType;

   explosionRadius    = 20;
   kickBackStrength   = 50.0;
   maxLevelFlightDist = 1;
   totalTime	      = 0.1;
   liveTime	      = 0.1;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;

   smokeName		  = "plasmatrail.dts";
};

//--------------------------------------

BulletData PlasmaBolt
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp0;

   damageClass	      = 1;
   damageValue	      = 0.45;
   damageType	      = $PlasmaDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 55.0;
   totalTime	      = 3.0;
   liveTime	      = 2.0;
   lightRange	      = 3.0;
   lightColor	      = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible	      = True;

   soundId = SoundJetLight;
};

//--------------------------------------

BulletData PlasmaBolt0
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp1;

   damageClass	      = 1;
   damageValue	      = 0.075;
   damageType	      = $PlasmaDamageType;
   explosionRadius    = 2.5;

   muzzleVelocity     = 80.0;
   totalTime	      = 3.0;
   liveTime	      = 2.0;
   lightRange	      = 3.0;
   lightColor	      = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible	      = True;

   soundId = SoundJetLight;
};

function PlasmaBolt0::onRemove(%this)
{
	 ReadyPlas(%this);
}

//--------------------------------------

BulletData PlasmaBolt1
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp0;

   damageClass	      = 1;
   damageValue	      = 0.075;
   damageType	      = $PlasmaDamageType;
   explosionRadius    = 5.0;

   muzzleVelocity     = 65.0;
   totalTime	      = 3.0;
   liveTime	      = 2.0;
   lightRange	      = 3.0;
   lightColor	      = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible	      = True;

   soundId = SoundJetLight;
};

function PlasmaBolt1::onRemove(%this)
{
	 ReadyPlas(%this);
}

//--------------------------------------

RocketData PlasmaBolt2
{
   bulletShapeName  = "plasmabolt.dts";
   explosionTag     = plasmaExp3;
   collisionRadius  = 0.0;
   mass 	    = 1.0;

   damageClass	    = 1;       // 0 impact, 1, radius
   damageValue	    = 0.075;
   damageType	    = $PlasmaDamageType;

   explosionRadius  = 10.0;
   kickBackStrength = 50.0;
   muzzleVelocity   = 40.0;
   terminalVelocity = 55.0;
   acceleration     = 5.0;
   totalTime	      = 3.0;
   liveTime	      = 2.0;
   lightRange	      = 3.0;
   lightColor	      = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;

   // rocket specific
   trailType   = 2;		   // smoke trail
   trailString = "plasmatrail.dts";
   smokeDist   = 0.1;

   soundId = SoundJetLight;
};

function PlasmaBolt2::onRemove(%this)
{
	 ReadyPlas(%this);
}

function ReadyPlas(%this)
{
	 %client = $PlasmaClient[%this];
	 %client.plasReady = true;
}
//--------------------------------------


ItemData PlasmaAmmo
{
	description = "Plasma Charges";
   heading = $InvCatAmmo;
	className = "Ammo";
	shapeFile = "plasammo";
	shadowDetailMask = 4;
	price = 2;
};

ItemImageData PlasmaGun2Image
{
	shapeFile = "plasma";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = PlasmaAmmo;
	accuFire = true;
	reloadTime = 0.0;
	fireTime = 0.0;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 1, 1, 0.2 };

	sfxFire = SoundFirePlasma;
	sfxReload = SoundDryFire;
};

ItemData PlasmaGun2
{
	description = "Plasma Charger";
	className = "Weapon";
	shapeFile = "plasma";
	hudIcon = "plasma";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = PlasmaGun2Image;
	price = 175;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData PlasmaGunImage
{
	shapeFile  = "breath";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = PlasmaAmmo;
	accuFire = true;
	reloadTime = 0.0;
	fireTime = 0.0;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 1, 1, 0.2 };

	sfxActivate = SoundPickUpWeapon;
};

ItemData PlasmaGun
{
	description = "Plasma Charger";
	className = "Weapon";
	shapeFile = "plasma";
	hudIcon = "plasma";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = PlasmaGunImage;
	price = 175;
	showWeaponBar = true;
   validateShape = true;
};

function PlasmaGunImage::onFire(%player, %slot)
{
	%client = Player::getClient(%player);
	if(%client.plasReady  == true || %client.plasReady == "") {
		if(Player::getItemCount(%player,PlasmaAmmo) > 0) {
			if($WeapMode[%client,PlasmaGun] >= $FireModes[PlasmaGun]) {
				%client.plasReady = false;
				%client.PlasUse = 1;
				$PlasmaClient[%client] = %client;
				%trans = getTransFix(%player);
				%vel = Item::getVelocity(%player);
				Player::trigger(%player,$ExtraSlotA,true);
				Player::trigger(%player,$ExtraSlotA,false);
				Projectile::spawnProjectile("PlasmaBolt",%trans,%player,%vel);
				Player::decItemCount(%player,PlasmaAmmo,1);
				schedule("ReadyPlas(" @ %client @ ");",0.6);
			}
			else if(!%player.ChrgOn) {
				%client.PlasUse = 0;
				%client.PlasBurst = 0;
				%player.TotMaxPlas = Player::getItemCount(%player,PlasmaAmmo);
				%player.MaxPlas = Player::getItemCount(%player,PlasmaAmmo);
				if(%player.MaxPlas > 30 && ($WeapMode[%client,PlasmaGun] <= 1 || $WeapMode[%client,PlasmaGun] == ""))
					%player.MaxPlas = 30;
				Plasma::Charge(%player,%player.TotMaxPlas);
			}
		}
	}
}

//charge coded by ProtoManX
function Plasma::Charge(%player,%ammo)
{
	%client = Player::getClient(%player);
	%state = Player::getItemState(%player,$WeaponSlot);
	if(%state == "Fire") {
		%player.ChrgOn = true;
		if(%ammo > 0 && %client.PlasUse < %player.MaxPlas) {
			%ammo -= 1;
			if(%ammo < 1)
				%ammo = 1;
			%client.PlasUse += 1;
		}
		Player::setItemCount(%player,PlasmaAmmo,%ammo);
		if(%client.PlasUse > %player.MaxPlas)
			%client.PlasUse = %player.MaxPlas;
		else if(%client.PlasUse > 30 && %client.pbcheck < %client.PlasUse) {
			%client.PlasBurst += 1;
		}
		if(%client.PlasBurst > 0 && %client.pbcheck < %client.PlasUse) {
			%rnd = floor(getRandom() * 100);
			if(%rnd < %client.PlasBurst) {
				%player.ChrgOn = false;
				%client.PlasUse += (Player::getItemCount(%player,PlasmaAmmo)/2);
				%trans = getTransFix(%player);
				%vel = Item::getVelocity(%player);
				GameBase::PlaySound(%player, SoundPackFail, 2);
				Projectile::spawnProjectile("PlasMalFuncBomb",%trans,%player,%vel);
				Player::unMountItem(%player,$WeaponSlot);
				Player::setItemCount(%player,PlasmaGun,0);
				Player::setItemCount(%player,PlasmaAmmo,0);
				%client.pbcheck = 0;
				return;
			}
			%client.pbcheck = %client.PlasUse;
		}
		Bottomprint(%client, "<JC><F1>Plasma Charges: <F2>" @ %client.PlasUse,1);
		schedule("Plasma::Charge(" @ %player @ "," @ Player::getItemCount(%player,PlasmaAmmo) @ ");",0.1);
	}
	else {
		%player.ChrgOn = false;
		//%trans = GameBase::getMuzzleTransform(%player);
		%trans = getTransFix(%player);
		%vel = Item::getVelocity(%player);
		Player::trigger(%player,$ExtraSlotA,true);
		Player::trigger(%player,$ExtraSlotA,false);
		if(%client.PlasUse < 10)
			%plasmaproj = Projectile::spawnProjectile("PlasmaBolt0",%trans,%player,%vel);
		else if(%client.PlasUse < 20)
			%plasmaproj = Projectile::spawnProjectile("PlasmaBolt1",%trans,%player,%vel);
		else
			%plasmaproj = Projectile::spawnProjectile("PlasmaBolt2",%trans,%player,%vel);
		$PlasmaClient[%plasmaproj] = %client;
		%client.plasReady = false;
		if(%client.PlasUse == %player.MaxPlas && %player.MaxPlas == %player.TotMaxPlas)
			Player::setItemCount(%player,PlasmaAmmo,0);
	}
}

function PlasmaGun::onMount(%player,%item)
{
	Player::mountItem(%player,PlasmaGun2,$ExtraSlotA);
}

function PlasmaGun::onUnMount(%player,%item)
{
	Player::unmountItem(%player,$ExtraSlotA);
}

$MountMSG[PlasmaGun,1] = "<JC><F2>Plasma Charger[Limiter: On] <F0>- <F1>Fires charged balls of superheated plasma.";
$MountMSG[PlasmaGun,2] = "<JC><F2>Plasma Charger[Limiter: Off] <F0>- <F1>Fires charged balls of superheated plasma.";
$MountMSG[PlasmaGun,3] = "<JC><F2>Plasma Charger[Single Shot] <F0>- <F1>Fires balls of superheated plasma.";

AddWeapon(PlasmaGun);
