//--------------------------------------

$AutoUse[SpawnGun] = True;
addAmmo(SpawnGun,SpawnAmmo,1,1);

addToInv(SpawnGun,1,1);
addToInv(SpawnAmmo,1,1);

setArmorItemMax(SpawnGun,1,1,1);
setArmorItemMax(SpawnAmmo,1,2,3);

//---------------------------------------
GrenadeData MommaShell
{
   bulletShapeName = "shotgunbolt.dts";
   explosionTag       = plasmaExp0;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 0.8;
   elasticity         = 0.75;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.5;
   damageType         = $SpawnDamageType;

   explosionRadius    = 10;
   kickBackStrength   = 50.0;
   maxLevelFlightDist = 60;
   totalTime          = 7.0;    // special meaning for grenades...
   liveTime           = 6.0;
   projSpecialTime    = 0.075;

   inheritedVelocityScale = 0.5;

   smokeName              = "plasmatrail.dts";
};

function MommaShell::onRemove(%this)
{
         $Babies[%this] = false;
}

//Babies--------------------------------------
GrenadeData BabyShell
{
   bulletShapeName    = "plasmatrail.dts";
   explosionTag       = plasmaExp2;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 0.6;
   elasticity         = 0.6;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.25;
   damageType         = $SpawnDamageType;

   explosionRadius    = 7.5;
   kickBackStrength   = 25.0;
   maxLevelFlightDist = 40.0;
   totalTime          = 6.0;    // special meaning for grenades...
   liveTime           = 5.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "laserhit.dts";
};

//--------------------------------------

ItemData SpawnAmmo
{
        description = "Mysterious Eggs";
        className = "Ammo";
   heading = $InvCatAmmo;
        shapeFile = "grenade";
        shadowDetailMask = 4;
        price = 5;
};

ItemImageData SpawnEggImage
{
   shapeFile  = "grenade";
        mountPoint = 0;
        mountRotation = { -1.57, 0.0, 0.0 };
//        mountOffset = { 0.0, 0.0, 0.0 };

        weaponType = 0; // Single Shot
        reloadTime = 0;
        fireTime = 0.0;
        minEnergy = 0;
        maxEnergy = 0;

        accuFire = true;
};

ItemData SpawnEgg
{
   heading = $InvCatWeapons[All];
        description = "Hatchling Gun";
        className = "Weapon";
   shapeFile  = "energygun";
        hudIcon = "blaster";
        shadowDetailMask = 4;
        imageType = SpawnEggImage;
        price = 0;
        showWeaponBar = false;
        showinventory = false;
};

ItemImageData SpawnGunImage
{
        shapeFile = "energygun";
        mountPoint = 0;

        weaponType = 0; // Single Shot
        ammoType = SpawnAmmo;
//        projectileType = MommaShell;
        accuFire = false;
        reloadTime = 4.0;
        fireTime = 2.0;

        lightType = 3;  // Weapon Fire
        lightRadius = 3;
        lightTime = 1;
        lightColor = { 1, 1, 0.2 };

        sfxFire = bigExplosion1;
        sfxActivate = SoundPickUpWeapon;
        sfxReload = SoundMortarReload;
        sfxReady = SoundMortarIdle;
};

ItemData SpawnGun
{
        description = "Hatchling Gun";
        className = "Weapon";
        shapeFile = "energygun";
        hudIcon = "ammopack";
   heading = $InvCatWeapons[All];
        shadowDetailMask = 4;
        imageType = SpawnGunImage;
        price = 500;
        showWeaponBar = true;
};

function SpawnGunImage::onFire(%player, %slot)
{
        %client = Player::getClient(%player);
        %ammo = Player::getItemCount(%player,SpawnAmmo);
        if(%ammo > 0) {
                %trans = getTransFix(%player);
                %vel = Item::getVelocity(%player);
                %obj = Projectile::spawnProjectile(MommaShell,%trans,%player,%vel);
                $Babies[%obj] = true;
                schedule("SpawnBabies(" @ %player @ ", " @ %client @ ", " @ %obj @ ");", 0.5);
                Player::decItemCount(%player,SpawnAmmo,1);
        }
}

function SpawnBabies(%player, %client, %obj) {
        if($Babies[%obj]) {
                %babies = floor(getRandom() * 3) + 1;
                %pos = GameBase::getPosition(%obj);
                %vel = Item::getVelocity(%obj);
                for(%i = 0; %i < %babies; %i++) {
                        %xrnd = floor(getRandom() * 60) -30;
                        %yrnd = floor(getRandom() * 60) -30;
                        %zrnd = floor(getRandom() * 60) -30;
                        %newvel = %xrnd@" "@%yrnd@" "@%zrnd;
                        %trans =  "0 0 1 0 0 0 0 0 1 " @ getBoxCenter(%obj);
                        %newobj = Projectile::spawnProjectile(BabyShell,%trans,%player,%vel);
                        GameBase::setPosition(%newobj, %pos);
                        Item::setVelocity(%newobj, %newvel);
                }
                schedule("SpawnBabies(" @ %player @ ", " @ %client @ ", " @ %obj @ ");", 0.5);
        }
}

function SpawnGun::onMount(%player,%item)
{
        Player::mountItem(%player,SpawnEgg,$ExtraSlotA);
}

function SpawnGun::onUnMount(%player,%item)
{
        Player::unmountItem(%player,$ExtraSlotA);
}

$MountMSG[SpawnGun] = "<JC><F2>Hatchling Gun <F0>- <F1>Lobs a mysterious creature from an egg that is hatched just before launch.";

AddWeapon(SpawnGun);
