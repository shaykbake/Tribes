//--------------------------------------

$AutoUse[PickerKnife] = True;
$WeaponAmmo[PickerKnife] = "";

addToInv(PickerKnife,1,1);

setArmorItemMax(PickerKnife,1,1,1);

//--------------------------------------

LightningData pickerCharge
{
   bitmapName       = "smoke01.bmp";

   damageType       = $NullDamageType;
   boltLength       = 7.5;
   coneAngle        = 5.0;
   damagePerSec      = 0.0;
   energyDrainPerSec = 0.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;//075;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = false;
};

function pickerCharge::steal(%client, %target)
{
        %playerID = Player::getClient(%client);
        %objectID = Player::getClient(%target);

        %chance = 100;
        %vel = Item::getVelocity(%objectID);
        if(%vel != "0 0 0")
                %chance -= 10;
        %vel = Item::getVelocity(%playerID);
        if(%vel != "0 0 0")
                %chance -= 15;
        $los::object = "";
        if(GameBase::getLOSInfo(%objectID,3)) {
                if($los::object == %playerID)
                        %chance -= 30;
        }
        $los::object = "";
        if(GameBase::getLOSInfo(%playerID,3)) {
                if($los::object != %objectID)
                        %chance -= 15;
        }
        %dist = Vector::getDistance(GameBase::getPosition(%playerID),GameBase::getPosition(%objectID));
        if(%dist > 0) {
                %chance -= (%dist * 4);
        }

        if(%chance > 0) {
                %roll = floor(getRandom() * 100);
                if(%roll < %chance) {
                        %sound = false;
                        %max = getNumItems();
                        %y = 0;
                        for (%i = 0; %i < %max; %i++) {
                                %count = Player::getItemCount(%objectID,%i);
                                %item = getItemData(%i);
                                if(%count && (%item.className == Ammo || %item.className == HandAmmo || %item == RepairKit)) {
                                        %stealIndex[%y] = %item;
                                        %stealCount[%y] = %count;
                                        %y++;
                                }
                        }
                        %rnd = floor(getRandom() * %y);
                        %item = %stealIndex[%rnd];
                        %amnt = floor(getRandom() * (%stealCount[%rnd] + 1));
                        %delta = Item::giveItem(%playerID,%item,%amnt);
                        if(%delta) {
                                Player::decItemCount(%objectID,%item,%delta);
                                %alert = floor(getRandom() * 100) - %chance;
                                if(%alert > 0) {
                                        Client::sendMessage(%objectID,1, "Someone has just stolen from you.~wAccess_Denied.wav");
                                }
                                Client::sendMessage(%playerID,3, "You stole " @ %delta @ " " @ %item.description @ " from " @ Client::getName(%objectID) @ ".");
                                playSound(SoundPickupItem,GameBase::getPosition(%playerID));
                        }
                }
        }
}

function pickerCharge::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
        if(%target.shieldStrength > 0 || getObjectType(%target) != "Player") {
                return;
        }
        else {
                pickerCharge::steal(%shooterID,%target);
        }
}

//--------------------------------------

ItemImageData PickerKnifeImage
{
   shapeFile = "force";
   mountPoint = 0;

   weaponType = 0;  // Sustained
   //projectileType = pickerCharge;
   minEnergy = 30;
   maxEnergy = 55;  // Energy used/sec for sustained weapons
   reloadTime = 1.0;

   lightType = 3;  // Weapon Fire
   lightRadius = 2;
   lightTime = 1;
   lightColor = { 0.25, 0.25, 0.85 };

   sfxActivate = false;
   sfxFire     = false;
};

ItemData PickerKnife
{
   description = "Pick Pocket's Knife";
   shapeFile = "force";
   hudIcon = "energyRifle";
   className = "Weapon";
   heading = $InvCatWeapons[All];
   shadowDetailMask = 4;
   imageType = PickerKnifeImage;
   showWeaponBar = true;
   price = 125;
};

function PickerKnifeImage::onFire(%player, %slot)
{
        %trans = getTransFix(%player);
        %vel = Item::getVelocity(%player);
        %obj = Projectile::spawnProjectile("pickerCharge",%trans,%player,%vel);
        schedule("deleteobject("@%obj@");",0.1);
        schedule("Player::trigger("@%player@", 0, false);",1);
}

$MountMSG[PickerKnife] = "<JC><F2>Pick Pocket's Knife <F0>- <F1>A small device used to slip items from a target's inventory.";

AddWeapon(PickerKnife);
