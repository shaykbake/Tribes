//--------------------------------------

$AutoUse[GrenadeLauncher] = True;
addAmmo(GrenadeLauncher,GrenadeAmmo,2,14);

addToInv(GrenadeLauncher,1,1);
addToInv(GrenadeAmmo,1,1);

setArmorItemMax(GrenadeLauncher,1,2,2);
setArmorItemMax(GrenadeAmmo,10,10,14);

//--------------------------------------

GrenadeData GrenadeShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass 	      = 1.0;
   elasticity	      = 0.45;

   damageClass	      = 1;	 // 0 impact, 1, radius
   damageValue	      = 0.4;
   damageType	      = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 150;
   totalTime	      = 30.0;	 // special meaning for grenades...
   liveTime	      = 1.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName		  = "smoke.dts";
};

//--------------------------------------

ItemData GrenadeAmmo
{
	description = "Grenade Ammo";
	className = "Ammo";
	shapeFile = "grenammo";
   heading = $InvCatAmmo;
	shadowDetailMask = 4;
	price = 2;
};

ItemImageData GrenadeLauncherImage
{
	shapeFile = "breath";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = GrenadeAmmo;
//	  projectileType = GrenadeShell;
	accuFire = false;
	reloadTime = 0.25;
	fireTime = 0.25;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxActivate = SoundPickUpWeapon;
};

ItemData GrenadeLauncher
{
	description = "Grenade Launcher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = GrenadeLauncherImage;
	price = 150;
	showWeaponBar = true;
   validateShape = true;
};

ItemImageData GrenadeLauncherAImage
{
	shapeFile = "grenadeL";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = GrenadeAmmo;
	projectileType = GrenadeShell;
	accuFire = false;
	reloadTime = 0.0;
	fireTime = 0.0;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireGrenade;
	sfxReload = SoundDryFire;
};

ItemData GrenadeLauncherA
{
	description = "Grenade Launcher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = GrenadeLauncherAImage;
	price = 150;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData GrenadeLauncherBMImage
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = { -0.75, 0, 0 };

	weaponType = 0; // Single Shot
	ammoType = GrenadeAmmo;
	projectileType = GrenadeShell;
	accuFire = false;
	reloadTime = 0.5;
	fireTime = 0.0;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireGrenade;
	sfxReload = SoundDryFire;
};

ItemData GrenadeLauncherBM
{
	description = "Grenade Launcher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = GrenadeLauncherBMImage;
	price = 150;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData GrenadeLauncherBHImage
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = { -1.2, 0, 0 };

	weaponType = 0; // Single Shot
	ammoType = GrenadeAmmo;
	projectileType = GrenadeShell;
	accuFire = false;
	reloadTime = 0.5;
	fireTime = 0.0;

	lightType = 3;	// Weapon Fire
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireGrenade;
	sfxReload = SoundDryFire;
};

ItemData GrenadeLauncherBH
{
	description = "Grenade Launcher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = $InvCatWeapons[All];
	shadowDetailMask = 4;
	imageType = GrenadeLauncherBHImage;
	price = 150;
	showWeaponBar = false;
	showinventory = false;
};

function GrenadeLauncherImage::onFire(%player, %slot)
{
	%client = Player::getClient(%player);
	%wieldnum = Player::getItemCount(%player,"GrenadeLauncher");
	%ammo = Player::getItemCount(%player,GrenadeAmmo);
	%fired = 0;
	if(%ammo >= 1) {
		if(%wieldnum == 2) {
			if($DualWMode[%client] <= 1 || $DualWMode[%client] == "") {
				if($SlotReady[%player, $ExtraSlotA] == true) {
					%fired += 1;
					Player::trigger(%player,$ExtraSlotA,true);
					Player::trigger(%player,$ExtraSlotA,false);
					$SlotReady[%player, $ExtraSlotA] = false;
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotA @ ");", 1.0);
				}
				else if($SlotReady[%player, $ExtraSlotB] == true) {
					%fired += 1;
					Player::trigger(%player,$ExtraSlotB,true);
					Player::trigger(%player,$ExtraSlotB,false);
					$SlotReady[%player, $ExtraSlotB] = false;
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotB @ ");", 1.0);
				}
			}
			else if($SlotReady[%player, $ExtraSlotA] == true && $SlotReady[%player, $ExtraSlotB] == true) {
				%fired += 1;
				Player::trigger(%player,$ExtraSlotA,true);
				Player::trigger(%player,$ExtraSlotA,false);
				$SlotReady[%player, $ExtraSlotA] = false;
				schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotA @ ");", 1.0);
				if(%ammo >= 2) {
					%fired += 1;
					Player::trigger(%player,$ExtraSlotB,true);
					Player::trigger(%player,$ExtraSlotB,false);
					$SlotReady[%player, $ExtraSlotB] = false;
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotB @ ");", 1.0);
				}
			}
		}
		else {
			if($SlotReady[%player, $ExtraSlotA] == true) {
				%fired += 1;
				Player::trigger(%player,$ExtraSlotA,true);
				Player::trigger(%player,$ExtraSlotA,false);
				$SlotReady[%player, $ExtraSlotA] = false;
				schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotA @ ");", 1.0);
			}
		}
	}
}

function GrenadeLauncher::onMount(%player,%item)
{
	Player::mountItem(%player,GrenadeLauncherA,$ExtraSlotA);
	%wieldnum = Player::getItemCount(%player,"GrenadeLauncher");
	if(%wieldnum == 2) {
		%armor = $ArmorName[Player::getArmor(%player)];
		if($ArmorSize[%armor] == "Medium")
			Player::mountItem(%player,GrenadeLauncherBM,$ExtraSlotB);
		if($ArmorSize[%armor] == "Heavy")
			Player::mountItem(%player,GrenadeLauncherBH,$ExtraSlotB);
	}
}

function GrenadeLauncher::onUnMount(%player,%item)
{
	Player::unmountItem(%player,$ExtraSlotA);
	Player::unmountItem(%player,$ExtraSlotB);
}

function GrenadeLauncher::onDrop(%player,%item)
{
	%client = Player::getClient(%player);
	%wieldnum = Player::getItemCount(%player,%item);
	%mount = Player::getMountedItem(%client,$WeaponSlot);
	Weapon::onDrop(%player,%item);
	if(%wieldnum == 2 && %mount == %item) {
		Player::unmountItem(%player,$WeaponSlot);
		Player::mountItem(%player,%item,$WeaponSlot);
	}
}

$MountMSG[GrenadeLauncher] = "<JC><F2>Grenade Launcher <F0>- <F1>Lobs concussion grenades.";

AddWeapon(GrenadeLauncher);
