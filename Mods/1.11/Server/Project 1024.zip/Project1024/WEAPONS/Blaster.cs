//--------------------------------------

$AutoUse[Blaster] = True;
$Use[Blaster] = True;
$WeaponAmmo[Blaster] = "";

addToInv(Blaster,1,1);

setArmorItemMax(Blaster,2,2,2);

//--------------------------------------

RocketData BlasterRocket
{
   bulletShapeName  = "shotgunbolt.dts";
   explosionTag     = blasterExp;
   collisionRadius  = 0.0;
   mass 	    = 1.0;

   damageClass	    = 0;       // 0 impact, 1, radius
   damageValue	    = 0.125;
   damageType	    = $BlasterDamageType;

   explosionRadius  = 0.0;
   kickBackStrength = 25.0;
   muzzleVelocity   = 160.0;
   terminalVelocity = 200.0;
   acceleration     = 10.0;
   totalTime	      = 2.0;
   liveTime	      = 1.125;
   lightRange	      = 3.0;
   lightColor	      = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;		   // smoke trail
   trailString = "laserhit.dts";
   smokeDist   = 3.0;
};

//--------------------------------------

ItemImageData BlasterAImage
{
   shapeFile  = "energygun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.0;
	minEnergy = 0;
	maxEnergy = 0;

	projectileType = BlasterRocket;
	accuFire = true;

	sfxFire = SoundFireBlaster;
};

ItemData BlasterA
{
   heading = $InvCatWeapons[All];
	description = "Blaster";
	className = "Weapon";
   shapeFile  = "energygun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = BlasterAImage;
	price = 0;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData BlasterBLImage
{
   shapeFile  = "energygun";
	mountPoint = 0;
	mountOffset = { -0.95, 0, 0 };

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.0;
	minEnergy = 0;
	maxEnergy = 0;

	projectileType = BlasterRocket;
	accuFire = true;

	sfxFire = SoundFireBlaster;
};

ItemData BlasterBL
{
   heading = $InvCatWeapons[All];
	description = "Blaster";
	className = "Weapon";
   shapeFile  = "energygun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = BlasterBLImage;
	price = 0;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData BlasterBMImage
{
   shapeFile  = "energygun";
	mountPoint = 0;
	mountOffset = { -0.75, 0, 0 };

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.0;
	minEnergy = 0;
	maxEnergy = 0;

	projectileType = BlasterRocket;
	accuFire = true;

	sfxFire = SoundFireBlaster;
};

ItemData BlasterBM
{
   heading = $InvCatWeapons[All];
	description = "Blaster";
	className = "Weapon";
   shapeFile  = "energygun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = BlasterBMImage;
	price = 0;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData BlasterBHImage
{
   shapeFile  = "energygun";
	mountPoint = 0;
	mountOffset = { -1.2, 0, 0 };

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.0;
	minEnergy = 0;
	maxEnergy = 0;

	projectileType = BlasterRocket;
	accuFire = true;

	sfxFire = SoundFireBlaster;
};

ItemData BlasterBH
{
   heading = $InvCatWeapons[All];
	description = "Blaster";
	className = "Weapon";
   shapeFile  = "energygun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = BlasterBHImage;
	price = 0;
	showWeaponBar = false;
	showinventory = false;
};

ItemImageData BlasterImage
{
   shapeFile  = "breath";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.15;
	minEnergy = 0;
	maxEnergy = 0;

	accuFire = true;

	sfxActivate = SoundPickUpWeapon;
};

ItemData Blaster
{
   heading = $InvCatWeapons[All];
	description = "Blaster";
	className = "Weapon";
   shapeFile  = "energygun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = BlasterImage;
	price = 85;
	showWeaponBar = true;
};

function BlasterImage::onFire(%player, %slot)
{
	%client = Player::getClient(%player);
	%wieldnum = Player::getItemCount(%player,"Blaster");
	%energy = GameBase::getEnergy(%player);
	if(%energy >= 5) {
		if(%wieldnum == 2) {
			if($DualWMode[%client] <= 1 || $DualWMode[%client] == "") {
				if($SlotReady[%player, $ExtraSlotA] == true) {
					%energy -= 6;
					Player::trigger(%player,$ExtraSlotA,true);
					Player::trigger(%player,$ExtraSlotA,false);
					$SlotReady[%player, $ExtraSlotA] = false;
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotA @ ");", 0.3);
				}
				else if($SlotReady[%player, $ExtraSlotB] == true) {
					%energy -= 6;
					Player::trigger(%player,$ExtraSlotB,true);
					Player::trigger(%player,$ExtraSlotB,false);
					$SlotReady[%player, $ExtraSlotB] = false;
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotB @ ");", 0.3);
				}
			}
			else if($SlotReady[%player, $ExtraSlotA] == true && $SlotReady[%player, $ExtraSlotB] == true) {
				if(%energy >= 10) {
					%energy -= 12;
					Player::trigger(%player,$ExtraSlotA,true);
					Player::trigger(%player,$ExtraSlotB,true);
					Player::trigger(%player,$ExtraSlotA,false);
					Player::trigger(%player,$ExtraSlotB,false);
					$SlotReady[%player, $ExtraSlotA] = false;
					$SlotReady[%player, $ExtraSlotB] = false;
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotA @ ");", 0.3);
					schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotB @ ");", 0.3);
				}
			}
		}
		else {
			if($SlotReady[%player, $ExtraSlotA] == true) {
				%energy -= 6;
				Player::trigger(%player,$ExtraSlotA,true);
				Player::trigger(%player,$ExtraSlotA,false);
				$SlotReady[%player, $ExtraSlotA] = false;
				schedule("ReadySlot(" @ %player @ ", " @ $ExtraSlotA @ ");", 0.3);
			}
		}
		if(%energy < 0) {
			%energy = 0;
		}
		GameBase::setEnergy(%player,%energy);
	}
}

function ReadySlot(%player, %slot)
{
	$SlotReady[%player, %slot] = true;
}

function Blaster::onMount(%player,%item)
{
	Player::mountItem(%player,BlasterA,$ExtraSlotA);
	%wieldnum = Player::getItemCount(%player,"Blaster");
	if(%wieldnum == 2) {
		%armor = $ArmorName[Player::getArmor(%player)];
		if($ArmorSize[%armor] == "Light")
			Player::mountItem(%player,BlasterBL,$ExtraSlotB);
		if($ArmorSize[%armor] == "Medium")
			Player::mountItem(%player,BlasterBM,$ExtraSlotB);
		if($ArmorSize[%armor] == "Heavy")
			Player::mountItem(%player,BlasterBH,$ExtraSlotB);
	}
}

function Blaster::onUnMount(%player,%item)
{
	Player::unmountItem(%player,$ExtraSlotA);
	Player::unmountItem(%player,$ExtraSlotB);
}

function Blaster::onDrop(%player,%item)
{
	%client = Player::getClient(%player);
	%wieldnum = Player::getItemCount(%player,%item);
	%mount = Player::getMountedItem(%client,$WeaponSlot);
	Weapon::onDrop(%player,%item);
	if(%wieldnum == 2 && %mount == %item) {
		Player::unmountItem(%player,$WeaponSlot);
		Player::mountItem(%player,%item,$WeaponSlot);
	}
}

$MountMSG[Blaster] = "<JC><F2>Blaster <F0>- <F1>Fire small energy bolts at your enemies.";

AddWeapon(Blaster);
