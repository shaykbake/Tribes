//                              Custom Server Settings:
//===========================================================================================
// Allow Custom Skins.
$Project1024::customSkins = true;

// Allow Voting Admin.
$Project1024::VoteAdmin = true;

// Allow Voting To Kick.
$Project1024::VoteKick = true;

// Kick/Ban Times:
$Project1024::KickTime = 180;
$Project1024::BanTime = 1800;

// Cheats:(admins only cheats)
$Project1024::CheatsForAdmins = true;

// SuperAdmin Passwords:
$Project1024::Super[0] = "";
$Project1024::Super[1] = "";
$Project1024::Super[2] = "";
$Project1024::Super[3] = "";
$Project1024::Super[4] = "";
$Project1024::Super[5] = "";


// PublicAdmin Passwords:
$Project1024::Public[0] = "";
$Project1024::Public[1] = "";
$Project1024::Public[2] = "";
$Project1024::Public[3] = "";
$Project1024::Public[4] = "";
$Project1024::Public[5] = "";

//Number of tries a player has to attempt admin passwords -1 ie 2 = 3 tries
$StrikeLimit = 2;

// Allow Public Admins To Kick.
$Project1024::PublicKick = true;

// Allow Public Admins To Change Mission.
$Project1024::PublicChngMission = true;

// Allow Public Admins To View\Change Server Options.
$Project1024::PublicSvrOpts = false;
//===========================================================================================

//                             General Server Settings:
//===========================================================================================
// Server Name, Shown In The Servers List.
$Server::HostName = "PRoject 1024 Server";

// Port Of Server, Usually 28001.
$Server::Port = "28001";

// Allow People To Connect To Your Server(true = yes | false = no).
$Server::HostPublicGame = true;

// Maximum Allowed Players.
$Server::MaxPlayers = "8";

// Leave Blank Unless You Want People To Enter A Password To Join Your Server.
$Server::Password = "";

// Set This To The Mission You Would Like The Server To Start On(Check Spelling).
$pref::LastMission = "Raindance";

// When You Highlight A Server, Then Click Info..You'll See This Screen.
$Server::Info = "Project 1024 server setup\nAdmin: Unknown\nEmail: Unknown";

// Message To Display When You First Join The Server(After The Loading Screen).
$Server::JoinMOTD = "<jc><f1>Email mod suggestions to TheDrunk007@yahoo.com";

// Port for telnet connections.
$TelnetPort = "";

// Password for telnet connections.
$TelnetPassword = "";

// Packet rate for client connections(recommended for cable)
$pref::PacketRate = 30;

// Packet size for client connections(recommended for cable)
$pref::PacketSize = 500;

// Minimum Allowed Votes To Succeed.
$Server::MinVotes = "2";

// ??
$Server::MinVotesPct = "0.5";

// Minimum Allowed Time To Vote.
$Server::MinVoteTime = "45";

// This Is The Delay Time After You Are Killed B4 You Can Spawn.
$Server::respawnTime = "2";

// Team Damage: (1 = on | 0 = off).
$Server::TeamDamageScale = "0";

// Mission time limit in minutes.
$Server::TimeLimit       = 30;

// Warmup Time B4 Match Starts.
$Server::WarmupTime      = 15;

// Start In Tournament Mode(true = yes | false = no).
$Server::TourneyMode = "false";

// ??
$Server::VoteAdminWinMargin = "0.66";

// ??
$Server::VoteFailTime = "30";

// ??
$Server::VoteWinMargin = "0.55";

// Overall Time For Vote.
$Server::VotingTime = "20";

// Time B4 Match Starts On Each New Mission.
$Server::warmupTime = "20";

// Auto-Set Teams When People Connect Or Let Them Pick(true = auto-assign | false = don't).
$Server::AutoAssignTeams = "true";


// Team Names & Team Skins:
$Server::teamName0 = "Blue";
$Server::teamSkin0 = "blue";

$Server::teamName1 = "Purple";
$Server::teamSkin1 = "purple";

$Server::teamName2 = "Base";
$Server::teamSkin2 = "base";

$Server::teamName3 = "Green";
$Server::teamSkin3 = "green";

$Server::teamName4 = "Blood Eagle";
$Server::teamSkin4 = "beagle";

$Server::teamName5 = "Diamond Sword";
$Server::teamSkin5 = "dsword";

$Server::teamName6 = "Starwolf";
$Server::teamSkin6 = "swolf";

$Server::teamName7 = "Children of the Phoenix";
$Server::teamSkin7 = "cphoenix";
