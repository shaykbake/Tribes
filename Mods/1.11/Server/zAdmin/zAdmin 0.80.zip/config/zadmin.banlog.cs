$IPBan1 = "IP:65.206               IP:65.206               TSI cheats so he can be mediocre";
$IPBanCount = "1";