zadmin::setCurrentAdminLevel("Public Admin");
zadmin::addAdmin("abc",	"123");

zadmin::setCurrentAdminLevel("General Admin");
zadmin::addAdmin("def",	"234");

zadmin::setCurrentAdminLevel("Super Admin");
zadmin::addAdmin("ghi",	"345");

zadmin::setCurrentAdminLevel("Ultra Admin");
zadmin::addAdmin("jkl",	"456");

zadmin::setCurrentAdminLevel("Jesus Christ");
zadmin::addAdmin("mno",	"567");