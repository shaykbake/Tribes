$zAdmin::ActiveMode = false;

//receive the active mode response from the server
function remotezAdminActiveMode(%client, %state)
{
	$zAdmin::ActiveMode = true;
}


function zAdmin::InitActiveMode()
{
	//dont call these on our own server
	if (String::FindSubStr($Server::Address, "LOOPBACK") != -1)
		return;
	
	
	$zAdmin::ActiveMode = false;
	//call the serverside function to put us in to active mode
	RemoteEval(2048, zAdminActiveMode);
}

Event::Attach(eventConnectionAccepted, zAdmin::InitActiveMode);

//--------------------------------------------
//
// these are all the functions called by the 
// server. they will only be called if you
// report to the server that you are in active
// mode
//	


//--------------------------------------------

function remoteItemReceived(%client, %item, %count)
{
	echo("Received " @ %count @ " " @ %item);
}

//--------------------------------------------

function remoteKillTrak(%client, %killer, %victim, %weapon)
{
	echo(%killer @ " just killed " @ %victim @ " with " @ %weapon);
}

//--------------------------------------------

function remoteMatchStarted(%client)
{
	echo("Match Started.");
}


//--------------------------------------------
// Inventory, RemoteInventory, Vehicle

function remoteEnterStation(%client, %station)
{
	echo("Entered Station type: " @ %station);
}

function remoteExitStation(%client, %station)
{
	echo("Exited Station type: " @ %station);
}

//--------------------------------------------

function remoteTeamScore(%client, %team, %score)
{
	echo("Team " @ %team @ " score = " @ %score);
}


//--------------------------------------------

function remoteFlagTaken(%client, %team, %player)
{
	echo(%player @ " just took the " @ %team @ " flag");
}

function remoteFlagDropped(%client, %team, %player)
{
	echo(%player @ " just dropped the " @ %team @ " flag");
}

function remoteFlagReturned(%client, %team, %player)
{
	echo(%player @ " just returned the " @ %team @ " flag");
}

function remoteFlagCaptured(%client, %team, %player)
{
	echo(%player @ " just captured the " @ %team @ " flag");
}