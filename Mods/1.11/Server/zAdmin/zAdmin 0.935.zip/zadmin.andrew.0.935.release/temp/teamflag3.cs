//--- export object begin ---//
instant Item "Flag" {
	dataBlock = "Flag";
	name = "";
	position = "-539.379 -308 175.99";
	rotation = "0 0 0";
	destroyable = "True";
	deleteOnDestroy = "False";
	rotates = "False";
	collideable = "False";
	count = "1";
	changeTeamCount = "0";
	scoreValue = "1";
	originalPosition = "-539.379 -308 175.99";
	atHome = "true";
	pickupSequence = "0";
	carrier = "-1";
	holdingTeam = "-1";
	enemyCaps = "0";
	caps0 = "0";
	caps1 = "0";
	caps2 = "0";
	caps3 = "0";
	caps4 = "0";
	caps5 = "0";
	caps6 = "0";
	caps7 = "0";
};
//--- export object end ---//
