//-----------------------------------
//
// Tribes startup
//
//-----------------------------------

$zadmin::version = "0.935";
$zadmin::state = "VANILLA";

$ModInfo = "zadmin <f2>v"@$zadmin::version@"<f1>/<f2>"@$zadmin::state;


$dedicated = true;
$WinConsoleEnabled = $dedicated;
$Console::logBufferEnabled = !$dedicated; // turn off window scroll back
$Console::Prompt = "% ";

newServer();
focusServer();

function EvalSearchPath()
{
   // search path always contains the config directory
   %searchPath = "config";
   if($modList == "")
      $modList = "base";
   else
   {
      for(%i = 0; (%word = getWord($modList, %i)) != -1; %i++)
         if(%word == "base")
            break;
      if(%word == -1)
         $modList = $modList @ " base";
   }
   for(%i = 0; (%word = getWord($modList, %i)) != -1; %i++)
   {
      %addPath = %word @ ";" @ %word @ "\\missions;" @ %word @ 
         "\\fonts;" @ %word @ "\\skins;" @ %word @ "\\voices;" @ %word @ "\\scripts";
      %searchPath = %searchPath @ ";" @ %addPath;
   }
   %searchPath = %searchPath @ ";recordings;temp";
   echo(%searchPath);

   $ConsoleWorld::DefaultSearchPath = %searchPath;

   // clear out the volumes:
   for(%i = 0; isObject(%vol = "VoiceVolume" @ %i); %i++)
      deleteObject(%vol);
   for(%i = 0; isObject(%vol = "SkinVolume" @ %i); %i++)
      deleteObject(%vol);

   // load all the volumes:
   %file = File::findFirst("voices\\*.vol");
   for(%i = 0; %file != ""; %file = File::findNext("voices\\*.vol"))
      if(newObject("VoiceVolume" @ %i, SimVolume, %file))
         %i++;

   %file = File::findFirst("skins\\*.vol");
   for(%i = 0; %file != ""; %file = File::findNext("skins\\*.vol"))
      if(newObject("SkinVolume" @ %i, SimVolume, %file))
         %i++;
}

//
EvalSearchPath();
newObject(ScriptsVolume, SimVolume, "scripts.vol");
newObject(EntitiesVolume, SimVolume, "entities.vol");
//newObject(InterfaceVolume, SimVolume, "interface.vol");

//start her up   
exec("banlist.cs");
exec("code.missionList.cs");
exec("code.server.cs");
exec("code.game.cs");
exec("code.observer.cs");
exec("code.player.cs");

// Load prefs and execute any autoexec commands...
exec("pref.serverdefaults.cs");
exec("clientprefs.cs");
exec("serverprefs.cs");
exec("serverConfig.cs");
exec("autoexec.cs");

createServer($HostMission, True);
translateMasters();
echo("Dedicated Server Initialized");