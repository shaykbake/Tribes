//
// Set up the various player levels
// Add in order of Power, First added is no power
//
// addAdminLevel("Level Name");

addAdminLevel("Player");
addAdminLevel("Public Admin");
addAdminLevel("General Admin");
addAdminLevel("Super Admin");
addAdminLevel("Ultra Admin");
addAdminLevel("Jesus Christ");
 
// Define minimum level of adminship for each action below, by changing the accessLevel
// Each level also inherits the abilities of the level below it

$minAccessRequired::changeGameMode			= getAdminLevel("Public Admin");
$minAccessRequired::changeMission			= getAdminLevel("Public Admin");
$minAccessRequired::changePlyrTeam			= getAdminLevel("Public Admin");
$minAccessRequired::EZConsoleShowsAsAdmin 	= getAdminLevel("Public Admin");
$minAccessRequired::forceMatchStart     	= getAdminLevel("Public Admin");
$minAccessRequired::kick					= getAdminLevel("Public Admin");
$minAccessRequired::switchTeamDamage   		= getAdminLevel("Public Admin");

$minAccessRequired::announceTakeover   			= getAdminLevel("General Admin");
$minAccessRequired::ban							= getAdminLevel("General Admin");
$minAccessRequired::cancelVote					= getAdminLevel("General Admin");
$minAccessRequired::changeTimeLimit				= getAdminLevel("General Admin");
$minAccessRequired::EZConsoleShowsAsSuperAdmin 	= getAdminLevel("General Admin");
$minAccessRequired::makeAdmin					= getAdminLevel("General Admin");
$minAccessRequired::sendPrivateMsgs				= getAdminLevel("General Admin");
$minAccessRequired::setPassword	        		= getAdminLevel("General Admin");
$minAccessRequired::pickupMode	        		= getAdminLevel("General Admin");

$minAccessRequired::Mute						= getAdminLevel("Super Admin");
$minAccessRequired::receiveAlerts       		= getAdminLevel("Super Admin");
$minAccessRequired::seePlayerSpecs      		= getAdminLevel("Super Admin");
$minAccessRequired::sendWarning					= getAdminLevel("Super Admin");

$minAccessRequired::permanentBan				= getAdminLevel("Ultra Admin");
$minAccessRequired::resetServer					= getAdminLevel("Ultra Admin");
$minAccessRequired::seePlayerlist				= getAdminLevel("Ultra Admin");

$minAccessRequired::antiRape					= getAdminLevel("Jesus Christ");
$minAccessRequired::antiRepair					= getAdminLevel("Jesus Christ");
$minAccessRequired::stripAdmin					= getAdminLevel("Jesus Christ");
$minAccessRequired::setTeamInfo					= getAdminLevel("Jesus Christ");

//add global spammers here to permanently remove global priveleges
addGlobalSpammer("(c) Killa J");
addGlobalSpammerIP("127");

//addMegaSpammer("(c) Killa J");
//addMegaSpammerIP("127");
