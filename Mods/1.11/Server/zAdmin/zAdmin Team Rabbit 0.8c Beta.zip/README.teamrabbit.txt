Team Rabbit v0.8 beta [zadmin version]

INSTALLATION INSTRUCTIONS
Unzip teamrabbit.zadmin.zip to your Tribes directory. That's it!  Start the server and switch to a Team Rabbit map.  Please try to limit the maximum number of players to 10-12.

UPDATED FOR ZADMIN
 - Points over time for carrying the flag [REMOVED]
 - Beacon Limit [FIXED]

Visit http://www.kineticpoet.com/trabbit/ for additional information.
Visit http://www.team5150.com/~andrew/ for additional information.
Email info@kineticpoet.com with questions, concerns and feedback.
Email andrew@team5150.com if you never want a reply, ever.

Have fun!
Michael Johnston, aka KineticPoet
Eric Chu, aka Special
Andrew, aka Greatest Known Tribes Player, Greatest Known Scripter, and all around Philanthropist