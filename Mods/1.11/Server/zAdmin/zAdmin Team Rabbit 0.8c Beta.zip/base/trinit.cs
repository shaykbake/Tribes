// Initialize some server variables and the default loadout
$Server::TeamDamageScale = 1; // Enable team damage
$TRabbit::oldTeamSkin0 = $Server::teamSkin0;  // Try saving old skin info
$TRabbit::oldTeamSkin1 = $Server::teamSkin1;
$TRabbit::oldTeamSkin2 = $Server::teamSkin2;



// Spawn default loadout
$spawnWeapon = "Disclauncher";  //equipment to spawn with & weapon to start with
$spawnBuyList[0] = LightArmor;
$spawnBuyList[1] = Disclauncher;
$spawnBuyList[2] = "EnergyPack";
$spawnBuyList[3] = RepairKit;
$spawnBuyList[4] = GrenadeLauncher;
$spawnBuyList[5] = Chaingun;
$spawnBuyList[6] = Beacon;
$spawnBuyList[7] = Beacon;
$spawnBuyList[8] = Grenade;
$spawnBuyList[9] = TargetingLaser;
$ItemMax[larmor, Grenade] = 2;


$TRabbit::Item[0, ItemType] = Blaster;  //items allowed, not allowed
$TRabbit::Item[0, allowed] = true;      //just adjust true/false field
$TRabbit::Item[0, displayName] = "Blaster";

$TRabbit::Item[1, ItemType] = Chaingun;
$TRabbit::Item[1, allowed] = true;
$TRabbit::Item[1, displayName] = "Chaingun";

$TRabbit::Item[2, ItemType] = Disclauncher;
$TRabbit::Item[2, allowed] = true;
$TRabbit::Item[2, displayName] = "Disc Launcher";

$TRabbit::Item[3, ItemType] = GrenadeLauncher;
$TRabbit::Item[3, allowed] = true;
$TRabbit::Item[3, displayName] = "Grenade Launcher";

$TRabbit::Item[4, ItemType] = Mortar;
$TRabbit::Item[4, allowed] = false;
$TRabbit::Item[4, displayName] = "Mortar";

$TRabbit::Item[5, ItemType] = PlasmaGun;
$TRabbit::Item[5, allowed] = true;
$TRabbit::Item[5, displayName] = "Plasma Gun";

$TRabbit::Item[6, ItemType] = LaserRifle;
$TRabbit::Item[6, allowed] = true;
$TRabbit::Item[6, displayName] = "Laser Rifle";

$TRabbit::Item[7, ItemType] = EnergyRifle;
$TRabbit::Item[7, allowed] = false;
$TRabbit::Item[7, displayName] = "Elf Gun";

$TRabbit::Item[8, ItemType] = TargetingLaser;
$TRabbit::Item[8, allowed] = true;
$TRabbit::Item[8, displayName] = "Targeting Laser";

$TRabbit::Item[9, ItemType] = MineAmmo;  //see note above
 $TRabbit::Item[9, allowed] = false;
$TRabbit::Item[9, displayName] = "Mines";

$TRabbit::Item[10, ItemType] = Grenade;  //see note above
$TRabbit::Item[10, allowed] = true;
$TRabbit::Item[10, displayName] = "Grenades";

$TRabbit::Item[11, ItemType] = Beacon; 
$TRabbit::Item[11, allowed] = true;
$TRabbit::Item[11, displayName] = "Beacons";

$TRabbit::Item[12, ItemType] = EnergyPack;
$TRabbit::Item[12, allowed] = true;
$TRabbit::Item[12, displayName] = "Energy Packs";

$TRabbit::Item[13, ItemType] = RepairPack;
$TRabbit::Item[13, allowed] = true;
$TRabbit::Item[13, displayName] = "Repair Packs";

$TRabbit::Item[14, ItemType] = ShieldPack;
$TRabbit::Item[14, allowed] = true;
$TRabbit::Item[14, displayName] = "Shield Packs";

$TRabbit::Item[15, ItemType] = SensorJammerPack;
$TRabbit::Item[15, allowed] = false;
$TRabbit::Item[15, displayName] = "Sensor Jammer Packs";

$TRabbit::Item[16, ItemType] = AmmoPack;
$TRabbit::Item[16, allowed] = true;
$TRabbit::Item[16, displayName] = "Ammo Packs";

$TRabbit::Item[17, ItemType] = MotionSensorPack;
$TRabbit::Item[17, allowed] = true;
$TRabbit::Item[17, displayName] = "Motion Sensors";

$TRabbit::Item[18, ItemType] = PulseSensorPack;
$TRabbit::Item[18, allowed] = true;
$TRabbit::Item[18, displayName] = "Pulse Sensors";

$TRabbit::Item[19, ItemType] = DeployableSensorJammerPack;
$TRabbit::Item[19, allowed] = true;
$TRabbit::Item[19, displayName] = "Sensor Jammers";

$TRabbit::Item[20, ItemType] = CameraPack;
$TRabbit::Item[20, allowed] = true;
$TRabbit::Item[20, displayName] = "Cameras";

$TRabbit::Item[21, ItemType] = TurretPack;
$TRabbit::Item[21, allowed] = false;
$TRabbit::Item[21, displayName] = "Turrets";

$TRabbit::Item[22, ItemType] = DeployableInvPack;
$TRabbit::Item[22, allowed] = false;
$TRabbit::Item[22, displayName] = "Remote Inventory Stations";

$TRabbit::Item[23, ItemType] = DeployableAmmoPack;
$TRabbit::Item[23, allowed] = true;
$TRabbit::Item[23, displayName] = "Ammo Stations";

$TRabbit::Item[24, ItemType] = RepairKit;
$TRabbit::Item[24, allowed] = true;
$TRabbit::Item[24, displayName] = "Repair Kits";

$TRabbit::Item[25, ItemType] = Larmor;  //these here for kicks.  Armor types not disallowable this way.  They hardcoded into function.  Need to rewrite function setupShoppingList to specifically disallow
$TRabbit::Item[25, allowed] = true;
$TRabbit::Item[25, displayName] = "Light Armor";

$TRabbit::Item[26, ItemType] = Marmor;
$TRabbit::Item[26, allowed] = true;
$TRabbit::Item[26, displayName] = "Medium Armor";

$TRabbit::Item[27, ItemType] = Harmor;
$TRabbit::Item[27, allowed] = true;
$TRabbit::Item[27, displayName] = "Heavy Armor";
