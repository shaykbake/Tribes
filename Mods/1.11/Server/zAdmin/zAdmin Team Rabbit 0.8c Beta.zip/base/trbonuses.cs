// All the Team Rabbit bonus and penalty info

// Bonus IDs
$flagSpeedBonusID = 0;
$grabSpeedBonusID = 6;
$beaconStopBonusID = 2;
$interceptionBonusID = 3;
$midairGrabBonusID = 4;
$flaggerKillBonusID = 5;
$flaggerChainKillBonusID = 7;
$marioBonusID = 8;
$kidneyThiefBonusID = 9;
$inverseMarioBonusID = 10;
$flaggerMidairDamageBonusID = 1;
$rabidRabbitBonusID = 11;
$grabDirectionBonusID = 12;
$midairGrenadeBonusID = 13;
$crazyFlagBonusID = 14;
$gogoGadgetBonusID = 15;
$passDirectionBonusID = 16;
$hareHelperBonusID = 17;
$passSequenceBonusID = 18;
$aeropackPassBonusID = 19;
$scavengerBonusID = 20;
$extraPassSpeedBonusID = 21;
$midairDiscThenGrabBonusID = 22;
$TRabbit::numBonuses = 23;

// Penalty IDs
$ownFlaggerKillPenaltyID = 0;
$oobFlagPenaltyID = 1;
$flagReturnedPenaltyID = 2;
$teammateKillPenaltyID = 3;
$interceptionPenaltyID = 4;
$TRabbit::numPenalties = 5;

$penaltyMessage[$ownFlaggerKillPenaltyID] = "Friendly Flagger Kill";
$penaltyAmount[$ownFlaggerKillPenaltyID] = 10;
$penaltySound[$ownFlaggerKillPenaltyID] = "~wtargetlaser.wav";
$penaltyMessage[$teammateKillPenaltyID] = "Teammate Kill";
$penaltyAmount[$teammateKillPenaltyID] = 4;
$penaltySound[$teammateKillPenaltyID] = "~wturretturn2.wav";
$penaltyMessage[$oobFlagPenaltyID] = "Out Of Bounds";
$penaltySound[$oobFlagPenaltyID] = "~wflagreturn.wav";
$penaltyAmount[$oobFlagPenaltyID] = 15;
$penaltyMessage[$flagReturnPenaltyID] = "Flag was allowed to return";  
$penaltyAmount[$flagReturnPenaltyID] =  8;
$penaltySound[$flagReturnPenaltyID] = "~wflagreturn.wav";
$penaltyMessage[$interceptionPenaltyID] = "Interception";
$penaltyAmount[$interceptionPenaltyID] = 2;
$penaltySound[$interceptionPenaltyID] = "";

// Bonus info
// $bonusMessage:  	The message to be displayed
// $bonusGoalValue:  	A value condition that must be met (often speed or height, but not always)
// $bonusAmount:  	Number of points to award
// $bonusSound:  		A sound to be played

$TRabbit::superBonusSound = "~wfloat_target.wav";

// Flag grabber speed
$bonusMessage[$grabSpeedBonusID, 0] = "Speed bonus:  * Natural *";
$bonusGoalValue[$grabSpeedBonusID, 0] = 21;
$bonusAmount[$grabSpeedBonusID, 0] = 1;
$bonusSound[$grabSpeedBonusID, 0] = "";
$bonusMessage[$grabSpeedBonusID, 1] = "Speed bonus:  ** Un-Natural **";
$bonusGoalValue[$grabSpeedBonusID, 1] = 35;
$bonusAmount[$grabSpeedBonusID, 1] = 2;
$bonusSound[$grabSpeedBonusID, 1] = "~wdiscspin.wav";
$bonusMessage[$grabSpeedBonusID, 2] = "Speed bonus:  *** Super-Natural ***";
$bonusGoalValue[$grabSpeedBonusID, 2] = 52;
$bonusAmount[$grabSpeedBonusID, 2] = 3;
$bonusSound[$grabSpeedBonusID, 2] = "~wshieldhit.wav";
$bonusMessage[$grabSpeedBonusID, 3] = "Speed bonus:  **** Nothing Left To Prove ****";
$bonusGoalValue[$grabSpeedBonusID, 3] = 73;
$bonusAmount[$grabSpeedBonusID, 3] = 4;
$bonusSound[$grabSpeedBonusID, 3] = "~wshieldhit.wav";
$numGrabSpeedBonuses = 4;

// Combined flag grabber/passer speed
$bonusMessage[$extraPassSpeedBonusID, 0] = "Pass bonus:  # Kilo #";
$bonusGoalValue[$extraPassSpeedBonusID, 0] = 28;
$bonusAmount[$extraPassSpeedBonusID, 0] = 2;
$bonusSound[$extraPassSpeedBonusID, 0] = "";
$bonusMessage[$extraPassSpeedBonusID, 1] = "Pass bonus:  ## Mega ##";
$bonusGoalValue[$extraPassSpeedBonusID, 1] = 48;
$bonusAmount[$extraPassSpeedBonusID, 1] = 3;
$bonusSound[$extraPassSpeedBonusID, 1] = "";
$bonusMessage[$extraPassSpeedBonusID, 2] = "Pass bonus:  ### Giga ###";
$bonusGoalValue[$extraPassSpeedBonusID, 2] = 68;
$bonusAmount[$extraPassSpeedBonusID, 2] = 4;
$bonusSound[$extraPassSpeedBonusID, 2] = "";
$bonusMessage[$extraPassSpeedBonusID, 3] = "Pass bonus:  #### Tera ####";
$bonusGoalValue[$extraPassSpeedBonusID, 3] = 88;
$bonusAmount[$extraPassSpeedBonusID, 3] = 5;
$bonusSound[$extraPassSpeedBonusID, 3] = "";
$numExtraPassSpeedBonuses = 4;

// Flag speed
$bonusMessage[$flagSpeedBonusID, 0] = "Flag bonus:  * Clambering Grab *";
$bonusGoalValue[$flagSpeedBonusID, 0] = 1;
$bonusAmount[$flagSpeedBonusID, 0] = 1;
$bonusSound[$flagSpeedBonusID, 0] = "";
$bonusMessage[$flagSpeedBonusID, 1] = "Flag bonus:  ** Dynamo Grab **";
$bonusGoalValue[$flagSpeedBonusID, 1] = 9;
$bonusAmount[$flagSpeedBonusID, 1] = 2;
$bonusSound[$flagSpeedBonusID, 1] = "~wshell_click.wav";
$bonusMessage[$flagSpeedBonusID, 2] = "Flag bonus:  *** Speedy Grab ***";
$bonusGoalValue[$flagSpeedBonusID, 2] = 16;
$bonusAmount[$flagSpeedBonusID, 2] = 3;
$bonusSound[$flagSpeedBonusID, 2] = "~welevator1.wav";
$bonusMessage[$flagSpeedBonusID, 3] = "Flag bonus:  **** Daunting Grab ****";
$bonusGoalValue[$flagSpeedBonusID, 3] = 35;
$bonusAmount[$flagSpeedBonusID, 3] = 4;
$bonusSound[$flagSpeedBonusID, 3] = "~wshieldhit.wav";
$numFlagSpeedBonuses = 4;

// Grab direction
$bonusMessage[$grabDirectionBonusID, 0] = "Grab bonus:  # Alluring Reversal #";
$bonusGoalValue[$grabDirectionBonusID, 0] = -0.4;
$bonusAmount[$grabDirectionBonusID, 0] = 1;
$bonusSound[$grabDirectionBonusID, 0] = "~wturretoff1.wav";
$bonusMessage[$grabDirectionBonusID, 1] = "Grab bonus:  ## Sexy Reversal ##";
$bonusGoalValue[$grabDirectionBonusID, 1] = -0.94;
$bonusAmount[$grabDirectionBonusID, 1] = 2;
$bonusSound[$grabDirectionBonusID, 1] = "~wturretoff2.wav";
$bonusMessage[$grabDirectionBonusID, 2] = "Grab bonus:  ### Ravishing Reversal ###";
$bonusGoalValue[$grabDirectionBonusID, 2] = -0.985;
$bonusAmount[$grabDirectionBonusID, 2] = 3;
$bonusSound[$grabDirectionBonusID, 2] = "~wflyer_dismount.wav";
$numGrabDirectionBonuses = 3;

// Pass direction
$bonusMessage[$passDirectionBonusID, 0] = "Pass bonus:  ### Blind Toss ###";
$bonusGoalValue[$passDirectionBonusID, 0] = 0.4;
$bonusAmount[$passDirectionBonusID, 0] = 3;
$bonusSound[$passDirectionBonusID, 0] = "~wflyer_mount.wav";
$bonusMessage[$passDirectionBonusID, 1] = "Pass bonus:  #### Love Toss ####";
$bonusGoalValue[$passDirectionBonusID, 1] = 0.94;
$bonusAmount[$passDirectionBonusID, 1] = 4;
$bonusSound[$passDirectionBonusID, 1] = "~wsensor_deploy.wav";
$numPassDirectionBonuses = 2;

// Flagger kill bonus
$bonusMessage[$flaggerKillBonusID, 0] = "Kill bonus:  + Furry Flagger Frag +";
$bonusGoalValue[$flaggerKillBonusID, 0] = 12;
$bonusAmount[$flaggerKillBonusID, 0] = 1;
$bonusSound[$flaggerKillBonusID, 0] = "~wturret_whir.wav";
$bonusMessage[$flaggerKillBonusID, 1] = "Kill bonus:  ++ FLIPPIN' Fast Flagger Frag ++";
$bonusGoalValue[$flaggerKillBonusID, 1] = 32;
$bonusAmount[$flaggerKillBonusID, 1] = 2;
$bonusSound[$flaggerKillBonusID, 1] = "~wpda_on.wav";
$bonusMessage[$flaggerKillBonusID, 2] = "Kill bonus:  +++ SWEET KILL SWEET KILL +++";
$bonusGoalValue[$flaggerKillBonusID, 2] = 50;
$bonusAmount[$flaggerKillBonusID, 2] = 3;
$bonusSound[$flaggerKillBonusID, 2] = "~wforceopen.wav";
$bonusMessage[$flaggerKillBonusID, 3] = "Kill bonus:  ++++ O   M   G ++++";
$bonusGoalValue[$flaggerKillBonusID, 3] = 67;
$bonusAmount[$flaggerKillBonusID, 3] = 4;
$bonusSound[$flaggerKillBonusID, 3] = "~wflierRocket.wav";
$numFlaggerKillBonuses = 4;

// Flagger midair Damage bonus
$bonusMessage[$flaggerMidairDamageBonusID, 0] = "Damage bonus:  + MA +";
$bonusGoalValue[$flaggerMidairDamageBonusID, 0] = 7;
$bonusAmount[$flaggerMidairDamageBonusID, 0] = 2;
$bonusSound[$flaggerMidairDamageBonusID, 0] = "~wBXplo4.wav";
$bonusMessage[$flaggerMidairDamageBonusID, 1] = "Damage bonus:  ++ MA Plus ++";
$bonusGoalValue[$flaggerMidairDamageBonusID, 1] = 16;
$bonusAmount[$flaggerMidairDamageBonusID, 1] = 3;
$bonusSound[$flaggerMidairDamageBonusID, 1] = "~wBXplo1.wav";
$bonusMessage[$flaggerMidairDamageBonusID, 2] = "Damage bonus:  +++ MA Supreme +++";
$bonusGoalValue[$flaggerMidairDamageBonusID, 2] = 24;
$bonusAmount[$flaggerMidairDamageBonusID, 2] = 4;
$bonusSound[$flaggerMidairDamageBonusID, 2] = "~wfloat_explode.wav";
$bonusMessage[$flaggerMidairDamageBonusID, 3] = "++++ EAT DISC MOTHER FUCKER ++++";
$bonusGoalValue[$flaggerMidairDamageBonusID, 3] = 50;
$bonusAmount[$flaggerMidairDamageBonusID, 3] = 5;
$bonusSound[$flaggerMidairDamageBonusID, 3] = "~wflierRocket.wav";
$numFlaggerMidairDamageBonuses = 4;

// Flagger chain kill bonus (for Buddy)
$bonusMessage[$flaggerChainKillBonusID, 0] = "Kill bonus:  + Flagger got sLaMmed by bullets +";
$bonusGoalValue[$flaggerChainKillBonusID, 0] = 28;
$bonusAmount[$flaggerChainKillBonusID, 0] = 1;
$bonusSound[$flaggerChainKillBonusID, 0] = "~wmachgun2.wav";
$bonusMessage[$flaggerChainKillBonusID, 1] = "Kill bonus:  ++ Buddy Be Bruised By Bullets ++";
$bonusGoalValue[$flaggerChainKillBonusID, 1] = 50;
$bonusAmount[$flaggerChainKillBonusID, 1] = 2;
$bonusSound[$flaggerChainKillBonusID, 1] = "~wmachgun2.wav";
$numFlaggerChainKillBonuses = 2;

// Midair grenade
$bonusMessage[$midairGrenadeBonusID, 0] = "Grenade bonus:  ++++ Kermy Kill ++++";
$bonusGoalValue[$midairGrenadeBonusID, 0] = 10;
$bonusAmount[$midairGrenadeBonusID, 0] = 8;
$bonusSound[$midairGrenadeBonusID, 0] = "~wexplo3.wav";

// Georgeson Backstab (disc to an enemy's middle back)
$bonusMessage[$georgesonBonusID, 0] = "Damage bonus:  + Georgeson Backstab +";
$bonusGoalValue[$georgesonBonusID, 0] = "";
$bonusAmount[$georgesonBonusID, 0] = 1;
$bonusSound[$georgesonBonusID, 0] = "";

// Rabid Rabbit (carrier kills chasers)
$bonusMessage[$rabidRabbitBonusID, 0] = "Kill bonus:  +++ Rabid Rabbit +++";
$bonusGoalValue[$rabidRabbitBonusID, 0] = "";
$bonusAmount[$rabidRabbitBonusID, 0] = 3;
$bonusSound[$rabidRabbitBonusID, 0] = "~wturretturn4.wav";
$numRabidRabbitBonuses = 1;

// Escort bonus
$bonusMessage[$hareHelperBonusID, 0] = "Kill bonus:  + Hare Helper +";
$bonusGoalValue[$hareHelperBonusID, 0] = 30;
$bonusAmount[$hareHelperBonusID, 0] = 1;
$bonusSound[$hareHelperBonusID, 0] = "";
$numHareHelperBonuses = 1;


// Midair flag grab
$bonusMessage[$midairGrabBonusID, 0] = "Flag bonus:  * Slight Air Grab *";
$bonusGoalValue[$midairGrabBonusID, 0] = 7;
$bonusAmount[$midairGrabBonusID, 0] = 2;
$bonusSound[$midairGrabBonusID, 0] = "";
$bonusMessage[$midairGrabBonusID, 1] = "Flag bonus:  ** Good Air Grab **";
$bonusGoalValue[$midairGrabBonusID, 1] = 18	;
$bonusAmount[$midairGrabBonusID, 1] = 3;
$bonusSound[$midairGrabBonusID, 1] = "~wcommand_power.wav";
$bonusMessage[$midairGrabBonusID, 2] = "Flag bonus:  *** Huge Air Grab ***";
$bonusGoalValue[$midairGrabBonusID, 2] = 46;
$bonusAmount[$midairGrabBonusID, 2] = 4;
$bonusSound[$midairGrabBonusID, 2] = "~wactivateTele.wav";
$bonusMessage[$midairGrabBonusID, 3] = "Flag bonus:  **** Top Of The World ****";
$bonusGoalValue[$midairGrabBonusID, 3] = 67;
$bonusAmount[$midairGrabBonusID, 3] = 5;
$bonusSound[$midairGrabBonusID, 3] = "~wactivateTele.wav";
$numMidairGrabBonuses = 4;

// Mario
$bonusMessage[$marioBonusID, 0] = "Special bonus:  == Mario Grab ==";
$bonusGoalValue[$marioBonusID, 0] = 1.1;
$bonusAmount[$marioBonusID, 0] = 4;
$bonusSound[$marioBonusID, 0] = "~welevator2.wav";
$numMarioBonuses = 1;

// Inverse Mario
// Happens when a teammate hits carrier from below, followed by grab
$bonusMessage[$inverseMarioBonusID, 0] = "Special bonus:  === Inverse Mario Grab ===";
$bonusGoalValue[$inverseMarioBonusID, 0] = 1.5;
$bonusAmount[$inverseMarioBonusID, 0] = 7;
$bonusSound[$inverseMarioBonusID, 0] = "~wflagcapture.wav";
$numInverseMarioBonuses = 1;

// Kidney Thief
$bonusMessage[$kidneyThiefBonusID, 0] = "Special bonus:  == Kidney Thief Steal ==";
$bonusGoalValue[$kidneyThiefBonusID, 0] = "";
$bonusAmount[$kidneyThiefBonusID, 0] = 2;
$bonusSound[$kidneyThiefBonusID, 0] = "~wactivateBeacon.wav";
$bonusMessage[$kidneyThiefID, 1] = "Special bonus:  ==== Mario Denial ====";
// Happens when other team attempts mario grab, but interception occurs immediately
$bonusGoalValue[$kidneyThiefBonusID, 1] = "";
$bonusAmount[$kidneyThiefBonusID, 1] = 10;
$bonusSound[$kidneyThiefBonusID, 1] = "~wusepack.wav";

// Crazy flags
$bonusMessage[$crazyFlagBonusID, 0] = "Extra bonus:  Crazy flag!";
$bonusGoalValue[$crazyFlagBonusID, 0] = "";
$bonusAmount[$crazyFlagBonusID, 0] = 1;
$bonusSound[$crazyFlagBonusID, 0] = "~wflagflap.wav";

// Go-go gadget flag
$bonusMessage[$gogoGadgetBonusID, 0] = "Special bonus:  == Go-go Gadget Grab ==";
$bonusGoalValue[$gogoGadgetBonusID, 0] = 7;
$bonusAmount[$gogoGadgetBonusID, 0] = 2;
$bonusSound[$gogoGadgetBonusID, 0] = "~wturretfire1.wav";

// Aeropack pass
$bonusMessage[$aeropackPassBonusID, 0] = "Special bonus:  === Aeropack Pass ===";
$bonusGoalValue[$aeropackPassBonusID, 0] = 5;
$bonusAmount[$aeropackPassBonusID, 0] = 3;
$bonusSound[$aeropackPassBonusID, 0] = "";

// Scavenger grab
$bonusMessage[$scavengerBonusID, 0] = "Special bonus:  === Scavenger Grab ===";
$bonusGoalValue[$scavengerBonusID, 0] = 1.6;
$bonusAmount[$scavengerBonusID, 0] = 3;
$bonusSound[$scavengerBonusID, 0] = "";

// Interception
$bonusMessage[$interceptionBonusID, 0] = "Turnover Bonus";
$bonusAmount[$interceptionBonusID, 0] = 1;
$bonusSound[$interceptionBonusID, 0] = "";
$bonusMessage[$interceptionBonusID, 1] = "INTERCEPTION:  ";
$bonusAmount[$interceptionBonusID, 1] = "2";
$bonusSound[$interceptionBonusID, 1] = "";

// Pass sequences
$bonusMessage[$passSequenceBonusID, 0] = "Sequence bonus:  $$ Double $$";
$bonusGoalValue[$passSequenceBonusID, 0] = 7;
$bonusAmount[$passSequenceBonusID, 0] = 3;
$bonusSound[$passSequenceBonusID, 0] = "";
$bonusMessage[$passSequenceBonusID, 1] = "Sequence bonus:  $$$ Triple $$$";
$bonusGoalValue[$passSequenceBonusID, 1] = 7;
$bonusAmount[$passSequenceBonusID, 1] = 4;
$bonusSound[$passSequenceBonusID, 1] = "";
$bonusMessage[$passSequenceBonusID, 2] = "Sequence bonus:  $$$$ Quadruple $$$$";
$bonusGoalValue[$passSequenceBonusID, 2] = 7;
$bonusAmount[$passSequenceBonusID, 2] = 5;
$bonusSound[$passSequenceBonusID, 2] = "";
$bonusMessage[$passSequenceBonusID, 3] = "Sequence bonus:  $$$$$ Quintuple $$$$$";
$bonusGoalValue[$passSequenceBonusID, 3] = 7;
$bonusAmount[$passSequenceBonusID, 3] = 6;
$bonusSound[$passSequenceBonusID, 3] = "";
$numPassSequenceBonuses = 4;
