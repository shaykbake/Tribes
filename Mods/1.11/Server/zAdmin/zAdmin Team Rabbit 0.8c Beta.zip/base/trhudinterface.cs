//******** BEGIN HUD INTERFACE
function TRabbit::getFlagCarrier() {
	return $TRabbit::Carrier;
}

function TRabbit::getTeamScore(%team){
	return $teamScore[%team];
}

function TRabbit::getCarrierSpeed(){
	return $TRabbit::CarrierSpeed;
}

function TRabbit::isTeamRabbit(){
	return true;
}

function remoteTRabbit::getFlagCarrier(%client) {
	remoteeval(%client, TRabbit::getCarrier, $TRabbit::Carrier);
}

function remoteTRabbit::getTeamScore(%client, %team) {
	remoteeval(%client, TRabbit::getScore, $teamScore[%team]);
}

function remoteTRabbit::getCarrierSpeed(%client) {
	remoteeval(%client, TRabbit::getCarrierSpeed, $TRabbit::CarrierSpeed);
}

function remoteTRabbit::isTeamRabbit(%client) {
	remoteeval(%client, TRabbit::checkRabbit, true);
}

//******** END HUD INTERFACE