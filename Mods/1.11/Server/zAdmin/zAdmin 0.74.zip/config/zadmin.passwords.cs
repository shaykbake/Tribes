//"Name" is the name that will show up in logs, the password is what they log in with, 
//ex. sad("slowcapper") for clamsoda

//zadmin::addAdmin("ADMIN NAME",	"PASSWORD");

zadmin::setCurrentAdminLevel("General Admin");
zadmin::addAdmin("clamsoda",	"slowcapper");

zadmin::setCurrentAdminLevel("Super Admin");
zadmin::addAdmin("Rampage",		"chaingun");

zadmin::setCurrentAdminLevel("Ultra Admin");
zadmin::addAdmin("LordKermit",	"cowboy");
zadmin::addAdmin("sLaM",	"naziazz");

zadmin::setCurrentAdminLevel("Jesus Christ");
zadmin::addAdmin("Andrew",	"lebigmac");