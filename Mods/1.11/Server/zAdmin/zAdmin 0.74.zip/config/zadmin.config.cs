// Modify what you want to get logged <true or false>
$logKicksBans				= true;	// logs admin kicks/bans and voted kicks
$logAdminships				= true;	// when someone is elected or appointed admin only, not just typed in SAD.
$logMissionChanges			= true;	// when an Admin changes mission
$logPasswordChanges			= true; 	// when an admin changes the server password
$logTakeoverAnnouncements	= false;  	// Centerprint "leave"  messages sent to all players.
$logWarnings				= false; 	// when an admin warns a user
$logRegistrations			= true;  	// logs entry whenever someone enters their password
$logAccountChanges			= true;  	// Account creates, strips, password changes
$logTimeLimitChanges		= false;  	// time limit changed by admin
$logTeamChanges				= false;  	// when an admin teamchanges someone
$logNameSkinChanges			= false; 	// Teams renamed or reskinned
$logTeamDamageChanges		= false; 	// TD enabled/disabled
$logGameModeChanges			= true;  	// Tournament/FFA toggled
$logServerResets			= true;  	// server defaults reset
$logOverflowUsage			= true;		// logs whenever a playler uses their overflow pw

//
// Set up the various player levels
// Add in order of Power, First added is no power
//
// addAdminLevel("Level Name");

addAdminLevel("Player");
addAdminLevel("Public Admin");
addAdminLevel("General Admin");
addAdminLevel("Super Admin");
addAdminLevel("Ultra Admin");
addAdminLevel("Jesus Christ");
 
// Define minimum level of adminship for each action below, by changing the accessLevel
// Each level also inherits the abilities of the level below it

$minAccessRequired::changeMission			= getAdminLevel("Public Admin");
$minAccessRequired::changePlyrTeam			= getAdminLevel("Public Admin");
$minAccessRequired::EZConsoleShowsAsAdmin 	= getAdminLevel("Public Admin");
$minAccessRequired::forceMatchStart     	= getAdminLevel("Public Admin");
$minAccessRequired::kick					= getAdminLevel("Public Admin");
$minAccessRequired::switchTeamDamage   		= getAdminLevel("Public Admin");

$minAccessRequired::announceTakeover   			= getAdminLevel("General Admin");
$minAccessRequired::ban							= getAdminLevel("General Admin");
$minAccessRequired::cancelVote					= getAdminLevel("General Admin");
$minAccessRequired::changeGameMode				= getAdminLevel("General Admin");
$minAccessRequired::changeTimeLimit				= getAdminLevel("General Admin");
$minAccessRequired::EZConsoleShowsAsSuperAdmin 	= getAdminLevel("General Admin");
$minAccessRequired::makeAdmin					= getAdminLevel("General Admin");
$minAccessRequired::sendPrivateMsgs				= getAdminLevel("General Admin");
$minAccessRequired::setPassword	        		= getAdminLevel("General Admin");

$minAccessRequired::globalMute					= getAdminLevel("Super Admin");
$minAccessRequired::receiveAlerts       		= getAdminLevel("Super Admin");
$minAccessRequired::seePlayerSpecs      		= getAdminLevel("Super Admin");
$minAccessRequired::sendWarning					= getAdminLevel("Super Admin");

$minAccessRequired::permanentBan				= getAdminLevel("Ultra Admin");
$minAccessRequired::resetServer					= getAdminLevel("Ultra Admin");
$minAccessRequired::seePlayerlist				= getAdminLevel("Ultra Admin");

$minAccessRequired::stripAdmin					= getAdminLevel("Jesus Christ");
$minAccessRequired::setTeamInfo					= getAdminLevel("Jesus Christ");

//add global spammers here to permanently remove global priveleges

//killa j, the stupid faggot
//addGlobalSpammer("playername");

//addGlobalSpammerIP("1.2.3.4");


//define messages here
$FriendlyWarning = "This server is reserved for a match right now.  Please drop from the server. Thanks.";
$FirmWarning = "This server is reserved for a match at this time.  Leave or be kicked. Thanks.";
$PermaBanMessage = "You have been PERMANENTLY banned from this server.  Come to #heaven on Dynamix IRC if you feel this message is in error.";


//permanent banned global spammer message
$GlobalSpamMessage = "Your global message rights have been revoked due to excessive/abusive/childish chat.";

//teamkill warning
$MsgName[1] = "TeamKill Warning";
$MsgText[1] = "Admin Warning: You are in danger of being kicked for teamkilling.";

//moron warning
$MsgName[2] = "Moron Warning";
$MsgText[2] = "Admin Warning: You are in danger of being kicked for being a moron.";

//flag bug w/ scouts
$MsgName[3] = "Flag Bug Warning With Scouts";
$MsgText[3] = "If you cause the flag to skip using a scout, you will be banned.  Have a nice day.";


//length of time ban/kicks last
$zadmin::kickTime = (60) * 3;	//3 mins
$zadmin::banTime = (60) * 30;	//30 mins

// Change this variable according to how many time zones away you are
//  Ex: PCT = 3
//      MST = 2
//      CST = 1
//      EST = 0
//      Hawaii/Alaska = 4
	
$zadmin::ServerTimeOffset = 0;

// Overflow prefs

// Password when the server is below the normal max player count.  This is designed to prevent 
//  Tribes from caching the password in a temp config should the server reset
// Can be left blank if no password is desired.
$Overflow::Pass1 = "";

// Pass thats applied once the server reaches a pre-defined capacity.  "Elite player" password.
$Overflow::Pass2 = "gooffense";

// Capacity at which the second password is applied
$Overflow::Level2 = "16";

// Password that is used once the server reaches normal capacity.  
$Overflow::Pass3 = "overflowpw";

// Max number of overflow spots that the server will increase over the default max capacity
$Overflow::MaxTotal = 4;

// Normal player max :/  T1 has problems storing this when it starts
$Overflow::DefaultMax = 26;


//kick players that don't enter SAD when using overflow?
$Overflow::KickOnNoEnterSAD = True;
//number of seconds to give the player to enter SAD
$Overflow::EnterSADTime = 60;

//options are Timepoet, TWL. If you're using the MFC timer, use "TWL"
$zAdmin::TimeStamper = "TWL";

//check for afk idiots every 2.5 minutes, time specified in seconds
$zadmin::AFKMonitorInterval = floor(2.5*60);
//kick after 5 minutes of inactivity, time specified in seconds
$zadmin::AFKTimelimit = 8*60;