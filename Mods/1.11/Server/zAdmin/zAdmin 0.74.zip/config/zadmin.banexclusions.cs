BanExclusions::add("IP:127.0.0.1", "[clan]bob", "bobs alias");
