// Tribes formatted Time output.

// Time/Date format used for IP logging.
$TWL::Time = "22:51";
$TWL::Date = "2003-02-24";

// Individual Time/Date components for ease of use.
$TWL::Hour = "22";
$TWL::Min = "51";
$TWL::Sec = "41";
$TWL::AMPM = "PM";
$TWL::Day = "24";
$TWL::Month = "02";
$TWL::Year = "2003";
