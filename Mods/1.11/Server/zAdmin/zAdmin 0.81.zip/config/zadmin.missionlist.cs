$nextMission["Snowblind"] = "DangerousCrossing";
$nextMission["Dangerouscrossing"] = "CanyonCrusade_Deluxe";
$nextMission["CanyonCrusade_Deluxe"] = "Bastard_forge_day";
$nextMission["Bastard_forge_day"] = "Stonehenge";
$nextMission["Stonehenge"] = "Raindance";
$nextMission["Raindance"] = "Hildebrand";
$nextMission["Hildebrand"] = "Rollercoaster";
$nextMission["Rollercoaster"] = "Snowblind";