exec("code.game.cs");  

//  GAME PREFERENCES - adjust as desired
$Server::TeamDamageScale = 0; //team damage off unless voted on (Tourney Mode too)
$Rabbit::origJoinMOTD = $Server::JoinMOTD; //save old message of the day

$Rabbit::oldTeamName0 = $Server::teamName0; //save old team info otherwise
$Rabbit::oldTeamName1 = $Server::teamName1; //not just Rabbit missions 
$Rabbit::oldTeamName2 = $Server::teamName2; //will use these
$Server::teamName0 = "Hunters";             //These get restored after 
$Server::teamName1 = "Plump Lil Bunny";     //Rabbit mission over
$Server::teamName2 = "Carrot";

$Rabbit::oldTeamSkin0 = $Server::teamSkin0;
$Rabbit::oldTeamSkin1 = $Server::teamSkin1;
$Rabbit::oldTeamSkin2 = $Server::teamSkin2;
$Server::teamSkin0 = "green";  //player team emblem
$Server::teamSkin1 = "orange";  //flag carrier team emblem
$Server::teamSkin2 = "orange";  //flag color/emblem

$spawnWeapon = "Disclauncher";  //equipment to spawn with & weapon to start with
$spawnBuyList[0] = LightArmor;
$spawnBuyList[1] = Disclauncher;
$spawnBuyList[2] = "EnergyPack";
$spawnBuyList[3] = RepairKit;
$spawnBuyList[4] = "";

//Note - An existing game bug - Auto reload feature at stations
//gives player grenades regardless of whether allowed.  May also give player
//beacons and/or ammo, haven't tested.  In short, can't 
//keep players from getting grenades without further modification.
//Also, armor types only disallowable by rewriting function setupShoppingList
//since they are specifically added to the available items list.  May rewrite
//later...
$Rabbit::Item[0, ItemType] = Blaster;  //items allowed, not allowed
$Rabbit::Item[0, allowed] = true;      //just adjust true/false field
$Rabbit::Item[0, displayName] = "Blaster";

$Rabbit::Item[1, ItemType] = Chaingun;
$Rabbit::Item[1, allowed] = true;
$Rabbit::Item[1, displayName] = "Chaingun";

$Rabbit::Item[2, ItemType] = Disclauncher;
$Rabbit::Item[2, allowed] = true;
$Rabbit::Item[2, displayName] = "Disc Launcher";

$Rabbit::Item[3, ItemType] = GrenadeLauncher;
$Rabbit::Item[3, allowed] = true;
$Rabbit::Item[3, displayName] = "Grenade Launcher";

$Rabbit::Item[4, ItemType] = Mortar;
$Rabbit::Item[4, allowed] = false;
$Rabbit::Item[4, displayName] = "Mortar";

$Rabbit::Item[5, ItemType] = PlasmaGun;
$Rabbit::Item[5, allowed] = true;
$Rabbit::Item[5, displayName] = "Plasma Gun";

$Rabbit::Item[6, ItemType] = LaserRifle;
$Rabbit::Item[6, allowed] = true;
$Rabbit::Item[6, displayName] = "Laser Rifle";

$Rabbit::Item[7, ItemType] = EnergyRifle;
$Rabbit::Item[7, allowed] = false;
$Rabbit::Item[7, displayName] = "Elf Gun";

$Rabbit::Item[8, ItemType] = TargetingLaser;
$Rabbit::Item[8, allowed] = true;
$Rabbit::Item[8, displayName] = "Targeting Laser";

$Rabbit::Item[9, ItemType] = MineAmmo;  //see note above
 $Rabbit::Item[9, allowed] = false;
$Rabbit::Item[9, displayName] = "Mines";

$Rabbit::Item[10, ItemType] = Grenade;  //see note above
$Rabbit::Item[10, allowed] = true;
$Rabbit::Item[10, displayName] = "Grenades";

$Rabbit::Item[11, ItemType] = Beacon; 
$Rabbit::Item[11, allowed] = true;
$Rabbit::Item[11, displayName] = "Beacons";

$Rabbit::Item[12, ItemType] = EnergyPack;
$Rabbit::Item[12, allowed] = true;
$Rabbit::Item[12, displayName] = "Energy Packs";

$Rabbit::Item[13, ItemType] = RepairPack;
$Rabbit::Item[13, allowed] = true;
$Rabbit::Item[13, displayName] = "Repair Packs";

$Rabbit::Item[14, ItemType] = ShieldPack;
$Rabbit::Item[14, allowed] = true;
$Rabbit::Item[14, displayName] = "Shield Packs";

$Rabbit::Item[15, ItemType] = SensorJammerPack;
$Rabbit::Item[15, allowed] = true;
$Rabbit::Item[15, displayName] = "Sensor Jammer Packs";

$Rabbit::Item[16, ItemType] = AmmoPack;
$Rabbit::Item[16, allowed] = true;
$Rabbit::Item[16, displayName] = "Ammo Packs";

$Rabbit::Item[17, ItemType] = MotionSensorPack;
$Rabbit::Item[17, allowed] = true;
$Rabbit::Item[17, displayName] = "Motion Sensors";

$Rabbit::Item[18, ItemType] = PulseSensorPack;
$Rabbit::Item[18, allowed] = true;
$Rabbit::Item[18, displayName] = "Pulse Sensors";

$Rabbit::Item[19, ItemType] = DeployableSensorJammerPack;
$Rabbit::Item[19, allowed] = true;
$Rabbit::Item[19, displayName] = "Sensor Jammers";

$Rabbit::Item[20, ItemType] = CameraPack;
$Rabbit::Item[20, allowed] = true;
$Rabbit::Item[20, displayName] = "Cameras";

$Rabbit::Item[21, ItemType] = TurretPack;
$Rabbit::Item[21, allowed] = false;
$Rabbit::Item[21, displayName] = "Turrets";

$Rabbit::Item[22, ItemType] = DeployableInvPack;
$Rabbit::Item[22, allowed] = true;
$Rabbit::Item[22, displayName] = "Remote Inventory Stations";

$Rabbit::Item[23, ItemType] = DeployableAmmoPack;
$Rabbit::Item[23, allowed] = true;
$Rabbit::Item[23, displayName] = "Ammo Stations";

$Rabbit::Item[24, ItemType] = RepairKit;
$Rabbit::Item[24, allowed] = true;
$Rabbit::Item[24, displayName] = "Repair Kits";

$Rabbit::Item[25, ItemType] = Larmor;  //these here for kicks.  Armor types not disallowable this way.  They hardcoded into function.  Need to rewrite function setupShoppingList to specifically disallow
$Rabbit::Item[25, allowed] = true;
$Rabbit::Item[25, displayName] = "Light Armor";

$Rabbit::Item[26, ItemType] = Marmor;
$Rabbit::Item[26, allowed] = true;
$Rabbit::Item[26, displayName] = "Medium Armor";

$Rabbit::Item[27, ItemType] = Harmor;
$Rabbit::Item[27, allowed] = true;
$Rabbit::Item[27, displayName] = "Heavy Armor";

$Rabbit::scoretimer = 5;  //how many seconds need to hold flag to score point (in seconds)
$flagReturnTime = 8;  //how long before dropped flag gets returned (in seconds)

//_______________________________________________________
//Initialize vars here - don't modify these
$Rabbit::banListCount = 0;  //used to create list of disallowed items
$Rabbit::LongestFlagHeld = 0;  //used to hold longest time flag held consecutively
$Rabbit::PlayerHoldingLongest ="";  //player who held flag longest consecutive time
$Rabbit::carrier = "";  //used to hold ID of current flag carrier
$Rabbit::lastToPassThrough = "";  //used to see who got last point for holding flag

function Rabbit::setJoinMOTD(){
   %line1 = "<Jc><f1>Welcome to\n";
   %line2 = "<Jc><f0>Kill the Rabbit! v1.1<f1>\n";
   %line3 = "\n";
   %line4 = "<Jc>Assembled by Eric Lanz\n";
   %line5 = "<Jc>aka |BMF| Balefire (balefire@altavista.net)\n";
   %line6 = "<Jc><f0>Press 'O' for game objectives & rules<f1>\n";
   %line7 = "<Jc>Fire to spawn\n";

   $Server::JoinMOTD = ""; //clear old message out
   for (%i = 1; %i < 8; %i++){
      $Server::JoinMOTD = $Server::JoinMOTD @ %line[%i];
   }
}

function Game::checkTimeLimit(){
   // if no timeLimit set or timeLimit set to 0,
   // just reschedule the check for a minute hence
   $timeLimitReached = false;
   if(!$Server::timeLimit){
      schedule("Game::checkTimeLimit();", 60);
      return;
   }
   %curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
   if(%curTimeLeft <= 0){
      $timeLimitReached = true;
      Rabbit::objectivesScreen();
      Server::nextMission();
   }
   else{
   // wierdness here, usually overruns timelimit before ending
//      echo("DEBUG : checking time limit every  20 seconds " @ getSimtime());
      schedule("Game::checkTimeLimit();", 1);
      UpdateClientTimes(%curTimeLeft);
   }
}


function Rabbit::displayFinalScores(){
   Rabbit::FlagHeldCheck(); //see if a player still holding flag
   Rabbit::getAvgHolds();	 //get players' avg times
   Rabbit::getLongestFlag();	//get name and time of longest holder
   
   %numClients = getNumClients();                                  
   for(%i = 0 ; %i < %numClients ; %i++)                           
      %clientList[%i] = getClientByIndex(%i);                      
   %doIt = 1;                                                      
   while(%doIt == 1){                                              
      %doIt = "";                                                  
      for(%i= 0 ; %i < %numClients; %i++) {                        
         if((%clientList[%i]).score < (%clientList[%i+1]).score) { 
            %hold = %clientList[%i];                               
            %clientList[%i] = %clientList[%i+1];                   
            %clientList[%i+1]= %hold;                              
            %doIt=1;                                               
         }                                                         
      }                                                            
   }
   for(%l = -1; %l < 2 ; %l++) {
      %lineNum = 0;
      Team::setObjective(%l, %lineNum, "<jc><B0,0:deathmatch1.bmp><B0,0:deathmatch2.bmp>");
	  Team::setObjective(%l, %lineNum++, "<f5>Mission Summary:");
      Team::setObjective(%l, %lineNum++, " " );
      Team::setObjective(%l, %lineNum++, "<f1>     - Longest Flag held by : " );
      if ($Rabbit::LongestFlagHeld == 0)
         Team::setObjective(%l, %lineNum++, "<L14><f5><Bskull_big.bmp>\nHmmmm.  You'd better read the objectives again!");
      else
         Team::setObjective(%l, %lineNum++, "<L14><f5><Bskull_big.bmp>\n" @ Client::getName($Rabbit::PlayerHoldingLongest) @ " with a time of " @ $Rabbit::LongestFlagHeld @ " seconds!");
      Team::setObjective(%l, %lineNum++, "<f1>     - Highest Score : " );
      Team::setObjective(%l, %lineNum++, "<L14><f5><Bskull_big.bmp>\n" @ Client::getName(%clientList[0]) @ " with a score of " @ (%clientList[0].score) @ "!");
      Team::setObjective(%l, %lineNum++, " " );
      Team::setObjective(%l, %lineNum++, "<f1>Player Name<L30>Kills<L40>Deaths<L55>Flag Grabs<L73>Avg Flag Held<L96>Score");
  
      for(%i = 0; %i < %numClients; %i++){
         %plyr = %clientList[%i];
         Team::setObjective(%l, %lineNum++, "<f1> - " @ Client::getName(%plyr) @ "<L32>" @ %plyr.scoreKills @ "<L43>" @ %plyr.scoreDeaths @ "<L61>" @ $Rabbit::PlyrFlagGrabs[%plyr] @ "<L78>" @ $Rabbit::PlyrAvgFlagHeld[%plyr] @ "<L98>" @ %plyr.score);
      }
      for(%s = %lineNum+1; %s < 30 ;%s++)	 //clear any previous remaining text
         Team::setObjective(%l, %s, " ");
   }
   $timeLimitReached = "";
   Rabbit::restoreServerDefaults();
}

function Rabbit::displayGameRules(){
   for(%l = -1; %l < 2 ; %l++) {		
      %lineNum = 0;
         Team::setObjective(%l, %lineNum, "<jc><B0,0:deathmatch1.bmp><B0,0:deathmatch2.bmp>");
         Team::setObjective(%l, %lineNum++, "<f5>Mission Information:");
         Team::setObjective(%l, %lineNum++, "<f1>   - Mission Name: " @ $missionName); 
         Team::setObjective(%l, %lineNum++, " ");
         Team::setObjective(%l, %lineNum++, "<f5>Mission Objectives:");
         Team::setObjective(%l, %lineNum++, "<f1>  Grab the flag and run!  Make rabbit noises!");
         Team::setObjective(%l, %lineNum++, "<f1>   - Score 2 points for each flag grab.");
         Team::setObjective(%l, %lineNum++, "<f1>   - Score 1 additional point for each " @ $Rabbit::scoretimer @ " seconds you retain the flag.");
         Team::setObjective(%l, %lineNum++, "<f1>   - Score 1 Point for eliminating a flag carrier.");
         Team::setObjective(%l, %lineNum++, "<f1>   - Score 1 point for each pursuer you eliminate, when you are the flag carrier.");
         Team::setObjective(%l, %lineNum++, "<f1>  If you leave the mission area, you will take damage!");
         Team::setObjective(%l, %lineNum++, " ");
         Team::setObjective(%l, %lineNum++, "<f5>Weapons not allowed are : " );
         for (%x = 0; $Rabbit::banlist[%x] != ""; %x++){
               Team::setObjective(%l, %lineNum++, "<f1>   - " @ $Rabbit::banList[%x]);
         }
      for(%s = %lineNum+1; %s < 30 ;%s++)	 //clear any previous remaining text
         Team::setObjective(%l, %s, " ");
   }
}


function Rabbit::objectivesScreen(){                                                           
   if ($timeLimitReached)
      Rabbit::displayFinalScores();
   else
      Rabbit::displayGameRules();
}


function Mission::init(){
   //  echo("DEBUG : MissionInit called");
   setClientScoreHeading ("Player Name\t\x6FTeam\t\xA6Score\t\xCFPing\t\xEFPL");
   $firstTeamLine = 7;
   $firstObjectiveLine = $firstTeamLine + getNumTeams() + 1;
   for(%i = -1; %i < getNumTeams(); %i++)
   {
      newObject("TeamDrops" @ %i, SimSet);
      addToSet(MissionCleanup, "TeamDrops" @ %i);
      %dropSet = nameToID("MissionGroup/Teams/Team" @ %i @ "/DropPoints/Random");
      for(%j = 0; (%dropPoint = Group::getObject(%dropSet, %j)) != -1; %j++)
         addToSet("MissionCleanup/TeamDrops" @ %i, %dropPoint);
   }
   $numObjectives = 0;
   newObject(ObjectivesSet, SimSet);
   addToSet(MissionCleanup, ObjectivesSet);
   
   Group::iterateRecursive(MissionGroup, ObjectiveMission::initCheck);
   %group = nameToID("MissionCleanup/ObjectivesSet");
 
   for(%i = 0; (%obj = Group::getObject(%group, %i)) != -1; %i++)
   {
      %obj.objectiveLine = %i + $firstObjectiveLine;
   }
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      %cl.score = 0;
      Game::refreshClientScore(%cl);
   }

   AI::setupAI();
   Rabbit::setJoinMOTD();
   Rabbit::invalidateItems();
   Rabbit::objectivesScreen();   
}

function Flag::onDrop(%player, %type){
   %playerTeam = GameBase::getTeam(%player);
   %flag = %player.carryFlag;
   %flagTeam = GameBase::getTeam(%flag);
   %playerClient = Player::getClient(%player);
   %dropClientName = Client::getName(%playerClient);
   %currentTime = getSimTime();

   if (%playerClient != $Rabbit::Carrier) 
      return;  //not sure why this function is called on every player death, but this to prevent erroneous flag drops

   $Rabbit::Carrier = "";
   %flagHeld = %currentTime - $Rabbit::FlagGrabTimeStamp[%playerClient];
   $Rabbit::PlyrTtlFlagHeld[%playerClient] += %flagHeld;
   if (%flagHeld > $Rabbit::PlyrLongestFlagHeld[%playerClient])
      $Rabbit::PlyrLongestFlagHeld[%playerclient] = %flagHeld;
   
   $Rabbit::FlagDropper = %playerClient;
   schedule("Rabbit::changeTeam($Rabbit::FlagDropper, 0);", 0.2);  //switch player to team 0 - delay it .2 secs so not counted as team kill
   $Rabbit::FlagLastTouched[%playerClient] = %currentTime;

   MessageAllExcept(%playerClient, 1, %dropClientName @ " dropped the flag!");
   
   GameBase::throw(%flag, %player, 10, false);
   Item::hide(%flag, false);
   Player::setItemCount(%player, "Flag", 0);
   %flag.carrier = -1;
   %player.carryFlag = "";
   %flag.dropFade = 1;

   if (%player.outArea != ""){
      Flag::checkReturn(%flag, %flag.pickupSequence);
      $Rabbit::FlagOutOfArea = 1;
   }
   else
      schedule("Flag::checkReturn(" @ %flag @ ", " @ %flag.pickupSequence @ ");", $flagReturnTime);
 
   Rabbit::clearWaypoint();

   //afk monitor
   %playerClient.lastActiveTimestamp = getSimTime();

   //active code
   zadmin::ActiveMessage::All(FlagDropped, 0, %playerClient); //using 0 for team for HUDs
}



function Flag::checkReturn(%flag, %sequenceNum){
   if(%flag.pickupSequence == %sequenceNum){
      if(%flag.dropFade){ 
         GameBase::startFadeOut(%flag);
         %flag.dropFade= "";
         %flag.fadeOut= 1;
         schedule("Flag::checkReturn(" @ %flag @ ", " @ %sequenceNum @ ");", 2.5);
      }
      else {
         %flagTeam = 0;	//we want team 0 to receive the message
		 if ($Rabbit::FlagOutOfArea){
            TeamMessages(1, %flagteam, "The flag was dropped outside the mission area", -2, "", "The flag was dropped outside the mission area");
            TeamMessages(1, %flagteam, "and was returned to base.~wflagreturn.wav", -2, "", "and was returned to base.~wflagreturn.wav");
            $Rabbit::FlagOutOfArea = "";   
         }
		 else
            TeamMessages(1, %flagteam, "The flag was returned to base.~wflagreturn.wav", -2, "", "The flag was returned to base.~wflagreturn.wav");
         GameBase::setPosition(%flag, %flag.originalPosition);
         Item::setVelocity(%flag, "0 0 0");
         %flag.atHome = true;
         GameBase::startFadeIn(%flag);
         %flag.fadeOut= "";

         //active code
         zadmin::ActiveMessage::All(FlagReturned, 0, 0); //server returns
      }
   }
}


function Flag::onCollision(%this, %object){
   if(getObjectType(%object) != "Player")
      return;
   if(%this.carrier != -1)
      return; // spurious collision
   if(Player::isAIControlled(%object))
   	return;   
      
   %name = Item::getItemData(%this);
   %playerTeam = GameBase::getTeam(%object);
   %flagTeam = GameBase::getTeam(%this);
   %playerClient = Player::getClient(%object);
   %touchClientName = Client::getName(%playerClient);
   
   %currentTime = getSimTime();
   // 11 seconds before player can grab flag again after dropping it
   if ((%currentTime - $Rabbit::FlagLastTouched[%playerClient]) < 11){ 
      echo ("diff : " @ %currentTime - $Rabbit::FlagLastTouched[%playerClient]);
      return;
   }

      if(%object.carryFlag == ""){
         if(%object.outArea == "") {
            if(%this.holdingTeam == %playerTeam)
               return;
            
            // make sure that flag is not already held when the flag is touched by a player
            // remember, if flag isn't held, rabbitcarrier should be ""
            if ($Rabbit::carrier != ""){
               echo("DEBUG : Held flag touched by another player");
               return;
            }
     
            $Rabbit::FlagGrabTimeStamp[%playerClient] = %currentTime;
            $Rabbit::carrier = %playerClient;
            schedule("Rabbit::flagPointTimer();", $Rabbit::scoreTimer + 0.05);
            echo($Rabbit::carrier @ " grabbed the flag at - simtime : " @ getsimtime());
            Rabbit::WaypointToCarrier($Rabbit::carrier);
 
            %playerClient.score += 2; 
            $Rabbit::PlyrFlagGrabs[%playerClient] +=1;    
            Game::refreshClientScore(%playerClient);
            Rabbit::changeTeam(%playerClient, 1);  //switch player to team 1

            Player::setItemCount(%object, Flag, 1);
            Player::mountItem(%object, Flag, $FlagSlot, %flagTeam);
            Item::hide(%this, true);
            $flagAtHome[1] = false;
            %this.atHome = false;
            %this.carrier = %object;
            %this.pickupSequence++;
            %object.carryFlag = %this;
            if(%this.fadeOut) {
               GameBase::startFadeIn(%this);
               %this.fadeOut= "";
            }
            MessageAllExcept(%playerClient, 0, %touchClientName @ " took the " @ getTeamName(%flagTeam) @ " flag! ~wflag1.wav");
            Client::sendMessage(%playerClient, 0, "~wmine_act.wav");
            Client::sendMessage(%playerClient, 1, "You took the " @ getTeamName(%flagTeam) @ " flag! ~wflag1.wav");

            //afk monitor
            %playerClient.lastActiveTimestamp = getSimTime();
			
            //active code
            zadmin::ActiveMessage::All(FlagTaken, (0), %playerClient); //using 0 for a team for HUDS
         }
         else
            Client::sendMessage(%playerClient, 1, "Flag not in mission area.");
     }
}


// modified this so the TAB score menu lists all players based
// on score rather than team then score.  Observers still last, but
// current flag holder stays in proper sort, regardless of fact that
// he is actually on another team.
function Game::refreshClientScore(%clientId){
   %team = Client::getTeam(%clientId);

   if(%team == -1) // observers go last.
      %team = 9;
   else
      %team = 0; //put all players on equal footing

   // objective mission sorts by team first.
   Client::setScore(%clientId, "%n\t%t\t  " @ %clientId.score  @ "\t%p\t%l", %clientId.score + (9 - %team) * 10000);
}


// switches player's team to whichever team is passed to it.  Also
// maintains player's custom skin.
function Rabbit::changeTeam(%playerId, %team)
{
   GameBase::setTeam(%playerId, %team); //switch team 
   Client::setSkin(%playerId, $Client::info[%playerId, 0]);  //use custom skin
}


//Player has a total of 10 seconds per life allowed outside designated mission area.
//After a player expends this 10 sec, the player is remotely killed.
function Player::leaveMissionArea(%player){
   %cl = Player::getClient(%player);
   Client::sendMessage(%cl,1,"You have left the mission area.");
   %player.outArea=1;
   alertPlayer(%player, 3);
}


//checking for timeout of dieSeqCount
function Player::checkLMATimeout(%player, %seqCount)
{
   echo("DEBUG : checking player timeout " @ %player @ " " @ %seqCount);
   if(%player.dieSeqCount == %seqCount)
      remoteKill(Player::getClient(%player));
}


function Player::enterMissionArea(%player)
{
   %player.outArea="";
   %player.dieSeqCount = 0;
   %player.timeLeft = %player.timeLeft - (getSimTime() - %player.leaveTime);
}

  
 function alertPlayer(%player, %count){                                                
    if(%player.outArea == 1){                                                          
       %clientId = Player::getClient(%player);                                         
       Client::sendMessage(%clientId,1,"~wLeftMissionArea.wav");                       
                                                                                       
       if(%count > 1)                                                                  
          schedule("alertPlayer(" @ %player @ ", " @ %count - 1 @ ");",1.5,%clientId); 
       else                                                                            
          schedule("leaveMissionAreaDamage(" @ %clientId @ ");",1,%clientId);          
    }                                                                                  
 }                                                                                     


 function leaveMissionAreaDamage(%client){                                            
    %player = Client::getOwnedObject(%client);                                        
                                                                                      
    if(%player.outArea == 1){                                                         
       if(!Player::isDead(%player)){                                                  
         Player::setDamageFlash(%client,0.1);                                        
          GameBase::setDamageLevel(%player,GameBase::getDamageLevel(%player) + 0.05); 
 	  schedule("leaveMissionAreaDamage(" @ %client @ ");",1);                           
       }                                                                              
       else {                                                                         
          playNextAnim(%client);	                                                    
          Client::onKilled(%client, %client);                                         
       }                                                                              
    }                                                                                 
 }                                                                                    


// modified to spawn/respawn player on team0, with custom skin.
function Game::playerSpawned(%pl, %clientId, %armor){	
   Rabbit::changeTeam(%clientId, 0);  //switch player to team 0
      
   %clientId.spawn= 1;
   for(%i = 0; (%item = $spawnBuyList[%i]) != ""; %i++)
      buyItem(%clientId,%item);	
   %clientId.spawn= "";

   Player::useItem(%pl,$spawnWeapon);
   $Rabbit::FlagLastTouched[%clientID] = -30;  // set reset timestamp to allow player to grab flag
   Rabbit::resetWaypoint(%clientId);	
}


function Rabbit::flagPointTimer(){
   if ($Rabbit::lastToPassThrough == ""){
      Rabbit::InitNewFlagCarrier();
      return;
   }
   if ($Rabbit::Carrier != $Rabbit::lastToPassThrough){
      echo(Client::getName($Rabbit::LastToPassThrough) @ " is no longer Flag Carrier, no points awarded - simtime : " @ getsimTime());  
      $Rabbit::lastToPassThrough = "";
      return; //flag carrier changed, kill thread
   }
      
   $Rabbit::Carrier.score += 1;
   Game::refreshClientScore($Rabbit::Carrier);
   echo("DEBUG : Awarding Point to " @ Client::getName($Rabbit::Carrier) @ "simtime : " @ getsimtime());
   schedule ("Rabbit::flagPointTimer();", $Rabbit::scoreTimer);
}

function Rabbit::initNewFlagCarrier(){
    if ($Rabbit::Carrier ==""){
       echo("DEBUG : Oops!  Dropped it before function was called!  Killing thread.");
       return;
    }
    $Rabbit::lastToPassThrough = $Rabbit::Carrier;
    echo(Client::getName($Rabbit::carrier) @ " is the new flag carrier");
    Rabbit::FlagPointTimer();
}


// called when player joins a game, to reset any
// scores that are present.  This in case the player
// joining takes over the Client ID of a player who
// dropped during the curretn mission.
function Rabbit::JoinInit(%clientId){
   // init flagheldtime[clientId], flaggrabs[clientId]
//   echo("DEBUG : Rabbit::joinInit called");
   $Rabbit::PlyrFlagGrabs[%clientId] = 0;
   $Rabbit::PlyrLongestFlagHeld[%clientId] = 0;
   $Rabbit::PlyrAvgFlagHeld[%clientId] = 0;
   $Rabbit::PlyrTtlFlagHeld[%clientId] = 0;
   Game::refreshClientScore(%clientId);
}


function Rabbit::resetWaypoint(%client){
   
   if (($Rabbit::Carrier != "") && (%client != $Rabbit::carrier)){      
      %carrier = $Rabbit::Carrier;
      %name = Client::getName(%carrier);
      issueTargCommand(%client, %client, 0,"Get the flag!  [" @ %name @ "]", %carrier);
      echo("DEBUG : Waypoint reset");
   }
   else
      echo("DEBUG : No Waypoint set");
}
   

function Rabbit::WaypointToCarrier(%carrier){
   %numclients = getNumClients();
   %name = Client::getName(%carrier);
   for (%i = 0; %i < %numclients; %i++){ 
      %client = getClientByIndex(%i);
      if (%client == $Rabbit::carrier)
         IssueTargCommand(%client, %client, 0, "Run! Silly rabbit!", %carrier - 2048);
      else       
         IssueTargCommand(%client, %client, 0, "Get the flag! " @ %name @ " has it!", %carrier - 2048);
   }
echo("DEBUG : Waypoint to carrier set " @ %client @ "  " @ %name @ "  " @ %carrier);
}


function Rabbit::clearWaypoint(){
   %numclients = getNumClients();
   %name = Client::getName(%carrier);
   for (%i = 0; %i < %numclients; %i++){ 
      %client = getClientByIndex(%i);  
      setCommandStatus(%client, 0, "The flag was dropped!");   
   }
   echo("DEBUG : Waypoint cleared");
}


// called when mission cycles to 
// see if a player is still holding flag 
// to capture time held & quit awarding points
function Rabbit::FlagHeldCheck(){
   if ($Rabbit::Carrier !=""){
         %plyr = $Rabbit::carrier;
         $Rabbit::Carrier = "";  
         %flagHeld = getSimTime() - $Rabbit::FlagGrabTimeStamp[%plyr];
         $Rabbit::PlyrTtlFlagHeld[%plyr] += %flagHeld;
         if (%flagHeld > $Rabbit::PlyrLongestFlagHeld[%plyr])
            $Rabbit::PlyrLongestFlagHeld[%plyr] = %flagHeld;      
   } 
}


// assign average time held for all players
// based on their (total time held / flag grabs)
function Rabbit::getAvgHolds(){
   %numClients = getNumClients();
   for (%z = 0; %z < %numClients; %z++){
      %plyr = getClientByIndex(%z);
      if ($Rabbit::PlyrTtlFlagHeld[%plyr] > 0) 
         $Rabbit::PlyrAvgFlagHeld[%plyr] = $Rabbit::PlyrTtlFlagHeld[%plyr] / $Rabbit::PlyrFlagGrabs[%plyr];
      else
         $Rabbit::PlyrAvgFlagHeld[%plyr] = 0;
   }
}
 

// check all clients, to see who held flag longest
function Rabbit::getLongestFlag(){
   %numClients = getNumClients();
   for (%z = 0; %z < %numClients; %z++){
     %plyr = getClientByIndex(%z);
      if ($Rabbit::PlyrLongestFlagHeld[%plyr] > $Rabbit::LongestFlagHeld){
         $Rabbit::PlayerHoldingLongest = %plyr;
         $Rabbit::LongestFlagHeld = $Rabbit::PlyrLongestFlagHeld[%plyr]; 
      }
   }
}

function Rabbit::restoreServerDefaults(){
   Rabbit::validateItems();
   Rabbit::restoreTeamInfo();
   
   exec("code.admin.cs");
   exec("code.game.cs");
   exec("code.server.cs");
   exec("objectives.cs");
}

function Rabbit::restoreTeamInfo(){  //Unfortunately I haven't figured out how to tell if the next mission will be a Rabbit mission or not, so this not used yet.
   $Server::teamName0 = $Rabbit::oldTeamName0;
   $Server::teamName1 = $Rabbit::oldTeamName1;
   $Server::teamName2 = $Rabbit::oldTeamName2;
   $Server::teamSkin0 = $Rabbit::oldTeamSkin0;
   $Server::teamSkin1 = $Rabbit::oldTeamSkin1;
   $Server::teamSkin2 = $Rabbit::oldTeamSkin2;
   $Server::JoinMOTD = $Rabbit::origJoinMOTD ; //replace old message of the day
}

function Rabbit::invalidateItems(){
   %count =0;
   for (%i = 0; $Rabbit::Item[%i, ItemType] != ""; %i++){
      if ($Rabbit::Item[%i, Allowed] != true){
         $invList[$Rabbit::Item[%i, ItemType]] = 0;
         $remoteInvList[$Rabbit::Item[%i, ItemType]] = 0;
         $ammoPackMax[$Rabbit::Item[%i, ItemType]] = 0;  //to stop players from getting these items via ammopack (circumvent game bug)  
         $Rabbit::banList[%count] = $Rabbit::Item[%i, DisplayName];
//         echo("DEBUG : Removing " @ $Rabbit::banList[%count]);
         %count++;
      }
   } 
   $Rabbit::banList[%count] = "";  //place blank entry at end of list to end        
}


function Rabbit::validateItems(){
   for (%i = 0; $Rabbit::Item[%i, ItemType] != ""; %i++){
      if ($Rabbit::Item[%i, Allowed] != true){
         $invList[$Rabbit::Item[%i, ItemType]] = 1;
         $remoteinvList[$Rabbit::Item[%i, ItemType]] = 1;
         // echo("DEBUG : Restoring " @ $Rabbit::Item[%i, displayName]);
      }
   } 
   $AmmoPackMax[BulletAmmo] = 150; //reset any $ammoPackMax values we might have changed in Rabbit::invalidateItems
   $AmmoPackMax[PlasmaAmmo] = 30;
   $AmmoPackMax[DiscAmmo] = 15;
   $AmmoPackMax[GrenadeAmmo] = 15;
   $AmmoPackMax[MortarAmmo] = 10;
   $AmmoPackMax[MineAmmo] = 5;
   $AmmoPackMax[Grenade] = 10;
   $AmmoPackMax[Beacon] = 10;
   exec("Objectives.cs");  //redefine Flag:: functions (and several others) in case next mission isn't Rabbit
}


function ObjectiveMission::initCheck(%object){
//   echo("DEBUG : ObjectiveMission::init called");
   if(GameBase::virtual(%object, objectiveInit))
      addToSet("MissionCleanup/ObjectivesSet", %object);
}


function Flag::objectiveInit(%this){
//   echo("DEBUG : Flag::ObjectiveInit called");
   %this.originalPosition = GameBase::getPosition(%this);
   %this.atHome = true;
   %this.pickupSequence = 0;
   %this.carrier = -1;
   %this.holdingTeam = -1;
   %this.holder = "";
   %this.enemyCaps = 0;
   %this.caps[0] = 0;
   %this.caps[1] = 0;
   %this.caps[2] = 0;
   %this.caps[3] = 0;
   %this.caps[4] = 0;
   %this.caps[5] = 0;
   %this.caps[6] = 0;
   %this.caps[7] = 0;
   $teamFlag[GameBase::getTeam(%this)] = %this;
   return true;
}



////////////////////////////////////////////////////////
// Altered Game functions used in other mission types //
////////////////////////////////////////////////////////
function remoteMissionChangeNotify(%serverManagerId, %nextMission)
{
   if(%serverManagerId == 2048)
   {
      //cls();  remmed this so I could see the console
      echo("DEBUG : Server mission complete - changing to mission: ", %nextMission);
      // echo("DEBUG : Flushing Texture Cache");
      flushTextureCache();
      schedule("purgeResources(true);", 3);
   }
}


// modified this to disable the ability to switch to any team
// other than team 0, assign custom skin rather than team default,
// and added a call to my Rabbit::JoinInit function to reset residual scores
function Game::initialMissionDrop(%clientId)
{
	Client::setGuiMode(%clientId, $GuiModePlay);

   if($Server::TourneyMode)
      GameBase::setTeam(%clientId, -1);
   else
   {
      if(%clientId.observerMode == "observerFly" || %clientId.observerMode == "observerOrbit")
      {
	      %clientId.observerMode = "observerOrbit";
	      %clientId.guiLock = "";
         Observer::jump(%clientId);
         return;
      }
      %numTeams = getNumTeams();
      %curTeam = Client::getTeam(%clientId);

      if(%curTeam >= %numTeams || (%curTeam == -1 && (%numTeams < 2 || $Server::AutoAssignTeams)) )
         GameBase::setTeam(%clientId, 0);
   }    
	Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
   %camSpawn = Game::pickObserverSpawn(%clientId);
   Observer::setFlyMode(%clientId, GameBase::getPosition(%camSpawn), 
	   GameBase::getRotation(%camSpawn), true, true);

   if(Client::getTeam(%clientId) == -1)
   {
      %clientId.observerMode = "pickingTeam";

      if($Server::TourneyMode && ($matchStarted || $matchStarting))
      {
         %clientId.observerMode = "observerFly";
         return;
      }
      else if($Server::TourneyMode)
      {
         if($Server::TeamDamageScale)
            %td = "ENABLED";
         else
            %td = "DISABLED";
         bottomprint(%clientId, "<jc><f1>Server is running in Competition Mode\nPick a team.\nTeam damage is " @ %td, 0);
      }
      Client::buildMenu(%clientId, "Pick a team:", "InitialPickTeam");
      Client::addMenuItem(%clientId, "0Observe", -2);
      Client::addMenuItem(%clientId, "1" @ getTeamName(0), 0);
      %clientId.justConnected = "";
   }
   else 
   {
      Client::setSkin(%clientId, $Client::info[%ClientId, 0]);  //use custom skin
      
      if(%clientId.justConnected)
      {
         centerprint(%clientId, $Server::JoinMOTD, 0);
         %clientId.observerMode = "justJoined";
         %clientId.justConnected = "";
      }
      else if(%clientId.observerMode == "justJoined")
      {
         centerprint(%clientId, "");
         %clientId.observerMode = "";
         Game::playerSpawn(%clientId, false);
      }
      else
         Game::playerSpawn(%clientId, false);
	}
	if($TeamEnergy[Client::getTeam(%clientId)] != "Infinite")
		$TeamEnergy[Client::getTeam(%clientId)] += $InitialPlayerEnergy;
	%clientId.teamEnergy = 0;
      Rabbit::JoinInit(%clientId);
}


function Vote::changeMission(){
   $timeLimitReached = true;
   Rabbit::objectivesScreen();
}

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

//zadmin overwrite
function displayMenuChangeTeamsMenu(%cl, %opt)
{
    buildNewMenu("Change Teams", "changeTeamsMenu", %cl);

	addLine("Observer", -2, true, %cl);
	addLine(getTeamName(0), 0, true, %cl);
}

// reset server defaults
function Server::loadMission(%missionName, %immed)
{             
   Rabbit::restoreServerDefaults();
   
   if($loadingMission)
      return;

   %missionFile = "missions\\" $+ %missionName $+ ".mis";
   
   if(File::FindFirst(%missionFile) == "")
   {
      %missionName = $firstMission;
      %missionFile = "missions\\" $+ %missionName $+ ".mis";
      if(File::FindFirst(%missionFile) == "")
      {
         echo("invalid nextMission and firstMission...");
         echo("aborting mission load.");
         return;
      }
   }
   echo("Notfifying players of mission change: ", getNumClients(), " in game");
   // Clearing this flag
   $DuelsStarted = "";
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      Client::setGuiMode(%cl, $GuiModeVictory);
      %cl.guiLock = true;
      %cl.nospawn = true;
      remoteEval(%cl, missionChangeNotify, %missionName);
   }

   $loadingMission = true;
   $missionName = %missionName;
   $missionFile = %missionFile;
   $prevNumTeams = getNumTeams();

   deleteObject("MissionGroup");
   deleteObject("MissionCleanup");
   deleteObject("ConsoleScheduler");
   resetPlayerManager();
   resetGhostManagers();
   $matchStarted = false;
   $countdownStarted = false;
   $ghosting = false;

   resetSimTime(); // deal with time imprecision

   newObject(ConsoleScheduler, SimConsoleScheduler);
   if(!%immed)
      schedule("Server::finishMissionLoad();", 18);
   else
      Server::finishMissionLoad();      
}



echo("     *** zadmin [rabbit/1.0.release/andrew]");