//"Name" is the name that will show up in logs, the password is what they log in with using sad("pwg")

zadmin::setCurrentAdminLevel("General Admin");
zadmin::addAdmin("Name",	"pwg");

zadmin::setCurrentAdminLevel("Super Admin");
zadmin::addAdmin("Name",	"pws");

zadmin::setCurrentAdminLevel("Ultra Admin");
zadmin::addAdmin("Name",	"pwu");

zadmin::setCurrentAdminLevel("Jesus Christ");
zadmin::addAdmin("Name",	"pwj");