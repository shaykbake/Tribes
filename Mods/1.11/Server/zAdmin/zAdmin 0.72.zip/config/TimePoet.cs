$TPDate = "25 02 2003";
$TPTime = "11:22:46";
$TPFrequency = 1;
