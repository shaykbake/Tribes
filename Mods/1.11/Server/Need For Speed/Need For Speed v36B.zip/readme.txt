The Need For Speed v36 Mod : Creators
Blade[INC] "mhaymon@speedchoice.com"
Enforcer[INC] "garzajoed@home.net or enforcer@planetstarsiege.com"
With input from the Incubus tribe members.  
** Stealth and Deployable Rocket Turret are code from the Renegade Mod. Thanks to the writers 
as it is always better to reuse than recreate.

To Use This Mod:
Place the "NFSv34" folder in C:\Dynamix\Tribes
Use this line to execute the mod:	
               (DEDICATED) "C:\Dynamix\Tribes\Tribes.exe -mod NFSv36 -dedicated"
               (HOSTED)    "C:\Dynamix\Tribes\Tribes.exe -mod NFSv36"	

What is in this Mod:

Speed for all armors have been adjusted to increase the pace of the game.
*New Armors:
	1)Very Light - Very fast, can use morters and nuker (designed for flag capture)
	2)Medium Defensive - Designed for defense set up and flag defender
	3)Heavy Destructive - Need I say more!

*New Vehicles:
           *NOTE* All Vehicles Are Now Armed and are more Responsive- All Armors Can Pilot Vehicles 
	1)Scout   - Increased cycle rate of fire
	2)Stealth - Invisable, fires Morters
	3)LPC     - Fires Grenades
	4)Nuker   - Need I say More!!
	5)HPC     - Fires Morters at a fast rate

*Weapons:
	1) Nuke	      - When you must absolutely Kill everyone in a large radious (Self included if close)
		        Only available to Very Light Armor - 1 shot only.
	2)Burst gun   - Multi-firing,high velocity shooting
	3)Elf Blaster - Upgrade of Burst gun, not as fast but alot stronger
	4)Nasty Gun   - Wel kind of the balance of all. Strong round, not too fast-not too slow.
	**All weapons have been modified to reflect the
	characteristics of real weapons-with realtion to balistics.

*New Deployables:
	1)Chaingun Turret
	2)Rocket Turret (from Renegade Mod)
	3)Blaster Turret
you will get credit for regular "Turret" kills

This Mod is a work in progress. There will be some who dont like it and some who do. We are open to any
suggestions that will improve the quality of game play.