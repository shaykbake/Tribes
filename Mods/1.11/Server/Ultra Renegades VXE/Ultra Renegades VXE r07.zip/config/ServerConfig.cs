//------------ Server Setup ------------\\

$Server::Info = "Admin: Unknown";		// Server Info... Seen when you are in the game and you press ESC
$Server::HostName = "My VXE Server";		// Server Name


$Server::JoinMOTD = "<jc><f1>Play nice, Play fair!\n<f1>Server is running <f2>Ultra_RenegadesVXE<f1>.";
						// Server "Message Of The Day"
$Server::MaxPlayers = 10;			// Max players
$Server::Password = "";				// Server Password, Recommended left blank

$Server::TourneyMode = "false";			// Tourney mode? Recommended FALSE
$Server::timeLimit = 25;			// Server Time Limit in Minutes
$Server::FloodProtectionEnabled = true;		// Flood protection, Recommended true
$Server::TeamDamageScale = 0;			// Team Damage, 0 false and 1 true
$Server::VotingTime = 20;			// Time until a vote succedes
$Server::VoteFailTime = 20;			// Time until a vote fails
$Server::warmupTime = 20;			// Time before match begins in seconds
$Server::respawnTime = 0;			// Time it takes to spawn after death, if "0" you must fire to spawn
$Server::AutoAssignTeams = true;		// Auto Assign Teams, Recommended true
$pref::LastMission = "DangerousCrossing";

$Server::HostPublicGame = true;			// DO NOT CHANGE THIS


// The below settings are for voting. Set to false to disable clients from voting.
$ultra_renegades::PVMission = true;		// Change mission
$ultra_renegades::PVTeamDamage = true;		// Team Damage
$ultra_renegades::PVFairTeams = true;		// Fair teams
$ultra_renegades::PVTourneyMode = true;		// Tourney / FFA Mode


//------------ Team stuff ------------\\

$Server::teamName0 = "Team1";
$Server::teamName1 = "Team2";
$Server::teamName2 = "Team3";
$Server::teamName3 = "Team4";
$Server::teamName4 = "Team5";
$Server::teamName5 = "Team6";
$Server::teamName6 = "Team7";
$Server::teamName7 = "Team8";
$Server::teamSkin0 = "cphoenix";
$Server::teamSkin1 = "swolf";
$Server::teamSkin2 = "base";
$Server::teamSkin3 = "base";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";


//------------ Admin passwords and telnet port/password ------------\\

$TelnetPort = 2008;
$TelnetPassword = "locksmith";

$AdminPassword = "xxxxxx"; 		//	replace xxxxxx with your super admin password
$MatchAdminPassword = "xxxxx";		//	replace xxxxx  with your match admin password

//Put as many match admin passwords as you want...
$MatchAdminPasswordList = "password1 password2 password3 password4 etcetc";
//Seperate each password with a space


//------------ Network settings ------------\\
// Test your bandwidth at www.dslreports.com, and write down your UPLOAD BANDWIDTH...
//   NOT your download bandwidth. You can then get an idea to what your max players
//   should be and what packet settings you should use.
//   Also keep in mind the higher the packet settings are, the more people will like 
//   your server, heh.

//RECOMMENDED NETWORK PREF SDSL 1.5mBit 12-16 players
//   9.6 kbytes/sec (76.8 kbits/sec) SERVER UPLOAD per player
$pref::PacketFrame = 32;
$pref::PacketRate = 24; 
$pref::PacketSize = 400;

//RECOMMENDED NETWORK PREF Cable Modem 8 players
//  4.4 kbytes/sec (35.2 kbits/sec) SERVER UPLOAD per player
//$pref::PacketFrame = 32;
//$pref::PacketRate = 20; 
//$pref::PacketSize = 220;

////HIGHEST NETWORK PREF
////  15 kbytes/sec (120 kbits/sec) SERVER UPLOAD per player
//$pref::PacketFrame = 32;
//$pref::PacketRate = 30; 
//$pref::PacketSize = 500;

////LOWEST NETWORK PREF Dial Up Server 2-4 players
//$pref::PacketFrame = 96;
//$pref::PacketRate = 10; 
//$pref::PacketSize = 200;



//  http://www.ggzleague.com/vxe/  \\