$Ultra_RenegadesVX5::difficultyvoting = "true";
$Ultra_RenegadesVX5::modvoting = "true";
$Ultra_RenegadesVX5::ultravxDIFmode = "Defaults";
$Ultra_RenegadesVX5::ultravxmod = "Ultra_RenegadesVX5";
