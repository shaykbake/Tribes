$TelnetPort = "2000";
$TelnetPassword = "kyle";
$AdminPassword = "PTC";

