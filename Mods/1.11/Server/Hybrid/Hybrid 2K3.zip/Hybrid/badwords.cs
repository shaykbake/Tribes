$badwords = "fuck bitch bastard cock cunt dick nigger shit whore";
