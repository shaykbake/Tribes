$TelnetPort = "2000";
$TelnetPassword = "Kyle";
$AdminPassword = "PTC";

