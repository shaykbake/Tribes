//------------ Server Setup ------------\\

$Server::Info = "Admin: Unknown\nEmail: Unknown";
$Server::HostName = "My VXE Server";


$Server::JoinMOTD = "<jc><f1>Play nice, Play fair!\n<f1>Server is running <f2>Ultra_RenegadesVXE r0.6<f1>.";
$Server::MaxPlayers = "10";
$Server::Password = "";

$Server::AutoAssignTeams = "true";
$Server::FloodProtectionEnabled = "true";
$Server::HostPublicGame = "true";
$Server::MinVotes = "1";
$Server::MinVotesPct = "0.5";
$Server::MinVoteTime = "45";
$Server::respawnTime = "0";
$Server::TeamDamageScale = "0";
$Server::timeLimit = "25";
$Server::TourneyMode = "false";
$Server::VoteAdminWinMargin = "0.659999";
$Server::VoteFailTime = "30";
$Server::VoteWinMargin = "0.549999";
$Server::VotingTime = "20";
$Server::warmupTime = "20";
$pref::LastMission = "DangerousCrossing";


//------------ Team stuff ------------\\

$Server::teamName0 = "Team1";
$Server::teamName1 = "Team2";
$Server::teamName2 = "Team3";
$Server::teamName3 = "Team4";
$Server::teamName4 = "Team5";
$Server::teamName5 = "Team6";
$Server::teamName6 = "Team7";
$Server::teamName7 = "Team8";
$Server::teamSkin0 = "cphoenix";
$Server::teamSkin1 = "swolf";
$Server::teamSkin2 = "base";
$Server::teamSkin3 = "base";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";


//------------ Admin passwords and telnet port/password ------------\\

$TelnetPort = 2008;
$TelnetPassword = "locksmith";

$AdminPassword = "xxxxxx"; 		//	replace xxxxxx with your super admin password
$MatchAdminPassword = "xxxxx";		//	replace xxxxx  with your match admin password

//Put as many match admin passwords as you want...
$MatchAdminPasswordList = "password1 password2 password3 password4 etcetc";
//Seperate each password with a space


//------------ Network settings ------------\\

//RECOMMENDED NETWORK PREF SDSL 1.5mBit 12-16 players
//   9.6 kbytes/sec (76.8 kbits/sec) SERVER UPLOAD per player
$pref::PacketFrame = 32;
$pref::PacketRate = 24; 
$pref::PacketSize = 400;

//RECOMMENDED NETWORK PREF Cable Modem 8 players
//  4.4 kbytes/sec (35.2 kbits/sec) SERVER UPLOAD per player
//$pref::PacketFrame = 32;
//$pref::PacketRate = 20; 
//$pref::PacketSize = 220;

////HIGHEST NETWORK PREF
////  15 kbytes/sec (120 kbits/sec) SERVER UPLOAD per player
//$pref::PacketFrame = 32;
//$pref::PacketRate = 30; 
//$pref::PacketSize = 500;

////LOWEST NETWORK PREF Dial Up Server 2-4 players
//$pref::PacketFrame = 96;
//$pref::PacketRate = 10; 
//$pref::PacketSize = 200;



//  http://www.ggzleague.com/vxe/  \\