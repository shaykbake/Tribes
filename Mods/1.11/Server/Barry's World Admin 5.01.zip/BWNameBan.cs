//================================================================================================
//=======                        BWNameBanList General Settings                            =======
//================================================================================================

//How many Ban Strings in your list?
$bwadmin::MaxBanStrings = 1;

//================================================================================================
//=======                         This is the ban data                                     =======
//================================================================================================
//
//	$bwadmin::NameBanString[1,string] = "Tosser";
//	$bwadmin::NameBanString[1,message] = "Buggar off you TKing SOB";
//	$bwadmin::NameBanString[1,bantime] = 1800;
//
//	In the example above, anyone with the string Tosser in their name (ie. [EK]Tosser, TosserB, etc)
//	will be kicked.  The message "Buggar off you TKing SOB" will eb displayed to this user and
//	he/she will be ip banned for 1800 seconds. (30 minutes)
//
//=================================================================================================

$bwadmin::NameBanString[1,string] = "Tosser";
$bwadmin::NameBanString[1,message] = "Buggar off you TKing SOB";
$bwadmin::NameBanString[1,bantime] = 1800;
