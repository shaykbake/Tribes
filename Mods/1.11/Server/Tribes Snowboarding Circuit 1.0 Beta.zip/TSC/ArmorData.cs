//----------------------------------------------------------------------------
// Light Armor
//----------------------------------------------------------------------------

$DamageScale[larmor, $LandingDamageType] = 0;
$DamageScale[larmor, $ImpactDamageType] = 0;
$DamageScale[larmor, $CrushDamageType] = 0;
$DamageScale[larmor, $BulletDamageType] = 0;
$DamageScale[larmor, $PlasmaDamageType] = 0;
$DamageScale[larmor, $EnergyDamageType] = 0;
$DamageScale[larmor, $ExplosionDamageType] = 0;
$DamageScale[larmor, $MissileDamageType] = 0;
$DamageScale[larmor, $DebrisDamageType] = 0;
$DamageScale[larmor, $ShrapnelDamageType] = 0;
$DamageScale[larmor, $LaserDamageType] = 0;
$DamageScale[larmor, $MortarDamageType] = 0;
$DamageScale[larmor, $BlasterDamageType] = 0;
$DamageScale[larmor, $ElectricityDamageType] = 0;
$DamageScale[larmor, $MineDamageType] = 0;

$ItemMax[larmor, Blaster] = 1;
$ItemMax[larmor, Chaingun] = 0;
$ItemMax[larmor, Disclauncher] = 0;
$ItemMax[larmor, GrenadeLauncher] = 0;
$ItemMax[larmor, Mortar] = 0;
$ItemMax[larmor, PlasmaGun] = 0;
$ItemMax[larmor, LaserRifle] = 0;
$ItemMax[larmor, EnergyRifle] = 1;
$ItemMax[larmor, TargetingLaser] = 0;
$ItemMax[larmor, MineAmmo] = 10;
$ItemMax[larmor, Grenade] = 10;
$ItemMax[larmor, Beacon]  = 0;

$ItemMax[larmor, BulletAmmo] = 0;
$ItemMax[larmor, PlasmaAmmo] = 0;
$ItemMax[larmor, DiscAmmo] = 0;
$ItemMax[larmor, GrenadeAmmo] = 0;
$ItemMax[larmor, MortarAmmo] = 0;

$ItemMax[larmor, EnergyPack] = 1;
$ItemMax[larmor, RepairPack] = 0;
$ItemMax[larmor, ShieldPack] = 1;
$ItemMax[larmor, SensorJammerPack] = 0;
$ItemMax[larmor, MotionSensorPack] = 0;
$ItemMax[larmor, PulseSensorPack] = 0;
$ItemMax[larmor, DeployableSensorJammerPack] = 0;
$ItemMax[larmor, CameraPack] = 1;
$ItemMax[larmor, TurretPack] = 0;
$ItemMax[larmor, AmmoPack] = 0;
$ItemMax[larmor, RepairKit] = 5;
$ItemMax[larmor, DeployableInvPack] = 0;
$ItemMax[larmor, DeployableAmmoPack] = 0;

$MaxWeapons[larmor] = 2;

//------------------------------------------------------------------
// Snowboarder Adrenaline Armor
//------------------------------------------------------------------

$DamageScale[larmor2, $LandingDamageType] = 0;
$DamageScale[larmor2, $ImpactDamageType] = 0;
$DamageScale[larmor2, $CrushDamageType] = 0;
$DamageScale[larmor2, $BulletDamageType] = 0;
$DamageScale[larmor2, $PlasmaDamageType] = 0;
$DamageScale[larmor2, $EnergyDamageType] = 0;
$DamageScale[larmor2, $ExplosionDamageType] = 0;
$DamageScale[larmor2, $MissileDamageType] = 0;
$DamageScale[larmor2, $DebrisDamageType] = 0;
$DamageScale[larmor2, $ShrapnelDamageType] = 0;
$DamageScale[larmor2, $LaserDamageType] = 0;
$DamageScale[larmor2, $MortarDamageType] = 0;
$DamageScale[larmor2, $BlasterDamageType] = 0;
$DamageScale[larmor2, $ElectricityDamageType] = 0;
$DamageScale[larmor2, $MineDamageType] = 0;

$ItemMax[larmor2, Blaster] = 1;
$ItemMax[larmor2, Chaingun] = 0;
$ItemMax[larmor2, Disclauncher] = 0;
$ItemMax[larmor2, GrenadeLauncher] = 0;
$ItemMax[larmor2, Mortar] = 0;
$ItemMax[larmor2, PlasmaGun] = 0;
$ItemMax[larmor2, LaserRifle] = 0;
$ItemMax[larmor2, EnergyRifle] = 1;
$ItemMax[larmor2, TargetingLaser] = 0;
$ItemMax[larmor2, MineAmmo] = 10;
$ItemMax[larmor2, Grenade] = 10;
$ItemMax[larmor2, Beacon]  = 0;

$ItemMax[larmor2, BulletAmmo] = 0;
$ItemMax[larmor2, PlasmaAmmo] = 0;
$ItemMax[larmor2, DiscAmmo] = 0;
$ItemMax[larmor2, GrenadeAmmo] = 0;
$ItemMax[larmor2, MortarAmmo] = 0;

$ItemMax[larmor2, EnergyPack] = 1;
$ItemMax[larmor2, RepairPack] = 0;
$ItemMax[larmor2, ShieldPack] = 1;
$ItemMax[larmor2, SensorJammerPack] = 0;
$ItemMax[larmor2, MotionSensorPack] = 0;
$ItemMax[larmor2, PulseSensorPack] = 0;
$ItemMax[larmor2, DeployableSensorJammerPack] = 0;
$ItemMax[larmor2, CameraPack] = 1;
$ItemMax[larmor2, TurretPack] = 0;
$ItemMax[larmor2, AmmoPack] = 0;
$ItemMax[larmor2, RepairKit] = 5;
$ItemMax[larmor2, DeployableInvPack] = 0;
$ItemMax[larmor2, DeployableAmmoPack] = 0;

$MaxWeapons[larmor2] = 2;

//------------------------------------------------------------------
// light armor data:
//------------------------------------------------------------------

DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};

PlayerData larmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
   debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
   mapFilter = 1;
   mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0;
   maxJetForwardVelocity = 0;
   minJetEnergy = 101;
   jetForce = 0;
   jetEnergyDrain = 0;

   maxDamage = 5000.0;
   maxForwardSpeed = 10;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 10.0;
   groundTraction = 10.0;
   maxEnergy = 100;
   drag = 1.0;
   density = 1.2;

   minDamageSpeed = 25;
   damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "root", none, 1, true, true, true, false, 0 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundSnow;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// snowboarder adrenaline armor data:
//------------------------------------lflame------------------------

DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};

PlayerData larmor2
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
   debrisId = playerDebris;
   flameShapeName = "rocket";
   shieldShapeName = "shield";
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = False;
   mapFilter = 1;
   mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 100.0;
   maxJetForwardVelocity = 200.0;
   minJetEnergy = 0.1;
   jetForce = 285.0;
   jetEnergyDrain = 0.01;

	maxDamage = 5000;
   maxForwardSpeed = 50;
   maxBackwardSpeed = 0;
   maxSideSpeed = 40;
   groundForce = 40 * 9.0;
   mass = 20.0;
   groundTraction = 2;
	maxEnergy = 5000;
   drag = 1.0;
   density = 1.0;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "root", none, 1, true, true, true, false, 0 };
   animData[2]  = { "root", none, 1, true, true, true, false, 0 };
   animData[3]  = { "root", none, 1, true, true, true, false, 0 };
   animData[4]  = { "root", none, 1, true, true, true, false, 0 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "root", none, 1, true, true, true, false, 0 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundFlyerIdle;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};






