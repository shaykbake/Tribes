Tribes Snowboarding Circuit
by Martyr, AKA Dayspring

Team:

Just me, Unfortunately. This isn't my first Mod, but it's the first I'm releasing. Hopefully, there will be more, but I'm no coder, I just do what I can. If anyone is interested in becoming part of a Developement team, I'm always open for the idea.

TSC (Tribes Snowboarding Circuit)

This Beta release will introduce you to the main aspect of the Mod, and provide a preview peek into it. If you haven't figured it out by now, the objective of the game is to race your opponents from start to finish, and be the first to cross the finish line. You have at your disposal [1] A cloaking device, used to slip past your opponent unseen. [2] A Nitrous Oxide System [NOS Controller, In-Game], which is used to gain additional speed during jumps and on the track. Careful with the NOS, as it is dangerous to use at lower speeds, and has been known to malfunction, causing Boarders to lose control and fly off the track. The "Finish line" is a flag at the end of the track. Smack it one good time, and you win.

The Player

Tribesman Joe-Blow [That'd be you] is tired of kickin peoples butts, and decides it's time for a vacation. He calls up his travel agent, and hooks it up with a trip to a fine ski-resort, which just happens to double as Snowboarding Race Circuit. He peeks into his custom inventory station, and rumages through the many items until he finds what he's looking for - A TSC Afterburner III Single-Thrust Engery-Propulsion Class AAA 1911-A4C Dominator Series Snowboard/Thrust Pack. Handy, huh? He packs it up, and takes the nearest DropShip to the resort, where he spends some time on 'The_Slopes.mis' practising for a bit, hint-hint, and then hits the Valhala Speedway for a few quick Introduction laps, and finally head to Sie_Lange_Nacht, for the real competition. Where to next? Time will tell...

The Game

Upon spawning, you are regular-whoever, a basic Tribesman, with no jetpack. You activate your pack when the match begins, and fight for the victory lane. Sounds simple? It is. Why make a complicated Snowboarding Mod? Directions for using everything is below:

TSC Pack/Snowboard:

Activate by pressing 'P' key. Unless you activate this, you will NOT be able to Snowboard, you will run like syrup. And you'll lose. Upon activation, your pack becomes a Board, and you are on it. You may now exceed 150 MPH, and slide around turns.

NOS Controller: What it sounds like. Used best when travelling uphill, or coming off jumps. Dangerous when used at slow speeds, as it may throw you off the track. Pretty much, an automatic loss.

Hunter IV Cloaking Device: For the fun of it. Will make you invisible for a limited ammount of time.

Controlling your Board-Warrior:

Use regular movement controls, as if you were running on foot. Watch the curves, turn a lil bit sooner than you normally would, or you might find yourself sliding off the track. Use your Jet button when going up inclines, going over jumps, and to control yourself in the air. It can be a great tool for speed, if you use it correctly. You can't Board in reverse, unless you slide backwards. Watch your jumps, too high or far may result in over-jumping the track, harmful if there's a curve ahead. Have fun.

This is a beta release. There are 3 small maps, one is meant for you to practice on [The_Slopes].
Look for more to come.

For info, details, questions, comments, complaints, suggestions, flames, or a free Pack of Cigarettes, send email to:

FiveDelta6@hotmail.com

  Dir Freund, Martyr