$ItemFavoritesKey = "TiZ";
$Welcome="<jc><f2>TiZ\n http://www.goncalves.com/mike\n\n";
$DefaultArmor[Male] = dmarmor;
$DefaultArmor[Female] = dmfemale;

 // Initial buy list
$spawnBuyList[0] = iarmorMercenary;
$spawnBuyList[1] = GrenadeLauncher;
$spawnBuyList[2] = Chaingun;
$spawnBuyList[3] = DiscLauncher;
$spawnBuyList[4] = RepairKit;
$spawnBuyList[5] = Grenade;
$spawnBuyList[6] = Grenade;
$spawnBuyList[7] = Grenade;
$spawnBuyList[8] = Grenade;
$spawnBuyList[9] = Beacon;
$spawnBuyList[10] = Beacon;
$spawnBuyList[11] = Beacon;
$spawnBuyList[12] = Beacon;
$spawnBuyList[13] = RepairPack;
$spawnBuyList[14] = Mineammo;
$spawnBuyList[15] = TargetingLaser;

function serverRenegades::Start()
{
   echo('>> Loading armor classes');
	exec(armorScout);
	exec(armorSpy);
	exec(armorMercenary);
	exec(armorEngineer);
	exec(armorBurster);
	exec(armorCyborg);
        exec(armorEngineer);
        exec(armorSniper);
        exec(armorAlien);
        exec(armorDM);
        exec(armorCommando);
        exec(armorLoader);
        exec(armorDestroyer);
   echo('>> Loading weapons');
        exec(weaponTargetLaser);
        exec(weaponPlasmaGun);
        exec(weaponLaserRifle);
	exec(weaponDiscCannon);
	exec(weaponAutoCannon);
	exec(weaponHyperBlaster);
        exec(weaponChaingun);
        exec(weaponMagnum);
        exec(weaponSniperRifle);
        exec(weaponLongRifle); 
        exec(weaponShotgun);
        exec(weaponFlamer);
        exec(weaponDiscLauncher);
	exec(weaponGrenade);
     	exec(weaponMortar);
      exec(weaponRocketLauncher);
	exec(weaponELF);
	exec(weaponFixit);
        
   echo('>> Loading packs');
	exec(packAmmo);
	exec(packCommand);
	exec(packEnergy);
        exec(packJetPack);
        exec(packRegeneration);
        exec(packRepair);
        exec(packShield);
        exec(packCloak);
        exec(packStealthShield);
	exec(packJammer);
	exec(packLightening);
	exec(packOptic);
        exec(packSMR);
	exec(packSuicide);
        exec(packOMen);
        

   echo('>> Loading misc');
	exec(miscBeacon);
	exec(miscGrenade);
	exec(miscMine);
	exec(miscRepairKit);

   echo('>> Loading deployable sensors');
	exec(deployMotionSensor);
	exec(deployPulseSensor);
        exec(deployCamera);
	exec(deploySensorJammer);

   echo('>> Loading deployable objects');
	exec(deploySmallInventoryStation);
	exec(deploySmallAmmoStation);
	exec(deploySmallCommandStation); 
        exec(deployBlastWall); 
        exec(deployPlatform);  
        exec(deployAirPlat);      
	exec(deployForceField);
	exec(deployBigField);
        exec(deployMannequin);
	exec(deployTree);
	exec(deployTeleporter);
	exec(deploySpringboard);
	exec(deployAccelerator);
	exec(deployVehicles);
	exec(deploySatchelCharge);
        exec(deployLRSensorJammerPack);
        exec(deployLRMotionSensorPack);
        exec(deployLRPulseSensorPack);
        exec(deployVehiclex);
         
   echo('>> Loading deployable weapons');
	exec(deployIonTurret);
	exec(deployLaserTurret);
	exec(deployMissileTurret);
	exec(deployPlasmaTurret);
         
   echo('>> Vehicles');
	exec(Vehicle);
	exec(vehicleScout);
	exec(vehicleInterceptor);
	exec(vehicleWraith);
        exec(vehicleFighter);
        exec(vehicleHAPC);
        exec(vehicleTempest);
	exec(vehicleLAPC);
        exec(vehicleHvyFighter);
        exec(vehicleSpeeder);
   echo('>> Usage');
	exec(serverRenegades_ItemUsage);
}

function serverRenegades::InitializeMission()
{
         // Initialize vehicles
	vehicleScout::Initialize();
	vehicleInterceptor::Initialize();
	vehicleWraith::Initialize();
        vehicleDogFighter::Initialize();
        vehicleHAPC::Initialize();
        vehicleTempest::Initialize();
	vehicleLAPC::Initialize();
	vehicleQuickLPC::Initialize();
        vehicleSpeeder::Initialize();
	 // Initialize deployables
	deploySmallInventoryStation::Initialize();
	deploySmallAmmoStation::Initialize();
	deploySmallCommandStation::Initialize();
	deployForceField::Initialize(); 
	deployBigField::Initialize();
	deployMannequin::Initialize();
	deployTree::Initialize();
	deployBlastWall::Initialize();
	deployPlatform::Initialize();
	deployTeleporter::Initialize();
	deploySpringboard::Initialize();
	deployAccelerator::Initialize();
        deployAirPlat::Initialize();

	miscMine::Initialize();
	miscBeacon::Initialize();

	deploySensorJammer::Initialize();
	deployCamera::Initialize();
	deployPulseSensor::Initialize();
	deployMotionSensor::Initialize();

	deployPlasmaTurret::Initialize();
	deployMissileTurret::Initialize();
	deployLaserTurret::Initialize();
	deployIonTurret::Initialize();	

	deploySatchelCharge::Initialize();
}