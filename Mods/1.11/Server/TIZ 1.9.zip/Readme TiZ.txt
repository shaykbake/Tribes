Thanks for download The Infinite Zero Mod, my new mod (By Timer[TiZ])

////////////////
T  i  Z    1.9\\
\\\\\\\\\\\\\\\\

By Michael Cheung (Timer[TiZ])

Timer2k@hotmail.com

INSTALLATION:

     a) Create a folder in your tribes directory called TiZ and move everything in this zip file
        into it

     b) Create a shortcut to Tribes.exe and right click on it, and goto PROPERTIES

     c) There should be a box called 'target', which states the path for your Tribes.exe, after it, type in
        " -mod TiZ"

        So, if my Tribes directory was in c:\dynamix (by default) it would be:

        C:\Dynamix\tribes\Tribes.exe -mod TiZ

     d) Run the SHORTCUT to tribes and host to play!

2) ITEM LIST

ARMOR

Kraken Armor - Very light, quick armor, meant for flag capping and harassment
Assault Armor - Average everyday armor (HINT: Bitches at infiltration)
Mechanic - Deploys EVERYTHING / Handi-man armor (a.k.a. Timer Armor) =)
Assasin Armor - Average Sniper armor that can carry DEVASTATING weaponry
Demolitions Man - Specializes in pyrotechniks and bombs and stuff...
Annihilator Armor - Slow, super bitch, which is strong against EVERYTHING except lasers
Titanic Armor - Faster, weaker version of Annihilator


WEAPONS

Targeting Laser
Plasma Gun
Nailgun
ERFP (Rapid Fire Pistol)
Laser Rifle
Disc Launcher
Grenade Launcher
Mortar
Sniper Rifle
Scorpion Rifle
Flamer
Rocket Launcher
ELF Gun
Doom Cannon
Repair Gun

somemore, but I forget =) A description is included for them when you use them

PACKS

Energy Pack
Repair Pack
Regeneration Pack
Shield Pack
Stealthshield Pack (Removes arrow)
Jammer Pack
Adv. Jammer Pack (JAMS MOTION SENSORS)
Ammo Pack (VERY buggy code)

DEPLOYABLES (MISC)

Remote Inv. Station
Ammo Station
Forcefield (large and small)
Deployable Platform (thick only)
Spring Pad
Blast Wall
Teleport Pad

some more, but I forget =)

SENSOR SYSTEM

Pulse Sensor
Sensor Jammer
Camera

No motion sensors, because I'm not letting someone just deploy 50+
turrets and expect them to ALWAYS defend =)

TURRETS

Laser Turret
Fusion Turret (a.k.a. ION Turret)
Plasma Turret
Missile Turret

*ALL TURRETS EXCEPT MISSILE CAN BE DEPLOYED ANYWHERE

3) OTHER ISSUES

REMEMBER TO SEND ALL SUGGESTIONS AND BUG REPORTS TO TIMER2K@HOTMAIL.COM

�COPYRIGHT 2000-2004
ALL RIGHTS RESERVED

+ I am not responsible for anything that happens to your computer while installing, playing
or viewing anything about or in this mod or the accompanying files


*yea, right* >=)

Please ask me if you wish ot edit the mod.