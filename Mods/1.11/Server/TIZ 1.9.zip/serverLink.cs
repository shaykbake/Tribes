exec(serverRenegades);

function serverLink::Start()
{
  serverRenegades::Start();
}

function serverLink::InitializeMission()
{
  serverRenegades::InitializeMission();
}