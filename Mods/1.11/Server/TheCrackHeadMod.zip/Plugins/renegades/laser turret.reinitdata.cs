//This is a MiniMod plugin...
//This is a modified Laser Turret from the ol' Renegades 1.2 mod. Ported and reworked by Dewy

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ LaserPack] = 0;
}
