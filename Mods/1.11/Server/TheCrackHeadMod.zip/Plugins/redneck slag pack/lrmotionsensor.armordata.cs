// This is a MiniMod Plugin.
// This is the Long Range Motion Sensor from the Redneck Slag Pack mod.
// Ported by PeterT.
//
// To install this plugin just...
// Add:
//
//    LRMotionSensor.ArmorData.cs
//    LRMotionSensor.item.cs
//    LRMotionSensor.reinitData.cs
//    LRMotionSensor.sensor.cs
//    LRMotionSensor.station.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[lfemale, DeployableLRMotionSensorPack] = 0;
$ItemMax[marmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[mfemale, DeployableLRMotionSensorPack] = 0;
$ItemMax[harmor, DeployableLRMotionSensorPack] = 1;
$ItemMax[sarmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[sfemale, DeployableLRMotionSensorPack] = 0;
$ItemMax[spyarmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[spyfemale, DeployableLRMotionSensorPack] = 0;
$ItemMax[barmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[bfemale, DeployableLRMotionSensorPack] = 0;
$ItemMax[earmor, DeployableLRMotionSensorPack] = 1;
$ItemMax[efemale, DeployableLRMotionSensorPack] = 1;
$ItemMax[aarmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[afemale, DeployableLRMotionSensorPack] = 0;
$ItemMax[darmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[tarmor, DeployableLRMotionSensorPack] = 0;
$ItemMax[scvarmor, DeployableLRMotionSensorPack] = 0;
