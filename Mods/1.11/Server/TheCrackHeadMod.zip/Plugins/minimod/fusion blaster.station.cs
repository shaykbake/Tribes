

$InvList[FusionGun] = 1;
$RemoteInvList[FusionGun] = 1;
