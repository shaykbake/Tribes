

function dataGotBlock(%blockName, %pctDone)
{
MiniMod::Load("plugins\\*.BanList.cs");
   if(%pctDone < 0.1)
      %text = "Loading Functions...";
   else if(%pctDone < 0.2)
      %text = "Loading Plugins...";
   else if(%pctDone < 0.3)
      %text = "Assigning Items, Weapons and Armor Loadouts...";
   else if(%pctDone < 0.4)
      %text = "Welcome to Crack-Heads enhanced Server...";
   else if(%pctDone < 0.5)
      %text = "You can download Crack-Heads mod from...";
   else if(%pctDone < 0.6)
      %text = "http://chm.iwarp.com ";
   else if(%pctDone < 0.7)
      %text = "Joining curret mission...";
   else if(%pctDone < 0.8)
      %text = "Note: Crack-Heads servers are EXTREAMLY modified...";
   else
      %text = "Don't Have to much fun...";

   //Control::setText(ProgressText, "Loading " @ %blockName @ " data...");
   Control::setValue(ProgressText, "<jc><f1>" @ %text);
   Control::setValue(ProgressSlider, %pctDone * 0.75);
}
