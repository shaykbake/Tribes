

$InvList[IndoorTurretPack] = 1;
$RemoteInvList[IndoorTurretPack] = 1;
