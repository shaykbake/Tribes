

$MissileDamageType     = 12;

// $HeatIncrease[$MissileDamageType] = 0; 

BulletData SniperBullet
{
bulletShapeName = "bullet.dts";
explosionTag = bulletExp0;
mass = 1.05;
bulletHoleIndex = 0;
damageClass = 0;
damageValue = 1.0;
damageType = $MissileDamageType;
aimDeflection = 0;
muzzleVelocity = 2000.0;
totalTime = 10.5;
inheritedVelocityScale = 2.0;
isVisible = true;
tracerPercentage = 1.0;
tracerLength = 30;
}; 
