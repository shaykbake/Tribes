


$DamageScale[Scout, $MissileDamageType] = 1.0; 
$DamageScale[LAPC, $MissileDamageType] = 1.0; 
$DamageScale[HAPC, $MissileDamageType] = 1.0; 
