

$InvList[MortarTurretPack] = 1;
$RemoteInvList[MortarTurretPack] = 1;
