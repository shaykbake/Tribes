

$ItemClass = 4;
$Item = SniperRifle;
$qty = 1;
MiniMod::Build::Classes();

$ItemClass = 4;
$Item = SniperBullets;
$qty = 20;
MiniMod::Build::Classes();

$ItemClass = 5;
$Item = SniperBullets;
$qty = 40;
MiniMod::Build::Classes();

$ItemClass = 6;
$Item = SniperBullets;
$qty = 60;
MiniMod::Build::Classes();

// Now setup the Damage Classes.

$DamageClass = 0;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 60;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 61;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 62;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 63;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 64;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 65;
$WeaponDamageType = $MissileDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();



