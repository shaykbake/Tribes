


$deathMsg[$MissileDamageType, 0]	       = "%1 says WHAT. %2 looked like %3 armor needed some vents.";
$deathMsg[$MissileDamageType, 1]	       = "Watch out for falling bullets."; 
$deathMsg[$MissileDamageType, 2]	       = "%1 Smacked %2 Ass.";
$deathMsg[$MissileDamageType, 3]	       = "Thats a shame.";
