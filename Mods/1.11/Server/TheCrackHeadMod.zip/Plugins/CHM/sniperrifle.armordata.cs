

$DamageScale[larmor, $MissileDamageType] = 1.6; 
$ItemMax[larmor, SniperRifle] = 1; 
$ItemMax[larmor, SniperBullets] = 20; 
$DamageScale[marmor, $MissileDamageType] = 1.6; 
$ItemMax[marmor, SniperRifle] = 0; 
$ItemMax[marmor, SniperBullets] = 40; 
$DamageScale[harmor, $MissileDamageType] = 1.4; 
$ItemMax[harmor, SniperRifle] = 0; 
$ItemMax[harmor, SniperBullets] = 60; 
$DamageScale[lfemale, $MissileDamageType] = 1.6; 
$ItemMax[lfemale, SniperRifle] = 1; 
$ItemMax[lfemale, SniperBullets] = 25; 
$DamageScale[mfemale, $MissileDamageType] = 1.5; 
$ItemMax[mfemale, SniperRifle] = 0; 
$ItemMax[mfemale, SniperBullets] = 40; 
$DamageScale[ulfemale, $MissileDamageType] = 1.9; 
$ItemMax[ulfemale, SniperRifle] = 1; 
$ItemMax[ulfemale, SniperBullets] = 10;
$DamageScale[ularmor, $MissileDamageType] = 1.9; 
$ItemMax[ularmor, SniperRifle] = 1; 
$ItemMax[ularmor, SniperBullets] = 10;
