

$ItemMax[larmor, MortarTurretPack] = 0;
$ItemMax[lfemale, MortarTurretPack] = 0;
$ItemMax[marmor, MortarTurretPack] = 1;
$ItemMax[mfemale, MortarTurretPack] = 1;
$ItemMax[harmor, MortarTurretPack] = 1;
$ItemMax[sarmor, MortarTurretPack] = 0;
$ItemMax[sfemale, MortarTurretPack] = 1;
$ItemMax[spyarmor, MortarTurretPack] = 0;
$ItemMax[spyfemale, MortarTurretPack] = 0;
$ItemMax[barmor, MortarTurretPack] = 0;
$ItemMax[bfemale, MortarTurretPack] = 0;
$ItemMax[earmor, MortarTurretPack] = 1;
$ItemMax[efemale, MortarTurretPack] = 1;
$ItemMax[aarmor, MortarTurretPack] = 0;
$ItemMax[afemale, MortarTurretPack] = 0;
$ItemMax[darmor, MortarTurretPack] = 1;
$ItemMax[tarmor, MortarTurretPack] = 0;
$ItemMax[scvarmor, MortarTurretPack] = 0;
