

TurretData DeployablePlasmaTurret
{
	className = "Turret";
	shapeFile = "hellfiregun";
        projectileType = fusionbolt;
	maxDamage = 1.0;
        maxEnergy = 200;
        minGunEnergy = 75;
        maxGunEnergy = 6;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
        reloadDelay = 0.5;
	speed = 2.0;
	speedModifier = 2.0;
        range = 90;
 
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = defaultDebrisMedium;
	shieldShapeName = "shield_medium";
        fireSound = SoundPlasmaTurretFire;
	activationSound = SoundPlasmaTurretOn;
	deactivateSound = SoundPlasmaTurretOff;
	explosionId = LargeShockwave;
        description = "Remote Plasma Turret";
	damageSkinData = "objectDamageSkins";
};

function DeployablePlasmaTurret::onAdd(%this)
{
        schedule("DeployablePlasmaTurret::deploy(" @ %this @ ");",1,%this);
        GameBase::setRechargeRate(%this,10);
        %this.shieldStrength = 0.01;
	if (GameBase::getMapName(%this) == "") {
                GameBase::setMapName (%this, "Remote Plasma Turret");
	}
}

function DeployablePlasmaTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function DeployablePlasmaTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function DeployablePlasmaTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
        $TeamItemCount[GameBase::getTeam(%this) @ "PlasmaTurretPack"]--;
}

// Override base class just in case.
function DeployablePlasmaTurret::onPower(%this,%power,%generator) {}
function DeployablePlasmaTurret::onEnabled(%this) 
{
        GameBase::setRechargeRate(%this,10);
	GameBase::setActive(%this,true);
}	


