

for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ MortarTurretPack] = 0;
}
