// To install this plugin just...
// Add:
//
//    ChainTurret.ArmorData.cs
//    ChainTurret.baseProjData.cs
//    ChainTurret.item.cs
//    ChainTurret.reinitData.cs
//    ChainTurret.station.cs
//    ChainTurret.turret.cs
//
// to your MiniMod/plugins directory.

$ItemMax[larmor, ChaingunTurretPack] = 0;
$ItemMax[lfemale, ChaingunTurretPack] = 0;
$ItemMax[marmor, ChaingunTurretPack] = 1;
$ItemMax[mfemale, ChaingunTurretPack] = 1;
$ItemMax[harmor, ChaingunTurretPack] = 1;
$ItemMax[sarmor, ChaingunTurretPack] = 0;
$ItemMax[sfemale, ChaingunTurretPack] = 0;
$ItemMax[spyarmor, ChaingunTurretPack] = 0;
$ItemMax[spyfemale, ChaingunTurretPack] = 0;
$ItemMax[barmor, ChaingunTurretPack] = 0;
$ItemMax[bfemale, ChaingunTurretPack] = 0;
$ItemMax[earmor, ChaingunTurretPack] = 1;
$ItemMax[efemale, ChaingunTurretPack] = 1;
$ItemMax[aarmor, ChaingunTurretPack] = 0;
$ItemMax[afemale, ChaingunTurretPack] = 0;
$ItemMax[darmor, ChaingunTurretPack] = 1;
$ItemMax[tarmor, ChaingunTurretPack] = 0;
$ItemMax[scvarmor, ChaingunTurretPack] = 0;
