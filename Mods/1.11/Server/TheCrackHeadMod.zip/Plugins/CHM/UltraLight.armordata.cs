


$ArmorType[Male, UlArmor] = Ularmor;
$ArmorType[Female, UlArmor] = Ulfemale;

$ArmorName[Ularmor] = UlArmor;
$ArmorName[Ulfemale] = UlArmor;

$MaxWeapons[Ularmor] = 3;
$MaxWeapons[Ulfemale] = 9;

ItemData UlArmor
{
   heading = "aArmor";
        description = "Ultra Light";
        className = "Armor";
        price = 3250;
};
$DamageScale[Ularmor, $LandingDamageType] = 1.0;
$DamageScale[Ularmor, $ImpactDamageType] = 1.0;
$DamageScale[Ularmor, $CrushDamageType] = 1.0;
$DamageScale[Ularmor, $BulletDamageType] = 1.0;
$DamageScale[Ularmor, $PlasmaDamageType] = 1.0;
$DamageScale[Ularmor, $EnergyDamageType] = 1.0;
$DamageScale[Ularmor, $ExplosionDamageType] = 1.0;
$DamageScale[Ularmor, $MissileDamageType] = 1.0;
$DamageScale[Ularmor, $ShrapnelDamageType] = 1.0;
$DamageScale[Ularmor, $DebrisDamageType] = 1.0;
$DamageScale[Ularmor, $LaserDamageType] = 1.0;
$DamageScale[Ularmor, $MortarDamageType] = 1.0;
$DamageScale[Ularmor, $BlasterDamageType] = 1.0;
$DamageScale[Ularmor, $ElectricityDamageType] = 1.0;
$DamageScale[Ularmor, $MineDamageType] = 1.0;


$DamageScale[Ulfemale, $LandingDamageType] = 1.0;
$DamageScale[Ulfemale, $ImpactDamageType] = 1.0;
$DamageScale[Ulfemale, $CrushDamageType] = 1.0;
$DamageScale[Ulfemale, $BulletDamageType] = 1.0;
$DamageScale[Ulfemale, $EnergyDamageType] = 1.0;
$DamageScale[Ulfemale, $PlasmaDamageType] = 1.0;
$DamageScale[Ulfemale, $ExplosionDamageType] = 1.0;
$DamageScale[Ulfemale, $MissileDamageType] = 1.0;
$DamageScale[Ulfemale, $ShrapnelDamageType] = 1.0;
$DamageScale[Ulfemale, $DebrisDamageType] = 1.0;
$DamageScale[Ulfemale, $LaserDamageType] = 1.0;
$DamageScale[Ulfemale, $MortarDamageType] = 1.0;
$DamageScale[Ulfemale, $BlasterDamageType] = 1.0;
$DamageScale[Ulfemale, $ElectricityDamageType] = 1.0;
$DamageScale[Ulfemale, $MineDamageType] = 1.0;

$ItemMax[Ularmor, Blaster] = 1;
$ItemMax[Ularmor, Chaingun] = 1;
$ItemMax[Ularmor, Disclauncher] = 1;
$ItemMax[Ularmor, GrenadeLauncher] = 1;
$ItemMax[Ularmor, Mortar] = 0;
$ItemMax[Ularmor, PlasmaGun] = 1;
$ItemMax[Ularmor, LaserRifle] = 1;
$ItemMax[Ularmor, EnergyRifle] = 1;
$ItemMax[Ularmor, TargetingLaser] = 1;
$ItemMax[Ularmor, MineAmmo] = 3;
$ItemMax[Ularmor, Grenade] = 5;
$ItemMax[Ularmor, Beacon] = 3;

$ItemMax[Ularmor, BulletAmmo] = 100;
$ItemMax[Ularmor, PlasmaAmmo] = 30;
$ItemMax[Ularmor, DiscAmmo] = 15;
$ItemMax[Ularmor, GrenadeAmmo] = 10;
$ItemMax[Ularmor, MortarAmmo] = 10;

$ItemMax[Ularmor, EnergyPack] = 1;
$ItemMax[Ularmor, RepairPack] = 1;
$ItemMax[Ularmor, ShieldPack] = 1;
$ItemMax[Ularmor, SensorJammerPack] = 1;
$ItemMax[Ularmor, MotionSensorPack] = 1;
$ItemMax[Ularmor, PulseSensorPack] = 1;
$ItemMax[Ularmor, DeployableSensorJammerPack] = 1;
$ItemMax[Ularmor, CameraPack] = 1;
$ItemMax[Ularmor, TurretPack] = 0;
$ItemMax[Ularmor, AmmoPack] = 1;
$ItemMax[Ularmor, RepairKit] = 1;
$ItemMax[Ularmor, DeployableInvPack] = 0;
$ItemMax[Ularmor, DeployableAmmoPack] = 0;

$ItemMax[Ulfemale, Blaster] = 1;
$ItemMax[Ulfemale, Chaingun] = 1;
$ItemMax[Ulfemale, Disclauncher] = 1;
$ItemMax[Ulfemale, GrenadeLauncher] = 1;
$ItemMax[Ulfemale, Mortar] = 0;
$ItemMax[Ulfemale, PlasmaGun] = 1;
$ItemMax[Ulfemale, LaserRifle] = 1;
$ItemMax[Ulfemale, EnergyRifle] = 1;
$ItemMax[Ulfemale, TargetingLaser] = 1;
$ItemMax[Ulfemale, MineAmmo] = 3;
$ItemMax[Ulfemale, Grenade] = 5;
$ItemMax[Ulfemale, Beacon] = 3;

$ItemMax[Ulfemale, BulletAmmo] = 100;
$ItemMax[Ulfemale, PlasmaAmmo] = 30;
$ItemMax[Ulfemale, DiscAmmo] = 15;
$ItemMax[Ulfemale, GrenadeAmmo] = 10;
$ItemMax[Ulfemale, MortarAmmo] = 10;

$ItemMax[Ulfemale, EnergyPack] = 1;
$ItemMax[Ulfemale, RepairPack] = 1;
$ItemMax[Ulfemale, ShieldPack] = 1;
$ItemMax[Ulfemale, SensorJammerPack] = 1;
$ItemMax[Ulfemale, MotionSensorPack] = 1;
$ItemMax[Ulfemale, PulseSensorPack] = 1;
$ItemMax[Ulfemale, DeployableSensorJammerPack] = 1;
$ItemMax[Ulfemale, CameraPack] = 1;
$ItemMax[Ulfemale, TurretPack] = 0;
$ItemMax[Ulfemale, AmmoPack] = 1;
$ItemMax[Ulfemale, RepairKit] = 1;
$ItemMax[Ulfemale, DeployableInvPack] = 0;
$ItemMax[Ulfemale, DeployableAmmoPack] = 0;




PlayerData Ularmor
{
   className = "Armor";
   shapeFile = "larmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
        debrisId = playerDebris;
   shadowDetailMask = 1;

   canCrouch = true;
   visibleToSensor = True;
        mapFilter = 1;
        mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 425;
   jetEnergyDrain = 0;

        maxDamage = 1.0;
   maxForwardSpeed = 8.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 6.0;
   groundTraction = 2.0;


        maxEnergy = 9990;
   drag = 1.0;
   density = 1.5;

        minDamageSpeed = 25;
        damageScale = 0.005;

   jumpImpulse = 160;
   jumpSurfaceMinDot = 0.2;


   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };

   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
        animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 };

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

        // Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds =
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  };
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};


PlayerData Ulfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
        debrisId = playerDebris;
   shadowDetailMask = 1;

   visibleToSensor = True;
        mapFilter = 1;
        mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 17;
   minJetEnergy = 1;
   jetForce = 325;
   jetEnergyDrain = 0;

   canCrouch = true;
        maxDamage = 1.0;
   maxForwardSpeed = 14.0;
   maxBackwardSpeed = 7.0;
   maxSideSpeed = 7.0;
   groundForce = 35 * 13.0;
   mass = 6.0;
   groundTraction = 3.0;

        maxEnergy = 9990;
   mass = 6.0;
   drag = 1.0;
   density = 1.5;

        minDamageSpeed = 25;
        damageScale = 0.005;

   jumpImpulse = 165;
   jumpSurfaceMinDot = 0.2;

     // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };

   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
        animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 };

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

        // Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds =
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  };
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};
