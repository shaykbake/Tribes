

%cnt = %cnt + AmmoStation::resupply(%player,SniperRifle,SniperBullets,10); 

