

$InvList[SniperRifle] = 1; 
$InvList[SniperBullets] = 1; 
$RemoteInvList[SniperRifle] = 1; 
$RemoteInvList[SniperBullets] = 1; 
