

TurretData DeployableIndoorTurret
{
	className = "Turret";
	shapeFile = "indoorgun";
        projectileType = shotgunbolt;
	maxDamage = 2.5;
        maxEnergy = 60;
        minGunEnergy =20;
        maxGunEnergy = 6;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
        reloadDelay = 0.4;
	speed = 5.0;
	speedModifier = 1.0;
        range = 25;
 
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = defaultDebrisMedium;
	shieldShapeName = "shield";
        fireSound = SoundEnergyTurretFire;
	activationSound = SoundEnergyTurretOn;
	deactivateSound = SoundEnergyTurretOff;
	explosionId = LargeShockwave;
        description = "Remote Indoor Turret";
	damageSkinData = "objectDamageSkins";
};

function DeployableIndoorTurret::onAdd(%this)
{
        schedule("DeployableIndoorTurret::deploy(" @ %this @ ");",1,%this);
        GameBase::setRechargeRate(%this,10);
        %this.shieldStrength = 0.01;
	if (GameBase::getMapName(%this) == "") {
                GameBase::setMapName (%this, "Remote Indoor Turret");
	}
}

function DeployableIndoorTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function DeployableIndoorTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function DeployableIndoorTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
        $TeamItemCount[GameBase::getTeam(%this) @ "IndoorTurretPack"]--;
}

// Override base class just in case.
function DeployableIndoorTurret::onPower(%this,%power,%generator) {}
function DeployableIndoorTurret::onEnabled(%this) 
{
        GameBase::setRechargeRate(%this,10);
	GameBase::setActive(%this,true);
}	


