

$ItemMax[larmor, PlasmaTurretPack] = 0;
$ItemMax[lfemale, PlasmaTurretPack] = 0;
$ItemMax[marmor, PlasmaTurretPack] = 1;
$ItemMax[mfemale, PlasmaTurretPack] = 1;
$ItemMax[harmor, PlasmaTurretPack] = 1;
$ItemMax[sarmor, PlasmaTurretPack] = 0;
$ItemMax[sfemale, PlasmaTurretPack] = 0;
$ItemMax[spyarmor, PlasmaTurretPack] = 0;
$ItemMax[spyfemale, PlasmaTurretPack] = 0;
$ItemMax[barmor, PlasmaTurretPack] = 0;
$ItemMax[bfemale, PlasmaTurretPack] = 0;
$ItemMax[earmor, PlasmaTurretPack] = 1;
$ItemMax[efemale, PlasmaTurretPack] = 1;
$ItemMax[aarmor, PlasmaTurretPack] = 0;
$ItemMax[afemale, PlasmaTurretPack] = 0;
$ItemMax[darmor, PlasmaTurretPack] = 1;
$ItemMax[tarmor, PlasmaTurretPack] = 0;
$ItemMax[scvarmor, PlasmaTurretPack] = 0;
