
$AutoUse[SniperRifle] = True; 
$SellAmmo[SniperBullets] = 80; 
$AmmoPackMax[SniperBullets] = 40; 
$AmmoPackItems[12] = SniperBullets; 
$WeaponAmmo[SniperRifle] = SniperBullets; 

MiniMod::WeaponCycle(Blaster, SniperRifle, PlasmaGun);

function SniperRifle::Fire::Volley(%trans,%player,%vel)
{
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
        Projectile::spawnProjectile("SniperBullet",%trans,%player,%vel);
}

ItemData SniperBullets
{
description = "Sniper Bullets";
className = "Ammo";
shapeFile = "ammo2";
heading = "xAmmunition";
shadowDetailMask = 4;
price = 220;
}; 

function SniperRifleImage::onFire(%player, %slot)
{
	%AmmoCount = Player::getItemCount(%player, $WeaponAmmo[SniperRifle]);
	Player::decItemCount(%player,$WeaponAmmo[SniperRifle],1);
	if(%AmmoCount != 1)
		{
		%trans = GameBase::getMuzzleTransform(%player);
		%vel = Item::getVelocity(%player); 
                SniperRifle::Fire::Volley(%trans,%player,%vel);
                return;
		}
	else
	{
        SniperRifle::Fire::Volley(%trans,%player,%vel);
        if(%AmmoCount == 1)
             {
             SniperRifle::Fire::Volley(%trans,%player,%vel);
             remoteNextWeapon(%player);
             }
        }
}

SoundData SoundFireSniperRifle
{
wavFileName = "mine_exp.wav"; profile = Profile3dNear;
};

ItemImageData SniperRifleImage
{
shapeFile = "sniper";
mountPoint = 0;
weaponType = 0;
ammoType = SniperBullets;
reloadTime =1.1;
accuFire = true;
fireTime = 0.01;
sfxFire = SoundFireSniperRifle;
sfxActivate = SoundPickUpWeapon;
sfxReload = SoundPickUpWeapon; //SoundMortarReload;
sfxReady = SoundPickUpWeapon;
};

ItemData SniperRifle
{
heading = "wCHM Stuff";
description = "Sniper Rifle";
className = "Weapon";
shapeFile = "sniper";
hudIcon = "ammopack";
shadowDetailMask = 4;
imageType = SniperRifleImage;
price = 785;
showWeaponBar = true;
};

