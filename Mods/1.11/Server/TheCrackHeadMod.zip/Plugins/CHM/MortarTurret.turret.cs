

TurretData DeployableMortarTurret
{
	className = "Turret";
	shapeFile = "mortar_turret";
        projectileType = mortarturretshell;
	maxDamage = 1.0;
        maxEnergy = 45;
        minGunEnergy = 45;
        maxGunEnergy = 100;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
        reloadDelay = 2.0;
	speed = 2.0;
	speedModifier = 2.0;
        range = 0;
 
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = defaultDebrisMedium;
	shieldShapeName = "shield_medium";
        fireSound = SoundMortarTurretFire;
	activationSound = SoundMortarTurretOn;
	deactivateSound = SoundMortarTurretOff;
	explosionId = LargeShockwave;
        description = "Remote Mortar Turret";
	damageSkinData = "objectDamageSkins";
};

function DeployableMortarTurret::onAdd(%this)
{
        schedule("DeployableMortarTurret::deploy(" @ %this @ ");",1,%this);
        GameBase::setRechargeRate(%this,10);
        %this.shieldStrength = 0.01;
	if (GameBase::getMapName(%this) == "") {
                GameBase::setMapName (%this, "Remote Mortar Turret");
	}
}

function DeployableMortarTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function DeployableMortarTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function DeployableMortarTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
        $TeamItemCount[GameBase::getTeam(%this) @ "MortarTurretPack"]--;
}

// Override base class just in case.
function DeployableMortarTurret::onPower(%this,%power,%generator) {}
function DeployableMortarTurret::onEnabled(%this) 
{
        GameBase::setRechargeRate(%this,10);
	GameBase::setActive(%this,true);
}	


