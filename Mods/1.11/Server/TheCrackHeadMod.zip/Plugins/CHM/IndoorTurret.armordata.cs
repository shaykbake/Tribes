

$ItemMax[larmor, IndoorTurretPack] = 1;
$ItemMax[lfemale, IndoorTurretPack] = 1;
$ItemMax[marmor, IndoorTurretPack] = 1;
$ItemMax[mfemale, IndoorTurretPack] = 1;
$ItemMax[harmor, IndoorTurretPack] = 1;
$ItemMax[sarmor, IndoorTurretPack] = 0;
$ItemMax[sfemale, IndoorTurretPack] = 1;
$ItemMax[spyarmor, IndoorTurretPack] = 0;
$ItemMax[spyfemale, IndoorTurretPack] = 0;
$ItemMax[barmor, IndoorTurretPack] = 0;
$ItemMax[bfemale, IndoorTurretPack] = 0;
$ItemMax[earmor, IndoorTurretPack] = 1;
$ItemMax[efemale, IndoorTurretPack] = 1;
$ItemMax[aarmor, IndoorTurretPack] = 0;
$ItemMax[afemale, IndoorTurretPack] = 0;
$ItemMax[darmor, IndoorTurretPack] = 1;
$ItemMax[tarmor, IndoorTurretPack] = 0;
$ItemMax[scvarmor, IndoorTurretPack] = 0;
