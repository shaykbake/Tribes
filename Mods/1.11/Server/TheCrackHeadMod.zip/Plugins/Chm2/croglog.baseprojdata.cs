
RocketData croglogTurret
{
   bulletShapeName  = "fusionbolt.dts";
   explosionTag     = mortarExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 1;
   damageType       = $flameDamageType;

   explosionRadius  = 3.5;
   kickBackStrength = 500.0;

   muzzleVelocity   = 90.0;
   terminalVelocity = 80.0;
   acceleration     = 4.0;
   totalTime        = 20.0;
   liveTime         = 21.0;
   lightRange       = 19.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;                // smoke trail
   trailString = "plasmabolt.dts";
   smokeDist   = 2.8;

   soundId = SoundJetHeavy;
};

