

$DamageScale[larmor, $MissileDamageType] = 1.1; 
$DamageScale[lfemale, $MissileDamageType] = 1.1;  
$DamageScale[marmor, $MissileDamageType] = 0.8; 
$DamageScale[mfemale, $MissileDamageType] = 0.8; 
$DamageScale[harmor, $MissileDamageType] = 0.6; 

$DamageScale[sarmor, $MissileDamageType] = 1.0; 
$DamageScale[sfemale, $MissileDamageType] = 1.0; 
$DamageScale[spyarmor, $MissileDamageType] = 1.0; 
$DamageScale[spyfemale, $MissileDamageType] = 1.0; 
$DamageScale[barmor, $MissileDamageType] = 1.0; 
$DamageScale[bfemale, $MissileDamageType] = 1.0; 
$DamageScale[earmor, $MissileDamageType] = 1.0; 
$DamageScale[efemale, $MissileDamageType] = 1.0; 
$DamageScale[aarmor, $MissileDamageType] = 1.0; 
$DamageScale[afemale, $MissileDamageType] = 1.0;
$DamageScale[darmor, $MissileDamageType] = 1.0;
$DamageScale[ularmor, $MissileDamageType] = 1.0;
$DamageScale[ulfemale, $MissileDamageType] = 1.0;


$ItemMax[larmor, cheeselauncher] = 0;
$ItemMax[lfemale, cheeselauncher] = 0;
$ItemMax[marmor, cheeselauncher] = 1;
$ItemMax[mfemale, cheeselauncher] = 1;
$ItemMax[harmor, cheeselauncher] = 1;

$ItemMax[sarmor, cheeselauncher] = 0;
$ItemMax[sfemale, cheeselauncher] = 0;
$ItemMax[spyarmor, cheeselauncher] = 0;
$ItemMax[spyfemale, cheeselauncher] = 0;
$ItemMax[barmor, cheeselauncher] = 0;
$ItemMax[bfemale, cheeselauncher] = 0;
$ItemMax[earmor, cheeselauncher] = 1;
$ItemMax[efemale, cheeselauncher] = 1;
$ItemMax[aarmor, cheeselauncher] = 0;
$ItemMax[afemale, cheeselauncher] = 0;
$ItemMax[darmor, cheeselauncher] = 1;

