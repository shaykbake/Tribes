

$cheeselauncherDamageType = 21;

BulletData cheeselauncherBlast
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = cheeselauncherExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 3.45;
   damageType         = $cheeselauncherDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 55.0;
   totalTime          = 6.0;
   liveTime           = 4.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

