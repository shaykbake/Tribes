

$InvList[cheeselauncher] = 1;
$RemoteInvList[cheeselauncher] = 1;
