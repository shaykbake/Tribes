

TurretData croglogDeployableTurret
{
	className = "Turret";
	shapeFile = "remoteturret";
	projectileType = croglogTurret;
	maxDamage = 5;
	maxEnergy = 40;
	minGunEnergy = 6;
	maxGunEnergy = 5;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	reloadDelay = 3;
	speed = 5.0;
	speedModifier = 1.5;
	range = 50;
	visibleToSensor = true;
	shadowDetailMask = 4;
	supressable = false;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	fireSound = SoundFireMortar;
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
	description = "CrogLog Turret";
	damageSkinData = "objectDamageSkins";
};

function croglogDeployableTurret::onAdd(%this)
{
	schedule("croglogDeployableTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,5);
	%this.shieldStrength = 0.012;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Croglog Turret");
	}
}

function croglogDeployableTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function croglogDeployableTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function croglogDeployableTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "croglogTurretPack"]--;
}

// Override base class just in case.
function croglogDeployableTurret::onPower(%this,%power,%generator) {}
function croglogDeployableTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,5);
	GameBase::setActive(%this,true);
}	



