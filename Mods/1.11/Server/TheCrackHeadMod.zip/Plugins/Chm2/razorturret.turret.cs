

TurretData Deployablerazor
{
	className = "Turret";
	shapeFile = "remoteturret";
        projectileType = disc;
	maxDamage = 0.45;
        maxEnergy = 30;
        minGunEnergy = 5;
        maxGunEnergy = 1;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
        reloadDelay = 4.0;
	speed = 6.0;
	speedModifier = 2.0;
        range = 25;
 
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield_medium";
        fireSound = SoundMissileTurretFire;
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
        description = "The-Crack-Head-Mod HTTP://chm.50megs.com/";
	damageSkinData = "objectDamageSkins";
};

function Deployablerazor::onAdd(%this)
{
        schedule("Deployablerazor::deploy(" @ %this @ ");",1,%this);
        GameBase::setRechargeRate(%this,10);
        %this.shieldStrength = 0.01;
	if (GameBase::getMapName(%this) == "") {
                GameBase::setMapName (%this, "Remote Razor Turret");
	}
}

function Deployablerazor::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function Deployablerazor::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function Deployablerazor::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
        $TeamItemCount[GameBase::getTeam(%this) @ "razorTurretPack"]--;
}

// Override base class just in case.
function Deployablerazor::onPower(%this,%power,%generator) {}
function Deployablerazor::onEnabled(%this) 
{
        GameBase::setRechargeRate(%this,10);
	GameBase::setActive(%this,true);
}	


