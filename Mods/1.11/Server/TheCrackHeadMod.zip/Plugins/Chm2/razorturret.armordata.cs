

$ItemMax[larmor, razorTurretPack] = 0;
$ItemMax[lfemale, razorTurretPack] = 0;
$ItemMax[marmor, razorTurretPack] = 1;
$ItemMax[mfemale, razorTurretPack] = 1;
$ItemMax[harmor, razorTurretPack] = 1;
$ItemMax[sarmor, razorTurretPack] = 0;
$ItemMax[sfemale, razorTurretPack] = 0;
$ItemMax[spyarmor, razorTurretPack] = 0;
$ItemMax[spyfemale, razorTurretPack] = 0;
$ItemMax[barmor, razorTurretPack] = 0;
$ItemMax[bfemale, razorTurretPack] = 0;
$ItemMax[earmor, razorTurretPack] = 1;
$ItemMax[efemale, razorTurretPack] = 1;
$ItemMax[aarmor, razorTurretPack] = 0;
$ItemMax[afemale, razorTurretPack] = 0;
$ItemMax[darmor, razorTurretPack] = 1;
$ItemMax[tarmor, razorTurretPack] = 0;
$ItemMax[scvarmor, razorTurretPack] = 0;
$ItemMax[larmor, razorTurretPack] = 1;
$ItemMax[lfemale, razorTurretPack] = 1;
