

$InvList[razorTurretPack] = 1;
$RemoteInvList[razorTurretPack] = 0;
