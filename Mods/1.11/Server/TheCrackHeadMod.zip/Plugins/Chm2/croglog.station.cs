

$InvList[croglogTurretPack] = 1;
$RemoteInvList[croglogTurretPack] = 1;
