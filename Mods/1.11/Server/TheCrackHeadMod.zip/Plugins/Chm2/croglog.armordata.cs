

$DamageScale[larmor, $FlameDamageType] = 0.1;
$DamageScale[lfemale, $FlameDamageType] = 0.1;
$DamageScale[marmor, $FlameDamageType] = 0.1;
$DamageScale[mfemale, $FlameDamageType] = 0.1;
$DamageScale[harmor, $FlameDamageType] = 0.1;
$DamageScale[sarmor, $FlameDamageType] = 0.1;
$DamageScale[sfemale, $FlameDamageType] = 0.1;
$DamageScale[spyarmor, $FlameDamageType] = 0.1;
$DamageScale[spyfemale, $FlameDamageType] = 0.1;
$DamageScale[barmor, $FlameDamageType] = 0.1;
$DamageScale[bfemale, $FlameDamageType] = 0.1;
$DamageScale[earmor, $FlameDamageType] = 0.1;
$DamageScale[efemale, $FlameDamageType] = 0.1;
$DamageScale[aarmor, $FlameDamageType] = 0;
$DamageScale[afemale, $FlameDamageType] = 0;
$DamageScale[barmor, $FlameDamageType] = 0;
$DamageScale[bfemale, $FlameDamageType] = 0;
$DamageScale[darmor, $FlameDamageType] = 0.1;
$DamageScale[tarmor, $FlameDamageType] = 0.1;
$DamageScale[scvarmor, $FlameDamageType] = 0.1;
$DamageScale[ularmor, $FlameDamageType] = 0.1;
$DamageScale[ulfemale, $FlameDamageType] = 0.1;


$ItemMax[larmor, croglogTurretPack] = 0;
$ItemMax[lfemale, croglogTurretPack] = 0;
$ItemMax[marmor, croglogTurretPack] = 0;
$ItemMax[mfemale, croglogTurretPack] = 1;
$ItemMax[harmor, croglogTurretPack] = 1;
$ItemMax[sarmor, croglogTurretPack] = 0;
$ItemMax[sfemale, croglogTurretPack] = 0;
$ItemMax[spyarmor, croglogTurretPack] = 0;
$ItemMax[spyfemale, croglogTurretPack] = 0;
$ItemMax[barmor, croglogTurretPack] = 0;
$ItemMax[bfemale, croglogTurretPack] = 0;
$ItemMax[earmor, croglogTurretPack] = 1;
$ItemMax[efemale, croglogTurretPack] = 1;
$ItemMax[aarmor, croglogTurretPack] = 0;
$ItemMax[afemale, croglogTurretPack] = 0;
$ItemMax[darmor, croglogTurretPack] = 0;
$ItemMax[tarmor, croglogTurretPack] = 0;
$ItemMax[scvarmor, croglogTurretPack] = 0; 
$ItemMax[ularmor, croglogTurretPack] = 1;
$ItemMax[ulfemale, croglogTurretPack] = 1;
