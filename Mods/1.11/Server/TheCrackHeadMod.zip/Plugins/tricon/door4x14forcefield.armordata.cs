///-----------------------------------------------
/// description = "Door 4x14 Force Field Door";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[sarmor, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[barmor, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[harmor, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[darmor, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[marmor, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[mfemale, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[earmor, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[efemale, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[lfemale, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[sfemale, doorfourbyfourteenForceFieldPack] = 1;
$ItemMax[bfemale, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[spyarmor, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[spyfemale, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[adarmor, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[sadarmor, doorfourbyfourteenForceFieldPack] = 0;
$ItemMax[parmor, doorfourbyfourteenForceFieldPack] = 0;