///-----------------------------------------------
/// Description - "Accelerator pad";
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
/// Original Idea ripped from Z-Tek
/// http://216.169.122.124/Z-Tek
///-----------------------------------------------

$ItemMax[larmor, AccelPPack] = 1;
$ItemMax[sarmor, AccelPPack] = 1;
$ItemMax[barmor, AccelPPack] = 0;
$ItemMax[harmor, AccelPPack] = 0;
$ItemMax[darmor, AccelPPack] = 0;
$ItemMax[marmor, AccelPPack] = 1;
$ItemMax[mfemale, AccelPPack] = 1;
$ItemMax[earmor, AccelPPack] = 1;
$ItemMax[efemale, AccelPPack] = 1;
$ItemMax[lfemale, AccelPPack] = 1;
$ItemMax[sfemale, AccelPPack] = 1;
$ItemMax[bfemale, AccelPPack] = 0;
$ItemMax[spyarmor, AccelPPack] = 0;
$ItemMax[spyfemale, AccelPPack] = 0;
$ItemMax[adarmor, AccelPPack] = 0;
$ItemMax[sadarmor, AccelPPack] = 0;
$ItemMax[parmor, AccelPPack] = 0;