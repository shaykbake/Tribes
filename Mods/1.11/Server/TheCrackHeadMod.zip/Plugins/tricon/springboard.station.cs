///-----------------------------------------------
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[SpringPack] = 1;
$RemoteInvList[SpringPack] = 1;








