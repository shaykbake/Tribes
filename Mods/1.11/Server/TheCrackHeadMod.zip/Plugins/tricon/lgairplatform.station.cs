///-----------------------------------------------
/// description = "Air Large Platform";
/// MiniMod Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[LargeAirPlatPack] = 1;
$RemoteInvList[LargeAirPlatPack] = 1;