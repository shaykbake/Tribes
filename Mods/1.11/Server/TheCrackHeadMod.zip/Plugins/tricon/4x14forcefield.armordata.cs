///-----------------------------------------------
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$ItemMax[larmor, fourbyfourteenForceFieldPack] = 1;
$ItemMax[sarmor, fourbyfourteenForceFieldPack] = 1;
$ItemMax[barmor, fourbyfourteenForceFieldPack] = 0;
$ItemMax[harmor, fourbyfourteenForceFieldPack] = 0;
$ItemMax[darmor, fourbyfourteenForceFieldPack] = 0;
$ItemMax[marmor, fourbyfourteenForceFieldPack] = 1;
$ItemMax[mfemale, fourbyfourteenForceFieldPack] = 1;
$ItemMax[earmor, fourbyfourteenForceFieldPack] = 1;
$ItemMax[efemale, fourbyfourteenForceFieldPack] = 1;
$ItemMax[lfemale, fourbyfourteenForceFieldPack] = 1;
$ItemMax[sfemale, fourbyfourteenForceFieldPack] = 1;
$ItemMax[bfemale, fourbyfourteenForceFieldPack] = 0;
$ItemMax[spyarmor, fourbyfourteenForceFieldPack] = 0;
$ItemMax[spyfemale, fourbyfourteenForceFieldPack] = 0;
$ItemMax[adarmor, fourbyfourteenForceFieldPack] = 0;
$ItemMax[sadarmor, fourbyfourteenForceFieldPack] = 0;
$ItemMax[parmor, fourbyfourteenForceFieldPack] = 0;