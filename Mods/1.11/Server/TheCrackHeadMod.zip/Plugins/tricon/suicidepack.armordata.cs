///-----------------------------------------------
/// description = "Suicide DetPack";
/// Plugin Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------



$ItemMax[larmor, SuicidePack] = 1;
$ItemMax[sarmor, SuicidePack] = 0;
$ItemMax[barmor, SuicidePack] = 1;
$ItemMax[harmor, SuicidePack] = 0;
$ItemMax[darmor, SuicidePack] = 0;
$ItemMax[marmor, SuicidePack] = 0;
$ItemMax[mfemale, SuicidePack] = 0;
$ItemMax[earmor, SuicidePack] = 1;
$ItemMax[efemale, SuicidePack] = 0;
$ItemMax[lfemale, SuicidePack] = 0;
$ItemMax[sfemale, SuicidePack] = 0;
$ItemMax[bfemale, SuicidePack] = 1;
$ItemMax[spyarmor, SuicidePack] = 0;
$ItemMax[spyfemale, SuicidePack] = 0;
$ItemMax[adarmor, SuicidePack] = 1;
$ItemMax[sadarmor, SuicidePack] = 1;
$ItemMax[parmor, SuicidePack] = 0;