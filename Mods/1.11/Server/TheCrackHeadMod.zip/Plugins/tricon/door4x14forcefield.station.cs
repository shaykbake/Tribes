///-----------------------------------------------
/// description = "4x14 Force Field Door";
/// Created by TriCon Team C3 & graphfx
/// http://www.planetstarsiege.com/tricon
///-----------------------------------------------

$InvList[doorfourbyfourteenForceFieldPack] = 1;
$RemoteInvList[doorfourbyfourteenForceFieldPack] = 1;