// This is a MiniMod plugin
// This is the Rail Turret From Ultra-Renegades.
// Code donated by URG_thrash, decompressed/ported by Dewy.

$ItemMax[larmor, RailTurret] = 0; 
$ItemMax[marmor, RailTurret] = 0; 
$ItemMax[harmor, RailTurret] = 1; 
$ItemMax[lfemale, RailTurret] = 0;
$ItemMax[mfemale, RailTurret] = 0; 
