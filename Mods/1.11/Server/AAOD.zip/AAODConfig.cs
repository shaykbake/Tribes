$Server::Address = "LOOPBACK:28001";
$Server::AutoAssignTeams = "true";
$Server::CurrentMaster = "0";
$Server::HostName = "AAOD Server";		// Your Server Name Here (Recommend you change this)
$Server::HostPublicGame = "true";		// Set to false if you dont want a public game.
$Server::Info = "Put a Description of Your Server Here.. \n The \n means new line\nAdmin: YourName\nEmail: YourEmail@yournet.com";

$AdminPassword="YourAdminPasswordgoesHere";

$Server::JoinMOTD = "<jc><f1>Welcome to a Dedicated AAOD Server\n** ** \n" \n\n\nFire to spawn.";

$Server::Master1 = "IP:tribes.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";
$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterName0 = "Tribes Master";
$Server::MaxPlayers = "6";				// Max Number of PLayers
$Server::MinVotes = "1";
$Server::MinVotesPct = "0.5";
$Server::MinVoteTime = "5";
$Server::Port = "28001";
$Server::TeamDamageScale = "1";
$Server::teamName0 = "Arch Angels of Death";
$Server::teamName1 = "Dragons Of Chaos";
$Server::teamName2 = "Children of the Phoenix";
$Server::teamName3 = "Starwolf";
$Server::teamName4 = "Generic 1";
$Server::teamName5 = "Generic 2";
$Server::teamName6 = "Generic 3";
$Server::teamName7 = "Generic 4";
$Server::teamSkin0 = "AAOD";		// Change these if you dont want to use the AAOD Skins
$Server::teamSkin1 = "DOC";			// Change these if you dont want to use the AAOD Skins
$Server::teamSkin2 = "cphoenix";
$Server::teamSkin3 = "swolf";
$Server::teamSkin4 = "base";
$Server::teamSkin5 = "base";
$Server::teamSkin6 = "base";
$Server::teamSkin7 = "base";
$Server::timeLimit = "15";
$Server::TourneyMode = "false";
$Server::VoteWinMargin = "0.699999";
$Server::VotingTime = "10";
$Server::warmupTime = "5";
$Server::XLMaster1 = "IP:198.74.38.23:28000";
$Server::XLMaster2 = "IP:Broadcast:28001";

$pref::lastMission = "RainDance"; // The mission the server will start on


