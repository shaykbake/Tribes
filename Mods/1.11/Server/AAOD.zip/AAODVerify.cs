function remoteSendPwd(%client)
{	echo("*** Authorizing Player Sending Password to Server");
	%pwd="BiteMe";
	remoteEval(2048,"SetPwd",%pwd);
}