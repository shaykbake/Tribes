/////////////////////////////////////////////////////
///      Basic Server File for Tantrum Mod       ///
////////////edit this to your liking///////////////

$Server::HostName = "Tribes Tantrum Server"; //name that shows up in server list
$Server::MaxPlayers = "8"; //MAX should be 8 for cable/DSL, 16 for T1, 32 for T3 or fatter pipe.
$Server::HostPublicGame = "True";
$Server::Info = "SERVERNAME\nAdmin: NAME (EMAIL)\nMod info: http://themaladroit.dgm3dengine.com"; 

//displays as the player connects to the server
$MODInfo = "\n<f0>:[ <f2>Tribes Tantrum <f0> ]:\n<f1>created by the maLadroiT\n<f1>Press '<f0>TAB<f1>' to select a Spawn Setup\n<f2>http://themaladroit.dgm3dengine.com";

//displays after they connect but before they join a team.
//MAXIMUM 71 CHARS PER MOTD STRING


$Server::Port = "28001";
$Server::Password = "";
$Server::TimeLimit = "15";
$Server::AutoAssignTeams = "True";
$Server::TourneyMode = "False";
$Server::TeamDamageScale = "0";
$Server::HostPublicGame = "True";
$AdminPassword = "anypasswordyouwouldlike"; <----------------------------change this
$Server::warmupTime = 0;
$Server::respawnTime = 1;
$Server::VotingTime = 15;
$Server::VoteWinMargin = 0.80;
$telnetport = "11111"; //change to something else
$telnetpassword = "anyotherpassyouwant";          <----------------------change this
$pref::PacketRate = "15"; //lower to 10 for modem players
$pref::PacketSize = "300"; //lower to 200 for modem players
$TCTimer = 10; //Teamchange timer: you cannot change teams again after a team change for x seconds
$VoteAdminAllowed = true; //vote admin function on or off

//Team names and skins
$Server::teamSkin0 = "beagle"; //Blood Eagle skins - red
$Server::teamName0 = "Blood Eagle"; //this name shows up in the score window
$Server::teamSkin1 = "dsword"; //use "green" if you don't have the football skins
$Server::teamName1 = "Diamond Sword"; //this name shows up in the score window

//Additional Code
$console::logmode=1; //set to 0 if you want NO LOG

//football missions only
exec(missionlist);
MissionList::clear();
Missionlist::initNextMission();
$pref::lastmission = "DangerousCrossing"; //first mission to launch when you startup

//Missionlist: order in reverse alphabetical here to make them alpha in the menu
MissionList::addMission("IceRidge");
MissionList::addMission("RollerCoaster");
MissionList::addMission("Stonehenge");
MissionList::addMission("SnowBlind");
MissionList::addMission("Blastside");
MissionList::addMission("Raindance");


//Rotation paradigm: $nextMission["CURRENT"] = "NEXT";
$nextMission["DangerousCrossing"] = "RollerCoaster";
$nextMission["RollerCoaster"] = "IceRidge";
$nextMission["IceRidge"] = "Stonehenge";
$nextMission["Stonehenge"] = "Blastside";
$nextMission["Blastside"] = "SnowBlind";
$nextMission["SnowBlind"] = "Raindance";
$nextMission["Raindance"] = "DangerousCrossing";
//last rotation map should always point back to the first.
