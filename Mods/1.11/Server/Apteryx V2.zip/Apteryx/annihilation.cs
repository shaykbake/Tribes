//===========================================================================================
//	Annihilation v2.1
//		IS NOW Apteryx
//	Coded By Sevnn and Plasmatic 2000, 2001, 2002.
//		and Crow 2003
//	Designed by the Annihilation Development Team:
//	Sevnn, Plasmatic, Scavenger, Raven, Auto, Monkey, Minuteman3, Whitehawk,
//	And all the others who donated their talent.
//
// Thank you 
// -Plasmatic
//
// www.annihilation.info
// www.clanorb.com
// www.adelphia.net/~mworhatch/Apteryx.html
//===========================================================================================
// Server Parameters
$Server::HostName = "Crow's Nest";	// Server Name
$Server::Port = "28001";					// Port used for client connections to server (usually 28001)
$Server::HostPublicGame = true;			// Server is shown in MasterServer List
$Server::Password = "";						// Password needed to join server
$AdminPassword = "";							// Local SuperAdmin password - CHANGE THIS
$pref::LastMission = "Raindance";		// This sets the first map in rotate when server launches (make sure it is spelled correctly)

//===========================================================================================
// Server Info Parameters (<jc> = center justified, <f1> = tan font, <f2> = white font, <f3> = orange font, \n = new line)
$Server::Info = "Apteryx v2";	// Server information listed on MasterServer List	
$Server::MODInfo = "<jc><f2>Apteryx - the world of flightless armors and armed fliers\nGo to users.adelphia.net/~mworhatch/Apteryx.html\n if you want to download the mod.";	// Information listed on server join screen
$Server::JoinMOTD = "<jc><f3>Welcome to Apteryx v2! Without powerful jets or snipers, this mod promotes strategy.\nIf you like this mod, you can download it at users.adelphia.net/~mworhatch/Apteryx.html";

//===========================================================================================
// Telnet (Console) Parameters
// If you want telnet access, set the port number to the desired port (23 is normal)
// BE SURE TO SET A PASSWORD THAT IS HARD TO GUESS
$TelnetPort="";								// Port for telnet connections
$TelnetPassword="";							// Password for telnet connections

//===========================================================================================
// Server Connection Parameters
$pref::PacketRate = 12;						// Packet rate for client connections
$pref::PacketSize = 200;					// Packet size for client connections

//===========================================================================================
// Annihilation Parameters
$Annihilation::NetMask = "IP:192.168";	// This is used to increase server player limit when local LAN players connect.
$Annihilation::IncreaseMax = true;		// If true, will increase player limit on server if IP of client connect matches NetMask.
$Annihilation::GiveLocalAdmin = true;	// If true, will give SuperAdmin status to players who are on the same machine as the server.
$Annihilation::ShoppingList = true;		// Set to true to limit item shopping list to display only items available for current armor.
$Annihilation::ResetServer = false;		// Set to true to rotate server to next map in list when last player leaves.
$Annihilation::KickTime = 180;			// Time (in seconds) for kicks.
$Annihilation::BanTime = 1800;			// Time (in seconds) for bans.
$Annihilation::StationTime = 200;		// Time allowed for Station Access.

//===========================================================================================
// Public Voting Parameters
$Annihilation::VoteAdmin = false;		// Allow Voting a Public Admin in.
$Annihilation::PVKick = true;				// Allow Public Kick Voting.
$Annihilation::PVChangeMission = true;	// Allow Public Mission Voting.
$Annihilation::PVTeamDamage = true;		// Allow Public Team Damage Voting.
$Annihilation::PVTourneyMode = true;	// Allow Public Tournament Mode Voting.
$Server::AdminMinVotes = 4;				// Minimum number of votes needed to vote admin
$Server::MinVotes = 1;						// Minimum number of votes needed to pass
$Server::MinVotesPct = 0.5;				// Percentage of available votes needed to pass a vote
$Server::MinVoteTime = 25;					// Time allotted for voting
$Server::VoteAdminWinMargin = 0.8;		// Ratio of Yes to No votes needed to pass
$Server::VoteFailTime = 30; 				// 30 seconds if your vote fails + $Server::MinVoteTime
$Server::VoteWinMargin = 0.6;				// Ratio of Yes to No votes needed to pass
$Server::VotingTime = 20;					// Length of votes if people are voting.

//===========================================================================================
// SuperAdmin Passwords, Up to 100 are available
$Annihilation::SADPassword[1] = "";
$Annihilation::SADPassword[2] = "";
$Annihilation::SADPassword[3] = "";
$Annihilation::SADPassword[4] = "";
$Annihilation::SADPassword[5] = "";
// SuperAdmin Parameters
$Annihilation::SADBan = 	true;				// Allow Super Admins to Ban.
$Annihilation::SADGiveAdmin = 	true;		// Allow Super Admins to Give Public Admin to other players.
$Annihilation::SADForceVote = 	true;		// Allow Super Admins to Force Votes to Pass/Fail.

//===========================================================================================
// Public Admin Passwords, Up to 100 are available
$Annihilation::PAPassword[1] = "";
$Annihilation::PAPassword[2] = "";
$Annihilation::PAPassword[3] = "";
$Annihilation::PAPassword[4] = "";
$Annihilation::PAPassword[5] = "";
// Public Admin Parameters
$Annihilation::PAKick = 	true;				// Allow Public Admins to Kick.
$Annihilation::PATeamChange = 	true;		// Allow Public Admins to Change other Players Teams.
$Annihilation::PAChangeMission= true;	// Allow Public Admins to Change the Mission.
$Annihilation::PATeamDamage = 	true;		// Allow Public Admins to Enable/Disable Team Damage.
$Annihilation::PATourneyMode = 	true;	// Allow Public Admins to Enable/Disable Tournament Mode.

//===========================================================================================
// Other Parameters
$Annihilation::AutoAdmin = true; 	
	// Uses the annihilationAdminList.cs in config, edit to your liking.

$Annihilation::ResetSettings = true;	// Resets server settings from this file on map change.

$Annihilation::FairTeams = true;			// Prevent team changing to the larger team

$Annihilation::UsePersonalSkin = true;	// Allows use of Personal Skins

$Annihilation::SafeBase = false;		
	// Base damage. True for safe (undestroyable) station and generators.

$Annihilation::BaseHeal = false;	
	// Base healing. True for regenerating (self healing) station and generators.

$Annihilation::VoteBuild = false;		// Allow voting on builder mode.

$Annihilation::obsAlert = true;		
	// Observer alert, notifies player who is watching them in observer.

$Annihilation::OutOfArea = false;		// Allow players out of bounds.

$Annihilation::QuickInv = false;		// inventory without stations
$Annihilation::ExtendedInvs = true;		// Extended Inventories, multiple use inventory stations.
$Annihilation::Zappy = true;	
	// uses electro beams to verify Extended Inventories aren't covered with blastwalls, force fields etc..

$IpLogger = true;	//logs names by ip to AnnInfo.cs, and much more.
//===========================================================================================
// Player Parameters
$Server::MaxPlayers = "10";				// Maximum number of client connections allowed
$Server::AutoAssignTeams = true;			// Server assigned teams
$Server::RespawnTime = 3; 					// Number of seconds before a respawn is allowed
$Server::TimeLimit = 30;					// Mission time limit in minutes
$Server::WarmupTime = 5;					// Time (in seconds) players are left standing before movement is allowed
$Server::TeamDamageScale = 0;				// Team damage, 0 = Off, 1 = On
$Server::TourneyMode = false;				// Tournament mode

//===========================================================================================
// Team Parameters
$Server::teamName[0] = "Crows";		// Team 1 Name
$Server::teamSkin[0] = "beagle";			// Team 1 Skin
$Server::teamName[1] = "Ravens";	// Team 2 Name
$Server::teamSkin[1] = "dsword";			// Team 2 Skin
$Server::teamName[2] = "Apteryxes";	// Team 3 Name
$Server::teamSkin[2] = "cphoenix";		// Team 3 Skin
$Server::teamName[3] = "Penguins";		// Team 4 Name
$Server::teamSkin[3] = "swolf";			// Team 4 Skin
$Server::teamName[4] = "Generic 1";		// Team 5 Name
$Server::teamSkin[4] = "base";			// Team 5 Skin
$Server::teamName[5] = "Generic 2";		// Team 6 Name
$Server::teamSkin[5] = "base";			// Team 6 Skin
$Server::teamName[6] = "Generic 3";		// Team 7 Name
$Server::teamSkin[6] = "base";			// Team 7 Skin
$Server::teamName[7] = "Generic 4";		// Team 8 Name
$Server::teamSkin[7] = "base";			// Team 8 Skin

//===========================================================================================
// Console Parameters
$Console::LogMode = "1"; 	// Log the console to a log file.