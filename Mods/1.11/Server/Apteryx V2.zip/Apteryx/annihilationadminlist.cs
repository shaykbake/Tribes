// Annihilation auto admin.

//The Actual User.
//$UserList::UserName[1] = "<UserName>";
//$UserList::UserMask[1] = "<AccessLevel> <IP Masks>";
//
//
//<UserName> 	= What is this Users Regular Name. 
//		 
//		
//
//<AccessLevel> 	= What Access do they have. Choices are:
//		  God		- Auto-God Admin status
//		  AutoSuper 	- Super Admin w/ Auto Admin. 
//		  AutoPublic 	- Public Admin, same as above w Auto Admin. 
//
//<IP Masks> 	= What IP or IPs you want to list for that user. you can list
//		  as many IPs as you want. the only wildcard accepted is * 
//		  For Example:
//			User's actual IP = 209.14.25.25
//			Successful IP Mask = 209.14.25.25 	-a good match for cable users, only exact ip
//			Successful IP Mask = 209.14.25.*	-most likely match for dial up users, and some cable/ dsl
//			Successful IP Mask = 209.14.*.*		-should work for all users, anyone with same isp could use same name
//		  When using the * that will allow any number for that part of the IP. 
//		  Please be aware of the consequences of using wildcards and autoadmin. 
//		  You may give a whole ISP control of your server, or even the whole Planet. 
// 		  Ip mask needs to be one word, with a space between additional ip's if needed.
//
// Example's

$UserList::MaxUsers = 5;	// TOTAL number of admin users

$UserList::UserName[1] = "Crow!";
$UserList::UserMask[1] = "God 68.169.*.*";

$UserList::UserName[2] = "RoboTek";
$UserList::UserMask[2] = "AutoSuper 208.58.*.*";

$UserList::UserName[3] = "Crow!";
$UserList::UserMask[3] = "God 00000000";

$UserList::UserName[4] = "{ST}sniper(Lt.)";
$UserList::UserMask[4] = "AutoPublic 134.84.*.*";

$UserList::UserName[5] = "Vince";
$UserList::UserMask[5] = "AutoSuper 216.231.*.*";