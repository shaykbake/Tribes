Thanx for downloading my mod, RavenStorm (Soon to be renamed)

It concentrates on the type of weapon you use, and how you use it.

Each armor issomewhat similiar, but has their own types of grenades/mines,
and a certain purpose for each, like the

Demolitions man porting the mortar but also being mobile, unlike the 
Normal Heavy Armored Goon.

INSTALLATION:

1) Create a folder called 'RavenStorm' in your Tribes directory, and DO NOT RENAME THE FOLDER!
2) Put EVERYTHING in this zip file into the RavenStorm folder (You can leave the readme file out)
3) Right click on Tribes.exe and create a shortcut
4) Right click on the shortcut and select 'properties'
5) Now, in a part called 'target' it shows the Tribes.exe's directory, at the end of the
message, type in " -mod RavenStorm"

6) Host the mod and enjoy!

-Timer