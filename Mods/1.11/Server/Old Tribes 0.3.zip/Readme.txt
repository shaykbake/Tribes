this is the OldTribes mod - (C)2000 by Tom Vogt <tom@lemuria.org>

this is version 0.3, released on April 19th, 2000


some code and ideas have been taken from shifter, professional and Tac/insomniax
if you take ideas from me, please give credit

for a full description of this mod, visit the website:

	http://www.tribes-universe.com/ot/


questions, ideas and feedback to: tom@ricardo.de
