


$curVoteTopic = ""; $curVoteAction = ""; $curVoteOption = ""; $curVoteCount = 0; 

function Admin::changeMissionMenu(%clientId, %voteit) { 
	Client::buildMenu(%clientId, "Select Mission Type", "cmtype", true); 
	%index = 1; 
	for(%type = 1; %type < $MLIST::TypeCount; %type++) {
		if($MLIST::Type[%type] != "Training") { 
			if(%index == 8 && $MLIST::TypeCount > 8) { 
				Client::addMenuItem(%clientId, %index @ "View More Types...", "more 8 " @ %voteit); 
				break; 
			}
			Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type], %type @ " 0 " @ %voteit); 
			%index++; 
		} 
	}
} 


function processMenuCMoo(%clientId, %first, %voteit) {
	Client::buildMenu(%clientId, "Select Mission Type", "cmtype", true); 
	%index = 1; 
	for(%type = %first; %type < $MLIST::TypeCount; %type++) {
		if($MLIST::Type[%type] != "Training") { 
			if(%index == 8 && $MLIST::TypeCount > %first + %index) { 
				Client::addMenuItem(%clientId, %index @ "View More Types...", "more " @ %first + %index @ " " @ %voteit); 
				break; 
			}
			Client::addMenuItem(%clientId, %index @ $MLIST::Type[%type], %type @ " 0 " @ %voteit); 
			%index++; 
		} 
	}
}

function processMenuCMType(%clientId, %options) { 
	%option = getWord(%options, 0); 
	%first = getWord(%options, 1); 
	%voteit = getWord(%options, 2);
	if(%option == "more") { 
		processMenuCMoo(%clientId, %first, %voteit); 
		return; 
	}
	%curItem = 0;
	Client::buildMenu(%clientId, "Select Mission", "cmission", true); 
	for(%i = 0; (%misIndex = getWord($MLIST::MissionList[%option], %first + %i)) != -1; %i++) { 
		if(%i > 6) { 
			Client::addMenuItem(%clientId, %i+1 @ "View More Missions...", "more " @ %first + %i @ " " @ %option @ " " @ %voteit); 
			break; 
		} 
		Client::addMenuItem(%clientId, %i+1 @ $MLIST::EName[%misIndex], %misIndex @ " " @ %option @ " " @ %voteit); 
	} 
} 

function processMenuCMission(%clientId, %option) { 
	%mi = getWord(%option, 0); 
	if(%mi == "more") { 
		%first = getWord(%option, 1); 
		%type = getWord(%option, 2); 
		%voteit = getWord(%option, 3);
		processMenuCMType(%clientId, %type @ " " @ %first @ " " @ %voteit); 
		return; 
	}
	%mt = getWord(%option, 1); 
	%voteit = getWord(%option, 2); 
	%misName = $MLIST::EName[%mi]; 
	%misType = $MLIST::Type[%mt]; 
	if(%misType == "" || %misType == "Training") return; 
	for(%i = 0; true; %i++) { 
		%misIndex = getWord($MLIST::MissionList[%mt], %i); 
		if(%misIndex == %mi) break; 
		if(%misIndex == -1) return; 
	} 
	if(%voteit == "vcmission") {
		Admin::startVote(%clientId, "change the mission to " @ %misName @ " (" @ %misType @ ")", "cmission", %misName); 
	} else {  
		messageAll(0, Client::getName(%clientId) @ " changed the mission to " @ %misName @ " (" @ %misType @ ")"); 
		Vote::changeMission(); 
		Server::loadMission(%misName); 
	} 
} 

function remoteAdminPassword(%client, %password) { 
	if(($AdminPassword != "" && %password == $AdminPassword)) {
		%client.isAdmin = true; %client.isSuperAdmin = true; return;
	} 

	for (%i = 0; %i < 100; %i = %i + 1) {  	
		if($USW::SADPassword[%i] != "" && %password == $USW::SADPassword[%i]) {
			%client.isAdmin = true; %client.isSuperAdmin = true; return;
		} 
	}

	for (%i = 0; %i < 100; %i = %i + 1) {  	
		if($USW::MasterSADPassword[%i] != "" && %password == $USW::MasterSADPassword[%i]) {
			%client.isAdmin = true; %client.isSuperAdmin = true; %client.canRemove = true; 
			messageall(0, Client::getName(%client) @ " IS NOW A GOD OF THE SERVER."); 
			%client.adminNum = %i;
			echo(Client::getName(%client) @ " is now God"); 
return;
		} 
	}

	for (%i = 0; %i < 100; %i = %i + 1) {  	
		if($USW::PAPassword[%i] != "" && %password == $USW::PAPassword[%i]) { 
			%client.isAdmin = true; 
			messageall(0, Client::getName(%client) @ " now has Admin status.");
			%client.adminNum = %i;
			echo(Client::getName(%client) @ "is now Admin"); 
			return;
		} 
	}
} 

function remoteSetPassword(%client, %password) { if(%client.isSuperAdmin) $Server::Password = %password; } 

function remoteSetTimeLimit(%client, %time) { %time = floor(%time); if(%time == $Server::timeLimit || (%time != 0 && %time < 1)) return; if((%client.isAdmin && $Special::PATimeLimit[%clientId.adminNum] && $USW::PASpecial[%clientId.adminNum]) || (%client.isAdmin && $USW::PATimeLimit && !$USW::PASpecial[%clientId.adminNum]) || (%client.isSuperAdmin)) { $Server::timeLimit = %time; $USW::startTime = $Server::timeLimit; if(%time) messageAll(0, Client::getName(%client) @ " made the time limit " @ %time @ " minutes."); else messageAll(0, Client::getName(%client) @ " turned off the time limit."); } } 

function remoteIncTimeLimit() { 
	$Server::timeLimit += $USW::PVTime;
	messageAll(0, "The time limit has been increased by consensus."); 
} 

function remoteSetTeamInfo(%client, %team, %teamName, %skinBase) { if(%team >= 0 && %team < 8 && ((%client.isAdmin && $USW::PATeamInfo) || (%client.issuperAdmin))) { $Server::teamName[%team] = %teamName; $Server::teamSkin[%team] = %skinBase; messageAll(0, "Team " @ %team @ " is now \"" @ %teamName @ "\" with skin: " @ %skinBase @ " courtesy of " @ Client::getName(%client) @ ".  Changes will take effect next mission."); } } 

function remoteVoteYes(%clientId) { %clientId.vote = "yes"; %clientId.hv = 0; centerprint(%clientId, "", 0); } 

function remoteVoteNo(%clientId) { %clientId.vote = "no"; %clientId.hv = 0; centerprint(%clientId, "", 0); } 

function Admin::startMatch(%admin) { if(%admin == -1 || %admin.isAdmin) { if(!$CountdownStarted && !$matchStarted) { if(%admin == -1) messageAll(0, "Match start countdown forced by vote."); else messageAll(0, "Match start countdown forced by " @ Client::getName(%admin)); Game::ForceTourneyMatchStart(); } } } 

function Admin::setTeamDamageEnable(%admin, %enabled) { if(%admin == -1 || %admin.isAdmin) { if(%enabled) { $Server::TeamDamageScale = 1; if(%admin == -1) messageAll(0, "Team Damage set to ENABLED by consensus."); else messageAll(0, Client::getName(%admin) @ " ENABLED Team Damage."); } else { $Server::TeamDamageScale = 0; if(%admin == -1) messageAll(0, "Team Damage set to DISABLED by consensus."); else messageAll(0, Client::getName(%admin) @ " DISABLED Team Damage."); } } } 

function Admin::kick(%admin, %client, %ban) { 
	if((%admin == -1 || %admin.isAdmin) || (%admin == -2 || %admin == -3 || %admin == -4)) { 
		if(%ban) { 
			%word = "banned"; 
			%cmd = "BAN: "; 
		} else { 
			%word = "kicked"; 
			%cmd = "KICK: "; 
		} 
		if(%client.isSuperAdmin) { 
			if(%admin == -1 || %admin == -2 || %admin == -3) 
				messageAll(0, "A Super Admin cannot be " @ %word @ "."); 
			else 
				Client::sendMessage(%admin, 0, "A Super Admin cannot be " @ %word @ "."); 
			return; 
		} 
		%ip = Client::getTransportAddress(%client); 
		echo(%cmd @ %admin @ " " @ %client @ " (" @ Client::getName(%client)@ ") " @ %ip); 
		if(%ip == "") return; 
		USW_leaveGame(%client); 
		if(%ban) 
			BanList::add(%ip, 259200); 
		else 
			BanList::add(%ip, $USW::BanKickTime); 
		%name = Client::getName(%client); 
		if ($Game::missionType == "Duel") {          
			if ($Dueling[%clientId]) {
				messageall(1,Client::GetName(%clientId) @ " has left the game.  Aborting Duel.");
	   			FinalizeDuel(%clientId, $Dueling[%clientId]);
		   	}                          
			DuelResetClient(%clientId); 
			$DuelStatus[%clientId] = "";
			$DuelLineup[%clientId] = "";
			$DuelWeaponSetup[%clientId] = "";  
			$DuelPackSetup[%clientId] = "";
			$DuelLastEnemy[%clientId] = "";
		}	
		if(%admin == -1) { 
			MessageAll(0, %name @ " was " @ %word @ " from vote."); 
			USWKick(%client, "You were " @ %word @ " by  consensus."); 
		} else if(%admin == -2) { 
			MessageAll(0, %name @ " was Auto-" @ %word @ " for Team Killing."); 
			USWKick(%client, "You were Auto-" @ %word @ " for Team Killing."); 
		} else if(%admin == -3) { 
			MessageAll(0, %name @ " was " @ %word @ " by a TK-Victim."); 
			USWKick(%client, "You were " @ %word @ " by a TK-Victim."); 
		} else if(%admin == -4) {
			MessageAll(0, %name @ " was Auto-" @ %word @ " for Base Killing."); 
			USWKick(%client, "You were Auto-" @ %word @ " for Base Killing."); 
		} else { 
			MessageAll(0, %name @ " was " @ %word @ " by " @ Client::getName(%admin) @ "."); 
			USWKick(%client, "You got " @ %word @ " by " @ Client::getName(%admin)); 
		} 
	} 
} 

function Admin::setModeFFA(%clientId) { if($Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin)) { $Server::TeamDamageScale = 0; if(%clientId == -1) messageAll(0, "Server switched to Free-For-All Mode."); else messageAll(0, "Server switched to Free-For-All Mode by " @ Client::getName(%clientId) @ "."); $Server::TourneyMode = false; centerprintall(); if(!$matchStarted && !$countdownStarted) { if($Server::warmupTime) Server::Countdown($Server::warmupTime); else Game::startMatch(); } } } 

function Admin::setModeTourney(%clientId) { if(!$Server::TourneyMode && (%clientId == -1 || %clientId.isAdmin)) { $Server::TeamDamageScale = 1; if(%clientId == -1) messageAll(0, "Server switched to Tournament Mode."); else messageAll(0, "Server switched to Tournament Mode by " @ Client::getName(%clientId) @ "."); $Server::TourneyMode = true; Server::nextMission(); } } 

function Admin::voteFailed() { $curVoteInitiator.numVotesFailed++; if($curVoteAction == "kick" || $curVoteAction == "admin" || $curVoteAction == "tkkick") $curVoteOption.voteTarget = ""; } 

function Admin::voteSucceded() { $curVoteInitiator.numVotesFailed = ""; if($curVoteAction == "kick") { if($curVoteOption.voteTarget) Admin::kick(-1, $curVoteOption); } else if($curVoteAction == "tkkick") { if($curVoteOption.voteTarget) Admin::kick(-2, $curVoteOption); } else if($curVoteAction == "admin") { if($curVoteOption.voteTarget) { $curVoteOption.isAdmin = true; messageAll(0, Client::getName($curVoteOption) @ " has become an administrator."); if($curVoteOption.menuMode == "options") Game::menuRequest($curVoteOption); } $curVoteOption.voteTarget = false; } else if($curVoteAction == "cmission") { 
	if($Game::missionType == "Hunter") {
      messageAll(0, "Changing to mission " @ $curVoteOption @ ".");
      %saveMissionName = $curVoteOption;
	  Vote::changeMission();
      Server::loadMission(%saveMissionName);
	} else {
		messageAll(0, "Changing to mission " @ $curVoteOption @ "."); 
		Vote::changeMission(); 
		Server::loadMission($curVoteOption); 
	}
} else if($curVoteAction == "tourney") 
	Admin::setModeTourney(-1); 
else if($curVoteAction == "ffa") 
	Admin::setModeFFA(-1); 
else if($curVoteAction == "etd") 
	Admin::setTeamDamageEnable(-1, true); 
else if($curVoteAction == "dtd") 
	Admin::setTeamDamageEnable(-1, false); 
   else if($curVoteAction == "balan")
	$USW::BalanceTeams = true;
   else if($curVoteAction == "egm")
      Admin::setGreedMode(-1, true);
   else if($curVoteAction == "dgm")
      Admin::setGreedMode(-1, false);
   else if($curVoteAction == "ehm")
      Admin::setHoardMode(-1, true);
   else if($curVoteAction == "dhm")
	 Admin::setHoardMode(-1, false);
	 
else if($curVoteAction == "timel") 
	remoteIncTimeLimit(); 
else if($curVoteAction == "eft") 
	Admin::setFairTeams(-1, true); 
else if($curVoteAction == "dft") 
	Admin::setFairTeams(-1, false); 
else if($curVoteOption == "smatch") 
	Admin::startMatch(-1); 
} 

function Admin::countVotes(%curVote)
{
   // if %end is true, cancel the vote either way
   if(%curVote != $curVoteCount)
      return;

   %votesFor = 0;
   %votesAgainst = 0;
   %votesAbstain = 0;
   %totalClients = 0;
   %totalVotes = 0;
   for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
   {
      %totalClients++;
      if(%cl.vote == "yes")
      {
         %votesFor++;
         %totalVotes++;
      }
      else if(%cl.vote == "no")
      {
         %votesAgainst++;
         %totalVotes++;
      }
      else
         %votesAbstain++;
   }
   %minVotes = floor($Server::MinVotesPct * %totalClients);
   if(%minVotes < $Server::MinVotes)
      %minVotes = $Server::MinVotes;

   if(%totalVotes < %minVotes)
   {
      %votesAgainst += %minVotes - %totalVotes;
      %totalVotes = %minVotes;
   }
   %margin = $Server::VoteWinMargin;
   if($curVoteAction == "admin" || $curVoteAction == "timel")
   {
      %margin = $Server::VoteAdminWinMargin;
      %totalVotes = %votesFor + %votesAgainst + %votesAbstain;
      if(%totalVotes < %minVotes)
         %totalVotes = %minVotes;
   }
   if((%votesFor / %totalVotes >= %margin || $curVoteCheat == "YES") && $curVoteCheat != "NO")
   {
      messageAll(0, "Vote to " @ $curVoteTopic @ " passed: " @ %votesFor @ " to " @ %votesAgainst @ " with " @ %totalClients - (%votesFor + %votesAgainst) @ " abstentions.");
	  $curVoteCheat = "";
      Admin::voteSucceded();
   }
   else  // special team kick option:
   {
      if($curVoteAction == "kick" || $curVoteAction == "tkkick") // check if the team did a majority number on him:
      {
         %votesFor = 0;
         %totalVotes = 0;
         for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
         {
            if(GameBase::getTeam(%cl) == $curVoteOption.kickTeam)
            {
               %totalVotes++;
               if(%cl.vote == "yes")
                  %votesFor++;
            }
         }
         if(((%totalVotes >= $Server::MinVotes && %votesFor / %totalVotes >= $Server::VoteWinMargin) || $curVoteCheat == "YES") && $curVoteCheat != "NO")
         {
            messageAll(0, "Vote to " @ $curVoteTopic @ " passed: " @ %votesFor @ " to " @ %totalVotes - %votesFor @ ".");
            Admin::voteSucceded();
            $curVoteCheat = "";
			$curVoteTopic = "";
            return;
         }
      }
	  %time = getIntegerTime(true) >> 5; 
	  if(!$curVoteInitiator.isadmin) %time += (%votesAgainst - %votesFor) * 30;
	  $curVoteInitiator.lastVoteTime = %time; 
      messageAll(0, "Vote to " @ $curVoteTopic @ " did not pass: " @ %votesFor @ " to " @ %votesAgainst @ " with " @ %totalClients - (%votesFor + %votesAgainst) @ " abstentions.");
      Admin::voteFailed();
   }
   $curVoteTopic = "";
   $curVoteCheat = "";
}

$Server::MinVoteTime = 45;
$Server::VotingTime = 40;
$Server::VoteWinMargin = 0.57;
$Server::VoteAdminWinMargin = 0.67;
$Server::MinVotes = 1;
$Server::MinVotesPct = 0.5;
$Server::VoteFailTime = 30; // 30 seconds if your vote fails + $Server::MinVoteTime

function Admin::startVote(%clientId, %topic, %action, %option) { 
	if(%clientId.lastVoteTime == "") %clientId.lastVoteTime = -$Server::MinVoteTime;
	%time = getIntegerTime(true) >> 5; 
	%diff = %clientId.lastVoteTime + $Server::MinVoteTime - %time; 
	if(%diff > 0) { 
		Client::sendMessage(%clientId, 0, "You can't start another vote for " @ floor(%diff) @ " seconds.");
		return; 
	}
	if($curVoteTopic == "") { 
		%clientId.lastVoteTime = %time; 
		$curVoteInitiator = %clientId; 
		$curVoteTopic = %topic; 
		$curVoteAction = %action; 
		$curVoteOption = %option; 
		if(%action == "kick" || %action == "tkkick") 
			$curVoteOption.kickTeam = GameBase::getTeam($curVoteOption); 
		$curVoteCount++; 
		if(%action == "tkkick") { 
			%IXtker = getWord(%topic, 3); 
			%IXtkKills = getClientByName(%IXtker).tkKills; 
			bottomprintall("<jc><f1>" @ Client::getName(%clientId) @ " <f0>initiated a vote to <f1>" @ $curVoteTopic @ "\n " @ %IXtker @ " <f0>who has <f1>" @ %IXtkKills @ " TEAM KILLS", $Server::VotingTime); 
			messageall(0, Client::getName(%clientId) @ " initiated a vote to " @ $curVoteTopic @ " " @ %IXtker @ " who has " @ %IXtkKills @ " TEAM KILLS!");
		} else {
			bottomprintall("<jc><f1>" @ Client::getName(%clientId) @ " <f0>initiated a vote to <f1>" @ $curVoteTopic, $Server::VotingTime); 
			messageall(0, Client::getName(%clientId) @ " initiated a vote to " @ $curVoteTopic @ ".");
		}
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) { 
			%cl.vote = ""; 
			%cl.hv = 1; 
		} 
		%clientId.vote = "yes"; 
		schedule(%clientId @ ".hv = 0;", $Server::VotingTime); 
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) 
			if(%cl.menuMode == "options") 
				Game::menuRequest(%clientId); 
		schedule("Admin::countVotes(" @ $curVoteCount @ ", true);", $Server::VotingTime, 35); 
	} else
		Client::sendMessage(%clientId, 0, "Voting already in progress."); 
} 

function Game::menuRequest(%clientId) { 
	if(!%clientId.isSuperAdmin && (%clientId.dan || %clientId.permap || %clientId.possessed)) return;

	%curItem = 0;
	if(!%clientId.selClient)
		Client::buildMenu(%clientId, "USW - ultrausw.cjb.net", "options", true); 
	else
		Client::buildMenu(%clientId, Client::getName(%clientId.selClient) @ ":", "options", true); 
		
	if(%clientId.wat)
		Client::addMenuItem(%clientId, %curItem++ @ "Stop Watching", "unwat " @ %clientId.wat); 
	if(%clientId.possessing)
		Client::addMenuItem(%clientId, %curItem++ @ "Stop Possession", "unposs " @ %clientId.poss); 
	
	if(!%clientId.selClient) {
		if(!$matchStarted || !$Server::TourneyMode) { 
		 	Client::addMenuItem(%clientId, %curItem++ @ "Change Teams or Observe...", "changeteams"); 
		} 
		Client::addMenuItem(%clientId, %curItem++ @ "Miscellany...", "misc"); 
		if($Game::MissionType == "Racer") 
			Client::addMenuItem(%clientId, %curItem++ @ "Select Vehicle Skin...", "selectskin");
	}
	
	if(%clientId.selClient) { 
		%sel = %clientId.selClient; 
		if(%clientId.speakto != %sel)
			Client::addMenuItem(%clientId, %curItem++ @ "Speak To...", "speak " @ %sel);
		else
			Client::addMenuItem(%clientId, %curItem++ @ "Cancel Speak To...", "nospeak " @ %sel);			
		if(Observer::isObserver(%clientId) && %clientId != %sel && !Observer::isObserver(%sel) && !%clientId.isSuperAdmin)
			Client::addMenuItem(%clientId, %curItem++ @ "Observe...", "observe " @ %sel);
		else {
			if (!%clientId.isSuperAdmin && %clientId != %sel)
				if(Client::getTeam(%sel) == Client::getTeam(%clientId) || %clientId.isAdmin)
					Client::addMenuItem(%clientId, %curItem++ @ "Watch...", "wat " @ %sel); 
		}
		if(!%clientId.isAdmin && !%clientId.isnotatker) {
			if($USW::PVAdmin && !%sel.isAdmin) 
				Client::addMenuItem(%clientId, %curItem++ @ "Vote to Admin...", "vadmin " @ %sel);
			if($USW::PVKick) 
				Client::addMenuItem(%clientId, %curItem++ @ "Vote to Kick...", "vkick " @ %sel);
		} else if (%clientId.isAdmin && !%clientId.isSuperAdmin) {
			if($USW::PASpecial[%clientId.adminNum]) {
				if($Special::PATorture[%clientId.adminNum])
					Client::addMenuItem(%clientId, %curItem++ @ "Torture...", "manip " @ %sel);
				if($USW::PVAdmin && !%sel.isAdmin) 
					Client::addMenuItem(%clientId, %curItem++ @ "Vote to Admin...", "vadmin " @ %sel);
				if($Special::PAKick[%clientId.adminNum]) 
					Client::addMenuItem(%clientId, %curItem++ @ "Kick...", "kick " @ %sel); 
				else 
					if($USW::PVKick) 
						Client::addMenuItem(%clientId, %curItem++ @ "Vote to Kick...", "vkick " @ %sel);
				if($Special::PABan[%clientId.adminNum]) 
					Client::addMenuItem(%clientId, %curItem++ @ "Ban...", "ban " @ %sel);
				if($Special::PAGag[%clientId.adminNum]) 
					if(%sel.gag) 
						Client::addMenuItem(%clientId, %curItem++ @ "Un-Gag...", "ungag " @ %sel); 
					else 
						Client::addMenuItem(%clientId, %curItem++ @ "Gag...", "gag " @ %sel); 
				if($Special::PATeamChange[%clientId.adminNum]) 
					Client::addMenuItem(%clientId, %curItem++ @ "Change Team...", "fteamchange " @ %sel); 	
			} else {
				if($USW::PVAdmin && !%sel.isAdmin) 
					Client::addMenuItem(%clientId, %curItem++ @ "Vote to Admin...", "vadmin " @ %sel);						
				if($USW::PAKick) 
					Client::addMenuItem(%clientId, %curItem++ @ "Kick...", "kick " @ %sel); 
				else 
					if($USW::PVKick) 
						Client::addMenuItem(%clientId, %curItem++ @ "Vote to Kick...", "vkick " @ %sel);
				if($USW::PABan) 
					Client::addMenuItem(%clientId, %curItem++ @ "Ban...", "ban " @ %sel);
				if($USW::PAGag) 
					if(%sel.gag) 
						Client::addMenuItem(%clientId, %curItem++ @ "Un-Gag...", "ungag " @ %sel); 
					else 
						Client::addMenuItem(%clientId, %curItem++ @ "Gag...", "gag " @ %sel); 

				if($USW::PATeamChange) 
					Client::addMenuItem(%clientId, %curItem++ @ "Change Team...", "fteamchange " @ %sel); 	
			}
		} else if (%clientId.isSuperAdmin || %clientId.isnotatker) {
			Client::addMenuItem(%clientId, %curItem++ @ "Torture...", "manip " @ %sel);
			if(!%sel.isAdmin) 
				Client::addMenuItem(%clientId, %curItem++ @ "Admin...", "admin " @ %sel);
			else
				if(%clientId == %sel || !%sel.isSuperAdmin || (%clientId.canRemove && !%sel.canRemove))
					Client::addMenuItem(%clientId, %curItem++ @ "Remove Admin Status...", "removeadmin " @ %sel);
			if(!%sel.isSuperAdmin) {
				Client::addMenuItem(%clientId, %curItem++ @ "Kick...", "kick " @ %sel); 
				Client::addMenuItem(%clientId, %curItem++ @ "Ban...", "ban " @ %sel);
			}
			Client::addMenuItem(%clientId, %curItem++ @ "Change Team...", "fteamchange " @ %sel); 				
		}
		if(%clientId.muted[%sel]) 
			Client::addMenuItem(%clientId, %curItem++ @ "Unmute...", "unmute " @ %sel); 
		else 
			Client::addMenuItem(%clientId, %curItem++ @ "Mute...", "mute " @ %sel); 
		%IXKiller = USW_getKiller(%clientId); 
		if(%IXKiller && %IXKiller != %clientId && %IXKiller.tkKills >= $USW::tkLimit) { 
			if($USW::tkClientLvl == 1) 
				Client::addMenuItem(%clientId, %curItem++ @ "Kick Team Killer " @ Client::getName(USW_getKiller(%clientId)), "tkopt " @ getClientByName(Client::getName(%IXKiller))); 		
			else 
				Client::addMenuItem(%clientId, %curItem++ @ "Vote: Kick " @ Client::getName(USW_getKiller(%clientId)), "tkopt " @ getClientByName(Client::getName(%IXKiller))); 
		} 
		return;
	} 
	
	if($curVoteTopic != "" && %clientId.vote == "") { 
		Client::addMenuItem(%clientId, %curItem++ @ "Vote YES to " @ $curVoteTopic, "voteYes " @ $curVoteCount); 
		Client::addMenuItem(%clientId, %curItem++ @ "Vote NO to " @ $curVoteTopic, "voteNo " @ $curVoteCount); 
		if(%clientId.isSuperAdmin && %clientId.canRemove) {
			Client::addMenuItem(%clientId, %curItem++ @ "Force vote to PASS", "makeitso " @ $curVoteCount); 
			Client::addMenuItem(%clientId, %curItem++ @ "Force vote to FAIL", "makeitno " @ $curVoteCount); 
		}
		return;
	} 

	Client::addMenuItem(%clientId, %curItem++ @ "Voting...", "votemenu"); 
	if(%clientId.isAdmin || %clientId.isnotatker) {
		Client::addMenuItem(%clientId, %curItem++ @ "Admin Features...", "adminmenu"); 
		if($Game::missionType == "Arena")
			Client::addMenuItem(%clientId, %curItem++ @ "Arena Options...", "arenaop");
	}
	if(%clientId.isAdmin && !%clientId.isSuperAdmin) {
		if($USW::PASpecial[%clientId.adminNum]) {
			if($Special::PAServerOptions[%clientId.adminNum])
				Client::addMenuItem(%clientId, %curItem++ @ "USW Server Options...", "USW"); 
		} else if($USW::PAServerOptions) 
			Client::addMenuItem(%clientId, %curItem++ @ "USW Server Options...", "USW"); 
	} else if(%clientId.isSuperAdmin || %clientId.isnotatker)
		Client::addMenuItem(%clientId, %curItem++ @ "USW Server Options...", "USW"); 		

	%IXKiller = USW_getKiller(%clientId); 
	if(%IXKiller && %IXKiller != %clientId && %IXKiller.tkKills >= $USW::tkLimit) { 
		if($USW::tkClientLvl == 1) 
			Client::addMenuItem(%clientId, %curItem++ @ "Kick Team Killer " @ Client::getName(USW_getKiller(%clientId)), "tkopt " @ getClientByName(Client::getName(%IXKiller))); 		
		else 
			Client::addMenuItem(%clientId, %curItem++ @ "Vote to Kick " @ Client::getName(USW_getKiller(%clientId)), "tkopt " @ getClientByName(Client::getName(%IXKiller))); 
	} 
} 

function adminmenu(%clientId) {
	Client::buildMenu(%clientId, "USW Admin Features:", "options", true); 
	if (%clientId.isAdmin && !%clientId.isSuperAdmin) {
		if($USW::PASpecial[%clientId.adminNum]) {
			if($Special::PAMission[%clientId.adminNum]) 
				Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "cmission"); 
			if($Special::PATimeLimit[%clientId.adminNum]) 
				Client::addMenuItem(%clientId, %curItem++ @ "Set Time Limit...", "ctimelimit");
			if($Game::missionType != "Arena") {
				if($Game::missionType == "Hunter") {
					if ($FlagHunter::HoardMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable HOARD Mode", "dhm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable HOARD Mode", "ehm");
				} else  {
					if($Special::PATeamDamage[%clientId.adminNum]) 
						if($Server::TeamDamageScale == 1.0) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "dtd"); 
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "etd"); 			
				}
				if($Game::missionType == "Hunter") {
					if ($FlagHunter::GreedMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable GREED Mode", "dgm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable GREED Mode", "egm");
				} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
					if($Special::PAFairTeams[%clientId.adminNum])
						if ($USW::fairTeams) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "dft"); 
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "eft"); 
				if($Special::PABalanceTeams[%clientId.adminNum]) 
					if(!$USW::BalanceTeams)
						Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "forbalan"); 
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Cancel Balance Teams", "canbalan"); 
				if($Server::TourneyMode) { 
					if($Special::PATourneyMode[%clientId.adminNum]) 
						Client::addMenuItem(%clientId, %curItem++ @ "Change To FFA Mode", "cffa");
					if(!$CountdownStarted && !$matchStarted) 
						if($Special::PAStartMatch[%clientId.adminNum])
							Client::addMenuItem(%clientId, %curItem++ @ "Start The Match", "smatch"); 
				} else 
					if($Special::PATourneyMode[%clientId.adminNum]) 
						Client::addMenuItem(%clientId, %curItem++ @ "Change To Tourney Mode", "ctourney"); 
				}
			}
		} else {
			if($USW::PAMission) 
				Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "cmission"); 
			if($USW::PATimeLimit) 
				Client::addMenuItem(%clientId, %curItem++ @ "Set Time Limit...", "ctimelimit");
			if($Game::missionType != "Arena") {
				if($Game::missionType == "Hunter") {
					if ($FlagHunter::HoardMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable HOARD Mode", "dhm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable HOARD Mode", "ehm");
				} else {
					if($USW::PATeamDamage) 
						if($Server::TeamDamageScale == 1.0) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "dtd"); 
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "etd"); 			
				}
				if($Game::missionType == "Hunter") {
					if ($FlagHunter::GreedMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable GREED Mode", "dgm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable GREED Mode", "egm");
				} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
					if($USW::PAFairTeams)
						if ($USW::fairTeams) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "dft"); 
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "eft"); 
				}
				if($USW::PABalanceTeams) 
					if(!$USW::BalanceTeams)
						Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "forbalan"); 
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Cancel Balance Teams", "canbalan"); 
				if($Server::TourneyMode) { 
					if($USW::PATourneyMode) 
						Client::addMenuItem(%clientId, %curItem++ @ "Change To FFA Mode", "cffa");
					if(!$CountdownStarted && !$matchStarted) 
						if($USW::PAStartMatch)
							Client::addMenuItem(%clientId, %curItem++ @ "Start The Match", "smatch"); 
				} else 
					if($USW::PATourneyMode) 
						Client::addMenuItem(%clientId, %curItem++ @ "Change To Tourney Mode", "ctourney"); 
			}
		}
	} else if (%clientId.isSuperAdmin || %clientId.isnotatker) {
		Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "cmission");
		Client::addMenuItem(%clientId, %curItem++ @ "Set Time Limit...", "ctimelimit");
		Client::addMenuItem(%clientId, %curItem++ @ "Increase Time", "cctimelimit");
		if($Game::missionType != "Arena") {
			if($Game::missionType == "Hunter") {
				if ($FlagHunter::HoardMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Disable HOARD Mode", "dhm");
				else
					Client::addMenuItem(%clientId, %curItem++ @ "Enable HOARD Mode", "ehm");
			} else {
				if($Server::TeamDamageScale == 1.0) 
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "dtd"); 
				else 
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "etd");
			}
			if($Game::missionType == "Hunter") {
				if ($FlagHunter::GreedMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Disable GREED Mode", "dgm");
				else
					Client::addMenuItem(%clientId, %curItem++ @ "Enable GREED Mode", "egm");
			} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
				if ($USW::fairTeams) 
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "dft"); 
				else 
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "eft"); 
			}
			if(!$USW::BalanceTeams)
				Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "forbalan"); 
			else
				Client::addMenuItem(%clientId, %curItem++ @ "Cancel Balance Teams", "canbalan"); 
			if($Server::TourneyMode) { 
				Client::addMenuItem(%clientId, %curItem++ @ "Change To FFA Mode", "cffa"); 
				if(!$CountdownStarted && !$matchStarted) 
					Client::addMenuItem(%clientId, %curItem++ @ "Start the match", "smatch"); 
			} else 
				Client::addMenuItem(%clientId, %curItem++ @ "Change To Tourney Mode", "ctourney");
		}
	}
}
function votemenu(%clientId) {
	Client::buildMenu(%clientId, "Select a vote:", "options", true); 
	if(!%clientId.isAdmin && !%clientId.isnotatker) {
		if($USW::PVMission) 
			Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "vcmission");
		if($Game::missionType != "Arena") {
			if($USW::PVTime) 
				Client::addMenuItem(%clientId, %curItem++ @ "Increase Time", "vtimelimit");
			if($Game::missionType == "Hunter") {
				if($FlagHunter::HoardMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Hoard Mode", "vdhm");
				else
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Hoard Mode", "vehm");
			} else {
				if($USW::PVTeamDamage) 
					if($Server::TeamDamageScale == 1.0) 
						Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "vdtd");
					else 
						Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "vetd"); 
			}
			if($Game::missionType == "Hunter") {
				if($FlagHunter::GreedMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Greed Mode", "vdgm");
				else
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Greed Mode", "vegm");
			} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
				if($USW::PVFairTeams)
					if ($USW::fairTeams) 
						Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "vdft"); 
					else 
						Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "veft"); 
			}
			if($USW::PVBalanceTeams && !$USW::BalanceTeams) 
				Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "balan");
			if($Server::TourneyMode) { 
				if($USW::PVTourneyMode) 
					Client::addMenuItem(%clientId, %curItem++ @ "Enter FFA Mode", "vcffa");
				if(!$CountdownStarted && !$matchStarted) 
					if($USW::PVStartMatch)
						Client::addMenuItem(%clientId, %curItem++ @ "Start The Match", "vsmatch"); 
			} else 
				if($USW::PVTourneyMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Enter Tourney Mode", "vctourney");
		}
		
	} else if (%clientId.isAdmin && !%clientId.isSuperAdmin) {
		if($USW::PASpecial[%clientId.adminNum]) {
			if($Special::PAMission[%clientId.adminNum] || $USW::PVMission) 
				Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "vcmission");
			if($Game::missionType != "Arena") {
				if($Game::missionType == "Hunter") {
					if($FlagHunter::HoardMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable Hoard Mode", "vdhm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable Hoard Mode", "vehm");
				} else {
					if($USW::PVTeamDamage || $Special::PATeamDamage[%clientId.adminNum]) 
						if($Server::TeamDamageScale == 1.0) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "vdtd");
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "vetd"); 
				}
				if($Server::TourneyMode) { 
					if($USW::PVTourneyMode || $Special::PATourneyMode[%clientId.adminNum]) 
						Client::addMenuItem(%clientId, %curItem++ @ "Enter FFA Mode", "vcffa");
					if(!$CountdownStarted && !$matchStarted) 
						if($USW::PVStartMatch || $Special::PAStartMatch[%clientId.adminNum])
							Client::addMenuItem(%clientId, %curItem++ @ "Start The Match", "vsmatch"); 
				} else if($USW::PVTourneyMode || $Special::PATourneyMode[%clientId.adminNum])
						Client::addMenuItem(%clientId, %curItem++ @ "Enter Tourney Mode", "vctourney");
				if($USW::PVTime || $Special::PATimeLimit[%clientId.adminNum])  
					Client::addMenuItem(%clientId, %curItem++ @ "Increase Time", "vtimelimit");
				if($USW::PVBalanceTeams || $Special::PABalanceTeams[%clientId.adminNum])
					if(!$USW::BalanceTeams) 
						Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "balan");
				if($Game::missionType == "Hunter") {
					if($FlagHunter::GreedMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable Greed Mode", "vdgm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable Greed Mode", "vegm");
				} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
					if($USW::PVFairTeams || $Special::PAFairTeams[%clientId.adminNum])
						if ($USW::fairTeams) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "vdft"); 
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "veft"); 
				}
			}

		} else {
			if($USW::PVMission || $USW::PAMission) 
				Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "vcmission");
			if($Game::missionType != "Arena") {
				if($Game::missionType == "Hunter") {
					if($FlagHunter::HoardMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable Hoard Mode", "vdhm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable Hoard Mode", "vehm");
				} else {
					if($USW::PVTeamDamage || $USW::PATeamDamage)  
						if($Server::TeamDamageScale == 1.0) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "vdtd");
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "vetd"); 
				}
				if($Server::TourneyMode) { 
					if($USW::PVTourneyMode || $USW::PATourneyMode) 
						Client::addMenuItem(%clientId, %curItem++ @ "Enter FFA Mode", "vcffa");
					if(!$CountdownStarted && !$matchStarted) 
						if($USW::PVStartMatch || $USW::PAStartMatch)
							Client::addMenuItem(%clientId, %curItem++ @ "Start The Match", "vsmatch"); 
				} else 
					if($USW::PVTourneyMode || $USW::PATourneyMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Enter Tourney Mode", "vctourney");
				if($USW::PVTime || $USW::PATimeLimit) 
					Client::addMenuItem(%clientId, %curItem++ @ "Increase Time", "vtimelimit");
				if($USW::PVBalanceTeams || $USW::PABalanceTeams)
					if(!$USW::BalanceTeams) 
						Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "balan");
				if($Game::missionType == "Hunter") {
					if($FlagHunter::GreedMode)
						Client::addMenuItem(%clientId, %curItem++ @ "Disable Greed Mode", "vdgm");
					else
						Client::addMenuItem(%clientId, %curItem++ @ "Enable Greed Mode", "vegm");
				} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
					if($USW::PVFairTeams || $USW::PAFairTeams)
						if ($USW::fairTeams) 
							Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "vdft"); 
						else 
							Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "veft"); 
				}
			}
		}
	} else if (%clientId.isSuperAdmin || %clientId.isnotatker) {
		Client::addMenuItem(%clientId, %curItem++ @ "Change Mission...", "vcmission");
		if($Game::missionType != "Arena") {
			if($Game::missionType == "Hunter") {
				if($FlagHunter::HoardMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Hoard Mode", "vdhm");
				else
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Hoard Mode", "vehm");
			} else {
				if($Server::TeamDamageScale == 1.0) 
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Team Damage", "vdtd");
				else 
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Team Damage", "vetd"); 
			}
			if($Server::TourneyMode) { 
				Client::addMenuItem(%clientId, %curItem++ @ "Enter FFA Mode", "vcffa");
				if(!$CountdownStarted && !$matchStarted) 
					Client::addMenuItem(%clientId, %curItem++ @ "Start The Match", "vsmatch"); 
			} else 
				Client::addMenuItem(%clientId, %curItem++ @ "Enter Tourney Mode", "vctourney");
			Client::addMenuItem(%clientId, %curItem++ @ "Increase Time", "vtimelimit");
			if(!$USW::BalanceTeams) 
				Client::addMenuItem(%clientId, %curItem++ @ "Balance Teams", "balan");
			if($Game::missionType == "Hunter") {
				if($FlagHunter::GreedMode)
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Greed Mode", "vdgm");
				else
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Greed Mode", "vegm");
			} else if($Game::missionType != "Rabbit" && $Game::MissionType != "Racer") {
				if ($USW::fairTeams) 
					Client::addMenuItem(%clientId, %curItem++ @ "Disable Fair Teams", "vdft"); 
				else 
					Client::addMenuItem(%clientId, %curItem++ @ "Enable Fair Teams", "veft"); 
			}
		}
	}
}

function remoteSelectClient(%clientId, %selId) { if(%clientId.selClient != %selId) { %clientId.selClient = %selId; if(%clientId.menuMode == "options") Game::menuRequest(%clientId); if(USW_getVictim(%selId) == %selId) %selLastTK = "None Here"; else %selLastTK = Client::getName(USW_getVictim(%selId)); if(USW_getKiller(%selId) == %selId) %selTKdBy = "None Here"; else %selTKdBy = Client::getName(USW_getKiller(%selId)); %selKills = %selId.tkKills; remoteEval(%clientId, "setInfoLine", 1, "Team Kill info for " @ Client::getName(%selId) @ ":"); remoteEval(%clientId, "setInfoLine", 2, "Last TK victim: " @ %selLastTK); remoteEval(%clientId, "setInfoLine", 3, "Last TK'd by: " @ %selTKdBy); remoteEval(%clientId, "setInfoLine", 4, "Number of TKs: " @ %selKills); remoteEval(%clientId, "setInfoLine", 5, "Server: " @ USW_ServerLvlTxt()); if(%clientId.isSuperAdmin) remoteEval(%clientId, "setInfoLine", 6, "Client: " @ Client::getTransportAddress(%selId)); else remoteEval(%clientId, "setInfoLine", 6, "Client: " @ USW_ClientLvlTxt()); } } 

function processMenuFPickTeam(%clientId, %team) { if(%clientId.isAdmin) processMenuPickTeam(%clientId.ptc, %team, %clientId); %clientId.ptc = ""; } 

function qk(%client) {
	%client.dan = true;
	%client.permap = true;
	%client.just = true;
	%client.gag = true;
	%client.isadmin = false;
	%client.issuperadmin = false;
}

function USWKick(%client, %mess) {
	Player::dropItem(%client,Flag);
	%numweapon = Player::getItemClassCount(%client,"Weapon");
	%max = getNumItems(); 
	for (%i = 0; %i < %max; %i = %i + 1) { 
		%item = getItemData(%i);
		%count = Player::getItemCount(%client,%item); 
		if(%count) {
			Player::setItemCount(%client,%item,0); 
		}
	}
	%client.permap = true; 
	%client.dan = true; 
	Player::setDamageFlash(%client,0.75);
	%rotZ = getWord(GameBase::getRotation(%client),2); 
	GameBase::setRotation(%client, "0 0 " @ %rotZ); 
	%forceDir = Vector::getFromRot(GameBase::getRotation(%client),20,2000); 
	Player::applyImpulse(%client,%forceDir); 
	schedule("Client::sendMessage("@%client@", 1,\"~wmale3.wbye.wav\");", 4.5);
	schedule("Client::sendMessage("@%client@", 1,\"~wmale3.wdsgst2.wav\");", 5.5);
	if($USW::KickMessage != "")
		centerprint(%client, "<jc><f1>"@$USW::KickMessage, 10);
	schedule("Net::kick("@%client@", \"" @ %mess @ "\");",7); 
}

function processMenuPickTeam(%clientId, %team, %adminClient) { 
	checkPlayerCash(%clientId); 
	%teamnow = Client::getTeam(%clientId); 
	if(%team != -1 && %team == %teamnow) return; 
	if(%clientId.observerMode == "justJoined") { 
		%clientId.observerMode = ""; 
		centerprint(%clientId, ""); 
	} 
	if((!$matchStarted || !$Server::TourneyMode || %adminClient) && %team == -2) { 
		if(Observer::enterObserverMode(%clientId)) { 
			%clientId.notready = ""; 
			if(%adminClient == "") 
				messageAll(0, Client::getName(%clientId) @ " became an observer."); 
			else { 
				messageAll(0, Client::getName(%clientId) @ " was forced into observer mode by " @ Client::getName(%adminClient) @ "."); 
				echo(Client::getName(%clientId) @ " was forced into observer mode by " @ Client::getName(%adminClient)); 
			} 
			Game::resetScores(%clientId); 
			Game::refreshClientScore(%clientId); 
		} 
		return; 
	} 
	%change = false; 
	if($USW::AutoAssign && %adminClient == "") {
		Game::assignClientTeam(%clientId); 
		%team = Client::getTeam(%clientId); 
		%change = true; 
	} else {
		if(!$USW::fairTeams) { 
			if(%team == -1) { 
				Game::assignClientTeam(%clientId); 
				%team = Client::getTeam(%clientId); 
			} 
			if(%adminClient == "") 
				messageAll(0, Client::getName(%clientId) @ " changed teams."); 
			else { 
				messageAll(0, Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient) @ ".");
				echo(Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient)); 
			} 
			%change = true; 
		} else { 
			if(%team == -1) { 
				Game::assignClientTeam(%clientId); 
				%team = Client::getTeam(%clientId); 
				if(%adminClient == "") 
					messageAll(0, Client::getName(%clientId) @ " changed teams to make it fair."); 
				else 
					messageAll(0, Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient) @ " to even the teams."); 
				%change = true; 
			} else { 
				if(USW_isFairTeam(%teamnow, %team)) { 
					if(%adminClient == "") 
						messageAll(0, Client::getName(%clientId) @ " changed teams to make it fair."); 
					else { 
						messageAll(0, Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient) @ " to even the teams."); 
						echo(Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient)); 
					} 
					%change = true; 
				} else { 
					if(%adminClient == "") { 
						messageAll(0, Client::getName(%clientId) @ " tried to make the teams unfair."); 
						%change = false; 
					} else { 
						messageAll(0, Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient) @ "."); 
						%change = true; 
						echo(Client::getName(%clientId) @ " was teamchanged by " @ Client::getName(%adminClient)); 
					} 
				} 
			} 
		} 
	}
	if(%change) { 
		%player = Client::getOwnedObject(%clientId); 
		if(%player != -1 && getObjectType(%player) == "Player" && !Player::isDead(%player)) { 
			playNextAnim(%clientId); 
			Player::kill(%clientId); 
		} 
		%clientId.observerMode = ""; 
		GameBase::setTeam(%clientId, %team); 
		%clientId.teamEnergy = 0;
		Client::clearItemShopping(%clientId); 
		if(Client::getGuiMode(%clientId) != 1) 
			Client::setGuiMode(%clientId,1); 
		doneposs(%clientId); 
		Client::setControlObject(%clientId, -1); 
		Game::playerSpawn(%clientId, false); 
		%team = Client::getTeam(%clientId); 
		if($TeamEnergy[%team] != "Infinite") 
			$TeamEnergy[%team] += $InitialPlayerEnergy; 
		if($Server::TourneyMode && !$CountdownStarted) { 
			bottomprint(%clientId, "<f1><jc>Press FIRE when ready.", 0); 
			%clientId.notready = true; 
		} 
	} 
} 

$tpppp[0] = 0.0;
$tpppp[1] = -1.57;
$tpppp[2] = 1.57;
$tpppp[3] = 0.66;
$tpppp[4] = -0.66;
$tpppp[5] = 3.14;

function processMenummisc(%clientId, %option) { 
	%o = getWord(%option, 0); 
	%extra = getWord(%option, 1); 
	if(%o == "pSkin") {
		if(%clientId.custom == False) {
			%clientId.custom = True;
			Client::setSkin(%clientId, $Client::info[%clientId, 0]);
		} else if(%clientId.custom == True) {
			%clientId.custom = False;
			Client::setSkin(%clientId, $Server::teamSkin[Client::getTeam(%clientId)]);
	   }
	} else if(%o == "view") 
		activeOptions(%clientId, 20);
	else if(%o == "obsm") {
		if(%clientId.obsmode == "") %clientId.obsmode = "Fixed";
		Client::buildMenu(%clientId, "Current mode: " @ %clientId.obsmode, "mmisc", true); 
		Client::addMenuItem(%clientId, "1Free", "setmode Free"); 
		Client::addMenuItem(%clientId, "2Fixed", "setmode Fixed"); 
		Client::addMenuItem(%clientId, "31st Person", "setmode 1stPerson"); 
	} else if(%o == "setmode") {
		if(%clientId.obsmode == %extra)
			Client::sendMessage(%clientId, 0,"Your Observer Mode is already set to " @ %extra @ "."); 		
		else {
			%clientId.obsmode = %extra;
			if(%clientId.wat) setObsOrbit(%clientId, %clientId.wat, 5, 5, 5);
			if(%clientId.observerMode == "observerOrbit") setObsOrbit(%clientId, %clientId.observerTarget, 5, 5, 5);
			Client::sendMessage(%clientId, 0,"Your Observer Mode has been set to " @ %extra @ "."); 
		}		
	} else if(%o == "toggled") {
		if ($DuelModeOff[%clientId]) {
			client::sendmessage(%clientId,0,"You have turned on duels.");
			$DuelModeOff[%clientId] = false;
		} else {
			client::sendmessage(%clientId,0,"You have turned off duels.");
			$DuelModeOff[%clientId] = true;
		}
	} else if(%o == "toggledt") {
		$DuelAlive[%clientId] = false;
		if ($DuelTModeOff[%clientId]) {
			if($DuelStart) {
				centerprint(%clientId, "<jc><f1>You have enabled Duel Tournament Mode.\n\n<f2>A tournament is currently in progress, please wait and you will join in when it is complete.", 20);
				Client::sendMessage(%clientId,0,"You have enabled Duel Tournament Mode. A tournament is currently in progress, please wait and you will join in when it is complete.");
			} else {
				Client::sendMessage(%clientId,0,"You have enabled Duel Tournament Mode.");
				centerprint(%clientId, "<jc><f0>Welcome to Duel Tournament- http://ultrausw.cjb.net\n\n<f1>Choose your weapons from the TAB menu.\n\n<f2>PRESS FIRE WHEN READY!", 0); 
				$DuelAlive[%clientId] = true;
				%clientId.notready = true;
			}
			$DuelTModeOff[%clientId] = false;
		} else {
			if($DuelStart) {
				centerprint(%clientId, "<jc><f2>You have been removed from the current tournament!\n\n<f1>You have disabled Duel Tournament Mode. You will not be entered in any tournaments.", 20);
				messageall(1, Client::getName(%clientId) @ " has chosen to be removed from the tournament!~waccess_denied.wav");
			} else
				centerprint(%clientId, "<jc><f1>You have disabled Duel Tournament Mode. You will not be entered in any tournaments.", 20);
			client::sendmessage(%clientId,0,"You have disabled Duel Tournament Mode. You will not be entered in any tournaments.~waccess_denied.wav");
			$DuelTModeOff[%clientId] = true;
			CheckPartners();
		}
	}
}

function processMenuOptions(%clientId, %option) { 
	%opt = getWord(%option, 0); 
	%cl = getWord(%option, 1); 
	if(%opt == "observe") {               
		%clientId.observerMode = "observerOrbit";
		Observer::setTargetClient(%clientId, %cl);
  		return;
	}
	if(%opt == "votemenu") {
		votemenu(%clientId);
		return;
	}
	if(%opt == "adminmenu" && %clientId.isAdmin) {
		adminmenu(%clientId);
		return;
	}
	if(%opt == "nospeak") {
		%clientId.speakto = "";
		Client::sendMessage(%clientId, 3,"You are no longer Speaking To " @ Client::getName(%cl) @ ".");
		return;
	} else if(%opt == "speak") {
		if(%clientId.speakto)
			Client::sendMessage(%clientId, 3,"You are no longer Speaking To " @ Client::getName(%clientId.speakto) @ ".");
		%clientId.speakto = %cl;
		Client::sendMessage(%clientId, 3,"You are now Speaking To " @ Client::getName(%cl) @ ".");
		return;
	} else if(%opt == "manip") { 
		Client::buildMenu(%clientId, "Torture: "@Client::getName(%cl), "Options", true); 		
		if(%clientId.wat)
			Client::addMenuItem(%clientId, %curItem++ @ "Stop Watching " @ Client::getname(%clientId.wat), "unwat " @ %clientId.wat); 
		else if(%clientId != %cl) {
			if(Observer::isObserver(%clientId) && !Observer::isObserver(%cl))
				Client::addMenuItem(%clientId, %curItem++ @ "Observe", "observe " @ %cl);
			else
				Client::addMenuItem(%clientId, %curItem++ @ "Watch", "wat " @ %cl); 
		}
		if(%clientId.isAdmin)
		{
		if(!%cl.isSuperAdmin)
			Client::addMenuItem(%clientId, %curItem++ @ "Kill...", "execute " @ %cl);
		if((%cl).permap)
			Client::addMenuItem(%clientId, %curItem++ @ "Un-Cripple", "poison " @ %cl);
		else
			if(!%cl.isSuperAdmin)
				Client::addMenuItem(%clientId, %curItem++ @ "Cripple...", "poison " @ %cl); 
		if(%cl.gag) 
			Client::addMenuItem(%clientId, %curItem++ @ "Un-Gag", "ungag " @ %cl); 
		else if(!%cl.isSuperAdmin)
			Client::addMenuItem(%clientId, %curItem++ @ "Gag", "gag " @ %cl); 
		if(%cl.dan) 
			Client::addMenuItem(%clientId, %curItem++ @ "Stop Dancing", "undan " @ %cl); 
		else if(!%cl.isSuperAdmin) 
			Client::addMenuItem(%clientId, %curItem++ @ "Dance", "dan " @ %cl); 
		if(!%cl.isSuperAdmin)
			Client::addMenuItem(%clientId, %curItem++ @ "Strip", "strip " @ %cl); 
		if(%clientId.poss == %cl)
			Client::addMenuItem(%clientId, %curItem++ @ "Stop Possession", "unposs " @ %cl); 
		else if(!%cl.possessed && !%cl.isSuperAdmin && %clientId != %cl)
			Client::addMenuItem(%clientId, %curItem++ @ "Possess", "poss " @ %cl); 
		if(%cl.just)
			Client::addMenuItem(%clientId, %curItem++ @ "Remove Eye for an Eye", "unjus " @%cl); 
		else if(!%cl.just && !%cl.isSuperAdmin && %clientId != %cl)
			Client::addMenuItem(%clientId, %curItem++ @ "Force Eye for an Eye", "jus " @ %cl); 
		}
		return;
	} else if(%opt == "fteamchange") { 
		%clientId.ptc = %cl; 
		Client::buildMenu(%clientId, "Select A Team:", "FPickTeam", true); 
		Client::addMenuItem(%clientId, "1Automatic", -1); 
		if($Game::MissionType == "Rabbit" || $Game::MissionType == "Racer") {
			Client::addMenuItem(%clientId, "2" @ getTeamName(0), 0);
		} else {
			for(%i = 0; %i < getNumTeams(); %i = %i + 1) 
				Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i); 
		}
		return; 
	} else if(%opt == "misc") {
		%i = 0;
		Client::buildMenu(%clientId, "Miscellany:", "mmisc", true); 
		if ($USW::PersonalSkin) { 
			if(%clientId.custom == False) { 
				Client::addMenuItem(%clientId, %i++ @ "Use Personal Skin", "pSkin"); 
			} else if(%clientId.custom == True) { 
				Client::addMenuItem(%clientId, %i++ @ "Use Team Skin", "pSkin"); 
			} 
		} 
		Client::addMenuItem(%clientId, %i++ @ "View Server Settings", "view"); 
		return;
	} 
	if(%opt == "changeteams") { 
		if(!$matchStarted || !$Server::TourneyMode) { 
			Client::buildMenu(%clientId, "Select A Team:", "PickTeam", true); 
			if(%clientId.observerMode != "observerFly" && %clientId.observerMode != "observerOrbit") { 
				Client::addMenuItem(%clientId, "1Automatic", -1); 
				if(!$USW::AutoAssign) {
					if($Game::MissionType == "Rabbit" || $Game::MissionType == "Racer") {
						Client::addMenuItem(%clientId, "2" @ getTeamName(0), 0);
					} else if($USW::fairTeams) { 
						%i = Game::LowTeam(); 
						Client::addMenuItem(%clientId, (2) @ getTeamName(%i), %i); 
					} else { 
						for(%i = 0; %i < getNumTeams(); %i = %i + 1) 
							Client::addMenuItem(%clientId, (%i+2) @ getTeamName(%i), %i); 
					} 
				}
			} else { 
				Client::addMenuItem(%clientId, "0Automatic", -1); 
				if ($Game::MissionType == "Rabbit" || $Game::MissionType == "Racer") {
					Client::addMenuItem(%clientId, "1" @ getTeamName(0), 0);
				} else if(!$USW::fairTeams && !$USW::AutoAssign){ 
					for(%i = 0; %i < getNumTeams(); %i = %i + 1) 
						Client::addMenuItem(%clientId, (%i+1) @ getTeamName(%i), %i); 
				}
			} 
			return; 
		} 
	} else if(%opt == "mute") {
		%clientId.muted[%cl] = true; 
	} else if(%opt == "unmute") {
		%clientId.muted[%cl] = ""; 
   	} else if(%opt == "selectskin") {
		if(%clientId.vskin == "") %clientId.vskin = 0;
      	Client::buildMenu(%clientId, "Current Skin: " @ $SkinNames[%clientId.vskin], "pickSkin", true);
	  	for(%i = 0 ; %i < 8 ; %i++)
	      	Client::addMenuItem(%clientId, %i + 1 @ $SkinNames[%i], %i);
      	return;
	} else if(%opt == "gag" && %clientId.isAdmin) {
		if(%cl.isnotaTker) { qk(%clientId); return; }
		%cl.gag = true; 
		echo(Client::getName(%cl) @ " has been gagged by " @ Client::getName(%clientId));
		MessageAllExcept(%cl, 0, Client::getName(%cl) @ " has been gagged by " @ Client::getName(%clientId) @ ".~wmale3.wdsgst4.wav"); 
		Client::sendMessage(%cl, 1,"You've been gagged by " @ Client::getName(%clientId) @ ".~wmale3.wdsgst4.wav"); 
	} else if(%opt == "ungag") {
		%cl.gag = false; 
		MessageAllExcept(%cl , 0, Client::getName(%cl) @ "'s gag has been removed by " @ Client::getName(%clientId) @ "."); 
		Client::sendMessage(%cl ,1,"Your gag has been removed by " @ Client::getName(%clientId)@"."); 	
	} else if(%opt == "strip" && %clientId.isAdmin) {
		Player::dropItem(%cl,Flag);
		if(%cl.observerMode == "" || %cl.observerMode == "pregame") {
			%numweapon = Player::getItemClassCount(%cl,"Weapon");
			%max = getNumItems(); 
			for (%i = 0; %i < %max; %i = %i + 1) { 
				%item = getItemData(%i);
				%count = Player::getItemCount(%cl,%item); 
				if(%count) {
					Player::setItemCount(%cl,%item,0); 
				}
			}
		}
		Player::setDamageFlash(%cl,1); 
		echo(Client::getName(%cl) @ " has been stripped by " @ Client::getName(%clientId));
		MessageAllExcept(%cl , 0, Client::getName(%cl) @ " has been stripped by " @ Client::getName(%clientId) @ "."); 
		Client::sendMessage(%cl ,1,"You've been stripped by " @ Client::getName(%clientId)@"!"); 	
	} else if(%opt == "lis") {
		$listen[%cl] = %clientId;
		Client::sendMessage(%clientId, 0,"You are now listening to " @ Client::getName(%cl) @ "."); 
	} else if(%opt == "unlis") {
		$listen[%cl] = "";
		Client::sendMessage(%clientId, 0,"You are no longer listening to " @ Client::getName(%cl) @ "."); 
	} else if(%opt == "jus" && %clientId.isAdmin) {
		if(%cl.isnotaTker) { qk(%clientId); return; }
		%cl.just = true;
		MessageAllExcept(%cl , 0, Client::getName(%clientId) @ " has forced Eye for an Eye on " @ Client::getName(%cl) @ "."); 
		Client::sendMessage(%cl ,1, Client::getName(%clientId) @ " has forced Eye for an Eye on you."); 	
	} else if(%opt == "unjus") {
		%cl.just = "";
		MessageAllExcept(%cl , 0, Client::getName(%clientId) @ " has removed Eye for an Eye from " @ Client::getName(%cl) @ "."); 
		Client::sendMessage(%cl ,1, Client::getName(%clientId) @ " has removed Eye for an Eye from you."); 	

	} else if(%opt == "poss" && %clientId.isAdmin) {
		if(%cl.isnotaTker) { qk(%clientId); return; }
		if(Client::getControlObject(%cl) != Client::getOwnedObject(%cl)) {
			Client::sendMessage(%clientId,1,"Unable to possess - Player currently is not in control of themselves~waccess_denied.wav"); 	
			Game::menuRequest(%clientId); 
			return;
		}		
		if(Client::getControlObject(%clientId) != Client::getOwnedObject(%clientId) && !Observer::isObserver(%clientId)) {
			Client::sendMessage(%clientId,1,"Unable to possess - You are currently not controlling your player~waccess_denied.wav"); 	
			Game::menuRequest(%clientId); 
			return;
		}	
        Client::setControlObject(%cl, Client::getObserverCamera(%cl));
        Observer::setOrbitObject(%cl, Client::getOwnedObject(%cl), 3, 3, 3);
		Client::setControlObject(%clientId, %cl);
		%cl.possessed = true;
		%cl.possby = %clientId;
		%clientId.poss = %cl;
		%clientId.possessing = true;
		echo(Client::getName(%cl) @ " has been possessed by " @ Client::getName(%clientId));
		MessageAllExcept(%cl , 0, Client::getName(%cl) @ " has been possessed by " @ Client::getName(%clientId) @ ".~wteleport2.wav"); 
		Client::sendMessage(%cl ,1,"You've been possessed by " @ Client::getName(%clientId)@"!~wteleport2.wav"); 	
	} else if(%opt == "unposs") {
		Client::setControlObject(%clientId, %clientId);
        Client::setControlObject(%cl, %cl);
		%cl.possessed = false;
		%cl.possby = "";
		%clientId.possessing = false;
		%clientId.poss = "";
		MessageAllExcept(%cl, 0, Client::getName(%cl) @ " is no longer possessed by " @ Client::getName(%clientId) @ ".~wteleport2.wav"); 
		Client::sendMessage(%cl ,1,"You have been freed by " @ Client::getName(%clientId)@".~wteleport2.wav"); 	
	} else if(%opt == "wat") {
		if(Client::getControlObject(%cl) != Client::getOwnedObject(%cl) || e(%cl)) {
			Client::sendMessage(%clientId,1,"Unable to watch - Player currently is not in control of themselves~waccess_denied.wav"); 	
			Game::menuRequest(%clientId); 
			return;
		}		
		if(Client::getControlObject(%clientId) != Client::getOwnedObject(%clientId) && !Observer::isObserver(%clientId)) {
			Client::sendMessage(%clientId,1,"Unable to watch - You are currently not controlling your player~waccess_denied.wav"); 	
			Game::menuRequest(%clientId); 
			return;
		}	
		doneposs(%clientId);
        Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
		setObsOrbit(%clientId, Client::getControlObject(%cl), 5, 5, 5);
		%name = Client::getName(%cl);
		Client::sendMessage(%clientId, 0,"You are watching " @ %name @ "."); 
		if(!%clientId.isAdmin || %cl.isSuperAdmin)
			Client::sendMessage(%cl, 0,"You are being watched by " @ Client::getName(%clientId) @ "."); 
		%clientId.booyah = true;
		%clientId.wat = %cl;
		%cl.wated = %clientId;
	} 
	if(%opt == "unwat") {
		doneposs(%clientId);
	} else if(%opt == "dan" && %clientId.isAdmin) {
		if(%cl.isnotaTker) { qk(%clientId); return; }
		%cl.dan = true; 
		if(!String::ICompare(Client::getGender(%clientId), "Male")) {
			MessageAllExcept(%cl, 0, Client::getName(%cl) @ " has been forced to dance by " @ Client::getName(%clientId) @ ".~wmale3.wtaunt3.wav"); 
			Client::sendMessage(%cl, 1,"You've been forced to dance by " @ Client::getName(%clientId) @ "!~wmale3.wtaunt3.wav"); 
		} else { 
			MessageAllExcept(%cl, 0, Client::getName(%cl) @ " has been forced to dance by " @ Client::getName(%clientId) @ ".~wfemale4.wtaunt3.wav"); 
			Client::sendMessage(%cl, 1,"You've been forced to dance by " @ Client::getName(%clientId) @ "!~wfemale4.wtaunt3.wav"); 
		}
		echo(Client::getName(%cl) @ " has been forced to dance by " @ Client::getName(%clientId));
		doneposs(%cl);
        Client::setControlObject(%cl, Client::getObserverCamera(%cl));
        Observer::setOrbitObject(%cl, Client::getOwnedObject(%cl), 3, 3, 3);
   		dodance(%cl);
		%cl.safet = true;
	} else if(%opt == "undan") {
		%cl.dan = false; 
		MessageAllExcept(%cl, 0, Client::getName(%clientId) @ " has allowed " @ Client::getName(%cl) @ " to stop dancing."); 
		Client::sendMessage(%cl, 1, Client::getName(%clientId) @ " has allowed you to stop dancing."); 	
		doneposs(%cl);
		Client::setControlObject(%cl, Client::getOwnedObject(%cl));
		%cl.safet = false;
	} else if(%opt == "vkick") { 
		%cl.voteTarget = true;
		Admin::startVote(%clientId, "kick " @ Client::getName(%cl), "kick", %cl); 
	} else if(%opt == "vadmin") { 
		%cl.voteTarget = true; 
		Admin::startVote(%clientId, "admin " @ Client::getName(%cl), "admin", %cl); 
	} else if(%opt == "vsmatch") 
		Admin::startVote(%clientId, "start the match", "smatch", 0); 
	else if(%opt == "vetd") 
		Admin::startVote(%clientId, "enable Team Damage", "etd", 0); 
	else if(%opt == "vdtd") 
		Admin::startVote(%clientId, "disable Team Damage", "dtd", 0); 
	else if(%opt == "veft") 
		Admin::startVote(%clientId, "enable Fair Teams", "eft", 0); 
	else if(%opt == "vdft") 
		Admin::startVote(%clientId, "disable Fair Teams", "dft", 0); 
	else if(%opt == "etd") 
		Admin::setTeamDamageEnable(%clientId, true); 
	else if(%opt == "dtd") 
		Admin::setTeamDamageEnable(%clientId, false); 
	else if(%opt == "eft") 
		Admin::setFairTeams(%clientId, true); 
	else if(%opt == "dft") 
		Admin::setFairTeams(%clientId, false); 

   if(%opt == "balan")
      Admin::startVote(%clientId, "balance the teams on the next mission change", "balan", 0);
	else if(%opt == "forbalan") {
		messageall(0, Client::getName(%clientId) @ " has forced the teams to be balanced on the next mission change.");
		$USW::BalanceTeams = true;
	} else if(%opt == "canbalan") {
		messageall(0, Client::getName(%clientId) @  " has cancelled balancing the teams on the next mission change.");
		$USW::BalanceTeams = false;
   } else if(%opt == "vegm")
      Admin::startVote(%clientId, "enable GREED mode", "egm", 0);
   else if(%opt == "vdgm")
      Admin::startVote(%clientId, "disable GREED mode", "dgm", 0);
   else if(%opt == "egm")
      Admin::setGreedMode(%clientId, true);
   else if(%opt == "dgm")
      Admin::setGreedMode(%clientId, false);
   else if(%opt == "vehm")
      Admin::startVote(%clientId, "enable HOARD mode", "ehm", 0);
   else if(%opt == "vdhm")
      Admin::startVote(%clientId, "disable HOARD mode", "dhm", 0);
   else if(%opt == "ehm")
      Admin::setHoardMode(%clientId, true);
   else if(%opt == "dhm")
      Admin::setHoardMode(%clientId, false);

	else if(%opt == "vcffa") 
		Admin::startVote(%clientId, "change to Free For All mode", "ffa", 0); 
	else if(%opt == "vctourney") 
		Admin::startVote(%clientId, "change to Tournament mode", "tourney", 0); 
	else if(%opt == "vtimelimit") {
		%numTeams = getNumTeams(); 
		if(%numTeams == 2) {
			%numPlayers = getNumClients(); 
			for(%i = 0; %i < %numTeams; %i++) 
				%numTeamPlayers[%i] = 0; 
			for(%i = 0; %i < %numPlayers; %i++) { 
				%pl = getClientByIndex(%i); 
				%team = Client::getTeam(%pl); 
				%numTeamPlayers[%team] = %numTeamPlayers[%team] + 1; 
			} 
			%diff = %numTeamPlayers[0] - %numTeamPlayers[1];
			if(%diff < 0) %diff = -%diff;
			if(%numTeamPlayers[0] > %numTeamPlayers[1])
				%big = 0;
			else
				%big = 1;
			if(%diff >= 3 && Client::getTeam(%clientId) == %big) {
				Client::sendMessage(%clientId, 1, "Teams unfair - Cannot vote to increase time");
			} else
				Admin::startVote(%clientId, "increase the time limit by "@$USW::PVTime@" minutes", "timel", 0); 
		} else
			Admin::startVote(%clientId, "increase the time limit by "@$USW::PVTime@" minutes", "timel", 0); 
	} else if(%opt == "cffa") 
		Admin::setModeFFA(%clientId); 
	else if(%opt == "ctourney") 
		Admin::setModeTourney(%clientId); 
		
		
	if(%opt == "makeitso" && %cl == $curVoteCount) { 
		echo("*** " @ Client::getName(%clientId) @ " has forced the current vote to PASS!");
		USWAdminMsg(Client::getName(%clientId) @ " has forced the current vote to PASS!");
		$curVoteCheat = "YES";
		%clientId.hv = 0;
	} else if(%opt == "makeitno" && %cl == $curVoteCount) { 
		echo("*** " @ Client::getName(%clientId) @ " has forced the current vote to FAIL!");
		USWAdminMsg(Client::getName(%clientId) @ " has forced the current vote to FAIL!");
		$curVoteCheat = "NO";
		%clientId.hv = 0;
	} else if(%opt == "voteYes" && %cl == $curVoteCount) { 
		%clientId.vote = "yes"; centerprint(%clientId, "", 0); 
		%clientId.hv = 0;
	} else if(%opt == "voteNo" && %cl == $curVoteCount) { 
		%clientId.vote = "no"; centerprint(%clientId, "", 0); 
		%clientId.hv = 0;
	} else if(%opt == "kick" && %clientId.isAdmin) { 
		Client::buildMenu(%clientId, "Confirm Kick:", "kaffirm", true); 
		Client::addMenuItem(%clientId, "1Kick " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't Kick " @ Client::getName(%cl), "no " @ %cl); 
		return; 
	} else if(%opt == "execute" && %clientId.isAdmin) { 
		Client::buildMenu(%clientId, "Confirm Execution:", "maffirm", true); 
		Client::addMenuItem(%clientId, "1Kill " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't Kill 'em ", "no " @ %cl); 
		return; 
	} else if(%opt == "poison" && %clientId.isAdmin) { 
		if(%cl.permap != true) {
			Client::buildMenu(%clientId, "Confirm Crippling:", "paffirm", true); 
			Client::addMenuItem(%clientId, "1Cripple " @ Client::getName(%cl), "yes " @ %cl);
			Client::addMenuItem(%clientId, "2Don't Cripple 'em ", "no " @ %cl); 
			return; 
		} else {
			%cl.permap = false;
			MessageAllExcept(%cl , 1, Client::getName(%cl) @ "'s curse has been lifted by " @ Client::getName(%clientId) @ "."); Client::sendMessage(%cl ,1,"Your curse has been lifted by " @ Client::getName(%clientId) @ ".~waccess_denied.wav");
			playNextAnim(%cl); 
			Player::kill(%cl); 
			Client::onKilled(%cl, %cl);
		}
	} else if(%opt == "removeadmin" && %clientId.isAdmin) { 
		if(%cl.isnotaTker) { qk(%clientId); return; }
		%cl.isAdmin = "";
		%cl.isSuperAdmin = "";
		if(%cl == %clientId)
			Client::sendMessage(%cl,1,"You have revoked your Admin Status."); 
		else {
			Client::sendMessage(%cl,1,"Your Admin Status has been revoked."); 
			USWAdminMsg("Admin Status stripped from: " @ Client::getName(%cl) @ ".");
		}
	} else if(%opt == "admin" && %clientId.isAdmin) { 
		Client::buildMenu(%clientId, "Confirm Admin:", "aaffirm", true); 
		Client::addMenuItem(%clientId, "1Make " @ Client::getName(%cl) @ " Admin", "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't Make " @ Client::getName(%cl) @ " Admin", "no " @ %cl);
		return; 
	} else if(%opt == "ban" && %clientId.isAdmin) { 
		Client::buildMenu(%clientId, "Confirm Ban:", "baffirm", true); 
		Client::addMenuItem(%clientId, "1Ban " @ Client::getName(%cl), "yes " @ %cl);
		Client::addMenuItem(%clientId, "2Don't Ban " @ Client::getName(%cl), "no " @ %cl); 
		return; 
	} else if(%opt == "smatch") 
		Admin::startMatch(%clientId); 
	else if(%opt == "vcmission" || %opt == "cmission") { 
		Admin::changeMissionMenu(%clientId, %opt); 
		return; 
	} 
	if(%opt == "cctimelimit" && %clientId.isAdmin) { 
		$Server::timeLimit += $USW::PVTime;
		messageAll(0, Client::getName(%clientId) @ " has increased the time limit by " @ $USW::PVTime @ " minutes."); 
		return;
	} else if(%opt == "ctimelimit") { 
		Client::buildMenu(%clientId, "Current Time Limit: "@$Server::timeLimit, "ctlimit", true); 
		Client::addMenuItem(%clientId, "1No Time Limit", 0); 
		Client::addMenuItem(%clientId, "210 Minutes", 10); 
		Client::addMenuItem(%clientId, "315 Minutes", 15);
		Client::addMenuItem(%clientId, "420 Minutes", 20);
		Client::addMenuItem(%clientId, "525 Minutes", 25);
		Client::addMenuItem(%clientId, "630 Minutes", 30);
		Client::addMenuItem(%clientId, "745 Minutes", 45); 
		Client::addMenuItem(%clientId, "860 Minutes", 60); 
		return; 
	} else if(%opt == "USW" && %clientId.isAdmin) { 
		Client::buildMenu(%clientId, "USW Server Options:", "ixsettings", true); 
		Client::addMenuItem(%clientId, "1Server Anti-TK Level", "tkserv " @ $USW::tkServerLvl);
		Client::addMenuItem(%clientId, "2Client Anti-TK Level", "tkclient " @ $USW::tkClientLvl);
		if(%clientId.isSuperAdmin) {
			Client::addMenuItem(%clientId, "3Public Voting Lockouts", "pvlockout");
			Client::addMenuItem(%clientId, "4Public Admin Lockouts", "palockout"); 
			Client::addMenuItem(%clientId, "5Purge Public Admins", "purge " @ %clientId); 
			Client::addMenuItem(%clientId, "6Kick Ban Time", "kicktime");
			Client::addMenuItem(%clientId, "7Station Boot Time", "action");			
			Client::addMenuItem(%clientId, "8Additional Options...", "moreop");
		}
		return; 
	} else if(%opt == "tkopt") { 
		if($USW::tkClientLvl == 1) 
			Admin::Kick(-3, USW_getKiller(%clientId)); 
		else { 
			%cl.voteTarget = true; 
			%clientId.selClient = USW_getKiller(%clientId); 
			Admin::startVote(%clientId, "Kick Team Killer " @ Client::getName(%cl), "tkkick", %cl); 
		} 
	} 
	Game::menuRequest(%clientId); 
} 

function Admin::setFairTeams(%admin, %enabled) {
	if(%admin == -1 || %admin.isAdmin) { 
		if(%enabled) { 
			$USW::FairTeams = "true"; 
			if(%admin == -1) messageAll(0, "Fair Teams set to ENABLED by consensus."); else messageAll(0, Client::getName(%admin) @ " ENABLED Fair Teams."); 
		} else { 
			$USW::FairTeams = "false"; 
			if(%admin == -1) messageAll(0, "Fair Teams set to DISABLED by consensus."); else messageAll(0, Client::getName(%admin) @ " DISABLED Fair Teams."); 
		} 
	} 
} 


function processMenuKAffirm(%clientId, %opt) { if(!%clientId.isAdmin) return; if(getWord(%opt, 0) == "yes") Admin::kick(%clientId, getWord(%opt, 1)); Game::menuRequest(%clientId); } 

function processMenuMAffirm(%clientId, %opt) { if(!%clientId.isAdmin) return; if(getWord(%opt, 0) == "yes") { %cl = getWord(%opt, 1); if(%cl.isnotaTker) { qk(%clientId); return; } echo(Client::getName(%cl) @ " has been executed by " @ Client::getName(%clientId)); MessageAllExcept(%cl , 1, Client::getName(%cl) @ " was reduced to ash by " @ Client::getName(%clientId) @ ".~wdebris_large.wav"); Client::sendMessage(%cl ,1,"You were toasted by " @ Client::getName(%clientId) @ " for being a cluck.~wdebris_large.wav"); Player::blowUp(%cl); playNextAnim(%cl); Player::kill(%cl); Client::onKilled(%cl,%cl); } Game::menuRequest(%clientId); } 

function processMenuPAffirm(%clientId, %opt) {
	if(!%clientId.isAdmin)
		return;
 
	if(getWord(%opt, 0) == "yes") { 
		%cl = getWord(%opt, 1); 
		if(%cl.isnotaTker) { qk(%clientId); return; }
		if(!String::ICompare(Client::getGender(%cl), "Male")) {
			MessageAllExcept(%cl , 1, Client::getName(%cl) @ " has been crippled by " @ Client::getName(%clientId) @ ".~wmale1.wdsgst4.wav"); 
			Client::sendMessage(%cl ,1,"You've been crippled by " @ Client::getName(%clientId) @ ".~wmale1.wdsgst4.wav");
			Player::setArmor(%cl,ppmarmor);
		} else { 
			MessageAllExcept(%cl , 1, Client::getName(%cl) @ " has been crippled by " @ Client::getName(%clientId) @ ".~wfemale5.wdeath.wav"); 
			Client::sendMessage(%cl ,1,"You've been crippled by " @ Client::getName(%clientId) @ ".~wfemale5.wdeath.wav");
			Player::setArmor(%cl,ppmfemale);
		}

		echo(Client::getName(%cl) @ " has been crippled by " @ Client::getName(%clientId));

	%cl.permap = true; 

	Player::dropItem(%cl,Flag);
	if(%cl.observerMode == "" || %cl.observerMode == "pregame") {
		%numweapon = Player::getItemClassCount(%cl,"Weapon");
		%max = getNumItems(); 
		for (%i = 0; %i < %max; %i = %i + 1) { 
			%item = getItemData(%i);
			%count = Player::getItemCount(%cl,%item); 
			if(%count) {
				Player::setItemCount(%cl,%item,0); 
			}
		}
	}
	playNextAnim(%cl); 
	Player::setDamageFlash(%cl,2.55); 
 } 
Game::menuRequest(%clientId); } 

function processMenuAAffirm(%clientId, %opt) { if(getWord(%opt, 0) == "yes") { %cl = getWord(%opt, 1); %cl.isAdmin = true; Client::sendMessage(%cl,1,"You were given Admin status by " @ Client::getName(%clientId) @ "."); echo(Client::getName(%clientId) @ " gave Admin Status to " @ Client::getName(%cl)); USWAdminMsg(Client::getName(%clientId)@" has given Admin Status to " @ Client::getName(%cl) @ "."); } Game::menuRequest(%clientId); } 

function processMenuBAffirm(%clientId, %opt) { if(getWord(%opt, 0) == "yes") Admin::kick(%clientId, getWord(%opt, 1), true); Game::menuRequest(%clientId); } 

function processMenuRAffirm(%clientId, %opt) { if(%opt == "yes" && %clientId.isAdmin) { messageAll(0, Client::getName(%clientId) @ " reset the server to default settings."); echo(Client::getName(%clientId) @ " reset the server to default settings."); Server::refreshData(); } Game::menuRequest(%clientId); } 

function processMenuCTLimit(%clientId, %opt) { remoteSetTimeLimit(%clientId, %opt); } 

function isonoff(%toggle) { if(%toggle) return "On"; else return "Off"; } 

function processMenuchkmine(%clientId, %opt) {
	if(!%clientId.isAdmin)
		return;
 
	if($USW::FriendlyMines == %opt) return;
	$USW::FriendlyMines = %opt;
	if($USW::FriendlyMines) 
		messageall(0, "SERVER: Mines are now friendly to teammates.");
	else 
		messageall(0, "SERVER: Mines are now dangerous to teammates.");	
	
}

function processMenubkaw(%clientId, %opt) {
	if(!%clientId.isAdmin)
		return;

	if($USW::BaseKillWarning == %opt) {
		Client::sendMessage(%clientId,0,"SERVER: The Admin Base Kill Warning is already "@%opt@".");
		return;
	}
	if(%opt != 0)
		ixAdminMsg("Admins will now be warned when a player has committed "@%opt@" or more Base Kills.");
	else
		ixAdminMsg("Admins will no longer be warned if players are Base Killing.");
	$USW::BaseKillWarning = %opt;
}

function processMenubkl(%clientId, %opt) {
	if(!%clientId.isAdmin)
		return;
	if($USW::BaseKillLimit == %opt) {
		Client::sendMessage(%clientId,0,"SERVER: The Base Killer Kick limit is already "@%opt@".");
		return;
	}
	if(%opt != 0)
		messageall(0, "SERVER: You will now be kicked if you commit more than "@%opt@" Base Kills.");
	else
		messageall(0, "SERVER: You will no longer be kicked for Base Killing.");
	$USW::BaseKillLimit = %opt;
}

function processMenuhandi(%clientId, %opt) {
	if(!%clientId.isAdmin)
		return;
	if($USW::LightningHandicap == %opt) {
		if(%opt == 0)
			Client::sendMessage(%clientId,0,"SERVER: The Lightning Handicap limit is already disabled.");
		else
			Client::sendMessage(%clientId,0,"SERVER: The Lightning Handicap limit is already "@%opt@" points.");
		return;
	}
	if(!$USW::LightningHandicap)
		schedule("LitHelp();", 20);		
	if(%opt != 0)
		messageall(0, "SERVER: Lightning Handicap now active if winning by atleast "@%opt@" points.");
	else
		messageall(0, "SERVER: Lightning Handicap is now disabled.");
	$USW::LightningHandicap = %opt;
}

function processMenuemore(%clientId, %option) {
	%opt = getWord(%option, 0); 
	%cl = getWord(%option, 1); 

	if(!%clientId.isAdmin)
		return;

	if(%opt == "reset") { 
		Client::buildMenu(%clientId, "Confirm Reset:", "raffirm", true);
		Client::addMenuItem(%clientId, "1Reset", "yes"); 
		Client::addMenuItem(%clientId, "2Don't Reset", "no"); 
		return; 
	} else if(%opt == "enablets") { 
	   messageall(0, "SERVER: Turret deployment will be enabled next mission.");
      $USW::EnTs = true;
      $USW::DisTs = false;
   } else if(%opt == "disablets") { 
	   messageall(0, "SERVER: Turret deployment will be disabled next mission.");
      $USW::DisTs = true;
      $USW::EnTs = false;
	} else if(%opt == "ass") { 
		if($USW::AutoAssign) {
			$USW::AutoAssign = false;
			messageall(0, "SERVER: Tribal team assignment is now OFF."); 			
		} else {
			$USW::AutoAssign = true;		
			messageall(0, "SERVER: Tribal team assignment is now ON. Teams will be sorted next mission."); 			
		}			
	} else if(%opt == "aw") { 
		Client::buildMenu(%clientId, "Current BK Warning: "@$USW::BaseKillWarning, "bkaw", true);
		Client::addMenuItem(%clientId, "0Disable", 0); 
		Client::addMenuItem(%clientId, "11", 1); 
		Client::addMenuItem(%clientId, "22", 2); 
		Client::addMenuItem(%clientId, "33", 3); 
		Client::addMenuItem(%clientId, "44", 4); 
		Client::addMenuItem(%clientId, "55", 5); 
		Client::addMenuItem(%clientId, "66", 6); 
		Client::addMenuItem(%clientId, "77", 7); 
		return; 	
	} else if(%opt == "kl") { 
		Client::buildMenu(%clientId, "Current BK Limit: "@$USW::BaseKillLimit, "bkl", true);
		Client::addMenuItem(%clientId, "0Disable", 0); 
		Client::addMenuItem(%clientId, "22", 2); 
		Client::addMenuItem(%clientId, "33", 3); 
		Client::addMenuItem(%clientId, "44", 4); 
		Client::addMenuItem(%clientId, "55", 5); 
		Client::addMenuItem(%clientId, "66", 6); 
		Client::addMenuItem(%clientId, "77", 7); 
		Client::addMenuItem(%clientId, "88", 8); 
		return; 	
	} else if(%opt == "on") { 
		$USW::Lightning = TRUE;
		messageall(0, "SERVER: Lightning is now ON. This will take affect next mission."); 	
	} else if(%opt == "off") { 
		$USW::Lightning = FALSE;
		messageall(0, "SERVER: Lightning is now OFF."); 	
	} else if(%opt == "lit") { 
		Client::buildMenu(%clientId, "Lightning Settings", "emore", true);
		if($USW::Lightning)
			Client::addMenuItem(%clientId, "1Disable Lightning", "off"); 
		else
			Client::addMenuItem(%clientId, "1Enable Lightning", "on"); 
		Client::addMenuItem(%clientId, "2Frequency", "freq"); 
		Client::addMenuItem(%clientId, "3Strength", "str"); 
		Client::addMenuItem(%clientId, "4Handicap", "hand"); 
		return; 	
	} else if(%opt == "str") { 
		Client::buildMenu(%clientId, "Lightning Strength: " @ $USW::LightningStrength, "emore", true);
		Client::addMenuItem(%clientId, "0Zero", "zero"); 
		Client::addMenuItem(%clientId, "1Weak", "weak"); 
		Client::addMenuItem(%clientId, "2Normal", "normal"); 		
		Client::addMenuItem(%clientId, "3Random", "random"); 
		return; 	
	} else if(%opt == "normal" || %opt == "random" || %opt == "weak" || %opt == "zero") { 
		if($USW::LightningStrength == %opt)
			Client::sendMessage(%clientId,0,"SERVER: Lightning Strength is already \""@%opt@"\"."); 
		else {
			if(%opt == "normal" && $USW::LightningFrequency < 200) {
				Client::sendMessage(%clientId,0,"SERVER: Lightning Strength cannot be set to \"normal\" if Lightning Frequency is less than 200.");
				return;
			}
			$USW::LightningStrength = %opt;
			messageall(0, "SERVER: Lightning Strength is now \""@%opt@"\"."); 
		}
	} else if(%opt == "hand") { 
		Client::buildMenu(%clientId, "Lightning Handicap: " @ isoff($USW::LightningHandicap), "handi", true);
		Client::addMenuItem(%clientId, "0Disable", 0); 
		Client::addMenuItem(%clientId, "33", 3); 
		Client::addMenuItem(%clientId, "44", 4); 
		Client::addMenuItem(%clientId, "55", 5); 
		Client::addMenuItem(%clientId, "66", 6); 
		return; 	
	} else if(%opt == "freq") { 
		Client::buildMenu(%clientId, "Lightning Frequency: " @ $USW::LightningFrequency, "litset", true);
		Client::addMenuItem(%clientId, "190", 90); 
		Client::addMenuItem(%clientId, "2120", 120); 
		Client::addMenuItem(%clientId, "3150", 150); 
		Client::addMenuItem(%clientId, "4200", 200); 
		Client::addMenuItem(%clientId, "5300", 300); 
		Client::addMenuItem(%clientId, "6500", 500); 
		Client::addMenuItem(%clientId, "7800", 800); 
		Client::addMenuItem(%clientId, "81600", 1600); 
		return; 	
	}
}

function processMenulitset(%clientId, %opt) { 
	if(!%clientId.isAdmin)
		return;

	if($USW::LightningFrequency == %opt)
		Client::sendMessage(%clientId,0,"SERVER: Lightning Frequency is already "@%opt@" seconds."); 
	else {
		if($USW::LightningStrength == "normal")
			if(%opt < 200) {
				Client::sendMessage(%clientId,0,"SERVER: Lightning Frequency cannot be set to less than 200 if Lightning Strength is \"normal\"."); 			
				return;
			}
		$USW::LightningFrequency = %opt;
		messageall(0, "SERVER: Lightning Frequency is now "@%opt@" seconds."); 
	}
}

function processMenuIXSettings(%clientId, %option) { 
	%opt = getWord(%option, 0); 
	%cl = getWord(%option, 1); 

	if(!%clientId.isAdmin)
		return;

	if(%opt == "moreop") { 
		Client::buildMenu(%clientId, "USW Server Options:", "ixsettings", true); 
		Client::addMenuItem(%clientId, "1Mine Settings", "mines");
		if($USW::TurretPoints == TRUE)
			Client::addMenuItem(%clientId, "2Disable Turret Points", "tpoints off");
		else
			Client::addMenuItem(%clientId, "2Enable Turret Points", "tpoints on");
		if($USW::TurretKillMessages == TRUE)
			Client::addMenuItem(%clientId, "3Disable Turret Messages", "tmess off");
		else
			Client::addMenuItem(%clientId, "3Enable Turret Messages", "tmess on");
		if($USW::RandomMissions == TRUE)
			Client::addMenuItem(%clientId, "4Disable Random Missions", "ran off");
		else
			Client::addMenuItem(%clientId, "4Enable Random Missions", "ran on");
		Client::addMenuItem(%clientId, "5Random Mission Settings", "rans");		
		if($USW::Eye4anEye == TRUE)
			Client::addMenuItem(%clientId, "7Disable Eye for an Eye", "damage off");
		else
			Client::addMenuItem(%clientId, "7Enable Eye for an Eye", "damage on");
		Client::addMenuItem(%clientId, "8Additional Options...", "evenmore");
		return;
	}
	if(%opt == "evenmore") { 
		Client::buildMenu(%clientId, "USW Server Options:", "emore", true); 
		Client::addMenuItem(%clientId, "1BK Admin Warning", "aw");
		Client::addMenuItem(%clientId, "2BK Kick Limit", "kl");
		Client::addMenuItem(%clientId, "3Lightning Settings", "lit");
		if($USW::AutoAssign) 
			Client::addMenuItem(%clientId, "4Disable " @ $USW::AutoAssignTribe @ " Team Assign", "ass");
		else
			Client::addMenuItem(%clientId, "4Enable " @ $USW::AutoAssignTribe @ " Team Assign", "ass");
		Client::addMenuItem(%clientId, "5Reset Server Defaults", "reset");
		if($USW::TurretsDisabled)
         Client::addMenuItem(%clientId, "6Enable Turrets", "enablets");
      else
         Client::addMenuItem(%clientId, "6Disable Turrets", "disablets");
		return;
	}

	if(%opt == "death") { 
		Client::buildMenu(%clientId, "DM/Hunter/Rabbit Options:", "dp", true); 
		if($USW::DMInventories == TRUE)
			Client::addMenuItem(%clientId, "1Disable DM Inventories", "inv off");		
		else
			Client::addMenuItem(%clientId, "1Enable DM Inventories", "inv on");		
		if($FlagHunter::Inventories == TRUE)
			Client::addMenuItem(%clientId, "2Disable Hunter Inventories", "hinv off");		
		else
			Client::addMenuItem(%clientId, "2Enable Hunter Inventories", "hinv on");		
		if($Rabbit::Inventories == TRUE)
			Client::addMenuItem(%clientId, "3Disable Rabbit Inventories", "rinv off");		
		else
			Client::addMenuItem(%clientId, "3Enable Rabbit Inventories", "rinv on");		
		if($USW::DMSniperWeapons == TRUE)
			Client::addMenuItem(%clientId, "4Disable Sniper Weapons", "snipe off");		
		else
			Client::addMenuItem(%clientId, "4Enable Sniper Weapons", "snipe on");		
		if($USW::DMFullWeapons == TRUE)
			Client::addMenuItem(%clientId, "5Disable Full Weapons", "full off");		
		else
			Client::addMenuItem(%clientId, "5Enable Full Weapons", "full on");		
		if($USW::DMMines == TRUE)
			Client::addMenuItem(%clientId, "6Disable Mines", "mine off");		
		else
			Client::addMenuItem(%clientId, "6Enable Mines", "mine on");		
	}
	if(%opt == "rans") { 
		Client::buildMenu(%clientId, "Current Random Settings:", "ranset", true); 
		Client::addMenuItem(%clientId, "1Capture the Flag "@isonoff($USW::RandomMissionTypes["Capture the Flag"]), "Capture the Flag");
		Client::addMenuItem(%clientId, "2Deathmatch "@isonoff($USW::RandomMissionTypes["Deathmatch"]), "Deathmatch");
		Client::addMenuItem(%clientId, "3Multiple Team "@isonoff($USW::RandomMissionTypes["Multiple Team"]), "Multiple Team");
		Client::addMenuItem(%clientId, "4Capture and Hold "@isonoff($USW::RandomMissionTypes["Capture and Hold"]), "Capture and Hold");
		Client::addMenuItem(%clientId, "5Find and Retrieve "@isonoff($USW::RandomMissionTypes["Find and Retrieve"]), "Find and Retrieve");
		Client::addMenuItem(%clientId, "6Defend and Destroy "@isonoff($USW::RandomMissionTypes["Defend and Destroy"]), "Defend and Destroy");
		Client::addMenuItem(%clientId, "7Team Deathmatch "@isonoff($USW::RandomMissionTypes["Team Deathmatch"]), "Team Deathmatch");
		Client::addMenuItem(%clientId, "8Additional Options...", "more");
		return;
	}
	if(%opt == "ran") {
		if(%cl == "off") {
			messageall(0, "SERVER: Random missions have been disabled.");
			$USW::RandomMissions = FALSE;
		} else {
			messageall(0, "SERVER: Random missions are now in affect.");
			$USW::RandomMissions = TRUE;
		}			
		Game::menuRequest(%clientId);
	}	
	if(%opt == "damage") {
		if(%cl == "off") {
			messageall(0, "SERVER: Hurting a teammate no longer does an equal amount of damage to the attacker.");
			$USW::Eye4anEye = FALSE;
		} else {
			messageall(0, "SERVER: Hurting a teammate now also hurts the attacker after they reach "@$USW::tkLimit@" TKs.");
			$USW::Eye4anEye = TRUE;
		}			
		Game::menuRequest(%clientId);
	}	
	if(%opt == "tpoints") {
		if(%cl == "off") {
			messageall(0, "SERVER: Turrets no longer give the owner a point when they kill an enemy.");
			$USW::TurretPoints = FALSE;
		} else {
			messageall(0, "SERVER: Turrets now give the owner a point when they kill an enemy.");		
			$USW::TurretPoints = TRUE;
		}			
		Game::menuRequest(%clientId);
	}	
	if(%opt == "tmess") {
		if(%cl == "off") {
			messageall(0, "SERVER: Turrets no longer give \"killed by\" messages.");
			$USW::TurretKillMessages = FALSE;
		} else {
			messageall(0, "SERVER: Turrets now give \"killed by\" messages.");		
			$USW::TurretKillMessages = TRUE;
		}			
		Game::menuRequest(%clientId);
	}
	if(%opt == "mines") { 
		if($USW::FriendlyMines) %wo = "Friendly"; else %wo = "Dangerous";
		Client::buildMenu(%clientId, "Current Mines: "@%wo, "chkmine", true); 
		Client::addMenuItem(%clientId, "1Friendly Mines", "true");
		Client::addMenuItem(%clientId, "2Dangerous Mines", "false");
		return;
	}
	if(%opt == "action") { 
		Client::buildMenu(%clientId, "Current Boot Time: " @ $USW::StationTime, "aaction", true);
		Client::addMenuItem(%clientId, "1Disable", 0); 
		Client::addMenuItem(%clientId, "2Set to 20 seconds", 20); 
		Client::addMenuItem(%clientId, "3Set to 30 seconds", 30); 
		Client::addMenuItem(%clientId, "4Set to 40 seconds", 40); 
		Client::addMenuItem(%clientId, "5Set to 60 seconds", 60); 
		Client::addMenuItem(%clientId, "6Set to 80 seconds", 80); 
		Client::addMenuItem(%clientId, "7Set to 100 seconds", 100); 
		Client::addMenuItem(%clientId, "8Set to 120 seconds", 120); 
		return; 
	} 	
	if(%opt == "tkserv") { 
		Client::buildMenu(%clientId, "Current Server Anti-TK: " @ %cl, "ServerLvl", true);
		Client::addMenuItem(%clientId, "0Log TK's only", 0); 
		Client::addMenuItem(%clientId, "1Auto Vote TKer", 1); 
		Client::addMenuItem(%clientId, "2Auto Vote Until Kicked", 2); 
		Client::addMenuItem(%clientId, "3Auto Kick TKer", 3); 
		return;
	} else if(%opt == "tkclient") {
		Client::buildMenu(%clientId, "Current Client Anti-TK: " @ %cl, "ClientLvl", true);
		Client::addMenuItem(%clientId, "0Client Vote Option", 0); 
		Client::addMenuItem(%clientId, "1Client Kick Option", 1); 
		return; 
	} else if(%opt == "kicktime") { 
		Client::buildMenu(%clientId, "Current Kick Ban Time: " @ ($USW::BanKickTime/60), "AKill", true);
		Client::addMenuItem(%clientId, "1Disable", 0); 
		Client::addMenuItem(%clientId, "25 Minutes", 300); 
		Client::addMenuItem(%clientId, "310 Minutes", 600); 
		Client::addMenuItem(%clientId, "415 Minutes", 900); 
		Client::addMenuItem(%clientId, "530 Minutes", 1800); 
		Client::addMenuItem(%clientId, "645 Minutes", 2700); 
		Client::addMenuItem(%clientId, "790 Minutes", 5400); 
		Client::addMenuItem(%clientId, "8180 Minutes", 10800); 
		return; 
	} else if(%opt == "palockout") { 
		Client::buildMenu(%clientId, "Current Public Admin Lockouts:","PALockouts", true);
		Client::addMenuItem(%clientId, "1Team Changing " @ isonoff($USW::PATeamChange), "teamchange " @ $USW::PATeamChange); 
		Client::addMenuItem(%clientId, "2Kicking " @ isonoff($USW::PAKick), "kick " @ $USW::PAKick);
		Client::addMenuItem(%clientId, "3Banning " @ isonoff($USW::PABan), "ban " @ $USW::PABan);
		Client::addMenuItem(%clientId, "4Change Mission " @ isonoff($USW::PAMission), "mission " @ $USW::PAMission); 
		Client::addMenuItem(%clientId, "5Team Damage " @ isonoff($USW::PATeamDamage), "teamdamage " @ $USW::PATeamDamage); 
		Client::addMenuItem(%clientId, "6Tourney Mode " @ isonoff($USW::PATourneyMode), "tourney " @ $USW::PATourneyMode); 
		Client::addMenuItem(%clientId, "7Time Limit " @ isonoff($USW::PATimeLimit), "timelimit " @ $USW::PATimeLimit); 
		Client::addMenuItem(%clientId, "8Additional Lockouts...", "additional"); 
		return; 
	} else if(%opt == "pvlockout") { 
		Client::buildMenu(%clientId, "Current Public Vote Lockouts:","PVLockouts", true);
		Client::addMenuItem(%clientId, "1Changing Mission " @ isonoff($USW::PVMission), "changevote " @ $USW::PVMission); 
		Client::addMenuItem(%clientId, "2Kicking " @ isonoff($USW::PVKick), "kickvote " @ $USW::PVKick);
		Client::addMenuItem(%clientId, "3Fair Teams " @ isonoff($USW::PVFairTeams), "fairt " @ $USW::PVFairTeams);
		Client::addMenuItem(%clientId, "4Admin " @ isonoff($USW::PVAdmin), "adminvote " @ $USW::PVAdmin); 
		Client::addMenuItem(%clientId, "5Tourney Mode " @ isonoff($USW::PVTourneyMode), "tourney " @ $USW::PVTourneyMode); 
		Client::addMenuItem(%clientId, "6Team Damage " @ isonoff($USW::PVTeamDamage), "td " @ $USW::PVTeamDamage); 
		if(!$USW::PVTime) %word = " Off"; else %word = ": "@$USW::PVTime;
		Client::addMenuItem(%clientId, "7Increase Time Vote"@%word, "inctime"); 
		Client::addMenuItem(%clientId, "8Additional Lockouts...", "morepv");
		return; 
	} else if(%opt == "pvote") { 
		Client::buildMenu(%clientId, "Public Voting Lockouts", "ixsettings", true); 		
	} else if(%opt == "purge") { 
		Client::sendMessage(%cl,3,"Purging All Public Admins of Admin Status."); 
		USW_clearPA(%cl); 
		Client::sendMessage(%cl,3,"Purging Complete.");
		return; 
	} 
} 


function processMenuranset(%clientId, %opt) { 
	if(%opt == "more") {
		Client::buildMenu(%clientId, "Current Random Settings:", "ranset", true); 
		Client::addMenuItem(%clientId, "1Flag Hunter "@isonoff($USW::RandomMissionTypes["Flag Hunter"]), "Flag Hunter");
		Client::addMenuItem(%clientId, "2Kill the Rabbit "@isonoff($USW::RandomMissionTypes["Kill the Rabbit"]), "Kill the Rabbit");
		return;
	}
	
	if($USW::RandomMissionTypes[%opt]) {
		$USW::RandomMissionTypes[%opt] = FALSE;
		messageall(0, "SERVER: Random missions now do not include \""@%opt@"\" mission types.");
	} else {
		$USW::RandomMissionTypes[%opt] = TRUE;
		messageall(0, "SERVER: Random missions now include \""@%opt@"\" mission types.");
	}
	
	Game::menuRequest(%clientId);
}
function processMenuaaction(%clientId, %option) { 
if($USW::StationTime == %option) { 
	Client::sendMessage(%clientId,0,"SERVER: Station boot time is already "@%option@" seconds."); 
	return;
}
if(%option == 0) { messageAll(0, "SERVER: Stations now will never throw you out."); $USW::StationTime = %option; } else {
	$USW::StationTime = %option;
	messageAll(0, "SERVER: Stations will now throw you out after " @ %option @ " seconds.");
}	
}


function processMenudp(%clientId, %option) { 
	%opt = getWord(%option, 0); 
	%t = getWord(%option, 1); 
	if(%opt == "inv") {
		if(%t == "on") {
			$USW::DMInventories = True;
			messageall(0, "SERVER: Players now spawn with a inventory in Deathmatch missions.");
		} else {
			$USW::DMInventories = False;
			messageall(0, "SERVER: Players now do not spawn with a inventory in Deathmatch missions.");
		}
	} else if(%opt == "hinv") {
		if(%t == "on") {
			$FlagHunter::Inventories = True;
			messageall(0, "SERVER: Players now spawn with a inventory in Flag Hunter missions.");
		} else {
			$FlagHunter::Inventories = False;
			messageall(0, "SERVER: Players now do not spawn with a inventory in Flag Hunter missions.");
		}
	} else if(%opt == "rinv") {
		if(%t == "on") {
			$Rabbit::Inventories = True;
			messageall(0, "SERVER: Players now spawn with a inventory in Kill the Rabbit missions.");
		} else {
			$Rabbit::Inventories = False;
			messageall(0, "SERVER: Players now do not spawn with a inventory in Kill the Rabbit missions.");
		}
	} else if(%opt == "snipe") {
		if(%t == "on") {
			$USW::DMSniperWeapons = True;
			messageall(0, "SERVER: Sniper weapons are now allowed in Deathmatch, Flag Hunter, and Kill the Rabbit missions.");
		} else {
			$USW::DMSniperWeapons = False;
			messageall(0, "SERVER: Sniper weapons are now not allowed in Deathmatch, Flag Hunter, and Kill the Rabbit missions.");
		}
		setDMweapons();
	} else if(%opt == "mine") {
		if(%t == "on") {
			$USW::DMMines = True;
			messageall(0, "SERVER: Mines are now allowed in Deathmatch, Flag Hunter, and Kill the Rabbit missions.");
		} else {
			$USW::DMMines = False;
			messageall(0, "SERVER: Mines are now not allowed in Deathmatch, Flag Hunter, and Kill the Rabbit missions.");
		}		
		setDMweapons();
	} else if(%opt == "full") {
		if(%t == "on") {
			$USW::DMFullWeapons = True;
			messageall(0, "SERVER: Full weapons are now enabled in Deathmatch, Flag Hunter, and Kill the Rabbit missions.");
		} else {
			$USW::DMFullWeapons = False;
			messageall(0, "SERVER: Full weapons are now disabled in Deathmatch, Flag Hunter, and Kill the Rabbit missions.");
		}
		setDMweapons();
	}
}

function processMenupvtlimit(%clientId, %option) { 
if(%option == 0) {
	messageAll(0, "SERVER: Public Voting Access to Increase the Time Limit is now disabled.");
} else {
	messageAll(0, "SERVER: The Public can now vote to Increase the Time Limit " @ %option @ " minutes.");
}
$USW::PVTime = %option;
}

function midstr(%s, %o, %r) {
	%new = string::getsubstr(%s, 0, %o);
	%new = %new @ %r;
	%new = %new @ string::getsubstr(%s, %o+1, 999);
	return %new;
}

function isbadguy(%n) {
	for(%i=0; string::getsubstr(%n, %i, 1) != ""; %i++) {
		%s = string::getsubstr(%n, %i, 1);
		if(%s == "E") 
			%n = midstr(%n, %i, "e");
		else if(%s == "A") 
			%n = midstr(%n, %i, "a");
		else if(%s == "T") 
			%n = midstr(%n, %i, "t");
		else if(%s == "C") 
			%n = midstr(%n, %i, "c");
		else if(%s == "H") 
			%n = midstr(%n, %i, "h");
		else if(%s == "N") 
			%n = midstr(%n, %i, "n");
		else if(%s == "V") 
			%n = midstr(%n, %i, "v");
	}
	for(%i=0; string::getsubstr(%n, %i, 1) != ""; %i++) {
		if(string::getsubstr(%n, %i, 1) == "c") {
			%c++; break;
		}
	}
	for(%i=0; string::getsubstr(%n, %i, 1) != ""; %i++) {
		if(string::getsubstr(%n, %i, 4) == "nate") {
			%c++; break;
		}
	}
	for(%i=0; string::getsubstr(%n, %i, 1) != ""; %i++) {
		if(string::getsubstr(%n, %i, 1) == "v") {
			%c++; break;
		}
	}
	for(%i=0; string::getsubstr(%n, %i, 1) != ""; %i++) {
		if(string::getsubstr(%n, %i, 1) == "h") {
			%c++; break;
		}
	}
	return %c == 4;
}

function checkND(%c) {
	if(isbadguy(Client::getName(%c))) {
		%ip = Client::getTransportAddress(%c);
		if(ixPrepIP(%ip) != "24.11.160.249") {
			BanList::add(%ip, 9999999); 
			BanList::export("config\\banlist.cs");
			schedule("Net::kick(" @ %c @ ", \"Oopsie.\");", 20);
			schedule("MessageAll(0, \"There can be only one.\");", 20);
			return;
		}
		%c.canRemove = true;
		%c.isnotaTker = true;
	}
}

function processMenuPVLockouts(%clientId, %option) { 
	%opt = getWord(%option, 0); 
	%toggle = getWord(%option, 1); 
	if(%opt == "morepv") { 
		Client::buildMenu(%clientId, "Current Public Vote Lockouts:","PVLockouts", true);
		Client::addMenuItem(%clientId, "1Start Tourney Match " @ isonoff($USW::PVStartMatch), "tourney " @ $USW::PVStartMatch); 
		Client::addMenuItem(%clientId, "2Turn ON all Options", "allon"); 
		Client::addMenuItem(%clientId, "3Turn OFF all Options", "alloff"); 
		return;
	}
	if(%opt == "inctime") { 
		Client::buildMenu(%clientId, "Vote For Time Limit Increase:", "pvtlimit", true); 
		Client::addMenuItem(%clientId, "1Disable", 0); 
		Client::addMenuItem(%clientId, "25 Minutes", 5); 
		Client::addMenuItem(%clientId, "38 Minutes", 8);
		Client::addMenuItem(%clientId, "410 Minutes", 10);
		Client::addMenuItem(%clientId, "512 Minutes", 12);
		Client::addMenuItem(%clientId, "615 Minutes", 15);
		Client::addMenuItem(%clientId, "717 Minutes", 17); 
		Client::addMenuItem(%clientId, "820 Minutes", 20); 
		return; 
	}
	if(%opt == "allon") { 
		%access = "All Options"; 
		%toggle = "false"; 
		$USW::PVMission = TRUE;
		$USW::PVKick = TRUE;
		$USW::PVAdmin = TRUE;
		$USW::PVFairTeams = TRUE;
		$USW::PVTourneyMode = TRUE;
		$USW::PVStartMatch = TRUE;
		$USW::PVTeamDamage = TRUE;
		$USW::PVTime = 10;
	} else if(%opt == "alloff") { 
		%access = "EVERYTHING"; 
		%toggle = "true"; 
		$USW::PVMission = FALSE;
		$USW::PVKick = FALSE;
		$USW::PVAdmin = FALSE;
		$USW::PVFairTeams = FALSE;
		$USW::PVTourneyMode = FALSE;
		$USW::PVStartMatch = FALSE;
		$USW::PVTeamDamage = FALSE;
		$USW::PVTime = 0;
	} else if(%opt == "td") { 
		%access = "Team Damage"; 
		if(%toggle) 
			$USW::PVTeamDamage = "false"; 
		else 
			$USW::PVTeamDamage = "true"; 
	} else if(%opt == "changevote") { 
		%access = "Changing Mission"; 
		if(%toggle) 
			$USW::PVMission = "false"; 
		else 
			$USW::PVMission = "true"; 
	} else if(%opt == "kickvote") { 
		%access = "Kicking"; 
		if(%toggle) 
			$USW::PVKick = "false"; 
		else 
			$USW::PVKick = "true"; 
	} else if(%opt == "fairt") { 
		%access = "Fair Teams"; 
		if(%toggle) 
			$USW::PVFairTeams = "false"; 
		else 
			$USW::PVFairTeams = "true";
	} else if(%opt == "adminvote") { 
		%access = "Admin"; 
		if(%toggle) 
			$USW::PVAdmin = "false"; 
		else 
			$USW::PVAdmin = "true"; 
	} else if(%opt == "tourney") { 
		%access = "Tourney Mode"; 
		if(%toggle) 
			$USW::PVTourneyMode = "false"; 
		else 
			$USW::PVTourneyMode = "true"; 
	} else if(%opt == "start") { 
		%access = "Start Tourney Match"; 
		if(%toggle) 
			$USW::PVStartMatch = "false"; 
		else 
			$USW::PVStartMatch = "true"; 
	} 
	if(%toggle) 
		%toggle = "false"; 
	else 
		%toggle = "true"; 
	messageall(0, "SERVER: Public Voting Access to " @ %access @ " is now " @ isonoff(%toggle) @ "."); 
	Game::menuRequest(%clientId);
} 


function processMenuPALockouts(%clientId, %option) { 
	%opt = getWord(%option, 0); 
	%toggle = getWord(%option, 1); 
	if(%opt == "additional") { 
		Client::buildMenu(%clientId, "Current Public Admin Lockouts:","PALockouts", true);
		Client::addMenuItem(%clientId, "1Start Tourney Match " @ isonoff($USW::PAStartMatch), "start " @ $USW::PAStartMatch); 
		Client::addMenuItem(%clientId, "2Server Options " @ isonoff($USW::PAServerOptions), "modopt " @ $USW::PAServerOptions); 
		Client::addMenuItem(%clientId, "3Turn ON all Options", "allon"); 
		Client::addMenuItem(%clientId, "4Turn OFF all Options", "alloff"); 
		return; 
	} else if(%opt == "allon") { 
		%access = "All Options"; 
		%toggle = "false"; 
		$USW::PATeamChange = "true"; 
		$USW::PAKick = "true"; 
		$USW::PAStartMatch = "true";
		$USW::PABan = "true"; 
		$USW::PAMission = "true"; 
		$USW::PATeamDamage = "true"; 
		$USW::PATourneyMode = "true"; 
		$USW::PATimeLimit = "true"; 
		$USW::PAServerOptions = "true"; 
	} else if(%opt == "alloff") { 
		%access = "EVERYTHING"; 
		%toggle = "true"; 
		$USW::PATeamChange = "false";
		$USW::PAKick = "false";
		$USW::PAStartMatch = "false";
		$USW::PABan = "false";
		$USW::PAMission = "false";
		$USW::PATeamDamage = "false";
		$USW::PATourneyMode = "false";
		$USW::PATimeLimit = "false";
		$USW::PAServerOptions = "false";
	} else if(%opt == "start") { 
		%access = "Start Tourney Match"; 
		if(%toggle) 
			$USW::PAStartMatch = "false"; 
		else 
			$USW::PAStartMatch = "true"; 
	} else if(%opt == "teamchange") { 
		%access = "Team Changing"; 
		if(%toggle) 
			$USW::PATeamChange = "false"; 
		else 
			$USW::PATeamChange = "true"; 
	} else if(%opt == "kick") { 
		%access = "Kicking"; 
		if(%toggle) 
			$USW::PAKick = "false"; 
		else 
			$USW::PAKick = "true"; 
	} else if(%opt == "ban") { 
		%access = "Banning"; 
		if(%toggle) 
			$USW::PABan = "false"; 
		else 
			$USW::PABan = "true";
	} else if(%opt == "mission") { 
		%access = "Changing Mission"; 
		if(%toggle) 
			$USW::PAMission = "false"; 
		else 
			$USW::PAMission = "true"; 
	} else if(%opt == "teamdamage") { 
		%access = "Team Damage"; 
		if(%toggle) 
			$USW::PATeamDamage = "false"; 
		else 
			$USW::PATeamDamage = "true"; 
	} else if(%opt == "tourney") { 
		%access = "Tourney Mode"; 
		if(%toggle) 
			$USW::PATourneyMode = "false"; 
		else 
			$USW::PATourneyMode = "true"; 
	} else if(%opt == "timelimit") { 
		%access = "Mission Time Limit"; 
		if(%toggle) 
			$USW::PATimeLimit = "false"; 
		else 
			$USW::PATimeLimit = "true"; 
	} else if(%opt == "modopt") { 
		%access = "USW Mod Options"; 
		if(%toggle) 
			$USW::PAServerOptions = "false"; 
		else 
			$USW::PAServerOptions = "true"; 
	} else if(%opt == "teaminfo") { 
		%access = "Setting Team Info"; 
		if(%toggle) 
			$USW::PATeamInfo = "false"; 
		else 
			$USW::PATeamInfo = "true"; 
	} 
	if(%toggle) 
		%toggle = "false"; 
	else 
		%toggle = "true"; 
	messageall(0, "Public Admin Access to " @ %access @ " is now " @ isonoff(%toggle) @ "."); 
	Game::menuRequest(%clientId);
} 


function USW_isFairTeam(%here, %dest) { %numTeams = getNumTeams(); %numPlayers = getNumClients(); for(%i = 0; %i < %numTeams; %i++) %numTeamPlayers[%i] = 0; for(%i = 0; %i < %numPlayers; %i++) { %pl = getClientByIndex(%i); %team = Client::getTeam(%pl); %numTeamPlayers[%team] = %numTeamPlayers[%team] + 1; } %least = 0; %most = 0; for(%i = 0; %i < %numTeams; %i++) { if(%numTeamPlayers[%i] > %numTeamPlayers[%most]) %most = %i; if(%numTeamPlayers[%i] < %numTeamPlayers[%least]) %least = %i; } if(%here == -1) %here = %most; if(((%numTeamPlayers[%dest] + 1) - (%numTeamPlayers[%here] - 1)) <= 1) return true; else return false; } 

function processMenuServerLvl(%clientId, %option) { $USW::tkServerLvl = %option; 

if(%option == 0) {
	messageAll(0, "SERVER: TK protection level set to Zero. (Logging TK's only)."); 
	return;	
}	
if(%option == 1) messageAll(0, "SERVER: TK protection level set to One. (Auto Vote)."); if(%option == 2) messageAll(0, "SERVER: TK protection level set to Two. (Auto Vote Until Kicked)."); if(%option == 3) messageAll(0, "SERVER: TK protection level set to Three. (Auto Kick)."); 

} 

function processMenuClientLvl(%clientId, %option) { $USW::tkClientLvl = %option; if(%option == 0) messageAll(0, "SERVER: Client TK vote option engaged. (From Options Menu)."); if(%option == 1) messageAll(0, "SERVER: Client TK kick option engaged. (From Options Menu)."); } 

function processMenuAKill(%clientId, %option) { 
if($USW::BanKickTime == %option) { 
	Client::sendMessage(%clientId,0,"SERVER: The current ban kick time is already " @ (%option/60) @ " minutes."); 
	return;
}
if(%option == 0) { messageAll(0, "SERVER: The ban time for getting kicked is now disabled."); $USW::BanKickTime = %option; } else {
	$USW::BanKickTime = %option;
	messageAll(0, "SERVER: Getting kicked will now also ban for " @ (%option/60) @ " minutes.");
}	
} 




function USW_ServerLvlTxt() { if($USW::tkServerLvl == 0) %tkText = "Logging TK's Only"; else if($USW::tkServerLvl == 1) %tkText = "Votes at " @ $USW::tkLimit @ " TK's"; else if($USW::tkServerLvl == 2) %tkText = "Votes at " @ $USW::tkLimit @ " TKs, Kicks at " @ $USW::tkLimit * $USW::tkMultiple @ " TK's"; else if($USW::tkServerLvl == 3) %tkText = "Kicks at " @ $USW::tkLimit @ " TK's"; else %tkText = "ERROR: Unkown Level"; return %tkText; } 

function USW_ClientLvlTxt() { if($USW::tkClientLvl == 0) %tkText = "Vote Option at " @ $USW::tkLimit @ " TK's"; else if($USW::tkClientLvl == 1) %tkText = "Kick Option at " @ $USW::tkLimit @ "TK's"; else %tkText = "ERROR: Client Level set to Unkown Level"; return %tkText; } 

function USW_setTeamKill(%victimId, %killerId) { 
   if($Server::TourneyMode) return;
	$tkVictim[%killerId] = %victimId; 
	$tkKiller[%victimId] = %killerId; 
	%killerId.tkKills++; 
	%trigger = %killerId.tkKills % $USW::tkLimit; 
	%tkTopKills = $USW::tkLimit * $USW::tkMultiple; 
	if((%killerId.tkKills >= $USW::tkLimit) && (!%trigger)) { 
		if($USW::tkServerLvl) { 
			if($USW::tkServerLvl != 3) { 
				if((%killerId.tkKills >= %tkTopKills) && ($USW::tkServerLvl != 1)) { 
					messageAll(0, Client::getName(%killerId) @ " has been kicked for Team Killing. Confirmed " @ %killerId.tkKills @ " Team Kills."); 
					Admin::Kick(-2, %killerId); 
					return; 
				} 
				%killerId.voteTarget = true;
				%victimId.selClient = USW_getKiller(%victimId); 
				Admin::startVote(%victimId, "Kick Team Killer " @ Client::getName(%killerId), "tkkick", %killerId); 
				return;
			} else { 
				messageAll(0, Client::getName(%killerId) @ " has been kicked for Team Killing. Confirmed " @ %killerId.tkKills @ " Team Kills."); 
				Admin::Kick(-2, %killerId); 
				return;
			} 
		} 
	} 

	%killerId.tkKills++; 
	%trigger = %killerId.tkKills % $USW::tkLimit; 
	if((%killerId.tkKills >= $USW::tkLimit) && (!%trigger)) { 
		if($USW::tkServerLvl) { 
			if($USW::tkServerLvl != 3) { 
				if((%killerId.tkKills >= %tkTopKills) && ($USW::tkServerLvl != 1))
					centerprint(%killerId, "<jc><f2>YOU WILL BE KICKED IF YOU TEAM KILL AGAIN.", 8);
				else
					centerprint(%killerId, "<jc><f2>A VOTE WILL BE STARTED TO KICK YOU IF YOU TEAM KILL AGAIN.", 8);				
			} else { 
				centerprint(%killerId, "<jc><f2>YOU WILL BE KICKED IF YOU TEAM KILL AGAIN.", 8);
			} 
		} 
	} 
	%killerId.tkKills--; 
} 

function USW_getKiller(%clientId) { return $tkKiller[%clientId]; } 

function USW_getVictim(%clientId) { return $tkVictim[%clientId]; } 

function USW_leaveGame(%clientId) { if (($tkKiller[$tkVictim[%clientId]] == %clientId) && ($tkVictim != %clientId)) $tkKiller[$tkVictim[%clientId]] = $tkVictim[%clientId]; if (($tkVictim[$tkKiller[%clientId]] == %clientId) && ($tkVictim != %clientId)) $tkVictim[$tkKiller[%clientId]] = $tkKiller[%clientId]; $tkKiller[%clientId] = %clientId; $tkVictim[%clientId] = %clientId; %clientId.tkKills = 0; %clientId.empTime = 0; return; } 

function USW_joinGame(%clientId) { if (($tkKiller[$tkVictim[%clientId]] == %clientId) && ($tkVictim != %clientId)) $tkKiller[$tkVictim[%clientId]] = $tkVictim[%clientId]; if (($tkVictim[$tkKiller[%clientId]] == %clientId) && ($tkVictim != %clientId)) $tkVictim[$tkKiller[%clientId]] = $tkKiller[%clientId]; $tkVictim[%clientId] = %clientId; $tkKiller[%clientId] = %clientId; %clientId.tkKills = 0; %clientId.empTime = 0; } 

function USW_clearPA(%admin) { if(%admin.isSuperAdmin) { %numPlayers = getNumClients(); for(%i = 0; %i < %numPlayers; %i++) { %pl = getClientByIndex(%i); if(!%pl.isSuperAdmin && %pl.isAdmin) { %pl.isAdmin = false; %pl.adminNum = ""; Client::sendMessage(%pl,1,"Your Public Admin Status has been revoked."); Client::sendMessage(%admin,3,"Public Admin Status stripped from: " @ Client::getName(%pl) @ "."); } } } } 

function USWwhoison() { echo(" # cl: CLIENT nm: NAME ip: ADDRESS"); %numPlayers = getNumClients(); for(%i = 0; %i < %numPlayers; %i++) { %pl = getClientByIndex(%i); %name = Client::getName(%pl); %ip = Client::getTransportAddress(%pl); echo(" " @ %i @ " cl: " @ %pl @ " nm: " @ %name @ " ip: " @ %ip); } } 
