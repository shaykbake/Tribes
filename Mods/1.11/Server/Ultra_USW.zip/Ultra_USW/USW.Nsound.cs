////////////FlameTurret////////////
SoundData SoundFlameTurret
{
   wavFileName = "flyer_fly.wav";
   profile = Profile3dMedium;
};

////////////ObeliskOfLight////////////
SoundData SoundBuzz
{
   wavFileName = "targetlaser.wav";
   profile = Profile3dMediumLoop;
};
