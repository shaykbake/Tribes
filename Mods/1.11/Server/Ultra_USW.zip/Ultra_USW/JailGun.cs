//=====Baseprojdata=====//
$JailDamageType         = 24;	//=== various


RocketData JailDart
{
	bulletShapeName  = "bullet.dts";
	explosionTag     = bulletExp0;
	collisionRadius  = 0.0;
	mass             = 0.2;
	damageClass      = 0;
	damageValue      = 0.37;
	damageType       = $JailDamageType;
	explosionRadius  = 0.1;
	bulletHoleIndex  = 0;
	kickBackStrength = 600.0;
	muzzleVelocity   = 9000;// 3500.0;
	terminalVelocity = 9000;// 3500.0;
	acceleration     = 500.0;
	totalTime        = 10.0;
	liveTime         = 11.0;
	lightRange       = 10.0;
	lightColor       = { 0.25, 0.25, 1 };
	inheritedVelocityScale = 0.0;
	soundId = SoundJetHeavy;
};

//=======Item.cs=======//
$AutoUse[JailRifle] = False;
$WeaponAmmo[JailRifle] = "";



//======================================================================= Jail Rifle

ItemImageData JailRifleImage
{
	shapeFile = "sniper";
	mountPoint = 0;
	minEnergy = 10;
	maxEnergy = 0.01;// 50;
	weaponType = 0;
	ammoType = "";
	projectileType = JailDart;
	accuFire = true;
	reloadTime = 0;
	fireTime = 0.01;

	lightType = 3;
	lightRadius = 6;
	lightTime = 2;
	lightColor = { 1.0, 0, 0 };
	sfxFire = SoundDryFire;
	sfxActivate = SoundPickUpWeapon;
	
};

ItemData JailRifle
{
	description = "Jail Rifle";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "targetlaser";
	heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = JailRifleImage;
	price = 375;
	showWeaponBar = true;
	
	validateShape = true;
	validateMaterials = false;
};

//========Station.cs=====//
$InvList[JailRifle] = 1;
$RemoteInvList[JailRifle] = 1;

//======Armordata.cs========//

$ItemMax[larmor, JailRifle] = 1;
$ItemMax[marmor, JailRifle] = 1;
$ItemMax[harmor, JailRifle] = 1;
$ItemMax[lfemale, JailRifle] = 1;
$ItemMax[mfemale, JailRifle] = 1;		