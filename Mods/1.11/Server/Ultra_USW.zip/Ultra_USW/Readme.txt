You might wanna print this out till ya get the "shortcut keys" down pat.

Control -1 = LiL POO mki
Control - 2 = Double Plasma  <<Doesnt work yet :-(
Control - 3 = Repair Rifle
Control - 4 = Jail Rifle
Control - 5 = Plasma Cannon
Control - 6 = Tank Shredder
Control - 7 = MineLauncher
Control - 8 = Claymor Mine

Shift - L = Light Armor
Shift - M = Medium Armor
Shift - H = Heavy Armor
Shift - G = Giveall(); 
Shift - 1 = Laser Turret
Shift - 2 =  Mini - Plasma Turret
Shift - 3 = Rail Turret
Shift - 4 = Mini - Beam of Pain
Shift - 5 = Repair Turret
Shift - 6 = Fireball Turret
Shift - 7 = Motion Sensor
Shift - 8 = Repair Pack
Shift - 9 = StealthShield Pack
Shift - 0 = Portable Generator

Alt - 1 = GOD SHIELD
Alt - 2 = Chaingun Turret
Alt - 3 = Stupiddr's mine-plasma turret
Alt - 4 = USW Wall
Alt - 5 = Portable Hole (My portal ive been working on for a YEAR)

