	//----------------------------------------------------------------------------
$ItemFavoritesKey = "USW";  // Change this if you add new items
                         // and don't want to mess up everyone's
                         // favorites - just put in something
                         // that uniquely describes your new stuff.

//----------------------------------------------------------------------------

$ItemPopTime = 3;

$ToolSlot=0;
$WeaponSlot=0;
$BackpackSlot=1;
$FlagSlot=2;
$DefaultSlot=3;

$AutoUse[Blaster] = False;
$AutoUse[Chaingun] = False;
$AutoUse[PlasmaGun] = False;
$AutoUse[Mortar] = False;
$AutoUse[GrenadeLauncher] = False;
$AutoUse[LaserRifle] = False;
$AutoUse[EnergyRifle] = False;
$AutoUse[TargetingLaser] = False;
$AutoUse[ChargeGun] = False;

//--USW

$AutoUse[FireballAbility] = False;
$AutoUse[SmScreenAbility] = False;
$AutoUse[ExSmScreenAbility] = False;
$AutoUse[FireScreenAbility] = False;
$AutoUse[SpellAbility] = False;
$AutoUse[TaserRifle] = False;
$AutoUse[LiLFFB] = False;
$AutoUse[LiLPOOmkii] = False;
$AutoUse[LiLPOOmki] = False;
$AutoUse[LiLRocketLauncher] = False;
$AutoUse[LiLEMPRocketLauncher] = False;
$AutoUse[BeamOfPain] = False;
$AutoUse[JailGun] = True;
$AutoUse[PlasmaCannon] = True;
$AutoUse[Stinger] = false;
$AutoUse[TankShredder] = false;
$AutoUse[TankRPGLauncher] = false;
$AutoUse[TRocketLauncher] = false;
$AutoUse[HDiscLauncher] = True;

//--USW-

$Use[Blaster] = False;

$ArmorType[Male, LightArmor] = larmor;
$ArmorType[Male, MediumArmor] = marmor;
$ArmorType[Male, HeavyArmor] = harmor;
$ArmorType[Female, LightArmor] = lfemale;
$ArmorType[Female, MediumArmor] = mfemale;	   
$ArmorType[Female, HeavyArmor] = harmor;

$ArmorName[larmor] = LightArmor;
$ArmorName[marmor] = MediumArmor;
$ArmorName[harmor] = HeavyArmor;
$ArmorName[lfemale] = LightArmor;
$ArmorName[mfemale] = MediumArmor;

// Amount to remove when selling or dropping ammo
$SellAmmo[BulletAmmo] = 50;
$SellAmmo[PlasmaAmmo] = 50;
$SellAmmo[DiscAmmo] = 50;
$SellAmmo[GrenadeAmmo] = 5;
$SellAmmo[MortarAmmo] = 5;
$SellAmmo[Beacon] = 5;
$SellAmmo[MineAmmo] = 5;
$SellAmmo[Grenade] = 5;
$SellAmmo[RadiusMineAmmo] = 5;
$SellAmmo[USWGasAttackAmmo] = 5;
$SellAmmo[FlashGrenade] = 5;
$SellAmmo[LiLBoostammo] = 5;

//--USW--

$SellAmmo[FireballAbilityAmmo] = 50;
$SellAmmo[SmScreenAbilityAmmo] = 50;
$SellAmmo[ExSmScreenAbilityAmmo] = 50;
$SellAmmo[FireScreenAbilityAmmo] = 50;
$SellAmmo[SpellAbilityAmmo] = 50;

$SellAmmo[LiLPOOmkiiAmmo] = 50;
$SellAmmo[LiLPOOmkiAmmo] = 50;
$SellAmmo[LiLFFBAmmo] = 50;
$SellAmmo[LiLRocketLauncherAmmo] = 50;
$SellAmmo[LiLEMPRocketLauncherAmmo] = 50;
$SellAmmo[StingerAmmo] = 5;
$SellAmmo[TankShredderAmmo] = 500;
$SellAmmo[TankRPGAmmo] = 150;
$SellAmmo[DualDiscs] = 50;

//--USW--

// Max Amount of ammo the Ammo Pack can carry
$AmmoPackMax[BulletAmmo] = 999;
$AmmoPackMax[PlasmaAmmo] = 450;// 30;
$AmmoPackMax[DiscAmmo] = 750;// 15;
$AmmoPackMax[GrenadeAmmo] = 15;
$AmmoPackMax[MortarAmmo] = 55;// 10;
$AmmoPackMax[MineAmmo] = 200;// 5;
$AmmoPackMax[Grenade] = 200;// 10;
$AmmoPackMax[Beacon] = 200;// 10;
$AmmoPackMax[TankRPGAmmo] = 999;

// Items in the AmmoPack
$AmmoPackItems[0] = BulletAmmo;
$AmmoPackItems[1] = PlasmaAmmo;
$AmmoPackItems[2] = DiscAmmo;
$AmmoPackItems[3] = GrenadeAmmo;
$AmmoPackItems[4] = Grenade;
$AmmoPackItems[5] = MineAmmo;
$AmmoPackItems[6] = MortarAmmo;
$AmmoPackItems[7] = Beacon;
$AmmoPackItems[8] = TankRPGAmmo;


// Limit on number of special Items you can buy
$TeamItemMax[DeployableAmmoPack] = 7;
$TeamItemMax[DeployableInvPack] = 10;// 5;
$TeamItemMax[TurretPack] = 10;
$TeamItemMax[CameraPack] = 5;
$TeamItemMax[DeployableSensorJammerPack] = 0;
$TeamItemMax[PulseSensorPack] = 0;
$TeamItemMax[MotionSensorPack] = 10;
$TeamItemMax[ScoutVehicle] = 10;
$TeamItemMax[HAPCVehicle] = 10;
$TeamItemMax[LAPCVehicle] = 12;
$TeamItemMax[Beacon] = 500;
$TeamItemMax[mineammo] = 500;
$TeamItemMax[jailpack] = 1;
$TeamItemMax[BlastWall] = 20;
$TeamItemMax[hugewall] = 20;

//--USW-
$TeamItemMax[TaserTrtBPack] = 10;
$TeamItemMax[TaserTrtCPack] = 10;
$TeamItemMax[LaserTurretPack] = 10;
$TeamItemMax[LaserTurretBPack] = 10;
$TeamItemMax[MiniFlakTurretPack] = 10;
$TeamItemMax[MiniSAMTurretPack] = 20;// 10;
$TeamItemMax[MiniELFTurretPack] = 10;
$TeamItemMax[MiniSmokeTurretPack] = 10;
$TeamItemMax[RailTurret] = 10;// 3;
$TeamItemMax[ChaingunTurretPack] = 55;// 3;
$TeamItemMax[TurretPack] = 10;// 5;
$TeamItemMax[SeekerPack] = 50;// 2;

$TeamItemMax[lgaForceFieldPack] = 12;
$TeamItemMax[lgbForceFieldPack] = 12;
$TeamItemMax[medaForceFieldPack] = 20;// 12;
$TeamItemMax[medbForceFieldPack] = 12;
$TeamItemMax[medcForceFieldPack] = 50;// 12;
$TeamItemMax[ArbitorBoxPack] = 2;// 1;
$TeamItemMax[ForceFieldFloorPack] = 20;// 12;
$TeamItemMax[DeployableSolarPanel] = 2;
$TeamItemMax[HolePack] = 10;// 3;
$TeamItemMax[hologram] = 15;
$TeamItemMax[ShockFloorPack] = 25;
$TeamItemMax[ForceFieldDoorPack] = 25;

$TeamItemMax[DeployableTeleport] = 4;
$TeamItemMax[cactuspack] = 4;

$TeamItemMax[radiusmineammo] = 1;
$TeamItemMax[USWGasAttackAmmo] = 500;
$TeamItemMax[flashgrenade] = 500;
$TeamItemMax[lilboost] = 500;
$TeamItemMax[JailCapPack] = 50;
$TeamItemMax[SuicidePack] = 500;

//--USW


// Global object damage skins (staticShapes Turrets Stations Sensors)
DamageSkinData objectDamageSkins
{
   bmpName[0] = "dobj1_object";
   bmpName[1] = "dobj2_object";
   bmpName[2] = "dobj3_object";
   bmpName[3] = "dobj4_object";
   bmpName[4] = "dobj5_object";
   bmpName[5] = "dobj6_object";
   bmpName[6] = "dobj7_object";
   bmpName[7] = "dobj8_object";
   bmpName[8] = "dobj9_object";
   bmpName[9] = "dobj10_object";
};

// Weapon to ammo table
$WeaponAmmo[Blaster] = "";
$WeaponAmmo[PlasmaGun] = PlasmaAmmo;
$WeaponAmmo[Chaingun] = BulletAmmo;
$WeaponAmmo[DiscLauncher] = DiscAmmo;
$WeaponAmmo[GrenadeLauncher] = GrenadeAmmo;
$WeaponAmmo[Mortar] = Mortarammo;
$WeaponAmmo[LaserRifle] = "";
$WeaponAmmo[EnergyRifle] = "";

//--USW-
$WeaponAmmo[TaserRifle] = "";
$WeaponAmmo[BeamOfPain] = "";
$WeaponAmmo[JailGun] = "";
$WeaponAmmo[PlasmaCannon] = "";
$WeaponAmmo[Stinger] = StingerAmmo;
$WeaponAmmo[TankRPGLauncher] = TankRPGAmmo;
$WeaponAmmo[TRocketLauncher] = TRocketLauncherAmmo;

$WeaponAmmo[LiLFFB] = LiLFFBammo;
$WeaponAmmo[LiLPOOmkii] = LiLPOOmkiiammo;
$WeaponAmmo[LiLPOOmki] = LiLPOOmkiammo;
$WeaponAmmo[LiLRocketLauncher] = LiLRocketLauncherammo;
$WeaponAmmo[LiLEMPRocketLauncher] = LiLEMPRocketLauncherammo;
$WeaponAmmo[TankShredder] = TankShredderAmmo;
$WeaponAmmo[HDiscLauncher] = DualDiscs;


$WeaponAmmo[FireballAbility] = FireballAbilityAmmo;
$WeaponAmmo[SmScreenAbility] = SmScreenAbilityAmmo;
$WeaponAmmo[ExSmScreenAbility] = ExSmScreenAbilityAmmo;
$WeaponAmmo[FireScreenAbility] = FireScreenAbilityAmmo;
$WeaponAmmo[SpellAbility] = SpellAbilityAmmo;

//--USW


//----------------------------------------------------------------------------
// Server side methods
// The client side inventory dialogs call buyItem, sellItem,
// useItem and dropItem through remoteEvals.

function teamEnergyBuySell(%player,%cost)
{
	%client = Player::getClient(%player);
	%team = Client::getTeam(%client);
	// IF - Cost positive selling    IF - Cost Negitive buying 
	%station = %player.Station;
	%stationName = GameBase::getDataName(%station); 
	if(%stationName == DeployableInvStation || %stationName == DeployableAmmoStation) {
		%station.Energy += %cost;			//Remote StationEnergy
		if(%station.Energy < 1)
			%station.Energy = 0;
	}
	else if($TeamEnergy[%team] != "Infinite") { 
		$TeamEnergy[%team] += %cost;    //Total TeamEnergy
 		%client.teamEnergy += %cost;   //Personal TeamEnergy
	}
}

function isPlayerBusy(%client)
{
	// Can't buy things if busy shooting.
	%state = Player::getItemState(%client,$WeaponSlot);
	return %state == "Fire" || %state == "Reload";
}

function remoteBuyFavorites(%client,%favItem0,%favItem1,%favItem2,%favItem3,%favItem4,%favItem5,%favItem6,%favItem7,%favItem8,%favItem9,%favItem10,%favItem11,%favItem12,%favItem13,%favItem14,%favItem15,%favItem16,%favItem17,%favItem18,%favItem19)
{

	if(!%client.observerMode == "" || $loadingMission == "true" || $matchStarted == "false" || %client.guiLock == "true")  //you don't need favs if any of these conditions are true -- Y|yukichigai
	{
		return;
	}

   // only can buy fav every 1/2 second
   %time = getIntegerTime(true) >> 4; // int half seconds
   if(%time <= %client.lastBuyFavTime)
      return;

   %client.lastBuyFavTime = %time;

	%station = (Client::getOwnedObject(%client)).Station;
	if(%station != "" ) {
		%stationName = GameBase::getDataName(%station); 
		if(%stationName == DeployableInvStation || %stationName == DeployableAmmoStation) 
			%energy = %station.Energy;
		else 
			%energy = $TeamEnergy[Client::getTeam(%client)];
		if(%energy == "Infinite" || %energy > 0) {
			%error = 0;
			%bought = 0;
			%max = getNumItems();
			for (%i = 0; %i < %max; %i = %i + 1) { 
				%item = getItemData(%i);
				if ($ServerCheats || Client::isItemShoppingOn(%client,%item)|| $TestCheats) {
					%count = Player::getItemCount(%client,%item);
					if(%count) {
						if(%item.className != Armor) 
							teamEnergyBuySell(Client::getOwnedObject(%client),(%item.price * %count));
						Player::setItemCount(%client, %item, 0);  
					}
				}
			}
			for (%i = 0; %i < 20; %i++) 
			{ 
				if(%favItem[%i] != "") 
				{
					%item = getItemData(%favItem[%i]);
					if ((Client::isItemShoppingOn(%client,%item)) && ($ItemMax[Player::getArmor(%client),  %item] > Player::getItemCount(%client,%item) || %item.className == Armor)) 
					{
						if(!buyItem(%client,%item))  
							%error = 1;
						else
							%bought++;
					}
				}
		  	}
			if(%bought) {
				if(%error) 
					Client::sendMessage(%client,0,"~wC_BuySell.wav");
				else 
					Client::SendMessage(%client,0,"~wbuysellsound.wav");
			}
			updateBuyingList(%client);
		}
	}
}


function replenishTeamEnergy(%team)
{
	$TeamEnergy[%team] += $incTeamEnergy;
	schedule("replenishTeamEnergy(" @ %team @ ");", $secTeamEnergy);
}


function checkResources(%player,%item,%delta,%noMessage)
{
	%client = Player::getClient(%player);
	%team = Client::getTeam(%client);
	%extraAmmo = 0 ;
	if (Player::getMountedItem(%client,$BackpackSlot) == ammopack && $AmmoPackMax[%item] != "") {
		%extraAmmo = $AmmoPackMax[%item];
		if(%delta == $ItemMax[Player::getArmor(%client), %item]) 
			%delta = %delta + %extraAmmo;
	}
	if($TestCheats == 0 && %client.spawn == "") {
		%energy = $TeamEnergy[%team];
    	%station = %player.Station;
		%sName = GameBase::getDataName(%station);
		if(%sName == DeployableInvStation || %sName == DeployableAmmoStation){
			%energy = %station.Energy;
		}
		if(%energy != "Infinite") {
			if (%item.price * %delta > %energy)	
				%delta = %energy / %item.price; 
			if(%delta < 1 ) {
				if(%noMessage == "")
					Client::sendMessage(%client,0,"Couldn't buy " @ %item.description @ " - "@ %energy @ " Energy points left");
				return 0;
			}
		}
	}
	if(%item.className == Weapon) {
		%armor = Player::getArmor(%client);
		%wcount = Player::getItemClassCount(%client,"Weapon");
		if (Player::getItemClassCount(%client,"Weapon") >= $MaxWeapons[%armor]) {
			Client::sendMessage(%client,0,"To many weapons for " @ $ArmorName[%armor].description @ " to carry");
			return 0;
		}
  	}
	else if(%item == RepairPatch) {
		%pDamage = GameBase::getDamageLevel(%player);
		if(GameBase::getDamageLevel(%player) > 0) 
			return 1;
		return 0;
   }
   else if($TeamItemMax[%item] != "" && !$TestCheats) {
		if($TeamItemMax[%item] <= $TeamItemCount[%team, %item]) {
			Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
			return 0;
		}
	}
	if(%item.className != Armor && %item.className != Vehicle) {
	   %count = Player::getItemCount(%client,%item);
	  	%max = $ItemMax[(Player::getArmor(%client)), %item] + %extraAmmo ;
	   if(%delta + %count >= %max) 
			%delta = %max - %count;
	}
	return %delta;
}

function buyItem(%client,%item)
{
	%player = Client::getOwnedObject(%client);
	%armor = Player::getArmor(%client);
	if (($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats || %client.spawn) && 
			($ItemMax[%armor, %item] || %item.className == Armor || %item.className == Vehicle || $TestCheats)) {
		if (%item.className == Armor) {
			// Assign armor by requested type & gender 
			%buyarmor = $ArmorType[Client::getGender(%client), %item];
			if(%armor != %buyarmor || Player::getItemCount(%client,%item) == 0)	{
				teamEnergyBuySell(%player,$ArmorName[%armor].price);
				if(checkResources(%player,%item,1)) {
					teamEnergyBuySell(%player,$ArmorName[%buyarmor].price * -1);
					Player::setArmor(%client,%buyarmor);
					checkMax(%client,%buyarmor);
					armorChange(%client);
     				Player::setItemCount(%client, $ArmorName[%armor], 0);  
     				Player::setItemCount(%client, %item, 1);  
					if (Player::getMountedItem(%client,$BackpackSlot) == ammopack) 
						fillAmmoPack(%client);	
					return 1;
				}

				teamEnergyBuySell(%player,$ArmorName[%armor].price * -1);
			}
		}
		else if (%item.className == Backpack) {
			if($TeamItemMax[%item] != "") {						
				if($TeamItemCount[GameBase::getTeam(%client) @ %item] >= $TeamItemMax[%item])
			 	  return 0;
			 }

			// Only one backpack per armor.
			%pack = Player::getMountedItem(%client,$BackpackSlot);
			if (%pack != -1) {
				if(%pack == ammopack) 
					checkMax(%client,%armor);
				else if(%pack == EnergyPack) {
					if(Player::getItemCount(%client,"LaserRifle") > 0) {
						Client::sendMessage(%client,0,"Sold Energy Pack - Auto Selling Laser Rifle");
						remoteSellItem(%client,22);						
					}
				}	
				teamEnergyBuySell(%player,%pack.price);
				Player::decItemCount(%client,%pack);
			}			   
			if (checkResources(%player,%item,1) || $testCheats) {
				teamEnergyBuySell(%player,%item.price * -1);
				Player::incItemCount(%client,%item);
				Player::useItem(%client,%item);									 
				if(%item == ammopack) 
					fillAmmoPack(%client);
				return 1;
			}
			else if(%pack != -1) {
				teamEnergyBuySell(%player,%pack.price * -1);
				Player::incItemCount(%client,%pack);
				Player::useItem(%client,%pack);									 
				if(%pack == ammopack) 
					fillAmmoPack(%client);
			}				 
		}
		else if(%item.className == Weapon) {
			if(checkResources(%player,%item,1)) {
				if(%item == LaserRifle && Player::getItemCount(%client,"EnergyPack") == 0) {
					buyItem(%client,"EnergyPack");
					Client::sendMessage(%client,0,"Bought Laser Rifle - Auto buying Energy Pack");
				}
				Player::incItemCount(%client,%item);
				teamEnergyBuySell(%player,(%item.price * -1));
				%ammoItem =  %item.imageType.ammoType; 
				if(%ammoItem != "") {
					%delta = checkResources(%player,%ammoItem,$ItemMax[%armor, %ammoItem]);
					if(%delta || $testCheats) {
						teamEnergyBuySell(%player,(%ammoItem.price * -1 * %delta));
						Player::incItemCount(%client,%ammoitem,%delta);
					}
				}
				return 1;
			}
		}
	 	else if(%item.className == Vehicle) {
		   if($TeamItemCount[GameBase::getTeam(%client) @ %item] < $TeamItemMax[%item]) {
				%shouldBuy = VehicleStation::checkBuying(%client,%item);
				if(%shouldBuy == 1) {
					teamEnergyBuySell(%player,(%item.price * -1));
					return 1;
				}			
 				else if(%shouldBuy == 2)
					return 1;
			}
		}
		else {
			if($TeamItemMax[%item] != "") {						
				if($TeamItemCount[GameBase::getTeam(%client) @ %item] >= $TeamItemMax[%item])
			 	  return 0;
			 }
		    %delta = checkResources(%player,%item,$ItemMax[%armor, %item]);
			 if(%delta || $testCheats) {
				teamEnergyBuySell(%player,(%item.price * -1 * %delta));
				Player::incItemCount(%client,%item,%delta);
				return 1;
			}
		}
		
 	}
	return 0;
}

function armorChange(%client)
{
	%player = Client::getOwnedObject(%client);
	if(%client.respawn == "" && %player.Station != "") {
		%sPos = GameBase::getPosition(%player.Station);
		%pPos	= GameBase::getPosition(%client);
		%posX = getWord(%sPos,0);
		%posY = getWord(%sPos,1);
		%posZ = getWord(%pPos,2);
		%vec = Vector::getFromRot(GameBase::getRotation(%player.Station),-1);	
	  	%newPosX = (getWord(%vec,0) * 1) + %posX;		 
		%newPosY = (getWord(%vec,1) * 1) + %posY;
		GameBase::setPosition(%client, %newPosX @ " " @ %newPosY @ " " @ %posZ);
	}
}

function remoteBuyItem(%client,%type)
{
	if (isPlayerBusy(%client))
		return;

	%item = getItemData(%type);
	if(buyItem(%client,%item)) {
 		Client::sendMessage(%client,0,"~wbuysellsound.wav");
		updateBuyingList(%client);
	}
	else 
  		Client::sendMessage(%client,0,"You couldn't buy "@ %item.description @"~wC_BuySell.wav");
}

function remoteSellItem(%client,%type)
{
	if (isPlayerBusy(%client))
		return;

	%item = getItemData(%type);
	%player = Client::getOwnedObject(%client);
	if ($ServerCheats || Client::isItemShoppingOn(%client,%item) || $TestCheats) {
		if(Player::getItemCount(%client,%item) && %item.className != Armor) {
			%numsell = 1;
			if(%item.className == Ammo || %item.className == HandAmmo) {
				%count = Player::getItemCount(%client, %item);
				if(%count < $SellAmmo[%item]) 
					%numsell = %count; 
				else 
					%numsell = $SellAmmo[%item];
			}
			else if (%item == ammopack) 
				checkMax(%client,Player::getArmor(%client));
			else if($TeamItemMax[%item] != "") {
				if(%item.className == Vehicle) 
					$TeamItemCount[(Client::getTeam(%client)) @ %item]--;
			}
			else if(%item == EnergyPack) { 
				if(Player::getItemCount(%client,"LaserRifle") > 0) {
					Client::sendMessage(%client,0,"Sold Energy Pack - Auto Selling Laser Rifle");
					remoteSellItem(%client,22);						
				}
			}
			teamEnergyBuySell(%player,%item.price * %numsell);
			Player::setItemCount(%player,%item,(%count-%numsell));
			updateBuyingList(%client);
			Client::SendMessage(%client,0,"~wbuysellsound.wav");
			return 1;
		}
	}
	Client::sendMessage(%client,0,"Cannot sell item ~wC_BuySell.wav");
}

function remoteUseItem(%client,%type)
{
	//echo("Use item: " @ %type @ " " @ %item);
	%client.throwStrength = 1;

	%item = getItemData(%type);
	if (%item == Backpack) 
		%item = Player::getMountedItem(%client,$BackpackSlot);
	else {
		if (%item == Weapon) 
			%item = Player::getMountedItem(%client,$WeaponSlot);
	}
	Player::useItem(%client,%item);
}

function remoteThrowItem(%client,%type,%strength)
{
	%player = Client::getOwnedObject(%client);
	if(%player.Station == "" && %player.waitThrowTime + $WaitThrowTime <= getSimTime()) {
		if(GameBase::getControlClient(%player) != -1 || %player.vehicle != "") {
		//if(GameBase::getControlClient(%player) != -1) {
	  		//echo("Throw item: " @ %type @ " " @ %strength);
			%item = getItemData(%type);
			if (%item == Grenade || %item == MineAmmo || %item == USWgasattackammo || %item == flashgrenade) {
				if (%strength < 0)
					%strength = 0;
				else
					if (%strength > 100)
						%strength = 100;
				%client.throwStrength = 0.3 + 0.7 * (%strength / 100);
				Player::useItem(%client,%item);
			}
		}
	}
}

function remoteDropItem(%client,%type)
{
	if((Client::getOwnedObject(%client)).driver != 1) {
		//echo("Drop item: ",%type);
		%client.throwStrength = 1;

		%item = getItemData(%type);
		if (%item == Backpack) {
			%item = Player::getMountedItem(%client,$BackpackSlot);
			Player::dropItem(%client,%item);
		}
	    else if (%item == Weapon) {
			%item = Player::getMountedItem(%client,$WeaponSlot);
			Player::dropItem(%client,%item);
		}
		else if (%item == Ammo) {
			%item = Player::getMountedItem(%client,$WeaponSlot);
			if(%item.className == Weapon) {
				%item = %item.imageType.ammoType;
				Player::dropItem(%client,%item);
			}
		}
		else 
			Player::dropItem(%client,%item);
	}
}

function remoteDeployItem(%client,%type)
{
    //echo("Deploy item: ",%type);
	%item = getItemData(%type);
	Player::deployItem(%client,%item);
}

//FireballAbility
//SmScreenAbility
//ExSmScreenAbility
//FireScreenAbility
//SpellAbility
//LiLRocketLauncher
//LiLEMPRocketLauncher

$NextWeapon[EnergyRifle] = HyperB;
$NextWeapon[HyperB] = Blaster;
$NextWeapon[Blaster] = PlasmaGun;
$NextWeapon[PlasmaGun] = Chaingun;
$NextWeapon[Chaingun] = LiLPOOmki;
$NextWeapon[LiLPOOmki] = LiLPOOmkii;
$NextWeapon[LiLPOOmkii] = DiscLauncher;
$NextWeapon[DiscLauncher] = FireballAbility;
$NextWeapon[FireBallAbility] = SmScreenAbility;
$NextWeapon[SmScreenAbility] = ExSmScreenAbility;
$NextWeapon[ExSmScreenAbility] = FireScreenAbility;
$NextWeapon[FireScreenAbility] = SpellAbility;
$NextWeapon[SpellAbility] = GrenadeLauncher;
$NextWeapon[GrenadeLauncher] = Mortar;
$NextWeapon[Mortar] = LiLFFB;
$NextWeapon[LiLFFB] = LiLRocketLauncher;
$NextWeapon[LiLRocketLauncher] = LiLEMPRocketLauncher;
$NextWeapon[LiLEMPRocketLauncher] = LaserRifle;
$NextWeapon[LaserRifle] = TaserRifle;
$NextWeapon[TaserRifle] = BeamOfPain;
$NextWeapon[BeamOfPain] = RepairRifle;
$NextWeapon[RepairRifle] =  JailGun;
$NextWeapon[JailGun] = PlasmaCannon;
$NextWeapon[PlasmaCannon] = Stinger;
$NextWeapon[Stinger] = TankRPGLauncher;
$NextWeapon[TankRPGLauncher] = TankShredder; 
$NextWeapon[TankShredder] = TRocketLauncher;
$NextWeapon[TRocketLauncher] = HDiscLauncher;
$NextWeapon[HDiscLauncher] = JailRifle;
$NextWeapon[JailRifle] = MineLauncher;
$NextWeapon[MineLauncher] = DetPackLauncher;
$NextWeapon[DetPackLauncher] = EnergyRifle;

$PrevWeapon[HyperB] = EnergyRifle;
$PrevWeapon[Blaster] = HyperB;
$PrevWeapon[PlasmaGun] = Blaster;
$PrevWeapon[Chaingun] = PlasmaGun;
$PrevWeapon[LiLPOOmki] = Chaingun;
$PrevWeapon[LiLPOOmkii] = LiLPOOmki;
$PrevWeapon[DiscLauncher] = LiLPOOmkii;
$PrevWeapon[FireBallAbility] = DiscLauncher;
$PrevWeapon[SmScreenAbility] = FireBallAbility;
$PrevWeapon[ExSmScreenAbility] = SmScreenAbility;
$PrevWeapon[FireScreenAbility] = ExSmScreenAbility;
$PrevWeapon[SpellAbility] = FireScreenAbility;
$PrevWeapon[GrenadeLauncher] = SpellAbility;
$PrevWeapon[Mortar] = GrenadeLauncher;
$PrevWeapon[LiLFFB] = Mortar;
$PrevWeapon[LiLRocketLauncher] = LiLFFB;
$PrevWeapon[LiLEMPRocketLauncher] = LiLRocketLauncher;
$PrevWeapon[LaserRifle] = LiLEMPRocketLauncher;
$PrevWeapon[TaserRifle] = LaserRifle;
$PrevWeapon[BeamOfPain] = TaserRifle;
$PrevWeapon[RepairRifle] = BeamOfPain;
$PrevWeapon[JailGun] = RepairRifle;
$PrevWeapon[PlasmaCannon] = JailGun;
$PrevWeapon[Stinger] = PlasmaCannon;
$PrevWeapon[TankRPGLauncher] = Stinger;
$PrevWeapon[TankShredder] = TankRPGLauncher;
$PrevWeapon[TRocketLauncher] = TankShredder;
$PrevWeapon[HDiscLauncher] = TRocketLauncher;
$PrevWeapon[JailRifle] = HDiscLauncher;
$PrevWeapon[MineLauncher] = JailRifle;
$PrevWeapon[DetPackLauncher] = MineLauncher;
$PrevWeapon[EnergyRifle] = DetPackLauncher;



function remoteNextWeapon(%client)
{
	%item = Player::getMountedItem(%client,$WeaponSlot);
	if (%item == -1 || $NextWeapon[%item] == "")
		selectValidWeapon(%client);
	else {
		for (%weapon = $NextWeapon[%item]; %weapon != %item;
				%weapon = $NextWeapon[%weapon]) {
			if (isSelectableWeapon(%client,%weapon)) {
				Player::useItem(%client,%weapon);
				// Make sure it mounted (laser may not), or at least
				// next in line to be mounted.
				if (Player::getMountedItem(%client,$WeaponSlot) == %weapon ||
						Player::getNextMountedItem(%client,$WeaponSlot) == %weapon)
					break;
			}
		}
	}
}

function remotePrevWeapon(%client)
{
	%item = Player::getMountedItem(%client,$WeaponSlot);
	if (%item == -1 || $PrevWeapon[%item] == "")
		selectValidWeapon(%client);
	else {
		for (%weapon = $PrevWeapon[%item]; %weapon != %item;
				%weapon = $PrevWeapon[%weapon]) {
			if (isSelectableWeapon(%client,%weapon)) {
				Player::useItem(%client,%weapon);
				// Make sure it mounted (laser may not), or at least
				// next in line to be mounted.
				if (Player::getMountedItem(%client,$WeaponSlot) == %weapon ||
						Player::getNextMountedItem(%client,$WeaponSlot) == %weapon)
					break;
			}
		}
	}
}

function selectValidWeapon(%client)
{
	%item = EnergyRifle;
	for (%weapon = $NextWeapon[%item]; %weapon != %item;
			%weapon = $NextWeapon[%weapon]) {
		if (isSelectableWeapon(%client,%weapon)) {
			Player::useItem(%client,%weapon);
			break;
		}
	}
}

function isSelectableWeapon(%client,%weapon)
{
	if (Player::getItemCount(%client,%weapon)) {
		%ammo = $WeaponAmmo[%weapon];
		if (%ammo == "" || Player::getItemCount(%client,%ammo) > 0)
			return true;
	}
	return false;
}


//----------------------------------------------------------------------------
// Default item scripts
//----------------------------------------------------------------------------

function Item::giveItem(%player,%item,%delta)
{
	%armor = Player::getArmor(%player);
	if($ItemMax[%armor, %item]) {		  
		%client = Player::getClient(%player);
		if (%item.className == Backpack) {
			// Only one backpack per armor, and it's always mounted
			if (Player::getMountedItem(%player,$BackpackSlot) == -1) {
		 		Player::incItemCount(%player,%item);
		 		Player::useItem(%player,%item);
				Client::sendMessage(%client,0,"You received a " @ %item @ " backpack");
		 		return 1;
			}
		}
  		else {
			// Check num weapons carried by player can't have more then max
			if (%item.className == Weapon) {
				if (Player::getItemClassCount(%player,"Weapon") >= $MaxWeapons[%armor]) 
					return 0;
			}  
			%extraAmmo = 0 ;
			if (Player::getMountedItem(%client,$BackpackSlot) == ammopack && $AmmoPackMax[%item] != "") 
				%extraAmmo = $AmmoPackMax[%item];
			// Make sure it doesn't exceed carrying capacity
			%count = Player::getItemCount(%player,%item);
			if (%count + %delta > $ItemMax[%armor, %item] + %extraAmmo) 
				%delta = ($ItemMax[%armor, %item] + %extraAmmo) - %count;
			if (%delta > 0) {
				Player::incItemCount(%player,%item,%delta);
				if (%count == 0 && $AutoUse[%item]) 
					Player::useItem(%player,%item);
				Client::sendMessage(%client,0,"You received " @ %delta @ " " @ %item.description);
				return %delta;
			}
		}
   }
	return 0;
}


//----------------------------------------------------------------------------
// Default Item object methods

$PickupSound[Ammo] = "SoundPickupAmmo";
$PickupSound[Weapon] = "SoundPickupWeapon";
$PickupSound[Backpack] = "SoundPickupBackpack";
$PickupSound[Repair] = "SoundPickupHealth";

function Item::playPickupSound(%this)
{
	%item = Item::getItemData(%this);
	%sound = $PickupSound[%item.className];
	if (%sound != "")  
		playSound(%sound,GameBase::getPosition(%this));
	else {
		// Generic item sound
		playSound(SoundPickupItem,GameBase::getPosition(%this));
	}
}	

function Item::respawn(%this)
{
	// If the item is rotating we respawn it,
	if (Item::isRotating(%this)) {
		Item::hide(%this,True);
		schedule("Item::hide(" @ %this @ ",false); GameBase::startFadeIn(" @ %this @ ");",$ItemRespawnTime,%this);
	}
	else { 
		deleteObject(%this);
	}
}	

function Item::onAdd(%this)
{
}

function Item::onCollision(%this,%object)
{
	if (getObjectType(%object) == "Player") {
		%item = Item::getItemData(%this);
		%count = Player::getItemCount(%object,%item);
		if (Item::giveItem(%object,%item,Item::getCount(%this))) {
			Item::playPickupSound(%this);
			Item::respawn(%this);
		}
	}
}


//----------------------------------------------------------------------------
// Default Inventory methods

function Item::onMount(%player,%item)
{
bottomprint(Player::getClient(%player),"<jc>Carrying: <f2>" @%item.description@"",5);
}

function Item::onUnmount(%player,%item)
{
}

function Item::onUse(%player,%item)
{
	//echo("Item used: ",%player," ",%item);
	Player::mountItem(%player,%item,$DefaultSlot);
}

function Item::pop(%item)
{
 	GameBase::startFadeOut(%item);
   schedule("deleteObject(" @ %item @ ");",2.5, %item);
}

function Item::onDrop(%player,%item)
{
	if($matchStarted) {
		if(%item.className != Armor) {
			//echo("Item dropped: ",%player," ",%item);
			%obj = newObject("","Item",%item,1,false);
 	 	  	schedule("Item::Pop(" @ %obj @ ");", $ItemPopTime, %obj);
 	 	 	addToSet("MissionCleanup", %obj);
			if (Player::isDead(%player)) 
				GameBase::throw(%obj,%player,10,true);
			else {
				GameBase::throw(%obj,%player,15,false);
				Item::playPickupSound(%obj);
			}
			Player::decItemCount(%player,%item,1);
			return %obj;
		}
	}
}

function Item::onDeploy(%player,%item,%pos)
{
}


//----------------------------------------------------------------------------
// Flags
//----------------------------------------------------------------------------

function Flag::onUse(%player,%item)
{
	Player::mountItem(%player,%item,$FlagSlot);
}


//----------------------------------------------------------------------------

ItemImageData FlagImage
{
	shapeFile = "flag";
	mountPoint = 2;
	mountOffset = { 0, 0, -0.35 };
	mountRotation = { 0, 0, 0 };

	lightType = 2;   // Pulsing
	lightRadius = 4;
	lightTime = 1.5;
	lightColor = { 1, 1, 1};
};

ItemData Flag
{
	description = "Flag";
	shapeFile = "flag";
	imageType = FlagImage;
	showInventory = false;
	shadowDetailMask = 4;
   validateShape = true;

	lightType = 2;   // Pulsing
	lightRadius = 4;
	lightTime = 1.5;
	lightColor = { 1, 1, 1 };
};

ItemData RaceFlag
{
	description = "Race Flag";
	shapeFile = "flag";
	imageType = FlagImage;
	showInventory = false;
	shadowDetailMask = 4;

	lightType = 2;   // Pulsing
	lightRadius = 4;
	lightTime = 1.5;
	lightColor = { 1, 1, 1 };
};

//----------------------------------------------------------------------------
// Armors
//----------------------------------------------------------------------------

ItemData LightArmor
{
   heading = "aArmor";
	description = "Light Armor";
	className = "Armor";
	price = 175;
};

ItemData MediumArmor
{
   heading = "aArmor";
	description = "Medium Armor";
	className = "Armor";
	price = 250;
};

ItemData HeavyArmor
{
   heading = "aArmor";
	description = "Heavy Armor";
	className = "Armor";
	price = 400;
};

//----------------------------------------------------------------------------
// Vehicles
//----------------------------------------------------------------------------

ItemData ScoutVehicle
{
	description = "Scout";
	className = "Vehicle";
   heading = "aVehicle";
	price = 600;
};

ItemData LAPCVehicle
{
	description = "LPC";
	className = "Vehicle";
   heading = "aVehicle";
	price = 675;
};

ItemData HAPCVehicle
{
	description = "HPC";
	className = "Vehicle";
   heading = "aVehicle";
	price = 875;
};


//----------------------------------------------------------------------------
// Tools, Weapons & ammo
//----------------------------------------------------------------------------

ItemData Weapon
{
	description = "Weapon";
	showInventory = false;
};

function Weapon::onDrop(%player,%item)
{
	%state = Player::getItemState(%player,$WeaponSlot);
	if (%state != "Fire" && %state != "Reload")
		Item::onDrop(%player,%item);
}	

function Weapon::onUse(%player,%item) 
{ 
     if(%player.Station=="") 
     { 
          %ammo = %item.imageType.ammoType; 
          if (%ammo == "")  
          { 
               // Energy weapons dont have ammo types 
               Player::mountItem(%player,%item,$WeaponSlot); 
          } 
          else  
          { 
               if (Player::getItemCount(%player,%ammo) > 0)  
                    Player::mountItem(%player,%item,$WeaponSlot); 
               else  
               { 
                    Client::sendMessage(Player::getClient(%player),0,strcat(%item.description," has no ammo")); 
                    return; 
               } 
          } 
          bottomprint(Player::getClient(%player),"<jc>Using: <f2>" @%item.description@"",5); 
     } 
}



//----------------------------------------------------------------------------

ItemData Tool
{
	description = "Tool";
	showInventory = false;
};

function Tool::onUse(%player,%item)
{
	Player::mountItem(%player,%item,$ToolSlot);
}



//----------------------------------------------------------------------------

ItemData Ammo
{
	description = "Ammo";
	showInventory = false;
};

function Ammo::onDrop(%player,%item)
{
	if($matchStarted) {
		%count = Player::getItemCount(%player,%item);
		%delta = $SellAmmo[%item];
		if(%count <= %delta) { 
			if( %item == BulletAmmo || (Player::getMountedItem(%player,$WeaponSlot)).imageType.ammoType != %item)
				%delta = %count;
			else 
				%delta = %count - 1;

		}
		if(%delta > 0) {
			%obj = newObject("","Item",%item,%delta,false);
      	schedule("Item::Pop(" @ %obj @ ");", $ItemPopTime, %obj);

      	addToSet("MissionCleanup", %obj);
			GameBase::throw(%obj,%player,20,false);
			Item::playPickupSound(%obj);
			Player::decItemCount(%player,%item,%delta);
		}
	}
}	

//----------------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////////////
/////////////USW
/////////////
////////////
//
//----------------------------------------------------------------------------

ItemImageData LaserRifleImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	projectileType = SniperLaser;
	accuFire = true;
	reloadTime = 0.05;
	fireTime = 0;
	minEnergy = 1;// 10;
	maxEnergy = 7;// 20;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 2;
	//lightTime = 1;
	//lightColor = { 1, 0, 0 };

	sfxFire = SoundFireLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData LaserRifle
{
	description = "Laser Rifle";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "sniper";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = LaserRifleImage;
	price = 200;
	showWeaponBar = true;
   validateShape = true;
   validateMaterials = false;
};

function LaserRifle::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
}
/////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Modified by Dustin Bruce so you dont need the energy pack//
/////////////////////////////////////////////////////////////////////////////////////
//
//	if(Player::getMountedItem(%player,$BackpackSlot) == EnergyPack)
//		Weapon::onUse(%player,%item);
//	else
//		Client::sendMessage(Player::getClient(%player),0,
//			"Must have an Energy Pack to use Laser Rifle."); 
//}
//
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

ItemImageData TaserRifleImage
{
        shapeFile = "sniper";
        mountPoint = 0;

        weaponType = 0; // 2,Sustained
        projectileType = TaserRfLaser;
        accuFire = true;
        minEnergy = 1;
        maxEnergy = 0.5;// 15;//brightness of beamhere
        reloadTime = 0.08;

        //lightType   = 3;  // Weapon Fire
        //lightRadius = 3;
        //lightTime   = 0.08;
        //lightColor = { 0.4, 0, 0.6 };

        sfxFire     = SoundTaserFire;
        sfxActivate = SoundPickUpWeapon;
        sfxReady = SoundEnergyPackOn;
};

ItemData TaserRifle
{
        description   = "Taser Rifle";
        className     = "Weapon";
        shapeFile     = "sniper";
        hudIcon       = "sniper";
   heading = "TUSW-Weapons";
        shadowDetailMask = 4;
        imageType     = TaserRifleImage;
        price         = 100;
        showWeaponBar = true;
};
function TaserRifle::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}
//--------------------------------------
ItemData FireballAbilityAmmo
{
        description = "Fire Implants";
        className = "Ammo";
        shapeFile = "grenammo";
   heading = "xAmmunition";
        shadowDetailMask = 4;
        price = 5;
};

ItemImageData FireballAbilityImage
{
        shapeFile = "plasmatrail";
        mountPoint = 0;

        weaponType = 0; // Single Shot
        ammoType = FireballAbilityAmmo;
        projectileType = Fireball;
        accuFire = true;
        reloadTime = 0.05;
        fireTime = 0;

        //lightType = 3;  // Weapon Fire
        //lightRadius = 3;
        //lightTime = 0.05;
        //lightColor = { 1, 1, 1 };

        sfxFire = SoundJetHeavy;
        sfxActivate = SoundPickUpWeapon;
};

ItemData FireballAbility
{
        description = "Fireball Ability";
        className = "Weapon";
        shapeFile = "plasmatrail";
        hudIcon = "deployable";
   heading = "WPsionics";
        shadowDetailMask = 4;
        imageType = FireballAbilityImage;
        price = 420;
        showWeaponBar = true;
};
function FireballAbility::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//--------------------------------------
ItemData SmScreenAbilityAmmo
{
        description = "Smoke Implants";
        className = "Ammo";
        shapeFile = "grenammo";
   heading = "xAmmunition";
        shadowDetailMask = 4;
        price = 5;
};

ItemImageData SmScreenAbilityImage
{
        shapeFile = "breath";
        mountPoint = 0;

        weaponType = 0; // Single Shot
        ammoType = SmScreenAbilityAmmo;
        projectileType = SmScreen;
        accuFire = true;
        reloadTime = 0.1;
        fireTime = 0;

        //lightType = 3;  // Weapon Fire
        //lightRadius = 3;
        //lightTime = 0.05;
        //lightColor = { 1, 1, 1 };

        sfxFire = SoundJetHeavy;
        sfxActivate = SoundPickUpWeapon;
};

ItemData SmScreenAbility
{
        description = "SmokeScreen Ability";
        className = "Weapon";
        shapeFile = "breath";
        hudIcon = "deployable";
   heading = "WPsionics";
        shadowDetailMask = 4;
        imageType = SmScreenAbilityImage;
        price = 23;
        showWeaponBar = true;
};
function SmScreenAbility::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//--------------------------------------
ItemData ExSmScreenAbilityAmmo
{
        description = "Lair Implants";
        className = "Ammo";
        shapeFile = "grenammo";
   heading = "xAmmunition";
        shadowDetailMask = 4;
        price = 5;
};

ItemImageData ExSmScreenAbilityImage
{
        shapeFile = "enbolt";
        mountPoint = 0;

        weaponType = 0; // Single Shot
        ammoType = ExSmScreenAbilityAmmo;
        projectileType = ExSmScreen;
        accuFire = true;
        reloadTime = 0.5;
        fireTime = 0;

        //lightType = 3;  // Weapon Fire
        //lightRadius = 3;
        //lightTime = 0.05;
        //lightColor = { 1, 1, 1 };

        sfxFire = SoundJetHeavy;
        sfxActivate = SoundPickUpWeapon;
};

ItemData ExSmScreenAbility
{
        description = "LairWaster";
        className = "Weapon";
        shapeFile = "enbolt";
        hudIcon = "deployable";
   heading = "WPsionics";
        shadowDetailMask = 4;
        imageType = ExSmScreenAbilityImage;
        price = 23;
        showWeaponBar = true;
};
function ExSmScreenAbility::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	bottomprint(Player::getClient(%player), "<jc><f2>Using LairWaster-This weapon.....well it sux", 2);
}

//--------------------------------------
ItemData FireScreenAbilityAmmo
{
        description = "FireWall Bombs";
        className = "Ammo";
        shapeFile = "grenammo";
   heading = "xAmmunition";
        shadowDetailMask = 4;
        price = 5;
};

ItemImageData FireScreenAbilityImage
{
        shapeFile = "plasmabolt";
        mountPoint = 0;

        weaponType = 0; // Single Shot
        ammoType = FireScreenAbilityAmmo;
        projectileType = FireScreen;
        accuFire = true;
        reloadTime = 0.05;
        fireTime = 0;

        //lightType = 3;  // Weapon Fire
        //lightRadius = 3;
        //lightTime = 0.05;
        //lightColor = { 1, 1, 1 };

        sfxFire = SoundJetHeavy;
        sfxActivate = SoundPickUpWeapon;
};

ItemData FireScreenAbility
{
        description = "FireWall";
        className = "Weapon";
        shapeFile = "plasmabolt";
        hudIcon = "deployable";
   heading = "WPsionics";
        shadowDetailMask = 4;
        imageType = FireScreenAbilityImage;
        price = 23;
        showWeaponBar = true;
};
function FireScreenAbility::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------

ItemData SpellAbilityAmmo
{
	description = "SpellHeart";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 1;
};

ItemImageData SpellAbilityImage
{
	shapeFile = "breath";
	mountPoint = 0;

	weaponType = 0; // Spinning
	reloadTime = 0;
	//spinUpTime = 0.1;
	//spinDownTime = 0.1;
	fireTime = 0.1;

	ammoType = SpellAbilityAmmo;
	projectileType = SpellAbilityproj;
	accuFire = true;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 0.6, 1, 1 };

	//sfxFire = soundwindgust;
	sfxActivate = SoundPickUpWeapon;
	//sfxSpinUp = SoundSpinUp;
	//sfxSpinDown = SoundSpinDown;
};

ItemData SpellAbility
{
	description = "Spell";
	className = "Weapon";
	shapeFile = "breath";
   validateShape = true;
	hudIcon = "sniper";
   heading = "WPsionics";
	shadowDetailMask = 4;
	imageType = SpellAbilityImage;
	price = 125;
	showWeaponBar = true;
};
function SpellAbility::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}
//----------------------------------------------------------------------------

ItemImageData BlasterImage
{
   shapeFile  = "paintgun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	reloadTime = 0;
	fireTime = 0.03;
	minEnergy = 1;
	maxEnergy = 0.5;// 0.1;

	projectileType = BlasterBolt;
	accuFire = true;

	sfxFire = SoundFireBlaster;
	sfxActivate = SoundPickUpWeapon;
};

ItemData Blaster
{
   heading = "TUSW-Weapons";
	description = "Blaster";
	className = "Weapon";
   shapeFile  = "paintgun";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = BlasterImage;
	price = 85;
	showWeaponBar = true;
};
function Blaster::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
}

//----------------------------------------------------------------------------

ItemData BulletAmmo
{
	description = "Bullet";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 1;
};

ItemImageData ChaingunImage
{
	shapeFile = "chaingun";
	mountPoint = 0;

	weaponType = 0; // Spinning
	reloadTime = 0;
	//spinUpTime = 0.1;
	//spinDownTime = 0.1;
	fireTime = 0.02;

	ammoType = BulletAmmo;
	projectileType = ChaingunBullet;
	accuFire = true;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 0.6, 1, 1 };

	sfxFire = debrissmallexplosion;
	sfxActivate = SoundPickUpWeapon;
	//sfxSpinUp = SoundSpinUp;
	//sfxSpinDown = SoundSpinDown;
};

ItemData Chaingun
{
	description = "Chaingun";
	className = "Weapon";
	shapeFile = "sniper";
   validateShape = true;
	hudIcon = "sniper";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = ChaingunImage;
	price = 125;
	showWeaponBar = true;
};
function Chaingun::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
}

//----------------------------------------------------------------------------

ItemData LiLPOOmkiAmmo
{
	description = "Bullet mki";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 0;
};

ItemImageData LiLPOOmkiImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Spinning
	reloadTime = 0;
	//spinUpTime = 0.5;
	//spinDownTime = 3;
	fireTime = 0.01;

	ammoType = LiLPOOmkiAmmo;
	projectileType = LiLPOOmkiBullet;
	accuFire = true;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 0.6, 1, 1 };

	sfxFire = SoundDryFire;
	sfxActivate = SoundPickUpWeapon;
	//sfxSpinUp = SoundSpinUp;
	//sfxSpinDown = SoundSpinDown;
};

ItemData LiLPOOmki
{
	description = "LiL POO mki";
	className = "Weapon";
	shapeFile = "sniper";
   validateShape = true;
	hudIcon = "sniper";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = LiLPOOmkiImage;
	price = 125;
	showWeaponBar = true;
};
function LiLPOOmki::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------

ItemData LiLPOOmkiiAmmo
{
	description = "Bullet mkii";
	className = "Ammo";
	shapeFile = "ammo1";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 0;
};

ItemImageData LiLPOOmkiiImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 0; // Spinning
	reloadTime = 0;
	//spinUpTime = 0.5;
	//spinDownTime = 3;
	fireTime = 0.02;

	ammoType = LiLPOOmkiiAmmo;
	projectileType = LiLPOOmkiiBullet;
	accuFire = true;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 0.6, 1, 1 };

	sfxFire = SoundLiLPOOmkii;
	sfxActivate = SoundPickUpWeapon;
	//sfxSpinUp = SoundSpinUp;
	//sfxSpinDown = SoundSpinDown;
};

ItemData LiLPOOmkii
{
	description = "LiL POO mkii";
	className = "Weapon";
	shapeFile = "sniper";
  // validateShape = true;
	hudIcon = "sniper";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = LiLPOOmkiiImage;
	price = 125;
	showWeaponBar = true;
};
function LiLPOOmkii::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}


//----------------------------------------------------------------------------

ItemData PlasmaAmmo
{
	description = "Plasma Bolt";
   heading = "xAmmunition";
	className = "Ammo";
	shapeFile = "plasammo";
	shadowDetailMask = 4;
	price = 2;
};

ItemImageData PlasmaGunImage
{
	shapeFile = "plasma";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = PlasmaAmmo;
	projectileType = PlasmaBolt;
	accuFire = true;
	reloadTime = 0.03;
	fireTime = 0.03;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 1, 1, 0.2 };

	sfxFire = SoundFirePlasma;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundDryFire;
};

ItemData PlasmaGun
{
	description = "Plasma Gun";
	className = "Weapon";
	shapeFile = "plasma";
	hudIcon = "plasma";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = PlasmaGunImage;
	price = 175;
	showWeaponBar = true;
   validateShape = true;
};
function PlasmaGun::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------

ItemData GrenadeAmmo
{
	description = "Grenade Ammo";
	className = "Ammo";
	shapeFile = "grenammo";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 2;
};

ItemImageData GrenadeLauncherImage
{
	shapeFile = "grenadeL";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = GrenadeAmmo;
	projectileType = GrenadeShell;
	accuFire = false;
	reloadTime = 0.05;
	fireTime = 0.05;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireGrenade;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundDryFire;
};

ItemData GrenadeLauncher
{
	description = "Grenade Launcher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = GrenadeLauncherImage;
	price = 150;
	showWeaponBar = true;
   validateShape = true;
};
function GrenadeLauncher::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------

ItemData MortarAmmo
{
	description = "Mortar Ammo";
	className = "Ammo";
   heading = "xAmmunition";
	shapeFile = "mortarammo";
	shadowDetailMask = 4;
	price = 5;
};

ItemImageData MortarImage
{
	shapeFile = "mortargun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	ammoType = MortarAmmo;
	projectileType = MortarShell;
	accuFire = false;
	reloadTime = 0.05;
	fireTime = 0.05;

	//lightType = 3;  // Weapon Fire
	//lightRadius = 3;
	//lightTime = 1;
	//lightColor = { 0.6, 1, 1.0 };

	sfxFire = SoundFireMortar;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
	sfxReady = SoundMortarIdle;
};

ItemData Mortar
{
	description = "Mortar";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "mortar";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = MortarImage;
	price = 375;
	showWeaponBar = true;
   validateShape = true;
};
function Mortar::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------

ItemData LiLFFBAmmo 
{ 
        description = "LiLFFB Ammo";
        className = "Ammo";
        heading = "xAmmunition";
        shapeFile = "grenammo";
        shadowDetailMask = 4;
        price = 5;
}; 

ItemImageData LiLFFBImage 
{ 
        shapeFile = "mortargun";
        mountPoint = 0;
        weaponType = 0;
        ammoType = LiLFFBAmmo;
        projectileType = LiLFFBShell;
        accuFire = false;
        reloadTime = 1;
        fireTime = 0;
        //lightType = 3;
        //lightRadius = 3;
        //lightTime = 1;
        //lightColor = { 0.4, 0, 0.6 };
        sfxFire = SoundMortarTurretFire;
        sfxActivate = SoundChainTurretOn;
        sfxReady = SoundGeneratorPower;
};

ItemData LiLFFB
{ 
        description = "LiLForce Field Buster";
        className = "Weapon";
        shapeFile = "mortargun";
        hudIcon = "plasma";
        heading = "TUSW-Weapons";
        shadowDetailMask = 4;
        imageType = LiLFFBImage;
        price = 100;
        showWeaponBar = true;
};
function LiLFFB::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//--------------------------------------------------------------

ItemData LiLRocketLauncherAmmo 
{ 
        description = "LiLRockets";
        className = "Ammo";
        heading = "xAmmunition";
        shapeFile = "grenammo";
        shadowDetailMask = 4;
        price = 5;
}; 

ItemImageData LiLRocketLauncherImage 
{ 
        shapeFile = "grenadel";
        mountPoint = 0;
        mountoffset = { 0, 0, -0.2 };
        mountrotation = { 0, 3, 0 };
        weaponType = 0;
        ammoType = LiLRocketLauncherAmmo;
        //projectileType = LiLFFBShell;
        accuFire = false;
        reloadTime = 0.2;
        fireTime = 0;
        //lightType = 3;
        //lightRadius = 3;
        //lightTime = 1;
        //lightColor = { 0.4, 0, 0.6 };
        sfxFire = soundmayhemassaultrifle;
        sfxActivate = SoundPickUpWeapon;
        //sfxReady = SoundGeneratorPower;
};

ItemData LiLRocketLauncher
{ 
        description = "LiLRocket Launcher";
        className = "Weapon";
        shapeFile = "grenadel";
        hudIcon = "plasma";
        heading = "TUSW-Weapons";
        shadowDetailMask = 4;
        imageType = LiLRocketLauncherImage;
        price = 100;
        showWeaponBar = true;
};

function LiLRocketLauncherImage::onFire(%player, %slot) 
{ 
	%client = GameBase::getOwnerClient(%player); 
	Player::decItemCount(%player,$WeaponAmmo[LiLRocketLauncher],1); 
	%trans = GameBase::getMuzzleTransform(%player); 
	%vel = Item::getVelocity(%player); 
	if(GameBase::getLOSInfo(%player,350)) 
	{ 
		%object = getObjectType($los::object); 
		if(%object == "Player" || %object == "Flier") 
		
		{  
		        RocketLockWarning(%client, $los::object, %object);
			Projectile::spawnProjectile("LiLRocketEMP",%trans,%player,%vel,$los::object);
			Projectile::spawnProjectile("LiLRocket",%trans,%player,%vel,$los::object);
			Projectile::spawnProjectile("LiLRocketSubmission",%trans,%player,%vel,$los::object);
		} else 
		        Projectile::spawnProjectile("LiLRocketalt",%trans,%player,%vel);
	} else 
                        Projectile::spawnProjectile("LiLRocketalt",%trans,%player,%vel);  
} 
function LiLRocketLauncher::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//--------------------------------------------------------------

ItemData LiLEMPRocketLauncherAmmo 
{ 
        description = "LiLEMPRockets";
        className = "Ammo";
        heading = "xAmmunition";
        shapeFile = "grenammo";
        shadowDetailMask = 4;
        price = 5;
}; 

ItemImageData LiLEMPRocketLauncherImage 
{ 
        shapeFile = "grenadel";
        mountPoint = 0;
        mountoffset = { 0, 0, -0.2 };
        mountrotation = { 0, 3, 0 };
        weaponType = 0;
        ammoType = LiLEMPRocketLauncherAmmo;
        //projectileType = LiLFFBShell;
        accuFire = false;
        reloadTime = 0.2;
        fireTime = 0;
        //lightType = 3;
        //lightRadius = 3;
        //lightTime = 1;
        //lightColor = { 0.4, 0, 0.6 };
        sfxFire = SoundEMPfire;
        sfxActivate = SoundPickUpWeapon;
        //sfxReady = SoundGeneratorPower;
};

ItemData LiLEMPRocketLauncher
{ 
        description = "LiLEMPRocket Launcher";
        className = "Weapon";
        shapeFile = "grenadel";
        hudIcon = "plasma";
        heading = "TUSW-Weapons";
        shadowDetailMask = 4;
        imageType = LiLEMPRocketLauncherImage;
        price = 100;
        showWeaponBar = true;
};

function LiLEMPRocketLauncherImage::onFire(%player, %slot) 
{ 
	%client = GameBase::getOwnerClient(%player); 
	Player::decItemCount(%player,$WeaponAmmo[LiLEMPRocketLauncher],1); 
	%trans = GameBase::getMuzzleTransform(%player); 
	%vel = Item::getVelocity(%player); 
	if(GameBase::getLOSInfo(%player,350)) 
	{ 
		%object = getObjectType($los::object); 
		if(%object == "Player" || %object == "Flier") 
		
		{  
		        RocketLockWarning(%client, $los::object, %object);
			Projectile::spawnProjectile("LiLEMPRocketONE",%trans,%player,%vel,$los::object);
			Projectile::spawnProjectile("LiLEMPRocketTWO",%trans,%player,%vel,$los::object);
		} else 
		        Projectile::spawnProjectile("LiLEMPRocketalt",%trans,%player,%vel);
	} else 
                        Projectile::spawnProjectile("LiLEMPRocketalt",%trans,%player,%vel);  
} 

//--------------------------------------------------------------
//--------------------------------------------------------------

ItemData DiscAmmo
{
	description = "Disc";
	className = "Ammo";
	shapeFile = "discammo";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 2;
};

ItemImageData DiscLauncherImage
{
	shapeFile = "disc";
	mountPoint = 0;

	weaponType = 0; // DiscLauncher
	ammoType = DiscAmmo;
	projectileType = DiscShell;
	accuFire = true;
	reloadTime = 0.05;
	fireTime = 0;
	//spinUpTime = 0.25;

	sfxFire = SoundFireDisc;
	sfxActivate = SoundPickUpWeapon;
	//sfxReload = SoundDiscReload;
	//sfxReady = SoundDiscSpin;
};

ItemData DiscLauncher
{
	description = "Disc Launcher";
	className = "Weapon";
	shapeFile = "disc";
	hudIcon = "disk";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = DiscLauncherImage;
	price = 150;
	showWeaponBar = true;
};
function DiscLauncher::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}


//--------------------------------------------------------------
ItemImageData TargetingLaserImage
{
	shapeFile = "paintgun";
	mountPoint = 0;

	weaponType = 2; // Sustained
	projectileType = targetLaser;
	accuFire = true;
	minEnergy = 5;
	maxEnergy = 15;
	reloadTime = 1.0;

	lightType   = 3;  // Weapon Fire
	lightRadius = 1;
	lightTime   = 1;
	lightColor  = { 0.25, 1, 0.25 };

	sfxFire     = SoundFireTargetingLaser;
	sfxActivate = SoundPickUpWeapon;
};

ItemData TargetingLaser
{
	description   = "Targeting Laser";
	className     = "Tool";
	shapeFile     = "paintgun";
	hudIcon       = "targetlaser";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType     = TargetingLaserImage;
	price         = 50;
	showWeaponBar = false;
};
function TargetingLaser::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//------------------------------------------------------------------------------

ItemImageData BeamOfPainImage
{
	shapeFile = "shotgun";
   mountPoint = 0;
       mountoffset = { 0, 0, -0.2 };
       mountrotation = { 0, 3, 0 };
   weaponType = 2;  // Sustained
	projectileType = BeamOfPainProj;
   minEnergy = 3;
   maxEnergy = 11;  // Energy used/sec for sustained weapons
	reloadTime = 0.03;
                        
   //lightType = 3;  // Weapon Fire
   //lightRadius = 2;
   //lightTime = 1;
   //lightColor = { 0.25, 0.25, 0.85 };

   sfxActivate = SoundPickUpWeapon;
   sfxFire     = SoundELFFire;
};

//---------------------------------

ItemData BeamOfPain
{
   description = "Beam Of Pain";
	shapeFile = "shotgun";
	hudIcon = "energyRifle";
   className = "Weapon";
   heading = "TUSW-Weapons";
   shadowDetailMask = 4;
   imageType = BeamOfPainImage;
	showWeaponBar = true;
   price = 125;
   validateShape = true;
};
function BeamOfPain::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}
//-----------------------------------------------------
// Jail Gun - from the Tricon Team

ItemImageData JailGunImage
{
	shapeFile = "shotgun";
	mountPoint = 0;

	weaponType = 2;
	projectileType = jailbolt;

	minEnergy = 3;// 5;
	maxEnergy = 11;// 80;
	reloadTime = 0.25;// 4.0;

	lightType = 3;
	lightRadius = 2;
	lightTime = 1;
	lightColor = { 0.25, 0.25, 0.85 };

	sfxActivate = SoundPickUpWeapon;
	sfxFire     = SoundELFIdle;
};

ItemData JailGun
{
	heading = "TUSW-Weapons";
        description = "Jail Gun";
        className = "Weapon";
        shapeFile  = "repairgun";
        shadowDetailMask = 4;
        imageType = JailGunImage;
        price = 385;
        showWeaponBar = true;
};
function JailGun::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//--------------------------------------------------------------

ItemImageData EnergyRifleImage
{
	shapeFile = "shotgun";
   mountPoint = 0;
       // mountoffset = { 0, 0, -0.2 };
       // mountrotation = { 0, 3, 0 };
   weaponType = 2;  // Sustained
	projectileType = lightningCharge;
   minEnergy = 3;
   maxEnergy = 11;  // Energy used/sec for sustained weapons
	reloadTime = 0.08;
                        
   lightType = 3;  // Weapon Fire
   lightRadius = 2;
   lightTime = 1;
   lightColor = { 0.25, 0.25, 0.85 };

   sfxActivate = SoundPickUpWeapon;
   sfxFire     = SoundELFIdle;
};

ItemData EnergyRifle
{
   description = "ELF Gun";
	shapeFile = "shotgun";
	hudIcon = "energyRifle";
   className = "Weapon";
   heading = "TUSW-Weapons";
   shadowDetailMask = 4;
   imageType = EnergyRifleImage;
	showWeaponBar = true;
   price = 125;
   validateShape = true;
};
function EnergyRifle::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//---------------------------------------------------
// Plasma Cannon - ripped from Redneck Slag Pack

ItemImageData PlasmaCannonImage
{
	shapeFile = "mortargun";
	mountPoint = 0;

	weaponType = 0; // Single Shot
	projectileType = PlasmaCannonBlast;
	accuFire = True;
	reloadTime = 0.07;// 0.5;
	fireTime = 0.1;
	minEnergy = 3;// 15;
	maxEnergy = 0.1;// 50;
	
	lightType = 3; // Weapon Fire
	lightRadius = 5;
	lightTime = 2;
	lightColor = { 0, 0, 1 };

	sfxFire = SoundPlasmaTurretFire;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundGeneratorPower;
};

ItemData PlasmaCannon
{
	description = "Plasma Cannon";
	className = "Weapon";
	shapeFile = "mortargun";
	hudIcon = "plasma";
	heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = PlasmaCannonImage;
	price = 250;
	showWeaponBar = true;
};

function PlasmaCannon::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------

ItemImageData RepairGunImage
{
	shapeFile = "repairgun";
	mountPoint = 0;

	weaponType = 2;  // Sustained
	projectileType = RepairBolt;
	minEnergy  = 3;
	maxEnergy = 10;  // Energy used/sec for sustained weapons

	lightType   = 3;  // Weapon Fire
	lightRadius = 1;
	lightTime   = 1;
	lightColor  = { 0.25, 1, 0.25 };

	sfxActivate = SoundPickUpWeapon;
	sfxFire = SoundRepairItem;
};

ItemData RepairGun
{
	description = "Repair Gun";
	shapeFile = "repairgun";
	className = "Weapon";
	shadowDetailMask = 4;
	imageType = RepairGunImage;
	showInventory = false;
	price = 125;
   validateShape = true;
};

function RepairGun::onMount(%player,%imageSlot)
{
	Player::trigger(%player,$BackpackSlot,true);
}

function RepairGun::onUnmount(%player,%imageSlot)
{
	Player::trigger(%player,$BackpackSlot,false);
}
function RepairGun::onUse(%player,%item)
{
      Weapon::onUse(%player,%item);
	
}

//----------------------------------------------------------------------------
// Backpacks
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

ItemData Backpack
{				
	description = "Backpack";
	showInventory = false;
};

function Backpack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::trigger(%player,$BackpackSlot);
	}
}


//----------------------------------------------------------------------------

ItemImageData DeployableInvPackImage
{
	shapeFile = "invent_remote";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.3 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData DeployableInvPack
{
	description = "Inventory Station";
	shapeFile = "invent_remote";
	className = "Backpack";
   heading = "dDeployables";
	shadowDetailMask = 4	;
	imageType = DeployableInvPackImage;
	mass = 2.0;
	elasticity = 0.2;
	price = $RemoteInvEnergy + 200;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};


function DeployableInvPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function DeployableInvPack::onDeploy(%player,%item,%pos)
{
	if (DeployableInvPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}	

function DeployableInvPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		%Set = newObject("set",SimSet);
						                                %Mask = $StaticObjectType;
						                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
						                                for(%i; %i < %num; %i++)
						                                {
						                                        %thing = Group::getObject(%Set, %i);
						                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
						                                        {
						                                                %inbase= true;
						                                                break;
						                                        }
						                                }
						                                deleteObject(%Set);
						                                if(%inbase)
                                {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				if (Vector::dot($los::normal,"0 0 1") > 0.7) {
					if(checkDeployArea(%client,$los::position)) {
						%inv = newObject("ammounit_remote","StaticShape","DeployableInvStation",true);
 	 		         addToSet("MissionCleanup", %inv);
						%rot = GameBase::getRotation(%player); 
						GameBase::setTeam(%inv,GameBase::getTeam(%player));
						GameBase::setPosition(%inv,$los::position);
						GameBase::setRotation(%inv,%rot);
						Gamebase::setMapName(%inv,%name);
						Client::sendMessage(%client,0,"Inventory Station deployed");
						playSound(SoundPickupBackpack,$los::position);
						$TeamItemCount[GameBase::getTeam(%inv) @ "DeployableInvPack"]++;
						echo("MSG: ",%client," deployed an Inventory Station");
						return true;
					}
				}
				else {
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		else {
					//remotekill(%client);
					bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
				}
	}
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	return false;
}


//----------------------------------------------------------------------------

ItemImageData DeployableAmmoPackImage
{
	shapeFile = "ammounit_remote";
	mountPoint = 2;
	mountOffset = { 0, -0.1, -0.3 };
	mountRotation = { 0, 0, 0 };
	mass = 1.0;
	firstPerson = false;
};

ItemData DeployableAmmoPack
{
	description = "Ammo Station";
	shapeFile = "ammounit_remote";
	className = "Backpack";
   heading = "dDeployables";
	shadowDetailMask = 4;
	imageType = DeployableAmmoPackImage;
	mass = 2.0;
	elasticity = 0.2;
	price = $RemoteAmmoEnergy;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};


function DeployableAmmoPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function DeployableAmmoPack::onDeploy(%player,%item,%pos)
{
	if (DeployableAmmoPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}	

function DeployableAmmoPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		%Set = newObject("set",SimSet);
						                                %Mask = $StaticObjectType;
						                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
						                                for(%i; %i < %num; %i++)
						                                {
						                                        %thing = Group::getObject(%Set, %i);
						                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
						                                        {
						                                                %inbase= true;
						                                                break;
						                                        }
						                                }
						                                deleteObject(%Set);
						                                if(%inbase)
                                {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				if (Vector::dot($los::normal,"0 0 1") > 0.7) {
					if(checkDeployArea(%client,$los::position)) {
						%inv = newObject("ammounit_remote","StaticShape","DeployableAmmoStation",true);
	         	   addToSet("MissionCleanup", %inv);
						%rot = GameBase::getRotation(%player); 
						GameBase::setTeam(%inv,GameBase::getTeam(%player));
						GameBase::setPosition(%inv,$los::position);
						GameBase::setRotation(%inv,%rot);
						Gamebase::setMapName(%inv,%name);
						Client::sendMessage(%client,0,"Ammo Station deployed");
						playSound(SoundPickupBackpack,$los::position);
						$TeamItemCount[GameBase::getTeam(%inv) @ "DeployableAmmoPack"]++;
						echo("MSG: ",%client," deployed an Ammo Station");
						return true;
					}
				}
				else 
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
					//remotekill(%client);
					bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
	}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	return false;
}


//----------------------------------------------------------------------------

ItemImageData EnergyPackImage
{
	shapeFile = "jetPack";
	weaponType = 2;  // Sustained

	mountPoint = 2;
	mountOffset = { 0, -0.1, 0 };

	minEnergy = -1;
 	maxEnergy = -20;
	firstPerson = false;
};

ItemData EnergyPack
{
	description = "Energy Pack";
	shapeFile = "jetPack";
	className = "Backpack";
   heading = "cBackpacks";
	shadowDetailMask = 4;
	imageType = EnergyPackImage;
	price = 150;
	hudIcon = "energypack";
	showWeaponBar = true;
	hiliteOnActive = true;
   validateShape = true;
   validateMaterials = true;
};

function EnergyPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
}

function EnergyPack::onMount(%player,%item)
{
	Player::trigger(%player,$BackpackSlot,true);
}

function EnergyPack::onUnmount(%player,%item)
{
	if (Player::getMountedItem(%player,$WeaponSlot) == LaserRifle) 
		Player::unmountItem(%player,$WeaponSlot);
}

//----------------------------------------------------------------------------

ItemImageData RepairPackImage
{
	shapeFile = "armorPack";
	mountPoint = 2;
	weaponType = 2;  // Sustained
   minEnergy = 0;
	maxEnergy = 0;   // Energy used/sec for sustained weapons
  	mountOffset = { 0, -0.05, 0 };
  	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData RepairPack
{
	description = "Repair Pack";
	shapeFile = "armorPack";
	className = "Backpack";
   heading = "cBackpacks";
	shadowDetailMask = 4;
	imageType = RepairPackImage;
	price = 125;
	hudIcon = "repairpack";
	showWeaponBar = true;
	hiliteOnActive = true;
   validateShape = true;
   validateMaterials = true;
};

function RepairPack::onUnmount(%player,%item)
{
	if (Player::getMountedItem(%player,$WeaponSlot) == RepairGun) {
		Player::unmountItem(%player,$WeaponSlot);
	}
}

function RepairPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::mountItem(%player,RepairGun,$WeaponSlot);
	}
}

function RepairPack::onDrop(%player,%item)
{
	if($matchStarted) {
		%mounted = Player::getMountedItem(%player,$WeaponSlot);
		if (%mounted == RepairGun) {
			Player::unmountItem(%player,$WeaponSlot);
		}
		else {
			// Remount the existing weapon to make sure the RepairGun
			// is not on the delayed mount "stack".
			Player::mountItem(%player,%mounted,$WeaponSlot);
		}
		Item::onDrop(%player,%item);
	}
}	


//----------------------------------------------------------------------------

ItemImageData ShieldPackImage
{
	shapeFile = "shieldPack";
	mountPoint = 2;
	weaponType = 2;  // Sustained
	minEnergy = 4;
	maxEnergy = 0.1;   // Energy/sec for sustained weapons
	sfxFire = SoundShieldOn;
	firstPerson = false;
};

ItemData ShieldPack
{
	description = "Shield Pack";
	shapeFile = "shieldPack";
	className = "Backpack";
   heading = "cBackpacks";
	shadowDetailMask = 4;
	imageType = ShieldPackImage;
	price = 175;
	hudIcon = "shieldpack";
	showWeaponBar = true;
	hiliteOnActive = true;
   validateShape = true;
   validateMaterials = true;
};

function ShieldPackImage::onActivate(%player,%imageSlot)
{
	Client::sendMessage(Player::getClient(%player),0,"Shield On");
	%player.shieldStrength = 0.008;
}

function ShieldPackImage::onDeactivate(%player,%imageSlot)
{
	Client::sendMessage(Player::getClient(%player),0,"Shield Off");
	Player::trigger(%player,$BackpackSlot,false);
	%player.shieldStrength = 0;
}


//----------------------------------------------------------------------------

ItemImageData SensorJammerPackImage
{
	shapeFile = "sensorjampack";
	mountPoint = 2;
	weaponType = 2;  // Sustained
	maxEnergy = 0.1;// 18;  // Energy used/sec for sustained weapons
	sfxFire = SoundJammerOn;
  	mountOffset = { 0, -0.05, 0 };
  	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData SensorJammerPack
{
	description = "StealthShield Pack";
	shapeFile = "sensorjampack";
	className = "Backpack";
   heading = "cBackpacks";
	shadowDetailMask = 4;
	imageType = SensorJammerPackImage;
	price = 200;
	hudIcon = "sensorjamerpack";
	showWeaponBar = true;
	hiliteOnActive = true;
   validateShape = true;
   validateMaterials = true;
};

function SensorJammerPackImage::onActivate(%player,%imageSlot)
{
	Client::sendMessage(Player::getClient(%player),0,"StealthShield On");
	%player.shieldStrength = 0.008;
	%rate = Player::getSensorSupression(%player) + 20;
	Player::setSensorSupression(%player,%rate);
}

function SensorJammerPackImage::onDeactivate(%player,%imageSlot)
{
	Client::sendMessage(Player::getClient(%player),0,"StealthShield Off");
	%player.shieldStrength = 0;
	%rate = Player::getSensorSupression(%player) - 20;
	Player::setSensorSupression(%player,%rate);
	Player::trigger(%player,$BackpackSlot,false);
}

//----------------------------------------------------------------------------

ItemImageData CloakingDeviceImage
{
	shapeFile = "sensorjampack";
	mountPoint = 2;
	weaponType = 2;  // Sustained
	maxEnergy = 18;  // Energy used/sec for sustained weapons
	sfxFire = SoundJammerOn;
  	mountOffset = { 0, -0.05, 0 };
  	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData CloakingDevice
{
	description = "Cloaking Device";
	shapeFile = "sensorjampack";
	className = "Backpack";
	heading = "cBackpacks";
	shadowDetailMask = 4;
	imageType = CloakingDeviceImage;
	price = 600;
	hudIcon = "sensorjamerpack";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function CloakingDeviceImage::onActivate(%player,%imageSlot)
{
 	GameBase::startFadeout(%player);
	Client::sendMessage(Player::getClient(%player),0,"Cloaking Device On");
	%rate = Player::getSensorSupression(%player) + 3;
	Player::setSensorSupression(%player,%rate);
}

function CloakingDeviceImage::onDeactivate(%player,%imageSlot)
{
 	GameBase::startFadein(%player);
	Client::sendMessage(Player::getClient(%player),0,"Cloaking Device Off");
	%rate = Player::getSensorSupression(%player) - 3;
	Player::setSensorSupression(%player,%rate);
	Player::trigger(%player,$BackpackSlot,false);
}

//----------------------------------------------------------------------------------------------

ItemImageData MotionSensorPackImage
{
	shapeFile = "sensor_small";
	mountPoint = 2;
	mountOffset = { 0, 0, 0.1 };
	mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData MotionSensorPack
{
	description = "Motion Sensor";
	shapeFile = "sensor_small";
	className = "Backpack";
   heading = "dDeployables";
	imageType = MotionSensorPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 125;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function MotionSensorPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function MotionSensorPack::onDeploy(%player,%item,%pos)
{
	if (MotionSensorPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
		$TeamItemCount[GameBase::getTeam(%player) @ "MotionSensorPack"]++;
	}
}

//	if (Item::deployShape(%player,"Motion Sensor",MotionSensor,%item)) {
function MotionSensorPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		%Set = newObject("set",SimSet);
						                                %Mask = $StaticObjectType;
						                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
						                                for(%i; %i < %num; %i++)
						                                {
						                                        %thing = Group::getObject(%Set, %i);
						                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
						                                        {
						                                                %inbase= true;
						                                                break;
						                                        }
						                                }
						                                deleteObject(%Set);
						                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%mSensor = newObject("","Sensor",DeployableMotionSensor,true);
	   	      addToSet("MissionCleanup", %mSensor);
					GameBase::setTeam(%mSensor,GameBase::getTeam(%player));
					GameBase::setRotation(%mSensor,%rot);
					GameBase::setPosition(%mSensor,$los::position);
					Gamebase::setMapName(%mSensor,"Motion Sensor");
					Client::sendMessage(%client,0,"Motion Sensor deployed");
					playSound(SoundPickupBackpack,$los::position);
					echo("MSG: ",%client," deployed a Motion Sensor");
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		else {
					//remotekill(%client);	
					bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
				}
	}
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

//----------------------------------------------------------------------------

ItemImageData AmmoPackImage
{
	shapeFile = "AmmoPack";
	mountPoint = 2;
   mountOffset = { 0, -0.03, 0 };
//   mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData AmmoPack
{
	description = "Ammo Pack";
	shapeFile = "AmmoPack";
	className = "Backpack";
   heading = "cBackpacks";
	imageType = AmmoPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 325;
	hudIcon = "ammopack";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function AmmoPack::onDrop(%player, %item)
{
	if($matchStarted) {
		%item = Item::onDrop(%player,%item);
		for(%i = 0; %i < 7 ; %i = %i +1) {
			%numPack = 0;
			%ammoItem = $AmmoPackItems[%i];
			%maxnum = $ItemMax[Player::getArmor(%player), %ammoItem];
			%pCount = Player::getItemCount(%player, %ammoItem);
			if(%pCount > %maxnum) {
				%numPack = %pCount - %maxnum;
				Player::decItemCount(%player,%ammoItem,%numPack);
			}	
			if(%i == 0) {
	 	    	%item.BulletAmmo = %numPack;
			}
			else if(%i == 1) {
	 	    	%item.PlasmaAmmo = %numPack;
			}
			else if(%i == 2) {
	 	    	%item.DiscAmmo = %numPack;
			}
			else if(%i == 3) {
	 	    	%item.GrenadeAmmo = %numPack;
			}
			else if(%i == 4) {
	 	    	%item.Grenade = %numPack;
			}
			else if(%i == 5) {
	 	    	%item.MortarAmmo = %numPack;
			}
			else {
	 	    	%item.MineAmmo = %numPack;
			}
		}
	}
}

function AmmoPack::onCollision(%this,%object)
{
	if (getObjectType(%object) == "Player") {
		%item = Item::getItemData(%this);
		%count = Player::getItemCount(%object,%item);
		if (Item::giveItem(%object,%item,Item::getCount(%this))) {
			Item::playPickupSound(%this);
			checkPacksAmmo(%object, %this);
			Item::respawn(%this);
		}
	}
}

function checkPacksAmmo(%player, %item)
{
	for(%i = 0; %i < 7 ; %i = %i +1) {
		%ammoItem = $AmmoPackItems[%i];
		if(%i == 0) {
	        %numAdd = %item.BulletAmmo;
		}
		else if(%i == 1) {
	    	%numAdd = %item.PlasmaAmmo;
		}
		else if(%i == 2) {
	    	%numAdd = %item.DiscAmmo;
		}
		else if(%i == 3) {
	    	%numAdd = %item.GrenadeAmmo;
		}
		else if(%i == 4) {
	    	%numAdd = %item.Grenade;
		}
		else if(%i == 5) {
 	    	%numAdd = %item.MortarAmmo;
		}
		else {
			%numAdd = %item.MineAmmo;
		}
		Player::incItemCount(%player,%ammoItem,%numAdd);
	}						 
}

function fillAmmoPack(%client)
{
	%player = Client::getOwnedObject(%client);
	for(%i = 0; %i < 7 ; %i = %i +1) {
		%item = $AmmoPackItems[%i];
		%maxnum = $AmmoPackMax[%item];
		%maxnum = checkResources(%player,%item,%maxnum); 
		if(%maxnum) {
			Player::incItemCount(%client,%item,%maxnum);
			teamEnergyBuySell(%player,%item.price * %maxnum * -1);
		}	
	}
}

//----------------------------------------------------------------------------

ItemImageData PulseSensorPackImage
{
	shapeFile = "radar_small";
	mountPoint = 2;
	mountOffset = { 0, 0, 0.1 };
	mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData PulseSensorPack
{
	description = "Pulse Sensor";
	shapeFile = "radar_small";
	className = "Backpack";
   heading = "dDeployables";
	imageType = PulseSensorPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 125;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function PulseSensorPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function PulseSensorPack::onDeploy(%player,%item,%pos)
{
	if (Item::deployShape(%player,"Pulse Sensor",DeployablePulseSensor,%item)) {
		Player::decItemCount(%player,%item);
		$TeamItemCount[GameBase::getTeam(%player) @ "PulseSensorPack"]++;
	}
}

// The Jail Cell - an original idea from the Tricon Team

ItemImageData jailpackImage
{
        shapeFile = "magcargo";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        firstPerson = false;
	mass = 1.5;
};

ItemData jailpack
{
	description = "Jail Cell";
	shapeFile = "forcefield";
	className = "Backpack";
	heading = "zJail Deployables";
	imageType = jailpackImage;
	shadowDetailMask = 4;
	mass = 5.0;
	elasticity = 0.2;
	price = 6000;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function jailpack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function jailpack::onDeploy(%player,%item,%pos)
{
        if (jailpack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function CreatejailportSimSet()
{
	%teleset = nameToID("MissionCleanup/jailports");
        if(%teleset == -1)
        {
                newObject("jailports",SimSet);
                addToSet("MissionCleanup","jailports");
        }
}

function jailpack::deployshape(%player,%item)
{
        GameBase::getLOSInfo(%player,3);
        %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ "jailpack"] >= $TeamItemMax[jailpack])
        {
		Client::sendMessage(%client,0,"Cannot Deploy. Jail Cell Already In Place");
		return false;
         }
	%playerPos = GameBase::getPosition(%player);
	%flag = $teamFlag[GameBase::getTeam(%player)];
	%flagpos = gamebase::getPosition(%flag);
	if(Vector::getDistance(%flagpos, %playerpos) < 150)
	{
                 Client::sendMessage(%client,0,"You are too close to your flag, Must be further from flag to deploy.");
                 return ;
	}
	%obj = getObjectType($los::object);
	%set = newObject("Jail",SimSet);
	%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0);
	%num = CountObjects(%set,"Jail",%num);

	%objDevice =   newObject("Jail","Staticshape",LLargeForceField,true);
	%objDevice.objSide1 = newObject("Jail","Staticshape",BLargeForceField,true);
	%objDevice.objSide2 = newObject("Jail","Staticshape",BLargeForceField,true);
	%objDevice.objSide3 = newObject("Jail","Staticshape",BLargeForceField,true);
	%objDevice.objSide4 = newObject("Jail","Staticshape",LLargeForceField,true);
	%objDevice.objSide5 = newObject("Jail","Staticshape",LLargeForceField,true);
	%objDevice.objSide6 = newObject("Jail","StaticShape",LLargeForceField,true);
	%objDevice.objSide7 = newObject("Jail","StaticShape",LLargeForceField,true);
	%objDevice.objSide8 = newObject("Jail","StaticShape",JailSwitchOpen,true);
	%objDevice.objSide9 = newObject("Jail","StaticShape",LLargeForceField,true);
	%objDevice.objSide10 = newObject("Jail","StaticShape",JailSwitchClose,true);

	%objDevice.objSide1.objParent = %objDevice;
	%objDevice.objSide2.objParent = %objDevice;
	%objDevice.objSide3.objParent = %objDevice;
	%objDevice.objSide4.objParent = %objDevice;
	%objDevice.objSide5.objParent = %objDevice;
	%objDevice.objSide6.objParent = %objDevice;
	%objDevice.objSide7.objParent = %objDevice;
	%objDevice.objSide8.objParent = %objDevice;
	%objDevice.objSide9.objParent = %objDevice;
	%objDevice.objSide10.objParent = %objDevice;

	addToSet(MissionCleanup, %objDevice);

	addToSet(MissionCleanup, %objDevice.objSide1);
	addToSet(MissionCleanup, %objDevice.objSide2);
	addToSet(MissionCleanup, %objDevice.objSide3);
	addToSet(MissionCleanup, %objDevice.objSide4);
	addToSet(MissionCleanup, %objDevice.objSide5);
	addToSet(MissionCleanup, %objDevice.objSide6);
	addToSet(MissionCleanup, %objDevice.objSide7);
	addToSet(MissionCleanup, %objDevice.objSide8);
	addToSet(MissionCleanup, %objDevice.objSide9);
	addToSet(MissionCleanup, %objDevice.objSide10);

	%pos = Vector::add(GameBase::getPosition(%player), "0 1 80");
	GameBase::setRotation(%objDevice.objSide1,"0 0 0");
	GameBase::setPosition(%objDevice.objSide1,%pos);
	GameBase::setTeam(%objDevice.objSide1,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "-5.1 6.5 80");
	GameBase::setRotation(%objDevice.objSide2,"-0.15 0 4.71339");
	GameBase::setPosition(%objDevice.objSide2,%pos);
	GameBase::setTeam(%objDevice.objSide2,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "5.1 6.5 80");
	GameBase::setRotation(%objDevice.objSide3,"0.15 0 4.71339");
	GameBase::setPosition(%objDevice.objSide3,%pos);
	GameBase::setTeam(%objDevice.objSide3,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "0 12.5 86");
	GameBase::setRotation(%objDevice.objSide4,"-4.71339 0 0");
	GameBase::setPosition(%objDevice.objSide4,%pos);
	GameBase::setTeam(%objDevice.objSide4,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "0 .5 86");
	GameBase::setRotation(%objDevice,"4.71339 0 0");
	GameBase::setPosition(%objDevice,%pos);
	GameBase::setTeam(%objDevice,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "0 12.5 80");
	GameBase::setRotation(%objDevice.objSide6,"-4.71339 0 0");
	GameBase::setPosition(%objDevice.objSide6,%pos);
	GameBase::setTeam(%objDevice.objSide6,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "0 .5 80");
	GameBase::setRotation(%objDevice.objSide7,"4.71339 0 0");
	GameBase::setPosition(%objDevice.objSide7,%pos);
	GameBase::setTeam(%objDevice.objSide7,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "-4.2 11.9 86.00");
	GameBase::setRotation(%objDevice.objSide8,"0 0 0");
	GameBase::setPosition(%objDevice.objSide8,%pos);
	GameBase::setTeam(%objDevice.objSide8,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "0 18 80");
	GameBase::setRotation(%objDevice.objSide9,"-4.71339 0 0");
	GameBase::setPosition(%objDevice.objSide9,%pos);
	GameBase::setTeam(%objDevice.objSide9,GameBase::getTeam(%player));

	%pos = Vector::add(GameBase::getPosition(%player), "4.2 11.9 86.00");
	GameBase::setRotation(%objDevice.objSide10,"0 0 0");
	GameBase::setPosition(%objDevice.objSide10,%pos);
	GameBase::setTeam(%objDevice.objSide10,GameBase::getTeam(%player));

	playSound(SoundPickupBackpack,$los::position);

	newObject("jaildoor",SimSet);
	addToSet("MissionCleanup","jaildoor");
	%sensor = newObject("jaildoor","StaticShape",jLargeForceField,true);

	addToSet("MissionCleanup/jaildoor", %sensor);
	addToSet("MissionCleanup", %sensor);
	GameBase::setTeam(%sensor,GameBase::getTeam(%player));
	%pos = Vector::add(GameBase::getPosition(%player), "0 12 80");
	GameBase::setPosition(%sensor,%pos);
	GameBase::setRotation(%sensor,"0 0 0");
	%sensor.disabled = false;
	playSound(SoundPickupBackpack,$los::position);

	%sensor = newObject("Teleport Pad","StaticShape","jailStand",true);
	CreatejailportSimSet();
	addToSet("MissionCleanup/jailports", %sensor);
	addToSet("MissionCleanup", %sensor);
	GameBase::setTeam(%sensor,GameBase::getTeam(%player));
	%pos = Vector::add(GameBase::getPosition(%player), "0 3 81");
	GameBase::setPosition(%sensor,%pos);
	Gamebase::setMapName(%sensor,"Jail Cell");

	%sensor.disabled = false;
	playSound(SoundPickupBackpack,$los::position);

	%beam = newObject("","StaticShape",ElectricalBeamBig,true);
	addToSet("MissionCleanup", %beam);
	GameBase::setTeam(%beam,GameBase::getTeam(%player));
	GameBase::setPosition(%beam,%pos);
	%sensor.beam1 = %beam;
	playSound(SoundPickupBackpack,$los::position);

	newObject("releasepad",SimSet);
	CreatereleasepadSimSet();
	addToSet("MissionCleanup/releasepad", %sensor);
	addToSet("MissionCleanup", %sensor);
	%sensor = newObject("releasepad","StaticShape","jailStandTop",true);

	addToSet("MissionCleanup/releasepad", %sensor);
	GameBase::setTeam(%sensor,GameBase::getTeam(%player));
	%pos = Vector::add(GameBase::getPosition(%player), "0 3 86.30");

	GameBase::setPosition(%sensor,%pos);
	Gamebase::setMapName(%sensor,"Jail Cell");

	%sensor.disabled = false;

	$TeamItemCount[GameBase::getTeam(%sensor) @ "jailpack"]++;
	echo("MSG: ",%client," deployed a Jail Cell");
	Client::sendMessage(%client,0,%item.description @ " deployed 250' Up");
	return true;
}

function CreatereleasepadSimSet()
{
	%teleset = nameToID("MissionCleanup/releasepad");
	if(%teleset == -1)
	{
		newObject("releasepad",SimSet);
		addToSet("MissionCleanup","releasepad");
	}
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

ItemImageData DeployableSensorJamPackImage
{
	shapeFile = "sensor_jammer";
 	mountPoint = 2;
  	mountOffset = { 0, 0.03, 0.1 };
  	mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData DeployableSensorJammerPack
{
	description = "Sensor Jammer";
  	shapeFile = "sensor_jammer";
  	className = "Backpack";
   heading = "dDeployables";
	imageType = DeployableSensorJamPackImage;
  	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
  	price = 225;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function DeployableSensorJammerPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function DeployableSensorJammerPack::onDeploy(%player,%item,%pos)
{
	if (Item::deployShape(%player,"Sensor Jammer",DeployableSensorJammer,%item)) {
		Player::decItemCount(%player,%item);
		$TeamItemCount[GameBase::getTeam(%player) @ "DeployableSensorJammerPack"]++;
	}
}


//----------------------------------------------------------------------------


ItemImageData CameraPackImage
{
	shapeFile = "camera";
	mountPoint = 2;
	mountOffset = { 0, -0.1, -0.06 };
	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData CameraPack
{
	description = "Camera";
	shapeFile = "camera";
	className = "Backpack";
   heading = "dDeployables";
	imageType = CameraPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 100;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
   validateShape = true;
   validateMaterials = true;
};

function CameraPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function CameraPack::onDeploy(%player,%item,%pos)
{
	if (CameraPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function CameraPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		%Set = newObject("set",SimSet);
						                                %Mask = $StaticObjectType;
						                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
						                                for(%i; %i < %num; %i++)
						                                {
						                                        %thing = Group::getObject(%Set, %i);
						                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
						                                        {
						                                                %inbase= true;
						                                                break;
						                                        }
						                                }
						                                deleteObject(%Set);
						                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%camera = newObject("Camera","Turret",CameraTurret,true);
	   	      addToSet("MissionCleanup", %camera);
					GameBase::setTeam(%camera,GameBase::getTeam(%player));
					GameBase::setRotation(%camera,%rot);
					GameBase::setPosition(%camera,$los::position);
					Gamebase::setMapName(%camera,"Camera#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Camera deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%camera) @ "CameraPack"]++;
					echo("MSG: ",%client," deployed a Camera");
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		else {
					//remotekill(%client);	
					bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
				}
	}
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

//----------------------USW
//function Kickabitch(%clientId)
//{
//Net::kick(%clientId, "Guess you thought you where gonna be cute and slam me eh bitch? Well I have banned your Bitch ass from ultra!.");
//}
//
//----------------------------------------------------------------------------
																			
ItemImageData LaserTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData LaserTurretPack
{
	description = "Laser Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "LUSW-Turrets";
	imageType = LaserTurretPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function LaserTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function LaserTurretPack::onDeploy(%player,%item,%pos)
{
	if (LaserTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function CountObjects(%set,%name,%num) 
{
	%count = 0;
	for(%i=0;%i<%num;%i++) {
		%obj=Group::getObject(%set,%i);
		if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) 
			%count++;
	}
	return %count;
}
function LaserTurretPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}

///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function LaserTurretPack::deployShape(%player,%item)
{
	deployable(%player,%item,"Turret","Laser Turret",False,False,False,False,False,False,4,True,100, True, "LaserTurret", "LaserTurretPack");
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//disable for stick on ceiling above
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//function LaserTurretPack::deployShape(%player,%item)
//{
//	%client = Player::getClient(%player);
//	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
//		if (GameBase::getLOSInfo(%player,3)) {
//			%obj = getObjectType($los::object);
//			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
//	    		%set = newObject("set",SimSet);
//				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
//				%num = CountObjects(%set,"LaserTurret",%num);
//				deleteObject(%set);
//				if($MaxNumTurretsInBox > %num) {
//		    		%set = newObject("set",SimSet);
//					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
//					%num = CountObjects(%set,"LaserTurret",%num);
//					deleteObject(%set);
//					if(0 == %num) {
//						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
//							if(checkDeployArea(%client,$los::position)) {
//								%rot = GameBase::getRotation(%player); 
//								%turret = newObject("remoteTurret","Turret",LaserTurret,true);
//	                     addToSet("MissionCleanup", %turret);
//								GameBase::setTeam(%turret,GameBase::getTeam(%player));
//								GameBase::setPosition(%turret,$los::position);
//								GameBase::setRotation(%turret,%rot);
//								Gamebase::setMapName(%turret,"Laser Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
//								Client::sendMessage(%client,0,"Laser Turret deployed");
//								playSound(SoundPickupBackpack,$los::position);
//								$TeamItemCount[GameBase::getTeam(%player) @ "LaserTurretPack"]++;
//								echo("MSG: ",%client," deployed a Laser Turret");
//								//	Remote turrets - kill points to player that deploy them
//								Client::setOwnedObject(%client, %turret); 
//								Client::setOwnedObject(%client, %player);
//								return true;
//							}
//						}
//						else 
//							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
//					} 
//					else
//						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
//				}
//			   else 
//					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
//			}
//			else 
//				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
//		}
//		else 
//			Client::sendMessage(%client,0,"Deploy position out of range");
//	}
//	else																						  
//	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
//
//	return false;
//}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//above disabled
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//----------------------USW

function checkDeployArea(%client,%pos)
{
  	%set=newObject("set",SimSet);
	%num=containerBoxFillSet(%set,$StaticObjectType | $ItemObjectType | $SimPlayerObjectType,%pos,1,1,1,1);
	if(!%num) {
		deleteObject(%set);
		return 1;
	}
	else if(%num == 1 && getObjectType(Group::getObject(%set,0)) == "Player") { 
		%obj = Group::getObject(%set,0);	
		if(Player::getClient(%obj) == %client)	
			Client::sendMessage(%client,0,"Unable to deploy - You're in the way");
		else
			Client::sendMessage(%client,0,"Unable to deploy - Player in the way");
	}
	else
		Client::sendMessage(%client,0,"Unable to deploy - Item in the way");

	deleteObject(%set);
	return 0;	
		

}




//----------------------------------------------------------------------------																		


//////////////////////////////////////////////////////////////////////
//function already exists above
//////////////////////////////////////////////////////////////////////
//function CountObjects(%set,%name,%num) 
//{
//	%count = 0;
//	for(%i=0;%i<%num;%i++) {
//		%obj=Group::getObject(%set,%i);
//		if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) 
//			%count++;
//	}
//	return %count;
//}
//------------------------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////
function TurretPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		
		%Set = newObject("set",SimSet);
				                                %Mask = $StaticObjectType;
				                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
				                                for(%i; %i < %num; %i++)
				                                {
				                                        %thing = Group::getObject(%Set, %i);
				                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
				                                        {
				                                                %inbase= true;
				                                                break;
				                                        }
				                                }
				                                deleteObject(%Set);
				                                if(%inbase)
                                {
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
	    		%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
				%num = CountObjects(%set,"DeployableTurret",%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num) {
		    		%set = newObject("set",SimSet);
					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
					%num = CountObjects(%set,"DeployableTurret",%num);
					deleteObject(%set);
					if(0 == %num) {
						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
							if(checkDeployArea(%client,$los::position)) {
								%rot = GameBase::getRotation(%player); 
								%turret = newObject("remoteTurret","Turret",DeployableTurret,true);
	                     addToSet("MissionCleanup", %turret);
								GameBase::setTeam(%turret,GameBase::getTeam(%player));
								GameBase::setPosition(%turret,$los::position);
								GameBase::setRotation(%turret,%rot);
								Gamebase::setMapName(%turret,"LiL Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
								Client::sendMessage(%client,0,"Fireball Turret deployed");
								playSound(SoundPickupBackpack,$los::position);
								$TeamItemCount[GameBase::getTeam(%player) @ "TurretPack"]++;
								echo("MSG: ",%client," deployed a Fireball Turret");
								//	Remote turrets - kill points to player that deploy them
								//Client::setOwnedObject(%client, %turret); 
								//Client::setOwnedObject(%client, %player);
								return true;
							}
						}
						else 
							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					} 
					else
						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
			   else 
					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		
		 else
				                                         
				                                         //remotekill(%client);
				                                         bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
				                                         //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

	return false;
}

//--USW-

//------------------------------------------------------------------------------------

ItemImageData 	TaserTrtBPackImage
{
        shapeFile = "camera";
        mountPoint = 2;
        mountOffset = { 0, -0.12, -0.1 };
        mountRotation = { 0, 0, 0 };
        mass = 1;
        firstPerson = false;
};

ItemData TaserTrtBPack
{
        description = "Taser Turret";
        shapeFile = "camera";
        className = "Backpack";
      heading = "LUSW-Turrets";
        imageType = TaserTrtBPackImage;
        shadowDetailMask = 4;
        mass = 1;
        elasticity = 0.2;
        price = 200;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};


function TaserTrtBPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function TaserTrtBPack::onDeploy(%player,%item,%pos)
{
        if (TaserTrtBPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}
function TaserTrtPack::onMount(%player,%item)
{
      Weapon::onMount(%player,%item);
	
}
///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function TaserTrtBPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		
		%Set = newObject("set",SimSet);
				                                %Mask = $StaticObjectType;
				                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
				                                for(%i; %i < %num; %i++)
				                                {
				                                        %thing = Group::getObject(%Set, %i);
				                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
				                                        {
				                                                %inbase= true;
				                                                break;
				                                        }
				                                }
				                                deleteObject(%Set);
				                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%turret = newObject("Camera","Turret",DeployableTaserTrtB,true);
	   	      addToSet("MissionCleanup", %turret);
					GameBase::setTeam(%turret,GameBase::getTeam(%player));
					GameBase::setRotation(%turret,%rot);
					GameBase::setPosition(%turret,$los::position);
					Gamebase::setMapName(%turret,"Taser Turret#"@ $totalNumTurrets++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Taser Turret deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%turret) @ "TaserTrtBPack"]++;
					echo("MSG: ",%client," deployed a Taser Turret");
					////Remote turrets - kill points to player that deploy them
					//Client::setOwnedObject(%client, %turret); 
                  			//Client::setOwnedObject(%client, %player);
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		
		 else
		//remotekill(%client);
		//Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
		bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
                }
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

/////////////////////////////////////////////////////
//this function replaced above for sticking on ceiling
/////////////////////////////////////////////////////
//function TaserTrtBPack::deployShape(%player,%item)
//{
//        %client = Player::getClient(%player);
//        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
//        {
//                if (GameBase::getLOSInfo(%player,3))
//                {
//                                %Set = newObject("set",SimSet);
//                                %Mask = $StaticObjectType;
//                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 100, 100, 100,0);
//                                for(%i; %i < %num; %i++)
//                                {
//                                        %thing = Group::getObject(%Set, %i);
//                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
//                                        {
//                                                %inbase= true;
//                                                break;
//                                        }
//                                }
//                                deleteObject(%Set);
//                                if(%inbase)
//                                {
//                                        if (Vector::dot($los::normal,"0 0 1") > 0.7)
//                                        {
//                                                if(checkDeployArea(%client,$los::position))
//                                                {
//                                                        %rot = GameBase::getRotation(%player);
//
//                                                        %turret = newObject("camera","Turret",DeployableTaserTrtB,true);
//                                                                addToSet("MissionCleanup", %turret);
//                                                        GameBase::setTeam(%turret,GameBase::getTeam(%player));
//                                                        GameBase::setPosition(%turret,$los::position);
//                                                        GameBase::setRotation(%turret,%rot);
//                                                        Gamebase::setMapName(%turret,"Taser Turret" @ Client::getName(%client));
//
//
//                                                        %backward = Vector::neg(Vector::getFromRot(%rot, 0.8));//meaning backwards a little bit.
//
//                                                        GameBase::setPosition(%cyl,Vector::add($los::position, %backward));
//                                                        GameBase::setRotation(%cyl,%rot);
//                                                        Gamebase::setMapName(%cyl,"DeployableTaserTrtB");
//
//                                                        %turret.cyl = %cyl;
//                                                        %cyl.turret = %turret;
//
//                                                        Client::sendMessage(%client,0,"Taser Turret deployed");
//                                                        playSound(SoundPickupBackpack,$los::position);
//                                                        $TeamItemCount[GameBase::getTeam(%player) @ "TaserTrtBPack"]++;
//                                                        echo("MSG: ",%client," deployed an Taser Turret");
//                                                        //        Remote turrets - kill points to player that deploy them
//                                                        Client::setOwnedObject(%client, %turret);
//                                                        Client::setOwnedObject(%client, %player);
//
//                                                        if(Player::getMountedItem(%player, $BackpackSlot) == SCVPack)
//                                                        {
//                                                                GameBase::setDamageLevel(%turret, 0.7 * TaserTrtBPack.maxDamage);
//                                                                
//                                                        }
//
//                                                        return true;
//                                                }
//                                                else
//                                                        Client::sendMessage(%client, 0, "Cannot deploy. Item in way");
//                                        }
//                                        else
//                                                Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
//                                }
//                                else
//                                        Client::sendMessage(%client,0,"You must be near your base.");          
//                }
//                else
//                        Client::sendMessage(%client,0,"Deploy position out of range");
//        }
//        else
//                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
//
//        return false;
//}
//
//
////------------------------------------------------------------------------------------

ItemImageData 	TaserTrtCPackImage
{
        shapeFile = "camera";
        mountPoint = 2;
        mountOffset = { 0, -0.12, -0.1 };
        mountRotation = { 0, 0, 0 };
        mass = 1;
        firstPerson = false;
};

ItemData TaserTrtCPack
{
        description = "Tracking Turret";
        shapeFile = "camera";
        className = "Backpack";
      heading = "LUSW-Turrets";
        imageType = TaserTrtCPackImage;
        shadowDetailMask = 4;
        mass = 1;
        elasticity = 0.2;
        price = 200;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};


function TaserTrtCPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function TaserTrtCPack::onDeploy(%player,%item,%pos)
{
        if (TaserTrtCPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}
function TaserTrtCPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}


///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function TaserTrtCPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		
		%Set = newObject("set",SimSet);
				                                %Mask = $StaticObjectType;
				                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
				                                for(%i; %i < %num; %i++)
				                                {
				                                        %thing = Group::getObject(%Set, %i);
				                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
				                                        {
				                                                %inbase= true;
				                                                break;
				                                        }
				                                }
				                                deleteObject(%Set);
				                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%turret = newObject("Camera","Turret",DeployableTaserTrtC,true);
	   	      addToSet("MissionCleanup", %turret);
					GameBase::setTeam(%turret,GameBase::getTeam(%player));
					GameBase::setRotation(%turret,%rot);
					GameBase::setPosition(%turret,$los::position);
					Gamebase::setMapName(%turret,"Taser Tracker#"@ $totalNumTurrets++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Taser Tracker deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%turret) @ "TaserTrtCPack"]++;
					echo("MSG: ",%client," deployed a Taser Tracker");
					////Remote turrets - kill points to player that deploy them
					//Client::setOwnedObject(%client, %turret); 
					//Client::setOwnedObject(%client, %player);
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		
		 else
				                                         
			//remotekill(%client);
			bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
			//Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}


//////////////////////////////////////////////////////
//function above replaces this one for stick on ceiling listening to the ORB Live93
//////////////////////////////////////////////////////
//function TaserTrtCPack::deployShape(%player,%item)
//{
//        %client = Player::getClient(%player);
//        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
//        {
//                if (GameBase::getLOSInfo(%player,3))
//                {
//                                %Set = newObject("set",SimSet);
//                                %Mask = $StaticObjectType;
//                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 100, 100, 100,0);
//                                for(%i; %i < %num; %i++)
//                                {
//                                        %thing = Group::getObject(%Set, %i);
//                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
//                                        {
//                                                %inbase= true;
//                                                break;
//                                        }
//                                }
//                                deleteObject(%Set);
//                                if(%inbase)
//                                {
//                                        if (Vector::dot($los::normal,"0 0 1") > 0.7)
//                                        {
//                                                if(checkDeployArea(%client,$los::position))
//                                                {
//                                                        %rot = GameBase::getRotation(%player);
//
//                                                        %turret = newObject("camera","Turret",DeployableTaserTrtC,true);
//                                                                addToSet("MissionCleanup", %turret);
//                                                        GameBase::setTeam(%turret,GameBase::getTeam(%player));
//                                                        GameBase::setPosition(%turret,$los::position);
//                                                        GameBase::setRotation(%turret,%rot);
//                                                        Gamebase::setMapName(%turret,"Taser Tracker" @ Client::getName(%client));
//
//
//                                                        %backward = Vector::neg(Vector::getFromRot(%rot, 0.8));//meaning backwards a little bit.
//
//                                                        GameBase::setPosition(%cyl,Vector::add($los::position, %backward));
//                                                        GameBase::setRotation(%cyl,%rot);
//                                                        Gamebase::setMapName(%cyl,"DeployableTaserTrtC");
//
//                                                        %turret.cyl = %cyl;
//                                                        %cyl.turret = %turret;
//
//                                                        Client::sendMessage(%client,0,"Taser Tracker deployed");
//                                                        playSound(SoundPickupBackpack,$los::position);
//                                                        $TeamItemCount[GameBase::getTeam(%player) @ "TaserTrtCPack"]++;
//                                                        echo("MSG: ",%client," deployed an Taser Tracker");
//                                                        //        Remote turrets - kill points to player that deploy them
//                                                        Client::setOwnedObject(%client, %turret);
//                                                        Client::setOwnedObject(%client, %player);
//
//                                                        if(Player::getMountedItem(%player, $BackpackSlot) == SCVPack)
//                                                        {
//                                                                GameBase::setDamageLevel(%turret, 0.7 * TaserTrtCPack.maxDamage);
//                                                                
//                                                        }
//
//                                                        return true;
//                                                }
//                                                else
//                                                        Client::sendMessage(%client, 0, "Cannot deploy. Item in way");
//                                        }
//                                        else
//                                                Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
//                                }
//                                else
//                                        Client::sendMessage(%client,0,"You must be near your base.");          
//                }
//                else
//                        Client::sendMessage(%client,0,"Deploy position out of range");
//        }
//        else
//                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
//
//        return false;
//}
//
//
////------------------------------------------------------------------------------------
//end dont use me
////////////////////////////////////////////////////////////////////////////////////////
//Mini-Plasma
//----------------------------------------------------------------------------
																			
ItemImageData LaserTurretBPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData LaserTurretBPack
{
	description = "Mini-Plasma Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "LUSW-Turrets";
	imageType = LaserTurretBPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function LaserTurretBPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function LaserTurretBPack::onDeploy(%player,%item,%pos)
{
	if (LaserTurretBPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

/////////////////////////////////////////////////////
//countobject already exists
////////////////////////////////////////////////////
//function CountObjects(%set,%name,%num) 
//{
//	%count = 0;
//	for(%i=0;%i<%num;%i++) {
//		%obj=Group::getObject(%set,%i);
//		if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) 
//			%count++;
//	}
//	return %count;
//}
//
///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function LaserTurretBPack::deployShape(%player,%item)
{
	deployable(%player,%item,"Turret","Mini-Plasma Turret",False,False,False,False,False,False,4,True,100, True, "LaserTurretB", "LaserTurretBPack");
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//disable for stick on ceiling above
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//function LaserTurretPack::deployShape(%player,%item)
//{
//	%client = Player::getClient(%player);
//	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
//		if (GameBase::getLOSInfo(%player,3)) {
//			%obj = getObjectType($los::object);
//			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
//	    		%set = newObject("set",SimSet);
//				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
//				%num = CountObjects(%set,"LaserTurret",%num);
//				deleteObject(%set);
//				if($MaxNumTurretsInBox > %num) {
//		    		%set = newObject("set",SimSet);
//					%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
//					%num = CountObjects(%set,"LaserTurret",%num);
//					deleteObject(%set);
//					if(0 == %num) {
//						if (Vector::dot($los::normal,"0 0 1") > 0.7) {
//							if(checkDeployArea(%client,$los::position)) {
//								%rot = GameBase::getRotation(%player); 
//								%turret = newObject("remoteTurret","Turret",LaserTurret,true);
//	                     addToSet("MissionCleanup", %turret);
//								GameBase::setTeam(%turret,GameBase::getTeam(%player));
//								GameBase::setPosition(%turret,$los::position);
//								GameBase::setRotation(%turret,%rot);
//								Gamebase::setMapName(%turret,"Laser Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
//								Client::sendMessage(%client,0,"Laser Turret deployed");
//								playSound(SoundPickupBackpack,$los::position);
//								$TeamItemCount[GameBase::getTeam(%player) @ "LaserTurretPack"]++;
//								echo("MSG: ",%client," deployed a Laser Turret");
//								//	Remote turrets - kill points to player that deploy them
//								Client::setOwnedObject(%client, %turret); 
//								Client::setOwnedObject(%client, %player);
//								return true;
//							}
//						}
//						else 
//							Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
//					} 
//					else
//						Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
//				}
//			   else 
//					Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
//			}
//			else 
//				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
//		}
//		else 
//			Client::sendMessage(%client,0,"Deploy position out of range");
//	}
//	else																						  
//	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
//
//	return false;
//}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//above disabled
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ItemImageData MiniFlakTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData MiniFlakTurretPack
{
	description = "Mini-Flak Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "LUSW-Turrets";
	imageType = MiniFlakTurretPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function MiniFlakTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function MiniFlakTurretPack::onDeploy(%player,%item,%pos)
{
	if (MiniFlakTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

//////////////////////////////////////////
//function CountObjects(%set,%name,%num) 
//{
//	%count = 0;
//	for(%i=0;%i<%num;%i++) {
//		%obj=Group::getObject(%set,%i);
//		if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) 
//			%count++;
//	}
//	return %count;
//}
///////////////////////////////////////////

///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function MiniFlakTurretPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		
		%Set = newObject("set",SimSet);
		                                %Mask = $StaticObjectType;
		                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
		                                for(%i; %i < %num; %i++)
		                                {
		                                        %thing = Group::getObject(%Set, %i);
		                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
		                                        {
		                                                %inbase= true;
		                                                break;
		                                        }
		                                }
		                                deleteObject(%Set);
		                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					
					
					
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%turret = newObject("remoteTurret","Turret",MiniFlakTurret,true);
	   	      addToSet("MissionCleanup", %turret);
					GameBase::setTeam(%turret,GameBase::getTeam(%player));
					GameBase::setRotation(%turret,%rot);
					GameBase::setPosition(%turret,$los::position);
					Gamebase::setMapName(%turret,"Mini-Flak Turret#"@ $totalNumTurrets++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Mini-Flak Turret deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%turret) @ "MiniFlakTurretPack"]++;
					echo("MSG: ",%client," deployed a Mini-Flak Turret");
					////	Remote turrets - kill points to player that deploy them
					Client::setOwnedObject(%client, %turret); 
                                        Client::setOwnedObject(%client, %player);
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		
		 else {
		                                         
		       //remotekill(%client);
		       bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
		       //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
		 
               }
	}
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

//----------------------------------------------------------------------------

ItemImageData MiniSAMTurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData MiniSAMTurretPack
{
	description = "Mini-S.A.M Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
   heading = "LUSW-Turrets";
	imageType = MiniSAMTurretPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function MiniSAMTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function MiniSAMTurretPack::onDeploy(%player,%item,%pos)
{
	if (MiniSAMTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}
function MiniSAMTurretPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}
//////////////////////////////////////////
//function CountObjects(%set,%name,%num) 
//{
//	%count = 0;
//	for(%i=0;%i<%num;%i++) {
//		%obj=Group::getObject(%set,%i);
//		if(GameBase::getDataName(Group::getObject(%set,%i)) == %name) 
//			%count++;
//	}
//	return %count;
//}
///////////////////////////////////////////

///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function MiniSAMTurretPack::deployShape(%player,%item)
{
	deployable(%player,%item,"Turret","Mini-S.a.m Turret",False,False,False,False,False,False,4,True,100, True, "MiniSAMTurret", "MiniSAMTurretPack");
}

//----------------------------------------------------------------------------

ItemImageData 	MiniELFTurretPackImage
{
        shapeFile = "camera";
        mountPoint = 2;
        mountOffset = { 0, -0.12, -0.1 };
        mountRotation = { 0, 0, 0 };
        mass = 1;
        firstPerson = false;
};

ItemData MiniELFTurretPack
{
        description = "Mini-ELF Turret";
        shapeFile = "camera";
        className = "Backpack";
      heading = "LUSW-Turrets";
        imageType = MiniELFTurretPackImage;
        shadowDetailMask = 4;
        mass = 1;
        elasticity = 0.2;
        price = 200;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};


function MiniELFTurretPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function MiniELFTurretPack::onDeploy(%player,%item,%pos)
{
        if (MiniELFTurretPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function MiniELFTurretPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		
		%Set = newObject("set",SimSet);
				                                %Mask = $StaticObjectType;
				                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
				                                for(%i; %i < %num; %i++)
				                                {
				                                        %thing = Group::getObject(%Set, %i);
				                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
				                                        {
				                                                %inbase= true;
				                                                break;
				                                        }
				                                }
				                                deleteObject(%Set);
				                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%elfturret = newObject("camera","Turret",MiniELFTurret,true);
	   	      addToSet("MissionCleanup", %elfturret);
					GameBase::setTeam(%elfturret,GameBase::getTeam(%player));
					GameBase::setRotation(%elfturret,%rot);
					GameBase::setPosition(%elfturret,$los::position);
					Gamebase::setMapName(%elfturret,"Mini-ELF#"@ $totalNumTurrets++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Mini-ELF deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%elfturret) @ "MiniELFTurretPack"]++;
					echo("MSG: ",%client," deployed a Mini-ELF");
					////Remote turrets - kill points to player that deploy them
					Client::setOwnedObject(%client, %elfturret); 
					Client::setOwnedObject(%client, %player);
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		
		 else
				                                         
			//remotekill(%client);
			bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
			//Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

//----------------------------------------------------------------------------


ItemImageData 	MiniSmokeTurretPackImage
{
        shapeFile = "camera";
        mountPoint = 2;
        mountOffset = { 0, -0.12, -0.1 };
        mountRotation = { 0, 0, 0 };
        mass = 1;
        firstPerson = false;
};

ItemData MiniSmokeTurretPack
{
        description = "Mini-Beam Of Pain";
        shapeFile = "camera";
        className = "Backpack";
      heading = "LUSW-Turrets";
        imageType = MiniSmokeTurretPackImage;
        shadowDetailMask = 4;
        mass = 1;
        elasticity = 0.2;
        price = 200;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};


function MiniSmokeTurretPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function MiniSmokeTurretPack::onDeploy(%player,%item,%pos)
{
        if (MiniSmokeTurretPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}
function MiniSmokeTurretPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}

///////////////////////////////////////////////////
//stick on ceiling modified from camera deploy function
///////////////////////////////////////////////////
function MiniSmokeTurretPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
		
		%Set = newObject("set",SimSet);
				                                %Mask = $StaticObjectType;
				                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
				                                for(%i; %i < %num; %i++)
				                                {
				                                        %thing = Group::getObject(%Set, %i);
				                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
				                                        {
				                                                %inbase= true;
				                                                break;
				                                        }
				                                }
				                                deleteObject(%Set);
				                                if(%inbase)
                                {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%elfturret = newObject("camera","Turret",MiniSmokeTurret,true);
	   	      addToSet("MissionCleanup", %elfturret);
					GameBase::setTeam(%elfturret,GameBase::getTeam(%player));
					GameBase::setRotation(%elfturret,%rot);
					GameBase::setPosition(%elfturret,$los::position);
					Gamebase::setMapName(%elfturret,"Mini-Beam Of Pain#"@ $totalNumTurrets++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Mini-Beam Of Pain deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%elfturret) @ "MiniSmokeTurretPack"]++;
					echo("MSG: ",%client," deployed a Mini-Beam Of Pain");
					////Remote turrets - kill points to player that deploy them
					Client::setOwnedObject(%client, %elfturret); 
					Client::setOwnedObject(%client, %player);
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		
		 else
				                                         
			//remotekill(%client);
			bottomprint(%client, "                             Fair play distance exceeded for " @ %item.description @ "s", 3);
			//Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

//----------------------------------------------------------------------------

ItemImageData lgaForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData lgaForceFieldPack
{
        description = "LgaForceFieldDoor";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "kForce Fields";
        imageType = lgaForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function lgaForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function lgaForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (lgaForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function lgaForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {
                
                %Set = newObject("set",SimSet);
								                                %Mask = $StaticObjectType;
								                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
								                                for(%i; %i < %num; %i++)
								                                {
								                                        %thing = Group::getObject(%Set, %i);
								                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
								                                        {
								                                                %inbase= true;
								                                                break;
								                                        }
								                                }
								                                deleteObject(%Set);
								                                if(%inbase)
                                {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("lgaForceFieldPack","StaticShape",lgaForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "lgaForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a Force Field Door ");
                                        return true;

                        }
                        else
									                                         
									                                         //remotekill(%client);
									                                         bottomprint(%client, "                         Fair play distance exceeded for " @ %item.description @ "s", 3);
									                                         //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
                        
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}


//----------------------------------------------------------------------------

ItemImageData lgbForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData lgbForceFieldPack
{
        description = "LgbForceFieldDoor";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "kForce Fields";
        imageType = lgbForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function lgbForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function lgbForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (lgbForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function lgbForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {
                
                %Set = newObject("set",SimSet);
								                                %Mask = $StaticObjectType;
								                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
								                                for(%i; %i < %num; %i++)
								                                {
								                                        %thing = Group::getObject(%Set, %i);
								                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
								                                        {
								                                                %inbase= true;
								                                                break;
								                                        }
								                                }
								                                deleteObject(%Set);
								                                if(%inbase)
                                {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("lgbForceFieldPack","StaticShape",lgbForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "lgbForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a Force Field Door ");
                                        return true;

                        }
                        else
									                                         
									                                         //remotekill(%client);
									                                         bottomprint(%client, "                         Fair play distance exceeded for " @ %item.description @ "s", 3);
									                                         //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
                        
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}


//----------------------------------------------------------------------------
ItemImageData medaForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData medaForceFieldPack
{
        description = "MedaForceFieldDoor";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "kForce Fields";
        imageType = medaForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function medaForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function medaForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (medaForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function medaForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {
                
                %Set = newObject("set",SimSet);
								                                %Mask = $StaticObjectType;
								                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
								                                for(%i; %i < %num; %i++)
								                                {
								                                        %thing = Group::getObject(%Set, %i);
								                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
								                                        {
								                                                %inbase= true;
								                                                break;
								                                        }
								                                }
								                                deleteObject(%Set);
								                                if(%inbase)
                                {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("medaForceFieldPack","StaticShape",medaForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "medaForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a Force Field Door ");
                                        return true;

                        }
                        
                        else
									                                         
									                                         //remotekill(%client);
									                                         bottomprint(%client, "                         Fair play distance exceeded for " @ %item.description @ "s", 3);
									                                         //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}


//----------------------------------------------------------------------------
ItemImageData medbForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData medbForceFieldPack
{
        description = "MedbForceFieldDoor";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "kForce Fields";
        imageType = medbForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function medbForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function medbForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (medbForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function medbForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {
                
                %Set = newObject("set",SimSet);
								                                %Mask = $StaticObjectType;
								                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
								                                for(%i; %i < %num; %i++)
								                                {
								                                        %thing = Group::getObject(%Set, %i);
								                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
								                                        {
								                                                %inbase= true;
								                                                break;
								                                        }
								                                }
								                                deleteObject(%Set);
								                                if(%inbase)
                                {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("medbForceFieldPack","StaticShape",medbForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "medbForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a Force Field Door ");
                                        return true;

                        }
                        else
									                                         
									                                         //remotekill(%client);
									                                         bottomprint(%client, "                         Fair play distance exceeded for " @ %item.description @ "s", 3);
									                                         //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
                        
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}


//----------------------------------------------------------------------------
ItemImageData medcForceFieldPackImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData medcForceFieldPack
{
        description = "MedcForceFieldDoor";
        shapeFile = "AmmoPack";
        className = "Backpack";
        heading = "kForce Fields";
        imageType = medcForceFieldPackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function medcForceFieldPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function medcForceFieldPack::onDeploy(%player,%item,%pos)
{
        if (medcForceFieldPack::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function medcForceFieldPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {
                
                %Set = newObject("set",SimSet);
								                                %Mask = $StaticObjectType;
								                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
								                                for(%i; %i < %num; %i++)
								                                {
								                                        %thing = Group::getObject(%Set, %i);
								                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
								                                        {
								                                                %inbase= true;
								                                                break;
								                                        }
								                                }
								                                deleteObject(%Set);
								                                if(%inbase)
                                {
                

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("medcForceFieldPack","StaticShape",medcForceFieldShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"Force Field Door#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Force Field Door deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "medcForceFieldPack"]++;
                                        echo("MSG: ",%client," deployed a Force Field Door ");
                                        return true;

                        }
                        
                        else
									                                         
									                                         //remotekill(%client);
									                                         bottomprint(%client, "                         Fair play distance exceeded for " @ %item.description @ "s", 3);
									                                         //Client::sendMessage(%client,0,"Fair play distance exceeded for " @ %item.description @ "s");
                }
                        
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
ItemImageData TeleportPackImage
{
	shapeFile = "flagstand";
	mountPoint = 2;
	mountOffset = { 0, 0, 0.1 };
	mountRotation = { 1.57, 0, 0 };
	firstPerson = false;
};

ItemData TeleportPack
{
	description = "Teleport Pad";
	shapeFile = "flagstand";
	className = "Backpack";
    heading = "dDeployables";
	imageType = TeleportPackImage;
	shadowDetailMask = 4;
	mass = 1;
	elasticity = 0.2;
	price = 3200;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function TeleportPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function TeleportPack::onDeploy(%player,%item,%pos)
{
	if (teleportPack::deployShape(%player,"Teleport Pad",DeployableTeleport,%item)) {
		Player::decItemCount(%player,%item);
		$TeamItemCount[GameBase::getTeam(%player) @ "DeployableTeleport"]++;
	}
}

function CreateteleportSimSet()
{
    %teleset = nameToID("MissionCleanup/Teleports");
	if(%teleset == -1)
	{
		newObject("Teleports",SimSet);
		addToSet("MissionCleanup","Teleports");
	}
}

function TeleportPack::deployShape(%player,%name,%shape,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ "DeployableTeleport"] < $TeamItemMax[DeployableTeleport]) {
		if (GameBase::getLOSInfo(%player,3)) {
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
%Set = newObject("set",SimSet);
				                                %Mask = $StaticObjectType;
				                                %num =containerBoxFillSet(%Set, %Mask, $los::position, 150, 150, 150,0);
				                                for(%i; %i < %num; %i++)
				                                {
				                                        %thing = Group::getObject(%Set, %i);
				                                        if(GameBase::getTeam(%thing) == GameBase::getTeam(%player))
				                                        {
				                                                %inbase= true;
				                                                break;
				                                        }
				                                }
				                                deleteObject(%Set);
				                                if(%inbase)
                {
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {

				if (Vector::dot($los::normal,"0 0 1") > 0.7) {
					if(checkDeployArea(%client,$los::position)) {
						%sensor = newObject("Teleport Pad","StaticShape",%shape,true);
						CreateteleportSimSet();
                        addToSet("MissionCleanup/Teleports", %sensor);
				addToSet("MissionCleanup", %sensor);
						GameBase::setTeam(%sensor,GameBase::getTeam(%player));
						%pos = Vector::add($los::position,"0 0 1");
						echo("LOS pos " @ $los::position @ " " @ %pos);
						GameBase::setPosition(%sensor,%pos);
						Gamebase::setMapName(%sensor,%name);
						Client::sendMessage(%client,0,%item.description @ " deployed");
						%sensor.disabled = false;
						playSound(SoundPickupBackpack,$los::position);

						%beam = newObject("","StaticShape",ElectricalBeamBig,true);
                        		addToSet("MissionCleanup", %beam);
						GameBase::setTeam(%beam,GameBase::getTeam(%player));
						GameBase::setPosition(%beam,%pos);
						%sensor.beam1 = %beam;

						

//				            schedule("DeployableTeleport::Destruct("@%sensor@");",600);
						return true;
					}
				}
				else 
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		////////////////////////////////////////////////////////////////////////////////////////
		 else
		 bottomprint(%client, "                         Fair play distance exceeded for " @ %item.description @ "s", 3);
		}
		/////////////////////////////////////////////////////////////////////////////////////////
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %name @ "s");
	return false;
}

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Remote deploy for items

function Item::deployShape(%player,%name,%shape,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape") {
				if (Vector::dot($los::normal,"0 0 1") > 0.7) {
					if(checkDeployArea(%client,$los::position)) {
						%sensor = newObject("","Sensor",%shape,true);
 	        	   	addToSet("MissionCleanup", %sensor);
						GameBase::setTeam(%sensor,GameBase::getTeam(%player));
						GameBase::setPosition(%sensor,$los::position);
						Gamebase::setMapName(%sensor,%name);
						Client::sendMessage(%client,0,%item.description @ " deployed");
						playSound(SoundPickupBackpack,$los::position);
						echo("MSG: ",%client," deployed a ",%name);
						return true;
					}
				}
				else 
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			}
			else 
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %name @ "s");
	return false;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

$AutoUse[RepairKit] = false;

ItemData RepairKit
{
   description = "Repair Kit";
   shapeFile = "armorKit";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 35;
   validateShape = true;
   validateMaterials = true;
};

function RepairKit::onUse(%player,%item)
{
	Player::decItemCount(%player,%item);
	GameBase::repairDamage(%player,0.99);
}

//----------------------------------------------------------------------------

ItemData MineAmmo
{
   description = "Mine";
   shapeFile = "mineammo";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 10;
   className = "HandAmmo";
   validateShape = true;
   validateMaterials = true;
};

function MineAmmo::onUse(%player,%item)
{
        if($matchStarted) {
                if(%player.throwTime < getSimTime() ) {
                        Player::decItemCount(%player,%item);
                        %obj = newObject("","Mine","antipersonelMine");
                         addToSet("MissionCleanup", %obj);
                        %client = Player::getClient(%player);
                        GameBase::throw(%obj,%player,15 * %client.throwStrength,false);
                        %player.throwTime = getSimTime() + 0.5;
                  GameBase::setTeam (%obj,GameBase::getTeam (%client));
                }
        }
}

//----------------------------------------------------------------------
ItemData RadiusMineAmmo
{
   description = "Radius Mine";
   shapeFile = "mineammo";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 10;
        className = "HandAmmo";
};

function RadiusMineAmmo::onUse(%player,%item)
{
        if($matchStarted) {
                if(%player.throwTime < getSimTime() ) {
                        Player::decItemCount(%player,%item);
                        %obj = newObject("","Mine","radiusMine");
                         addToSet("MissionCleanup", %obj);
                        %client = Player::getClient(%player);
                        GameBase::throw(%obj,%player,15 * %client.throwStrength,false);
                        %player.throwTime = getSimTime() + 0.5;
                  GameBase::setTeam (%obj,GameBase::getTeam (%client));
                }
        }
}

//---------------------------------------------------------------------------
ItemData Grenade
{
   description = "Grenade";
   shapeFile = "grenade";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 5;
	className = "HandAmmo";
   validateShape = true;
   validateMaterials = true;
};

function Grenade::onUse(%player,%item)
{
  if($matchStarted) {
	  Player::decItemCount(%player,%item);
	  %client = Player::getClient(%player);	
          %velocity = Item::getVelocity(%player);
    	  %velX = getWord(%velocity, 0);
    	  %velY = getWord(%velocity, 1);
	  %velZ = getWord(%velocity, 2);
	  %velXa = %velX / 6;
	  %velYa = %velY / 6;
	  %velZa = %velZ / 6;
	  Item::setVelocity(%player, %velXa @ " " @ %velYa @ " " @ %velZa);
	  Client::sendMessage(%client,0,"You use an AirBrake.");
	}
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

ItemData FlashGrenade
{
   description = "FlashGrenade";
   shapeFile = "grenade";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 5;
	className = "HandAmmo";
   validateShape = true;
   validateMaterials = true;
};

function FlashGrenade::onUse(%player,%item)
{
	if($matchStarted) {
		if(%player.throwTime < getSimTime() ) {
			Player::decItemCount(%player,%item);
			%obj = newObject("","Mine","Flash");
 	 	 	addToSet("MissionCleanup", %obj);
			%client = Player::getClient(%player);
			GameBase::throw(%obj,%player,9 * %client.throwStrength,false);
			%player.throwTime = getSimTime() + 0.5;
		}
	}
}


//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

ItemData LiLBoostammo
{
   description = "LiLBoost";
   shapeFile = "sensor_small";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 5;
        className = "HandAmmo";
};

function LiLBoostammo::onUse(%player,%item)
{
        //if (Beacon::deployShape(%player,%item)) {
        //        Player::decItemCount(%player,%item);
//        }
if($matchStarted) {
                if(%player.throwTime < getSimTime() ) {
                        Player::decItemCount(%player,%item);
                        %obj = newObject("","Mine","LiLBoost");
                         addToSet("MissionCleanup", %obj);
                        %client = Player::getClient(%player);
                        GameBase::throw(%obj,%player,0,false);
                        %player.throwTime = getSimTime() + 0.5;
                        Client::sendMessage(Player::getClient(%player),0,"You use a LiL Booster.");
                }
        }
}


//----------------------------------------------------------------------------

ItemData USWGasAttackAmmo
{
   description = "Claymor Mine";
   shapeFile = "mineammo";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 10;
        className = "HandAmmo";
};

function USWGasAttackAmmo::onUse(%player,%item)
{
        if($matchStarted) {
                if(%player.throwTime < getSimTime() ) {
                        Player::decItemCount(%player,%item);
                        %obj = newObject("","Mine","USWGasAttack");
                         addToSet("MissionCleanup", %obj);
                        %client = Player::getClient(%player);
                        GameBase::throw(%obj,%player,15 * %client.throwStrength,false);
                        %player.throwTime = getSimTime() + 0.5;
                  GameBase::setTeam (%obj,GameBase::getTeam (%client));
                }
        }
}

//----------------------------------------------------------------------------

ItemData Beacon
{
   description = "Beacon";
   shapeFile = "sensor_small";
   heading = "eMiscellany";
   shadowDetailMask = 4;
   price = 5;
        className = "HandAmmo";
};

function Beacon::onUse(%player,%item)
{
        //if (Beacon::deployShape(%player,%item)) {
        //        Player::decItemCount(%player,%item);
        //}
                if($matchStarted) {
                if(%player.throwTime < getSimTime() ) {
                        Player::decItemCount(%player,%item);
                        %obj = newObject("","Mine","boost");
                         addToSet("MissionCleanup", %obj);
                        %client = Player::getClient(%player);
                        GameBase::throw(%obj,%player,0,false);
                        %player.throwTime = getSimTime() + 0.2;
                        Client::sendMessage(Player::getClient(%player),0,"You use a Speed Booster.");
                }
        }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

ItemData RepairPatch
{
	description = "Repair Patch";
	className = "Repair";
	shapeFile = "armorPatch";
   heading = "eMiscellany";
	shadowDetailMask = 4;
  	price = 2;
   validateShape = true;
   validateMaterials = true;
};

function RepairPatch::onCollision(%this,%object)
{
	if (getObjectType(%object) == "Player") {
		if(GameBase::getDamageLevel(%object)) {
			GameBase::repairDamage(%object,0.5);
			%item = Item::getItemData(%this);
			Item::playPickupSound(%this);
			Item::respawn(%this);
		}
	}
}

function RepairPatch::onUse(%player,%item)
{
	Player::decItemCount(%player,%item);
	GameBase::repairDamage(%player,0.1);
}

ItemImageData 	cactuspackImage
{
        shapeFile = "cactus2";
        mountPoint = 2;
        mountOffset = { 0, 0.2, -1.7 };
        mountRotation = { 0, 0, 0 };
        mass = 1;
        firstPerson = false;
};

ItemData cactusPack
{
        description = "Land Camo";
        shapeFile = "cactus2";
        className = "Backpack";
      heading = "eMiscellany";
        imageType = cactuspackImage;
        shadowDetailMask = 4;
        mass = 1;
        elasticity = 0.2;
        price = 200;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

//------------------------------------

ItemImageData RailTurretImage
{
shapeFile = "remoteturret";
mountPoint = 2;
mountOffset = { 0, -0.12, -0.1 };
mountRotation = { 0, 0, 0 };
mass = 2.5;
firstPerson = false;
};
 
ItemData RailTurret
{
description = "Rail Turret";
shapeFile = "remoteturret";
className = "Backpack";
heading = "LUSW-Turrets";
imageType = RailTurretImage;
shadowDetailMask = 4;
mass = 2.0;
elasticity = 0.2;
price = 850;
hudIcon = "deployable";
showWeaponBar = true;
hiliteOnActive = true;
}; 

function RailTurret::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
		{
		Player::mountItem(%player,%item,$BackpackSlot);
		}
	else
		{
		Player::deployItem(%player,%item);
		}
}

function RailTurret::onDeploy(%player,%item,%pos)
{
	if (RailTurret::deployShape(%player,%item))
		{
		Player::decItemCount(%player,%item);
		}
}



function CountObjects(%set,%name,%num)
{
%count = 0; for(%i=0;%i<%num;%i++)
	{
	%obj=Group::getObject(%set,%i);
	if(GameBase::getDataName(Group::getObject(%set,%i)) == %name)
	%count++;
	}
return %count;
}

function RailTurret::deployShape(%player,%item)
{
%client = Player::getClient(%player);
if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
	{
	if (GameBase::getLOSInfo(%player,3))
		{
		%obj = getObjectType($los::object);
		if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform")
			{
			%set = newObject("set",SimSet);
			%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMaxLength,$TurretBoxMaxWidth,$TurretBoxMaxHeight,0);
			%num = CountObjects(%set,"DeployableVulcan",%num);
			deleteObject(%set);
			if($MaxNumTurretsInBox > %num)
				{
				%set = newObject("set",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
				%num = CountObjects(%set,"DeployablePlasma",%num);
				deleteObject(%set); if(0 == %num)
					{
					if (Vector::dot($los::normal,"0 0 1") > 0.7)
						{
						if(checkDeployArea(%client,$los::position))
							{
							%rot = GameBase::getRotation(%player);
							%turret = newObject("hellfiregun","Turret",DeployableRail,true);
							addToSet("MissionCleanup", %turret);
							GameBase::setTeam(%turret,GameBase::getTeam(%player));
							GameBase::setPosition(%turret,$los::position);
							GameBase::setRotation(%turret,%rot);
							Gamebase::setMapName(%turret,"Rail Turret#" @ $totalNumTurrets++ @ " " @ Client::getName(%client));
							Client::sendMessage(%client,0,"Rail Turret deployed");
							playSound(SoundPickupBackpack,$los::position);
							$TeamItemCount[GameBase::getTeam(%player) @ "RailTurret"]++; return true;
							}
						}
						else Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
					}
					else Client::sendMessage(%client,0,"Frequency Overload - Too close to other remote turrets");
				}
				else Client::sendMessage(%client,0,"Interference from other remote turrets in the area");
			}
			else Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	return false;
}
function RailTurret::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}

//--------------------------------------------------------

//-------------------------------------------------------------------
// Arbitor Device - from the Ideal mod

ItemImageData ArbitorBoxPackImage
{
	shapeFile = "magcargo";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData ArbitorBoxPack
{
	description = "Arbitor Device";
	shapeFile = "magcargo";
	className = "Backpack";
	heading = "dDeployables";
	imageType = ArbitorBoxPackImage;
	shadowDetailMask = 4;
	mass = 2.5;
	elasticity = 0.2;
	price = 1350;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};


function ArbitorBoxPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
	{
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else
	{
		Player::deployItem(%player,%item);
	}
}

function ArbitorBoxPack::onDeploy(%player,%item,%pos)
{
	if (ArbitorBoxPack::deployShape(%player,%item))
	{
		Player::decItemCount(%player,%item);
	}
}

function ArbitorBoxPack::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item])
	{
		if (GameBase::getLOSInfo(%player,3))
		{
			%obj = getObjectType($los::object);
			if (CheckDeployTerrain($los::object,%client,"Most"))
			{
				if (Vector::dot($los::normal,"0 0 1") > 0.7)
				{
					if(checkDeployArea(%client,Vector::add($los::position, "0.2 0.2 0")))
					{
						%rot = GameBase::getRotation(%player); 
						%turret = newObject("Arbitor Device","Turret",ArbitorBox,true);
                 				addToSet("MissionCleanup", %turret);
						GameBase::setTeam(%turret,GameBase::getTeam(%player));
						GameBase::setPosition(%turret,$los::position);
						GameBase::setRotation(%turret,%rot);
						Gamebase::setMapName(%turret,"Arbitor Device " @ Client::getName(%client));
						Client::sendMessage(%client,0,"Arbitor Device deployed");
						playSound(SoundPickupBackpack,$los::position);
						$TeamItemCount[GameBase::getTeam(%player) @ "ArbitorBoxPack"]++;
						echo("MSG: ",%client," deployed an Arbitor Device");
						return true;
					}
				}
				else 
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			}
		//	else 
		//		Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else 
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "es");

	return false;
}
function SeekerPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}
//----------------------------------------------------------------
// Sentry Turret - modified as part of Orion

ItemImageData TurretPackImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.12, -0.1 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData TurretPack
{
	description = "Ion Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
	heading = "LUSW-Turrets";
	imageType = TurretPackImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 300;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function TurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
	{
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else
	{
		Player::deployItem(%player,%item);
	}
}

function TurretPack::onDeploy(%player,%item,%pos)
{
	if (TurretPack::deployShape(%player,%item))
	{
		Player::decItemCount(%player,%item);
	}
}

function TurretPack::deployShape(%player,%item)
{
	deployable(%player,%item,"Turret","Ion Turret",False,False,False,False,False,False,4,True,100, True, "DeployableTurret", "TurretPack");
}
function TurretPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}


// Seeker Turret - based upon hvTactical's Watchdog but modified by Epsilon

ItemImageData SeekerImage
{
	shapeFile = "remoteturret";
	mountPoint = 2;
	mountOffset = { 0, -0.1, -0.06 };
	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData SeekerPack
{
	description = "Fireball Turret";
	shapeFile = "remoteturret";
	className = "Backpack";
	heading = "LUSW-Turrets";
	imageType = SeekerImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 420;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function SeekerPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
	{
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else
	{
		Player::deployItem(%player,%item);
	}
}

function SeekerPack::onDeploy(%player,%item,%pos)
{
	if (SeekerPack::deployShape(%player,%item))
	{
		Player::decItemCount(%player,%item);
	}
}

function SeekerPack::deployShape(%player,%item)
{
	DeployIt(%player,%item,"Turret","Fireball Turret",False,"Camera",1,"Any",False,3,True,"DeployableSeeker","SeekerPack");
}
function SeekerPack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}
//------------------------------------------------------------------
ItemImageData BlastWallImage
{
        shapeFile = "AmmoPack";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData BlastWall
{
        description = "Blast Wall";
        shapeFile = "newdoor5";
        className = "Backpack";
        heading = "nDeployable Walls";
        imageType = BlastWallImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function BlastWall::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function BlastWall::onDeploy(%player,%item,%pos)
{
        if (BlastWall::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}

function BlastWall::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {

                        %obj = getObjectType($los::object);
                                %rot = GameBase::getRotation(%player);

                                        %camera = newObject("BlastWall","StaticShape",BlastWallShape,true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,%rot);
                                        GameBase::setPosition(%camera,$los::position);
                                        Gamebase::setMapName(%camera,"Wall#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Wall deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%camera) @ "BlastWall"]++;
                                        echo("MSG: ",%client," deployed a Blast Wall");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}

//--------------------------------------------------------------------
ItemImageData EnergizerPackImage
{
	shapeFile = "sensorjampack"; // Changed to make it look better. :)
	weaponType = 2;  // Sustained

	mountPoint = 2;
	mountOffset = { 0, -0.1, 0 };

	minEnergy = -15; // This is where it negates the armors jet drain. By in creasing its recharge rate.
 	maxEnergy = 0.1;// -20; // This is where it negates the armors jet drain. By in creasing its recharge rate.
	firstPerson = false;
};

ItemData EnergizerPack
{
	description = "X's Armor";
	shapeFile = "mortarpack"; // Changed to make it look better. :)
	className = "Backpack";
   heading = "cBackpacks";
	shadowDetailMask = 4;
	imageType = EnergizerPackImage;
	price = 150;
	hudIcon = "energypack";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function EnergizerPackImage::onActivate(%player,%imageSlot)
{
	Client::sendMessage(Player::getClient(%player),0,"God Shield On :)");
	%player.shieldStrength = 500.008;
	%rate = Player::getSensorSupression(%player) + 5;
	Player::setSensorSupression(%player,%rate);
}

function EnergizerPackImage::onDeactivate(%player,%imageSlot)
{
	Client::sendMessage(Player::getClient(%player),0,"God Shield Off :(");
	Player::trigger(%player,$BackpackSlot,false);
	%player.shieldStrength = 0;
	%rate = Player::getSensorSupression(%player) - 5;
	Player::setSensorSupression(%player,%rate);
}

//----------------------------------------
ItemImageData RepairRifleImage
{
	shapeFile = "sniper";
	mountPoint = 0;

	weaponType = 2; // Sustained
	projectileType = RepairRifleBolt;
	accuFire = true;
//	reloadTime = 0.1;
//	fireTime = 0.5;
	minEnergy  = 3;
	maxEnergy = 10;  // Energy used/sec for sustained weapons

	lightType = 3;  // Weapon Fire
	lightRadius = 2;
	lightTime = 1;
	lightColor  = { 0.25, 1, 0.25 };

	sfxFire = SoundRepairItem;
	sfxActivate = SoundPickUpWeapon;
};

ItemData RepairRifle
{
	description = "Repair Rifle";
	className = "Weapon";
	shapeFile = "sniper";
	hudIcon = "repairpack";
   heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = RepairRifleImage;
	price = 500;
	showWeaponBar = true;
};

function RepairRifle::onUse(%player,%item)
{
	Weapon::onUse(%player,%item);
	
}
////////////////////////////////////////////////////////////////////////////
//////modified by Dustin Bruce so you dont need that dumb energizer pack////
////////////////////////////////////////////////////////////////////////////

//	  if(Player::getMountedItem(%player,$BackpackSlot) == EnergizerPack)
//		Weapon::onUse(%player,%item);
//   	else
//		Client::sendMessage(Player::getClient(%player),0,
//			"Must have an Energizer Pack to use Repair Rifle."); 
//}
//------------------------------------------------------------------
ItemImageData JailCapPackImage
{
        shapeFile = "flagstand";
        mountOffset = { 0, 0, 0.1 };
	  mountRotation = { 1.57, 0, 0 };
        mass = 2.5;
        firstPerson = false;
};

ItemData JailCapPack
{
        description = "Jail Capture Pad";
        shapeFile = "flagstand";
        className = "Backpack";
        heading = "zJail Deployables";
        imageType = JailCapPackImage;
        shadowDetailMask = 4;
        mass = 1.0;
        elasticity = 0.2;
        price = 500;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function JailCapPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else {
                Player::deployItem(%player,%item);
        }
}

function JailCapPack::onDeploy(%player,%item,%pos)
{
        if (JailCapPack::deployShape(%player,%item)) {
                Player::decItemCount(%player,%item);
        }
}
function JailCapPack::deployShape(%player,%item)
{
         %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
                if (GameBase::getLOSInfo(%player,3)) {

                        %obj = getObjectType($los::object);

                         %playerPos = GameBase::getPosition(%player);
                         %flag = $teamFlag[GameBase::getTeam(%player)];
                         %flagpos = gamebase::getPosition(%flag);

                         if(Vector::getDistance(%flagpos, %playerpos) < 10)
                          {
                          Client::sendMessage(%client,0,"You are too close to your flag, Must be further from flag to deploy.");
                          return;
                          }


                                %prot = GameBase::getRotation(%player);
                                %zRot = getWord(%prot,2);
                                %rot =  "1.57079 0 " @ %zRot;
                                %padd = "0 0 0";
                                %pos = Vector::add($los::position,%padd);
//
                                        %camera = newObject("","StaticShape","jailpad",true);
                                        addToSet("MissionCleanup", %camera);
                                        GameBase::setTeam(%camera,GameBase::getTeam(%player));
                                        GameBase::setRotation(%camera,"0 0 0");
                                        GameBase::setPosition(%camera,%pos);
                                        Gamebase::setMapName(%camera,"JailPad " @ $totalNumCameras++ @ " " @ Client::getName(%client));
                                        Client::sendMessage(%client,0,"Jail Pad Deployed");
                                        playSound(SoundPickupBackpack,$los::position);
                                        $TeamItemCount[GameBase::getTeam(%player) @ "JailCapPack"]++;
                                        echo("MSG: ",%client," deployed a Jail Pad");
                                        return true;

                        }
                       else {
                                Client::sendMessage(%client,0,"Cannot deploy here.");
                        }

        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}
//------------------------------------------------
ItemImageData SuicidePackImage
{
        shapeFile = "magcargo";
        mountPoint = 2;
        mountOffset = { 0, -0.5, -0.3 };
        mountRotation = { 0, 0, 0 };
        mass = 2.5;
        firstPerson = false;

};

ItemData SuicidePack
{
        description = "Suicide DetPack";
        shapeFile = "magcargo";
        className = "Backpack";
   heading = "cBackpacks";
        imageType = SuicidePackImage;
        shadowDetailMask = 4;
        mass = 2.5;
        elasticity = 0.2;
        price = 450;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};


function SuicidePack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else {
                Player::deployItem(%player,%item);
        }
}

function SuicidePack::onUnmount(%player,%item)
{
        deleteObject(%item);

}

function SuicidePack::onDeploy(%player,%item,%pos)
{
        if (SuicidePack::deployShape(%player,%item)) {
                Player::decItemCount(%player,%item);
        }
}

function SuicidePack::deployShape(%player,%item)
{
        Player::unmountItem(%player,$BackpackSlot);

                        %obj = newObject("","Mine","Suicidebomb2");
                         addToSet("MissionCleanup", %obj);
                        %client = Player::getClient(%player);
                        GameBase::throw(%obj,%player,3 * %client.throwStrength,false);
                        Client::sendMessage(%client,1,"Det Pack will destruct in 20 seconds");
                         echo("MSG: ",%client," deployed a Suicide Pack");



}

function SuicidePack::onUnmount(%player,%item)
{
      Player::unmountItem(%player,%BackPackSlot);
	
}
//------------------------------------------------------------
ItemData StingerAmmo
{
	description = "Stinger Ammo";
	classname = "Ammo";
	shapeFile = "mortarammo";		
	heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 50;
};

ItemImageData StingerImage
{
	shapeFile = "grenadeL";
	mountPoint = 0;
	mountOffset = { -0.1, 0, 0 };
	mountRotation = { 0, -1.85, 0};
	weaponType = 0; 
	reloadTime = 0.25;// 1.5;
	fireTime = 0.1;
	minEnergy = 5;
	maxEnergy = 6;
	ammoType = StingerAmmo;
	accuFire = true;
	sfxFire	= SoundMissileTurretFire;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundMortarReload;
	//sfxReady = SoundMortarIdle;
};

ItemData Stinger
{
	heading = "TUSW-Weapons";
	description = "Stinger Missle";
	classname = "Weapon";
	shapeFile = "GrenadeL";
	hudIcon	= "sensorjamerpack";
	shadowDetailMask = 4;
	imageType = StingerImage;
	price = 350;
	showWeaponBar = true;
};

function Stinger::onMount(%player,%item)
{	
	if($debug)echo("?? EVENT mount "@ %item @" onto player "@ %player @" cl# "@ Player::getclient(%player));
	%clientId = Player::getclient(%player);
	if(%clientId.weaponHelp)
		bottomprint(%clientId, "<jc>Stinger Missile: <f2>Give it a good lock, it'll give you a good hit.");
}

function StingerImage::onFire(%player,%slot)
{		
	if($debug)echo("?? EVENT fire "@Player::getMountedItem(%player,0)@ " player "@ %player @" cl# "@ Player::getclient(%player));		
	%AmmoCount = Player::getItemCount(%player, $WeaponAmmo[Stinger]);
	if(%AmmoCount)
	{	
		%client = GameBase::getOwnerClient(%player);
		%clientName = Player::getClient(%player);
		%clientId = Client::getName(%client);
		%trans = GameBase::getMuzzleTransform(%player);
		%vel = Item::getVelocity(%player);
		if(GameBase::getLOSInfo(%player,1500))
		{
			%object = getObjectType($los::object);
			%targeted = GameBase::getOwnerClient($los::object);
			if(%object == "Player" || %object == "Flier")
			{
				%targetP = Client::getName(%targeted);
				Client::sendMessage(%client,0,"Stinger lock acquired "@ %targetP @ "~wmine_act.wav");
				Client::sendMessage(%targeted,0,"Stinger lock detected - " @ %clientId @ "~wono.wav");
				Projectile::spawnProjectile("StingerMissile",%trans,%player,%vel,$los::object);
				Player::decItemCount(%player,$WeaponAmmo[Stinger],1);
			}
			else
			{
				Projectile::spawnProjectile("StingerRocket",%trans,%player,%vel,%player);
				Player::decItemCount(%player,$WeaponAmmo[Stinger],1);
			}
		}
		else
		{
			Projectile::spawnProjectile("StingerRocket",%trans,%player,%vel,$los::object);
			Player::decItemCount(%player,$WeaponAmmo[Hellfire],1);
		}
	}
	else 
		Client::sendMessage(Player::getClient(%player),0,"Stinger out of ammo.~waccess_denied.wav");
}
//------------------------------------------------
$TankShredderSlotA=4;
$TankShredderSlotB=7;
$TankShredderSlotC=6;
//------------------------------------------------
ItemData TankShredderAmmo 
{
	description = "Tank Shredder Ammo";
	className = "Ammo";
	shapeFile = "ammo1";
	heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 1;
};

ItemImageData TankShredderImage 
{
	shapeFile = "chaingun";
	mountPoint = 0;
	mountOffset = { 0, -0.351, 0 };
	mountRotation = { 0, -1.01, 0 };
	weaponType = 1;
	reloadTime = 0;
	spinUpTime = 0.1;
	spinDownTime = 3;
	fireTime = 0.1;
	ammoType = TankShredderAmmo;
	accuFire = true;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };
	sfxFire = SoundFireChaingun;
	sfxActivate = SoundPickupWeapon;
	sfxSpinUp = SoundSpinUp;
	sfxSpinDown = SoundSpinDown;
};

ItemData TankShredder 
{
	description = "Tank Shredder";
	className = "Weapon";
	shapeFile = "chaingun";
	hudIcon = "chain";
	heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = TankShredderImage;
	price = 7500;
	showWeaponBar = true;
};


ItemImageData TankShredder2Image 
{
	shapeFile = "chaingun";
	mountPoint = 0;
	mountOffset = { -1.21, -0.351, 0 };
	mountRotation = { 0, 1.01, 0};
	weaponType = 1;
	reloadTime = 0;
	spinUpTime = 0.1;
	spinDownTime = 3;
	fireTime = 0.1;
	ammoType = TankShredderAmmo;
	projectileType = ShredderBullet;
	accuFire = true;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };
	sfxFire = SoundFireChaingun;
	sfxSpinUp = SoundSpinUp;
	sfxSpinDown = SoundSpinDown;
};

ItemData TankShredder2 
{
	description = "Tank Shredder";
	className = "Weapon";
	shapeFile = "chaingun";
	hudIcon = "chain";
	shadowDetailMask = 4;
	imageType = TankShredder2Image;
	price = 0;
	showWeaponBar = false;
	showInventory = false;
};

ItemImageData TankShredder3Image 
{
	shapeFile = "chaingun";
	mountPoint = 0;
	mountOffset = { -1.3051, -0.201, 0.251 };
	mountRotation = { 0, 1.501, 0 };
	weaponType = 1;
	reloadTime = 0;
	spinUpTime = 0.1;
	spinDownTime = 3;
	fireTime = 0.1;
	ammoType = TankShredderAmmo;
	projectileType = ShredderBullet;
	accuFire = true;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };
	sfxFire = SoundFireChaingun;
};

ItemData TankShredder3 
{
	description = "Tank Shredder";
	className = "Weapon";
	shapeFile = "chaingun";
	hudIcon = "chain";
	shadowDetailMask = 4;
	imageType = TankShredder3Image;
	price = 0;
	showWeaponBar = false;
	showInventory = false;
};
ItemImageData TankShredder4Image 
{
	shapeFile = "chaingun";
	mountPoint = 0;
	mountOffset = {0.101, -0.201, 0.251 };
	mountRotation = { 0, -1.501, 0}; 
	weaponType = 1;
	reloadTime = 0;
	spinUpTime = 0.1;
	spinDownTime = 3;
	fireTime = 0.1;
	ammoType = TankShredderAmmo;
	projectileType = ShredderBullet;
	accuFire = true;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1 };
	sfxFire = SoundFireChaingun;
};

ItemData TankShredder4 
{
	description = "Tank Shredder";
	className = "Weapon";
	shapeFile = "chaingun";
	hudIcon = "chain";
	shadowDetailMask = 4;
	imageType = TankShredder4Image;
	price = 0;
	showWeaponBar = false;
	showInventory = false;
};

function TankShredderImage::onFire(%player, %slot) 
{		
	if($debug)echo("?? EVENT fire "@Player::getMountedItem(%player,0)@ " player "@ %player @" cl# "@ Player::getclient(%player));	
	//TankShredderImage::spawnProjectile(%player);
	%client = GameBase::getOwnerClient(%player);
	//%player.firingShredder = true;
	//schedule("TankShredderImage::spawnProjectile(" @ %player @ ");",1);
	Player::decItemCount(%player,$WeaponAmmo[TankShredder],1);
	%trans = GameBase::getMuzzleTransform(%player);
	%vel = Item::getVelocity(%player);
	Projectile::spawnProjectile("ShredderBullet",%trans,%player,%vel,%player);
	if(!$FiringTankShredder[%client]) 
		CheckTankShredder(%client, %player);
}

function TankShredderImage::spawnProjectile(%player)
{
	%client = GameBase::getOwnerClient(%player);
	if(Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == "TankShredder"))
	{
		Player::decItemCount(%player,$WeaponAmmo[TankShredder],1);
		%trans = GameBase::getMuzzleTransform(%player);
		%vel = Item::getVelocity(%player);
		Projectile::spawnProjectile("ShredderBullet",%trans,%player,%vel,%player);
	}
}

function TankShredder::onDrop(%player,%item) 
{
	%state = Player::getItemState(%player,$WeaponSlot);
	if(%state != "Fire" && %state != "Reload") 
	{
		Player::setItemCount(%player, TankShredder2, 0);
		Item::onDrop(%player,%item);
	}
}

function TankShredder::onMount(%player,%item) 
{	
	if($debug)echo("?? EVENT mount "@ %item @" onto player "@ %player @" cl# "@ Player::getclient(%player));
	Player::mountItem(%player,TankShredder2,$TankShredderSlotA);
	Player::mountItem(%player,TankShredder3,$TankShredderSlotB);
	Player::mountItem(%player,TankShredder4,$TankShredderSlotC);
	%clientId = Player::getclient(%player);
	if(%clientId.weaponHelp)
		bottomprint(%clientId, "<jc>Tank Shredder: <f2>You don't want to get in the way of this quad chaingun!");
}

function TankShredder::onUnmount(%player,%imageSlot) 
{
	Player::unmountItem(%player,$TankShredderSlotA);
	Player::unmountItem(%player,$TankShredderSlotB);	 
	Player::unmountItem(%player,$TankShredderSlotC);
}

function CheckTankShredder(%client, %player) 
{
	if(Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == "TankShredder")) 
	{
		Player::trigger(%player,$TankShredderSlotA,true);
		Player::trigger(%player,$TankShredderSlotB,true);
		Player::trigger(%player,$TankShredderSlotC,true);
		schedule("CheckTankShredder(" @ %client @ "," @ %player @ ");",0.1);
		$FiringTankShredder[%client] = true;
	}
	else 
	{
		Player::trigger(%player,$TankShredderSlotA,false);
		Player::trigger(%player,$TankShredderSlotB,false);
		Player::trigger(%player,$TankShredderSlotC,false);
		$FiringTankShredder[%client] = false;
	}
}
//---------------------------------------------------
$TankRPGSlotA=4;
$TankRPGSlotB=7;
$TankRPGSlotC=6; 
//---------------------------------------------------
ItemData TankRPGAmmo 
{
	description = "RPG Ammo"; 
	className = "Ammo"; 
	shapeFile = "ammo1"; 
	heading = "xAmmunition"; 
	shadowDetailMask = 4; 
	price = 1; 
}; 

ItemImageData TankRPGLauncherImage 
{
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = { -1.305, -0.20, 0.25 }; 
	mountRotation = { 0, 1.50, 0 }; 
	weaponType = 0; 
	reloadTime = 0.55;// 2.0; 
	fireTime = 0.1;
	minEnergy = 5;	
	maxEnergy = 6;
	ammoType = TankRPGAmmo; 
	accuFire = true; 
	sfxFire = SoundMissileTurretFire; 
	sfxActivate = SoundPickUpWeapon; 
	sfxReload = SoundMortarReload;
	sfxReady = SoundMortarIdle;
}; 

ItemData TankRPGLauncher 
{
	description = "Tank RPG"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	mountOffset = { -1.1, 0.02, 0.4 }; 
	mountRotation = { 0, -1.1, 0}; 
	hudIcon = "ammopack"; 
	heading = "TUSW-Weapons"; 
	shadowDetailMask = 4; 
	imageType = TankRPGLauncherImage; 
	price = 550; 
	showWeaponBar = true; 
};

ItemImageData TankRPGLauncher2Image 
{
	ammoType = TankRPGAmmo; 
	projectileType = RPG; 
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = { -1.2, -0.35, 0 }; 
	mountRotation = { 0, 1.0, 0}; 
	weaponType = 0; 
	reloadTime = 0.55;// 2.0;
	fireTime = 0.1;
	accuFire = false; 
	sfxFire = SoundMissileTurretFire; 
};

ItemData TankRPGLauncher2 
{
	description = "Tank RPG"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	hudIcon = "chain"; 
	shadowDetailMask = 4; 
	imageType = TankRPGLauncher2Image; 
	price = 0; 
	showWeaponBar = true; 
	showInventory = false; 
};

ItemImageData TankRPGLauncher3Image 
{
	ammoType = TankRPGAmmo; 
	projectileType = RPG; 
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = { 0, -0.35, 0 }; 
	mountRotation = { 0, -1.0, 0 }; 
	weaponType = 0; 
	reloadTime = 0.55;// 2.0;
	fireTime = 0.1;
	accuFire = false; 
	sfxFire = SoundMissileTurretFire; 
};

ItemData TankRPGLauncher3 
{
	description = "Tank RPG"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	hudIcon = "chain"; 
	shadowDetailMask = 4; 
	imageType = TankRPGLauncher3Image; 
	price = 0; 
	showWeaponBar = true; 
	showInventory = false; 
};
 
ItemImageData TankRPGLauncher4Image 
{
	ammoType = TankRPGAmmo; 
	projectileType = RPG; 
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = {0.10, -0.20, 0.25 }; 
	mountRotation = { 0, -1.50, 0}; 
	weaponType = 0; 
	reloadTime = 0.55;// 2.0; 
	fireTime = 0.1;
	accuFire = false; 
	sfxFire = SoundMissileTurretFire; 
};

ItemData TankRPGLauncher4 
{
	description = "Tank RPG"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	hudIcon = "chain"; 
	shadowDetailMask = 4; 
	imageType = TankRPGLauncher4Image; 
	price = 0; 
	showWeaponBar = true; 
	showInventory = false; 
};

function TankRPGLauncherImage::onFire(%player, %slot) 
{		
	if($debug)echo("?? EVENT fire "@Player::getMountedItem(%player,0)@ " player "@ %player @" cl# "@ Player::getclient(%player));	
	%client = GameBase::getOwnerClient(%player); 
	Player::decItemCount(%player,TankRPGammo,1); 
	%trans = GameBase::getMuzzleTransform(%player); 
	%vel = Item::getVelocity(%player); 
	Projectile::spawnProjectile("RPG",%trans,%player,%vel,%player); 
	if(!$FiringTankRPGLauncher[%client]) 
		CheckTankRPGLauncher(%client, %player); 
}

function TankRPGLauncher::onDrop(%player,%item) 
{
	%state = Player::getItemState(%player,$WeaponSlot); 
	if(%state != "Fire" && %state != "Reload") 
	{
		Player::setItemCount(%player, TankRPGLauncher2, 0); 
		Item::onDrop(%player,%item); 
	}
}

function TankRPGLauncher::onMount(%player,%item) 
{	
	if($debug)echo("?? EVENT mount "@ %item @" onto player "@ %player @" cl# "@ Player::getclient(%player));
	Player::mountItem(%player,TankRPGLauncher2,$TankRPGSlotA); 
	Player::mountItem(%player,TankRPGLauncher3,$TankRPGSlotB); 
	Player::mountItem(%player,TankRPGLauncher4,$TankRPGSlotC);
	%clientId = Player::getclient(%player);
	if(%clientId.weaponHelp)
		bottomprint(%clientId, "<jc>Tank RPG: <f2>Fires four highly explosive missiles to pummel your target.");
}

function TankRPGLauncher::onUnmount(%player,%imageSlot) 
{
	Player::unmountItem(%player,$TankRPGSlotA);
	Player::unmountItem(%player,$TankRPGSlotB);	 
	Player::unmountItem(%player,$TankRPGSlotC);
}

function CheckTankRPGLauncher(%client, %player) 
{
	if(Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == "TankRPGLauncher")) 
	{	Player::trigger(%player,$TankRPGSlotA,true);
		Player::trigger(%player,$TankRPGSlotB,true);
		Player::trigger(%player,$TankRPGSlotC,true); 
		schedule("CheckTankRPGLauncher(" @ %client @ "," @ %player @ ");",0.1); 
		$FiringTankRPGLauncher[%client] = true; 
	}
	else 
	{	Player::trigger(%player,$TankRPGSlotA,false); 
		Player::trigger(%player,$TankRPGSlotB,false); 
		Player::trigger(%player,$TankRPGSlotC,false); 
		$FiringTankRPGLauncher[%client] = false; 
	}
}
//-------------------------------------------------
$TRocketLauncherSlotA=4;
$TRocketLauncherSlotB=7;
$TRocketLauncherSlotC=6; 
//-------------------------------------------------
ItemData TRocketLauncherAmmo
{
	description = "TRocketLauncher Ammo";
	classname = "Ammo";
	shapeFile = "mortarammo";		
	heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 50;
};

ItemImageData TRocketLauncherImage 
{
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = { -1.346, 0.08, 0.01 }; 
	mountRotation = { 0, 1.575, 0 }; 
	weaponType = 0; 
	reloadTime = 0.25;// 1.0; 
	fireTime = 0.1;
	minEnergy = 5;	
	maxEnergy = 6;
	ammoType = TRocketLauncherAmmo; 
	accuFire = true; 
	sfxFire = SoundMissileTurretFire; 
	sfxActivate = SoundPickUpWeapon; 
	sfxReload = SoundMortarReload;
	sfxReady = SoundMortarIdle;
}; 

ItemData TRocketLauncher 
{
	description = "Tank Rocketgun"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	mountOffset = { -1.346, 0.08, 0.01 }; 
	mountRotation = { 0, 1.575, 0 }; 
	hudIcon	= "sensorjamerpack";
	heading = "TUSW-Weapons";
	shadowDetailMask = 4; 
	imageType = TRocketLauncherImage; 
	price = 2500; 
	showWeaponBar = true; 
}; 

ItemImageData TRocketLauncher2Image 
{
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = { -1.21, -0.45, 0 }; 
	mountRotation = { 0, 0, 0 }; 
	weaponType = 0; 
	reloadTime = 0.25;// 1.0; 
	fireTime = 0.1;
	ammoType = TRocketLauncherAmmo; 
	accuFire = true; 
	sfxFire = SoundMissileTurretFire; 
	minEnergy = 5;	
	maxEnergy = 6;
};	

ItemData TRocketLauncher2 
{
	description = "Tank Rocketgun"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	shadowDetailMask = 4; 
	imageType = TRocketLauncher2Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
}; 

ItemImageData TRocketLauncher3Image 
{
	shapeFile = "mortargun"; 
	mountPoint = 0; 
	mountOffset = { 0, -0.45, 0 }; 
	mountRotation = { 0, 0, 0 }; 
	weaponType = 0; 
	reloadTime = 0.25;// 1.0; 
	fireTime = 0.1;
	ammoType = TRocketLauncherAmmo; 
	accuFire = true; 
	sfxFire = SoundMissileTurretFire; 
	minEnergy = 5;	
	maxEnergy = 6;
}; 

ItemData TRocketLauncher3 
{
	description = "Tank Rocketgun"; 
	className = "Weapon"; 
	shapeFile = "mortargun";
	shadowDetailMask = 4;
	imageType = TRocketLauncher3Image;
	price = 0;
	showWeaponBar = false;
	showInventory = false;
}; 

ItemImageData TRocketLauncher4Image 
{
	shapeFile = "mortargun";
	mountPoint = 0; 
	mountOffset = { 0.15, 0.08, 0.01 };
	mountRotation = { 0, -1.575, 0}; 
	weaponType = 0; 
	reloadTime = 0.25;// 1.0; 
	fireTime = 0.1;
	ammoType = TRocketLauncherAmmo; 
	accuFire = true; 
	sfxFire = SoundMissileTurretFire; 
	minEnergy = 5;	
	maxEnergy = 6;
}; 

ItemData TRocketLauncher4 
{
	description = "Tank Rocketgun"; 
	className = "Weapon"; 
	shapeFile = "mortargun"; 
	shadowDetailMask = 4; 
	imageType = TRocketLauncher4Image; 
	price = 0; 
	showWeaponBar = false;
	showInventory = false; 
}; 

//  Begin TRocketLauncher Fire Function

function TRocketLauncherImage::onFire(%player, %slot) 
{		
	if($debug)echo("?? EVENT fire "@Player::getMountedItem(%player,0)@ " player "@ %player @" cl# "@ Player::getclient(%player));		
	%AmmoCount = Player::getItemCount(%player, $WeaponAmmo[TRocketLauncher]);
	if(%AmmoCount)
	{
		%client = GameBase::getOwnerClient(%player);
		%clientName = Player::getClient(%player);
		%clientId = Client::getName(%client);
		%trans = GameBase::getMuzzleTransform(%player);
		%vel = Item::getVelocity(%player);
		
		// ------- Second Projectile Placement --------
		
		%pos=gamebase::getposition(%player);
		%rot=gamebase::getrotation(%player);
		%vec=Vector::getFromRot(%rot);
		
		%vec1=getWord(%vec,0);
		%vec2=getWord(%vec,1);
		
		%pos1=getWord(%trans,0);
		%pos2=getWord(%trans,1);
		%pos3=getWord(%trans,2);
		%pos4=getWord(%trans,3);
		%pos5=getWord(%trans,4);
		%pos6=getWord(%trans,5);
		%pos7=getWord(%trans,6);
		%pos8=getWord(%trans,7);
		%pos9=getWord(%trans,8);
		%pos10=getWord(%trans,9) + %vec2;
		%pos11=getWord(%trans,10) - %vec1;
		%pos12=getWord(%trans,11);
		
		%trans2=%pos1@" "@%pos2@" "@%pos3@" "@%pos4@" "@%pos5@" "@%pos6@" "@%pos7@" "@%pos8@" "@%pos9@" "@%pos10@" "@%pos11@" "@%pos12;
		
		// ----- End of Second Projectile Placement -----
		
		if(GameBase::getLOSInfo(%player,1500))
		{	
			%object = getObjectType($los::object);
			%targeted = GameBase::getOwnerClient($los::object);
			if(%object == "Player" || %object == "Flier")
			{
				%targetP = Client::getName(%targeted);
				Projectile::spawnProjectile("TankMissile",%trans,%player,%vel,$los::object);
				Projectile::spawnProjectile("TankMissile",%trans2,%player,%vel,$los::object);
				Client::sendMessage(%client,0,"Tank Rocket Launcher lock acquired "@ %targetP @ "~wmine_act.wav");
				Client::sendMessage(%targeted,0,"Tank Rocket Launcher lock detected - " @ %clientId @ "~wono.wav");
				if(!$FiringTRocketLauncher[%client]) 
					CheckTRocketLauncher(%client, %player);
				//GiveKickBack(%player, 125, 1);
				Player::decItemCount(%player,$WeaponAmmo[TRocketLauncher],2);
			}
			else
			{
				Projectile::spawnProjectile("TankRocket",%trans,%player,%vel,%target);
				Projectile::spawnProjectile("TankRocket",%trans2,%player,%vel,%target);
				if(!$FiringTRocketLauncher[%client]) 
					CheckTRocketLauncher(%client, %player); 
				//GiveKickBack(%player, 125, 1);
				Player::decItemCount(%player,$WeaponAmmo[TRocketLauncher],2);
			}
		}
		else
		{
			Projectile::spawnProjectile("TankRocket",%trans,%player,%vel,%target);
			Projectile::spawnProjectile("TankRocket",%trans2,%player,%vel,%target);
			if(!$FiringTRocketLauncher[%client]) 
				CheckTRocketLauncher(%client, %player); 
			//GiveKickBack(%player, 125, 1);
			Player::decItemCount(%player,$WeaponAmmo[TRocketLauncher],2);
		}
	}
	else
		Client::sendMessage(%client,0,"Tank Rocket Launcher out of ammo.~waccess_denied.wav");
}

function TRocketLauncher::onDrop(%player,%item) 
{
	%state = Player::getItemState(%player,$WeaponSlot); 
	if(%state != "Fire" && %state != "Reload") 
	{
		Player::setItemCount(%player, TRocketLauncher2, 0); 
		Item::onDrop(%player,%item); 
	}
}

//function TRocketLauncher::onUse()
//{
//}

function TRocketLauncher::onMount(%player,%item) 
{	
	if($debug)echo("?? EVENT mount "@ %item @" onto player "@ %player @" cl# "@ Player::getclient(%player));	
	Player::mountItem(%player,TRocketLauncher2,$TRocketLauncherSlotA); 
	Player::mountItem(%player,TRocketLauncher3,$TRocketLauncherSlotB); 
	Player::mountItem(%player,TRocketLauncher4,$TRocketLauncherSlotC);
	%clientId = Player::getclient(%player);
	if(%clientId.weaponHelp)
		bottomprint(%clientId, "<jc>Tank RocketLauncher: <f2>This duel heat seeking launcher will lock onto your enemies."); 
}

function TRocketLauncher::onUnmount(%player,%imageSlot) 
{
	Player::unmountItem(%player,$TRocketLauncherSlotA);
	Player::unmountItem(%player,$TRocketLauncherSlotB);	 
	Player::unmountItem(%player,$TRocketLauncherSlotC);
}

function CheckTRocketLauncher(%client, %player) 
{
	if(Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == "TRocketLauncher")) 
	{
		Player::trigger(%player,$TRocketLauncherSlotA,true);
		Player::trigger(%player,$TRocketLauncherSlotB,true);
		Player::trigger(%player,$TRocketLauncherSlotC,true);
		schedule("CheckTRocketLauncher(" @ %client @ "," @ %player @ ");",0.1); 
		$FiringTRocketLauncher[%client] = true;
	}
	else 
	{
		Player::trigger(%player,$TRocketLauncherSlotA,false); 
		Player::trigger(%player,$TRocketLauncherSlotB,false); 
		Player::trigger(%player,$TRocketLauncherSlotC,false); 
		$FiringTRocketLauncher[%client] = false; 
	}
}
//-----------------------------------------------------------------------------

//-------------------------------------------------------------
// Deployable Portable Generator - was originally the Solar Panel from Pantheon mod,
// 				   renamed and given a new shape by me

ItemImageData DeployableSolarPanelImage
{
	shapeFile = "generator_p";
	mountPoint = 2;
  	mountOffset = { 0, 0, 0 };
	mountRotation = { 0, 0, 0 };
	mass = 0.5;
	firstPerson = false;
};

ItemData DeployableSolarPanel
{
	description = "Portable Generator";
	shapeFile = "generator_p";
	className = "Backpack";
	heading = "jOther Deployables";
	shadowDetailMask = 4	;
	imageType = DeployableSolarPanelImage;
	mass = 3.0;
	elasticity = 0.2;
	price = 750;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};


function DeployableSolarPanel::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) 
	{
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else 
	{
		Player::deployItem(%player,%item);
	}
}

function DeployableSolarPanel::onDeploy(%player,%item,%pos)
{
	if (DeployableSolarPanel::deployShape(%player,%item)) 
	{
		Player::decItemCount(%player,%item);
	}
}	

function DeployableSolarPanel::deployShape(%player,%item)
{
	%client = Player::getClient(%player);
	if(%client.outArea)
	{
		Client::sendMessage(%client,0,"Can only deploy within the mission boundaries.");
		return;
	}
		
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) 
	{
		if (GameBase::getLOSInfo(%player,3)) 
		{
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape" || GameBase::getDataName($los::object)=="OutpostWall") 
			{
				if (Vector::dot($los::normal,"0 0 1") > 0.7) 
				{
					if(checkDeployArea(%client,$los::position)) 
					{
						%teamnum = GameBase::getTeam(%player);
						%SPanel = newObject("Portable Generator","StaticShape",DeployableGenerator,true);
						addToSet("MissionGroup/Teams/Team" @ %teamnum, %SPanel);
						%rot = GameBase::getRotation(%player); 
						GameBase::setTeam(%SPanel,GameBase::getTeam(%player));
						GameBase::setPosition(%SPanel,$los::position);
						GameBase::setRotation(%SPanel,%rot);
						Gamebase::setMapName(%SPanel,"Portable Generator");
						GameBase::generatePower(%SPanel, True);
						Client::sendMessage(%client,0,"Portable Generator deployed");
						playSound(SoundPickupBackpack,$los::position);
						$TeamItemCount[GameBase::getTeam(%SPanel) @ "DeployableSolarPanel"]++;
						echo("MSG: ",%client," deployed a Portable Generator");
						return true;
					}
				}
				else 
					Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
			}
			else
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
		}
		else
			Client::sendMessage(%client,0,"Deploy position out of range");
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	return false;
}
//----------------------------------------------
ItemImageData HoloPackImage
{
        shapeFile = "larmor";
        mountPoint = 2;
        mountOffset = { 1.5, 0.8, -1.50};// 0 };
        mass = 1.0;
        firstPerson = false;
};

ItemData HoloPack
{
        description = "Hologram";
        shapeFile = "larmor";
        className = "Backpack";
        heading = "jOther Deployables";
        imageType = HoloPackImage;
        shadowDetailMask = 4;
        mass = 1.5;
        elasticity = 0.2;
        price = 900;
        hudIcon = "deployable";
        showWeaponBar = true;
        hiliteOnActive = true;
};

function HoloPack::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else {
                Player::deployItem(%player,%item);
        }
}

function HoloPack::onDeploy(%player,%item,%pos)
{
        if (HoloPack::deployShape(%player,%item)) {
                Player::decItemCount(%player,%item);
        }
}

function HoloPack::deployShape(%player,%item)
{
        %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ "hologram"] < $TeamItemMax["hologram"]) {
                if (GameBase::getLOSInfo(%player,3)) {
                        %obj = getObjectType($los::object);

                                    %set = newObject("set",SimSet);
                                %num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0);
                                %num = CountObjects(%set,"Hologram",%num);
                                deleteObject(%set);

                                        if (Vector::dot($los::normal,"0 0 1") > 0.7) {
                                                if(checkDeployArea(%client,$los::position)) {
                                                        %rot = GameBase::getRotation(%player);
                                                        %rnd = floor(getRandom() * 10);
                                                        if(%rnd > 6)

                                                           %fField = newObject("","StaticShape",Hologram1,true);
                                                        else
                                                                if((%rnd > 2) && (%rnd < 7))


                                                           %fField = newObject("","StaticShape",Hologram2,true);
                                                        else


                                                           %fField = newObject("","StaticShape",Hologram3,true);

                                                        addToSet("MissionCleanup", %fField);
                                                        GameBase::setTeam(%fField,GameBase::getTeam(%player));
                                                        GameBase::setPosition(%fField,$los::position);
                                                        GameBase::setRotation(%fField,%rot);
                                                        Client::sendMessage(%client,0,"Hologram Deployed");
                                                        echo("MSG: ",%client," deployed a Hologram");
                                                        GameBase::startFadeIn(%fField);
                                                        playSound(ForceFieldOpen,$los::position);


                                                        $TeamItemCount[GameBase::getTeam(%player) @ "hologram"]++;
                                                        return true;
                                                }
                                        }
                                        else
                                                Client::sendMessage(%client,0,"Can only deploy on flat surfaces");
                                        }
                else
                        Client::sendMessage(%client,0,"Deploy position out of range");
        }
        else
                 Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");

        return false;
}
//========================Portable Hole pack
ItemImageData HolePackImage
{
	shapeFile = "display_three";
	mountPoint = 2;
	mountOffset = { 0, -0.03, -0.4 };
	mountRotation = { 0, 0, 0 };
	mass = 2;
	firstPerson = false;
};

ItemData HolePack
{
    description = "Portable Hole";
    shapeFile = "display_three";
    className = "Backpack";
    heading = "dDeployables";
    imageType = HolePackImage;
    shadowDetailMask = 4;
    elasticity = 0.2;
    price = 500;
    hudIcon = "deployable";
    showWeaponBar = true;
    hiliteOnActive = true;
};

function HolePack::onUse(%player,%item)
{
	%client = Player::getClient(%player);
	%pos = GameBase::getPosition(%player);
 	%group = nameToID("MissionCleanup/jailports");
	%num = Group::objectCount(%group);
	for(%i; %i < %num; %i++)
	{
		%obj = Group::getObject(%group, %i);
		%homepos = GameBase::getPosition(%obj);
		if (Vector::getDistance(%pos,%homepos) < 10 && Client::getTeam(%client) == GameBase::getTeam(%obj))
		{
			Client::sendMessage(%client,1,"Too close to your team's jail.");
			deleteObject(%set);
			return False;
		}
	}
	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
		Player::mountItem(%player,%item,$BackpackSlot);
	else
		Player::deployItem(%player,%item);
}

function HolePack::onDeploy(%player,%item,%pos)
{
	if (HolePack::deployShape(%player,%item))
		Player::decItemCount(%player,%item);
}
function HolePack::deployShape(%player,%item)
{
	%object = ( deployable(%player,%item,"StaticShape","Portal",False,False,False,False,False,False,5,True,25, True, "Portal", "HolePack") );
	if (%object)
	{
		%client = Player::getClient(%player);
		%team = Client::getTeam(%client);
		TeamMessages(0, %team, "Friendly Portal Deployed~welevator2.wav", -2, "Hull Breech!~welevator2.wav", "Hull Breech!~welevator2.wav");
      	Client::sendMessage(%client,0,"Establishing team access: 2 points.");
      	%client.score = (%client.score +2);
		return true;
	}
}
/////-------------------------Function for holepack-----------////////////////
function deployable(%player,%item,%type,%name,%angle,%freq,%prox,%noinside,%area,%surface,%range,%limit,%flag, %kill, %deploy, %count)
{
	%client = Player::getClient(%player);
	%playerteam = Client::getTeam(%client);
	%playerpos = GameBase::getPosition(%player);
	%homepos = ($teamFlag[%playerteam]).originalPosition;
	%flagdist = Vector::getDistance(%playerpos,%homepos);

	if($TeamItemCount[GameBase::getTeam(%player) @ %count] < $TeamItemMax[%count])
	{
		if (GameBase::getLOSInfo(%player,%range))
		{
			%o = ($los::object);
			%obj = getObjectType(%o);
			%datab = GameBase::getDataName(%o);
			%pos = $los::position;

			if (%surface)
			{
				if (%obj == "SimTerrain" || %obj == "InteriorShape")
				{

				}
				else if (%datab == "DeployablePlatform" || %datab == "LargeAirBasePlatform" || %datab == "BlastFloor" || %datab == "BlastWall" || %datab == "LargeEmplacementPlatform")
				{

				}
				else
				{
					Client::sendMessage(%client,1,"Can only deploy on terrain or buildings...");
					return;
				}
			}

			if (%prox)
			{
				%set = newObject("proxset",SimSet);
				%num = containerBoxFillSet(%set,$StaticObjectType,%pos,$TurretBoxMinLength,$TurretBoxMinWidth,$TurretBoxMinHeight,0);
				%num = CountObjects(%set,%deploy,%num);
				deleteObject(%set);
				if($MaxNumTurretsInBox > %num){}
				else
				{
					Client::sendMessage(%client,1,"Frequency Overload - Too close to other " @ %deploy @ "s.");
					return;
				}

				%set = newObject("minimumset",SimSet);
				%Mask = $StaticObjectType|$VehicleObjectType|$ItemObjectType;
				%num = containerBoxFillSet(%Set, %Mask, %pos, 2.5,2.5,2.5, 0);
				%num = CountObjects(%set,"",%num);
				deleteObject(%set);
				if(!%num){}else
				{
					Client::sendMessage(%client,1,"Frequency Overload - Too close to other remote turrets");
					return;
				}
			}

			if (%noinside)
			{
				%padd = "0 0 10";%poss = Vector::add(%pos, %padd);
				for (%b=1; %b < 15; %b++)
				{
					%padd = "0 0 " @ %b;
					%poss = Vector::add(%pos, %padd);
					if(!GameBase::testPosition(%player, %poss))
						%nope = 1;
				}
				if (%nope == 1)
				{
					Client::sendMessage(%client,0,"You can not deploy " @ %name @ ", space to enclosed.");
					return;
				}


			}
			if (%freq)
			{
				%set = newObject("freqset",SimSet);%Mask = $StaticObjectType|$VehicleObjectType|$ItemObjectType;
				%num = containerBoxFillSet(%Set, %Mask, $los::position, $TurretBoxMaxLength/2,$TurretBoxMaxWidth/2,$TurretBoxMaxHeight/2, 0);
				%num = CountObjects(%set,"",%num);
				deleteObject(%set);
				if(%num > 0)
				{
					Client::sendMessage(%client,1,"Other objects in the way.");
					return;
				}
			}

			if (%angle == "True")
			{
				if (Vector::dot($los::normal,"0 0 1") > 0.7)
				{
					%prot = GameBase::getRotation(%player);
					%zRot = getWord(%prot,2);

					if (Vector::dot($los::normal,"0 0 1") > 0.6)
					{
						%rot = "0 0 " @ %zRot;
					}
					else
					{
						if (Vector::dot($los::normal,"0 0 -1") > 0.6)
						{
							%rot = "3.14159 0 " @ %zRot;
						}
						else
						{
							%rot = Vector::getRotation($los::normal);
						}
					}
				}
				else
				{
					Client::sendMessage(%client,1,"Can only deploy on flat surfaces");
					return 0;
				}
			}
			else if (%angle == "Player")
			{
				%rot = GameBase::getRotation(%player);
			}
			else if(%angle == "Flat")
			{
				%rot = "-1.54564 0.02591 -3.09105";

			}
			else if (!%angle || %angle == "False")
			{
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6)
				{
					%rot = "0 0 " @ %zRot;
				}
				else
				{
					if (Vector::dot($los::normal,"0 0 -1") > 0.6)
					{
						%rot = "3.14159 0 " @ %zRot;
					}
					else
					{
						%rot = Vector::getRotation($los::normal);
					}
				}
			}

			if (%area)
			{
				if(!checkDeployArea(%client,$los::position))
				{
					return 0;
				}
			}

			%turret = newObject(%name,%type, %deploy,true);
			addToSet("MissionCleanup", %turret);
			GameBase::setTeam(%turret,GameBase::getTeam(%player));
			GameBase::setPosition(%turret,$los::position);
			GameBase::setRotation(%turret,%rot);
			Client::sendMessage(%client,0,"" @ %name @ " deployed");
			GameBase::startFadeIn(%turret);
			playSound(SoundPickupBackpack,$los::position);
			$TeamItemCount[GameBase::getTeam(%player) @ "" @ %count @ ""]++;

			//echo("MSG: ",%client," deployed a " @ %name);

			if (%type == "Turret")
				Gamebase::setMapName(%turret, %name @ " # " @ $totalNumTurrets++ @ " " @ Client::getName(%client));
			else
				Gamebase::setMapName(%turret, %name);

			if (%flagdist < %flag && %flag != 0)
			{
				%client.score = %client.score + $Score::FlagDef;
				if ($ScoreOn) bottomprint(%Client, "Score + " @ $Score::FlagDef @ " Flag Defence = " @ %client.score @ " Total Score" ,3);
				Game::refreshClientScore(%client);
			}

			if ($BlackJack::TurretKill && %kill)
			{
				Client::setOwnedObject(%client, %turret);
				Client::setOwnedObject(%client, %player);
			}
			return %turret;
		}
		else
			Client::sendMessage(%client,1,"Deploy position out of range");
	}
	else
	 	Client::sendMessage(%client,1,"Deployable Item limit reached for " @ %item.description @ "'s.");
	return false;
}
//===============
//Added function for hole pack//////
function EmplacementPack::rotVector(%vec,%rot)
{
	// this function rotates a vector about the z axis

	%vec_x = getWord(%vec,0);
	%vec_y = getWord(%vec,1);
	%vec_z = getWord(%vec,2);

	// new vector with z axis removed
	%basevec = %vec_x @ "  " @ %vec_y @ "  0";

	// change vector to distance and rotation
	%basedis = Vector::getDistance( "0 0 0", %basevec);
	%normvec = Vector::normalize( %basevec );
	%baserot = Vector::add( Vector::getRotation( %normvec ), "1.571 0 0" );

	// modify rotation and change back to vector (put z axis offset back)
	%newrot = Vector::add( %baserot, %rot );
	%newvec = Vector::getFromRot( %newrot, %basedis, %vec_z );

	return %newvec;
}
//-----------------------------------------
ItemData DualDiscs
{
	description = "Razor Ammo";
	className = "Ammo";
	shapeFile = "discammo";
   heading = "xAmmunition";
	shadowDetailMask = 4;
	price = 1;
};

ItemImageData HDisc1Image 
{ 
	shapeFile = "disc"; 
	mountPoint = 0; 
	mountRotation = { 0,-1.57, 0 }; 
	mountOffset = { 0.1, 0, 0 };
	ammoType = DualDiscs; 
	weaponType = 3; 
	accuFire = true; 
	reloadTime = 0.05;// 0.047; 
	fireTime = 0;// 0.047; 
	spinUpTime = 0.005; 
	projectileType = DiscShell2;
}; 

ItemData HDisc1 
{ 
	description = "Double Disk";
	 className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
	heading = "TUSW-Weapons"; 
	shadowDetailMask = 4; 
	imageType = HDisc1Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
}; 

ItemImageData HDisc2Image 
{
	 shapeFile = "disc"; 
	mountPoint = 0; 
	mountRotation = { 0,1.57, 0 };
	mountOffset = { 0.03, 0, 0 };
	 ammoType = DualDiscs; 
	weaponType = 3; 
	accuFire = true; 

	reloadTime = 0.05;// 0.067; 
	fireTime = 0;// 0.067; 
	spinUpTime = 0.005; 
	projectileType = DiscShell2; 
}; 

ItemData HDisc2 
{ 
	description = "Double Disk";
	 className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
	heading = "TUSW-Weapons"; 
	shadowDetailMask = 4; 
	imageType = HDisc2Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
};

ItemImageData HDiscLauncherImage 
{ 
	shapeFile = "breath"; 
	mountPoint = 3; 
	weaponType = 3; 
	ammoType = DualDiscs; 
	accuFire = true; 
	reloadTime = 0.05;// 0.067; 
	fireTime = 0;// 0.067; 
	spinUpTime = 0.005; 
	sfxFire = SoundFireDisc; 
	sfxActivate = SoundPickUpWeapon; 
	sfxReload = SoundDiscReload; 
	sfxReady = SoundDiscSpin; 
}; 

ItemData HDiscLauncher 
{ 
	description = "Double Disk"; 
	className = "Weapon"; 
	shapeFile = "disc"; 
	hudIcon = "disk"; 
   heading = "TUSW-Weapons"; 
	shadowDetailMask = 4; 
	imageType = HDiscLauncherImage; 
	price = 250; 
	showWeaponBar = true; 
}; 

function HDiscLauncherImage::onFire(%player, %slot) 
{  
	%state1 = Player::getItemState(%player,6);  
	%state2 = Player::getItemState(%player,7);  
	if (%state1 != "Fire" && %state1 != "Reload" && %state2 != "Fire" && %state2 != "Reload") 
	{   
		%client = GameBase::getOwnerClient(%player);   
		Player::decItemCount(%player, "DualDiscs", 0.5);   
		%num = Player::getItemCount(%player, "DualDiscs");   
		if(%client.hd == 0) 
		{    
			%client.hd = 1;    
			if(%num == 1)     
			Player::setItemCount(%player, "DualDiscs", 0);    
			else     
			Player::setItemCount(%player, "DualDiscs", %num);    
			Player::trigger(%player,5,true);    
			Player::trigger(%player,5,false);   
		} 
		else 
		{    

			%client.hd = 0;    
			if(%num == 1)     
			Player::setItemCount(%player, "DualDiscs", 0);    
			else     
			Player::setItemCount(%player, "DualDiscs", %num);    
			Player::trigger(%player,6,true);    
			Player::trigger(%player,6,false);   
		}  
	} 
} 

function HDiscLauncher::onMount(%player,%imageSlot) 
{  
	%num = Player::getItemCount(%player, "DualDiscs");  
	Player::setItemCount(%player, "DualDiscs", %num);  
	Player::mountItem(%player,HDisc1,5);  
	Player::mountItem(%player,HDisc2,6); 
} 

function HDiscLauncher::onUnmount(%player,%imageSlot) 
{  
	Player::unmountItem(%player,5);  
	Player::unmountItem(%player,6); 
}

///////////////////////////////////////////////////////////////////////////////////

function remoteGiveAll(%clientId)
{
	if ($TestCheats) {
		Player::setItemCount(%clientId,Blaster,1);
		Player::setItemCount(%clientId,Chaingun,1);
		Player::setItemCount(%clientId,PlasmaGun,1);
		Player::setItemCount(%clientId,DiscLauncher,1);
		Player::setItemCount(%clientId,Mortar,1);
            Player::setItemCount(%clientId,LiLPOOmki,1);
            Player::setItemCount(%clientId,LiLPOOmkii,1);
            Player::setItemCount(%clientId,JailRifle,1);
            Player::setItemCount(%clientId,PlasmaCannon,1);
            Player::setItemCount(%clientId,HyperB,1);
            Player::setItemCount(%clientId,TankRPGLauncher,1);
            Player::setItemCount(%clientId,TankShredder,1);
            Player::setItemCount(%clientId,TRocketLauncher,1);
            Player::setItemCount(%clientId,FireballAbility,1);
            Player::setItemCount(%clientId,LiLFFB,1);
            Player::setItemCount(%clientId,RepairRifle,1);
            Player::setItemCount(%clientId,MineLauncher,1);
            Player::setItemcount(%clientId,DetPackLauncher,1);


		Player::setItemCount(%clientId,BulletAmmo,500);
		Player::setItemCount(%clientId,PlasmaAmmo,999);
		Player::setItemCount(%clientId,DiscAmmo,500);
		Player::setItemCount(%clientId,MortarAmmo,500);
                Player::setItemCount(%clientId,LiLPOOmkiAmmo,999);
                Player::setItemCount(%clientId,LiLPOOmkiiAmmo,999);
                Player::setItemCount(%clientId,TankRPGAmmo,500);
                Player::setItemCount(%clientId,TankShredderAmmo,999);
                Player::setItemCount(%clientId,TRocketLauncherAmmo,999);
                Player::setItemCount(%clientId,FireballAbilityAmmo,999);
                Player::setItemCount(%clientId,MineLauncherAmmo,500);
                Player::setItemCount(%clientId,LiLFFBAmmo,55);
                Player::setItemcount(%clientId,DetPackLauncherAmmo,15);

                Player::setItemCount(%clientId,Grenade, 475);
                Player::setItemCount(%clientId,MineAmmo, 200);
		Player::setItemCount(%clientId,Beacon,  450);

		Player::setItemCount(%clientId,RepairKit,200);
	}
	else if($ServerCheats) {
		%armor = Player::getArmor(%clientId);
		Player::setItemCount(%clientId,BulletAmmo,$ItemMax[%armor, BulletAmmo]);
		Player::setItemCount(%clientId,PlasmaAmmo,$ItemMax[%armor, PlasmaAmmo]);
		Player::setItemCount(%clientId,GrenadeAmmo,$ItemMax[%armor, GrenadeAmmo]);
		Player::setItemCount(%clientId,DiscAmmo,$ItemMax[%armor, DiscAmmo]);
		Player::setItemCount(%clientId,MortarAmmo,$ItemMax[%armor, MortarAmmo]);

      Player::setItemCount(%clientId,Grenade, $ItemMax[%armor, Grenade]);
      Player::setItemCount(%clientId,MineAmmo,$ItemMax[%armor, MineAmmo]);
		Player::setItemCount(%clientId,Beacon,$ItemMax[%armor, Beacon]);

		Player::setItemCount(%clientId,RepairKit,1);
	}
}


//----------------------------------------------------------------------------


function checkMax(%client,%armor)
{
 	%weaponflag = 0;
	%numweapon = Player::getItemClassCount(%client,"Weapon");
	if (%numweapon > $MaxWeapons[%armor]) {
	   %weaponflag = %numweapon - $MaxWeapons[%armor];
	}
	%max = getNumItems();
	for (%i = 0; %i < %max; %i = %i + 1) {
		%item = getItemData(%i);
		%maxnum = $ItemMax[%armor, %item];
		if(%maxnum != "") {
			%numsell = 0;
			%count = Player::getItemCount(%client,%item);
			if(%count > %maxnum) {
				%numsell =  %count - %maxnum;
			}
			if (%count > 0 && %weaponflag && %item.className == Weapon) {
				%numsell = 1;
				%weaponflag = %weaponflag - 1;
			}
			if(%numsell > 0) {
		    	Client::sendMessage(%client,0,"SOLD " @ %numsell @ " " @ %item);
				teamEnergyBuySell(Client::getOwnedObject(%client),(%item.price * %numsell));
				Player::setItemCount(%client, %item, %count - %numsell);  
				updateBuyingList(%client);
			} 
		}
	}
}

function checkPlayerCash(%client)
{
	%team = Client::getTeam(%client);	
	if($TeamEnergy[%team] != "Infinite") {
		if(%client.teamEnergy > ($InitialPlayerEnergy * -1) ) {
			if(%client.teamEnergy >= 0)
				%diff = $InitialPlayerEnergy;
			else 
				%diff = $InitialPlayerEnergy + %client.teamEnergy;
			$TeamEnergy[%team] -= %diff;
		}
	}
}	

function Mission::reinitData()
{
	$TeamItemCount[0 @ DeployableAmmoPack] = 0;
	$TeamItemCount[0 @ DeployableInvPack] = 0;
	$TeamItemCount[0 @ TurretPack] = 0;
	$TeamItemCount[0 @ CameraPack] = 0;
	$TeamItemCount[0 @ DeployableSensorJammerPack] = 0;
	$TeamItemCount[0 @ PulseSensorPack] = 0;
	$TeamItemCount[0 @ MotionSensorPack] = 0;
	$TeamItemCount[0 @ ScoutVehicle] = 0;
	$TeamItemCount[0 @ LAPCVehicle] = 0;
	$TeamItemCount[0 @ HAPCVehicle] = 0;
	$TeamItemCount[0 @ Beacon] = 0;
	$TeamItemCount[0 @ mineammo] = 0;

	$TeamItemCount[1 @ DeployableAmmoPack] = 0;
	$TeamItemCount[1 @ DeployableInvPack] = 0;
	$TeamItemCount[1 @ TurretPack] = 0;
	$TeamItemCount[1 @ CameraPack] = 0;
	$TeamItemCount[1 @ DeployableSensorJammerPack] = 0;
	$TeamItemCount[1 @ PulseSensorPack] = 0;
	$TeamItemCount[1 @ MotionSensorPack] = 0;
	$TeamItemCount[1 @ ScoutVehicle] = 0;
	$TeamItemCount[1 @ LAPCVehicle] = 0;
	$TeamItemCount[1 @ HAPCVehicle] = 0;
	$TeamItemCount[1 @ Beacon] = 0;
	$TeamItemCount[1 @ mineammo] = 0;

	$TeamItemCount[2 @ DeployableAmmoPack] = 0;
	$TeamItemCount[2 @ DeployableInvPack] = 0;
	$TeamItemCount[2 @ TurretPack] = 0;
	$TeamItemCount[2 @ CameraPack] = 0;
	$TeamItemCount[2 @ DeployableSensorJammerPack] = 0;
	$TeamItemCount[2 @ PulseSensorPack] = 0;
	$TeamItemCount[2 @ MotionSensorPack] = 0;
	$TeamItemCount[2 @ ScoutVehicle] = 0;
	$TeamItemCount[2 @ LAPCVehicle] = 0;
	$TeamItemCount[2 @ HAPCVehicle] = 0;
	$TeamItemCount[2 @ Beacon] = 0;
	$TeamItemCount[2 @ mineammo] = 0;

	$TeamItemCount[3 @ DeployableAmmoPack] = 0;
	$TeamItemCount[3 @ DeployableInvPack] = 0;
	$TeamItemCount[3 @ TurretPack] = 0;
	$TeamItemCount[3 @ CameraPack] = 0;
	$TeamItemCount[3 @ DeployableSensorJammerPack]= 0;
	$TeamItemCount[3 @ PulseSensorPack] = 0;
	$TeamItemCount[3 @ MotionSensorPack] = 0;
	$TeamItemCount[3 @ ScoutVehicle] = 0;
	$TeamItemCount[3 @ LAPCVehicle] = 0;
	$TeamItemCount[3 @ HAPCVehicle] = 0;
	$TeamItemCount[3 @ Beacon] = 0;
	$TeamItemCount[3 @ mineammo] = 0;

	$TeamItemCount[4 @ DeployableAmmoPack] = 0;
	$TeamItemCount[4 @ DeployableInvPack] = 0;
	$TeamItemCount[4 @ TurretPack] = 0;
	$TeamItemCount[4 @ CameraPack] = 0;
	$TeamItemCount[4 @ DeployableSensorJammerPack]= 0;
	$TeamItemCount[4 @ PulseSensorPack] = 0;
	$TeamItemCount[4 @ MotionSensorPack] = 0;
	$TeamItemCount[4 @ ScoutVehicle] = 0;
	$TeamItemCount[4 @ LAPCVehicle] = 0;
	$TeamItemCount[4 @ HAPCVehicle] = 0;
	$TeamItemCount[4 @ Beacon] = 0;
	$TeamItemCount[4 @ mineammo] = 0;

	$TeamItemCount[5 @ DeployableAmmoPack] = 0;
	$TeamItemCount[5 @ DeployableInvPack] = 0;
	$TeamItemCount[5 @ TurretPack] = 0;
	$TeamItemCount[5 @ CameraPack] = 0;
	$TeamItemCount[5 @ DeployableSensorJammerPack]= 0;
	$TeamItemCount[5 @ PulseSensorPack] = 0;
	$TeamItemCount[5 @ MotionSensorPack] = 0;
	$TeamItemCount[5 @ ScoutVehicle] = 0;
	$TeamItemCount[5 @ LAPCVehicle] = 0;
	$TeamItemCount[5 @ HAPCVehicle] = 0;
	$TeamItemCount[5 @ Beacon] = 0;
	$TeamItemCount[5 @ mineammo] = 0;

	$TeamItemCount[6 @ DeployableAmmoPack] = 0;
	$TeamItemCount[6 @ DeployableInvPack] = 0;
	$TeamItemCount[6 @ TurretPack] = 0;
	$TeamItemCount[6 @ CameraPack] = 0;
	$TeamItemCount[6 @ DeployableSensorJammerPack]= 0;
	$TeamItemCount[6 @ PulseSensorPack] = 0;
	$TeamItemCount[6 @ MotionSensorPack] = 0;
	$TeamItemCount[6 @ ScoutVehicle] = 0;
	$TeamItemCount[6 @ LAPCVehicle] = 0;
	$TeamItemCount[6 @ HAPCVehicle] = 0;
	$TeamItemCount[6 @ Beacon] = 0;
	$TeamItemCount[6 @ mineammo] = 0;

	$TeamItemCount[7 @ DeployableAmmoPack] = 0;
	$TeamItemCount[7 @ DeployableInvPack] = 0;
	$TeamItemCount[7 @ TurretPack] = 0;
	$TeamItemCount[7 @ CameraPack] = 0;
	$TeamItemCount[7 @ DeployableSensorJammerPack]= 0;
	$TeamItemCount[7 @ PulseSensorPack] = 0;
	$TeamItemCount[7 @ MotionSensorPack] = 0;
	$TeamItemCount[7 @ ScoutVehicle] = 0;
	$TeamItemCount[7 @ LAPCVehicle] = 0;
	$TeamItemCount[7 @ HAPCVehicle] = 0;
	$TeamItemCount[7 @ Beacon] = 0;
	$TeamItemCount[7 @ mineammo] = 0;
	
	//--USW-
	
	$TeamItemCount[0 @ LaserTurretPack] = 0;
	$TeamItemCount[1 @ LaserTurretPack] = 0;
	$TeamItemCount[2 @ LaserTurretPack] = 0;
	$TeamItemCount[3 @ LaserTurretPack] = 0;
	$TeamItemCount[4 @ LaserTurretPack] = 0;
	$TeamItemCount[5 @ LaserTurretPack] = 0;
    $TeamItemCount[6 @ LaserTurretPack] = 0;
	$TeamItemCount[7 @ LaserTurretPack] = 0;
	
	$TeamItemCount[0 @ LaserTurretBPack] = 0;
	$TeamItemCount[1 @ LaserTurretBPack] = 0;
	$TeamItemCount[2 @ LaserTurretBPack] = 0;
	$TeamItemCount[3 @ LaserTurretBPack] = 0;
	$TeamItemCount[4 @ LaserTurretBPack] = 0;
	$TeamItemCount[5 @ LaserTurretBPack] = 0;
	$TeamItemCount[6 @ LaserTurretBPack] = 0;
	$TeamItemCount[7 @ LaserTurretBPack] = 0;
	
	$TeamItemCount[0 @ TaserTrtBPack] = 0;
	$TeamItemCount[1 @ TaserTrtBPack] = 0;
	$TeamItemCount[2 @ TaserTrtBPack] = 0;
	$TeamItemCount[3 @ TaserTrtBPack] = 0;
	$TeamItemCount[4 @ TaserTrtBPack] = 0;
	$TeamItemCount[5 @ TaserTrtBPack] = 0;
	$TeamItemCount[6 @ TaserTrtBPack] = 0;
	$TeamItemCount[7 @ TaserTrtBPack] = 0;
	
	$TeamItemCount[0 @ TaserTrtCPack] = 0;
	$TeamItemCount[1 @ TaserTrtCPack] = 0;
	$TeamItemCount[2 @ TaserTrtCPack] = 0;
	$TeamItemCount[3 @ TaserTrtCPack] = 0;
	$TeamItemCount[4 @ TaserTrtCPack] = 0;
	$TeamItemCount[5 @ TaserTrtCPack] = 0;
	$TeamItemCount[6 @ TaserTrtCPack] = 0;
	$TeamItemCount[7 @ TaserTrtCPack] = 0;
	
	$TeamItemCount[0 @ MiniFlakTurretPack] = 0;
	$TeamItemCount[1 @ MiniFlakTurretPack] = 0;
	$TeamItemCount[2 @ MiniFlakTurretPack] = 0;
	$TeamItemCount[3 @ MiniFlakTurretPack] = 0;
	$TeamItemCount[4 @ MiniFlakTurretPack] = 0;
	$TeamItemCount[5 @ MiniFlakTurretPack] = 0;
    $TeamItemCount[6 @ MiniFlakTurretPack] = 0;
	$TeamItemCount[7 @ MiniFlakTurretPack] = 0;
	
	$TeamItemCount[0 @ MiniSAMTurretPack] = 0;
	$TeamItemCount[1 @ MiniSAMTurretPack] = 0;
	$TeamItemCount[2 @ MiniSAMTurretPack] = 0;
	$TeamItemCount[3 @ MiniSAMTurretPack] = 0;
	$TeamItemCount[4 @ MiniSAMTurretPack] = 0;
	$TeamItemCount[5 @ MiniSAMTurretPack] = 0;
        $TeamItemCount[6 @ MiniSAMTurretPack] = 0;
	$TeamItemCount[7 @ MiniSAMTurretPack] = 0;
	
	$TeamItemCount[0 @ MiniELFTurretPack] = 0;
	$TeamItemCount[1 @ MiniELFTurretPack] = 0;
	$TeamItemCount[2 @ MiniELFTurretPack] = 0;
	$TeamItemCount[3 @ MiniELFTurretPack] = 0;
	$TeamItemCount[4 @ MiniELFTurretPack] = 0;
	$TeamItemCount[5 @ MiniELFTurretPack] = 0;
	$TeamItemCount[6 @ MiniELFTurretPack] = 0;
	$TeamItemCount[7 @ MiniELFTurretPack] = 0;
	
	$TeamItemCount[0 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[1 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[2 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[3 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[4 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[5 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[6 @ MiniSmokeTurretPack] = 0;
	$TeamItemCount[7 @ MiniSmokeTurretPack] = 0;

      $TeamItemCount[0 @ RailTurret] = 0;
	$TeamItemCount[1 @ RailTurret] = 0;
	$TeamItemCount[2 @ RailTurret] = 0;
	$TeamItemCount[3 @ RailTurret] = 0;
	$TeamItemCount[4 @ RailTurret] = 0;
	$TeamItemCount[5 @ RailTurret] = 0;
	$TeamItemCount[6 @ RailTurret] = 0;
	$TeamItemCount[7 @ RailTurret] = 0;

      $TeamItemCount[0 @ ChaingunTurretPack] = 0;
      $TeamItemCount[1 @ ChaingunTurretPack] = 0;
      $TeamItemCount[2 @ ChaingunTurretPack] = 0;
      $TeamItemCount[3 @ ChaingunTurretPack] = 0;
      $TeamItemCount[4 @ ChaingunTurretPack] = 0;
      $TeamItemCount[5 @ ChaingunTurretPack] = 0;
      $TeamItemCount[6 @ ChaingunTurretPack] = 0;
      $TeamItemCount[7 @ ChaingunTurretPack] = 0;

      $TeamItemCount[0 @ "SeekerPack"] = 0;
      $TeamItemCount[1 @ "SeekerPack"] = 0;
      $TeamItemCount[2 @ "SeekerPack"] = 0;
      $TeamItemCount[3 @ "SeekerPack"] = 0;
      $TeamItemCount[4 @ "SeekerPack"] = 0;
      $TeamItemCount[5 @ "SeekerPack"] = 0;
      $TeamItemCount[6 @ "SeekerPack"] = 0;
      $TeamItemCount[7 @ "SeekerPack"] = 0;

      $TeamItemCount[0 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[1 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[2 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[3 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[4 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[5 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[6 @ "ArbitorBoxPack"] = 0;
      $TeamItemCount[7 @ "ArbitorBoxPack"] = 0;

      $TeamItemCount[0 @ SuicidePack] = 0;
      $TeamItemCount[1 @ SuicidePack] = 0;
      $TeamItemCount[2 @ SuicidePack] = 0;
      $TeamItemCount[3 @ SuicidePack] = 0;
      $TeamItemCount[4 @ SuicidePack] = 0;
      $TeamItemCount[5 @ SuicidePack] = 0;
      $TeamItemCount[6 @ SuicidePack] = 0;
      $TeamItemCount[7 @ SuicidePack] = 0;

      $TeamItemCount[0 @ HolePack] = 0;
      $TeamItemCount[1 @ HolePack] = 0;
      $TeamItemCount[2 @ HolePack] = 0;
      $TeamItemCount[3 @ HolePack] = 0;
      $TeamItemCount[4 @ HolePack] = 0;
      $TeamItemCount[5 @ HolePack] = 0;
      $TeamItemCount[6 @ HolePack] = 0;
      $TeamItemCount[7 @ HolePack] = 0;

      
	$TeamItemCount[0 @ lgaForceFieldPack] = 0;
	$TeamItemCount[1 @ lgaForceFieldPack] = 0;
	$TeamItemCount[2 @ lgaForceFieldPack] = 0;
	$TeamItemCount[3 @ lgaForceFieldPack] = 0;
	$TeamItemCount[4 @ lgaForceFieldPack] = 0;
	$TeamItemCount[5 @ lgaForceFieldPack] = 0;
	$TeamItemCount[6 @ lgaForceFieldPack] = 0;
	$TeamItemCount[7 @ lgaForceFieldPack] = 0;
	       
	$TeamItemCount[0 @ lgbForceFieldPack] = 0;
	$TeamItemCount[1 @ lgbForceFieldPack] = 0;
	$TeamItemCount[2 @ lgbForceFieldPack] = 0;
	$TeamItemCount[3 @ lgbForceFieldPack] = 0;
	$TeamItemCount[4 @ lgbForceFieldPack] = 0;
	$TeamItemCount[5 @ lgbForceFieldPack] = 0;
	$TeamItemCount[6 @ lgbForceFieldPack] = 0;
	$TeamItemCount[7 @ lgbForceFieldPack] = 0;
	       
	       
	$TeamItemCount[0 @ medaForceFieldPack] = 0;
	$TeamItemCount[1 @ medaForceFieldPack] = 0;
	$TeamItemCount[2 @ medaForceFieldPack] = 0;
	$TeamItemCount[3 @ medaForceFieldPack] = 0;
	$TeamItemCount[4 @ medaForceFieldPack] = 0;
	$TeamItemCount[5 @ medaForceFieldPack] = 0;
	$TeamItemCount[6 @ medaForceFieldPack] = 0;
	$TeamItemCount[7 @ medaForceFieldPack] = 0;
	       
	$TeamItemCount[0 @ medbForceFieldPack] = 0;
	$TeamItemCount[1 @ medbForceFieldPack] = 0;
	$TeamItemCount[2 @ medbForceFieldPack] = 0;
	$TeamItemCount[3 @ medbForceFieldPack] = 0;
	$TeamItemCount[4 @ medbForceFieldPack] = 0;
	$TeamItemCount[5 @ medbForceFieldPack] = 0;
	$TeamItemCount[6 @ medbForceFieldPack] = 0;
	$TeamItemCount[7 @ medbForceFieldPack] = 0;
	              
	$TeamItemCount[0 @ medcForceFieldPack] = 0;
	$TeamItemCount[1 @ medcForceFieldPack] = 0;
	$TeamItemCount[2 @ medcForceFieldPack] = 0;
	$TeamItemCount[3 @ medcForceFieldPack] = 0;
	$TeamItemCount[4 @ medcForceFieldPack] = 0;
	$TeamItemCount[5 @ medcForceFieldPack] = 0;
	$TeamItemCount[6 @ medcForceFieldPack] = 0;
        $TeamItemCount[7 @ medcForceFieldPack] = 0;

      $TeamItemCount[0 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[1 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[2 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[3 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[4 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[5 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[6 @ ForceFieldFloorPack] = 0;
      $TeamItemCount[7 @ ForceFieldFloorPack] = 0;
      
      $TeamItemCount[0 @ ShockFloorPack] = 0;
      $TeamItemCount[1 @ ShockFloorPack] = 0;
      $TeamItemCount[2 @ ShockFloorPack] = 0;
      $TeamItemCount[3 @ ShockFloorPack] = 0;
      $TeamItemCount[4 @ ShockFloorPack] = 0;
      $TeamItemCount[5 @ ShockFloorPack] = 0;
      $TeamItemCount[6 @ ShockFloorPack] = 0;
      $TeamItemCount[7 @ ShockFloorPack] = 0;
        
        $TeamItemCount[0 @ DeployableTeleport] = 0;
	$TeamItemCount[1 @ DeployableTeleport] = 0;
	$TeamItemCount[2 @ DeployableTeleport] = 0;
	$TeamItemCount[3 @ DeployableTeleport] = 0;
	$TeamItemCount[4 @ DeployableTeleport] = 0;
	$TeamItemCount[5 @ DeployableTeleport] = 0;
	$TeamItemCount[6 @ DeployableTeleport] = 0;
	$TeamItemCount[7 @ DeployableTeleport] = 0;
	
        $TeamItemCount[0 @ RadiusMineAmmo] = 0;
	$TeamItemCount[1 @ RadiusMineAmmo] = 0;
	$TeamItemCount[2 @ RadiusMineAmmo] = 0;
	$TeamItemCount[3 @ RadiusMineAmmo] = 0;
	$TeamItemCount[4 @ RadiusMineAmmo] = 0;
	$TeamItemCount[5 @ RadiusMineAmmo] = 0;
	$TeamItemCount[6 @ RadiusMineAmmo] = 0;
	$TeamItemCount[7 @ RadiusMineAmmo] = 0;
	
        $TeamItemCount[0 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[1 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[2 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[3 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[4 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[5 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[6 @ USWGasAttackAmmo] = 0;
	$TeamItemCount[7 @ USWGasAttackAmmo] = 0;
	
        $TeamItemCount[0 @ FlashGrenade] = 0;
	$TeamItemCount[1 @ FlashGrenade] = 0;
	$TeamItemCount[2 @ FlashGrenade] = 0;
	$TeamItemCount[3 @ FlashGrenade] = 0;
	$TeamItemCount[4 @ FlashGrenade] = 0;
	$TeamItemCount[5 @ FlashGrenade] = 0;
	$TeamItemCount[6 @ FlashGrenade] = 0;
	$TeamItemCount[7 @ FlashGrenade] = 0;
	
        $TeamItemCount[0 @ LiLBoostammo] = 0;
	$TeamItemCount[1 @ LiLBoostammo] = 0;
	$TeamItemCount[2 @ LiLBoostammo] = 0;
	$TeamItemCount[3 @ LiLBoostammo] = 0;
	$TeamItemCount[4 @ LiLBoostammo] = 0;
	$TeamItemCount[5 @ LiLBoostammo] = 0;
	$TeamItemCount[6 @ LiLBoostammo] = 0;
	$TeamItemCount[7 @ LiLBoostammo] = 0;
	
        $TeamItemCount[0 @ cactuspack] = 0;
	$TeamItemCount[1 @ cactuspack] = 0;
	$TeamItemCount[2 @ cactuspack] = 0;
	$TeamItemCount[3 @ cactuspack] = 0;
	$TeamItemCount[4 @ cactuspack] = 0;
	$TeamItemCount[5 @ cactuspack] = 0;
	$TeamItemCount[6 @ cactuspack] = 0;
	$TeamItemCount[7 @ cactuspack] = 0;
	
	$TeamItemCount[0 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[1 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[2 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[3 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[4 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[5 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[6 @ ForceFieldDoorPack] = 0;
	$TeamItemCount[7 @ ForceFieldDoorPack] = 0;
	
	$TeamItemCount[0 @ jailpack] = 0;
	$TeamItemCount[1 @ jailpack] = 0;
	$TeamItemCount[2 @ jailpack] = 0;
	$TeamItemCount[3 @ jailpack] = 0;
	$TeamItemCount[4 @ jailpack] = 0;
	$TeamItemCount[5 @ jailpack] = 0;
	$TeamItemCount[6 @ jailpack] = 0;
	$TeamItemCount[7 @ jailpack] = 0;
	
	$TeamItemCount[0 @ hugewall] = 0;
    $TeamItemCount[1 @ hugewall] = 0;
    $TeamItemCount[2 @ hugewall] = 0;
    $TeamItemCount[3 @ hugewall] = 0;
    $TeamItemCount[4 @ hugewall] = 0;
    $TeamItemCount[5 @ hugewall] = 0;
    $TeamItemCount[6 @ hugewall] = 0;
    $TeamItemCount[7 @ hugewall] = 0;

      
	
	//--USW

	$totalNumCameras = 0;
	$totalNumTurrets = 0;


	for(%i = -1; %i < 8 ; %i++)
		$TeamEnergy[%i] = $DefaultTeamEnergy; 
}
//============================
//ShockFloorPack//
//============================
ItemImageData ShockFloorPackImage
{
	shapeFile = "plasmabolt";
	mountPoint = 2;
   	mountOffset = { 0, -0.03, -0.4 };
	mass = 1.5;
	firstPerson = false;
};

ItemData ShockFloorPack
{
	description = "Blast Floor";
	shapeFile = "display_three";
	className = "Backpack";
	heading = "nDeployable Walls";
	imageType = ShockFloorPackImage;
	shadowDetailMask = 4;
	elasticity = 0.2;
	price = 500;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function ShockFloorPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item)
	{
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else
	{
		Player::deployItem(%player,%item);
	}
}

function ShockFloorPack::onDeploy(%player,%item,%pos)
{
	if (ShockFloorPack::deployShape(%player,%item))
	{
		Player::decItemCount(%player,%item);
	}
}

function ShockFloorPack::deployShape(%player,%item)
{
	GameBase::getLOSInfo(%player,3);
	%client = Player::getClient(%player);
	%team = GameBase::getTeam(%player);
	if($TeamItemCount[%team @ "ShockFloorPack"] < $TeamItemMax["ShockFloorPack"])
	{
		%deploypos = Vector::add(Gamebase::getPosition(%player), EmplacementPack::rotVector( "0 3 0", GameBase::getRotation(%player) ) );
		if (Vector::dot($los::normal,"0 0 1") < 0.7 ) %deploypos = Vector::add(%deploypos, "0 0 2");
		%rot = Vector::add(GameBase::getRotation(%player), "1.57 0 0");
		%inv = newObject("Shock Floor", "StaticShape", "ShockFloor", true);
		addToSet("MissionCleanup", %inv);
		GameBase::setTeam(%inv,%team);
		GameBase::setRotation(%inv,%rot);
		GameBase::setPosition(%inv,%deploypos);
		Gamebase::setMapName(%inv,"Blast Floor");
		Client::setOwnedObject(%client, %inv);
		Client::setOwnedObject(%client, %player);
		playSound(SoundPickupBackpack,$los::position);
		$TeamItemCount[%team @ "ShockFloorPack"]++;
		Client::sendMessage(%client,0,"Blast Floor is laid.");
		%inv.nukable = "True";
        }
}
ItemImageData ForceFieldDoorPackImage
{	
	shapeFile = "AmmoPack";
	mountPoint = 2;
	mountOffset = { 0, -0.03, 0 };
	mountRotation = { 0, 0, 0 };
	mass = 2.5;
	firstPerson = false;
};

ItemData ForceFieldDoorPack
{	
	description = "USW WALL";
	shapeFile = "AmmoPack";
	className = "Backpack";
	heading = $InvHead[ihBar];
	imageType = ForceFieldDoorPackImage;
	shadowDetailMask = 4;
	mass = 2.5;
	elasticity = 0.2;
	price = 500;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function ForceFieldDoorPack::onUse(%player,%item)
{	
	if(Player::getMountedItem(%player,$BackpackSlot) != %item)
		Player::mountItem(%player,%item,$BackpackSlot);
	else
		Player::deployItem(%player,%item);
}

function ForceFieldDoorPack::onDeploy(%player,%item,%pos)
{	
	if(ForceFieldDoorPack::deployShape(%player,%item)&& !$build)
		Player::decItemCount(%player,%item);
}

function ForceFieldDoorPack::deployShape(%player,%item)
{	
	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] >= $TeamItemMax[%item] && !$build) 
	{
		Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
		return false;
	}
	if(!GameBase::getLOSInfo(%player,3)) 
	{
		Client::sendMessage(%client,0,"Cannot deploy here.");
		return false;
	}
	%rot = GameBase::getRotation(%player);
	%obj = newObject("ForceFieldDoorPack","StaticShape",ForceFieldDoorShape,true);
	NukeList(%obj);
	%obj.cloakable = true;
	addToSet("MissionCleanup", %obj);
	GameBase::setTeam(%obj,GameBase::getTeam(%player));
	GameBase::setRotation(%obj,%rot);
	GameBase::setPosition(%obj,$los::position);
	Gamebase::setMapName(%obj,"Blast Wall :)");
	Client::sendMessage(%client,0,"Blast Wall :)");
	playSound(SoundPickupBackpack,$los::position);
	$TeamItemCount[GameBase::getTeam(%obj) @ "ForceFieldDoorPack"]++;
	echo("MSG: ",%client," deployed a Blast Wall :) ");
	return true;
}


exec("JailGun.cs");
exec("doubleplasma.cs");
exec("MineLauncher.cs");
exec("DetPackLauncher.cs");
exec("HugeBlastWall.cs");