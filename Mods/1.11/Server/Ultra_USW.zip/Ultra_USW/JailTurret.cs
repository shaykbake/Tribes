////////////JailTurret////////////
TurretData JailTurret
{
	className = "Turret";
	shapeFile = "camera"; //"remoteturret";
	projectileType = JailDart;
	maxDamage = 150;// 0.65;
	maxEnergy = 300;
	minGunEnergy = 75;
	maxGunEnergy = 0.01;// 0.1;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	reloadDelay = 0.1;
	speed = 4.0;//4.0
	speedModifier = 1.5;//1.5
	range = 200;
	visibleToSensor = true;
	shadowDetailMask = 4;
	dopplerVelocity = 1;//0;
	castLOS = true;
	supression = false;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	fireSound = SoundRemoteTurretFire;
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
	description = "Jail Turret";
	damageSkinData = "objectDamageSkins";
};

function JailTurret::onAdd(%this)
{
	schedule("JailTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,5);
	%this.shieldStrength = 0.010;
	if (GameBase::getMapName(%this) == "") {
		GameBase::setMapName (%this, "Jail Turret");
	}
}

function JailTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function JailTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function JailTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "JailTurretPack"]--;
}

// Override base class just in case.
function JailTurret::onPower(%this,%power,%generator) {}
function JailTurret::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,5);
	GameBase::setActive(%this,true);
}
////////////JailTurretTurret////////////
$TeamItemMax[JailTurretPack] = 500;

ItemImageData JailTurretImage
{
	shapeFile = "camera";
	mountPoint = 2;
	mountOffset = { 0, -0.1, -0.06 };
	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData JailTurretPack
{
	description = "Jail Turret";
	shapeFile = "camera";
	className = "Backpack";
   heading = "zJail Deployables";
	imageType = JailTurretImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 125;
	hudIcon = "TurretsUSW";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function JailTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function JailTurretPack::onDeploy(%player,%item,%pos)
{
	if (JailTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function JailTurretPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") {

				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%camera = newObject("Camera","Turret",JailTurret,true);
	   	      addToSet("MissionCleanup", %camera);
					GameBase::setTeam(%camera,GameBase::getTeam(%player));
					GameBase::setRotation(%camera,%rot);
					GameBase::setPosition(%camera,$los::position);
					Gamebase::setMapName(%camera,"JailTurret#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"JailTurret deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%camera) @ "JailTurretPack"]++;
					Client::setOwnedObject(%client, %elfturret); 
		            Client::setOwnedObject(%client, %player);
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

	$TeamItemCount[0 @ JailTurretPack] = 0;
	$TeamItemCount[1 @ JailTurretPack] = 0;
	$TeamItemCount[2 @ JailTurretPack] = 0;
	$TeamItemCount[3 @ JailTurretPack] = 0;
	$TeamItemCount[4 @ JailTurretPack] = 0;
	$TeamItemCount[5 @ JailTurretPack] = 0;
	$TeamItemCount[6 @ JailTurretPack] = 0;
	$TeamItemCount[7 @ JailTurretPack] = 0;	
	
	
//=====Armordata.cs======//	
$ItemMax[larmor, JailTurretPack] = 1;
$ItemMax[marmor, JailTurretPack] = 1;
$ItemMax[harmor, JailTurretPack] = 1;
$ItemMax[lfemale, JailTurretPack] = 1;
$ItemMax[mfemale, JailTurretPack] = 1;	

//=======Station.cs======//
$InvList[JailTurretPack] = 1;
$RemoteInvList[JailTurretPack] = 1;