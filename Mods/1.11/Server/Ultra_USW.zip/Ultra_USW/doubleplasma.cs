//-----------------------------
//====Double Plasma
//-----------------------------

//====Item.cs====//
ItemImageData HyperB1Image 
{ 
	 shapeFile = "plasma"; 
	mountPoint = 0; 
	mountOffset = { -0.75, 0, 0 };
	weaponType = 0;
      ammoType = PlasmaAmmo;
//	minEnergy = 5;
//	maxEnergy = 0.001;// 6;
	accuFire = true; 
	reloadTime = 0.03;// 0;
	fireTime = 0.03;// 0.1;
	projectileType = PlasmaBolt; 
}; 

ItemData HyperB1
{ 
	description = "Double Plasma";
	className = "Weapon"; 
	shapeFile = "plasma"; 
	hudIcon = "chain"; 
	heading = "TUSW-Weapons"; 
	shadowDetailMask = 4; 
	imageType = HyperB1Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
}; 

ItemImageData HyperB2Image 
{
	 shapeFile = "plasma"; 
	mountPoint = 0; 
	weaponType = 0;
    ammoType = PlasmaAmmo;
//	minEnergy = 0;
//	maxEnergy = 0;
	accuFire = true; 
	reloadTime = 0.03;// 0;
	fireTime = 0.03;// 0.1;
	projectileType = PlasmaBolt; 
}; 

ItemData HyperB2 
{ 
	description = "Double Plasma";
	 className = "Weapon"; 
	shapeFile = "plasma"; 
	hudIcon = "chain"; 
	heading = "TUSW-Weapons"; 
	shadowDetailMask = 4; 
	imageType = HyperB2Image; 
	price = 0; 
	showWeaponBar = false; 
	showInventory = false; 
};

ItemImageData HyperBImage 
{ 
	shapeFile = "breath"; 
	mountPoint = 0; 
	mountOffset = { -0.38, -1, -0.5 };
	weaponType = 0; 
    ammoType = PlasmaAmmo;
	reloadTime = 0.03;// 0;
//	minEnergy = 0;
//	maxEnergy = 0;
	fireTime = 0.03;// 0.1;
	sfxFire = SoundFirePlasma; 
	sfxActivate = SoundPickUpWeapon; 
}; 

ItemData HyperB
{ 
	description = "Double Plasma"; 
	className = "Weapon"; 
	shapeFile = "plasma"; 
	hudIcon = "chain"; 
   heading = "TUSW-Weapons";
	shadowDetailMask = 4; 
	imageType = HyperBImage; 
	price = 200; 
	showWeaponBar = true;
}; 

function HyperBImage::onFire(%player, %slot) 
{  
	%state1 = Player::getItemState(%player,4);  
	%state2 = Player::getItemState(%player,5);  
	if (%state1 != "Fire" && %state1 != "Reload" && %state2 != "Fire" && %state2 != "Reload") 
	{   
		%client = GameBase::getOwnerClient(%player);   
		if(%client.hd == 0) 
		{    
			%client.hd = 1;    
			Player::trigger(%player,4,true);    
			Player::trigger(%player,4,false);   
		} 
		else 
		{    
			%client.hd = 0;    
			Player::trigger(%player,5,true);    
			Player::trigger(%player,5,false);   
		}  
	} 
} 

function HyperB::onMount(%player,%imageSlot) 
{  
	Player::mountItem(%player,HyperB1,4);  
	Player::mountItem(%player,HyperB2,5); 
} 

function HyperB::onUnmount(%player,%imageSlot) 
{  
	Player::unmountItem(%player,4);  
	Player::unmountItem(%player,5); 
}

$AutoUse[HyperB]			= True;





//====Station.cs====//
$InvList[HyperB] = 1;
$RemoteInvList[HyperB] = 1;

//====Armordata.cs====//
$ItemMax[harmor, HyperB] = 1;
$ItemMax[marmor, HyperB] = 1;
$ItemMax[mfemale, HyperB] = 1;
$ItemMax[larmor, HyperB] = 1;
$ItemMax[lfemale, HyperB] = 1;
$ItemMax[harmorx, HyperB] = 1;
$ItemMax[marmork, HyperB] = 1;
$ItemMax[mfemalek, HyperB] = 1;
$ItemMax[larmorz, HyperB] = 1;
$ItemMax[lfemalez, HyperB] = 1;

//*****************************
