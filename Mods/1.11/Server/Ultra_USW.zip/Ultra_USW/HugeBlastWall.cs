ItemImageData hugewallImage
{
        shapeFile = "magcargo";
        mountPoint = 2;
        mountOffset = { 0, 0, 0 };
        mountRotation = { 0, 0, 0 };
        firstPerson = false;
	mass = 1.5;
};

ItemData hugewall
{
	description = "Huge Wall";
	shapeFile = "newdoor5";
	className = "Backpack";
	heading = "dDeployables";
	imageType = hugewallImage;
	shadowDetailMask = 4;
	mass = 5.0;
	elasticity = 0.2;
	price = 6000;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function hugewall::onUse(%player,%item)
{
        if (Player::getMountedItem(%player,$BackpackSlot) != %item)
        {
                Player::mountItem(%player,%item,$BackpackSlot);
        }
        else
        {
                Player::deployItem(%player,%item);
        }
}

function hugewall::onDeploy(%player,%item,%pos)
{
        if (hugewall::deployShape(%player,%item))
        {
                Player::decItemCount(%player,%item);
        }
}


function hugewall::deployshape(%player,%item)
{
        GameBase::getLOSInfo(%player,3);
        %client = Player::getClient(%player);
        if($TeamItemCount[GameBase::getTeam(%player) @ "hugewall"] >= $TeamItemMax[hugewall])
        {
		Client::sendMessage(%client,0,"Cannot Deploy. Jail Cell Already In Place");
		return false;
         }
	%playerPos = GameBase::getPosition(%player);
	%flag = $teamFlag[GameBase::getTeam(%player)];
	%flagpos = gamebase::getPosition(%flag);
	if(Vector::getDistance(%flagpos, %playerpos) < 10)
	{
                 Client::sendMessage(%client,0,"You are too close to your flag, Must be further from flag to deploy.");
                 return ;
	}
	%obj = getObjectType($los::object);
	%set = newObject("hugewall",SimSet);
	%num = containerBoxFillSet(%set,$StaticObjectType,$los::position,$ForceFieldBoxMinLength,$ForceFieldBoxMinWidth,$ForceFieldBoxMinHeight,0);
	%num = CountObjects(%set,"hugewall",%num);

	%objDevice =   newObject("hugewall","Staticshape",HugeWallShape,true);
	%objDevice.objSide1 = newObject("hugewall","Staticshape",HugeWallShape,true);
	%objDevice.objSide2 = newObject("hugewall","Staticshape",HugeWallShape,true);
	%objDevice.objSide3 = newObject("hugewall","Staticshape",HugeWallShape,true);
	%objDevice.objSide4 = newObject("hugewall","Staticshape",HugeWallShape,true);
	%objDevice.objSide5 = newObject("hugewall","Staticshape",HugeWallShape,true);
	%objDevice.objSide6 = newObject("hugewall","StaticShape",HugeWallShape,true);
	%objDevice.objSide7 = newObject("hugewall","StaticShape",HugeWallShape,true);
	%objDevice.objSide8 = newObject("hugewall","StaticShape",HugeWallShape,true);
	%objDevice.objSide9 = newObject("hugewall","StaticShape",HugeWallShape,true);
	%objDevice.objSide10 = newObject("hugewall","StaticShape",HugeWallShape,true);
	%objDevice.objSide11 = newObject("hugewall","StaticShape",HugeWallShape,true);

	%objDevice.objSide1.objParent = %objDevice;
	%objDevice.objSide2.objParent = %objDevice;
	%objDevice.objSide3.objParent = %objDevice;
	%objDevice.objSide4.objParent = %objDevice;
	%objDevice.objSide5.objParent = %objDevice;
	%objDevice.objSide6.objParent = %objDevice;
	%objDevice.objSide7.objParent = %objDevice;
	%objDevice.objSide8.objParent = %objDevice;
	%objDevice.objSide9.objParent = %objDevice;
	%objDevice.objSide10.objParent = %objDevice;
	%objDevice.objSide11.objParent = %objDevice;

	addToSet(MissionCleanup, %objDevice);

	addToSet(MissionCleanup, %objDevice.objSide1);
	addToSet(MissionCleanup, %objDevice.objSide2);
	addToSet(MissionCleanup, %objDevice.objSide3);
	addToSet(MissionCleanup, %objDevice.objSide4);
	addToSet(MissionCleanup, %objDevice.objSide5);
	addToSet(MissionCleanup, %objDevice.objSide6);
	addToSet(MissionCleanup, %objDevice.objSide7);
	addToSet(MissionCleanup, %objDevice.objSide8);
	addToSet(MissionCleanup, %objDevice.objSide9);
	addToSet(MissionCleanup, %objDevice.objSide10);
	addToSet(MissionCleanup, %objDevice.objSide11);

	%rot = gamebase::getrotation(%player);
    %playerpos = GameBase::getPosition(%player);

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "24.6 11.9 7.9",%rot));
	GameBase::setRotation(%objDevice.objSide1,%rot);
	GameBase::setPosition(%objDevice.objSide1,%pos);
	GameBase::setTeam(%objDevice.objSide1,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "24.6 11.9 15.8", %rot));
	GameBase::setRotation(%objDevice.objSide2,%rot);
	GameBase::setPosition(%objDevice.objSide2,%pos);
	GameBase::setTeam(%objDevice.objSide2,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "14.9 11.9 15.8", %rot));
	GameBase::setRotation(%objDevice.objSide3,%rot);
	GameBase::setPosition(%objDevice.objSide3,%pos);
	GameBase::setTeam(%objDevice.objSide3,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "14.9 11.9 7.9", %rot));
	GameBase::setRotation(%objDevice.objSide4,%rot);
	GameBase::setPosition(%objDevice.objSide4,%pos);
	GameBase::setTeam(%objDevice.objSide4,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "14.9 11.9 0", %rot));
	GameBase::setRotation(%objDevice,%rot);
	GameBase::setPosition(%objDevice,%pos);
	GameBase::setTeam(%objDevice,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "5 11.9 0", %rot));
	GameBase::setRotation(%objDevice.objSide6,%rot);
	GameBase::setPosition(%objDevice.objSide6,%pos);
	GameBase::setTeam(%objDevice.objSide6,GameBase::getTeam(%player));

	
	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "-4.9 11.9 0", %rot));
	GameBase::setRotation(%objDevice.objSide7,%rot);
	GameBase::setPosition(%objDevice.objSide7,%pos);
	GameBase::setTeam(%objDevice.objSide7,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "-4.9 11.9 15.8", %rot));
	GameBase::setRotation(%objDevice.objSide8,%rot);
	GameBase::setPosition(%objDevice.objSide8,%pos);
	GameBase::setTeam(%objDevice.objSide8,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "-4.9 11.9 7.9", %rot));
	GameBase::setRotation(%objDevice.objSide9,%rot);
	GameBase::setPosition(%objDevice.objSide9,%pos);
	GameBase::setTeam(%objDevice.objSide9,GameBase::getTeam(%player));

	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "5 11.9 15.8", %rot));
	GameBase::setRotation(%objDevice.objSide10,%rot);
	GameBase::setPosition(%objDevice.objSide10,%pos);
	GameBase::setTeam(%objDevice.objSide10,GameBase::getTeam(%player));
	
	
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "24.6 11.9 0", %rot));
	GameBase::setRotation(%objDevice.objSide11,%rot);
	GameBase::setPosition(%objDevice.objSide11,%pos);
	GameBase::setTeam(%objDevice.objSide11,GameBase::getTeam(%player));

	playSound(SoundPickupBackpack,$los::position);

	newObject("Hugewall",SimSet);
	addToSet("MissionCleanup","hugewall");
	%sensor = newObject("jaildoor","StaticShape",LLargeForceField,true);

	addToSet("MissionCleanup/hugewall", %sensor);
	addToSet("MissionCleanup", %sensor);
	GameBase::setTeam(%sensor,GameBase::getTeam(%player));
	%pos = Vector::add(%playerpos, EmplacementPack::rotVector( "5 11.9 7.9", %rot));
	GameBase::setPosition(%sensor,%pos);
	GameBase::setRotation(%sensor,%rot);
	%sensor.disabled = false;
	playSound(SoundPickupBackpack,$los::position);

	

	GameBase::setPosition(%sensor,%pos);
	GameBase::setRotation(%camera,%rot);
	Gamebase::setMapName(%sensor,"Huge Wall");

	%sensor.disabled = false;

	$TeamItemCount[GameBase::getTeam(%sensor) @ "hugewall"]++;
	echo("MSG: ",%client," deployed a huge wall");
	Client::sendMessage(%client,0,%item.description @ " deployed ");
	return true;
}

$TeamItemCount[0 @ hugewall] = 0;
$TeamItemCount[1 @ hugewall] = 0;
$TeamItemCount[2 @ hugewall] = 0;
$TeamItemCount[3 @ hugewall] = 0;
$TeamItemCount[4 @ hugewall] = 0;
$TeamItemCount[5 @ hugewall] = 0;
$TeamItemCount[6 @ hugewall] = 0;
$TeamItemCount[7 @ hugewall] = 0;

//====Station.cs===//
$InvList[hugewall] = 1;
$RemoteInvList[hugewall] = 1;

//====Armordata.cs====//
$ItemMax[harmor, hugewall] = 1;
$ItemMax[marmor, hugewall] = 1;
$ItemMax[mfemale, hugewall] = 1;
$ItemMax[larmor, hugewall] = 1;
$ItemMax[lfemale, hugewall] = 1;

//====TeamItemMax====//
$TeamItemMax[hugewall] = 15;
