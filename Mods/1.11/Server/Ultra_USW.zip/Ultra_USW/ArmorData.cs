


//----------------------------------------------------------------------------
// Light Armor
//----------------------------------------------------------------------------

$DamageScale[larmor, $LandingDamageType] = 1.0;
$DamageScale[larmor, $ImpactDamageType] = 1.0;
$DamageScale[larmor, $CrushDamageType] = 1.0;
$DamageScale[larmor, $BulletDamageType] = 1.2;
$DamageScale[larmor, $PlasmaDamageType] = 1.0;
$DamageScale[larmor, $EnergyDamageType] = 1.3;
$DamageScale[larmor, $ExplosionDamageType] = 1.0;
$DamageScale[larmor, $MissileDamageType] = 1.0;
$DamageScale[larmor, $DebrisDamageType] = 1.2;
$DamageScale[larmor, $ShrapnelDamageType] = 1.2;
$DamageScale[larmor, $LaserDamageType] = 1.0;
$DamageScale[larmor, $MortarDamageType] = 1.3;
$DamageScale[larmor, $BlasterDamageType] = 1.3;
$DamageScale[larmor, $ElectricityDamageType] = 1.0;
$DamageScale[larmor, $MineDamageType] = 1.2;
$DamageScale[larmor, $LiLRocketDamageType] = 1.0;
$DamageScale[larmor, $EMPDamageType] = 1.0;
$DamageScale[larmor, $LiLPOOmkiiDamageType] = 1.0;
$DamageScale[larmor, $SmokeDamageType] = 1.0;
$DamageScale[larmor, $MiniELFDamageType] = 1.0;
$DamageScale[larmor, $beamofpainDamageType] = 1.0;
$DamageScale[larmor, $SniperDamageType] = 1.0;
$DamageScale[larmor, $FlashDamageType] = 1.0;
$DamageScale[larmor, $PlasmaCannonDamageType] = 1.5;

$ItemMax[larmor, Blaster] = 1;
$ItemMax[larmor, Chaingun] = 1;
$ItemMax[larmor, Disclauncher] = 1;
$ItemMax[larmor, GrenadeLauncher] = 1;
$ItemMax[larmor, Mortar] = 1;
$ItemMax[larmor, PlasmaGun] = 1;
$ItemMax[larmor, LaserRifle] = 1;
$ItemMax[larmor, EnergyRifle] = 1;
$ItemMax[larmor, TargetingLaser] = 0;
$ItemMax[larmor, MineAmmo] = 35;
$ItemMax[larmor, Grenade] = 35;
$ItemMax[larmor, Beacon]  = 35;
$ItemMax[larmor, JailGun] = 1;// 0;
$ItemMax[larmor, PlasmaCannon] = 1;// 0;
$ItemMax[larmor, RepairRifle] = 1;
$ItemMax[larmor, FireballAbility] = 1;
$ItemMax[larmor, FireScreenAbility] = 1;
$ItemMax[larmor, Stinger] = 1;
$ItemMax[larmor, TankShredder] = 1;
$ItemMax[larmor, TankRPGLauncher] = 1;
$ItemMax[larmor, TRocketLauncher] = 1;
$ItemMax[larmor,HDiscLauncher]=1;


//--USW-
$ItemMax[larmor, TaserRifle] = 1;

$ItemMax[larmor, LiLFFB] = 1;
$ItemMax[larmor, LiLFFBAmmo] = 20;//8;

$ItemMax[larmor, TaserTrtBPack] = 1;
$ItemMax[larmor, TaserTrtCPack] = 1;
$ItemMax[larmor, LaserTurretPack] = 1;
$ItemMax[larmor, RailTurret] = 1;// 0;
$ItemMax[larmor, ChaingunTurretPack] = 1;// 0;
$ItemMax[larmor, TurretPack] = 1;// 0;
$ItemMax[larmor, SeekerPack] = 1;// 0;
$ItemMax[larmor, SuicidePack] = 1;
$ItemMax[larmor, ChaingunTurretPack] = 1;


$ItemMax[larmor, lgaForceFieldPack] = 1;
$ItemMax[larmor, lgbForceFieldPack] = 1;
$ItemMax[larmor, medaForceFieldPack] = 1;
$ItemMax[larmor, medbForceFieldPack] = 1;
$ItemMax[larmor, medcForceFieldPack] = 1;
$ItemMax[larmor, ArbitorBoxPack] = 1;// 0;
$ItemMax[larmor, blastwall] = 1;// 0;
$ItemMax[larmor, ForceFieldFloorPack] = 1;
$ItemMax[larmor, DeployableSolarPanel] = 1;
//--USW

$ItemMax[larmor, BulletAmmo] = 999;
$ItemMax[larmor, PlasmaAmmo] = 999;
$ItemMax[larmor, DiscAmmo] = 350;// 250;
$ItemMax[larmor, GrenadeAmmo] = 55;// 20;
$ItemMax[larmor, MortarAmmo] = 55;// 18;
$ItemMax[larmor, StingerAmmo] = 200;
$ItemMax[larmor, TankShredderAmmo] = 999;
$ItemMax[larmor, TankRPGAmmo] = 999;
$ItemMax[larmor, TRocketLauncherAmmo] = 999;
$ItemMax[larmor,DualDiscs]=350;

$ItemMax[larmor, EnergyPack] = 1;
$ItemMax[larmor, RepairPack] = 1;
$ItemMax[larmor, ShieldPack] = 1;
$ItemMax[larmor, SensorJammerPack] = 1;
$ItemMax[larmor, MotionSensorPack] = 1;
$ItemMax[larmor, PulseSensorPack] = 1;
$ItemMax[larmor, DeployableSensorJammerPack] = 1;
$ItemMax[larmor, CameraPack] = 1;
$ItemMax[larmor, TurretPack] = 1;
$ItemMax[larmor, AmmoPack] = 1;
$ItemMax[larmor, RepairKit] = 1;
$ItemMax[larmor, DeployableInvPack] = 1;
$ItemMax[larmor, DeployableAmmoPack] = 1;
$ItemMax[larmor, jailpack] = 1;// 0;
$ItemMax[larmor, EnergizerPack] = 1;
$ItemMax[larmor, JailCapPack] = 1;
$ItemMax[larmor, HolePack] = 1;
$ItemMax[larmor, HoloPack] = 1;
$ItemMax[larmor, ShockFloorPack] = 1;
$ItemMax[larmor, ForceFieldDoorPack] = 1;

$MaxWeapons[larmor] = 15;

//----------------------------------------------------------------------------
// Medium Armor
//----------------------------------------------------------------------------
$DamageScale[marmor, $LandingDamageType] = 0.7;
$DamageScale[marmor, $ImpactDamageType] = 0.7;
$DamageScale[marmor, $CrushDamageType] = 0.7;
$DamageScale[marmor, $BulletDamageType] = 0.7;
$DamageScale[marmor, $PlasmaDamageType] = 0.6;
$DamageScale[marmor, $EnergyDamageType] = 0.7;
$DamageScale[marmor, $ExplosionDamageType] = 0.7;
$DamageScale[marmor, $MissileDamageType] = 0.7;
$DamageScale[marmor, $ShrapnelDamageType] = 0.7;
$DamageScale[marmor, $DebrisDamageType] = 0.7;
$DamageScale[marmor, $LaserDamageType] = 0.7;
$DamageScale[marmor, $MortarDamageType] = 0.7;
$DamageScale[marmor, $BlasterDamageType] = 0.7;
$DamageScale[marmor, $ElectricityDamageType] = 0.7;
$DamageScale[marmor, $MineDamageType] = 0.7;
$DamageScale[marmor, $LiLRocketDamageType] = 1.0;
$DamageScale[marmor, $EMPDamageType] = 1.0;
$DamageScale[marmor, $LiLPOOmkiiDamageType] = 1.0;
$DamageScale[marmor, $SmokeDamageType] = 1.0;
$DamageScale[marmor, $MiniELFDamageType] = 1.0;
$DamageScale[marmor, $beamofpainDamageType] = 1.0;
$DamageScale[marmor, $SniperDamageType] = 1.0;
$DamageScale[marmor, $FlashDamageType] = 1.0;
$DamageScale[marmor, $PlasmaCannonDamageType] = 1.5;

$ItemMax[marmor, Blaster] = 1;
$ItemMax[marmor, Chaingun] = 1;
$ItemMax[marmor, Disclauncher] = 1;
$ItemMax[marmor, GrenadeLauncher] = 1;
$ItemMax[marmor, Mortar] = 1;
$ItemMax[marmor, PlasmaGun] = 1;
$ItemMax[marmor, LaserRifle] = 1;
$ItemMax[marmor, EnergyRifle] = 1;
$ItemMax[marmor, TargetingLaser] = 0;
$ItemMax[marmor, MineAmmo] = 30;
$ItemMax[marmor, Grenade] = 60;
$ItemMax[marmor, Beacon] = 30;
$ItemMax[marmor, JailGun] = 1;// 0;
$ItemMax[marmor, PlasmaCannon] = 1;// 0;
$ItemMax[marmor, RepairRifle] = 1;
$ItemMax[marmor, Stinger] = 1;
$ItemMax[marmor, TankShredder] = 1;
$ItemMax[marmor, TankRPGLauncher] = 1;
$ItemMax[marmor, TRocketLauncher] = 1;
$ItemMax[marmor,HDiscLauncher]=1;

//--USW-
$ItemMax[marmor, TaserRifle] = 1;

$ItemMax[marmor, LiLFFB] = 1;
$ItemMax[marmor, LiLFFBAmmo] = 20;// 8;

$ItemMax[marmor, TaserTrtBPack] = 1;
$ItemMax[marmor, TaserTrtCPack] = 1;
$ItemMax[marmor, LaserTurretPack] = 1;
$ItemMax[marmor, RailTurret] = 1;// 0;
$ItemMax[marmor, ChaingunTurretPack] = 1;// 0;
$ItemMax[marmor, TurretPack] = 1;// 0;
$ItemMax[marmor, SeekerPack] = 1;// 0;
$ItemMax[marmor, SuicidePack] = 1;
$ItemMax[marmor, ChaingunTurretPack] = 1;


$ItemMax[marmor, lgaForceFieldPack] = 1;
$ItemMax[marmor, lgbForceFieldPack] = 1;
$ItemMax[marmor, medaForceFieldPack] = 1;
$ItemMax[marmor, medbForceFieldPack] = 1;
$ItemMax[marmor, medcForceFieldPack] = 1;
$ItemMax[marmor, ArbitorBoxPack] = 1;// 0;
$ItemMax[marmor, blastwall] = 1;// 0;
$ItemMax[marmor, EnergizerPack] = 1;
$ItemMax[marmor, JailCapPack] = 1;
$ItemMax[marmor, ForceFieldFloorPack] = 1;
$ItemMax[marmor, DeployableSolarPanel] = 1;
//--USW

$ItemMax[marmor, BulletAmmo] = 300;
$ItemMax[marmor, PlasmaAmmo] = 999;
$ItemMax[marmor, DiscAmmo] = 300;
$ItemMax[marmor, GrenadeAmmo] = 30;
$ItemMax[marmor, MortarAmmo] = 55;// 8;
$ItemMax[marmor, StingerAmmo] = 200;
$ItemMax[marmor, TankShredderAmmo] = 999;
$ItemMax[marmor, TankRPGAmmo] = 999;
$ItemMax[marmor, TRocketLauncherAmmo] = 999;
$ItemMax[marmor,DualDiscs]=350;

$ItemMax[marmor, EnergyPack] = 1;
$ItemMax[marmor, RepairPack] = 1;
$ItemMax[marmor, ShieldPack] = 1;
$ItemMax[marmor, SensorJammerPack] = 1;
$ItemMax[marmor, MotionSensorPack] = 1;
$ItemMax[marmor, PulseSensorPack] = 1;
$ItemMax[marmor, DeployableSensorJammerPack] = 1;
$ItemMax[marmor, CameraPack] = 1;
$ItemMax[marmor, TurretPack] = 1;
$ItemMax[marmor, AmmoPack] = 1;
$ItemMax[marmor, RepairKit] = 1;
$ItemMax[marmor, DeployableInvPack] = 1;
$ItemMax[marmor, DeployableAmmoPack] = 1;
$ItemMax[marmor, jailpack] = 1;// 0;
$ItemMax[marmor, HolePack] = 1;
$ItemMax[marmor, HoloPack] = 1;
$ItemMax[marmor, ShockFloorPack] = 1;
$ItemMax[marmor, ForceFieldDoorPack] = 1;

$MaxWeapons[marmor] = 10;

//----------------------------------------------------------------------------
// Heavy Armor
//----------------------------------------------------------------------------
$DamageScale[harmor, $LandingDamageType] = 1.0;
$DamageScale[harmor, $ImpactDamageType] = 1.0;
$DamageScale[harmor, $CrushDamageType] = 1.0;
$DamageScale[harmor, $BulletDamageType] = 0.6;
$DamageScale[harmor, $PlasmaDamageType] = 0.4;
$DamageScale[harmor, $EnergyDamageType] = 0.7;
$DamageScale[harmor, $ExplosionDamageType] = 0.6;
$DamageScale[harmor, $MissileDamageType] = 0.6;
$DamageScale[harmor, $DebrisDamageType] = 0.8;
$DamageScale[harmor, $ShrapnelDamageType] = 0.8;
$DamageScale[harmor, $LaserDamageType] = 0.6;
$DamageScale[harmor, $MortarDamageType] = 0.7;
$DamageScale[harmor, $BlasterDamageType] = 0.7;
$DamageScale[harmor, $ElectricityDamageType] = 1.0;
$DamageScale[harmor, $MineDamageType] = 0.8;
$DamageScale[harmor, $LiLRocketDamageType] = 1.0;
$DamageScale[harmor, $EMPDamageType] = 1.0;
$DamageScale[harmor, $LiLPOOmkiiDamageType] = 1.0;
$DamageScale[harmor, $SmokeDamageType] = 1.0;
$DamageScale[harmor, $MiniELFDamageType] = 1.0;
$DamageScale[harmor, $beamofpainDamageType] = 1.0;
$DamageScale[harmor, $SniperDamageType] = 1.0;
$DamageScale[harmor, $FlashDamageType] = 1.0;
$DamageScale[harmor, $PlasmaCannonDamageType] = 1.5;

$ItemMax[harmor, Blaster] = 1;
$ItemMax[harmor, Chaingun] = 1;
$ItemMax[harmor, Disclauncher] = 1;
$ItemMax[harmor, GrenadeLauncher] = 1;
$ItemMax[harmor, Mortar] = 1;
$ItemMax[harmor, PlasmaGun] = 1;
$ItemMax[harmor, LaserRifle] = 1;
$ItemMax[harmor, EnergyRifle] = 1;
$ItemMax[harmor, TargetingLaser] = 0;
$ItemMax[harmor, MineAmmo] = 18;
$ItemMax[harmor, Grenade] = 8;
$ItemMax[harmor, Beacon] = 10;
$ItemMax[harmor, JailGun] = 1;// 0;
$ItemMax[harmor, PlasmaCannon] = 1;// 0;
$ItemMax[harmor, RepairRifle] = 1;
$ItemMax[harmor, Stinger] = 1;
$ItemMax[harmor, TankShredder] = 1;
$ItemMax[harmor, TankRPGLauncher] = 1;
$ItemMax[harmor, TRocketLauncher] = 1;
$ItemMax[harmor,HDiscLauncher]=1;

//--USW-
$ItemMax[harmor, TaserRifle] = 1;

$ItemMax[harmor, LiLFFB] = 1;
$ItemMax[harmor, LiLFFBAmmo] = 50;//8;

$ItemMax[harmor, TaserTrtBPack] = 1;
$ItemMax[harmor, TaserTrtCPack] = 1;
$ItemMax[harmor, LaserTurretPack] = 1;
$ItemMax[harmor, RailTurret] = 1;// 0;
$ItemMax[harmor, ChaingunTurretPack] = 1;// 0;
$ItemMax[harmor, TurretPack] = 1;// 0;
$ItemMax[harmor, SeekerPack] = 1;// 0;
$ItemMax[harmor, SuicidePack] = 1;
$ItemMax[harmor, ChaingunTurretPack] = 1;

$ItemMax[harmor, lgaForceFieldPack] = 1;
$ItemMax[harmor, lgbForceFieldPack] = 1;
$ItemMax[harmor, medaForceFieldPack] = 1;
$ItemMax[harmor, medbForceFieldPack] = 1;
$ItemMax[harmor, medcForceFieldPack] = 1;
$ItemMax[harmor, ArbitorBoxPack] = 1;// 0;
$ItemMax[harmor, blastwall] = 1;// 0;
$ItemMax[harmor, EnergizerPack] = 1;
$ItemMax[harmor, JailCapPack] = 1;
$ItemMax[harmor, ForceFieldFloorPack] = 1;
$ItemMax[harmor, DeployableSolarPanel] = 1;
//--USW

$ItemMax[harmor, BulletAmmo] = 100;
$ItemMax[harmor, PlasmaAmmo] = 500;
$ItemMax[harmor, DiscAmmo] = 100;
$ItemMax[harmor, GrenadeAmmo] = 20;
$ItemMax[harmor, MortarAmmo] = 55;// 8;
$ItemMax[harmor, StingerAmmo] = 200;
$ItemMax[harmor, TankShredderAmmo] = 999;
$ItemMax[harmor, TankRPGAmmo] = 999;
$ItemMax[harmor, TRocketLauncherAmmo] = 999;
$ItemMax[harmor,DualDiscs]=350;

$ItemMax[harmor, EnergyPack] = 1;
$ItemMax[harmor, RepairPack] = 1;
$ItemMax[harmor, ShieldPack] = 1;
$ItemMax[harmor, SensorJammerPack] = 1;
$ItemMax[harmor, MotionSensorPack] = 1;
$ItemMax[harmor, PulseSensorPack] = 1;
$ItemMax[harmor, DeployableSensorJammerPack] = 1;
$ItemMax[harmor, CameraPack] = 1;
$ItemMax[harmor, TurretPack] = 1;
$ItemMax[harmor, AmmoPack] = 1;
$ItemMax[harmor, RepairKit] = 1;
$ItemMax[harmor, DeployableInvPack] = 1;
$ItemMax[harmor, DeployableAmmoPack] = 1;
$ItemMax[harmor, jailpack] = 1;// 0;
$ItemMax[harmor, HolePack] = 1;
$ItemMax[harmor, HoloPack] = 1;
$ItemMax[harmor, ShockFloorPack] = 1;
$ItemMax[harmor, ForceFieldDoorPack] = 1;

$MaxWeapons[harmor] = 8;

//----------------------------------------------------------------------------
// light Female Armor
//----------------------------------------------------------------------------
$DamageScale[lfemale, $LandingDamageType] = 1.0;
$DamageScale[lfemale, $ImpactDamageType] = 1.0;	
$DamageScale[lfemale, $CrushDamageType] = 1.0;	
$DamageScale[lfemale, $BulletDamageType] = 1.2;
$DamageScale[lfemale, $PlasmaDamageType] = 1.0;
$DamageScale[lfemale, $EnergyDamageType] = 1.3;
$DamageScale[lfemale, $ExplosionDamageType] = 1.0;
$DamageScale[lfemale, $MissileDamageType] = 1.0;
$DamageScale[lfemale, $ShrapnelDamageType] = 1.2;
$DamageScale[lfemale, $DebrisDamageType] = 1.2;
$DamageScale[lfemale, $LaserDamageType] = 1.0;
$DamageScale[lfemale, $MortarDamageType] = 1.3;
$DamageScale[lfemale, $BlasterDamageType] = 1.3;
$DamageScale[lfemale, $ElectricityDamageType] = 1.0;
$DamageScale[lfemale, $MineDamageType] = 1.2;
$DamageScale[lfemale, $LiLRocketDamageType] = 1.0;
$DamageScale[lfemale, $EMPDamageType] = 1.0;
$DamageScale[lfemale, $LiLPOOmkiiDamageType] = 1.0;
$DamageScale[lfemale, $SmokeDamageType] = 1.0;
$DamageScale[lfemale, $MiniELFDamageType] = 1.0;
$DamageScale[lfemale, $beamofpainDamageType] = 1.0;
$DamageScale[lfemale, $SniperDamageType] = 1.0;
$DamageScale[lfemale, $FlashDamageType] = 1.0;
$DamageScale[lfemale, $PlasmaCannonDamageType] = 1.5;

$ItemMax[lfemale, Blaster] = 1;
$ItemMax[lfemale, Chaingun] = 1;
$ItemMax[lfemale, Disclauncher] = 1;
$ItemMax[lfemale, GrenadeLauncher] = 1;
$ItemMax[lfemale, Mortar] = 1;
$ItemMax[lfemale, PlasmaGun] = 1;
$ItemMax[lfemale, LaserRifle] = 1;
$ItemMax[lfemale, EnergyRifle] = 1;
$ItemMax[lfemale, TargetingLaser] = 0;
$ItemMax[lfemale, MineAmmo] = 35;
$ItemMax[lfemale, Grenade] = 35;
$ItemMax[lfemale, Beacon] = 35;
$ItemMax[lfemale, JailGun] = 1;// 0;
$ItemMax[lfemale, PlasmaCannon] = 1;// 0;
$ItemMax[lfemale, RepairRifle] = 1;
$ItemMax[lfemale, Stinger] = 1;
$ItemMax[lfemale, TankShredder] = 1;
$ItemMax[lfemale, TankRPGLauncher] = 1;
$ItemMax[lfemale, TRocketLauncher] = 1;
$ItemMax[lfemale,HDiscLauncher]=1;

//--USW-
$ItemMax[lfemale, TaserRifle] = 1;

$ItemMax[lfemale, LiLFFB] = 1;
$ItemMax[lfemale, LiLFFBAmmo] = 8;

$ItemMax[lfemale, TaserTrtBPack] = 1;
$ItemMax[lfemale, TaserTrtCPack] = 1;
$ItemMax[lfemale, LaserTurretPack] = 1;
$ItemMax[lfemale, RailTurret] = 1;// 0;
$ItemMax[lfemale, ChaingunTurretPack] = 1;// 0;
$ItemMax[lfemale, TurretPack] = 1;// 0;
$ItemMax[lfemale, SeekerPack] = 1;// 0;
$ItemMax[lfemale, SuicidePack] = 1;
$ItemMax[lfemale, ChaingunTurretPack] = 1;

$ItemMax[lfemale, lgaForceFieldPack] = 1;
$ItemMax[lfemale, lgbForceFieldPack] = 1;
$ItemMax[lfemale, medaForceFieldPack] = 1;
$ItemMax[lfemale, medbForceFieldPack] = 1;
$ItemMax[lfemale, medcForceFieldPack] = 1;
$ItemMax[lfemale, ArbitorBoxPack] = 1;// 0;
$ItemMax[lfemale, blastwall] = 1;// 0;
$ItemMax[lfemale, EnergizerPack] = 1;
$ItemMax[lfemale, JailCapPack] = 1;
$ItemMax[lfemale, ForceFieldFloorPack] = 1;
$ItemMax[lfemale, DeployableSolarPanel] = 1;
//--USW

$ItemMax[lfemale, BulletAmmo] = 999;
$ItemMax[lfemale, PlasmaAmmo] = 999;
$ItemMax[lfemale, DiscAmmo] = 250;
$ItemMax[lfemale, GrenadeAmmo] = 20;
$ItemMax[lfemale, MortarAmmo] = 18;
$ItemMax[lfemale, StingerAmmo] = 200;
$ItemMax[lfemale, TankShredderAmmo] = 999;
$ItemMax[lfemale, TankRPGAmmo] = 999;
$ItemMax[lfemale, TRocketLauncherAmmo] = 999;
$ItemMax[lfemale,DualDiscs]=350;

$ItemMax[lfemale, EnergyPack] = 1;
$ItemMax[lfemale, RepairPack] = 1;
$ItemMax[lfemale, ShieldPack] = 1;
$ItemMax[lfemale, SensorJammerPack] = 1;
$ItemMax[lfemale, MotionSensorPack] = 1;
$ItemMax[lfemale, PulseSensorPack] = 1;
$ItemMax[lfemale, DeployableSensorJammerPack] = 1;
$ItemMax[lfemale, CameraPack] = 1;
$ItemMax[lfemale, TurretPack] = 1;
$ItemMax[lfemale, AmmoPack] = 1;
$ItemMax[lfemale, RepairKit] = 1;
$ItemMax[lfemale, DeployableInvPack] = 1;
$ItemMax[lfemale, DeployableAmmoPack] = 1;
$ItemMax[lfemale, jailpack] = 1;// 0;
$ItemMax[lfemale, HolePack] = 1;
$ItemMax[lfemale, HoloPack] = 1;
$ItemMax[lfemale, ShockFloorPack] = 1;
$ItemMax[lfemale, ForceFieldDoorPack] = 1;

$MaxWeapons[lfemale] = 15;

//----------------------------------------------------------------------------
// Medium Female Armor
//----------------------------------------------------------------------------
$DamageScale[mfemale, $LandingDamageType] = 0.7;
$DamageScale[mfemale, $ImpactDamageType] = 0.7;
$DamageScale[mfemale, $CrushDamageType] = 0.7;
$DamageScale[mfemale, $BulletDamageType] = 0.7;
$DamageScale[mfemale, $EnergyDamageType] = 0.7;
$DamageScale[mfemale, $PlasmaDamageType] = 0.6;
$DamageScale[mfemale, $ExplosionDamageType] = 0.7;
$DamageScale[mfemale, $MissileDamageType] = 0.7;
$DamageScale[mfemale, $ShrapnelDamageType] = 0.7;
$DamageScale[mfemale, $DebrisDamageType] = 0.7;
$DamageScale[mfemale, $LaserDamageType] = 0.7;
$DamageScale[mfemale, $MortarDamageType] = 0.7;
$DamageScale[mfemale, $BlasterDamageType] = 0.7;
$DamageScale[mfemale, $ElectricityDamageType] = 0.7;
$DamageScale[mfemale, $MineDamageType] = 0.7;
$DamageScale[mfemale, $LiLRocketDamageType] = 1.0;
$DamageScale[mfemale, $EMPDamageType] = 1.0;
$DamageScale[mfemale, $LiLPOOmkiiDamageType] = 1.0;
$DamageScale[mfemale, $SmokeDamageType] = 1.0;
$DamageScale[mfemale, $MiniELFDamageType] = 1.0;
$DamageScale[mfemale, $beamofpainDamageType] = 1.0;
$DamageScale[mfemale, $SniperDamageType] = 1.0;
$DamageScale[mfemale, $FlashDamageType] = 1.0;
$DamageScale[mfemale, $PlasmaCannonDamageType] = 1.5;

$ItemMax[mfemale, Blaster] = 1;
$ItemMax[mfemale, Chaingun] = 1;
$ItemMax[mfemale, Disclauncher] = 1;
$ItemMax[mfemale, GrenadeLauncher] = 1;
$ItemMax[mfemale, Mortar] = 1;
$ItemMax[mfemale, PlasmaGun] = 1;
$ItemMax[mfemale, LaserRifle] = 1;
$ItemMax[mfemale, EnergyRifle] = 1;
$ItemMax[mfemale, TargetingLaser] = 0;
$ItemMax[mfemale, MineAmmo] = 8;
$ItemMax[mfemale, Grenade] = 8;
$ItemMax[mfemale, Beacon] = 30;
$ItemMax[mfemale, JailGun] = 1;// 0;
$ItemMax[mfemale, PlasmaCannon] = 1;// 0;
$ItemMax[mfemale, RepairRifle] = 1;
$ItemMax[mfemale, Stinger] = 1;
$ItemMax[mfemale, TankShredder] = 1;
$ItemMax[mfemale, TankRPGLauncher] = 1;
$ItemMax[mfemale, TRocketLauncher] = 1;
$ItemMax[mfemale,HDiscLauncher]=1;

//--USW-
$ItemMax[mfemale, TaserRifle] = 1;

$ItemMax[mfemale, LiLFFB] = 1;
$ItemMax[mfemale, LiLFFBAmmo] = 8;

$ItemMax[mfemale, TaserTrtBPack] = 1;
$ItemMax[mfemale, TaserTrtCPack] = 1;
$ItemMax[mfemale, LaserTurretPack] = 1;
$ItemMax[mfemale, RailTurret] = 1;// 0;
$ItemMax[mfemale, ChaingunTurretPack] = 1;
$ItemMax[mfemale, TurretPack] = 1;// 0;
$ItemMax[mfemale, SeekerPack] = 1;// 0;
$ItemMax[mfemale, EnergizerPack] = 1;
$ItemMax[mfemale, JailCapPack] = 1;
$ItemMax[mfemale, SuicidePack] = 1;
$ItemMax[mfemale, ChaingunTurretPack] = 1;
//--USW

$ItemMax[mfemale, BulletAmmo] = 500;
$ItemMax[mfemale, PlasmaAmmo] = 999;
$ItemMax[mfemale, DiscAmmo] = 500;
$ItemMax[mfemale, GrenadeAmmo] = 20;
$ItemMax[mfemale, MortarAmmo] = 8;
$ItemMax[mfemale, StingerAmmo] = 200;
$ItemMax[mfemale, TankShredderAmmo] = 999;
$ItemMax[mfemale, TankRPGAmmo] = 999;
$ItemMax[mfemale, TRocketLauncherAmmo] = 999;
$ItemMax[mfemale,DualDiscs]=350;

$ItemMax[mfemale, EnergyPack] = 1;
$ItemMax[mfemale, RepairPack] = 1;
$ItemMax[mfemale, ShieldPack] = 1;
$ItemMax[mfemale, SensorJammerPack] = 1;
$ItemMax[mfemale, MotionSensorPack] = 1;
$ItemMax[mfemale, PulseSensorPack] = 1;
$ItemMax[mfemale, DeployableSensorJammerPack] = 1;
$ItemMax[mfemale, CameraPack] = 1;
$ItemMax[mfemale, TurretPack] = 1;
$ItemMax[mfemale, AmmoPack] = 1;
$ItemMax[mfemale, RepairKit] = 1;
$ItemMax[mfemale, DeployableInvPack] = 1;
$ItemMax[mfemale, DeployableAmmoPack] = 1;
$ItemMax[mfemale, jailpack] = 1;// 0;
$ItemMax[mfemale, HolePack] = 1;
$ItemMax[mfemale, HoloPack] = 1;
$ItemMax[mfemale, ShockFloorPack] = 1;
$ItemMax[mfemale, ForceFieldDoorPack] = 1;

$ItemMax[mfemale, lgaForceFieldPack] = 1;
$ItemMax[mfemale, lgbForceFieldPack] = 1;
$ItemMax[mfemale, medaForceFieldPack] = 1;
$ItemMax[mfemale, medbForceFieldPack] = 1;
$ItemMax[mfemale, medcForceFieldPack] = 1;
$ItemMax[mfemale, ArbitorBoxPack] = 1;// 0;
$ItemMax[mfemale, blastwall] = 1;// 0;
$ItemMax[mfemale, ForceFieldFloorPack] = 1;
$ItemMax[mfemale, DeployableSolarPanel] = 1;


$MaxWeapons[mfemale] = 10;

//------------------------------------------------------------------

//-------------------------------USW-------------------------------------------

$ItemMax[larmor, ExSmScreenAbility] = 1;
$ItemMax[larmor, ExSmScreenAbilityAmmo] = 60;
$ItemMax[larmor, SmScreenAbility] = 1;
$ItemMax[larmor, SmScreenAbilityAmmo] = 125;
$ItemMax[larmor, FireballAbility] = 1;
$ItemMax[larmor, FireballAbilityAmmo] = 275;
$ItemMax[larmor, FireScreenAbility] = 1;
$ItemMax[larmor, FireScreenAbilityAmmo] = 160;

$ItemMax[marmor, ExSmScreenAbility] = 1;
$ItemMax[marmor, ExSmScreenAbilityAmmo] = 60;
$ItemMax[marmor, SmScreenAbility] = 1;
$ItemMax[marmor, SmScreenAbilityAmmo] = 125;
$ItemMax[marmor, FireballAbility] = 1;
$ItemMax[marmor, FireballAbilityAmmo] = 275;
$ItemMax[marmor, FireScreenAbility] = 1;
$ItemMax[marmor, FireScreenAbilityAmmo] = 160;

$ItemMax[harmor, ExSmScreenAbility] = 1;
$ItemMax[harmor, ExSmScreenAbilityAmmo] = 60;
$ItemMax[harmor, SmScreenAbility] = 1;
$ItemMax[harmor, SmScreenAbilityAmmo] = 125;
$ItemMax[harmor, FireballAbility] = 1;
$ItemMax[harmor, FireballAbilityAmmo] = 275;
$ItemMax[harmor, FireScreenAbility] = 1;
$ItemMax[harmor, FireScreenAbilityAmmo] = 160;

$ItemMax[lfemale, ExSmScreenAbility] = 1;
$ItemMax[lfemale, ExSmScreenAbilityAmmo] = 60;
$ItemMax[lfemale, SmScreenAbility] = 1;
$ItemMax[lfemale, SmScreenAbilityAmmo] = 125;
$ItemMax[lfemale, FireballAbility] = 1;
$ItemMax[lfemale, FireballAbilityAmmo] = 275;
$ItemMax[lfemale, FireScreenAbility] = 1;
$ItemMax[lfemale, FireScreenAbilityAmmo] = 160;

$ItemMax[mfemale, ExSmScreenAbility] = 1;
$ItemMax[mfemale, ExSmScreenAbilityAmmo] = 60;
$ItemMax[mfemale, SmScreenAbility] = 1;
$ItemMax[mfemale, SmScreenAbilityAmmo] = 125;
$ItemMax[mfemale, FireballAbility] = 1;
$ItemMax[mfemale, FireballAbilityAmmo] = 275;
$ItemMax[mfemale, FireScreenAbility] = 1;
$ItemMax[mfemale, FireScreenAbilityAmmo] = 160;

$ItemMax[larmor, JailGun] = 1;// 0;
$ItemMax[marmor, JailGun] = 1;// 0;
$ItemMax[harmor, JailGun] = 1;// 0;
$ItemMax[lfemale, JailGun] = 1;// 0;
$ItemMax[mfemale, JailGun] = 1;// 0;

$ItemMax[larmor, PlasmaCannon] = 1;// 0;
$ItemMax[marmor, PlasmaCannon] = 1;// 0;
$ItemMax[harmor, PlasmaCannon] = 1;// 0;
$ItemMax[lfemale, PlasmaCannon] = 1;// 0;
$ItemMax[mfemale, PlasmaCannon] = 1;// 0;

$ItemMax[larmor,HDiscLauncher]=1;
$ItemMax[marmor,HDiscLauncher]=1;
$ItemMax[harmor,HDiscLauncher]=1;
$ItemMax[lfemale,HDiscLauncher]=1;
$ItemMax[mfemale,HDiscLauncher]=1;

//CloakingDevice
$ItemMax[larmor, CloakingDevice] = 1;
$ItemMax[marmor, CloakingDevice] = 1;
$ItemMax[harmor, CloakingDevice] = 1;
$ItemMax[lfemale, CloakingDevice] = 1;
$ItemMax[mfemale, CloakingDevice] = 1;

$ItemMax[larmor, blastwall] = 1;// 0;
$ItemMax[marmor, blastwall] = 1;// 0;
$ItemMax[harmor, blastwall] = 1;// 0;
$ItemMax[lfemale, blastwall] = 1;// 0;
$ItemMax[mfemale, blastwall] = 1;// 0;

$ItemMax[larmor, LaserTurretBPack] = 1;
$ItemMax[marmor, LaserTurretBPack] = 1;
$ItemMax[harmor, LaserTurretBPack] = 1;
$ItemMax[lfemale, LaserTurretBPack] = 1;
$ItemMax[mfemale, LaserTurretBPack] = 1;

$ItemMax[larmor, MiniFlakTurretPack] = 1;
$ItemMax[marmor, MiniFlakTurretPack] = 1;
$ItemMax[harmor, MiniFlakTurretPack] = 1;
$ItemMax[lfemale, MiniFlakTurretPack] = 1;
$ItemMax[mfemale, MiniFlakTurretPack] = 1;

$ItemMax[larmor, MiniSAMTurretPack] = 1;
$ItemMax[marmor, MiniSAMTurretPack] = 1;
$ItemMax[harmor, MiniSAMTurretPack] = 1;
$ItemMax[lfemale, MiniSAMTurretPack] = 1;
$ItemMax[mfemale, MiniSAMTurretPack] = 1;

$ItemMax[larmor, MiniELFTurretPack] = 1;
$ItemMax[marmor, MiniELFTurretPack] = 1;
$ItemMax[harmor, MiniELFTurretPack] = 1;
$ItemMax[lfemale, MiniELFTurretPack] = 1;
$ItemMax[mfemale, MiniELFTurretPack] = 1;

$ItemMax[larmor, MiniSmokeTurretPack] = 1;
$ItemMax[marmor, MiniSmokeTurretPack] = 1;
$ItemMax[harmor, MiniSmokeTurretPack] = 1;
$ItemMax[lfemale, MiniSmokeTurretPack] = 1;
$ItemMax[mfemale, MiniSmokeTurretPack] = 1;

$ItemMax[larmor, RailTurret] = 1;// 0; 
$ItemMax[marmor, RailTurret] = 1;// 0; 
$ItemMax[harmor, RailTurret] = 1; 
$ItemMax[lfemale, RailTurret] = 1;// 0;
$ItemMax[mfemale, RailTurret] = 1;// 0;

$ItemMax[larmor, ChaingunTurretPack] = 1;// 0;
$ItemMax[marmor, ChaingunTurretPack] = 1;// 0;
$ItemMax[harmor, ChaingunTurretPack] = 1;// 0;
$ItemMax[lfemale, ChaingunTurretPack] = 1;
$ItemMax[mfemale, ChaingunTurretPack] = 1;

$ItemMax[larmor, ChaingunTurretPack] = 1;
$ItemMax[marmor, ChaingunTurretPack] = 1;
$ItemMax[harmor, ChaingunTurretPack] = 1;
$ItemMax[lfemale, ChaingunTurretPack] = 1;
$ItemMax[mfemale, ChaingunTurretPack] = 1;

$ItemMax[larmor, TurretPack] = 1;// 0;
$ItemMax[marmor, TurretPack] = 1;// 0;
$ItemMax[harmor, TurretPack] = 1;// 0;
$ItemMax[lfemale, TurretPack] = 1;// 0;
$ItemMax[mfemale, TurretPack] = 1;// 0;

$ItemMax[larmor, SeekerPack] = 1;// 0;
$ItemMax[marmor, SeekerPack] = 1;// 0;
$ItemMax[harmor, SeekerPack] = 1;// 0;
$ItemMax[lfemale, SeekerPack] = 1;// 0;
$ItemMax[mfemale, SeekerPack] = 1;// 0;

$ItemMax[larmor, SuicidePack] = 1;
$ItemMax[marmor, SuicidePack] = 1;
$ItemMax[harmor, SuicidePack] = 1;
$ItemMax[lfemale, SuicidePack] = 1;
$ItemMax[mfemale, SuicidePack] = 1;

$ItemMax[larmor, jailpack] = 1;// 0;
$ItemMax[marmor, jailpack] = 1;// 0;
$ItemMax[harmor, jailpack] = 1;// 0;
$ItemMax[lfemale, jailpack] = 1;// 0;
$ItemMax[mfemale, jailpack] = 1;// 0;

$ItemMax[larmor, ArbitorBoxPack] = 1;// 0;
$ItemMax[marmor, ArbitorBoxPack] = 1;// 0;
$ItemMax[harmor, ArbitorBoxPack] = 1;// 0;
$ItemMax[lfemale, ArbitorBoxPack] = 1;// 0;
$ItemMax[mfemale, ArbitorBoxPack] = 1;// 0;

$ItemMax[larmor, JailCapPack] = 1;
$ItemMax[marmor, JailCapPack] = 1;
$ItemMax[harmor, JailCapPack] = 1;
$ItemMax[lfemale, JailCapPack] = 1;
$ItemMax[mfemale, JailCapPack] = 1;

$ItemMax[larmor, HoloPack] = 1;
$ItemMax[marmor, HoloPack] = 1;
$ItemMax[harmor, HoloPack] = 1;
$ItemMax[lfemale, HoloPack] = 1;
$ItemMax[mfemale, HoloPack] = 1;

$ItemMax[larmor, HolePack] = 1;
$ItemMax[marmor, HolePack] = 1;
$ItemMax[harmor, HolePack] = 1;
$ItemMax[lfemale, HolePack] = 1;
$ItemMax[mfemale, HolePack] = 1;

$ItemMax[larmor, TeleportPack] = 1;
$ItemMax[marmor, TeleportPack] = 1;
$ItemMax[harmor, TeleportPack] = 1;
$ItemMax[lfemale, TeleportPack] = 1;
$ItemMax[mfemale, TeleportPack] = 1;

$ItemMax[larmor, LiLPOOmkii] = 1;
$ItemMax[marmor, LiLPOOmkii] = 1;
$ItemMax[harmor, LiLPOOmkii] = 1;
$ItemMax[lfemale, LiLPOOmkii] = 1;
$ItemMax[mfemale, LiLPOOmkii] = 1;

$ItemMax[larmor, LiLPOOmkiiAmmo] = 999;
$ItemMax[marmor, LiLPOOmkiiAmmo] = 999;
$ItemMax[harmor, LiLPOOmkiiAmmo] = 999;
$ItemMax[lfemale, LiLPOOmkiiAmmo] = 999;
$ItemMax[mfemale, LiLPOOmkiiAmmo] = 999;

$ItemMax[larmor, LiLPOOmki] = 1;
$ItemMax[marmor, LiLPOOmki] = 1;
$ItemMax[harmor, LiLPOOmki] = 1;
$ItemMax[lfemale, LiLPOOmki] = 1;
$ItemMax[mfemale, LiLPOOmki] = 1;

$ItemMax[larmor, LiLPOOmkiAmmo] = 999;
$ItemMax[marmor, LiLPOOmkiAmmo] = 999;
$ItemMax[harmor, LiLPOOmkiAmmo] = 999;
$ItemMax[lfemale, LiLPOOmkiAmmo] = 999;
$ItemMax[mfemale, LiLPOOmkiAmmo] = 999;

$ItemMax[larmor, LiLRocketLauncher] = 1;
$ItemMax[marmor, LiLRocketLauncher] = 1;
$ItemMax[harmor, LiLRocketLauncher] = 1;
$ItemMax[lfemale, LiLRocketLauncher] = 1;
$ItemMax[mfemale, LiLRocketLauncher] = 1;

$ItemMax[larmor, LiLRocketLauncherAmmo] = 80;
$ItemMax[marmor, LiLRocketLauncherAmmo] = 80;
$ItemMax[harmor, LiLRocketLauncherAmmo] = 100;
$ItemMax[lfemale, LiLRocketLauncherAmmo] = 80;
$ItemMax[mfemale, LiLRocketLauncherAmmo] = 100;

$ItemMax[larmor, LiLEMPRocketLauncher] = 1;
$ItemMax[marmor, LiLEMPRocketLauncher] = 1;
$ItemMax[harmor, LiLEMPRocketLauncher] = 1;
$ItemMax[lfemale, LiLEMPRocketLauncher] = 1;
$ItemMax[mfemale, LiLEMPRocketLauncher] = 1;

$ItemMax[larmor, LiLEMPRocketLauncherAmmo] = 80;
$ItemMax[marmor, LiLEMPRocketLauncherAmmo] = 80;
$ItemMax[harmor, LiLEMPRocketLauncherAmmo] = 100;
$ItemMax[lfemale, LiLEMPRocketLauncherAmmo] = 80;
$ItemMax[mfemale, LiLEMPRocketLauncherAmmo] = 100;

$ItemMax[larmor, Stinger] = 1;
$ItemMax[larmor, StingerAmmo] = 200;
$ItemMax[marmor, Stinger] = 1;
$ItemMax[marmor, StingerAmmo] = 200;
$ItemMax[harmor, Stinger] = 1;
$ItemMax[harmor, StingerAmmo] = 200;
$ItemMax[lfemale, Stinger] = 1;
$ItemMax[lfemale, StingerAmmo] = 200;
$ItemMax[mfemale, Stinger] = 1;
$ItemMax[mfemale, StingerAmmo] = 200;

$ItemMax[larmor, TankShredder] = 1;
$ItemMax[larmor, TankShredderAmmo] = 999;
$ItemMax[marmor, TankShredder] = 1;
$ItemMax[marmor, TankShredderAmmo] = 999;
$ItemMax[harmor, TankShredder] = 1;
$ItemMax[harmor, TankShredderAmmo] = 999;
$ItemMax[lfemale, TankShredder] = 1;
$ItemMax[lfemale, TankShredderAmmo] = 999;
$ItemMax[mfemale, TankShredder] = 1;
$ItemMax[mfemale, TankShredderAmmo] = 999;

$ItemMax[larmor, TankRPGLauncher] = 1;
$ItemMax[larmor, TankRPGAmmo] = 999;
$ItemMax[marmor, TankRPGLauncher] = 1;
$ItemMax[marmor, TankRPGAmmo] = 999;
$ItemMax[harmor, TankRPGLauncher] = 1;
$ItemMax[harmor, TankRPGAmmo] = 999;
$ItemMax[lfemale, TankRPGLauncher] = 1;
$ItemMax[lfemale, TankRPGAmmo] = 999;
$ItemMax[mfemale, TankRPGLauncher] = 1;
$ItemMax[mfemale, TankRPGAmmo] = 999;

$ItemMax[larmor, TRocketLauncher] = 1;
$ItemMax[larmor, TRocketLauncherAmmo] = 999;
$ItemMax[marmor, TRocketLauncher] = 1;
$ItemMax[marmor, TRocketLauncherAmmo] = 999;
$ItemMax[harmor, TRocketLauncher] = 1;
$ItemMax[harmor, TRocketLauncherAmmo] = 999;
$ItemMax[lfemale, TRocketLauncher] = 1;
$ItemMax[lfemale, TRocketLauncherAmmo] = 999;
$ItemMax[mfemale, TRocketLauncher] = 1;
$ItemMax[lfemale, TRocketLauncherAmmo] = 999;

$ItemMax[larmor, DeployableSolarPanel] = 1;
$ItemMax[marmor, DeployableSolarPanel] = 1;
$ItemMax[harmor, DeployableSolarPanel] = 1;
$ItemMax[lfemale, DeployableSolarPanel] = 1;
$ItemMax[mfemale, DeployableSolarPanel] = 1;

$ItemMax[larmor, BeamOfPain] = 1;
$ItemMax[marmor, BeamOfPain] = 1;
$ItemMax[harmor, BeamOfPain] = 1;
$ItemMax[lfemale, BeamOfPain] = 1;
$ItemMax[mfemale, BeamOfPain] = 1;

$ItemMax[larmor, SpellAbility] = 1;
$ItemMax[marmor, SpellAbility] = 1;
$ItemMax[harmor, SpellAbility] = 1;
$ItemMax[lfemale, SpellAbility] = 1;
$ItemMax[mfemale, SpellAbility] = 1;

$ItemMax[larmor, SpellAbilityAmmo] = 500;
$ItemMax[marmor, SpellAbilityAmmo] = 500;
$ItemMax[harmor, SpellAbilityAmmo] = 500;
$ItemMax[lfemale, SpellAbilityAmmo] = 500;
$ItemMax[mfemale, SpellAbilityAmmo] = 500;

$ItemMax[larmor, cactuspack] = 1;
$ItemMax[marmor, cactuspack] = 1;
$ItemMax[harmor, cactuspack] = 1;
$ItemMax[lfemale, cactuspack] = 1;
$ItemMax[mfemale, cactuspack] = 1;

$ItemMax[larmor, FlashGrenade] = 35;
$ItemMax[marmor, FlashGrenade] = 35;
$ItemMax[harmor, FlashGrenade] = 35;
$ItemMax[lfemale, FlashGrenade] = 35;
$ItemMax[mfemale, FlashGrenade] = 35;

$ItemMax[larmor, LiLBoostammo] = 35;
$ItemMax[marmor, LiLBoostammo] = 35;
$ItemMax[harmor, LiLBoostammo] = 35;
$ItemMax[lfemale, LiLBoostammo] = 35;
$ItemMax[mfemale, LiLBoostammo] = 35;

$ItemMax[larmor, RadiusMineAmmo] = 1;
$ItemMax[marmor, RadiusMineAmmo] = 1;
$ItemMax[harmor, RadiusMineAmmo] = 1;
$ItemMax[lfemale, RadiusMineAmmo] = 1;
$ItemMax[mfemale, RadiusMineAmmo] = 1;

$ItemMax[larmor, USWGasAttackAmmo] = 35;
$ItemMax[marmor, USWGasAttackAmmo] = 35;
$ItemMax[harmor, USWGasAttackAmmo] = 35;
$ItemMax[lfemale, USWGasAttackAmmo] = 35;
$ItemMax[mfemale, USWGasAttackAmmo] = 35;
//-----------------------------USW----------------------------------------


// light armor data:
//------------------------------------------------------------------

DamageSkinData armorDamageSkins
{
   bmpName[0] = "dskin1_armor";
   bmpName[1] = "dskin2_armor";
   bmpName[2] = "dskin3_armor";
   bmpName[3] = "dskin4_armor";
   bmpName[4] = "dskin5_armor";
   bmpName[5] = "dskin6_armor";
   bmpName[6] = "dskin7_armor";
   bmpName[7] = "dskin8_armor";
   bmpName[8] = "dskin9_armor";
   bmpName[9] = "dskin10_armor";
};

PlayerData larmor
{
   className = "Armor";
   shapeFile = "larmor";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";
   canCrouch = true;

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 32;
   minJetEnergy = 1;
   jetForce = 436;
   jetEnergyDrain = 0.1;

	maxDamage = 0.66;
   maxForwardSpeed = 13;
   maxBackwardSpeed = 13;
   maxSideSpeed = 10;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 500;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, direction
	// firstPerson, chaseCam, thirdPerson, signalThread
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 


    // celebration animations:
   animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
 
    // taunt animations:
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
 
    // poses:
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;
   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.6666;
   boxCrouchTorsoPercentage = 0.3333;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium Armor data:
//------------------------------------------------------------------

PlayerData marmor
{
   className = "Armor";
   shapeFile = "marmor";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   canCrouch = false;
   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 32;
   minJetEnergy = 1;
   jetForce = 436;
   jetEnergyDrain = 0.1;

	maxDamage = 1.0;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 11;
   maxSideSpeed = 11;
   groundForce = 40 * 9;
   mass = 11;
   groundTraction = 3.0;
	
	maxEnergy = 500;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.83;
   boxNormalTorsoPercentage = 0.49;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Heavy Armor data:
//------------------------------------------------------------------

PlayerData harmor
{
   className = "Armor";
   shapeFile = "harmor";
   flameShapeName = "hflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 13;
   minJetEnergy = 1;
   jetForce = 436;
   jetEnergyDrain = 0.1;

	maxDamage = 2.0;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 11;
   maxSideSpeed = 11;
   groundForce = 40 * 9;
   groundTraction = 3;
   mass = 11;
	maxEnergy = 100;
   drag = 1.0;
   density = 2.5;
   canCrouch = false;

	minDamageSpeed = 25;
	damageScale = 0.006;

   jumpImpulse = 150;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetHeavy;

   rFootSounds = 
   {
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRHard,
     SoundHFootRSnow,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft,
     SoundHFootRSoft
  }; 
   lFootSounds =
   {
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLHard,
      SoundHFootLSnow,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft,
      SoundHFootLSoft
   };

   footPrints = { 4, 5 };

   boxWidth = 0.8;
   boxDepth = 0.8;
   boxNormalHeight = 2.6;

   boxNormalHeadPercentage  = 0.70;
   boxNormalTorsoPercentage = 0.45;

   boxHeadLeftPercentage  = 0.48;
   boxHeadRightPercentage = 0.70;
   boxHeadBackPercentage  = 0.48;
   boxHeadFrontPercentage = 0.60;
};

//------------------------------------------------------------------
// Light female data:
//------------------------------------------------------------------

PlayerData lfemale
{
   className = "Armor";
   shapeFile = "lfemale";
   flameShapeName = "lflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   canCrouch = true;
   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 32;
   minJetEnergy = 1;
   jetForce = 436;
   jetEnergyDrain = 0.1;

	maxDamage = 0.66;
   maxForwardSpeed = 13;
   maxBackwardSpeed = 13;
   maxSideSpeed = 13;
   groundForce = 40 * 9.0;
   mass = 9.0;
   groundTraction = 3.0;
	maxEnergy = 500;
   drag = 1.0;
   density = 1.2;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 75;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };


   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRHard,
     SoundLFootRSnow,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft,
     SoundLFootRSoft
  }; 
   lFootSounds =
   {
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLHard,
      SoundLFootLSnow,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft,
      SoundLFootLSoft
   };

   footPrints = { 0, 1 };

   boxWidth = 0.5;
   boxDepth = 0.5;
   boxNormalHeight = 2.3;
   boxCrouchHeight = 1.8;

   boxNormalHeadPercentage  = 0.85;
   boxNormalTorsoPercentage = 0.53;
   boxCrouchHeadPercentage  = 0.88;
   boxCrouchTorsoPercentage = 0.35;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
// Medium female data:
//------------------------------------------------------------------

PlayerData mfemale
{
   className = "Armor";
   shapeFile = "mfemale";
   flameShapeName = "mflame";
   shieldShapeName = "shield";
   damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
   shadowDetailMask = 1;
   validateShape = true;

   visibleToSensor = True;
	mapFilter = 1;
	mapIcon = "M_player";

   maxJetSideForceFactor = 0.8;
   maxJetForwardVelocity = 32;
   minJetEnergy = 1;
   jetForce = 436;
   jetEnergyDrain = 0.1;

   canCrouch = false;
	maxDamage = 1.0;
   maxForwardSpeed = 11;
   maxBackwardSpeed = 11;
   maxSideSpeed = 11;
   groundForce = 40 * 9;
   mass = 13;
   groundTraction = 3.0;
	maxEnergy = 500;
   mass = 11;
   drag = 1.0;
   density = 1.5;

	minDamageSpeed = 25;
	damageScale = 0.005;

   jumpImpulse = 110;
   jumpSurfaceMinDot = 0.2;

   // animation data:
   // animation name, one shot, exclude, direction,
	// firstPerson, chaseCam, thirdPerson, signalThread

   // movement animations:
   animData[0]  = { "root", none, 1, true, true, true, false, 0 };
   animData[1]  = { "run", none, 1, true, false, true, false, 3 };
   animData[2]  = { "runback", none, 1, true, false, true, false, 3 };
   animData[3]  = { "side left", none, 1, true, false, true, false, 3 };
   animData[4]  = { "side left", none, -1, true, false, true, false, 3 };
   animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
   animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
   animData[7] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[8] = { "crouch root", none, 1, true, false, true, false, 3 };
   animData[9] = { "crouch root", none, -1, true, false, true, false, 3 };
   animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
   animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
   animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
   animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
   animData[14]  = { "fall", none, 1, true, true, true, false, 3 };
   animData[15]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[16]  = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
   animData[17]  = { "tumble loop", none, 1, true, false, false, false, 3 };
   animData[18]  = { "tumble end", none, 1, true, false, false, false, 3 };
   animData[19] = { "jet", none, 1, true, true, true, false, 3 };

   // misc. animations:
   animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
   animData[21] = { "throw", none, 1, true, false, false, false, 3 };
   animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
   animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
   animData[24] = { "apc root", none, 1, false, false, false, false, 3 };
   
   // death animations:
   animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
   animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };

   // signal moves:
	animData[38] = { "sign over here",  none, 1, true, false, false, false, 2 };
   animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
   animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
   animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
   animData[42] = { "sign salut", none, 1, true, false, false, true, 1 }; 

    // celebraton animations:
   animData[43] = { "celebration 1", none, 1, true, false, false, false, 2 };
   animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
   animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };

    // taunt anmations:
   animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
   animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };

    // poses:
   animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
   animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };

	// Bonus wave
   animData[50] = { "wave", none, 1, true, false, false, true, 1 };

   jetSound = SoundJetLight;

   rFootSounds = 
   {
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRHard,
     SoundMFootRSnow,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft,
     SoundMFootRSoft
  }; 
   lFootSounds =
   {
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLHard,
      SoundMFootLSnow,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft,
      SoundMFootLSoft
   };

   footPrints = { 2, 3 };

   boxWidth = 0.7;
   boxDepth = 0.7;
   boxNormalHeight = 2.4;

   boxNormalHeadPercentage  = 0.84;
   boxNormalTorsoPercentage = 0.55;

   boxHeadLeftPercentage  = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage  = 0;
   boxHeadFrontPercentage = 1;
};

//------------------------------------------------------------------
//
//------------------------------------------------------------------







