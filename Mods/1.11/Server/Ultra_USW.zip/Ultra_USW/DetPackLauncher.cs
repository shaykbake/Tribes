ItemData DetPackLauncherAmmo 
{	
	description = "DetPackLauncher ammo"; 
	className = "Ammo"; 
	shapeFile = "grenammo"; 
	heading = "xAmmunition"; 
	shadowDetailMask = 4; 
	price = 2;
}; 

ItemImageData DetPackLauncherImage 
{	
	shapeFile = "grenadeL";
	mountPoint = 0;
	weaponType = 0;
	ammoType = DetPackLauncherAmmo;
	accuFire = false;
	reloadTime = 1.0;// 0.1;
	fireTime = 0.05;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
	sfxFire = SoundPickUpWeapon;	//SoundTurretDeploy;	//SoundFireGrenade;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundDryFire;
};

ItemData DetPackLauncher 
{	
	description = "DetPack Launcher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
	heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = DetPackLauncherImage;
	price = 150;
	showWeaponBar = true;
};

function DetPackLauncherImage::onFire(%player, %slot)
{
	%Ammo = Player::getItemCount(%player, $WeaponAmmo[DetPackLauncher]);
	%playerId = Player::getClient(%player);
	 if(%Ammo || %client.firegrenadelauncher)
	 {
	 	%fired.deployer = %player;
		%client = GameBase::getOwnerClient(%player);
		%vel = Item::getVelocity(%player);
		%trans = GameBase::getMuzzleTransform(%player);
		%armor = Player::getArmor(%player);
		%clientId = Player::getclient(%player);
		if (%playerId.grenl == 1 || (!%client.grenl && %armor == "harmor") )
		{
			%obj = newObject("","Mine","Suicidebomb2");
			GameBase::throw(%obj,%player,5,false);
			addToSet("MissionCleanup", %obj);
			%pos = GameBase::getPosition(%player);
			deleteObject(%client.firegrenadelauncher);
			GameBase::setPosition(%obj, %pos);
			%obj.deployer = %client;
			GameBase::setTeam (%obj,GameBase::getTeam (%client));
			Client::sendMessage(Player::getClient(%player),1,"20 Seconds untill detonation");
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>5 Seconds Untill Detonation\");",15);
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>650 Meter Blast Raduis!\");",5);
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>There she blows!\");",20);
		}
		else if (%playerId.grenl == 5 || (!%client.grenl && (%armor == "larmor" || %armor == "lfemale")) )
		{
			%obj = newObject("","Mine","Suicidebomb2");
			GameBase::throw(%obj,%player,5,false);
			addToSet("MissionCleanup", %obj);
			%pos = GameBase::getPosition(%player);
			deleteObject(%client.firegrenadelauncher);
			GameBase::setPosition(%obj, %pos);
			%obj.deployer = %client;
			GameBase::setTeam (%obj,GameBase::getTeam (%client));
			Client::sendMessage(%client,1,"20 Seconds untill detonation");
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>5 Seconds Untill Detonation!\");",15);
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>There she blows!\");",20);
		}
                else
		{
			%obj = newObject("","Mine","Suicidebomb2");
			GameBase::throw(%obj,%player,5,false);
			addToSet("MissionCleanup", %obj);
			%pos = GameBase::getPosition(%player);
			deleteObject(%client.firegrenadelauncher);
			GameBase::setPosition(%obj, %pos);
			%obj.deployer = %client;
			GameBase::setTeam (%obj,GameBase::getTeam (%client));
			Client::sendMessage(Player::getClient(%player),1,"20 Seconds untill detonation");
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>5 Seconds Untill Detonation\");",15);
			schedule("bottomprint(" @ %clientId @ ", \"<jc><f1>There she blows!\");",20);
		}
	

		Player::decItemCount(%player,$WeaponAmmo[DetPackLauncher],1);
	}
}
$ItemMax[larmor, DetPackLauncher] = 1;
$ItemMax[marmor, DetPackLauncher] = 1;
$ItemMax[harmor, DetPackLauncher] = 1;
$ItemMax[lfemale, DetPackLauncher] = 1;
$ItemMax[mfemale, DetPackLauncher] = 1;

$ItemMax[larmor, DetPackLauncherAmmo] = 10;
$ItemMax[marmor, DetPackLauncherAmmo] = 10;
$ItemMax[harmor, DetPackLauncherAmmo] = 10;
$ItemMax[lfemale, DetPackLauncherAmmo] = 10;
$ItemMax[mfemale, DetPackLauncherAmmo] = 10;

$InvList[DetPackLauncher] = 1;
$RemoteInvList[DetPackLauncher] = 1;

$InvList[DetPackLauncherAmmo] = 1;
$RemoteInvList[DetPackLauncherAmmo] = 1;

$AutoUse[DetPackLauncher] = false;
$SellAmmo[DetPackLauncherAmmo] = 5;
$WeaponAmmo[DetPackLauncher] = DetPackLauncherAmmo;

$TeamItemMax[DetPackLaumcher] = 1;
 