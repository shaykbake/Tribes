////////////AirBase////////////
$InvList[airbase] = 1;
$RemoteInvList[airbase] = 1;
////////////AribitorBox////////////
$InvList[ArbitorBoxPack] = 1;
$RemoteInvList[ArbitorBoxPack] = 1;
////////////BlastWall////////////
$InvList[BlastWall] = 1;
$RemoteInvList[BlastWall] = 1;
////////////Dissection Turret////////////
$InvList[DissectionPack] = 1;
$RemoteInvList[DissectionPack] = 1;
////////////Flame Turret////////////
$InvList[FlameTurretPack] = 1;
$RemoteInvList[FlameTurretPack] = 1;
////////////GuardDogTurret////////////
$InvList[ConPack] = 1; //GuardDog Turret
$RemoteInvList[ConPack] = 1; //GuardDog Turret
////////////Nuclear Turret////////////
$InvList[NuclearTurretPack] = 1;
$RemoteInvList[NuclearTurretPack] = 1;
////////////ObeliskOfLight////////////
$InvList[ObeliskPowerPack] = 1;
$InvList[ObeliskPack] = 1;
$RemoteInvList[ObeliskPowerPack] = 1;
$RemoteInvList[ObeliskPack] = 1;
////////////RailTurret////////////
$InvList[RailTurret] = 1; 
$RemoteInvList[RailTurret] = 1;
////////////JabberwalkieTurret////////////
$InvList[JabberwalkiePack] = 1;
$RemoteInvList[JabberwalkiePack] = 1;
////////////SuicidePack////////////
$InvList[SuicidePack] = 1;
$RemoteInvList[SuicidePack] = 1;
////////////WatchDogTurret////////////
$InvList[WatchdogPack] = 1;
$RemoteInvList[WatchdogPack] = 1;
////////////ZZ////////////
$InvList[ChaingunTurretPack] = 0;
$RemoteInvList[ChaingunTurretPack] = 0;
//ZZZ//
//$InvList[.] = 0;
//$RemoteInvList[.] = 0;
//==========================
//SHOCKFLOOR//
//==========================
$InvList[ShockFloorPack] = 1;
$RemoteInvList[ShockFloorPack] = 1;
