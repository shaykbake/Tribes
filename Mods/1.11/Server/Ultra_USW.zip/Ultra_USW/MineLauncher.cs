GrenadeData EMPgrenshl
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = ShockwaveThree;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.15;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $FlashDamageType;

   explosionRadius    = 20;
   kickBackStrength   = 50.0;
   maxLevelFlightDist = 130;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 2.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
	smokeName              = "enex.dts";
};

//======================= Tranq Grenade Shell
GrenadeData Tranqgren
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.15;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 50.9;
   damageType         = $MortarDamageType;

   explosionRadius    = 20;
   kickBackStrength   = 0;
   maxLevelFlightDist = 130;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 1.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
	smokeName              = "laserhit.dts";
};

$InvList[MineLauncher] = 1;
$RemoteInvList[MineLauncher] = 1;

$InvList[MineLauncherAmmo] = 1;
$RemoteInvList[MineLauncherAmmo] = 1;

$AutoUse[MineLauncher] = false;
$SellAmmo[MineLauncherAmmo] = 5;
$WeaponAmmo[MineLauncher] = MineLauncherAmmo;


ItemData MineLauncherAmmo 
{	
	description = "MineLauncher ammo"; 
	className = "Ammo"; 
	shapeFile = "grenammo"; 
	heading = "xAmmunition"; 
	shadowDetailMask = 4; 
	price = 2;
}; 

ItemImageData MineLauncherImage 
{	
	shapeFile = "grenadeL";
	mountPoint = 0;
	weaponType = 0;
	ammoType = MineLauncherAmmo;
	accuFire = true;
	reloadTime = 0.6;
	fireTime = 0.05;
	lightType = 3;
	lightRadius = 3;
	lightTime = 1;
	lightColor = { 0.6, 1, 1.0 };
	sfxFire = SoundPickUpWeapon;	//SoundTurretDeploy;	//SoundFireGrenade;
	sfxActivate = SoundPickUpWeapon;
	sfxReload = SoundDryFire;
};

ItemData MineLauncher 
{	
	description = "MineLauncher";
	className = "Weapon";
	shapeFile = "grenadeL";
	hudIcon = "grenade";
	heading = "TUSW-Weapons";
	shadowDetailMask = 4;
	imageType = MineLauncherImage;
	price = 150;
	showWeaponBar = true;
};

function MineLauncherImage::onFire(%player, %slot)
{
	%Ammo = Player::getItemCount(%player, $WeaponAmmo[MineLauncher]);
	%playerId = Player::getClient(%player);
	 if(%Ammo || %client.firegrenadelauncher)
	 {
	 	%fired.deployer = %player;
		%client = GameBase::getOwnerClient(%player);
		%vel = Item::getVelocity(%player);
		%trans = GameBase::getMuzzleTransform(%player);
		%armor = Player::getArmor(%player);
		if (%playerId.grenl == 1 || (!%client.grenl && %armor == "harmor") )
		{
			%fired = Projectile::spawnProjectile("Tranqgren",%trans,%player,%vel);
			%fired.deployer = %client;
			bottomprint(Player::getClient(%player),"<jc>Projectile Type: <f1>A-Bomb Grenade",5);
		}
		else if (%playerId.grenl == 5 || (!%client.grenl && (%armor == "larmor" || %armor == "lfemale")) )
		{
			%obj = newObject("","Mine","USWGasAttack");
			GameBase::throw(%obj,%player,20,false);
			addToSet("MissionCleanup", %obj);
			%pos = GameBase::getPosition(%player);
			deleteObject(%client.firegrenadelauncher);
			GameBase::setPosition(%obj, %pos);
			%obj.deployer = %client;
			GameBase::setTeam (%obj,GameBase::getTeam (%client));
			bottomprint(Player::getClient(%player),"<jc>Projectile Type: <f1>Claymor Mine - <f2>Do not confuse this for any other mine or you'll end up face down in a ditch with a load in your pants",5);
		}
                else
		{
			%fired = Projectile::spawnProjectile("EMPgrenshl",%trans,%player,%vel);
			%fired.deployer = %client;
			bottomprint(Player::getClient(%player),"<jc>Projectile Type: <f1>EMP Grenade",5);
		}
	

		Player::decItemCount(%player,$WeaponAmmo[MineLauncher],1);
	}
}
$ItemMax[larmor, MineLauncher] = 1;
$ItemMax[marmor, MineLauncher] = 1;
$ItemMax[harmor, MineLauncher] = 1;
$ItemMax[lfemale, MineLauncher] = 1;
$ItemMax[mfemale, MineLauncher] = 1;

$ItemMax[larmor, MineLauncherAmmo] = 500;
$ItemMax[marmor, MineLauncherAmmo] = 500;
$ItemMax[harmor, MineLauncherAmmo] = 500;
$ItemMax[lfemale, MineLauncherAmmo] = 500;
$ItemMax[mfemale, MineLauncherAmmo] = 500;