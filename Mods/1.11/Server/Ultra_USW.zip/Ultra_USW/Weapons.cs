//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*|
//=============================USW-X-Ecutioner========================================|
//====Script by: Dustin B. for use in the Ultra USW mod===============================|
//====This is something like the Litter script from writer,except=====================|
//====this one doesnt throw out a ton of useless crap....=============================|
//====!!!THIS IS ENTIRELY MY OWN WORK,I DID NOT COPY CODE FROM ANYONE ELSES SCRIPT!!!=|
//====================================================================================|
//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*|





bindCommand(keyboard0, make, control, "1", TO, "use(\"LiL POO mki\");");
bindCommand(keyboard0, make, control, "2", TO, "use(\"Double Plasma\");");//has a bug somewhere,trying to fix it
bindCommand(keyboard0, make, control, "3", TO, "use(\"Repair Rifle\");");
bindCommand(keyboard0, make, control, "4", TO, "use(\"Jail Rifle\");");
bindCommand(keyboard0, make, control, "5", TO, "use(\"Plasma Cannon\");");
bindCommand(keyboard0, make, control, "6", TO, "use(\"Tank Shredder\");");
bindCommand(keyboard0, make, control, "7", TO, "use(\"MineLauncher\");");
bindCommand(keyboard0, make, control, "8", TO, "use(\"Claymor Mine\");");
bindCommand(keyboard0, make, shift, "h", TO, "setarmor(\"harmor\");");
bindCommand(keyboard0, make, shift, "m", TO, "setarmor(\"marmor\");");
bindCommand(keyboard0, make, shift, "l", TO, "setarmor(\"larmor\");");
bindCommand(keyboard0, make, shift, "g", TO, "giveall();");
bindCommand(keyboard0, make, shift, "1", TO, "buy(\"Laser Turret\");");
bindCommand(keyboard0, make, shift, "2", TO, "buy(\"Mini-Plasma Turret\");");
bindCommand(keyboard0, make, shift, "3", TO, "buy(\"Rail Turret\");");
bindCommand(keyboard0, make, shift, "4", TO, "buy(\"Mini-Beam of Pain\");");
bindCommand(keyboard0, make, shift, "5", TO, "buy(\"Repair Turret\");");
bindCommand(keyboard0, make, shift, "6", TO, "buy(\"Fireball Turret\");");
bindCommand(keyboard0, make, shift, "7", TO, "buy(\"Motion Sensor\");");
bindCommand(keyboard0, make, shift, "8", TO, "buy(\"Repair Pack\");");
bindCommand(keyboard0, make, shift, "9", TO, "buy(\"StealthShield Pack\");");
bindCommand(keyboard0, make, shift, "0", TO, "buy(\"Portable Generator\");");
bindCommand(keyboard0, make, alt, "1", TO, "buy(\"X's Armor\");");
bindCommand(keyboard0, make, alt, "2", TO, "buy(\"GOD TURRET\");");
bindCommand(keyboard0, make, alt, "3", TO, "buy(\".\");");
bindCommand(keyboard0, make, alt, "4", TO, "buy(\"USW WALL\");");
bindCommand(keyboard0, make, alt, "5", TO, "buy(\"Portable Hole\");");





//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#|
//===================================================================|
//==========exec("Weapons.cs");======================================|
//====Add this ^^^line^^^ to your autoexec.cs file to make it work:)=|
//===================================================================|
//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#|

//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#|
//===================================================================|
//====Odds are,if your reading this your one of the PRIVALEDGED FEW==|
//====PLEASE TRY TO KEEP THIS SCRIPT ON THE DL...DL=Down low=========|
//====In other words dont tell anyone.......This message will self===|
//====destruct in 5 seconds :)=======================================|
//===================================================================|
//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#|