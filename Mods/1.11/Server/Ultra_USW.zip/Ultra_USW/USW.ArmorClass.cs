////////////RailTurret////////////
$DamageClass = 0;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 60;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 61;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 62;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 63;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 64;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

$DamageClass = 65;
$WeaponDamageType = $SniperDamageType;
$value = 1.0;
MiniMod::Build::Damage::Classes();

