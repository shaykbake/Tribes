//============================================================================================= Healing Beacon

TurretData RepairTurret
{
	className = "Turret";
	shapeFile = "cactus2";
	maxDamage = 1;
	maxEnergy = 0;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	visibleToSensor = true;
	shadowDetailMask = 4;
	supressable = true;
	pinger = false;
	dopplerVelocity = 0;
	castLOS = true;
	supression = true;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = flashExpMedium;
	description = "Healing Plant";
//	damageSkinData = "objectDamageSkins";
};

function RepairTurret::onAdd(%this)
{
	schedule("RepairTurret::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,5);
	if (GameBase::getMapName(%this) == "") 
	{
		GameBase::setMapName (%this, "Repair Turret");
	}
}

function RepairTurret::deploy(%this)
{
	GameBase::playSequence(%this,1,"deploy");
}

function RepairTurret::onEndSequence(%this,%thread)
{
	GameBase::setActive(%this,true);
}

function RepairTurret::onDisabled(%this)
{
	Turret::onDisabled(%this);
}
function RepairTurret::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "RepairTurretPack"]--;
}

function RepairTurret::onPower(%this,%power,%generator) {}

function RepairTurret::onEnabled(%this) 
{
	schedule("RepairTurret::checkHealingPlant(" @ %this @ ");", 0.1, %this);
}	

function RepairTurret::onCollision(%this,%obj)
{
	if(getObjectType(%obj) != "Player")
	{
		return;
	}

	if(Player::isDead(%obj))
	{
		return;
	}

	%c = Player::getClient(%obj);


	%playerTeam = GameBase::getTeam(%obj);
	%teleTeam = GameBase::getTeam(%this);

	if(GameBase::getDamageLevel(%obj)) 
	{
		GameBase::setDamageLevel(%obj,0);
		GameBase::playSound(%this,ForceFieldOpen,0);
	}
}

function RepairTurret::checkHealingPlant(%this)
{
	if(GameBase::getDamageState(%this) != "Enabled")
		return;

	%Set = newObject("set",SimSet); 
	%Pos = GameBase::getPosition(%this); 
	%Mask = $SimPlayerObjectType|$StaticObjectType|$VehicleObjectType|$MineObjectType|$SimInteriorObjectType;
	
	containerBoxFillSet(%Set, %Mask, %Pos, 200, 200, 200,0);
	
	%num = Group::objectCount(%Set);
	
	for(%i; %i < %num; %i++)
	{
		%obj = Group::getObject(%Set, %i);

		if (%obj != %this) 
		{
//			if (getObjectType(%obj) == "Player")
//			{
				if(GameBase::getTeam(%obj) != GameBase::getTeam(%this))
				{
					if(GameBase::getDamageLevel(%obj))
					{
						%armor = Player::getArmor(%obj);

						if(%armor == "spyarmor" || %armor == "spyfemale")
						{
							Gamebase::repairDamage(%obj,5.09);
							schedule ("playSound(ForceFieldOpen,GameBase::getPosition(" @ %obj @ "));",0.1);
						}
					}
				}
				else
				{
					if(GameBase::getDamageLevel(%obj))
					{
						%drate = GameBase::getDamageLevel(%obj);
                                                %drate -= 40.5;
                                                if(%drate < 0) %drate = 0;
                                                GameBase::setDamageLevel(%obj,%drate);
                                                schedule ("playSound(ForceFieldOpen,GameBase::getPosition(" @ %obj @ "));",0.1);
					}
				}
//			}
		}
	}
	deleteObject(%set);
	schedule("RepairTurret::checkHealingPlant(" @ %this @ ");", 5.0, %this);
}

////////////RepairTurretPack////////////
$TeamItemMax[RepairTurretPack] = 40;

ItemImageData RepairTurretImage
{
	shapeFile = "cactus2";
	mountPoint = 2;
	mountOffset = { 0, -0.1, -0.06 };
	mountRotation = { 0, 0, 0 };
	firstPerson = false;
};

ItemData RepairTurretPack
{
	description = "Repair Turret";
	shapeFile = "cactus2";
	className = "Backpack";
   heading = "jOther Deployables";
	imageType = RepairTurretImage;
	shadowDetailMask = 4;
	mass = 2.0;
	elasticity = 0.2;
	price = 250;
	hudIcon = "deployable";
	showWeaponBar = true;
	hiliteOnActive = true;
};

function RepairTurretPack::onUse(%player,%item)
{
	if (Player::getMountedItem(%player,$BackpackSlot) != %item) {
		Player::mountItem(%player,%item,$BackpackSlot);
	}
	else {
		Player::deployItem(%player,%item);
	}
}

function RepairTurretPack::onDeploy(%player,%item,%pos)
{
	if (RepairTurretPack::deployShape(%player,%item)) {
		Player::decItemCount(%player,%item);
	}
}

function RepairTurretPack::deployShape(%player,%item)
{
 	%client = Player::getClient(%player);
	if($TeamItemCount[GameBase::getTeam(%player) @ %item] < $TeamItemMax[%item]) {
		if (GameBase::getLOSInfo(%player,3)) {
			// GetLOSInfo sets the following globals:
			// 	los::position
			// 	los::normal
			// 	los::object
			%obj = getObjectType($los::object);
			if (%obj == "SimTerrain" || %obj == "InteriorShape" || %obj == "DeployablePlatform") {

				// Try to stick it straight up or down, otherwise
				// just use the surface normal
				%prot = GameBase::getRotation(%player);
				%zRot = getWord(%prot,2);
				if (Vector::dot($los::normal,"0 0 1") > 0.6) {
					%rot = "0 0 " @ %zRot;
				}
				else {
					if (Vector::dot($los::normal,"0 0 -1") > 0.6) {
						%rot = "3.14159 0 " @ %zRot;
					}
					else {
						%rot = Vector::getRotation($los::normal);
					}
				}
				if(checkDeployArea(%client,$los::position)) {
					%camera = newObject("Repair Turret","Turret","RepairTurret",true);
	   	      addToSet("MissionCleanup", %camera);
					GameBase::setTeam(%camera,GameBase::getTeam(%player));
					GameBase::setRotation(%camera,%rot);
					GameBase::setPosition(%camera,$los::position);
					Gamebase::setMapName(%camera,"Repair Turret#"@ $totalNumCameras++ @ " " @ Client::getName(%client));
					Client::sendMessage(%client,0,"Repair Turret deployed");
					playSound(SoundPickupBackpack,$los::position);
					$TeamItemCount[GameBase::getTeam(%camera) @ "RepairTurretPack"]++;
					return true;
				}
			}
			else {
				Client::sendMessage(%client,0,"Can only deploy on terrain or buildings");
			}
		}
		else {
			Client::sendMessage(%client,0,"Deploy position out of range");		
		}
	}
	else																						  
	 	Client::sendMessage(%client,0,"Deployable Item limit reached for " @ %item.description @ "s");
	
	return false;
}

	$TeamItemCount[0 @ RepairTurretPack] = 0;
	$TeamItemCount[1 @ RepairTurretPack] = 0;
	$TeamItemCount[2 @ RepairTurretPack] = 0;
	$TeamItemCount[3 @ RepairTurretPack] = 0;
	$TeamItemCount[4 @ RepairTurretPack] = 0;
	$TeamItemCount[5 @ RepairTurretPack] = 0;
	$TeamItemCount[6 @ RepairTurretPack] = 0;
	$TeamItemCount[7 @ RepairTurretPack] = 0;
	
//=======Station.cs====//
$InvList[RepairTurretPack] = 1;
$RemoteInvList[RepairTurretPack] = 1;

//======Armordata.cs=====//
$ItemMax[larmor, RepairTurretPack] = 1;
$ItemMax[lfemale, RepairTurretPack] = 1;
$ItemMax[marmor, RepairTurretPack] = 1;
$ItemMax[mfemale, RepairTurretPack] = 1;
$ItemMax[harmor, RepairTurretPack] = 1;