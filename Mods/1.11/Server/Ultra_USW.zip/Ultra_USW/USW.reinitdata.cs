////////////AirBase////////////
for(%i = 0; %i < 8; %i++)
{
                $TeamItemCount[%i @ airbase] = 0;
                $TeamEnergy[%i] = $DefaultTeamEnergy;
}
////////////BlastWall////////////
for(%i = 0; %i < 8; %i++)
{
                $TeamItemCount[%i @ BlastWall] = 0;

}
////////////Dissection Turret////////////
for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ DissectionPack] = 0;
}
////////////Flame Turret////////////
for(%i = 0; %i < 8; %i++)
{
	$TeamItemCount[%i @ FlameTurretPack] = 0;
	$TeamEnergy[%i] = $DefaultTeamEnergy;
}
////////////GuardDogTurret////////////
for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ ConPack] = 0;
}
////////////ObeliskOfLight////////////
for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ ObeliskPowerPack] = 0;
		$TeamItemCount[%i @ ObeliskPack] = 0;
}
////////////RailTurret////////////
for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ RailTurret] = 0;
}
////////////JabberwalkieTurret////////////
for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ JabberwalkiePack] = 0;
}
////////////SuicidePack////////////
for(%i = 0; %i < 8; %i++)
{
                $TeamItemCount[%i @ SuicidePack] = 0;
                $TeamEnergy[%i] = $DefaultTeamEnergy;
}
////////////WatchDogTurret////////////
for(%i = 0; %i < 8; %i++)
{
		$TeamItemCount[%i @ WatchdogPack] = 0;
}