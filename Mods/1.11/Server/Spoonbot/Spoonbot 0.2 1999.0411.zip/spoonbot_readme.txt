----------------------------------------------------------------
Name: Spoonbot Mod
Version: 0.2
Date: 11 April 1999
Author: Josef Jahn
Email: werewolf@playspoon.com
URL :http://www.playspoon.com
Purpose: Enhanced bot AI with "hunt and kill" capability and extended armor/weapon handling.



Notes:   Please feel free to host this mod admins, and if you have time, drop me a line where its at so i can come play :)
Known Bugs: Sometimes a bot stops chasing you fo no reason. However this is really rare by now. You may never encounter this bug at all!

---------------------------------------------------------------

Client Install: NONE. 


Server Install: 
	Unzip the archive with pathnames.


When installed The Files Should be here: 
 Tribes\spoonbot\scripts.vol
 Tribes\spoonbot_readme.txt
 Tribes\spoonbot.bat
 Tribes\base\missions\Spoonbot test map.dsc
 Tribes\base\missions\Spoonbot test map.mis

To start the server with this mod go to DOS and the tribes directory and type
  tribes -mod spoonbot

or for a dedicated server type

   tribes -mod spoonbot -dedicated

NOTE:  Make sure you have the tribes 1.3 version installed first!
       Just download it at www.tribesplayers.com and get instructions there.


Check out any updates at www.playspoon.com
and email me at werewolf@playspoon.com




 Spoonbot Features
------------------------------

As usual, bots can be controlled via the command console.
However, if a bot spots an enemy (regardless if it is another bot or a human player), it will chase the enemy.
If out of sight, bots will try to re-aquire a visual contact and resume hunting.
Bots will choose the adequate weapons depending on range and player status.

Different armor/weapon configuration for bots:
Multiple armor/weapon configurations are available. For example, if you want to test the heavy bot, have his name contain the word "Guard"
A bot called "Guard", "MyGuard" or even "WhateverNameYouWant_Guard" will automatically spawn as heavy equipped with plasma, disclauncher and mortar.

There's a map included with this archive, called "Spoonbot test map". It contains a bot named "Team0Guard" for you to test the heavy config.






 Other changes to TRIBES:
------------------------------

- Rocket Turrets won't autofire on bots or vehicles anymore. They WILL autofire on jetting players.
  This was really annoying, since bots had no chance because of those damn rocket turrets.
  I will try to make Rocket Turrets distinguish players, vehicles and bots so they react accordingly.

- Respawn delay for bots has increased.





 Known Issues
------------------------------

- Snipers fire much too rapidly

- Painters ditto

- Females in heavy armor won't do... Dunno why





 ToDo:
------------------------------

DONE: More bot armor/weapon configurations!
DONE: Spawn bots as heavy/medium/light just by having its name contain some control word
- OR alternatively, making them respond to buy/equip orders by going to an inventory station and buying stuff
- Long-range mortaring of painted targets.
- Bot chatting
- Avoid obstacles!
- Use jumpjets for climbing towers, ski-jumping and evading
- Resuming mission after chasing and killing a spotted enemy (instead of just staying put there)
- Returning to a reload station after ammo is depleted.
- Bots checking target locations to see if they can actually get there.


- Plus any stuff you want me to implement!





 Bot Classes:
------------------------------

Bots are organized in classes. To have a bot spawn in "Medic" configuration, simply have his name contain the word "Medic". This applies to all classes, so a bot named "BillClinton_Demo" will spawn as Demolition-bot.
If you are making maps or work on a bot-ai, please conform with this definitions, or email us suggestions because else everyone has to download an extra map for each bot-ai ... and this is pure hell for mapmakers.
That's something we don't want to happen. So you can expect both me and Savage to be compatible with each other. I hope other AI-programmers will join our concept.


  Guard
  ------------
Armor: Heavy
Weapons: Mortar, Disc Launcher, Plasma Gun
Backpacks: Ammo Pack

This is a heavy bot, designed to take out turrets and other installations from long-distance. Future versions may include the ability to mortar "painted" targets.




  Demo
  ------------
Armor: Medium
Weapons: Disc Launcher, Plasma Gun, Grenade Launcher
Backpacks: Jammer Pack

AI not implemented yet. Behaves like standard bot.




  Painter
  ------------
Armor: Light
Weapons: Blaster, Disc Launcher, Chaingun, Targeting Laser
Backpacks: Ammo Pack

AI not FULLY implemented yet. Behaves like standard bot & marks targets farther away than 50 units.




  Sniper
  ------------
Armor: Light
Weapons: Disc Launcher, Plasma Gun, Laser Rifle
Backpacks: Energy Pack

AI not FULLY implemented yet. Behaves like standard bot & snipes at targets farther away than 100 units.




  Medic
  ------------
Armor: Light
Weapons: Blaster, Disc Launcher, Chaingun
Backpacks: Repair Pack

AI not implemented yet. Behaves like standard bot.




  Miner
  ------------
Armor: Light
Weapons: Blaster, Disc Launcher, Plasma Gun, Mines
Backpacks: Jammer Pack

AI not FULLY implemented yet. Behaves like standard bot & throws mines at ground targets closer than 100 units.



--------------------------------------------------------------------------------














Email me! 
Please send any questions or comments or ideas to me at werewolf@playspoon.com

Also, if you would have a server and would like to host this mod, feel free! Just please let me know where your server is at so I can come play sometime! 




----------------------------------------------------------------
Disclaimer: I am not responsible for any damage this game 
	    modification may cause you or anything having to do 
	    with you. I also am not responsible for any hardware failures 
	    or software problems that may arise in TRIBES, your computer,
	    or life in general.  If you would like to host this mod.. feel free.
            if you like, or hate this mod, or have any ideas, please drop me a line.
 	    Thank you!
----------------------------------------------------------------

