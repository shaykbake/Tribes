function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "Main1"){
      %positionIn = "816.543 324.439 2295.8";
      %positionOut = "816.543 324.439 2295.8";
   }
	if(%this.num == "Main2"){
      %positionIn = "550.945 446.2 2895.03";
      %positionOut = "550.945 446.2 2895.03";
   }
	if(%this.num == "Main3"){
      %positionIn = "564.979 439.254 2542.01";
      %positionOut = "564.979 439.254 2542.01";
   }
	if(%this.in){ 
         GameBase::setPosition(%client, %positionIn);
         //messageAll(0, "~wshieldhit.wav");
	   Client::SendMessage(%client,0,"~wshieldhit.wav");
      }
      	else if(%this.out){
         GameBase::setPosition(%client, %positionOut);
         //messageAll(0, "~wshieldhit.wav");
         Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
} 


