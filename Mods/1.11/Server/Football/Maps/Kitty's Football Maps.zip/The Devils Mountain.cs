function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "Main1"){
      %positionIn = "844.104 1045.78 2370.13";
      %positionOut = "844.104 1045.78 2370.13";
   }
	if(%this.num == "Main2"){
      %positionIn = "852.296 1071.42 2637.05";
      %positionOut = "852.296 1071.42 2637.05";
   }
	if(%this.num == "Main3"){
      %positionIn = "859.939 1057.28 2378.13";
      %positionOut = "859.939 1057.28 2378.13";
   }
	if(%this.in){ 
         GameBase::setPosition(%client, %positionIn);
         //messageAll(0, "~wshieldhit.wav");
	   Client::SendMessage(%client,0,"~wshieldhit.wav");
      }
      	else if(%this.out){
         GameBase::setPosition(%client, %positionOut);
         //messageAll(0, "~wshieldhit.wav");
         Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
} 


