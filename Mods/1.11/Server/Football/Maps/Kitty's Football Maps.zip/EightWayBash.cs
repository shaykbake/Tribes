function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "Main1"){ //this is how u kill someone instead of teleporting
		GameBase::setAutoRepairRate(%object, -4)  
   }
	if(%this.num == "Main2"){
		GameBase::setAutoRepairRate(%object, -4)  
   }
	if(%this.num == "Main3"){
		GameBase::setAutoRepairRate(%object, -4)  
   }
	if(%this.num == "Main4"){
		GameBase::setAutoRepairRate(%object, -4)  
   }
	if(%this.in && %teleport == "true"){ 
		GameBase::setPosition(%client, %positionIn);
		GameBase::setRotation(%client, %rotationIn);
		GameBase::startFadeIn(%client);
		Client::SendMessage(%client,0,"~wmotion_activate.wav");
	}
	else if(%this.out && %teleport == "true"){
		GameBase::setPosition(%client, %positionOut);
		Client::SendMessage(%client,0,"wmotion_activate.wav");
	}
 
} 


