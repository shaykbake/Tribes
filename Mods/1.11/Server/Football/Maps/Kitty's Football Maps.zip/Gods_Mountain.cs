function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "Main1"){
	%teleport="true";
      %positionIn = "267.14 298.368 -201.592";
      %positionOut = "267.14 298.368 -201.592";
      %rotationIn = "0 0 0";
   }
	if(%this.num == "Main2"){
      %teleport="true";
      %positionIn = "573.8 -599.719 4117.04";
      %positionOut = "573.8 -599.719 4117.04";
      %rotationIn = "0 0 0";
   }
	if(%this.num == "Main3"){
      %teleport="true";
      %positionIn = "602.1 -589.003 3980.82";
      %positionOut = "602.1 -589.003 3980.82";
      %rotationIn = "0 0 0";
   }
	if(%this.in && %teleport == "true"){ 
		GameBase::setPosition(%client, %positionIn);
		GameBase::setRotation(%client, %rotationIn);
		GameBase::startFadeIn(%client);
		Client::SendMessage(%client,0,"~wmotion_activate.wav");
	}
	else if(%this.out && %teleport == "true"){
		GameBase::setPosition(%client, %positionOut);
		Client::SendMessage(%client,0,"wmotion_activate.wav");
	}
 
} 


