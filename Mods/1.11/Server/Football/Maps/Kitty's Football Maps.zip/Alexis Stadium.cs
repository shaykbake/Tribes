function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "Main1"){
	%teleport="true";
      %positionIn = "-734.612 518.001 261.355";
      %positionOut = "-734.612 518.001 261.355";
      %rotationIn = "0 0 0";
   }
	if(%this.num == "Main2"){
      %teleport="true";
      %positionIn = "68.5254 542.225 100";
      %positionOut = "68.5254 542.225 100";
      %rotationIn = "0 0 0";
   }
	if(%this.in && %teleport == "true"){ 
		GameBase::setPosition(%client, %positionIn);
		GameBase::setRotation(%client, %rotationIn);
		GameBase::startFadeIn(%client);
		Client::SendMessage(%client,0,"~wmotion_activate.wav");
	}
	else if(%this.out && %teleport == "true"){
		GameBase::setPosition(%client, %positionOut);
		Client::SendMessage(%client,0,"wmotion_activate.wav");
	}
 
} 


