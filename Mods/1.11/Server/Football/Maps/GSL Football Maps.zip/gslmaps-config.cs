//Dedicated Football Server Prefs file by Spike <gsl@spikescape.com>
//Join the Tribes Football ladder at GSL: http://thegsl.com
//Football FTP archive: http://amishrabbit.com/tribes/football
//How to set up a dedicated server: http://amishrabbit.com/tribes/football/server.html
//Updated 15 August 2002

$Server::HostName = "GSL Football"; //name that shows up in server list
$Server::MaxPlayers = "16"; //MAX should be 8 for cable/DSL, 16 for T1, 32 for T3 or higher.
$Server::HostPublicGame = "True";
$Server::Info = "GSL Football\nAdmin: NAME (EMAIL)\nLeague site: www.thegsl.com"; 

//displays as the player connects to the server
$MODInfo = "<f0>It's Football--Tribes style!\n\n<f1>'' If all the year were playing holidays, To sport would be as tedious as to work. ''  --Shakespeare";

//displays after they connect but before they join a team.
//MAXIMUM 71 CHARS PER MOTD STRING
$Server::JoinMOTD = "<f1><jc>Welcome to Tribes Football\n<f2>We run the GSL football mod.\nGet the client pack from amishrabbit.com/tribes/football";

$Server::Port = "28001";
$Server::Password = "";
$Server::TimeLimit = "15";
$Server::AutoAssignTeams = "True";
$Server::TourneyMode = "False";
$Server::TeamDamageScale = "0";
$Server::HostPublicGame = "True";
$AdminPassword = "CHANGEME";
$Server::warmupTime = 20;
$Server::respawnTime = 1;
$Server::VotingTime = 15;
$Server::VoteWinMargin = 0.80;
$telnetport = "11111"; //change to something else
$telnetpassword = "CHANGEMETOO";
$pref::PacketRate = "15"; //lower to 10 for modem players
$pref::PacketSize = "300"; //lower to 200 for modem players

//Team names and skins
$Server::teamSkin0 = "beagle";
$Server::teamName0 = "TEAM 1";
$Server::teamSkin1 = "NFLPATRIOTS";
$Server::teamName1 = "TEAM 2";

//Additional Code
$console::logmode=1; //set to 0 if you want NO LOG

//football missions only
exec(missionlist);
MissionList::clear();
Missionlist::initNextMission();
$pref::lastmission = "HighSchool"; //first mission to launch when you startup

//Missionlist: order in reverse alphabetical here to make them alpha in the menu
MissionList::addMission("Xenomorphic");
MissionList::addMission("TK-421_Extended_Stadium");
MissionList::addMission("The_Ruins");
MissionList::addMission("The_Colosseum");
MissionList::addMission("The_Cliff");
MissionList::addMission("Tennis");
MissionList::addMission("Stingray_Stadium");
MissionList::addMission("SlamDunk_Stadium");
MissionList::addMission("RomanFootBall");
MissionList::addMission("Redshirt_Memorial_Stadium");
MissionList::addMission("RampedTouchdown2");
MissionList::addMission("Pro_Ball");
MissionList::addMission("PrisonCampRedux");
MissionList::addMission("Official_Stadium9");
MissionList::addMission("Official_Stadium8");
MissionList::addMission("Official_Stadium7");
MissionList::addMission("Official_Stadium6");
MissionList::addMission("Official_Stadium5");
MissionList::addMission("Official_Stadium4");
MissionList::addMission("Official_Stadium3");
MissionList::addMission("Official_Stadium2");
MissionList::addMission("Official_Stadium1");
//MissionList::addMission("n00b");
MissionList::addMission("Nameless_Stadium");
MissionList::addMission("JAFS");
MissionList::addMission("HighSchool");
MissionList::addMission("HeiligeScheisseStadium");
MissionList::addMission("football");
MissionList::addMission("Flip_Stadium13");
MissionList::addMission("Flip_Stadium10");
MissionList::addMission("Flip_Stadium8");
MissionList::addMission("Flip_Stadium5");
MissionList::addMission("Flip_Stadium4");
MissionList::addMission("EEPROM_Stadium");

//Rotation paradigm: $nextMission["CURRENT"] = "NEXT";
$nextMission["football"] = "Official_Stadium1";
$nextMission["Official_Stadium1"] = "Official_Stadium2";
$nextMission["Official_Stadium2"] = "Official_Stadium3";
$nextMission["Official_Stadium3"] = "Official_Stadium4";
$nextMission["Official_Stadium4"] = "Official_Stadium5";
$nextMission["Official_Stadium5"] = "Official_Stadium6";
$nextMission["Official_Stadium6"] = "Official_Stadium7";
$nextMission["Official_Stadium7"] = "Official_Stadium8";
$nextMission["Official_Stadium8"] = "Official_Stadium9";
$nextMission["Official_Stadium9"] = "EEPROM_Stadium";
$nextMission["EEPROM_Stadium"] = "RomanFootBall";
$nextMission["RomanFootBall"] = "HighSchool";
$nextMission["HighSchool"] = "HeiligeScheisseStadium";
$nextMission["HeiligeScheisseStadium"] = "TK-421_Extended_Stadium";
$nextMission["TK-421_Extended_Stadium"] = "Xenomorphic";
$nextMission["Xenomorphic"] = "The_Ruins";
$nextMission["TheRuins"] = "Pro_Ball";
$nextMission["Pro_Ball"] = "Stingray_Stadium";
$nextMission["Stingray_Stadium"] = "Flip_Stadium4";
$nextMission["Flip_Stadium4"] = "Flip_Stadium5";
$nextMission["Flip_Stadium5"] = "Flip_Stadium8";
$nextMission["Flip_Stadium8"] = "Flip_Stadium10";
$nextMission["Flip_Stadium10"] = "Flip_Stadium13";
$nextMission["Flip_Stadium13"] = "PrisonCampRedux";
$nextMission["PrisonCampRedux"] = "Redshirt_Memorial_Stadium";
$nextMission["Redshirt_Memorial_Stadium"] = "SlamDunk_Stadium";
$nextMission["SlamDunk_Stadium"] = "Nameless_Stadium";
$nextMission["Nameless_Stadium"] = "Tennis";
$nextMission["Tennis"] = "The_Cliff";
$nextMission["The_Cliff"] = "The_Colosseum";
$nextMission["The_Colosseum"] = "JAFS";
$nextMission["JAFS"] = "RampedTouchdown2";
$nextMission["RampedTouchdown2"] = "football";
//missing these missions -- enter into rotation later
//$nextMission["n00b"] = "football";
//last rotation map should always point back to the first.
