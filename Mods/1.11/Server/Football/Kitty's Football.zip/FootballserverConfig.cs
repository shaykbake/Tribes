$Server::HostName = "Server Name here";
$Server::MaxPlayers = "8"; 
$Server::HostPublicGame = "True";
$Server::Info = "Server Name Here\nAdmin: Owner (owners email)\nMod info: mods.tribalwar.com/football"; 

//displays as the player connects to the server
$MODInfo = "<f0>It's Football--Tribes style!\n\n<f1>'' Meow. ''  --Kitty";

//displays after they connect but before they join a team.
//MAXIMUM 71 CHARS PER MOTD STRING
$Server::JoinMOTD = "<f1><jc>Welcome to Server\n<f2>nWelcome to server.";

$TCTimer = 10; //cannot change teams for this long (seconds) after any team change
$VoteAdminAllowed = false; //vote admin function on or off
$halftimeDelay = 10; //delay (seconds) before game resumes at half time, if under 5 - no halftime
$HPM = false; //toggles hot patato mode
$HPTime = 15; //time a person has to pass before punishment
$SmurfTracker = true;
$gunFumbleChance = 50;
$RanAssign = 3;
$InfJet = false;
$TATD = true; //toggles if tackle after TD is on or off (false is off)
$SecondConnectingMessage = "<f1>\nHEY!!!!";
$CycleOnEmpty = false; //cycles mission when last player leaves server

$Server::Port = "28001";
$Server::Password = "";
$Server::TimeLimit = "5"; //this is for each half
$Server::AutoAssignTeams = "True";
$Server::TourneyMode = "False";
$Server::TeamDamageScale = "0";
$Server::HostPublicGame = "True";
$AdminPassword = "changeme";
$Server::warmupTime = 20;
$Server::respawnTime = 1;
$Server::VotingTime = 15;
$Server::VoteWinMargin = 0.80;
$telnetport = "11111"; //change to something else
$telnetpassword = "changemetoo";
$pref::PacketRate = "15"; //lower to 10 for modem players
$pref::PacketSize = "300"; //lower to 200 for modem players

//Team names and skins
$Server::teamSkin0 = "beagle";
$Server::teamName0 = "Cats";
$Server::teamSkin1 = "blue"; 
$Server::teamName1 = "Dogs";
$Server::teamSkin2 = "purple";
$Server::teamName2 = "Elks";
$Server::teamSkin3 = "green"; 
$Server::teamName3 = "The Gays";
$Server::teamSkin4 = "orange";
$Server::teamName4 = "I Dont Know";
$Server::teamSkin5 = "dsword"; 
$Server::teamName5 = "Damnit!!";
$Server::teamSkin6 = "swolf";
$Server::teamName6 = "Browns";
$Server::teamSkin7 = "cphoenix"; 
$Server::teamName7 = "reds";

//Additional Code
$console::logmode=1; //set to 0 if you want NO LOG
exec("FBMissionslist");