Simply place all the files in C:\Dynamix\Tribes\Config

and your set.

this is not how you host a server :P