Balance of Power - Mod for Tribes by James C. Vetsch aka {=MaS=}Qa.Man.9

Version 1.85

Qa.Man.9@Worldnet.Att.Net
Qa.Man.9@PlanetStarSiege.Com

http://home.att.net/~qa.man.9/
http://207.199.1.116/Balance

// To run a server

1. Make a folder called 'BOP' under your Tribes directory.
2. Unzip BOP.zip to this newly created folder.
3. Modify your Tribes shortcut to run 'Tribes.exe -mod BOP'.
	a. to modify your shortcut - right click on the tribes icon, choose properties,
		and add -mod BOP after tribes.exe in the target 
4. Start a server.

// To run a dedicated server

1. Same as above, except run 'infinitespawn *tribes -mod BOP -dedicated'
	
// To check out the changes offline

1. Setup same as to run a server.
2. Host a game offline.
Note: if your Internet connection program try's to start itself when you start an internet game, you need to shut this off before hosting a game offline, or it will stall Tribes. If you cannot do this, hit alt+enter to switch to the program during a game and manually close your connection window(you might have to do this several times).

GIVE ME A JOB IN THE GAME INDUSTRY AND I WILL ETERNALLY LOVE YOU!

I test medical software, but have always wanted to work with games. Ive been playing since space invaders ($65 back then) on the atari, til the present, and have an intermediate knowledge of programming. I also can find bugs in any software - havent found a game yet that didnt have bugs( or things not quite right ). Did you know in Tribes if you run exactly over a hill joint angle and go back and look at your footprints, you can see half of one on the hill and the other angled into the air?

Thanks...

Credits are now on my webpage... the list is getting big.

If you would like to use my code in your mods, or are wondering how I did something, email me and I'll send you txt files of all the positions in normal cs's that I changed. The bop?????.cs, and My????.cs files have all my code, except for the additions to the normal ones.

