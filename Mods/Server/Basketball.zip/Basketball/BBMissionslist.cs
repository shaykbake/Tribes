//football missions only
exec(missionlist);
MissionList::clear();
Missionlist::initNextMission();
$pref::lastmission = "Official_BballStadium7"; //first mission to launch when you startup

//Missionlist: order in reverse alphabetical here to make them alpha in the menu
MissionList::addMission("Official_BballStadium10");
MissionList::addMission("Official_BballStadium9");
MissionList::addMission("Official_BballStadium8");
MissionList::addMission("Official_BballStadium7");
MissionList::addMission("Official_BballStadium6");
MissionList::addMission("Official_BballStadium5");
MissionList::addMission("Official_BballStadium4");
MissionList::addMission("Official_BballStadium3");
MissionList::addMission("Official_BballStadium2");
MissionList::addMission("Official_BballStadium1");
MissionList::addMission("BasketBall");

//Rotation paradigm: $nextMission["CURRENT"] = "NEXT";
$nextMission["Official_BballStadium1"] = "Official_BballStadium2";
$nextMission["Official_BballStadium2"] = "Official_BballStadium3";
$nextMission["Official_BballStadium3"] = "Official_BballStadium4";
$nextMission["Official_BballStadium4"] = "Official_BballStadium5";
$nextMission["Official_BballStadium5"] = "Official_BballStadium6";
$nextMission["Official_BballStadium6"] = "Official_BballStadium7";
$nextMission["Official_BballStadium7"] = "Official_BballStadium8";
$nextMission["Official_BballStadium8"] = "Official_BballStadium9";
$nextMission["Official_BballStadium9"] = "Official_BballStadium10";
$nextMission["Official_BballStadium10"] = "Official_BballStadium1";
//last rotation map should always point back to the first.