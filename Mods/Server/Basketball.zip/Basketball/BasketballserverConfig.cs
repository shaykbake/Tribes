$Server::HostName = "Server Name here";//***change***
$Server::MaxPlayers = "8"; 
$Server::HostPublicGame = "True";
$Server::Info = "Server Name Here\nAdmin: Owner (owners email)\nMod info: http://freewebs.com/yttikeht/bballmod.zip"; 

//displays as the player connects to the server
$MODInfo = "<f0>It's Football--Tribes style!\n\n<f1>'' Meow. ''  --Kitty";

//displays after they connect but before they join a team.
//MAXIMUM 71 CHARS PER MOTD STRING
$Server::JoinMOTD = "<f1><jc>Welcome to Server\n<f2>nWelcome to server.";//***change***

$TCTimer = 10; //cannot change teams for this long (seconds) after any team change
$VoteAdminAllowed = false; //vote admin function on or off
$HPM = false; //toggles hot patato mode
$HPTime = 15; //time a person has to pass before punishment
$SmurfTracker = true;
$gunFumbleChance = 50;
$RanAssign = 3;
$InfJet = false;
$TATD = true; //toggles if tackle after TD is on or off (false is off)
$SecondConnectingMessage = "<f1>\nHEY!!!!";
$CycleOnEmpty = false; //cycles mission when last player leaves server

$Server::Port = "28001";
$Server::Password = "";
$Server::TimeLimit = "5"; //this is for each half
$Server::AutoAssignTeams = "True";
$Server::TourneyMode = "False";
$Server::TeamDamageScale = "0";
$SuperAdminPassword = "changeme";//***change***
$AdminPassword = "changeme";//***change***
$Server::warmupTime = 20;
$Server::respawnTime = 1;
$Server::VotingTime = 15;
$Server::VoteWinMargin = 0.80;
$telnetport = "11111";//***change***
$telnetpassword = "changemetoo";//***change***
$pref::PacketRate = "15"; //lower to 10 for modem players
$pref::PacketSize = "300"; //lower to 200 for modem players

//Team names and skins
$Server::teamSkin0 = "beagle";
$Server::teamName0 = "Cats";//***change***
$Server::teamSkin1 = "blue"; 
$Server::teamName1 = "Dogs";//***change***
$Server::teamSkin2 = "purple";
$Server::teamName2 = "Elks";//***change***
$Server::teamSkin3 = "green"; 
$Server::teamName3 = "The Gays";//***change***
$Server::teamSkin4 = "orange";
$Server::teamName4 = "I Dont Know";//***change***
$Server::teamSkin5 = "dsword"; 
$Server::teamName5 = "Damnit!!";//***change***
$Server::teamSkin6 = "swolf";
$Server::teamName6 = "Browns";//***change***
$Server::teamSkin7 = "cphoenix"; 
$Server::teamName7 = "reds";//***change***

//Additional Code
$console::logmode=0; //set to 0 if you want NO LOG
exec("BBMissionslist");