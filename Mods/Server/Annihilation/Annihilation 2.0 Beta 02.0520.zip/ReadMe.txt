Annihilation 2.0 BETA
Build: 20.05.02

(bundled with some Plasmatic maps)

Fixed small admin bug,
Added $Annihilation::BaseHeal variable to annihilation.cs
Added jump pads and teleporters to mission editor.


Rename existing annihilation.cs to annihilation_old.cs (or something like that).
Delete existing scripts.vol.

Extract new files over top of old file locations.

Change your server execute line from 

Tribes\InfiniteSpawn.exe *28001Tribes.exe -mod annihilation +exec serverConfig.cs -dedicated
to
Tribes\InfiniteSpawn.exe *28001Tribes.exe -mod annihilation -dedicated

(Get rid of the "+exec serverConfig.cs")

We have moved all server settings and configurations to annihilation.cs.
This will allow much easier server changes from one mod to another mod.
This will also help to prevent mod conflict over common configuration files.

Be sure to edit annihilation.cs and annihilationAdminList.cs

-Plasmatic & Sevnn