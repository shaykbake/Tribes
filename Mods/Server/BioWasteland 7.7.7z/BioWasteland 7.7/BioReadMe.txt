
If you are trying to run a dedicated server, double click on the biowasteland.bat file.

Customize your server by changing options in the Wasteland.cs file

While running a dedicated server, you won't see much except a dos window.  Its best to connect to your dedicated server from a different PC.


B�ohazard
biohazard@exploratoriums.com
www.exploratoriums.com


See the maps included called Example to learn how to make these exciting new mission types:

1.  Capture Energy
2.  Bone Collector
3.  Vehicle Capture
4.  Free-For-All Team DM
5.  Elimination
6.  Racing
7.  Duel
8.  Boxing
9.  Titan
10. Smear the Flag