Dynamix Plus MOD version 1.1 for Tribes v. 1.11 and higher
(C) 2000 Dynamix, Inc.
					  
Rebalanced Tribes gameplay MOD

Features:

Reduced (capped) ski velocities
Increased chaingun spread
Temporary respawn invulnerability (controlled by $Server::respawnInvulnerableTime)
Temporary respawn no weapon
Longer range on mortar, ELF and repair pack
Mines take more damage to destroy before deployed
Shields on vehicle pads
Faster and tougher medium armor
Faster and tougher vehicles
ELF spam fix
Flag return fixes
Team player count added to tab score list
