$modList = "ANARCHY";
//Connect message to be displayed during initial loadup... I'm so modest..
$plasmatic = "\nVisit My Website at Plasmatica.cjb.net";
//Tricon and some admin programs need a port and password to work with.
$TelnetPort="";
$TelnetPassword="";
$pref::PacketRate = "10";
$pref::PacketSize = "200";
$Anarchy::BanKickTime = "1800";
$Anarchy::fairTeams = "false";
$Anarchy::PABan = "false";
$Anarchy::PAKick = "false";
$Anarchy::PAMission = "true";
$Anarchy::PAModOptions = "true";
$Anarchy::PAResetDefaults = "true";
$Anarchy::PATeamChange = "true";
$Anarchy::PATeamDamage = "true";
$Anarchy::PATeamInfo = "true";
$Anarchy::PATimelimit = "true";
$Anarchy::PATourneyMode = "false";
$Anarchy::PAVote = "false";
$Anarchy::tkClientLvl = "3";
$Anarchy::tkLimit = "5";
$Anarchy::tkMultiple = "3";
$Anarchy::tkServerLvl = "3";
$Anarchy::Spawnclass = "false";

//logs the name and IP of everyone who connects, to config\\Connect.log
$ConnectLog = true; 

//log people who are kicked by admins, to config\\KickList.log
$ExportAKicks = true; 

//log people who are kicked by the computer, to config\\KickList.log
$ExportCKicks = true; 

//What you want it to say when an admin kicks a client, this is a centerprint message
//The "\n" will seperate lines of text on the screen... Example....
$Admin::KickMessage = "For being a complete Idiot, and total moron.....\n\n You are being kicked off of this server. \n\n Come back when you no longer have an attack of the STUPIDS.";

//If you want to use personal skins.  The skins must be installed in the
//tribes\base\skins directory on the server, and on the client side
$Anarchy::PersonalSkin = "true"; 

//When set to true, no one can blow you out of ANY stations
//I wouldn't set this unless you have the station kick on also.
//Without the station kick, they can tie up a station for the rest of the game
//if they want, and nothing will blow them out!!
//If the person gets blocked in so that the station kick function can't
//kick them out, THEN you can shoot them out of the station, but not before.
$StationLockTD = "false";  // no knock from station with teamdamage off
$StationLockNTD = "true";  // no knock from station with teamdamage on

//How long the server will wait before ejecting someone out of a inventory station
$Anarchy::StationTime = "60";  //range is 20-60

$PA::noKick = "True";  //if set to true, public admins cant be kicked by a vote

//If you have someone that you dont want to give admin status too, but dont want
//them to be kicked off of the server by VOTE or Public Admin, put their name in the quotes "".
$Name::noKicka = "";  //name of the client that you dont want to be kicked
$Name::noKickb = "";
$Name::nokickc = "";
$Name::nokickd = "";

//Special message for the owner when you gain super admin
//status with the SAD code..... no big deal, I was bored
$Owner::Name = ""; 

//gives you God admin status with a SAD password 
//by typing sad(BETTERchangeMEidiot);
//This is not something that you want to give everyone, 
//it is for the owner of the server only.
$OwnerPassword = "BETTERchangeMEidiot"; 

$PublicPassword = "BETTERchangeMEidiot";  //public admin sad code
$AdminPassword = "BETTERchangeMEidiot";   //super admin sad code
