//=============================================================================================================================
// Server Parameters
$Server::HostName = "Annihilation X";		// Server Name
$Server::Port = "28001";			// Port used for client connections to server (usually 28001)
$Server::HostPublicGame = true;			// Server is shown in MasterServer List
$Server::Password = "";				// Password needed to join server
$AdminPassword = "password";			// Local SuperAdmin password - CHANGE THIS


//=============================================================================================================================
// Server Info Parameters (<jc> = center justified, <f1> = tan font, <f2> = white font, <f3> = orange font, \n = new line)
// Server information listed on MasterServer List
$Server::Info = "Annihilation Mod\nAdmin: \nEmail: ";
// Information listed on server join screen					
$Server::MODInfo = "<jc><f1>Annihilation Mod is now available.\n<f3>Please the official website <f1>www.zerovoid.net";
// Message of the day listed once connected to the server					
$Server::JoinMOTD = "<jc><f2>WELCOME, <f3>This is Annihilation Mod, public beta.\nPlease the official website <f1>www.zerovoid.net\n<f2>    ENJOY!!!";


//=============================================================================================================================
// Telnet (Console) Parameters
$TelnetPort="23";				// Port for telnet connections
$TelnetPassword="password";			// Password for telnet connections - CHANGE THIS


//=============================================================================================================================
// Server Connection Parameters
$pref::PacketRate = 12;				// Packet rate for client connections
$pref::PacketSize = 200;			// Packet size for client connections
$pref::LastMission = "Raindance";		// This sets the first map in rotate when server launches (make sure it is spelled correctly)


//=============================================================================================================================
// Player Parameters
$Server::MaxPlayers = "10";			// Maximum number of client connections allowed
$Server::AutoAssignTeams = true;		// Server assigned teams
$Server::respawnTime = 2; 			// Number of seconds before a respawn is allowed
$Server::TimeLimit = 30;			// Mission time limit in minutes
$Server::warmupTime = 20;			// Time (in seconds) players are left standing before movement is allowed

//=============================================================================================================================
// Team Parameters
$Server::teamName[0] = "Attrition";		// Team 1 Name
$Server::teamSkin[0] = "beagle";		// Team 1 Skin
$Server::teamName[1] = "Regression";		// Team 2 Name
$Server::teamSkin[1] = "dsword";		// Team 2 Skin
$Server::teamName[2] = "Subversion";		// Team 3 Name
$Server::teamSkin[2] = "cphoenix";		// Team 3 Skin
$Server::teamName[3] = "Downfall";		// Team 4 Name
$Server::teamSkin[3] = "swolf";			// Team 4 Skin
$Server::teamName[4] = "Generic 1";		// Team 5 Name
$Server::teamSkin[4] = "base";			// Team 5 Skin
$Server::teamName[5] = "Generic 2";		// Team 6 Name
$Server::teamSkin[5] = "base";			// Team 6 Skin
$Server::teamName[6] = "Generic 3";		// Team 7 Name
$Server::teamSkin[6] = "base";			// Team 7 Skin
$Server::teamName[7] = "Generic 4";		// Team 8 Name
$Server::teamSkin[7] = "base";			// Team 8 Skin


//=============================================================================================================================
// Voting Parameters
$Server::MinVoteTime = 45;			// Time allotted for voting
$Server::VotingTime = 20;			// Length of votes if people are voting.
$Server::VoteWinMargin = 0.6999;		// Ratio of Yes to No votes needed to pass
$Server::VoteAdminWinMargin = 0.6999;		// Ratio of Yes to No votes needed to pass
$Server::MinVotes = 1;				// Minimum number of votes needed to pass
$Server::MinVotesPct = 0.5;			// Percentage of available votes needed to pass a vote
$Server::VoteFailTime = 30; 			// 30 seconds if your vote fails + $Server::MinVoteTime


//==============================================================================================================================
// Other Parameters
$Server::TeamDamageScale = 0;			// Team damage, 0 = Off, 1 = On
$Server::TourneyMode = false;			// Tournament mode