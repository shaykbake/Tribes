//=============================================================================================================================
// Annihilation Parameters
$Annihilation::NetMask = "IP:192.168.1";	// This is used to increase server player limit when local LAN players connect.
$Annihilation::ShoppingList = true;		// Set to true to limit item shopping list to display only items available for current armor.
$Annihilation::ResetServer = true;		// Set to true to rotate server to next map in list when last player leaves.
$Annihilation::KickTime = 180;			// Time (in seconds) for kicks.
$Annihilation::BanTime = 1800;			// Time (in seconds) for bans.
$Annihilation::StationTime = 20;		// Time allowed for Station Access.

//=============================================================================================================================
// SuperAdmin Passwords, Up to 100 are available
$Annihilation::SADPassword[1] = "";
$Annihilation::SADPassword[2] = "";
$Annihilation::SADPassword[3] = "";
$Annihilation::SADPassword[4] = "";
$Annihilation::SADPassword[5] = "";

//=============================================================================================================================
// Public Admin Passwords, Up to 100 are available
$Annihilation::PAPassword[1] = "";
$Annihilation::PAPassword[2] = "";
$Annihilation::PAPassword[3] = "";
$Annihilation::PAPassword[4] = "";
$Annihilation::PAPassword[5] = "";
