//
// Happy Mod2 Breaker copywrite 2003, 2004
// by Plasmatic aka Steve Madden
// www.annihilation.info 
// ziptiezmail@netscape.net
// Feel free to use this, provided you leave these lines at the top
// This code will create 8 - 16 fake flags and players,
// and shuffle them around clients in the game.
//
// The best way to discourage match players using HM2 is to require them to record demo, 
// then review with Happy Mod2 running, Cheaters will look or shoot at the fake players,
// and chase fake flags...
// 
// -Plasmatic


// Advanced Usage:
// Code from this file can be placed anywhere in the mod it will get executed. This file can also 
// 	Open Game.cs and locate function Game::startMatch(). Add this to the end of the function.
//	code: 
//	--------------------------------------------------------------------------------
//	   if($Annihilation::HappyBreaker) 
//	      HappyBreaker::CreateStuff(); 
//	--------------------------------------------------------------------------------
//	
//	
// 	Add this to your mods setup cs file, or to autoexec.cs in the config directory.
//	code: 
//	--------------------------------------------------------------------------------
//	$Annihilation::HappyBreaker = true; 
//	--------------------------------------------------------------------------------
//	


$Happy::Time = 15;	// shuffle time + 0~15 random
$Happy::Dist = 750;	// random distance around clients

ItemImageData HappyFlagImage
{
	shapeFile = "flag";
	mountPoint = 2;
	mountOffset = { 0, 0, -0.35 };
	mountRotation = { 0, 0, 0 };
	lightType = 2; // Pulsing
	lightRadius = 4;
	lightTime = 1.5;
	lightColor = { 1, 1, 1};
};

ItemData HappyFlag
{
	description = "Flag";
	shapeFile = "flag";
	imageType = FlagImage;
	showInventory = false;
	shadowDetailMask = 4;
	validateShape = true;
	lightType = 2; // Pulsing
	lightRadius = 0.0;
	lightTime = 1.5;
	lightColor = { 1, 1, 1 };
};

TurretData HappyStand 
{	
	className = "Turret";
	shapeFile = "camera";
	maxDamage = 2500;
	maxEnergy = 10;
	speed = 20;
	speedModifier = 1.0;
	range = 0.0;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	visibleToSensor = true;
	shadowDetailMask = 4;
	castLOS = true;
	supression = false;
	supressable = false;
	mapFilter = 2;
	mapIcon = "M_camera";
	debrisId = defaultDebrisSmall;
	FOV = 0.707;
	pinger = false;
	explosionId = debrisExpMedium;
	description = "HappyStand";
};

function HappyStand::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
	//do nothing, no damage..
}
PlayerData HappyJack
{
	className = "Armor";
	shapeFile = "larmor";
	damageSkinData = "armorDamageSkins";
	debrisId = playerDebris;
	flameShapeName = "enex";	
	shieldShapeName = "shield";
	shadowDetailMask = 1;
	visibleToSensor = false;
	mapFilter = 1;
	mapIcon = "M_player";
	canCrouch = true;
	maxJetSideForceFactor = 0.0;
	maxJetForwardVelocity = 0;
	minJetEnergy = 1;
	jetForce = 0;
	jetEnergyDrain = 0.8;
	maxDamage = 500.0;
	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxSideSpeed = 0;
	groundForce = 40 * 9.0;
	mass = 9.0;
	groundTraction = 3.0;
	maxEnergy = 60;
	drag = 1.0;
	density = 1.2;
	minDamageSpeed = 25;
	damageScale = 0.0;
	jumpImpulse = 0;
	jumpSurfaceMinDot = 0.2;
	animData[0] = { "root", none, 1, true, true, true, false, 0 };
	animData[1] = { "run", none, 1, true, false, true, false, 3 };
	animData[2] = { "runback", none, 1, true, false, true, false, 3 };
	animData[3] = { "side left", none, 1, true, false, true, false, 3 };
	animData[4] = { "side left", none, -1, true, false, true, false, 3 };
	animData[5] = { "jump stand", none, 1, true, false, true, false, 3 };
	animData[6] = { "jump run", none, 1, true, false, true, false, 3 };
	animData[7] = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[8] = { "crouch root", none, 1, true, true, true, false, 3 };
	animData[9] = { "crouch root", none, -1, true, true, true, false, 3 };
	animData[10] = { "crouch forward", none, 1, true, false, true, false, 3 };
	animData[11] = { "crouch forward", none, -1, true, false, true, false, 3 };
	animData[12] = { "crouch side left", none, 1, true, false, true, false, 3 };
	animData[13] = { "crouch side left", none, -1, true, false, true, false, 3 };
	animData[14] = { "fall", none, 1, true, true, true, false, 3 };
	animData[15] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[16] = { "landing", SoundLandOnGround, 1, true, false, false, false, 3 };
	animData[17] = { "tumble loop", none, 1, true, false, false, false, 3 };
	animData[18] = { "tumble end", none, 1, true, false, false, false, 3 };
	animData[19] = { "jet", none, 1, true, true, true, false, 3 };
	animData[20] = { "PDA access", none, 1, true, false, false, false, 3 };
	animData[21] = { "throw", none, 1, true, false, false, false, 3 };
	animData[22] = { "flyer root", none, 1, false, false, false, false, 3 };
	animData[23] = { "apc root", none, 1, true, true, true, false, 3 };
	animData[24] = { "apc pilot", none, 1, false, false, false, false, 3 };
	animData[25] = { "crouch die", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[26] = { "die chest", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[27] = { "die head", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[28] = { "die grab back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[29] = { "die right side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[30] = { "die left side", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[31] = { "die leg left", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[32] = { "die leg right", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[33] = { "die blown back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[34] = { "die spin", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[35] = { "die forward", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[36] = { "die forward kneel", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[37] = { "die back", SoundPlayerDeath, 1, false, false, false, false, 4 };
	animData[38] = { "sign over here", none, 1, true, false, false, false, 2 };
	animData[39] = { "sign point", none, 1, true, false, false, true, 1 };
	animData[40] = { "sign retreat",none, 1, true, false, false, false, 2 };
	animData[41] = { "sign stop", none, 1, true, false, false, true, 1 };
	animData[42] = { "sign salut", none, 1, true, false, false, true, 1 };
	animData[43] = { "celebration 1",none, 1, true, false, false, false, 2 };
	animData[44] = { "celebration 2", none, 1, true, false, false, false, 2 };
	animData[45] = { "celebration 3", none, 1, true, false, false, false, 2 };
	animData[46] = { "taunt 1", none, 1, true, false, false, false, 2 };
	animData[47] = { "taunt 2", none, 1, true, false, false, false, 2 };
	animData[48] = { "pose kneel", none, 1, true, false, false, true, 1 };
	animData[49] = { "pose stand", none, 1, true, false, false, true, 1 };
	animData[50] = { "wave", none, 1, true, false, false, true, 1 };
	jetSound = SoundJetLight;
	rFootSounds = { SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRHard, SoundLFootRSnow, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft, SoundLFootRSoft };
	lFootSounds = { SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLHard, SoundLFootLSnow, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft, SoundLFootLSoft };
	footPrints = { 0, 1 };
	boxWidth = 0.7;
	boxDepth = 0.7;
	boxNormalHeight = 2.2;
	boxCrouchHeight = 1.8;
	boxNormalHeadPercentage = 0.83;
	boxNormalTorsoPercentage = 0.53;
	boxCrouchHeadPercentage = 0.6666;
	boxCrouchTorsoPercentage = 0.3333;
	boxHeadLeftPercentage = 0;
	boxHeadRightPercentage = 1;
	boxHeadBackPercentage = 0;
	boxHeadFrontPercentage = 1;
};

function HappyBreaker::CreateStuff()
{
	%Group = newObject("HappyFakes", SimGroup);
	addToSet("MissionCleanup", %Group);		
	%Group = newObject("HappyStands", SimGroup);
	addToSet("MissionCleanup", %Group);	
	if (getNumClients() < 8)
		%itemCount = 8;
	else
		%itemCount = 8 + floor(getNumClients()/4);
		
	for (%i=0; %i < %itemCount; %i++)
	{
		//create Fakey dude
		%aiName = getword("Happy Asshole Cheat BozoMaster Wildone Tim Tatters Wildwoman Newbits cheatingslut happywhore Discman Slayer Peterpuller DaJackel TheCheat Master Suckit",%i);//
		if(AI::spawn( %aiName, "HappyJack", %spawnPos, %spawnRot,%aiName, "male2" ))	
		{
			%aiId = AI::getId(%aiName);	//return cl#
			%player = Client::getOwnedObject(%aiId);
			GameBase::startFadeOut(%player);
			addtoset("MissionCleanup/HappyFakes", %player);
			GameBase::setDamageLevel(%player, floor(getrandom() * 400));					
		}
	
		//create Fakey flag
		%flagobj = newobject("flag1", "item", "HappyFlag", 1, false);
		addtoset("MissionCleanup/HappyFakes", %flagobj);
	}
	schedule("HappyBreaker::PickRandomPos();",$Happy::Time);
}


function HappyBreaker::PickRandomPos()
{
	%clients = getnumclients()-1;
	if(%clients != -1)
	{
		//delete old stands
		%simset = nameToID("MissionCleanup/HappyStands");
		for(%i = 0; (%o = Group::getObject(%simset, %i)) != -1; %i++)
		{
			deleteobject(%o);		
		}		
		%simset = nameToID("MissionCleanup/HappyFakes");
		for(%i = 0; (%object = Group::getObject(%simset, %i)) != -1 ; %i++)
		{			
			if($Happy::ClientIndex > %clients)
				$Happy::ClientIndex = 0;
			%client = getClientByIndex($Happy::ClientIndex);
			%clPos = gamebase::getposition(%client);
			%try = 0;
			%continue = "";
			while(!%continue && %try < 10)
			{
				%try++;
				%newpos = vector::add(%clPos,(getrandom()-0.5)*$Happy::Dist @" "@(getrandom()-0.5)*$Happy::Dist @ " 0");	
				%continue = HappyBreaker::CheckVertical(%newpos,%object);
				//echo("Moving Object "@%i@" "@%object@" around "@%client@" try "@%try);	
			}
			$Happy::ClientIndex++;
		}
	}
	%Shuffle = $Happy::Time + getrandom()*15;
	schedule("HappyBreaker::PickRandomPos();",%Shuffle);
}


function HappyBreaker::CheckVertical(%pos,%object)
{
	//looking up..  -plasmatic	
	%camera = newObject("Camera","Turret",HappyStand,true);
	addtoset("MissionCleanup/HappyStands", %camera);
	GameBase::setPosition(%camera,vector::add(%pos,"0 0 -3000"));
	GameBase::startFadeOut(%camera);
	if(GameBase::getLOSInfo(%camera,5000,"1.5708 0 0"))
	{	
		// GetLOSInfo sets the following globals:
		// 	los::position
		// 	los::normal
		// 	los::object		
		%name = getObjectType($los::object);
		if(%name == SimTerrain)
		{
			%newPos = vector::add($los::position,"0 0 -3.5");//players are 2.2m tall -plasmatic
			GameBase::setPosition(%camera,%newPos);
			Item::setVelocity(%object,"0 0 0");
			GameBase::setPosition(%object,%newPos);
			return true;
		}
			
	}
	deleteobject(%camera);
	return false;	
}

