$MsgTypeSystem = 0;
$MsgTypeGame = 1;
$MsgTypeChat = 2;
$MsgTypeTeamChat = 3;
$MsgTypeCommand = 4;

//if(!String::ICompare(Client::getGender(%killerId), "Male"))
//String::convertSpaces($NM::missionName);
//%strIndex = String::findSubStr(%voiceSet, ".whello.wav");
//%voiceBase = String::getSubStr(%voiceSet, 0, %strIndex);
//!String::NCompare(%address, "LOOPBACK", 8)
//if(string::getsubstr(%message, 7, String::lenfrom(%message,7))
//


function Ann::StrLen(%string) 
{ 
	for(%i=0; String::getSubStr(%string, %i, 1) != "";%i++) 
	%length = %i; 
	%length++; 
	return %length; 
} 

//plasmatic
function Ann::Replace(%string, %search, %replace)
{
	%len = Ann::StrLen(%search);
	for (%i = 0; (%char = String::getSubStr(%string, %i, %len)) != ""; %i++)
	{
		if (%char @ "s" == %search @ "s") %string = String::getSubStr(%string, 0, %i) @ %replace @ String::getSubStr(%string, %i + %len, 255);
	}
	return %string;
}

// 1337 speek -Plasmatic, idea from A_Newbie
function Ann::leetSpeek(%string)
{
	%norm = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	%leet = "48(d3f9h1jk1mn0PQR57uvwxyz@6cD3F9hiJk|Mn0pqr$+uvWXy2";
	for(%i = 0; %i < 52; %i = %i + 1)
	{
		%rem = String::getSubStr(%norm, %i, 1);
		%new = String::getSubStr(%leet, %i, 1);
		%string = Ann::Replace(%string, %rem, %new);		
	}
	%string = Ann::Replace(%string, "y0u", "j00");
	return %string;	
}


//plasmatic 3.0 
function Ann::Clean::string(%string)
{
	//anti hack crap. -give it up you wankers.. -Plas
	if(String::findSubStr(%string, "\t") >= 0 || String::findSubStr(%string, "\t") >= 0 || String::findSubStr(escapeString(%string), "\\x") >= 0)  
	{
		//sigh... 
		for (%i = 0; (%char = String::getSubStr(%string, %i, 1)) != ""; %i++)
		{
			if(%char == "\t" || %char == "\n") 
				%string = String::getSubStr(%string, 0, %i) @ "!" @ String::getSubStr(%string, %i + 1, 255);	
			else if(String::findSubStr(escapeString(%char), "\\x") == 0)
				%string = String::getSubStr(%string, 0, %i) @ "?" @ String::getSubStr(%string, %i + 1, 255);	
		}
	}
	return %string;
}


function remoteSay(%clientId, %team, %message)
{
	
	%message = Ann::Clean::string(%message);	// Strip out funk. plas 3.0
	%team++;
	%team--;
	
	if(string::getsubstr(%message, 0, 1) == "#" && (%clientId.isAdmin || %clientId.isUntouchable) && $build) // Allow a lil fun..
	{
		%player = Client::getOwnedObject(%clientId);
		echo(%clientId@" using object deploy..");
		if(GameBase::getLOSInfo(%player,500)) 
		{
			if(String::findSubStr(%message,".dis") > 4)
			{
				%prot = GameBase::getRotation(%player);
				%shape = String::getSubStr(%message, 1, 50);//assuming its a shape
				echo("dis "@%shape);
				%obj = newObject(%name,InteriorShape,%shape);
				GameBase::startFadeIn(%obj);
				echo("Create Shape: "@ %shape @ " object#: " @ %obj);
				addToSet("MissionCleanup", %obj);
				GameBase::setPosition(%obj,$los::position);
				GameBase::setRotation(%obj,%prot);	
			}
		}	
	}	
		
	
	for(%i = 0; (%word = getWord(%message, %i)) != -1; %i++)
	{
		if(String::findSubStr(%word, "god") == 0)
			%blasphemyg = true;
		if(String::findSubStr(%word, "damn") == 0)
			%blasphemyd = true;	
		if(%blasphemyg && %blasphemyd)
		{
			remoteKill(%clientId);
			%message = "I have been struck down for my sin of blasphemy!";
			//return;
		}				
	}

	if(%clientId.silenced)
	{
		Client::sendMessage(%clientId, 1, "You are silenced. sorry...~wfemale2.wsorry.wav");
		return true;
	}

	if(%clientId.noKpack)
	{
		%curTime = getSimTime();
		if(%curTime - %clientId.LastKillTime < 1)
		{
			//Client::sendMessage(%clientId, 1, "You are an imbecile. sorry...~wfemale2.wsorry.wav");
			return true;
		}
	}	

	// check for flooding if it's a broadcast OR if it's team in FFA
	if($Server::FloodProtectionEnabled && (!$Server::TourneyMode || !%team) && !%clientId.isSuperAdmin) // Allow Super Admins to Flood Messages
	{
		// we use getIntTime here because getSimTime gets reset.
		// time is measured in 32 ms chunks... so approx 32 to the sec
		%time = getIntegerTime(true) >> 5;
		if(%clientId.floodMute)
		{
			%delta = %clientId.muteDoneTime - %time;
			if(%delta > 0)
			{
				Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for " @ %delta @ " seconds.");
				return true;
			}
			%clientId.floodMute = "";
			%clientId.muteDoneTime = "";
		}
		%clientId.floodMessageCount++;
		// funky use of schedule here:
		schedule(%clientId @ ".floodMessageCount--;", 5, %clientId);
		if(%clientId.floodMessageCount > 4)
		{
			%clientId.floodMute = true;
			%clientId.muteDoneTime = %time + 10;
			Client::sendMessage(%clientId, $MSGTypeGame, "FLOOD! You cannot talk for 10 seconds.");
			return true;
		}
	}
	
	
	//seperate message and sound if present -plasmatic
	if(String::findSubStr(%message, "~w")>0)
	{
		if(%clientId.noVpack)
		{
			Client::sendMessage(%clientId, 1, "Your sound pack is broken. sorry...~wfemale2.wsorry.wav");
			return true;
		}	
		else if(%clientId.BlockMySound)
		{
			%message = "(You have disabled your sound pack): " @%message;
			Client::sendMessage(%clientId, 1, %message, %clientId);
			return true;
		}	
		%pos = String::findSubStr(%message, "~w");
	//	if(%pos > 0)
	//	{
			%sound = string::getSubStr(%message, %pos, 25);	
			%message = string::getSubStr(%message, 0, %pos);
			//echo("Split sound: "@%message@" "@%sound);
	//	}		
	}
			
	if($leet || %clientId.leet)	
		%message = Ann::leetSpeek(%message);
			
	

	if(string::getsubstr(%message, 0, 1) == "@") 
	{
		%message = string::getsubstr(%message, 1, 999);
		%message = Ann::leetSpeek(%message);
	}
	
	%message = %message @ %sound;	
		
	if(string::getsubstr(%message, 0, 1) == "!" && %clientId.isAdmin) // Allow Admins to Bottom and Center print messages
	{
		if(string::getsubstr(%message, 1, 1) == "!" && %clientId.isAdmin)
		{
			%message = string::getsubstr(%message, 2, 999);
			centerprintall("<jc><f2>" @ %message, 8);
			return true;
		}
		else
		{
			%message = string::getsubstr(%message, 1, 999);
			bottomprintall("<jc><f2>" @ %message, 8);
			return true;
		}
	}
	if(string::getsubstr(%message, 0, 1) == "=" && string::getsubstr(%message, 1, 1) != "") // Whisper Talking
	{
		if(%clientId.whisper != "" && (Client::getTeam(%clientId) != -1 || %clientId.isAdmin)) 
		{
			if(%clientId.isAdmin) 
			{
				if(string::getsubstr(%message, 1, 1) == "!" && %clientId.isSuperAdmin) 
				{
					%message = string::getsubstr(%message, 2, 999);
					centerprint(%clientId.whisper, "<jc><f0>" @ Client::getName(%clientID) @ " (private): <f1>" @ %message, 8);
				}
				Client::sendMessage(%clientId.whisper, $MsgTypeChat, Client::getName(%clientID) @ " (private): " @ %message);
				Client::sendMessage(%clientId, $MsgTypeChat, Client::getName(%clientID) @ " (to " @ Client::getName(%clientId.whisper) @ "): " @ %message);
			}
			else if((Client::getTeam(%clientId) != -1 || $Game::missionType == "Duel") && !(%clientId.whisper).muted[%clientId]) 
			{
				if(!(%clientId.whisper).isSuperAdmin && Client::getTeam(%clientId) != Client::getTeam(%clientId.whisper))
					cheatAdminMsg(Client::getName(%clientID)@" (to "@Client::getName(%clientId.whisper)@"): "@%message);
				if(!(%clientId.whisper).isSuperAdmin && $listen[%clientId] != "")
					Client::sendMessage($listen[%clientId], 1, Client::getName(%clientID)@" (to "@Client::getName(%clientId.whisper)@"): "@%message);
				Client::sendMessage(%clientId.whisper, $MsgTypeChat, Client::getName(%clientID)@" (private): "@%message);
				Client::sendMessage(%clientId, $MsgTypeChat, Client::getName(%clientID)@" (to "@Client::getName(%clientId.whisper)@"): "@%message);
			}
		
			echo("SAY: " @ %clientId @ " \""@Client::getName(%clientID)@" (to "@Client::getName(%clientId.whisper)@"): "@%message@"\"");
			return true;
		}
	}
	%msg = %clientId @ " \"" @ %message @ "\" : " @ Client::getName(%clientID)@", "@timestamppatch();
	if(%team)
	{
		if($dedicated)
			echo("SAYTEAM: " @ %msg);						
		%team = Client::getTeam(%clientId);
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
			if(Client::getTeam(%cl) == %team && !%cl.muted[%clientId])
				Client::sendMessage(%cl, $MsgTypeTeamChat, %message, %clientId);
	}
	else
	{	
		if($dedicated)
			echo("SAY: " @ %msg);
         	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
			if(!%cl.muted[%clientId])
				Client::sendMessage(%cl, $MsgTypeChat, %message, %clientId);
	}
	return true;	
}

function remoteIssueCommand(%commander, %cmdIcon, %command, %wayX, %wayY, %dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14)
{
	if(!evalspam(%commander))
		return;	//plasm 3.0
			
	if($dedicated)
		echo("COMMANDISSUE: " @ %commander @ " \"" @ Ann::Clean::string(%command) @ "\"");
		
	if($debug)
		echo("remote Issue Command: x,"@%wayX@" y,"@ %wayY);
			
	// issueCommandI takes waypoint 0-1023 in x,y scaled mission area
	// issueCommand takes float mission coords.
	for(%i = 1; %dest[%i] != ""; %i = %i + 1)
		if(!%dest[%i].muted[%commander])
			issueCommandI(%commander, %dest[%i], %cmdIcon, %command, %wayX, %wayY);
}

function remoteIssueTargCommand(%commander, %cmdIcon, %command, %targIdx, %dest1, %dest2, %dest3, %dest4, %dest5, %dest6, %dest7, %dest8, %dest9, %dest10, %dest11, %dest12, %dest13, %dest14)
{
	if(!evalspam(%commander))
		return;	//plasm 3.0
			
	if($dedicated)
		echo("COMMANDISSUE: " @ %commander @ " \"" @ Ann::Clean::string(%command) @ "\"");
	for(%i = 1; %dest[%i] != ""; %i = %i + 1)
		if(!%dest[%i].muted[%commander])
			issueTargCommand(%commander, %dest[%i], %cmdIcon, %command, %targIdx);
}

function remoteCStatus(%clientId, %status, %message)
{
	if(!evalspam(%clientId))
		return;	//plasm 3.0
			
	// setCommandStatus returns false if no status was changed.
	// in this case these should just be team says.
	if(setCommandStatus(%clientId, %status, %message))
	{
		if($dedicated)
			echo("COMMANDSTATUS: " @ %clientId @ " \"" @ Ann::Clean::string(%message) @ "\"");
	}
	else
		remoteSay(%clientId, true, %message);
}

function teamMessages(%mtype, %team1, %message1, %team2, %message2, %message3)
{
	echo("teamMessages "@%mtype@", "@ %team1@", "@ %message1@", "@ %team2@", "@ %message2@", "@ %message3);
	%numPlayers = getNumClients();
	for(%i = 0; %i < %numPlayers; %i = %i + 1)
	{
		%id = getClientByIndex(%i);
		if(Client::getTeam(%id) == %team1)
		{
			Client::sendMessage(%id, %mtype, %message1);
		}
		else if(%message2 != "" && Client::getTeam(%id) == %team2)
		{
			Client::sendMessage(%id, %mtype, %message2);
		}
		else if(%message3 != "")
		{
			Client::sendMessage(%id, %mtype, %message3);
		}
	}
}

function messageAll(%mtype, %message, %filter)
{
	if(%filter == "")
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
			Client::sendMessage(%cl, %mtype, %message);
	else
	{
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		{
			if(%cl.messageFilter & %filter)
				Client::sendMessage(%cl, %mtype, %message);
		}
	}
}

function messageAllExcept(%except, %mtype, %message)
{
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		if(%cl != %except)
			Client::sendMessage(%cl, %mtype, %message);
}

function messageTeam(%client, %color, %msg)
{
	%team = Client::getTeam(%client);
	%numPlayers = getNumClients();
	for(%i = 0; %i < %numPlayers; %i++)
	{
		%cl = getClientByIndex(%i);
		%now = Client::getTeam(%cl);
		if(%team == %now)
		{
			Client::sendMessage(%cl,%color,%msg);
		}
	}
}

function messageTeamExcept(%client, %color, %msg)
{
	%team = Client::getTeam(%client);
	%numPlayers = getNumClients();
	for(%i = 0; %i < %numPlayers; %i++)
	{
		%cl = getClientByIndex(%i);
		%now = Client::getTeam(%cl);
		if((%team == %now) && (%cl != %client))
		{
			Client::sendMessage(%cl,%color,%msg);
		}
	}
}

function messageEnemy(%client, %color, %msg)
{
	%team = Client::getTeam(%client);
	%numPlayers = getNumClients();
	for(%i = 0; %i < %numPlayers; %i++)
	{
		%cl = getClientByIndex(%i);
		%now = Client::getTeam(%cl);
		if(%team != %now)
		{
			Client::sendMessage(%cl,%color,%msg);
		}
	}
}