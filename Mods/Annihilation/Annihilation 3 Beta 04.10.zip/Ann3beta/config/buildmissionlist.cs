MissionList::clear();





MissionList::addMission("Challenge");

MissionList::addMission("Canyoneros");
MissionList::addMission("Blue_Buddha");

MissionList::addMission("1V");
MissionList::addMission("Rollercoaster");
MissionList::addMission("PartyGirl");
MissionList::addMission("Scarabrae");
MissionList::addMission("Scooby_Snack");
MissionList::addMission("Jungle_Gym");

MissionList::addMission("BlackHole");

MissionList::addMission("Raindance");
MissionList::addMission("Broadside");
MissionList::addMission("IceRidge");
MissionList::addMission("Dropzone_2");
MissionList::addMission("Mortum");
MissionList::addMission("Grass_Bowl");
MissionList::addMission("Stonehenge");


MissionList::addMission("Brood");
MissionList::addMission("DangerousCrossing");

$pref::LastMission = "DangerousCrossing";
MissionList::initNextMission();
