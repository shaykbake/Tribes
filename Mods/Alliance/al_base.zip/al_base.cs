echo(">> ");
echo(">> BASE TRIBES");
echo(">> ");