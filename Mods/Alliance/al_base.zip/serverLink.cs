exec(serverBase);

function serverLink::Start()
{
  serverBase::Start();
}

function serverLink::InitializeMission()
{
  serverBase::InitializeMission();
}