exec(serverAlliance);

function serverLink::Start()
{
  serverAlliance::Start();
}

function serverLink::InitializeMission()
{
  serverAlliance::InitializeMission();
}