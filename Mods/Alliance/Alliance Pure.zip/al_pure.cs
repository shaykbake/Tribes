echo(">> ");
echo(">> PURE ALLIANCE");
echo(">> ");