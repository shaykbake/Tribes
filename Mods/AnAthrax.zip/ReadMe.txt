Most of you already know how to host a dedicated server so I wont waste your time....Thanks for downloading my mod and I hope you enjoy it.
Go to www.angelfire.com/on3/anathrax/frames2.html for updates which will be soon to come!

						-AnAThrax