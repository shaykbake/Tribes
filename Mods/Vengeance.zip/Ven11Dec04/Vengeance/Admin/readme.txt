**	
**	Annihilation 3 file ripper instructions:
**
**	ServerAnnihilation.cs will auto-execute anything in this folder alphabetically.
**	The file with the same name as the folder name, if present will be loaded first.
**	Any parent functions should be defined in first file.
**
**	For example. In the weapon folder:
**	Weapon.cs is executed first, then all other .cs files in alphabetical order.
**	Tribes will sort available items in inventory in the order they were defined.
**
**	To add new items:
**	1) Define the item in a .cs file and drop into one of the items folders.
**	2) Add a coresponding line to ServerItemUsage.cs 
**	Simple as that. 
**	As new items are added or modified, the $favorites key will be automatically changed.
**	
**	If you would like to use this as a base for your mod, please ask before release.
**	We may be able to help with distribution, promotion, or debugging
**	If you have questions or comments, I may be reached in the forums at www.annihilation.info
**	-Plasmatic
