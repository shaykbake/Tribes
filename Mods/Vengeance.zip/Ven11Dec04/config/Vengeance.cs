// generic server settings to default to, and 
// Annihilation 2.3 specific settings -Plasmatic

// Basic server settings, no need to mess with these.
$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "US Tribes Master";
$Server::MasterName1 = "UK Tribes Master";
$Server::MasterName2 = "Australian Tribes Master";
$Server::CurrentMaster = 0;
$Server::XLMasterN0 = "IP:209.185.222.237:28000";
$Server::XLMasterN1 = "IP:209.67.28.148:28000";
$Server::XLMasterN2 = "IP:198.74.40.67:28000";
// End important settings. 

//===========================================================================================
// Server Parameters
$Server::HostName = "The Past";	// Server Name
$Server::Port = "28002";			// Port used for client connections to server (usually 28001)
$Server::HostPublicGame = true;			// Server is shown in MasterServer List
$Server::Password = "";				// Password needed to join server.
$AdminPassword = "";				// Local SuperAdmin password - CHANGE THIS
$pref::LastMission = "Brood";		// This sets the first map in rotate when server launches (make sure it is spelled correctly)

//===========================================================================================
// Server Info (<jc> = center, <f1> = tan font, <f2> = white font, <f3> = orange font, \n = new line)
$Server::Info = "Tribes Vengence Beta.\nServer Owner: Sevnn and Plasmatic\nwww.annihilation.info ";	
	// Server information listed on MasterServer List.
	
$Server::MODInfo = "<jc><f2>www.annihilation.info\n<f1>Welcome to <f3>Tribes Vengence<f1>\nAnother ghetto mod by <f3>Plas 'Stole your T:V' matic.\n <f2>Please respect other players.";
	// Information listed on server join screen.
$Server::JoinMOTD = "<jc><f1>Welcome to <f2>Tribes Vengence v"@$ModVersion@"\n<f3>www.annihilation.info\n<f1>Welcome to The Past.\n<f2>Have fun and don't be a jerk.";	// Message of the day listed once connected to the server
	// Message of the day listed once connected to the server

//===========================================================================================
// Console Parameters
$Console::LogMode = "1"; 		// Log the console to console.log file.

// If you want telnet access, set the port number to the desired port (23 is normal)
// BE SURE TO SET A PASSWORD THAT IS HARD TO GUESS
$TelnetPort="";				// Port for telnet connections
$TelnetPassword="";			// Password for telnet connections

//===========================================================================================
// Server Connection Parameters
$pref::PacketRate = 12;						// Packet rate for client connections
$pref::PacketSize = 200;					// Packet size for client connections

//===========================================================================================
// Annihilation Parameters
//$Annihilation::NetMask = "IP:192.168";	// This is used to increase server player limit when local LAN players connect.
$Annihilation::IncreaseMax = false;		// If true, will increase player limit on server if IP of client connect matches NetMask.
$Annihilation::GiveLocalAdmin = true;		// Gives SuperAdmin status to player on the same machine as the server.
$Annihilation::ResetServer = false;		// Set to true to rotate server to next map in list when last player leaves.
$Annihilation::KickTime = 180;			// Time (in seconds) for kicks.
$Annihilation::BanTime = 1800;			// Time (in seconds) for bans.

//===========================================================================================
// Public Voting Parameters
$Annihilation::VoteAdmin = false;		// Allow Voting a Public Admin in.
$Annihilation::PVKick = true;			// Allow Public Kick Voting.
$Annihilation::PVChangeMission = true;		// Allow Public Mission Voting.
$Annihilation::PVTeamDamage = true;		// Allow Public Team Damage Voting.
$Annihilation::PVTourneyMode = true;		// Allow Public Tournament Mode Voting.
$Server::AdminMinVotes = 4;			// Minimum number of votes needed to vote admin
$Server::MinVotes = 1;				// Minimum number of votes needed to pass
$Server::MinVotesPct = 0.5;			// Percentage of available votes needed to pass a vote
$Server::MinVoteTime = 25;			// Time allotted for voting
$Server::VoteAdminWinMargin = 0.8;		// Ratio of Yes to No votes needed to pass
$Server::VoteFailTime = 30; 			// 30 seconds if your vote fails + $Server::MinVoteTime
$Server::VoteWinMargin = 0.6;			// Ratio of Yes to No votes needed to pass
$Server::VotingTime = 20;			// Length of votes if people are voting.
$annihilation::voteFlagCaps = true;		
	// Allow public voting on flag caps. Maps won't 'cap out' with captures off.
$Annihilation::VoteBuild = false;		
	// Allow voting on builder mode. Players will generally vote this on if allowed.	
	
//===========================================================================================
// Auto Admin. 
// Uses the AnnAdminList.cs in config, edit to your liking.
$Annihilation::AutoAdmin = true; 	
	
//===========================================================================================
// SuperAdmin Passwords, Up to 100 are available
$Annihilation::SADPassword[1] = "";
$Annihilation::SADPassword[2] = "";
$Annihilation::SADPassword[3] = "";
$Annihilation::SADPassword[4] = "";
$Annihilation::SADPassword[5] = "";
// SuperAdmin Parameters
$Annihilation::SADBan = true;			// Allow Super Admins to Ban.
$Annihilation::SADGiveAdmin = true;		// Allow Super Admins to Give Public Admin to other players.
$Annihilation::SADForceVote = true;		// Allow Super Admins to Force Votes to Pass/Fail.

//===========================================================================================
// Public Admin Passwords, Up to 100 are available.
$Annihilation::PAPassword[1] = "";
$Annihilation::PAPassword[2] = "";
$Annihilation::PAPassword[3] = "";
$Annihilation::PAPassword[4] = "";
$Annihilation::PAPassword[5] = "";
// Public Admin Parameters
$Annihilation::PAKick = true;			// Allow Public Admins to Kick.
$Annihilation::PATeamChange = true;		// Allow Public Admins to Change other Players Teams.
$Annihilation::PAChangeMission = true;		// Allow Public Admins to Change the Mission.
$Annihilation::PATeamDamage = true;		// Allow Public Admins to Enable/Disable Team Damage.
$Annihilation::PATourneyMode = true;		// Allow Public Admins to Enable/Disable Tournament Mode.

//===========================================================================================
// Other Parameters
$Server::FloodProtectionEnabled = true;		// Spaminator.
$Server::respawnTime = 2; 			// number of seconds before a respawn is allowed	
$Annihilation::ResetSettings = false;		// Resets server settings from this file on map change.
$Annihilation::FairTeams = true;		// Prevent team changing to the larger team
$Annihilation::UsePersonalSkin = true;		// Allows use of Personal Skins
$Annihilation::OutOfArea = false;		// Allow players out of bounds.
$annihilation::VehicleImpactor = true;	
	// Adds a little cpu strain to safeguard against vehicle instability.
$Annihilation::HappyBreaker = false;	
	// creates dummy player models and flage to fool Happy Mod2	
$annihilation::DisableTurretsOnTeamChange = false;	
	// Disables a clients turrets when they switch teams or disconnect.

//===========================================================================================
// Inventory settings
$Annihilation::QuickInv = false;	// inventory without stations
$Annihilation::ExtendedInvs = true;	// Extended Inventories, multiple use inventory stations.
$Annihilation::Zappy = true;		// Uses electro beams to verify Extended Inventories aren't covered with blastwalls, force fields etc..
$Annihilation::StationTime = 200;	// Time allowed for Station Access, when normal stations.
$Annihilation::ShoppingList = true;	// Limit item shopping list to display only items available for current armor.
$Annihilation::SafeBase = false;	// True for undestroyable station and generators.
$Annihilation::BaseHeal = false;	// True for regenerating (self healing) station and generators.
$build = false;
	// Build mode. Infinite deployables, no need for inventory stations.
	
//===========================================================================================
// Player Parameters
$Server::MaxPlayers = "30";			// Maximum number of client connections allowed
$Server::AutoAssignTeams = true;		// Server assigned teams
$Server::RespawnTime = 0.5; 			// Number of seconds before a respawn is allowed
$Server::TimeLimit = 30;			// Mission time limit in minutes
$Server::WarmupTime = 0;			// Time (in seconds) players are left standing before movement is allowed
$Server::TeamDamageScale = 0;			// Team damage, 0 = Off, 1 = On
$Server::TourneyMode = false;			// Tournament mode

//===========================================================================================
// Player Information.
$IpLogger = true;				// Saves player names sorted by ip.
$Annihilation::obsAlert = true;			// Notifies player who is watching them in observer.

//===========================================================================================
// Team Parameters
$Server::teamName[0] = "Blood Eagle";		// Team 1 Name
$Server::teamSkin[0] = "beagle";		// Team 1 Skin
$Server::teamName[1] = "Imperial";		// Team 2 Name
$Server::teamSkin[1] = "dsword";		// Team 2 Skin
$Server::teamName[2] = "Subversion";		// Team 3 Name
$Server::teamSkin[2] = "cphoenix";		// Team 3 Skin
$Server::teamName[3] = "Downfall";		// Team 4 Name
$Server::teamSkin[3] = "swolf";			// Team 4 Skin
$Server::teamName[4] = "Generic 1";		// Team 5 Name
$Server::teamSkin[4] = "base";			// Team 5 Skin
$Server::teamName[5] = "Generic 2";		// Team 6 Name
$Server::teamSkin[5] = "base";			// Team 6 Skin
$Server::teamName[6] = "Generic 3";		// Team 7 Name
$Server::teamSkin[6] = "base";			// Team 7 Skin
$Server::teamName[7] = "Generic 4";		// Team 8 Name
$Server::teamSkin[7] = "base";			// Team 8 Skin

//===========================================================================================
// You can call a custom mission list from here.
//exec(buildmissionlist);

$Annihilation::OverflowLimit = 24;			// Max # of players before passwording.
$Annihilation::OverflowPassword = "overflow";		// Password set on overflow.

$annihilation::VotePlayerDamage = false;
exec(buildMissionList);		//Sets Map rotation