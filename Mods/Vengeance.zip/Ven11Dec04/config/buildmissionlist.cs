MissionList::clear();





MissionList::addMission("Challenge");

MissionList::addMission("Canyoneros");
MissionList::addMission("Blue_Buddha");

MissionList::addMission("1V");
MissionList::addMission("Rollercoaster");

MissionList::addMission("Scarabrae");
MissionList::addMission("Scooby_Snack");
MissionList::addMission("Raindance");

MissionList::addMission("IceRidge");
MissionList::addMission("BlackHole");

MissionList::addMission("Broadside");

MissionList::addMission("PartyGirl");

MissionList::addMission("Mortum");

MissionList::addMission("Stonehenge");
MissionList::addMission("Dropzone_2");

MissionList::addMission("Brood");
MissionList::addMission("DangerousCrossing");

$pref::LastMission = "DangerousCrossing";
MissionList::initNextMission();
