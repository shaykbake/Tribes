Ice Valley v1.0
By: Lordface (dwb@idirect.com)


This is my first try at creating a Tribes mission.  Bacially its a night time ice planet mission with two bases on either side of a large mountain.

Installation:

To in stall the mission extract the files in this zip file to you tribes\base\missions directory then just host a game and select IceValley from the CTF menu.

Please send any comments, suggestions, or bugs to me at dwb@idirect.com
