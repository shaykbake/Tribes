FLAG ARENA
Both teams battle each other in this super fast game of Flag Ball! What is flag ball? Each team is set in a small arena where they must capture the enemy flag and carry it 100 yards to their flag to score. During the time the other team will try and slaughter, kill, and destroy you! Football now has a new meaning, in the future we play Flag ball, welcome to the Flag_Arena!

just unzip into your tribes\base\mission folder and enjoy!

Made by Mike Hamlett XGN Optimizer, visit our site at www.xtremegaming.net
