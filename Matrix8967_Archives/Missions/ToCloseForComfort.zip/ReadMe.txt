ToCloseForComfort

This CTF map puts both teams together in a close battle for the flag. In the middle of the base you will find the center base which holds a mortar and rocket turret. This is your ultimate way to win this mission, grab the center and hold it while your team grabs the flag!

I am a new map maker at XGN (Xtreme Gaming Network). Pick up my new maps weekly and send any comments or suggestions to us at affiliates@xtremegaming.net

Unzip to tribes/base/mission

XGN Headshot (Ron Oliver)