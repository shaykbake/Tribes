MP-Nervosa 0.9
by Andrew "IrritAnt" Orman
Email: aorman at hotmail dot com

August 2 2005

Teams:			Phoenix, Blood Eagle
Player Spawns:		16 per side at main bases, 8 per side at secondary bases
Recommended Player #s:	8-32
Supported Modes:	CTF, Fuel
Default Mode:		CTF
Number of Bases:	2 per side
Base Sensors:		Yes
Base Generator:		Yes (main base only)
Number of Territories:	0
Vehicles:		1 x Assault Ship, 2 x Fighters at each secondary base
Known Bugs:		None known (Please report any you find!)

Installation
Put MP-Nervosa.tvm and MP-NervosaTextures.pkg in your Content\Maps folder.
Put MP-Nervosa.mopp in your Content\HavokData folder.

Another planet laid waste by constant warfare forms the background for ongoing hostilities between the proud Phoenix Clan and the antagonistic Blood Eagles.

Notes

0.9 Initial Release

This level may be freely distributed as long as;
a) it is not sold or included as part of a collection or compilation which is sold;
b) it is not modified in any way, including this readme file.

If you wish to use parts of this map to create your own, please contact me FIRST; aorman at hotmail dot com.


THIS MAP IS NOT ENDORSED, CREATED, SUPPORTED OR SANCTIONED BY IRRATIONAL GAMES OR VIVENDI UNIVERSAL GAMES. It is an INDEPENDENT release, made in my own free time.