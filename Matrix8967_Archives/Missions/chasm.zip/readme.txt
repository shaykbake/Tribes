Chasm

Server side Tribes Map.  CTF

Map By Godlike
Special thanx to Server[B+H] for the idea of spawning inside a ship.  =)

If you dont know where to unzip these files, you should not have downloaded it.

2 bases , seperated by a huge Chasm, the only thing connecting the two from the baron land inbetween
is a huge bridge. Walls guard against entrance from the valleys. Turrets and Sensors not connected to
the base are temporary. Defend them well.  Cross the bridge , dont fall off , and cap the enemy flag.

Have fun , peace out , and try to survive the Chasm. Bwuahaha   =)

Godlike
