Title: FrozenTundra

Based on: Nothing this is a totally original map that I made.

Author: [SMS]Omnipotent

Email: nima@progamers.com

Thanks: Bosshog for helping me out with some problems.  Also thanks to LTsniper for giving me the confidence to make this map. :)

Testers:Bosshog, [SMS]Rantage, [SMS]Sniper, [SMS]Brad, [SMS-T]Grafex, [SMS]Smooth, [SMS]SeRpicO, and none other them me 

Made for: Clan SteelMaelStrom and myself

Installtion:  Place the 3 files in your tribes/base/missions directory.  Yes people its that simple.

Game Type: Capture ans Hold


Description:

The planet is going through the same phase as the ice age that Earth went through but much worse.  Along with your tribe, one other tribe has survived this bitterly cold age so far.  Scientists theorize that the planet will soon be completely inhospitable, however one abandoned dropship remains that can transport your tribe to safety.  You must fight to the death with the other tribe for the chance to save yourself.  The tribe that controls the dropship the longest will survive this horrible fate.

Enjoy, and please give me feedback. Even if it's bad. It's my first map and its hard 
to know  how a map is going to play out and I need to know what works and what sucks.


[SMS]Omnipotent




