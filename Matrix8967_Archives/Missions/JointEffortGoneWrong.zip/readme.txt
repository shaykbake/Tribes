JointEffortGoneWrong-(CTF)

This is a server side map..... 

Just extract to your tribes/base/missions directory and that's it!

Two teams have just landed on the planet of Theta Draconis IV in a joint effort to create the most poweful base in the universe.  However, with tension (and egos) running high, both groups could only decide on one thing.  And that was to take this base for themselves!  With most of the supplies still on board their dropships, the base has limited functions.  You will have to make frequent trips up to the dropship in order to get what you need.  The team that reaches the score of eight first will win!

 
Designed by Pokey
Feel free to email me with any questions or comments.
jiw592s@mail.smsu.edu
http://maroon.smsu.edu/J/jiw592s



Special thanks to Earthworm for a fantastic tutorial! http://www.tribesworld.com/index.html



