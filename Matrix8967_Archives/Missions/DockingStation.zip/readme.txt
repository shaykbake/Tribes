Just Unzip the files into your Tribes/base/missions directory.

Mission : Docking Station
Mission Type : CTF
Author : RedNight
E-Mail : tsimpson@banet.net

Send any comments or suggestions to tsimpson@banet.net