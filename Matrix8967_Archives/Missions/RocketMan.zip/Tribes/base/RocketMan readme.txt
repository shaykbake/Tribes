Rocket Man is a map created with a new object called a jumppad.  It takes Tribes to a new level of playing and is quite exciting.  For the jumppads to actually show up in the map on your PC, you will need the two files, registerobjects.cs and staticshape.cs, sent with this zip.  For any mappers out there who would like to incorporate the jumppads into new maps they create, you can, once you've installed the two files, find the jumppad in the MISC section.

place registerobjects.cs and staticshape.cs in your dynamix/tribes/base folder

I want to give recognition where it is due.  The jumppad concept was introduced in Renegades 2.0 based losely on the new jumppad's found in Quake III.  Thanks to the man who wrote the code for the jumppad in Tribes.  Hopefully, we will see the jumppad in many maps to come.

Enjoy!

Goldberg

c0027763@airmal.net