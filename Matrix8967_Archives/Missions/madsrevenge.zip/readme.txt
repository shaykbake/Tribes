Madmans Madness V1.0

Unzip this into your Tribes\base\missions directory. This is a server sided map so only 
servers need to have this.

The things you will find on this map are 2 bases, a building near the middle with inventory 
stations that can be used by either team, Jump pads, and a new style of defense. Check it out
to see the new d.

I am in the process of changing all of my maps to server sided, so expect to see many more of 
them you can check for them at http://home.earthlink.net/~goodguy/

If you have any questions or comments feel free to EMAIL me at jcnrr@hotmail.com

Thanks-- Madman