-=   STARSIEGE TRIBES MAP    =-

MADE BY:  Steve Gagn� (XGN DF0)
WHEN:     21 MAY 1999
EMAIL:    stevgagn@cgocable.ca