=-=-=-=Shooters Pack=-=-=-=

Each of the three zipped up maps need to be unzipped as so:

.MIS and .DSC files go in the DYNAMIX/TRIBES/BASE/MISSION folder.
Any .cs file goes in the DYNAMIX/TRIBES/BASE folder.

Shooters by EEPROM
Shooters on the Rocks by EEPROM
Straight Shooters by Goldberg

Find these and all of our other maps and packs at:

www.planetstarsiege.com/extreme