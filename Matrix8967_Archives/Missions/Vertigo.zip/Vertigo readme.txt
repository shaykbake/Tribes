(\/)(\/)(\/)(\/)(\/)(\/)
(/\)(/\)(/\)(/\)(/\)(/\)
	Vertigo
(\/)(\/)(\/)(\/)(\/)(\/)
(/\)(/\)(/\)(/\)(/\)(/\)

Exrtract these files

Vertigo.MIS
Vertigo.dsc

into your

Tribes\Base\missions

directory.
Also soon visit
http://vertigoone.webjump.com
and come to my server
"Vertigo ONE's pack palace"
and put me on your buddy list
				
				


				Vertigo ONE