//-----------------------------------------
//GroupTrigger::onEnter()
//-----------------------------------------
function GroupTrigger::onEnter(%this, %object)
{
// this gets the clients id number
%client = Player::getClient(%object);
   // Diamond Sword in out positions 
	if(%this.num == "DS"){
      %positionIn = "-430.161 -147.648 467.32";
      %positionOut = "-448.375 -15.0678 178.903";
   }
// Blood Eagle in out positions
   else if(%this.num == "TP"){
      %positionIn = "118.095 72.4637 23.8724";
      %positionOut = "5.93841 193.586 586.988";
   }  
      // this sets the actual position if trigger is in = true
	if(%this.in){ 
         GameBase::setPosition(%client, %positionIn);
         //messageAll(0, "~wshieldhit.wav");
	   Client::SendMessage(%client,0,"~wshieldhit.wav");
      }
      // this sets the position if out = true
	else if(%this.out){
         GameBase::setPosition(%client, %positionOut);
         //messageAll(0, "~wshieldhit.wav");
         Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
} 

// you will want to set the trigger num = to something
// otherwise it'll mess up triggers in other maps 
// the client sendMessage is better than messageAll 
// the client will hear the sound but others won't
// the messageall plays the sound for everyone full volume, gets annoying
// put this file in your base directory
// this file is executed in the .mis file (at bottom)