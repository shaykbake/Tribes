This is my level, woohoo!  It is called Sky War, and is server side so that players do not have to download it.  There are 4 
files included in this zip, plus this readme.

Sky_War.MIS and Sky_War.dsc both go in your Tribes\Base\Missions folder.  They 
are the level files.

RegisterObject.cs and staticshape.cs are scripts that allow the jump pads in my level to work.  They are the EXACT same scripts that come with the level JUMP_ZONE, so the author of that level certainly gets recognition.  They have to be installed on the servers computer in the Tribes\Base folder, otherwise the level will not work properly.

Thank you for playing my map!

Phil Small
^*^SW Cheezeman
Cheeze@adelphia.net
ICQ# 32351059