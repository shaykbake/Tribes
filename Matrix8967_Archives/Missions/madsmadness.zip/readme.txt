Madmans Madness V1.0

Unzip this into your Tribes\base\missions directory. This is a server sided map so only 
servers need to have this.

On this map there are 2 bases and 2 capturable rooms one room in each base each room is 
worth one point. The one who controlsthese rooms can do plenty of damage to the othe team.

I am in the process of changing all of my maps to server sided, so expect to see many more of 
them you can check for them at http://home.earthlink.net/~goodguy/

If you have any questions or comments feel free to EMAIL me at jcnrr@hotmail.com

Thanks-- Madman