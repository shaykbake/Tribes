Map: UniversalSoldier2
Author: XGN MechLoud

This map has just about everything in it. This map uses
the Dangerous Crossing battlefield with a new twist. Above
the bridge in the middle of the map is an arena with flags
at both ends. You can play Death Match type battles or the
traditional Capture the Flag style of game. There is also
something speacial about this map. In the middle area of
the arena there is a type of "No Man's Land". I have built 
the walls so they can also be used as a hiding place and
they also resemble "Pill Boxes" as have been used in real
wars. They have been built to allow you to see and shoot
out into the middle of the arena. I hope this is a map
everyone will enjoy for a long time. 

More Maps are on the way !!

XGN MechLoud

