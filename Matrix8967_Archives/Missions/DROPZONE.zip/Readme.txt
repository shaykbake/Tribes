DROPZONE

The huge floating nuclear supply station has been taken over by two tribes. The station transports from planet to planet gathering nuclear energy for dropship runs. Now each Tribe must battle each other to the death for control of the last supply of nuclear energy. The supply station hovers 2 miles above the planet, if you fall you will die. Score 8 points to win this mission.

Unzip into C:\Dynamix\Tribes\base\missions or wherever your Dynamix file is located.

Map by Xtreme Gaming, check daily for new maps at http://www.xtremegaming.net