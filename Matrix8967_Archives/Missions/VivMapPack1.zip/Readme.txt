*****************************
*     ViViD MAP PACK #1     *
*****************************

:: Unzip the starsiege tribes map pack to your default
:: tribes directory. (NOTE: Please make sure "Overwrite
:: Exisiting Files" is checked.

:: Usually: C:\Dynamix\Tribes\base\missions


:: This is our first release, Well it is pleasent to
:: see that the feedback we receive regarding this
:: first map collection was all good.  There will be
:: many more maps yet to come, so visit our site daily
:: for news, updates and downloads!

:: Regards,  Darksheer (Vivid Founder)


[ViV] --> http://come.to/vivid/
	  News, Updates, more maps!

:: Email: Darksheer@YoursForever.com with any comments
:: or suggestions.
