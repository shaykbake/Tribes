Stormhammer Ridge is a Starsiege: Tribes map designed by KyleJade.
It includes a well-equipped base for both teams and a capturable tower off to the side of the main battle path, useful for a heavy recharging waypoint on base sieges and also for the extra points! The power sources for each team are relatively open to long-range fire, and there are reapir packs and respawning ammo for when the lights go out!

Credit for the name goes to Bloodhype!

Anyone may distibute this level as long as the zip file remains unchanged. Good luck and have fun!