Mission Name: AvicordValleys
Type: CTF
Added(based on peekaboo terrain): Totally new base and tower placements

Just extract to your tribes/base/missions directory and that's it!
This is a server side map, requiring no client download. 

Designed by Astroboy 
It ran fine on a p2 400 with a voodoo2 but hopefully it should be ok
on lower spec systems however i was unable to test this.
DropPoints work as they should however the game may write
"unable to find player" to the console a few times before you spawn.
I could not fix this.

A final note, no this mission is not impossible! I like strategy and
it takes a team effort for a capture, which is why i made it hard.

Enjoy

Email me with any comments : astro_boy@bigpond.com

