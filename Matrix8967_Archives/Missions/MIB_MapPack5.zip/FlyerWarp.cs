// Flyer Warp Script by Com. Sentinal [M.I.B.]
// Modified Repulser/Warp
// Warps in all 3 dimensions

function setStuff()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.lock = false;
      %player.alive = true;
   }
}

focusserver(); setStuff(); focusclient();

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   %player.lock = false;
   %player.alive = true;
}

function vehicle::onScan(%scanned, %scanner)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player1.lock == false)
   {
      %player1.lock = true;
      %x1 = getPosition(%scanner, x);
      %y1 = getPosition(%scanner, y);
      %z1 = getPosition(%scanner, z);
      %nav = getVehicleNavMarkerId(%scanner);
      %x2 = getPosition(%nav, x);
      %y2 = getPosition(%nav, y);
      %z2 = getPosition(%nav, z);
      %distance = getDistance(%scanner, %nav);
      %increments = %distance / 10;
      %xDist = %x2 - %x1;
      %yDist = %y2 - %y1;
      %zDist = %z2 - %z1;
      %xOffset = %xDist / %increments;
      %yOffset = %yDist / %increments;
      %zOffset = %zDist / %increments;
      repulse(%scanner, %xOffset, %yOffset, %zOffset, %increments);
   }
}

function structure::onScan(%scanned, %scanner)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player1.lock == false)
   {
      %player1.lock = true;
      %x1 = getPosition(%scanner, x);
      %y1 = getPosition(%scanner, y);
      %z1 = getPosition(%scanner, z);
      %nav = getVehicleNavMarkerId(%scanner);
      %x2 = getPosition(%nav, x);
      %y2 = getPosition(%nav, y);
      %z2 = getPosition(%nav, z);
      %distance = getDistance(%scanner, %nav);
      %increments = %distance / 10;
      %xDist = %x2 - %x1;
      %yDist = %y2 - %y1;
      %zDist = %z2 - %z1;
      %xOffset = %xDist / %increments;
      %yOffset = %yDist / %increments;
      %zOffset = %zDist / %increments;
      repulse(%scanner, %xOffset, %yOffset, %zOffset, %increments);
   }
}

function vehicle::onSpot(%spotter, %target)
{
   if(%target != "")
   {
      %player1 = playerManager::vehicleIdToPlayerNum(%spotter);
      if(%player1.lock == false)
      {
         %player1.lock = true;
         %x1 = getPosition(%spotter, x);
         %y1 = getPosition(%spotter, y);
         %z1 = getPosition(%spotter, z);
         %nav = getVehicleNavMarkerId(%spotter);
         %x2 = getPosition(%nav, x);
         %y2 = getPosition(%nav, y);
         %z2 = getPosition(%nav, z);
         %distance = getDistance(%spotter, %nav);
         %increments = %distance / 10;
         %xDist = %x2 - %x1;
         %yDist = %y2 - %y1;
         %zDist = %z2 - %z1;
         %xOffset = %xDist / %increments;
         %yOffset = %yDist / %increments;
         %zOffset = %zDist / %increments;
         repulse(%spotter, %xOffset, %yOffset, %zOffset, %increments);
      }
   }
}

function repulse(%vehicleId, %xOffset, %yOffset, %zOffset, %increments)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if((%increments > 1)&&(%player.alive == true))
   {
      %increments--;
      %x = getPosition(%vehicleId, x) + %xOffset;
      %y = getPosition(%vehicleId, y) + %yOffset;
      %z = getPosition(%vehicleId, z) + %zOffset;
      setPosition(%vehicleId, %x, %y, %z);
      schedule("repulse(" @ %vehicleId @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %zOffset @ ", " @ %increments @ ");", 0.1);
   }
   else
   {
      %player.lock = false;
      if(%player.alive == true)
      {
         %nav = getVehicleNavMarkerId(%vehicleId);
         %x = getPosition(%nav, x);
         %y = getPosition(%nav, y);
         %z = getPosition(%nav, z) + 10;
         setPosition(%vehicleId, %x, %y, %z);
         say("Everybody", 2, "<F5>" @ getName(%player) @ " has reached his destination.", "alarm2.wav");
      }
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player.alive = false;

   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer))&&(%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}