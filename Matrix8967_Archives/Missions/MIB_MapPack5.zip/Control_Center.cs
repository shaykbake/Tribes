// Control Center Script Template
//------------------------------------------------------------------------------
// FILENAME:	Control_Center.cs
//
// AUTHORS:  	Maj. Deathrow [M.I.B.]
// Version:       1.00
//------------------------------------------------------------------------------

$missionName = $squad @ " Control Center";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$shoot = false;
$help = false;
//Insert map names from your multiplayer folder.
//Example: $map1 = "Dm_city_on_the_edge";
$map = "";
$map2 = "";
$map3 = "";
$map4 = "";
$map5 = ""; 
$map6 = "";
$map7 = ""; 
$map8 = "";
$map9 = "";
$map10 = "";
$map11 = "";
$map12 = "";
$map13 = "";
$map14 = "";
$map15 = "";
$map16 = "";
//Insert squad name if one.
//Example: $squad = "M.I.B.";
$squad = "";

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = false;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = true;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
   
   $server::TimeLimit = 20;
}


function onMissionStart()
{
   marsSounds();
}

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.name = getHUDName(%vehicleId);
}


function player::OnRemove(%player)
{
}


function player::onAdd(%player)
{ 

   say(%player, 0, "Welcome to the " @ $squad @ " Control Center! Choose which map you want to play by shooting one of the floating target drones. If you need additional help, the \"Help Desk\" target drone is in the Temple.Goto the the info button to know what this map is! You can download this & other missions made by Maj. Deathrow [M.I.B.] at www.starsiegeplayers.com.", "TR_INTR01.WAV");
   %txt ="." @ $map @ " Control Center was made for you to pick the map you want to go to.";
   messageBox(%player,%txt); 
   %txt ="You pick the map you want to go to from inside the game By shooting the floating drones.";
   messageBox(%player,%txt); 
   %txt ="If you need help while in the game go to the help desk in the game.";
   messageBox(%player,%txt);
    %txt ="This map was created by Maj.Deathrow [M.I.B.] and Help from Com.Sentinal [M.I.B.]";
   messageBox(%player,%txt);	
}

function onMissionLoad(){
   cdAudioCycle("Purge", "Terror", "Watching"); 
	
	setGameInfo("<F2>GAME TYPE:<F0>  Comand Center!\n\n<F2>MISSION:<F0>  You are able to choose one of the levels that you want to play while in the game created by M.I.B. members just by shooting the floating drones <F3><F0>. You can download Control Center & other missions made by Maj. Deathrow [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at http://mibhq.4mg.com");
}


function battle::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map @ ".");
      %txt =" Now "@ $map @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = $map;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function tower::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map2 @ ".");
	%txt =" Now "@ $map2 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
                $MissionCycling::Stage0 = $map2;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function aquatica::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map3 @ ".");
	%txt =" Now "@ $map3 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = $map3;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function aquaticadam::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map4 @ ".");
      %txt =" Now "@ $map4 @ " will start in 5 secs.";
      messageBox("Everybody",%txt);  	
      $shoot=true;
	$MissionCycling::Stage0 = $map4;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function sky::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map5 @ ".");
      $shoot=true;
	%txt =" Now "@ $map5 @ " will start in 5 secs.";
       messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = $map5;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}
	
function rome::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map6 @ ".");
      $shoot=true;
	%txt =" Now "@ $map6 @ " will start in 5 secs.";
      messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = $map6;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function nova::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map7 @ ".");
      $shoot=true;
	%txt =" Now "@ $map7 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
	$MissionCycling::Stage0 = $map7;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function pit::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map8 @ ".");
      $shoot=true;
	%txt =" Now "@ $map8 @ " will start in 5 secs.";
      messageBox(%this,%txt); 
	$MissionCycling::Stage0 = $map8;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}	

function mine::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map9 @ ".");
      $shoot=true;
	%txt =" Now "@ $map9 @ " will start in 5 secs.";
      messageBox(%this,%txt); 
	$MissionCycling::Stage0 = $map9;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}	

function la::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map10 @ ".");
      $shoot=true;
	%txt =" Now "@ $map10 @ " will start in 5 secs.";
      messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = $map10;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function cage::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map11 @ ".");
      $shoot=true;
	%txt =" Now "@ $map11 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
	$MissionCycling::Stage0 = $map11;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function complex::structure::onAttacked(%this, %attacker)	
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map12 @ ".");
      $shoot=true;
	%txt =" Now "@ $map12 @ " will start in 5 secs.";
      messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = $map12;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}	

function bowl::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map13 @ ".");
	%txt =" Now "@ $map13 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = $map13;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function tube::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map14 @ ".");
	%txt =" Now "@ $map14 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = $map14;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}
	
function rebel::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map15 @ ".");
	%txt =" Now "@ $map15 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = $map15;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function deep::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play " @ $map16 @ ".");
	%txt =" Now "@ $map16 @ " will start in 5 secs.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = $map16;
	$MissionCycling::Stage1 = "Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function help::structure::onAttacked(%this, %attacker)
{
   if($help == false)
   {
      $help=true;
	%txt ="Welcome to the help desk. May I help you?";
      messageBox(%attacker,%txt); 
      say("Everybody", 1, "___");	
      say("Everybody", 1, "Welcome to the Control Center! You have chosen th \"Help Desk\". Please choose which map you want to play by shooting one of the floating target drones. The server will then change the map to the one you have chosen. After the mission ends, you will be returned to the Control Center.", "M5_DM_hibuddy.wav");
      schedule("$help = false;", 10);
   }
}