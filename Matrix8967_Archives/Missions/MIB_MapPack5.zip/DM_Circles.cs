// FILENAME:	DM_Circles.cs
//
// AUTHORS:  	Maj. StormTrooper [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Circles";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$yellowHerc1Path = "MissionGroup/r1path";
$yellowHerc2Path = "MissionGroup/r2path";
$yellowHerc4Path = "MissionGroup/r4path";
$yellowHerc5Path = "MissionGroup/r5Path";
$yellowHerc6Path = "MissionGroup/r6path";
$yellowHerc7Path = "MissionGroup/r7path";
$yellowHerc8Path = "MissionGroup/r8path";
$yellowHerc9Path = "MissionGroup/r9path";

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;
}

function onMissionStart()
{
	$healRate = 100;   
	$ammoRate = 3;
 	$padWaitTime = 45;

      windSounds();
	marsSounds();
      order( $yellowHerc1, guard, $yellowHerc1Path );
      order( $yellowHerc2, guard, $yellowHerc2Path );
      order( $yellowHerc3, guard, $yellowHerc2Path );
      order( $yellowHerc4, guard, $yellowHerc4Path );
      order( $yellowHerc5, guard, $yellowHerc5Path );
      order( $yellowHerc6, guard, $yellowHerc6Path );
      order( $yellowHerc7, guard, $yellowHerc7Path );
      order( $yellowHerc8, guard, $yellowHerc8Path );
      order( $yellowHerc9, guard, $yellowHerc9Path );
}

function onMissionLoad()
{
   cdAudioCycle("Gnash", "Cloudburst", "Cyberntx"); 

   // get the original ID for each AI Herc ( for use later when we clone them )
   $yellowHerc1 = getObjectId( "MissionGroup/redguys/r1" );
   $yellowHerc2 = getObjectId( "MissionGroup/redguys/r2" );
   $yellowHerc3 = getObjectId( "MissionGroup/redguys/r3" );
   
   $yellowHerc4 = getObjectId( "MissionGroup/redguys/r4" );
   $yellowHerc5 = getObjectId( "MissionGroup/redguys/r5" );
   $yellowHerc6 = getObjectId( "MissionGroup/redguys/r6" );
   $yellowHerc7 = getObjectId( "MissionGroup/redguys/r7" );
   $yellowHerc8 = getObjectId( "MissionGroup/redguys/r8" );
   $yellowHerc9 = getObjectId( "MissionGroup/redguys/r9" );

}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to DeathMatch Circles! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

// Easter Egg time
function AirChina::trigger::onEnter(%this, %vehicleId)
{
	say(playerManager::vehicleIdToPlayerNum(%vehicleId), 0, *IDMULT_AIR_CHINA);
	%backToTheField = strcat("endTheTrip(", %vehicleId, ");");
	schedule(%backToTheField, 10);	
}

function endTheTrip(%vehicleId)
{
	randomTransport(%vehicleId, -1890, 1681, -1890, 1681);
}
