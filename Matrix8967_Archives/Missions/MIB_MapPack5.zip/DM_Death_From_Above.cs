// FILENAME:	DM_Death_From_Above.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//
// RANDOM QUOTE: "Who throws a shoe? Honestly...
//               You could put an eye out with that thing!"
//                                 - Austin Powers
//------------------------------------------------------------------------------

$missionName = "DM_Death_From_Above";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");
exec("BoostStdLib.cs"); //Beta version...doesn't work too well.

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	marsSounds();

      $active=true;
      $path="Missiongroup/Path";
}     

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DeathMatch Death From Above! Check the rules for information on how to fly. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("NewTech", "Mechsoul", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  DeathMatch\n\n<F2>MISSION:<F0>  DM_Death_From_Above\n\nWelcome to DeathMatch Death From Above! Scan another player or a structure to boost up & hover for a few seconds. If you have the HercBoost Keymap, you can steer in mid-air & fly indefinitely. You can download the keymaps along with this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" on the MIB website at www.starsiegemeninblack.cjb.net.\n\n<f2>HercBoost Keymap Controls:<f0>\n\nBoost:                             <f3>Ctrl + S<F0>\nHover:                            <f3>Ctrl + D<f0>\nBoost Forward:                    <f3>Ctrl + W<f0>\nCancel Boost or Hover:            <f3>Ctrl + A<f0>\nSteer Left (Tanks Only):           <f3>Left Arrow<f0>\nSteer Right (Tanks Only):          <f3>Right Arrow<f0>");
}

//------------------------------------------------------------------
// Scan someone to jump up, then hover.

function vehicle::onscan(%scanned,%scanner)
{
   jump(%scanner);
   schedule("jump("@%scanner@");",0.1);
   schedule("jump("@%scanner@");",0.2);
   schedule("jump("@%scanner@");",0.3);
   schedule("jump("@%scanner@");",0.4);
   schedule("jump("@%scanner@");",0.5);
   schedule("hover2("@%scanner@");",0.6);
   schedule("hover2("@%scanner@");",0.7);
   schedule("hover2("@%scanner@");",0.8);
   schedule("hover2("@%scanner@");",0.9);
   schedule("hover2("@%scanner@");",1.0);
   schedule("hover2("@%scanner@");",1.1);
   schedule("hover2("@%scanner@");",1.2);
   schedule("hover2("@%scanner@");",1.3);
   schedule("hover2("@%scanner@");",1.4);
   schedule("hover2("@%scanner@");",1.5);
   schedule("hover2("@%scanner@");",1.6);
   schedule("hover2("@%scanner@");",1.7);
   schedule("hover2("@%scanner@");",1.8);
   schedule("hover2("@%scanner@");",1.9);
   schedule("hover2("@%scanner@");",2.0);
   schedule("hover2("@%scanner@");",2.1);
   schedule("hover2("@%scanner@");",2.2);
   schedule("hover2("@%scanner@");",2.3);
   schedule("hover2("@%scanner@");",2.4);
   schedule("hover2("@%scanner@");",2.5);
   schedule("hover2("@%scanner@");",2.6);
   schedule("hover2("@%scanner@");",2.7);
   schedule("hover2("@%scanner@");",2.8);
   schedule("hover2("@%scanner@");",2.9);
   schedule("hover2("@%scanner@");",3.0);
   schedule("hover2("@%scanner@");",3.1);
   schedule("hover2("@%scanner@");",3.2);
   schedule("hover2("@%scanner@");",3.3);
   schedule("hover2("@%scanner@");",3.4);
   schedule("hover2("@%scanner@");",3.5);
   schedule("hover2("@%scanner@");",3.6);
   schedule("hover2("@%scanner@");",3.7);
   schedule("hover2("@%scanner@");",3.8);
   schedule("hover2("@%scanner@");",3.9);
   schedule("hover2("@%scanner@");",4.0);
}

function structure::onscan(%scanned,%scanner)
{
   jump(%scanner);
   schedule("jump("@%scanner@");",0.1);
   schedule("jump("@%scanner@");",0.2);
   schedule("jump("@%scanner@");",0.3);
   schedule("jump("@%scanner@");",0.4);
   schedule("jump("@%scanner@");",0.5);
   schedule("hover2("@%scanner@");",0.6);
   schedule("hover2("@%scanner@");",0.7);
   schedule("hover2("@%scanner@");",0.8);
   schedule("hover2("@%scanner@");",0.9);
   schedule("hover2("@%scanner@");",1.0);
   schedule("hover2("@%scanner@");",1.1);
   schedule("hover2("@%scanner@");",1.2);
   schedule("hover2("@%scanner@");",1.3);
   schedule("hover2("@%scanner@");",1.4);
   schedule("hover2("@%scanner@");",1.5);
   schedule("hover2("@%scanner@");",1.6);
   schedule("hover2("@%scanner@");",1.7);
   schedule("hover2("@%scanner@");",1.8);
   schedule("hover2("@%scanner@");",1.9);
   schedule("hover2("@%scanner@");",2.0);
   schedule("hover2("@%scanner@");",2.1);
   schedule("hover2("@%scanner@");",2.2);
   schedule("hover2("@%scanner@");",2.3);
   schedule("hover2("@%scanner@");",2.4);
   schedule("hover2("@%scanner@");",2.5);
   schedule("hover2("@%scanner@");",2.6);
   schedule("hover2("@%scanner@");",2.7);
   schedule("hover2("@%scanner@");",2.8);
   schedule("hover2("@%scanner@");",2.9);
   schedule("hover2("@%scanner@");",3.0);
   schedule("hover2("@%scanner@");",3.1);
   schedule("hover2("@%scanner@");",3.2);
   schedule("hover2("@%scanner@");",3.3);
   schedule("hover2("@%scanner@");",3.4);
   schedule("hover2("@%scanner@");",3.5);
   schedule("hover2("@%scanner@");",3.6);
   schedule("hover2("@%scanner@");",3.7);
   schedule("hover2("@%scanner@");",3.8);
   schedule("hover2("@%scanner@");",3.9);
   schedule("hover2("@%scanner@");",4.0);
}

function jump(%scanner)
{
   %posx=getposition(%scanner,x);
   %posy=getposition(%scanner,y);
   %posz=getposition(%scanner,z)+5;
   setposition(%scanner,%posx,%posy,%posz);
}

function hover2(%scanner)
{
   %posx=getposition(%scanner,x);
   %posy=getposition(%scanner,y);
   %posz=getposition(%scanner,z)+0.2;
   setposition(%scanner,%posx,%posy,%posz);
}

//Easter Egg
//--------------------------------------------------------------

Pilot Prom
{
   id = 28;
   
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 600.0;
   deactivateBuff = 500.0;
   targetFreq = 2.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Prometheus";
};

Pilot Exec
{
   id = 29;
   
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 600.0;
   deactivateBuff = 500.0;
   targetFreq = 2.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Platinum Guard Executioner";
};

Pilot Judge
{
   id = 30;
   
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 600.0;
   deactivateBuff = 500.0;
   targetFreq = 2.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Platinum Guard Adjudicator";
};

function cybrid::structure::onattacked(%attacked,%attacker)
{
   if($active==true)
   {
       $active=false;
       setposition(%attacker,421.962,-10.1936,50.2085);
       $prom = newobject("Prom",Herc,29);
       schedule("setTeam($prom, *IDSTR_TEAM_PURPLE);",1);  
       schedule("setPilotId($prom,28);",1); 
       schedule("setposition($prom, 498.188,1944.51,73.8654);",1);
       schedule("order($prom,guard,$path);",1);
       schedule("order($prom,speed,high);",1);
       $exec = newobject("Exec",Herc,28);
       schedule("setTeam($exec, *IDSTR_TEAM_PURPLE);",2);
       schedule("setPilotId($exec,29);",2); 
       schedule("setposition($exec, -1759.2,-180.347,43.1855);",2);
       schedule("order($exec,guard,$path);",2);
       schedule("order($exec,speed,high);",2);
       $judge = newobject("Judge",Herc,27);
       schedule("setTeam($judge, *IDSTR_TEAM_PURPLE);",3);
       schedule("setPilotId($judge,30);",3); 
       schedule("setposition($judge, 2444.65,-15.5687,61.3396);",3);
       schedule("order($judge,guard,$path);",3);
       schedule("order($judge,speed,high);",3);
       schedule("setFlybyCamera($prom , 0, 50, 15);",7);
       schedule("setFlybyCamera($exec , 0, 50, 15);",12);
       schedule("setFlybyCamera($judge , 0, 50, 15);",17);
       schedule("setPlayerCamera();", 22 );
       schedule("say(0,0,\"<f1>Cybrids on the perimeter!\",\"sfx_siren.wav\");",5);
       schedule("$active=true;",300);
   }
}

