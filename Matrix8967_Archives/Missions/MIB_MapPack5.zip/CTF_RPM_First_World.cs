// FILENAME:	CTF_RPM_First_World.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
// This script uses my EXP_Map script as a base. For convenience, many existing
// variables were left with the same names, so if it looks a little strange,
// that's why.      - Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
$missionName = "CTF_RPM_First_World";

// CTF stuff
$maxFlagCount  = 8;           // no of flags required by a team to end the game
$flagValue     = 5;          // points your team gets for capturing
$carrierValue  = 2;          //  "      "    "    "    " killing carrier
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 300;             // 5 minute timer

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
	mercurySounds();
      $explosivesSupply1 = "ready";
      $explosivesSupply2 = "ready";
      $explosivesSupply3 = "ready";
      $explosivesSupply4 = "ready";
      $explosivesSupply5 = "ready";
      loop();
      // CTF stuff
      initGlobalVars();
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "Cloudburst", "Terror","Mechsoul"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Repulsor Mine Capture the Flag\n\n<F2>MISSION:<F0>  CTF_RPM_First_World\n\nWelcome to Repulsor Mine CTF! Your vehicle is equipped with a Repulsor Mine when you spawn. Shut down to set the Repulsor Mine. Your Repulsor Mine will repel other players from it until you set another mine. You can only set one mine at a time. Re-Supply your vehicle with a Repulsor Mine by walking into an Repulsor Mine Supply Depot. You cannot set a mine while in a pad. You can disable your existing mine by scanning a structure or another vehicle. You can download CTF_RPM_First_World & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   //reset deathdelay
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.deathdelay = false;
   }
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Repulsor Mine CTF! Your vehicle is equipped with a Repulsor Mine when you spawn. Shut down to set the Repulsor Mine. Your Repulsor Mine will repel other players from it until you set another mine. Check the Game Info tab for more information. You can download CTF_RPM_First_World & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   deleteobject(%player.bomb);
   deleteobject(%player.glow);
   %player.bomb = "nothing";
   %player.glow = "nothing";
   %player.deathdelay = false;
}

function player::onremove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
   deleteobject(%player.bomb);
   deleteobject(%player.glow);
   %player.bomb = "nothing";
   %player.glow = "nothing";
}


function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %player.hasBomb = true;
   %player.InPad = false;
   %player.spawndelay = true;
   schedule("spawndelay("@%player@");",5);   
   // CTF stuff
   %team = getTeam(playerManager::vehicleIdToPlayerNum(%vehicleId));
   %color = teamToColor(%team);
   %flagKey = strcat(%color, "FlagCount");
	
   adjTeamCount(%team, 1);
	
   //if the flag isn't at the base, but no one has it, correct situation
   if(dataRetrieve(0, %flagKey) && !dataRetrieve(0, strcat(%color, "FlagCarried")))
   {
   	setFlag(%team, true);
   }
}   

function spawndelay(%player)
{
   %player.spawndelay = false;
}

function vehicle::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   
   %player2.deathdelay=true;
   schedule("deathdelay("@%player2@");",5);   
   // CTF stuff
   %team = getTeam(%destroyed);
   adjTeamCount(%team, -1);
   %teamCount = getTeamPlayerCount(%team);      

   if(%teamCount < 1)
   {
	   setFlag(%team, false);					
   }

   %color = dataRetrieve(%destroyed, "hasFlag");
   %flagTeam = colorToTeam(%color);
   
   // if the destroyed vehicle has a flag, it goes back to it's base
   if (%color != "")
   {
      playerDropsFlag(%destroyed);
      
      // let everyone know this guy drops the flag
      %str =
         *IDMULT_CHAT_SURRENDER_FLAG_1 @
         getName( %destroyed )         @
         *IDMULT_CHAT_SURRENDER_FLAG_2 @ 
         %flagTeam                     @
         *IDMULT_CHAT_SURRENDER_FLAG_3;
      
      %soundFile = "";   
      if(%flagTeam == *IDSTR_TEAM_RED)
      {
         %soundFile = "red_flag_sur.wav";
      }
      else if(%flagTeam == *IDSTR_TEAM_BLUE)
      {
         %soundFile = "blue_flag_sur.wav";
      }
      else if(%flagTeam == *IDSTR_TEAM_YELLOW)
      {
         %soundFile = "yel_flag_sur.wav";
      }
      else
      {
         %soundFile = "purp_flag_sur.wav";
      }   
      
      say( 0, 0, %str, %soundFile );

            
      if($scoringFreeze == false)
      {     
         // destroyer's team gets credit for killing the carrier
         %destroyerTeam = getTeam(%destroyer);  
      
         // only give points if destroyed recovered his/her own flag
         if(%destroyerTeam == colorToTeam(%color))
         {
            %key = strcat(teamToColor(getTeam(%destroyer)), "CarriersKilled");
            dataStore(0, %key, 1 + dataRetrieve(0, %key));
            
            // player gets credit, too
            %player = playerManager::vehicleIdToPlayerNum(%destroyer);
            if(%player != 0)
            {
               %player.carriersKilled = %player.carriersKilled + 1;
            }
         }

         // echo the surrender to the console for logging
         echo(*IDSTR_CONSOLE_CTF_SURRENDER @ " " @ playerManager::vehicleIdToPlayerNum(%destroyed));                        
      }	  
   }
   else
   {
      // not a flag carrier ... is it an enemy?
      if($scoringFreeze == false)
      {
         if(getTeam(%destroyed) != getTeam(%destroyer))
         {
            %player = playerManager::vehicleIdToPlayerNum(%destroyer);
            if(%player != 0)
            {
               %player.genericKills = %player.genericKills + 1;
            }
         }
      }
   }
   vehicle::onDestroyedLog(%destroyed, %destroyer);
  
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }      
}

function deathdelay(%player2)
{
   %player2.deathdelay = false;
}

function vehicle::onscan(%scanned,%scanner)
{
   %player = playerManager::VehicleIdtoPlayerNum(%scanner);
   if(%player.bomb=="nothing")
   {
      say(%player,%player,"<f1>You do not have a Repulsor Mine to disable.");
   }
   else if(%player.bomb!="nothing")
   {
      say(%player,%player,"<f1>Your Repulsor Mine has been disabled.");
      deleteObject(%player.bomb);
      deleteObject(%player.glow);
      %player.bomb = "nothing";
      %player.glow = "nothing";
   }
}

function structure::onscan(%scanned,%scanner)
{
   %player = playerManager::VehicleIdtoPlayerNum(%scanner);
   if(%player.bomb=="nothing")
   {
      say(%player,%player,"<f1>You do not have a Repulsor Mine to disable.");
   }
   else if(%player.bomb!="nothing")
   {
      say(%player,%player,"<f1>Your Repulsor Mine has been disabled.");
      deleteObject(%player.bomb);
      deleteObject(%player.glow);
      %player.bomb = "nothing";
      %player.glow = "nothing";
   }
}

function loop()
{   
   %count = playermanager::getplayercount();
   for(%i=0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if((%player.bomb!="")&&(%player.bombdelay==false))
      {
         damageArea(%player.bomb,0,0,-8,100,0);
      }
   }
   schedule("loop();",0.05);
}

function explosives::trigger::oncontact(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(isshutdown(%object)==false)
   {
      %player.justlaid = false;
   }
   if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%player.hasbomb==true)&&(%player.deathdelay==false))
   {  
      %player.justlaid = true;
      say(%player,%player,"<f1>Repulsor Mine will be deployed in 10 seconds.");
      setMine(%object);
   }  
   else if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%player.hasbomb==false)&&(%player.justlaid==false))
   {  
      %player.justlaid = true;
      say(%player,%player,"<f1>You are not equipped with a Repulsor Mine.");
   }
}

function setMine(%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   deleteObject(%player.bomb);
   deleteObject(%player.glow);
   %player.bomb = "nothing";
   %player.glow = "nothing";
   %player.bombdelay = true;   
   %player.hasbomb = false;
   %player.bomb = newobject("Mine", StaticShape, "pr_prx.DTS");
   %player.glow = newObject("Glow", StaticShape, "pr_empT.DTS");
   playAnimSequence(%player.glow,0,false);
   schedule("playAnimSequence("@%player.glow@",0,true);",5);
   %x = getposition(%object,x);
   %y = getposition(%object,y);
   %z = getTerrainHeight(%x,%y)+5;
   setposition(%player.bomb,-5000,-5000,-1000);
   setposition(%player.glow,-5000,-5000,-1000);
   schedule("setposition("@%player.bomb@","@%x@","@%y@","@%z@");",10);
   schedule("setposition("@%player.glow@","@%x@","@%y@","@%z@");",10);
   setHudTimer(10, -1, "Repulsor Mine will deploy in:", 3, %player); 
   schedule("say("@%player@","@%player@",\"<f5>Repulsor Mine deployed.\");",10);
   schedule("bombdelay("@%player@");",10);   
}

function bombdelay(%player)
{
   %player.bombdelay = false;
}

function onMissionEnd()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      deleteobject(%player.bomb);
      deleteobject(%player.glow);
      %player.bomb = "nothing";
      %player.glow = "nothing";
   }
}

function explosivesSupply1::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply1=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Repulsor Mine.");
      $explosivesSupply1 = "not ready";
      schedule("$explosivesSupply1 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Repulsor Mine Supply Depot 001 is ready.\");",30);
   }
   else if(($explosivesSupply1=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have a Repulsor Mine!");
   }
   else if($explosivesSupply1!="ready")
   {
      say(%player,%player,"<f1>Repulsor Mine Supply Depot 001 is not ready.");
   }
}

function explosivesSupply2::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply2=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Repulsor Mine.");
      $explosivesSupply2 = "not ready";
      schedule("$explosivesSupply2 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Repulsor Mine Supply Depot 002 is ready.\");",30);
   }
   else if(($explosivesSupply2=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have a Repulsor Mine!");
   }
   else if($explosivesSupply2!="ready")
   {
      say(%player,%player,"<f1>Repulsor Mine Supply Depot 002 is not ready.");
   }
}

function explosivesSupply3::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply3=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Repulsor Mine.");
      $explosivesSupply3 = "not ready";
      schedule("$explosivesSupply3 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Repulsor Mine Supply Depot 003 is ready.\");",30);
   }
   else if(($explosivesSupply3=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have a Repulsor Mine!");
   }
   else if($explosivesSupply3!="ready")
   {
      say(%player,%player,"<f1>Repulsor Mine Supply Depot 003 is not ready.");
   }
}

function explosivesSupply4::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply4=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Repulsor Mine.");
      $explosivesSupply4 = "not ready";
      schedule("$explosivesSupply4 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Repulsor Mine Supply Depot 004 is ready.\");",30);
   }
   else if(($explosivesSupply4=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have a Repulsor Mine!");
   }
   else if($explosivesSupply4!="ready")
   {
      say(%player,%player,"<f1>Repulsor Mine Supply Depot 004 is not ready.");
   }
}

function explosivesSupply5::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply5=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Repulsor Mine.");
      $explosivesSupply5 = "not ready";
      schedule("$explosivesSupply5 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Repulsor Mine Supply Depot 005 is ready.\");",30);
   }
   else if(($explosivesSupply5=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have a Repulsor Mine!");
   }
   else if($explosivesSupply5!="ready")
   {
      say(%player,%player,"<f1>Repulsor Mine Supply Depot 005 is not ready.");
   }
}

//  BombZen Pad Functionality
function BombZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);
      %player.InPad = true; 
}

function BombZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 40, 70, true); 
}

function BombZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombHeal Pad Functionality
function BombHeal::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);
      %player.InPad = true; 
}

function BombHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 0, 0, true); 
}

function BombHeal::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombAmmo Pad Functionality
function BombAmmo::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);
      %player.InPad = true; 
}

function BombAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, 40, 40, true); 
}

function BombAmmo::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

function explosives::trigger::onEnter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.spawndelay==false)
   {
      say(%player,%player,"<f1>Re-entering mission area. Repulsor Mine back online.");
   }
}

function explosives::trigger::onLeave(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.deathdelay==false)
   {
      say(%player,%player,"<f1>Leaving mission area. Repulsor Mine disabled.");
   }
}