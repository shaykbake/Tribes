// FILENAME:	DM_Meteor_Shower.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
// 
// RANDOM QUOTE: "Behold, the power of cheese."
//------------------------------------------------------------------------------

$missionName = "DM_Meteor_Shower";

$ballshot = false;
$prom = "MissionGroup\\PROM";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	venusSounds();

	// Start the meteor showers
	dropMeteor("default", -40, -1, 2454, -139, 2767, 159, -18, -346, 602, 584);
	 
	// Schedule a meteor storm
	%randomTime = randomInt(30, 100);
	schedule("randomDeathStorm();", %randomTime);
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DeathMatch Meteor Shower! Get to the underground base to avoid the meteors. Use the teleporter at Nav 001 to teleport to the top of the mountain. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%vehicleId)
{
%vehicleId.name = getHUDName(%vehicleId);
}

function onMissionLoad()
{
   cdAudioCycle("Newtech", "Mechsoul", "Terror"); 
}

function randomDeathStorm()
{
	%nextStorm = randomInt(30, 180);

	Say(0, 0, "WARNING:  Meteor shower detected! Get underground fast!");
	dropMeteor("default", 1, 3, 2454, -139, 2767, 159, -18, -346, 602, 584);
    
    %dropMeteors = "dropMeteor(\"default\", 1, 3, 2454, -139, 2767, 159, -18, -346, 602, 584);";

	schedule(%dropMeteors, 4);
	schedule(%dropMeteors, 8);
	schedule(%dropMeteors, 12);
	schedule(%dropMeteors, 16);
	schedule(%dropMeteors, 20);
	schedule(%dropMeteors, 24);
	schedule(%dropMeteors, 28);
	schedule(%dropMeteors, 32);
	schedule(%dropMeteors, 36);

	schedule("randomDeathStorm();", %nextStorm);
}

// ---------------------------------------------------------------------------------------------------
function dropMeteor(%type, %rate, %count, %xHigh1, %yHigh1, %xHigh2, %yHigh2, %xLow1, %yLow1, %xLow2, %yLow2){

	%ceiling = 1800;

	if(%xHigh2 == "") %xHigh2 = 0;
	if(%yHigh2 == "") %yHigh2 = 0;
	if(%xLow1 == "") %xLow1 = 0;
	if(%yLow1 == "") %yLow1 = 0;
	if(%xLow2 == "") %xLow2 = 0;
	if(%yLow2 == "") %yLow2 = 0;

	if(%xLow1 == 0 && %xLow2 == 0 && %yLow1 == 0 && %yLow2 == 0){
		%xLow1 = %xHigh1;
		%xLow2 = %xHigh2;
		%yLow1 = %yHigh1;
		%yLow2 = %yHigh2;
	}

	%startX = randomInt(%xHigh1, %xHigh2);
	%startY = randomInt(%yHigh1, %yHigh2);

	%endX = randomInt(%xLow1, %xLow2);
	%endY = randomInt(%yLow1, %yLow2);

	if(%type == "focus"){
		%startX = %endX = %xHigh1;
		%startY = %endY = %yHigh1;		
	}
	else if(%type == "focalStart"){
		%startX = %xLow1;
		%startY = %yLow1;
	}
	else if(%type == "focalEnd"){
		%endX = %xLow1;
		%endY = %yLow1;
	}
	else if(%type == "vertical"){
		%startX = %endX;
		%startY = %endY;
	}

	%endZ = getTerrainHeight(%endX, %endY);

	// Determine when the next meteorite will fall
	%when = %rate;
	if(%when < 0){
		%when = %when * -1;
		%when = randomFloat(0, %when);
	}

	if(count != -1)
		%count = %count - 1;

	%nextMeteorite = "dropMeteor(";
	%nextMeteorite = strcat(%nextMeteorite, %type, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %rate, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %count, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xHigh1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yHigh1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xHigh2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yHigh2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xLow1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yLow1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xLow2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yLow2, ");");

	dropPod(%startX, %startY, %ceiling, %endX, %endY, %endZ, "MissionGroup\\meteorite");
	%doDamage = "blast(";
	%doDamage = strcat(%doDamage, "\"MissionGroup\\\\meteorite\", 100, 8000, \"MissionGroup\\\\meteorite\");");

	// This next bit calculates when the meteor hits the ground and damages the herc when it does...
	%timeDrop = ((%endX - %startX) * (%endX - %startX));
	%timeDrop = %timeDrop + ((%endY - %startY) * (%endY - %startY));
	%timeDrop = %timeDrop + ((%ceiling - %endZ) * (%ceiling - %endZ));
	%timeDrop = sqrt(%timeDrop);
	%timeDrop = %timeDrop / 400;
	schedule(%doDamage, %timeDrop);

	if(%count != 0)
		schedule(%nextMeteorite, %when);
}

//Teleport to top of mountain
function Teleport::trigger::onEnter(%this, %object)
{
	setPosition(%object, -1746, 184, 939);
}

//Drop Promie in a drop pod when you shoot the magic ball.

function Ball::structure::onAttacked(%attacked, %attacker)
{
  if($ballshot == false)
  {
      $ballshot = true;
      dropPod(-4662,-23,836,-4662.56,-22.9276,598.53,$prom);
  }
}


