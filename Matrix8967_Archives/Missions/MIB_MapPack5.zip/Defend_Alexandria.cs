// FILENAME:	Defend_Alexandria.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Defend Alexandria";

// Allows the missions to cycle (defaulted to true)
$cycleMissions = true;

$missionLoaded = false;
$missionStarted = false;
$currentActivePlayers = 0;
$successLock = false;
$vehId = "N/A";
$vehType = "N/A";
$squad1Activated = false;
$squad2Activated = false;
$squad3Activated = false;
$squad4Activated = false;


exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
}

Pilot BigRadar
{
   id = 28;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 1500.0;
   deactivateBuff = 1000.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot SmallRadar
{
   id = 29;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 200.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot NoRadar
{
   id = 30;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 75.0;
   deactivateBuff = 0.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Reinforcement1
{
   id = 31;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "MAJ Davis [IMP/KN/T32]";
};

Pilot Reinforcement2
{
   id = 32;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "SGT Sanchez [IMP/KN/T32]";
};

Pilot Reinforcement3
{
   id = 33;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "LT Jackson [IMP/KN/T32]";
};

Pilot Reinforcement4
{
   id = 34;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "CPT Slater [IMP/KN/T32]";
};

Pilot Reinforcement5
{
   id = 35;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "PVT Daniels [IMP/KN/T32]";
};

function onMissionStart()
{
   desertSounds();
   $navDelta = getObjectId("Missiongroup\\navDelta");
   $AIhercs = "Missiongroup/AIhercs";
   $reinforcements = "Missiongroup/reinforcements";
   $reinforcement1 = getObjectId("Missiongroup\\reinforcements\\reinforcement1");
   $reinforcement2 = getObjectId("Missiongroup\\reinforcements\\reinforcement2");
   $reinforcement3 = getObjectId("Missiongroup\\reinforcements\\reinforcement3");
   $reinforcement4 = getObjectId("Missiongroup\\reinforcements\\reinforcement4");
   $reinforcement5 = getObjectId("Missiongroup\\reinforcements\\reinforcement5");
   $emperor = getObjectId("Missiongroup\\base\\emperor");
   $cameraMarker = getObjectId("Missiongroup\\CameraMarker");
   $squad1Herc1 = getObjectId("Missiongroup\\squad1Herc1");
   $squad1Herc2 = getObjectId("Missiongroup\\squad1Herc2");
   $squad1Herc3 = getObjectId("Missiongroup\\squad1Herc3");   
   $squad2Herc1 = getObjectId("Missiongroup\\squad2Herc1");
   $squad2Herc2 = getObjectId("Missiongroup\\squad2Herc2");
   $squad2Herc3 = getObjectId("Missiongroup\\squad2Herc3");
   $squad3Herc1 = getObjectId("Missiongroup\\squad3Herc1");
   $squad3Herc2 = getObjectId("Missiongroup\\squad3Herc2");
   $squad3Herc3 = getObjectId("Missiongroup\\squad3Herc3");
   $squad4Herc1 = getObjectId("Missiongroup\\AIhercs\\squad4Herc1");
   $squad4Herc2 = getObjectId("Missiongroup\\AIhercs\\squad4Herc2");
   $squad4Herc3 = getObjectId("Missiongroup\\AIhercs\\squad4Herc3");
   $squad1path = "Missiongroup/squad1path";
   $squad2path = "Missiongroup/squad2path";
   $squad3path = "Missiongroup/squad3path";
   $squad4path = "Missiongroup/squad4path";
   $reinforcementPath = "Missiongroup/reinforcementPath";
   $base = "Missiongroup/base";
   setVehicleRadarVisible($reinforcement1, false);
   setVehicleRadarVisible($reinforcement2, false);
   setVehicleRadarVisible($reinforcement3, false);
   setVehicleRadarVisible($reinforcement4, false);
   setVehicleRadarVisible($reinforcement5, false);
   setVehicleRadarVisible($squad1Herc1, false);
   setVehicleRadarVisible($squad1Herc2, false);
   setVehicleRadarVisible($squad1Herc3, false);
   setVehicleRadarVisible($squad2Herc1, false);
   setVehicleRadarVisible($squad2Herc2, false);
   setVehicleRadarVisible($squad2Herc3, false);
   setVehicleRadarVisible($squad3Herc1, false);
   setVehicleRadarVisible($squad3Herc2, false);
   setVehicleRadarVisible($squad3Herc3, false);
   setVehicleRadarVisible($squad4Herc1, false);
   setVehicleRadarVisible($squad4Herc2, false);
   setVehicleRadarVisible($squad4Herc3, false);
}

function player::onAdd(%player)
{
   say(%player, 0, "Mission 6: Defend Alexandria. The cybrids have pushed our forces back to Egypt. The glitches are now within a few hours distance of Nova Alexandria. Your mission is to defend Nova Alexandria and the emperor at all costs. Humanity still has hope, Grandmaster Caanon and his brother Harabec are on a mission to destroy Prometheus himself. We must hold off the cybrids until we recieve word that operation Cardinal Spear has succeeded.");
   %player.status = "Waiting";
   %player.vehicle = "N/A";
   %player.reload = true;
   %player.late = true;
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Watching", "CloudBurst", "Terror", "Mechsoul", "Yougot");
   setGameInfo("<F2>GAME TYPE:<F0>  MIB Multiplayer Campaign\n\n<F2>MISSION:<F0>  Mission 6: Defend Alexandria\n\n<F2>MISSION CREATOR:<F0>  Com. Sentinal [M.I.B.]\n\n<F2>BRIEFING:<F0>\n\nDespite the empire's efforts to hold back the cybrids, the glitches have pushed our forces back to Egypt. The cybrids are now within a few hours distance of Nova Alexandria's gates. Your squad is stationed closest to the city, so we are sending you in. Your mission is to defend Nova Alexandria and the emperor at all costs. Humanity still has hope, Grandmaster Caanon and his brother Harabec are on a mission to destroy Prometheus himself. We must hold off the cybrids until we recieve word that operation Cardinal Spear has succeeded.\n\n<f3>TIP: Each player has 1 emergency reload per mission. Scan another vehicle to use it at any time during the mission.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download the entire MIB Multiplayer Campaign & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      %player.status = "Waiting";
      %player.late = true;
   }
   $currentActivePlayers = "N/A";
   if($missionLoaded == false)
   {
      $missionLoaded = true;
      say("Everybody", 0, "Mission 6: Defend Alexandria. The cybrids have pushed our forces back to Egypt. The glitches are now within a few hours distance of Nova Alexandria. Your mission is to defend Nova Alexandria and the emperor at all costs. Humanity still has hope, Grandmaster Caanon and his brother Harabec are on a mission to destroy Prometheus himself. We must hold off the cybrids until we recieve word that operation Cardinal Spear has succeeded.");
   }
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player != 0)
   {
      %player.late = true;
      %player.reload = false;
      if((getTeam(%vehicleId)!=*IDSTR_TEAM_YELLOW)&&(%player!=0))
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      }
      if($missionStarted==true)
      {
         schedule("healObject(" @ %vehicleId @ ", -50000);", 1);
         messageBox(%player, "You cannot join a game in progress. Please wait until the mission is over to join.");
      }
      else if($missionStarted==false)
      {
         %player.late = false;
         %player.status = "Alive";
         %player.vehicle = getVehicleName(%vehicleId);
      }
   }
}

function dropZoneWarning::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if($missionStarted == false)
      {
         say(%player, 1, "<F5>WARNING: Exiting the drop zone will start the mission.");
      }
   }
}

function exitDropZone::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      $missionStarted = true;
      startMessage();
   }
}

function startMessage()
{
   $playersNotLate = 0;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(%player.late==false)
      {
         $playersNotLate++;
      }
      %player.reload = false;
   }
   $currentActivePlayers = $playersNotLate;
   if($playersNotLate == 1)
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " player.");
   }
   else
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " players.");
   }
   setNavDelta();
}

function setNavDelta()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navDelta, true, %vehicleId); 
   }
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Despite the empire's efforts to hold back the cybrids, the glitches have pushed our forces back to Egypt.\");", 5);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: The cybrids are now within a few hours distance of Nova Alexandria's gates. Your squad is stationed closest to the city, so we are sending you in.\");", 11);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Your mission is to defend Nova Alexandria and the emperor at all costs.\");", 17);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Humanity still has hope, Grandmaster Caanon and his brother Harabec are on a mission to destroy Prometheus himself.\");", 23);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: We must hold off the cybrids until we recieve word that operation Cardinal Spear has succeeded.\");", 29);
}

function squad1::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad1Activated == false))
   {
      $squad1Activated = true;
      schedule("squad2();", 120);
      setVehicleRadarVisible($squad1Herc1, true);
      setVehicleRadarVisible($squad1Herc2, true);
      setVehicleRadarVisible($squad1Herc3, true);
      dropPod(1231, 1695, (253 + 1000), 1231, 1695, 253, $squad1Herc1);
      schedule("dropPod(1360, 1763, (231 + 1000), 1360, 1763, 231, $squad1Herc2);", 3);
      schedule("dropPod(1291, 1892, (211 + 1000), 1291, 1892, 211, $squad1Herc3);", 6);
      order($squad1Herc1, speed, high);
      order($squad1Herc2, speed, high);
      order($squad1Herc3, speed, high);
      order($squad1Herc1, attack, $base);
      order($squad1Herc2, attack, $base);
      order($squad1Herc3, attack, $base);
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 4))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 4)
      {
         %extraHercs = 4;
      }
      %x1 = 1441;
      %y1 = 1630;
      %x2 = 1671;
      %y2 = 2092;
      $currentPath = $base;
      %dropInterval = 5;
      %speed = "high";
      %radar = "normal";
      dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
   }
}

function squad2()
{
   $squad2Activated = true;
   schedule("squad3();", 120);
   addToSet($AIhercs, $squad2Herc1);
   addToSet($AIhercs, $squad2Herc2);
   addToSet($AIhercs, $squad2Herc3);
   setVehicleRadarVisible($squad2Herc1, true);
   setVehicleRadarVisible($squad2Herc2, true);
   setVehicleRadarVisible($squad2Herc3, true);
   dropPod(-176, 3566, (252 + 1000), -176, 3566, 252, $squad2Herc1);
   schedule("dropPod(-612, 3486, (253 + 1000), -612, 3486, 253, $squad2Herc2);", 3);
   schedule("dropPod(193, 3455, (203 + 1000), 193, 3455, 203, $squad2Herc3);", 6);
   order($squad2Herc1, attack, $base);
   order($squad2Herc2, attack, $base);
   order($squad2Herc3, attack, $base);
   order($squad2Herc1, speed, high);
   order($squad2Herc2, speed, high);
   order($squad2Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 5))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 5)
   {
      %extraHercs = 5;
   }
   %x1 = 504;
   %y1 = 3639;
   %x2 = -1025;
   %y2 = 4517;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function squad3()
{
   $squad3Activated = true;
   schedule("squad4();", 120);
   addToSet($AIhercs, $squad3Herc1);
   addToSet($AIhercs, $squad3Herc2);
   addToSet($AIhercs, $squad3Herc3);
   setVehicleRadarVisible($squad3Herc1, true);
   setVehicleRadarVisible($squad3Herc2, true);
   setVehicleRadarVisible($squad3Herc3, true);
   dropPod(-1612, 2079, (257 + 1000), -1612, 2079, 257, $squad3Herc1);
   schedule("dropPod(-1776, 2227, (285 + 1000), -1776, 2227, 285, $squad3Herc2);", 3);
   schedule("dropPod(-1172, 2516, (275 + 1000), -1172, 2516, 275, $squad3Herc3);", 6);
   order($squad3Herc1, speed, high);
   order($squad3Herc2, speed, high);
   order($squad3Herc3, speed, high);
   order($squad3Herc1, attack, $base);
   order($squad3Herc2, attack, $base);
   order($squad3Herc3, attack, $base);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 6;
   }
   %x1 = 504;
   %y1 = 3639;
   %x2 = -1025;
   %y2 = 4517;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function squad4()
{
   $squad4Activated = true;
   addToSet($AIhercs, $squad4Herc1);
   addToSet($AIhercs, $squad4Herc2);
   addToSet($AIhercs, $squad4Herc3);
   setVehicleRadarVisible($squad4Herc1, true);
   setVehicleRadarVisible($squad4Herc2, true);
   setVehicleRadarVisible($squad4Herc3, true);
   dropPod(778, 1606, (263 + 1000), 778, 1606, 263, $squad4Herc1);
   schedule("dropPod(-1720, 2363, (282 + 1000), -1720, 2363, 282, $squad4Herc2);", 3);
   schedule("dropPod(-81, 3344, (252 + 1000), -81, 3344, 252, $squad4Herc3);", 6);
   order($squad4Herc1, attack, $base);
   order($squad4Herc2, attack, $base);
   order($squad4Herc3, attack, $base);
   order($squad4Herc1, speed, high);
   order($squad4Herc2, speed, high);
   order($squad4Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 7))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 7)
   {
      %extraHercs = 7;
   }
   %x1 = 697;
   %y1 = 3022;
   %x2 = 1389;
   %y2 = 3688;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      else if(%radar == "none")
      {
         setPilotId(%herc, 30);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      order(%herc, guard, $emperor);
      order(%herc, attack, $currentPath);
      %target = $currentPath;
      schedule("safetyNetAttack(" @ %herc @ ", " @ %target @ ");", 5);
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %radar @ ");", %dropInterval);
   }
}

function randomCybVeh()
{
   %type = randomInt(0,13);
   if(%type==0)
   {
      $vehId = 20;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 21;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 25;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 26;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 28;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==13)
   {
      $vehId = 28;
      $vehType = "herc";
   }
}

function safetyNetAttack(%herc, %target)
{
   order(%herc, attack, %target);
   schedule("safetyNetAttack2(" @ %herc @ ", " @ %target @ ");", 5);
}

function safetyNetAttack2(%herc, %target)
{
   order(%herc, attack, %target);
   %xInit = getPosition(%herc, x);
   %yInit = getPosition(%herc, y);
   schedule("safetyNetGuard(" @ %herc @ ", " @ %target @ ", " @ %xInit @ ", " @ %yInit @ ");", 10);
}

function safetyNetGuard(%herc, %target, %xInit, %yInit)
{
   %x2 = getPosition(%herc, x);
   %y2 = getPosition(%herc, y);
   %deltaX = abs(%x2 - %xInit);
   %deltaY = abs(%y2 - %yInit);
   %distance = getHypotenuse(%deltaX, %deltaY);
   if(%distance < 50)
   {
      order(%herc, guard, $emperor);   
   }
   schedule("cleanUpDefectiveCybrid(" @ %herc @ ", " @ %xInit @ ", " @ %yInit @ ");", 10);
}

function cleanUpDefectiveCybrid(%herc, %xInit, %yInit)
{
   %x2 = getPosition(%herc, x);
   %y2 = getPosition(%herc, y);
   %deltaX = abs(%x2 - %xInit);
   %deltaY = abs(%y2 - %yInit);
   %distance = getHypotenuse(%deltaX, %deltaY);
   if(%distance < 50)
   {
      healObject(%herc, -99999);
      schedule("deleteObject(" @ %herc @ ");", 3);
   }
}

function abs(%number)
{
   if(%number >= 0)
   {
      %answer = %number;
   }
   else if(%number < 0)
   {
      %answer = -%number;
   }
}

function getHypotenuse(%deltaX, %deltaY, %deltaZ)
{
   if(%deltaZ == "")
   {
      %answer = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
   }
   else if(%deltaZ != "")
   {
      %hyp = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
      %answer = sqrt((%hyp * %hyp) + (%deltaZ * %deltaZ));
   }
   return %answer;
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   if(%player1 == 0)
   {
      if(($squad4Activated == true)&&(isGroupDestroyed($AIHercs) == true))
      {
         $successLock = true;
         playSound(0, "Mission_comp.wav", IDPRF_2D);
         messageBox(0, "Mission Successful");
         setPosition($reinforcement1, -176, 4000, 252);
         setPosition($reinforcement2, -208, 4050, 252);
         setPosition($reinforcement3, -147, 4050, 252);
         setPosition($reinforcement4, -115, 4100, 253);
         setPosition($reinforcement5, -236, 4100, 253);
         setVehicleRadarVisible($reinforcement1, true);
         setVehicleRadarVisible($reinforcement2, true);
         setVehicleRadarVisible($reinforcement3, true);
         setVehicleRadarVisible($reinforcement4, true);
         setVehicleRadarVisible($reinforcement5, true);
         order($reinforcement1, speed, high);
         order($reinforcement1, makeleader, true);
         order($reinforcements, formation, delta);
         order($reinforcement1, guard, $reinforcementPath);
         schedule("cinematic();", 5);
      }
      schedule("deleteObject(" @ %destroyed @ ");", 5);
   }
   else
   {
      if($missionStarted == true)
      {
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            reloadObject(%vehicleId, 10000);
         }
         if(%player1.late == false)
         {
            %player1.late = true;
            %player1.status = "Dead";
            $currentActivePlayers--;
            checkForPlayersDead();
         }
      }
      else
      {
         %player1.late = true;
         %player1.status = "Waiting";
      }
   }
   if(%player2 != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function structure::onDestroyed(%destroyed, %destroyer)
{
   if(isMember($base, %destroyed) == true)
   {
      if(isGroupDestroyed($base) == true)
      {
         baseDestroyed();
      }
   }
}

function baseDestroyed()
{
   say("Everybody", 3, "<F5>Emperor Petresun has been assassinated!");
   schedule("missionFailed();", 3);
}

function cybridBoundary::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(($squad1Activated == true)&&(%player == 0)&&(getTeam(%object) == *IDSTR_TEAM_RED)&&(%object != $reinforcement1)&&(%object != $reinforcement2)&&(%object != $reinforcement3)&&(%object != $reinforcement4)&&(%object != $reinforcement5))
   {
      healObject(%object, -99999);
   }
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player.reload == false)
   {
      %player.reload = true;
      reloadObject(%scanner, 99999);
      say(%player, %player, "<F5>Emergency reload initiated.");
   }
}

function checkForPlayersDead()
{
   %allDead = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%vehicleId != "") && (isGroupDestroyed(%vehicleId) == false))
      {
         %allDead = false;
      }
   }
   if(%allDead == true)
   {
      schedule("missionFailed();", 3);
   }
}

function cameraTest()
{
   $successLock = true;
   playSound(0, "Mission_comp.wav", IDPRF_2D);
   messageBox(0, "Mission Successful");
   setPosition($reinforcement1, -176, 4000, 252);
   setPosition($reinforcement2, -208, 4050, 252);
   setPosition($reinforcement3, -147, 4050, 252);
   setPosition($reinforcement4, -115, 4100, 253);
   setPosition($reinforcement5, -236, 4100, 253);
   setVehicleRadarVisible($reinforcement1, true);
   setVehicleRadarVisible($reinforcement2, true);
   setVehicleRadarVisible($reinforcement3, true);
   setVehicleRadarVisible($reinforcement4, true);
   setVehicleRadarVisible($reinforcement5, true);
   order($reinforcement1, speed, high);
   order($reinforcement1, makeleader, true);
   order($reinforcements, formation, delta);
   order($reinforcement1, guard, $reinforcementPath);
   schedule("cinematic();", 5);
}

function cinematic()
{
   setFlybyCamera($reinforcement1, -15, 150, 50);
   say("Everybody", 7, "<F5>MAJ Davis [IMP/KN/T32]: This is Major Davis of squad Tau-32, we have reinforcements coming in to secure the city.");
   schedule("say(\"Everybody\", 7, \"<F5>MAJ Davis [IMP/KN/T32]: We also have word that operation Cardinal Spear has been a success. Prometheus is no more!\");", 6);
   schedule("say(\"Everybody\", 8, \"<F5>LT Jackson [IMP/KN/T32]: Wooooh! Awesome!\", \"M10_Jaguar_wooh.wav\");", 9);
   schedule("say(\"Everybody\", 9, \"<F5>SGT Sanchez [IMP/KN/T32]: Aiyeeeehaah!\", \"M8_Hunter_aiyeehah.wav\");", 10.5);
   schedule("setDominantCamera($reinforcement1, $emperor, 0, -10, 3);", 10);
   schedule("setFlybyCamera($reinforcement1, 0, 150, 5);", 20);
   schedule("setDominantCamera($reinforcement1, $reinforcement2, -25, -25, 10);", 30);
   schedule("setCombatCamera($reinforcement1, $reinforcement2, L, 45);", 35);
   schedule("setDominantCamera($reinforcement1, $emperor, 0, -100, 15);", 40);
   schedule("setFlybyCamera($reinforcement1, -150, 150, 100);", 45);
   schedule("setTowerCamera($reinforcement1, -835, 1450, 450);", 60);
   schedule("setDominantCamera($emperor, $reinforcement1, 100, -100, 50);", 70);
   schedule("setFlybyCamera($reinforcement1, 0, -100, 25);", 80);
   schedule("setTowerCamera($cameraMarker, -342.52, 1351.67, 249.846);", 90);
   schedule("epilogue();", 95);
}

function epilogue()
{
   messageBox(0, "Without Prometheus to guide them, the cybrid forces fall into total chaos. Their formations break, and there will be many more imperial victories over the cybrids here on Earth.");
   messageBox(0, "Several imperial squads will be mobilized to clean up the remaining cybrids on both Earth and the colonies. Mars will also finally gain its independence from the empire.");
   messageBox(0, "The war has been won! Humanity is once again victorious!");
   missionSuccessful();
}

function missionSuccessful()
{
   flushConsoleScheduler();
   if($cycleMissions == true)
   {
      $MissionCycling::Stage0 = "Martian_Recon";
      $server::Mission = $MissionCycling::Stage0;
   }
   schedule("missionEndConditionMet();", 15);
}

function missionFailed()
{  
   if($successLock == false)
   {
      flushConsoleScheduler();
      playSound(0, "Mission_fail.wav", IDPRF_2D);
      messageBox(0, "Mission Failed");
      if($cycleMissions == true)
      {
         $MissionCycling::Stage0 = "Martian_Recon";
         $server::Mission = $MissionCycling::Stage0;
      }
      schedule("missionEndConditionMet();", 5);
   }
}

function onMissionEnd()
{
   deleteObject($AIhercs);
}

function getPlayerStatus(%player)
{
   return(%player.status);
}

function getActivePlayers()
{
   return($currentActivePlayers);
}

function getPlayerVehicle(%player)
{
   return(%player.vehicle);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";


	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
         $ScoreBoard::PlayerColumnFunction4 = "getPlayerVehicle";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = "Players Remaining";
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getActivePlayers";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}
