// FILENAME:	EXP_Stadium_2000.cs
//
// AUTHORS:  	Gen. DarkRaven [M.I.B.]
// "If anything could possibly go wrong, it will." - Murphy's Law
//------------------------------------------------------------------------------

$missionName = "EXP_Stadium_2000";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	marsSounds();
	earthquakesounds();
      $explosivesSupply1 = "ready";
      $explosivesSupply2 = "ready";
      $explosivesSupply3 = "ready";
      $explosivesSupply4 = "ready";
      $explosivesSupply5 = "ready";
      $explosivesSupply6 = "ready";
	$ban = "missiongroup/misc/flyer";
	$path = "missioncleanup";
	order($ban, speed, low);
	order($ban, guard, $path);
	meltdown();
}
function boom::structure::onadd(%this)
{
	%this = $bang;
}
function boom::structure::ondestroyed(%this, %destroyer)
{
	blast(%this, 0, 500, 10000);
}
function meltdown()
{
	Schedule("dead();", 600);
}
function dead()
{
	healobject($bang, -500000000);
}
function onMissionLoad()
{
   cdAudioCycle("Watching", "NewTech", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  DeathMatch\n\n<F2>MISSION:<F0>  EXP_Stadium_2000\n\nWelcome to Explosive Deathmatch! Your vehicle is equipped with explosives when you spawn. Shut down to set the explosives. You can toggle the amount of time until detonation by scanning a structure or another vehicle. Re-Supply your vehicle with explosives by walking into an Explosives Supply Depot. You cannot set explosives while in a pad. You can download EXP_Stadium_2000 & other missions made by Gen. DarkRaven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}
function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Explosive DeathMatch! Check the game info tab for the rules. You can download EXP_Stadium_2000 & other missions made by Gen. DarkRaven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.bombtime = 15;
   %player.laidBomb = false;
}
function player::onremove(%player)
{
   deleteobject(%player.bomb);
   deleteobject(%player.explosion);
}
function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %vehicleId.name=gethudname(%vehicleId);
   %player.hasBomb = true;
   %player.InPad = false;
   %player.spawndelay = true;
   schedule("spawndelay("@%player@");",5);
   if(%player.laidbomb==true)
   {
      %player.timeElapsed = getcurrenttime() - %player.setTime;
      %player.timeleft = %player.TempTime - %player.timeElapsed;
      setHudTimer(%player.timeleft, -1, "Explosives Timer", 1, %player); 
   }
	order($ban, guard, %player);
}   
function spawndelay(%player)
{
   %player.spawndelay = false;
}
function vehicle::onscan(%scanned,%scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%player.bombtime==10)
   {
      %player.bombtime = 15;
      say(%player,%player,"<f1>Explosives timer set to 15 seconds.");
   }
   else if(%player.bombtime==15)
   {
      %player.bombtime = 20;
      say(%player,%player,"<f1>Explosives timer set to 20 seconds.");
   }
   else if(%player.bombtime==20)
   {
      %player.bombtime = 30;
      say(%player,%player,"<f1>Explosives timer set to 30 seconds.");
   }
   else if(%player.bombtime==30)
   {
      %player.bombtime = 60;
      say(%player,%player,"<f1>Explosives timer set to 60 seconds.");
   }
   else if(%player.bombtime==60)
   {
      %player.bombtime = 120;
      say(%player,%player,"<f1>Explosives timer set to 2 minutes.");
   }
   else if(%player.bombtime==120)
   {
      %player.bombtime = 10;
      say(%player,%player,"<f1>Explosives timer set to 10 seconds.");
   }
}
function vehicle::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   
   %player2.deathdelay=true;
   schedule("deathdelay("@%player2@");",5);
   if(%player == 0)
   {
      say("Everybody",1,gethudname(%destroyed) @ " got blown up!");
   }
   else
   {
      vehicle::onDestroyedLog(%destroyed, %destroyer);
   
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
      
      // enforce the rules
      if($server::TeamPlay == true)
      {
         if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
         {
            antiTeamKill(%destroyer);
         }
      }   
   }
	if(%destroyed = $ban)
	{
		%clone = clone($ban);
		%clone = $ban;
		order($ban, speed, low);
		setposition($ban, 400, 0, 2000);
	}
}
function deathdelay(%player2)
{
   %player2.deathdelay = false;
}
function structure::onscan(%scanned,%scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%player.bombtime==10)
   {
      %player.bombtime = 15;
      say(%player,%player,"<f1>Explosives timer set to 15 seconds.");
   }
   else if(%player.bombtime==15)
   {
      %player.bombtime = 20;
      say(%player,%player,"<f1>Explosives timer set to 20 seconds.");
   }
   else if(%player.bombtime==20)
   {
      %player.bombtime = 30;
      say(%player,%player,"<f1>Explosives timer set to 30 seconds.");
   }
   else if(%player.bombtime==30)
   {
      %player.bombtime = 60;
      say(%player,%player,"<f1>Explosives timer set to 60 seconds.");
   }
   else if(%player.bombtime==60)
   {
      %player.bombtime = 120;
      say(%player,%player,"<f1>Explosives timer set to 2 minutes.");
   }
   else if(%player.bombtime==120)
   {
      %player.bombtime = 10;
      say(%player,%player,"<f1>Explosives timer set to 10 seconds.");
   }
}
function explosives::trigger::oncontact(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(isshutdown(%object)==false)
   {
      %player.justlaid = false;
   }
   if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%player.hasbomb==true)&&(%player.laidbomb==false))
   {  
      %player.justlaid = true;
      say(%player,%player,"<f5>Explosives Armed.");
      setexplosives(%object);
   }  
   else if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%player.hasbomb==false)&&(%player.justlaid==false))
   {  
      %player.justlaid = true;
      say(%player,%player,"<f1>You do not have explosives.");
   }
   else if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%player.hasbomb==true)&&(%player.laidbomb==true)&&(%player.justlaid==false))
   {
      %player.justlaid = true;   
      say(%player,%player,"<f1>You cannot lay more explosives until your current explosives have detonated.");
   }
}
function setexplosives(%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   %player.hasbomb = false;
   %player.laidbomb = true;
   %player.bomb = newobject("Explosives", StaticShape, "pr_prx.DTS");
   %player.x = getposition(%object,x);
   %player.y = getposition(%object,y);
   %player.z = getTerrainHeight(%player.x,%player.y)+0.2;
   setposition(%player.bomb,%player.x,%player.y,%player.z);
   %player.setTime = getcurrenttime();
   %player.TempTime = %player.bombtime;
   setHudTimer(%player.bombtime, -1, "Explosives Timer", 1, %player); 
   schedule("explode("@%player@");",%player.bombtime);
   %player.explosion = newobject("Explosion", StaticShape, "fx_exp_podT.DTS");
   setShapeVisibility(%player.explosion,false);
   playAnimSequence(%player.explosion,0,false);
   setposition(%player.explosion,%player.x,%player.y,(%player.z-0.2));
}
function explode(%player)
{
   if(%player!=0)
   {
      %object = playermanager::PlayerNumtoVehicleId(%player);
      setShapeVisibility(%player.explosion,true);
      playAnimSequence(%player.explosion,0,true);
      say(0,0,"<f5>" @ gethudname(%object) @ "'s explosives have detonated!","sfx_fog.wav"); 
      damageArea(%player.bomb,0,0,0,250,5000);
      schedule("DeleteItAll(" @ %player @ ");",1.067);
   }
}
function DeleteItAll(%player)
{
   deleteobject(%player.bomb);
   deleteobject(%player.explosion);
   %player.laidbomb = false;
}
function explosivesSupply1::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply1=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been supplied with explosives.");
      $explosivesSupply1 = "not ready";
      schedule("$explosivesSupply1 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Explosives Supply Depot 001 is ready.\");",30);
   }
   else if(($explosivesSupply1=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have explosives!");
   }
   else if($explosivesSupply1!="ready")
   {
      say(%player,%player,"<f1>Explosives Supply Depot 001 is not ready.");
   }
}
function explosivesSupply2::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply2=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been supplied with explosives.");
      $explosivesSupply2 = "not ready";
      schedule("$explosivesSupply2 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Explosives Supply Depot 002 is ready.\");",30);
   }
   else if(($explosivesSupply2=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have explosives!");
   }
   else if($explosivesSupply2!="ready")
   {
      say(%player,%player,"<f1>Explosives Supply Depot 002 is not ready.");
   }
}
function explosivesSupply3::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply3=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been supplied with explosives.");
      $explosivesSupply3 = "not ready";
      schedule("$explosivesSupply3 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Explosives Supply Depot 003 is ready.\");",30);
   }
   else if(($explosivesSupply3=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have explosives!");
   }
   else if($explosivesSupply3!="ready")
   {
      say(%player,%player,"<f1>Explosives Supply Depot 003 is not ready.");
   }
}
function explosivesSupply4::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply4=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been supplied with explosives.");
      $explosivesSupply4 = "not ready";
      schedule("$explosivesSupply4 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Explosives Supply Depot 004 is ready.\");",30);
   }
   else if(($explosivesSupply4=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have explosives!");
   }
   else if($explosivesSupply4!="ready")
   {
      say(%player,%player,"<f1>Explosives Supply Depot 004 is not ready.");
   }
}
function explosivesSupply5::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply5=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been supplied with explosives.");
      $explosivesSupply5 = "not ready";
      schedule("$explosivesSupply5 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Explosives Supply Depot 005 is ready.\");",30);
   }
   else if(($explosivesSupply5=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have explosives!");
   }
   else if($explosivesSupply5!="ready")
   {
      say(%player,%player,"<f1>Explosives Supply Depot 005 is not ready.");
   }
}
function explosivesSupply6::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply6=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been supplied with explosives.");
      $explosivesSupply6 = "not ready";
      schedule("$explosivesSupply6 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Explosives Supply Depot 006 is ready.\");",30);
   }
   else if(($explosivesSupply6=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>You already have explosives!");
   }
   else if($explosivesSupply6!="ready")
   {
      say(%player,%player,"<f1>Explosives Supply Depot 006 is not ready.");
   }
}

//  BombZen Pad Functionality
function BombZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);
      %player.InPad = true; 
}

function BombZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 40, 70, true); 
}

function BombZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombHeal Pad Functionality
function BombHeal::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);
      %player.InPad = true; 
}

function BombHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 0, 0, true); 
}

function BombHeal::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombAmmo Pad Functionality
function BombAmmo::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);
      %player.InPad = true; 
}

function BombAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, 40, 40, true); 
}

function BombAmmo::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}
function explosives::trigger::onEnter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.spawndelay==false)
   {
      say(%player,%player,"<f1>Re-entering mission area. Explosives back online.");
   }
}
function explosives::trigger::onLeave(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.deathdelay==false)
   {
      say(%player,%player,"<f1>Leaving mission area. Explosives disabled.");
   }
}
//??????????????????????//
//	TELEPORTERS	//
//??????????????????????//
function hiddentele::trigger::oncontact(%this, %who)
{
	setposition(%who, 400, 850, 81);
}
function telem::trigger::oncontact(%this, %who)
{
	setposition(%who, 400, 0, 110);
}
function telef::trigger::oncontact(%this, %who)
{
	setposition(%who, 565, 165, 110);
}
function telen::trigger::oncontact(%this, %who)
{
	setposition(%who, 230, -160, 110);
}
function teleout::trigger::oncontact(%this, %who)
{
	setposition(%who, 400, 10, 110);
}

function setDefaultMissionItems()
{
   allowWeapon( 3, FALSE );    //Disrupter Weapon  
}