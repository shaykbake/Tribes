// FILENAME:	SPYDER_Sand_Dunes.cs
//
// SCRIPT BY:  	Com. Sentinal [M.I.B.]
//
// MAP BY:        Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "SPYDER_Sand_Dunes";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   desertSounds();
   $explosivesSupply1 = "ready";
   $explosivesSupply2 = "ready";
   $explosivesSupply3 = "ready";
   $explosivesSupply4 = "ready";
   $explosivesSupply5 = "ready";
   $boom1 = "MissionGroup/Anims/boom1";
   $boom2 = "MissionGroup/Anims/boom2";
   $boom3 = "MissionGroup/Anims/boom3";
   $boom4 = "MissionGroup/Anims/boom4";
   $boom5 = "MissionGroup/Anims/boom5";
   $boom6 = "MissionGroup/Anims/boom6";
   $boom7 = "MissionGroup/Anims/boom7";
   $boom8 = "MissionGroup/Anims/boom8";
   $boom9 = "MissionGroup/Anims/boom9";
   $boom10 = "MissionGroup/Anims/boom10";
   $boom11 = "MissionGroup/Anims/boom11";
   $boom12 = "MissionGroup/Anims/boom12";
   $boom13 = "MissionGroup/Anims/boom13";
   $boom14 = "MissionGroup/Anims/boom14";
   $boom15 = "MissionGroup/Anims/boom15";      
   $mines = "MissionGroup/mines";   
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "CloudBurst", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Spyder Mine DeathMatch\n\n<F2>MISSION:<F0>  SPYDER_Sand_Dunes\n\nWelcome to Spyder Mine Deathmatch! Your vehicle is equipped with a Spyder Mine when you spawn. Set a nav marker, then shut down to deploy the Spyder Mine. The Spyder Mine drone will then proceed to your nav marker and deploy a proximity mine field there. You can toggle your mine field's density by scanning a structure or another vehicle. To re-equip your vehicle with a Spyder Mine, merely walk into an Spyder Mine Supply Depot. You can download SPYDER_Sand_Dunes & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   //reset the boomkills
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.boomkill = 0;
      %player.armed = false;
      %player.spyderlock = false;
      %player.deathdelay = false;
   }
}

function player::onAdd(%player)
{
   %player.boomkill = 0;
   %player.armed = false;
   %player.spyderlock = false;
   %player.deathdelay = false;
   %player.leftgame = false;
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Spyder Mine DeathMatch! Check the game info tab for the rules. You can download SPYDER_Sand_Dunes & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   deleteItAll(%player);
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
   %player.leftgame = true;
   %player.deleted = true;
   %player.armed = false;
   deleteobject(%player.spyder);
   %player.spyder = "";
   deleteobject(%player.explosion);
   %player.explosion = "";
   deleteobject(%player.mine1);
   %player.mine1 = "";
   deleteobject(%player.mine2);
   %player.mine2 = "";
   deleteobject(%player.mine3);
   %player.mine3 = "";
   deleteobject(%player.mine4);
   %player.mine4 = "";
   deleteobject(%player.mine5);
   %player.mine5 = "";
   deleteobject(%player.mine6);
   %player.mine6 = "";
   deleteobject(%player.mine7);
   %player.mine7 = "";
   deleteobject(%player.mine8);
   %player.mine8 = "";
   deleteobject(%player.mine9);
   %player.mine9 = "";
   deleteobject(%player.mine10);
   %player.mine10 = "";
   deleteobject(%player.minetrigger11);
   %player.minetrigger11 = "";
   deleteobject(%player.minetrigger21);
   %player.minetrigger21 = "";
   deleteobject(%player.minetrigger31);
   %player.minetrigger31 = "";
   deleteobject(%player.minetrigger41);
   %player.minetrigger41 = "";
   deleteobject(%player.minetrigger12);
   %player.minetrigger12 = "";
   deleteobject(%player.minetrigger22);
   %player.minetrigger22 = "";
   deleteobject(%player.minetrigger32);
   %player.minetrigger32 = "";
   deleteobject(%player.minetrigger42);
   %player.minetrigger42 = "";
   deleteobject(%player.minetrigger13);
   %player.minetrigger13 = "";
   deleteobject(%player.minetrigger23);
   %player.minetrigger23 = "";
   deleteobject(%player.minetrigger33);
   %player.minetrigger33 = "";
   deleteobject(%player.minetrigger43);
   %player.minetrigger43 = "";
   deleteobject(%player.minetrigger14);
   %player.minetrigger14 = "";
   deleteobject(%player.minetrigger24);
   %player.minetrigger24 = "";
   deleteobject(%player.minetrigger34);
   %player.minetrigger34 = "";
   deleteobject(%player.minetrigger44);
   %player.minetrigger44 = "";
   deleteobject(%player.minetrigger15);
   %player.minetrigger15 = "";
   deleteobject(%player.minetrigger25);
   %player.minetrigger25 = "";
   deleteobject(%player.minetrigger35);
   %player.minetrigger35 = "";
   deleteobject(%player.minetrigger45);
   %player.minetrigger45 = "";
   deleteobject(%player.minetrigger16);
   %player.minetrigger16 = "";
   deleteobject(%player.minetrigger26);
   %player.minetrigger26 = "";
   deleteobject(%player.minetrigger36);
   %player.minetrigger36 = "";
   deleteobject(%player.minetrigger46);
   %player.minetrigger46 = "";
   deleteobject(%player.minetrigger17);
   %player.minetrigger17 = "";
   deleteobject(%player.minetrigger27);
   %player.minetrigger27 = "";
   deleteobject(%player.minetrigger37);
   %player.minetrigger37 = "";
   deleteobject(%player.minetrigger47);
   %player.minetrigger47 = "";
   deleteobject(%player.minetrigger18);
   %player.minetrigger18 = "";
   deleteobject(%player.minetrigger28);
   %player.minetrigger28 = "";
   deleteobject(%player.minetrigger38);
   %player.minetrigger38 = "";
   deleteobject(%player.minetrigger48);
   %player.minetrigger48 = "";
   deleteobject(%player.minetrigger19);
   %player.minetrigger19 = "";
   deleteobject(%player.minetrigger29);
   %player.minetrigger29 = "";
   deleteobject(%player.minetrigger39);
   %player.minetrigger39 = "";
   deleteobject(%player.minetrigger49);
   %player.minetrigger49 = "";
   deleteobject(%player.minetrigger110);
   %player.minetrigger110 = "";
   deleteobject(%player.minetrigger210);
   %player.minetrigger210 = "";
   deleteobject(%player.minetrigger310);
   %player.minetrigger310 = "";
   deleteobject(%player.minetrigger410);
   %player.minetrigger410 = "";
}


function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %player.hasBomb = true;
   %player.InPad = false;
   %player.spawndelay = true;
   %player.minefield = "normal";
   %player.destroyer = "Nobody";
   %player.hitamine = false;
   schedule("spawndelay(" @ %player @ ");", 5);
}   

function spawndelay(%player)
{
   %player.spawndelay = false;
}

function trigger::onEnter(%trigger, %vehicleId)
{
   %player1 = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   if(getObjectName(%trigger) == "mine")
   {
      %player2 = %trigger.owner;
      if(%player2.armed == true)
      {
         %player1.hitamine = true;
         explodeMine(%player1, %player2, %trigger);
      }
   }
}

function explodeMine(%player1, %player2, %trigger)
{
   %player1.destroyer = %player2;
   %x = getPosition(%trigger.mine, x);
   %y = getPosition(%trigger.mine, y);
   %z = getTerrainHeight(%x, %y);
   setposition(%player2.explosion, %x, %y, (%z - 1));
   setShapeVisibility(%player2.explosion, true);
   playAnimSequence(%player2.explosion, 0, true);
   playSound(0, "sfx_fog.wav", IDPRF_2D); 
   damageArea(%trigger, 0, 0, 0, 150, 2500);
   schedule("setShapeVisibility(" @ %player2.explosion @ ", false);", 1.067);
   schedule("playAnimSequence(" @ %player2.explosion @ ", 0, false);", 1.1);
   schedule("deleteMine(" @ %player2 @ ", " @ %trigger @ ");", 1.067);
   schedule("victimSurvived(" @ %player1 @ ");", 2);
}

function deleteMine(%player, %trigger)
{
   for(%num = 1; %num < 11; %num++)
   {
      if(%trigger.mine == %player.mine[%num])
      {
         deleteObject(%player.mine[%num]);
         %player.mine[%num] = "";
         deleteObject(%player.minetrigger1[%num]);
         %player.minetrigger1[%num] = "";
         deleteObject(%player.minetrigger2[%num]);
         %player.minetrigger2[%num] = "";
         deleteObject(%player.minetrigger3[%num]);
         %player.minetrigger3[%num] = "";
         deleteObject(%player.minetrigger4[%num]);
         %player.minetrigger4[%num] = "";
      }
   }
}

function victimSurvived(%player)
{
   %player.destroyer = "Nobody";
   %player.hitamine = false;
}

function vehicle::ondestroyed(%destroyed, %destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   
   %player2.deathdelay = true;
   schedule("deathdelay(" @ %player2 @ ");", 5);
   if(%player2.hitamine == true)
   {
      if(%player2.destroyer != %player2)
      {
         say("Everybody", 3, getHudName(%destroyed) @ " was destroyed by one of " @ getName(%player2.destroyer) @ "'s mines!");
         if($server::TeamPlay == false)
         {
            %killer = %player2.destroyer;
            %killer.boomkill = %killer.boomkill + 3;
         }
         else if(($server::TeamPlay == true)&&(getTeam(%player2.destroyer) != getTeam(%player2)))
         {
            %killer = %player2.destroyer;
            %killer.boomkill = %killer.boomkill + 3;
         }
      }
      else
      {
         say("Everybody", 4, getHudName(%destroyed) @ " accidently stepped on one of his own mines!");
      }
   }
   else if((%player == 0)&&(%player2.hitamine == false))
   {
      say("Everybody", 0, getHudName(%destroyed) @ " got blown up!");
   }
   else
   {
      vehicle::onDestroyedLog(%destroyed, %destroyer);
   
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
      
      // enforce the rules
      if($server::TeamPlay == true)
      {
         if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
         {
            antiTeamKill(%destroyer);
         }
      }   
   }
}

function deathdelay(%player2)
{
   %player2.deathdelay = false;
}

function vehicle::onscan(%scanned, %scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%player.minefield == "normal")
   {
      %player.minefield = "dense";
      say(%player, %player, "<f1>Mine field density: Dense");
   }
   else if(%player.minefield == "dense")
   {
      %player.minefield = "extremelydense";
      say(%player, %player, "<f1>Mine field density: Extremely Dense");
   }
   else if(%player.minefield == "extremelydense")
   {
      %player.minefield = "extremelysparse";
      say(%player, %player, "<f1>Mine field density: Extremely Sparse");
   }
   else if(%player.minefield == "extremelysparse")
   {
      %player.minefield = "sparse";
      say(%player, %player, "<f1>Mine field density: Sparse");
   }
   else if(%player.minefield == "sparse")
   {
      %player.minefield = "normal";
      say(%player, %player, "<f1>Mine field density: Normal");
   }
}

function structure::onscan(%scanned, %scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%player.minefield == "normal")
   {
      %player.minefield = "dense";
      say(%player, %player, "<f1>Mine field density: Dense");
   }
   else if(%player.minefield == "dense")
   {
      %player.minefield = "extremelydense";
      say(%player, %player, "<f1>Mine field density: Extremely Dense");
   }
   else if(%player.minefield == "extremelydense")
   {
      %player.minefield = "extremelysparse";
      say(%player, %player, "<f1>Mine field density: Extremely Sparse");
   }
   else if(%player.minefield == "extremelysparse")
   {
      %player.minefield = "sparse";
      say(%player, %player, "<f1>Mine field density: Sparse");
   }
   else if(%player.minefield == "sparse")
   {
      %player.minefield = "normal";
      say(%player, %player, "<f1>Mine field density: Normal");
   }
}

function explosives::trigger::onContact(%trigger, %vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   if(isshutdown(%vehicleId) == false)
   {
      %player.justlaid = false;
   }
   if((%player.InPad == false)&&(isshutdown(%vehicleId) == true)&&(%player.hasbomb == true)&&(%player.justlaid == false)&&(%player.deathdelay == false))
   {  
      %player.justlaid = true;
      deploySpyder(%vehicleId);
   }  
   else if((%player.InPad == false)&&(isshutdown(%vehicleId) == true)&&(%player.hasbomb == false)&&(%player.justlaid == false)&&(%player.deathdelay == false))
   {  
      %player.justlaid = true;
      say(%player, %player, "<f1>Your vehicle is not equipped with a Spyder Mine.");
   }
}

function deploySpyder(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player.spyderlock == false)
   {
      say(%player, %player, "<f5>Spyder Mine deployed.", "C5_pbbbbbt.WAV");
      %player.spyderlock = true;
      %player.armed = false;
      deleteItAll(%player);
      %player.spyder = newObject("spyder", StaticShape, "pr_ara.DTS");
      %x = getPosition(%vehicleId, x);
      %y = getPosition(%vehicleId, y);
      %z = getTerrainHeight(%x, %y);
      setPosition(%player.spyder, %x, %y, %z);
      %player.deleted = false;
      addToSet($mines, %player.spyder);
      playAnimSequence(%player.spyder, 0, false);
      schedule("playAnimSequence(" @ %player.spyder @ ", 0, true);", 0.5);
      %player.hasbomb = false;
      %x1 = getPosition(%vehicleId, x);
      %y1 = getPosition(%vehicleId, y);
      %nav = getVehicleNavMarkerId(%vehicleId);
      %x2 = getPosition(%nav, x);
      %y2 = getPosition(%nav, y);
      %distance = getDistance(%vehicleId, %nav);
      if(%distance == 0)
      {
         %increments = 1;
         %xOffset = 7.07;
         %yOffset = 7.07;
      }
      else
      {
         %increments = %distance / 10;
         %xDist = %x2 - %x1;
         %yDist = %y2 - %y1;
         %xOffset = %xDist / %increments;
         %yOffset = %yDist / %increments;
      }
      schedule("repulse(" @ %player @ ", " @ %player.spyder @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %increments @ ");", 1);
   }
   else
   {
      say(%player, %player, "<f1>You must wait until your current mine field is armed before you can deploy another Spyder Mine.");
   }
}

function repulse(%player, %spyder, %xOffset, %yOffset, %increments)
{
   if((%increments > 1)&&(%player.deleted == false))
   {
      %increments--;
      %x = getPosition(%spyder, x) + %xOffset;
      %y = getPosition(%spyder, y) + %yOffset;
      %z = getTerrainHeight(%x, %y);
      setPosition(%spyder, %x, %y, %z);
      schedule("repulse(" @ %player @ ", " @ %spyder @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %increments @ ");", 0.1);
   }
   else
   {
      if(%player.deleted == false)
      {
         %player.explosion = newobject("Explosion", StaticShape, "fx_exp_podT.DTS");
         addToSet($mines, %player.explosion);
         setShapeVisibility(%player.explosion, false);
         playAnimSequence(%player.explosion, 0, false);
         %x = getPosition(%spyder, x);
         %y = getPosition(%spyder, y);
         %z = getTerrainHeight(%x, %y);
         setPosition(%player.explosion, %x, %y, %z);
         layMines(%player, %spyder, %player.minefield, 1);
      }
   }
}

function layMines(%player, %spyder, %configuration, %num)
{
   if(%player.leftgame == false)
   {
      if(%num <= 10)
      {
         %player.mine[%num] = newobject("prox", StaticShape, "pr_prx.DTS");
         addToSet($mines, %player.mine[%num]);
         %x1 = getposition(%spyder, x);
         %y1 = getposition(%spyder, y);
         if(%configuration == "extremelysparse")
         {
            %low = -200;
            %high = 200;
         } 
         else if(%configuration == "sparse")
         {
            %low = -150;
            %high = 150;
         } 
         else if(%configuration == "normal")
         {
            %low = -100;
            %high = 100;
         } 
         else if(%configuration == "dense")
         {
            %low = -50;
            %high = 50;
         }
         else if(%configuration == "extremelydense")
         {
            %low = -25;
            %high = 25;
         }
         %x = randomInt((%x1 + %low), (%x1 + %high));
         %y = randomInt((%y1 + %low), (%y1 + %high));
         %z = getTerrainHeight(%x, %y);
         setPosition(%player.mine[%num], %x, %y, (%z + 0.5));
         %player.minetrigger1[%num] = newObject("mine", SimTrigger);
         %trigger1 = %player.minetrigger1[%num];
         %trigger1.owner = %player;
         %trigger1.mine = %player.mine[%num];
         %player.minetrigger2[%num] = newObject("mine", SimTrigger);
         %trigger2 = %player.minetrigger2[%num];
         %trigger2.owner = %player;
         %trigger2.mine = %player.mine[%num];
         %player.minetrigger3[%num] = newObject("mine", SimTrigger);
         %trigger3 = %player.minetrigger3[%num];
         %trigger3.owner = %player;
         %trigger3.mine = %player.mine[%num];
         %player.minetrigger4[%num] = newObject("mine", SimTrigger);
         %trigger4 = %player.minetrigger4[%num];
         %trigger4.owner = %player;
         %trigger4.mine = %player.mine[%num];
         addToSet($mines, %player.minetrigger1[%num]);
         addToSet($mines, %player.minetrigger2[%num]);
         addToSet($mines, %player.minetrigger3[%num]);
         addToSet($mines, %player.minetrigger4[%num]);
         setPosition(%player.minetrigger1[%num], (%x - 1), (%y - 1), (%z + 1));
         setPosition(%player.minetrigger2[%num], (%x - 1), (%y + 1), (%z + 1));
         setPosition(%player.minetrigger3[%num], (%x + 1), (%y - 1), (%z + 1));
         setPosition(%player.minetrigger4[%num], (%x + 1), (%y + 1), (%z + 1));
         %num++;
         schedule("layMines(" @ %player @ ", " @ %spyder @ ", " @ %configuration @ ", " @ %num @ ");", 1);
      }
      else
      {
         deleteObject(%player.spyder);
         %player.spyder = "";
         %player.armed = true;
         %player.spyderlock = false;
         say(%player, %player, "<F5>Mine field armed.", "C2_tattadit.WAV");
      }
   }
   else if(%player.leftgame == true)
   {
      deleteItAll(%player);
   }
}

function deleteItAll(%player)
{
   %player.deleted = true;
   %player.armed = false;
   deleteobject(%player.spyder);
   %player.spyder = "";
   deleteobject(%player.explosion);
   %player.explosion = "";
   deleteobject(%player.mine1);
   %player.mine1 = "";
   deleteobject(%player.mine2);
   %player.mine2 = "";
   deleteobject(%player.mine3);
   %player.mine3 = "";
   deleteobject(%player.mine4);
   %player.mine4 = "";
   deleteobject(%player.mine5);
   %player.mine5 = "";
   deleteobject(%player.mine6);
   %player.mine6 = "";
   deleteobject(%player.mine7);
   %player.mine7 = "";
   deleteobject(%player.mine8);
   %player.mine8 = "";
   deleteobject(%player.mine9);
   %player.mine9 = "";
   deleteobject(%player.mine10);
   %player.mine10 = "";
   deleteobject(%player.minetrigger11);
   %player.minetrigger11 = "";
   deleteobject(%player.minetrigger21);
   %player.minetrigger21 = "";
   deleteobject(%player.minetrigger31);
   %player.minetrigger31 = "";
   deleteobject(%player.minetrigger41);
   %player.minetrigger41 = "";
   deleteobject(%player.minetrigger12);
   %player.minetrigger12 = "";
   deleteobject(%player.minetrigger22);
   %player.minetrigger22 = "";
   deleteobject(%player.minetrigger32);
   %player.minetrigger32 = "";
   deleteobject(%player.minetrigger42);
   %player.minetrigger42 = "";
   deleteobject(%player.minetrigger13);
   %player.minetrigger13 = "";
   deleteobject(%player.minetrigger23);
   %player.minetrigger23 = "";
   deleteobject(%player.minetrigger33);
   %player.minetrigger33 = "";
   deleteobject(%player.minetrigger43);
   %player.minetrigger43 = "";
   deleteobject(%player.minetrigger14);
   %player.minetrigger14 = "";
   deleteobject(%player.minetrigger24);
   %player.minetrigger24 = "";
   deleteobject(%player.minetrigger34);
   %player.minetrigger34 = "";
   deleteobject(%player.minetrigger44);
   %player.minetrigger44 = "";
   deleteobject(%player.minetrigger15);
   %player.minetrigger15 = "";
   deleteobject(%player.minetrigger25);
   %player.minetrigger25 = "";
   deleteobject(%player.minetrigger35);
   %player.minetrigger35 = "";
   deleteobject(%player.minetrigger45);
   %player.minetrigger45 = "";
   deleteobject(%player.minetrigger16);
   %player.minetrigger16 = "";
   deleteobject(%player.minetrigger26);
   %player.minetrigger26 = "";
   deleteobject(%player.minetrigger36);
   %player.minetrigger36 = "";
   deleteobject(%player.minetrigger46);
   %player.minetrigger46 = "";
   deleteobject(%player.minetrigger17);
   %player.minetrigger17 = "";
   deleteobject(%player.minetrigger27);
   %player.minetrigger27 = "";
   deleteobject(%player.minetrigger37);
   %player.minetrigger37 = "";
   deleteobject(%player.minetrigger47);
   %player.minetrigger47 = "";
   deleteobject(%player.minetrigger18);
   %player.minetrigger18 = "";
   deleteobject(%player.minetrigger28);
   %player.minetrigger28 = "";
   deleteobject(%player.minetrigger38);
   %player.minetrigger38 = "";
   deleteobject(%player.minetrigger48);
   %player.minetrigger48 = "";
   deleteobject(%player.minetrigger19);
   %player.minetrigger19 = "";
   deleteobject(%player.minetrigger29);
   %player.minetrigger29 = "";
   deleteobject(%player.minetrigger39);
   %player.minetrigger39 = "";
   deleteobject(%player.minetrigger49);
   %player.minetrigger49 = "";
   deleteobject(%player.minetrigger110);
   %player.minetrigger110 = "";
   deleteobject(%player.minetrigger210);
   %player.minetrigger210 = "";
   deleteobject(%player.minetrigger310);
   %player.minetrigger310 = "";
   deleteobject(%player.minetrigger410);
   %player.minetrigger410 = "";
}

function onMissionEnd()
{
   deleteobject($mines);
}

function getPlayerScore(%player)
{
   return((getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints)) + %player.boomkill;
}

function explosivesSupply1::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply1=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply1 = "not ready";
      schedule("$explosivesSupply1 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 001 is ready.\");",30);
   }
   else if(($explosivesSupply1=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply1!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 001 is not ready.");
   }
}

function explosivesSupply2::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply2=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply2 = "not ready";
      schedule("$explosivesSupply2 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 002 is ready.\");",30);
   }
   else if(($explosivesSupply2=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply2!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 002 is not ready.");
   }
}

function explosivesSupply3::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply3=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply3 = "not ready";
      schedule("$explosivesSupply3 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 003 is ready.\");",30);
   }
   else if(($explosivesSupply3=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply3!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 003 is not ready.");
   }
}

function explosivesSupply4::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply4=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply4 = "not ready";
      schedule("$explosivesSupply4 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 004 is ready.\");",30);
   }
   else if(($explosivesSupply4=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply4!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 004 is not ready.");
   }
}

function explosivesSupply5::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply5=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply5 = "not ready";
      schedule("$explosivesSupply5 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 005 is ready.\");",30);
   }
   else if(($explosivesSupply5=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply5!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 005 is not ready.");
   }
}

//  BombZen Pad Functionality
function BombZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);
      %player.InPad = true; 
}

function BombZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 40, 70, true); 
}

function BombZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombHeal Pad Functionality
function BombHeal::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);
      %player.InPad = true; 
}

function BombHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 0, 0, true); 
}

function BombHeal::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombAmmo Pad Functionality
function BombAmmo::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);
      %player.InPad = true; 
}

function BombAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, 40, 40, true); 
}

function BombAmmo::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}


function explosives::trigger::onEnter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.spawndelay==false)
   {
      say(%player,%player,"<f1>Re-entering mission area. Spyder Mine back online.");
   }
}

function explosives::trigger::onLeave(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.deathdelay==false)
   {
      say(%player,%player,"<f1>Leaving mission area. Spyder Mine disabled.");
   }
}


// DM_Sand_Dunes stuff past this point
//-------------------------------------------------------------------------

function boom1::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom1,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom1,0,true);
      damageArea($boom1,0,0,0,150,2000);
      schedule("deleteobject($boom1);",1.067);
   }
   else
   {
      schedule("deleteobject($boom1);",1.067);
   }
}

function boom2::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom2,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom2,0,true);
      damageArea($boom2,0,0,0,150,2000);
      schedule("deleteobject($boom2);",1.067);
   }
   else
   {
      schedule("deleteobject($boom2);",1.067);
   }
}

function boom3::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom3,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom3,0,true);
      damageArea($boom3,0,0,0,150,2000);
      schedule("deleteobject($boom3);",1.067);
   }
   else
   {
      schedule("deleteobject($boom3);",1.067);
   }
}

function boom4::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom4,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom4,0,true);
      damageArea($boom4,0,0,0,150,2000);
      schedule("deleteobject($boom4);",1.067);
   }
   else
   {
      schedule("deleteobject($boom4);",1.067);
   }
}

function boom5::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom5,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom5,0,true);
      damageArea($boom5,0,0,0,150,2000);
      schedule("deleteobject($boom5);",1.067);
   }
   else
   {
      schedule("deleteobject($boom5);",1.067);
   }
}

function boom6::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom6,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom6,0,true);
      damageArea($boom6,0,0,0,150,2000);
      schedule("deleteobject($boom6);",1.067);
   }
   else
   {
      schedule("deleteobject($boom6);",1.067);
   }
}

function boom7::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom7,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom7,0,true);
      damageArea($boom7,0,0,0,150,2000);
      schedule("deleteobject($boom7);",1.067);
   }
   else
   {
      schedule("deleteobject($boom7);",1.067);
   }
}

function boom8::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom8,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom8,0,true);
      damageArea($boom8,0,0,0,150,2000);
      schedule("deleteobject($boom8);",1.067);
   }
   else
   {
      schedule("deleteobject($boom8);",1.067);
   }
}

function boom9::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom9,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom9,0,true);
      damageArea($boom9,0,0,0,150,2000);
      schedule("deleteobject($boom9);",1.067);
   }
   else
   {
      schedule("deleteobject($boom9);",1.067);
   }
}

function boom10::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom10,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom10,0,true);
      damageArea($boom10,0,0,0,150,2000);
      schedule("deleteobject($boom10);",1.067);
   }
   else
   {
      schedule("deleteobject($boom10);",1.067);
   }
}

function boom11::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom11,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom11,0,true);
      damageArea($boom11,0,0,0,150,2000);
      schedule("deleteobject($boom11);",1.067);
   }
   else
   {
      schedule("deleteobject($boom11);",1.067);
   }
}

function boom12::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom12,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom12,0,true);
      damageArea($boom12,0,0,0,150,2000);
      schedule("deleteobject($boom12);",1.067);
   }
   else
   {
      schedule("deleteobject($boom12);",1.067);
   }
}

function boom13::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom13,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom13,0,true);
      damageArea($boom13,0,0,0,150,2000);
      schedule("deleteobject($boom13);",1.067);
   }
   else
   {
      schedule("deleteobject($boom13);",1.067);
   }
}

function boom14::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom14,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom14,0,true);
      damageArea($boom14,0,0,0,150,2000);
      schedule("deleteobject($boom14);",1.067);
   }
   else
   {
      schedule("deleteobject($boom14);",1.067);
   }   
}

function boom15::structure::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%player==0)
   {
      %destroyed.x = getposition(%destroyed,x);
      %destroyed.y = getposition(%destroyed,y);
      %destroyed.z = getTerrainHeight(%destroyed.x,%destroyed.y);
      setposition($boom15,%destroyed.x,%destroyed.y,%destroyed.z);
      playAnimSequence($boom15,0,true);
      damageArea($boom15,0,0,0,150,2000);
      schedule("deleteobject($boom15);",1.067);
   }
   else
   {
      schedule("deleteobject($boom15);",1.067);
   }
}