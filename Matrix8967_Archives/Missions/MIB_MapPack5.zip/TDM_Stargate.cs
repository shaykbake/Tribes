// FILENAME:	TDM_Stargate.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "TDM_Stargate";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

	$server::DisableTeamRed = false;
	$server::DisableTeamBlue = false;
	$server::DisableTeamYellow = true;
	$server::DisableTeamPurple = true;
}

function onMissionStart()
{
	marsSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to Team DeathMatch Stargate! Go through the Stargates to attack the enemy base. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

function ZenTransporter::trigger::onContact(%this, %object)
{
	setPosition(%object, 7914.42, 2742.25, 603);
}

function ZenTransporter2::trigger::onContact(%this, %object)
{
	setPosition(%object, -1867.88, 1809.29, 423);
}