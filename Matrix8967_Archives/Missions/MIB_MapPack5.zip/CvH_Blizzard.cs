// FILENAME:	CvH_Blizzard.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------

// this var 
$missionName = "CvH_Blizzard";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	iceSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to Cybrid Vs. Human Team DeathMatch! Cybrids must be on blue team, Humans must be on yellow team. You can download CvH_Blizzard & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad(){
   cdAudioCycle("Gnash", "Cloudburst", "Cyberntx"); 
}

//From this line to the next line is the script needed for Cybrid Vs. Human


function setDefaultMissionItems()
{
    allowVehicle("all", true);
   allowComponent("all", true);
   allowWeapon("all", true);
}

//heres what I added -JR

function vehicle::onAdd(%this)
{
   // Cybrid vs Humans ... Cybrids must be blue, Humans must be yellow
   if(getVehicleTechBase(%this) == "H" && getTeam(%this) != *IDSTR_TEAM_YELLOW)
   {
      setTeam(%this, *IDSTR_TEAM_YELLOW);
      say(PlayerManager::vehicleIdToPlayerNum(%this), 1234, "Humans must be on the YELLOW team!");
      redrop(%this);
   }
   else if(getVehicleTechBase(%this) == "C" && getTeam(%this) != *IDSTR_TEAM_BLUE)
   {
      setTeam(%this, *IDSTR_TEAM_BLUE);
      say(PlayerManager::vehicleIdToPlayerNum(%this), 1234, "Cybrids must be on the BLUE team!");
      redrop(%this);
   }

}

