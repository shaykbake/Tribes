// FILENAME:	 FTAG_ThunderStorm.cs
//
// AUTHOR:  	 Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "FTAG_ThunderStorm";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = false;	

      // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

      // what can the server admin choose for available teams
      $server::disableTeamRed = false;
      $server::disableTeamBlue = false;
      $server::disableTeamYellow = true;
      $server::disableTeamPurple = true;

      // Time limit
      $server::TimeLimit = 20;
}

// move the map
$server::HudMapViewOffsetX = 5196.1;
$server::HudMapViewOffsetY = 1240.2;

function onMissionStart()
{
   temperateSounds();
   // ThunderStorm Stuff
   stormsounds();
   $StormStarted = false;
   $bolt = getObjectId("MissionGroup\\Bolt");
   $rod1 = getObjectId("MissionGroup\\Rods\\rod1");
   $rod2 = getObjectId("MissionGroup\\Rods\\rod2");
   $rod3 = getObjectId("MissionGroup\\Rods\\rod3");
   $rod4 = getObjectId("MissionGroup\\Rods\\rod4");
   $rod5 = getObjectId("MissionGroup\\Rods\\rod5");
   $rod6 = getObjectId("MissionGroup\\Rods\\rod6");
   $rod7 = getObjectId("MissionGroup\\Rods\\rod7");
   $rod8 = getObjectId("MissionGroup\\Rods\\rod8");
   $rod9 = getObjectId("MissionGroup\\Rods\\rod9");
   $rod10 = getObjectId("MissionGroup\\Rods\\rod10");
   // Flag Tag Stuff
   $startTime = getCurrentTime(); 
   $flag = getobjectId("MissionGroup\\blueflag");
   $CenterNav = getobjectId("MissionGroup\\CenterNav");
   $gamestart = false;
   $triggeron = true;
   $flagholder = "nobody";
}

function onMissionLoad()
{
   cdAudioCycle("Cloudburst", "Terror", "Cyberntx","Mechsoul","Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Flag Tag\n\n<F2>MISSION:<F0>  FTAG_ThunderStorm\n\nWelcome to Flag Tag (FTAG)! After there is at least 2 players in the game, grab the flag & hold it to score 1 point each second. There are no points awarded for kills, so you must have the flag to score. You can steal the flag by killing the flagholder. Padkilling the flagholder is encouraged. If you go 600 meters away from Nav Alpha, you will be killed for going out of bounds. You can download FTAG_ThunderStorm & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.score = 0;
   }
}

function player::onadd(%player) 
{
   %player.spawned = false;
   %player.score = 0;
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Flag Tag! Check the game info tab for the rules. Severe thunderstorms have been detected in the area. Watch out for lightning strikes! You can download FTAG_ThunderStorm & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
   if(playerManager::getPlayerCount()==2)
   {
      messageBox("Everybody", "All other players have left the game. You are the winner!");
      schedule("missionEndConditionMet();", 5);
   }
   else if(playerManager::getPlayerCount()==1)
   {
      schedule("missionEndConditionMet();", 1);
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %player.spawned = true;
   if($StormStarted==false)
   {
      $StormStarted = true;
      schedule("storm();",15);
      unAnimate();
   }
   %vehicleId.name = getHUDName(%vehicleId);
   %now = getCurrentTime(); 
   %totalTime = ($server::TimeLimit * 60); 
   %timeLeft = (%totalTime - (%now - $startTime));
   setHudTimer(%timeLeft, -1, "Mission Time Left", 1, %player); 
}

function flag::trigger::onEnter(%this,%object)
{
   if(($triggeron == true) && ($gamestart == false) && (playerManager::getPlayerCount()>=2))
   {      
      setvehiclespecialidentity(%object, on, blue);
      setshapevisibility($flag, false);
      $gamestart = true;
      $triggeron = false;
      $flagholder = %object;
      scoreflagholder();
      say("everybody",1, "<f5>" @ %object.name @ " has the flag!");
   }
   else if(($triggeron == true) && ($gamestart == false) && (playerManager::getPlayerCount()<2))
   {
      say("everybody",1,"<f5>There must be two players in the server before you can play!");
   }
   else if(($triggeron == true) && ($gamestart == true))
   {
      setvehiclespecialidentity(%object, on, blue);
      setshapevisibility($flag, false);
      $triggeron = false;
      $flagholder = %object;
      say("everybody",1, "<f5>" @ %object.name @ " has the flag!");
   } 
}

function scoreflagholder()
{
   %player = playerManager::vehicleIdToPlayerNum($flagholder);
   %player.score++;
   %distance = getdistance($flagholder, $CenterNav);
  
   if(%distance >= 600)
   {
      healobject($flagholder, -50000);
      say("everybody",1, "<f5>The Flag Holder went out of bounds!"); 
   }
   schedule("scoreflagholder();",1);
}     

function storm()
{
   %count = playerManager::getPlayerCount();
   if(%count<3)
   {
      %random1 = randomint(1,3);
      if((%random1==1) && (%count>1))
      {
         %num = 0;
         %random2 = randomInt(1,%count);   
         for(%i=0;%i<%count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %num++;
            if(%num==%random2)
            {
               strike(%player);
            }
         }
      }
      else
      {
         strikeRod();
      }
   }
   else
   {
      %random1 = randomint(1,2);
      if(%random1==1)
      {
         %num = 0;
         %random2 = randomInt(1,%count);   
         for(%i=0;%i<%count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %num++;
            if(%num==%random2)
            {
               strike(%player);
            }
         }
      }
      else
      {
         strikeRod();
      }
   }
}

function strike(%player)
{
   %target = playermanager::playernumtovehicleid(%player);
   %x = getposition(%target,x);
   %y = getposition(%target,y);
   %z = getposition(%target,z)-150;
   setposition($bolt,%x,%y,%z);
   if(%player.spawned==true)
   {
      say(0,2,"<f1>"@getname(%player)@" got struck by lightning!","sfx_thunder1.wav");
   }
   else if(%player.spawned==false)
   {
      playsound(0,"sfx_thunder1.wav",IDPRF_2D);
   }
   damagearea(%target,0,0,0,150,1000);
   fadeevent(%player,in,0.3,1,1,1);
   schedule("fadeevent("@%player@",in,0.3,1,1,1);",0.7);
   schedule("fadeevent("@%player@",in,0.3,1,1,1);",1.2);
   schedule("setposition($bolt,8000,-12000,-1000);",1.3);
   %count = playermanager::getPlayerCount();
   for(%i=0;%i<%count; %i++)
   {
      %player2 = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playernumtovehicleId(%player2);
      if((getDistance(%vehicleId,%target)<=300) && (%vehicleId!=%target))
      {
         fadeevent(%player2,in,0.3,1,1,1);
         schedule("fadeevent("@%player2@",in,0.3,1,1,1);",0.7);
      }
   }
   %time = randomInt(20,90);
   schedule("storm();",%time);
}

function strikeRod()
{
   %random = randomInt(1,10);
   if(%random==1)
   {
      %rod = $rod1;
   }
   else if(%random==2)
   {
      %rod = $rod2;
   }
   else if(%random==3)
   {
      %rod = $rod3;
   }
   else if(%random==4)
   {
      %rod = $rod4;
   }
   else if(%random==5)
   {
      %rod = $rod5;
   }
   else if(%random==6)
   {
      %rod = $rod6;
   }
   else if(%random==7)
   {
      %rod = $rod7;
   }
   else if(%random==8)
   {
      %rod = $rod8;
   }
   else if(%random==9)
   {
      %rod = $rod9;
   }
   else if(%random==10)
   {
      %rod = $rod10;
   }
   %x = getposition(%rod,x);
   %y = getposition(%rod,y);
   %z = getposition(%rod,z)-150;
   setposition($bolt,%x,%y,%z);
   damagearea(%rod,0,0,0,150,1000);
   playsound(0,"sfx_thunder1.wav",IDPRF_2D);
   schedule("setposition($bolt,8000,-12000,-1000);",1.3);
   %count = playermanager::getPlayerCount();
   for(%i=0;%i<%count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playernumtovehicleId(%player);
      if(getDistance(%vehicleId,%rod)<=300)
      {
         fadeevent(%player,in,0.3,1,1,1);
         schedule("fadeevent("@%player@",in,0.3,1,1,1);",0.7);
      }
   }
   %time = randomInt(20,90);
   schedule("storm();",%time);

}

function Animate()
{
   playAnimSequence($rod8,0,true);
   schedule("unAnimate();",60);
}

function unAnimate()
{
   playAnimSequence($rod8,0,false);
   schedule("Animate();",60);
}
     
function vehicle::ondestroyed(%destroyed,%destroyer)
{
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   %player2.spawned = false;   
   if(%player == 0)
   {
      say(0,0,"<f0>" @ getname(%destroyed) @ " died.");
   }
   else
   {
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
      
      // enforce the rules
      if($server::TeamPlay == true)
      {
         if((getTeam(%destroyed)==getTeam(%destroyer))&&(%destroyed!=%destroyer))
         {
            antiTeamKill(%destroyer);
         }
      }
   }   
   if((%destroyed == $flagholder) && (%player.spawned == true))
   {
      $flagholder = %destroyer;
      setvehiclespecialidentity(%destroyer, on, blue);
      say("everybody",1, "<f5>" @ %destroyer.name @ " has the flag!");
   }
   else if((%destroyed == $flagholder) && (%player.spawned == false))
   {
      $flagholder = "nobody";
      setshapevisibility($flag, true);
      $triggeron = true;
      say("everybody",1,"<f5>The flag has been returned to Nav Alpha!");
   }   
   else if((%destroyed == $flagholder) && (%player==0))
   {
      $flagholder = "nobody";
      setshapevisibility($flag, true);
      $triggeron = true;
      say("everybody",1,"<f5>The flag has been returned to Nav Alpha!");
   }
}
   
function getPlayerScore(%player) 
{ 
   return(%player.score);
}    

function onMissionEnd()
{
   flushConsoleScheduler();
}

// Take away light, fast hercs so they cant run around like crazy.
function setDefaultMissionItems()
{
   allowVehicle(all, true); // All Hercs
   allowVehicle(4, false);  // No talons
   allowVehicle(13, false); // No knight's talons
   allowVehicle(20, false); // No seekers
   allowVehicle(35, false); // No metagen seekers
   allowVehicle(21, false); // No goads
   allowVehicle(36, false); // No metagen goads

   // No Tracking weapons 
   allowWeapon(all, true);
   allowWeapon(124, false);
   allowWeapon(125, false);
   allowWeapon(126, false);
   allowWeapon(127, false);
   allowWeapon(128, false);
   allowWeapon(129, false);
   allowWeapon(130, false);
   allowWeapon(131, false);
   allowWeapon(132, false);
   allowWeapon(133, false);
   allowWeapon(147, false);
   allowWeapon(150, false);   
}