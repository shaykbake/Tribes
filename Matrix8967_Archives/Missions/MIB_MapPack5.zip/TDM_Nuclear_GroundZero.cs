// FILENAME:	TDM_Nuclear_GroundZero.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "TDM_Nuclear_GroundZero";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$server::HudMapViewOffsetX = 800;
$server::HudMapViewOffsetY = 6230;

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   venusSounds();
   $blueNuke = "Used";
   $redNuke = "Used";
   $blueTarget = "Nothing";
   $redTarget = "Nothing";
   $blueTargetSpotted = false;
   $redTargetSpotted = false;
   $blueDracoLaunched = false;
   $redDracoLaunched = false;
 
   //Shrike Missile Husks for the bombs
   $blueBomb = getObjectId("Missiongroup\\blueBomb");
   $redBomb = getObjectId("Missiongroup\\redBomb");

   //Waypoints (Put them where they are placed in this map in relation to the bases)
   $blueWaypoint = getObjectId("Missiongroup\\blueWaypoints\\blueWaypoint");
   $redWaypoint = getObjectId("Missiongroup\\redWaypoints\\redWaypoint");
   $blueWaypoint2 = getObjectId("Missiongroup\\blueWaypoints\\blueWaypoint2");
   $redWaypoint2 = getObjectId("Missiongroup\\redWaypoints\\redWaypoint2");
   
   //PodExplosion Animations (Buzzbum MOD - FX Shapes)
   $blueExplosion = getObjectId("Missiongroup\\blueExplosion");
   $redExplosion = getObjectId("Missiongroup\\redExplosion");
   
   //Thumper Animations (Buzzbum MOD - FX Shapes)
   $blueShockwave = getObjectId("Missiongroup\\blueShockwave");
   $redShockwave = getObjectId("Missiongroup\\redShockwave");

   $blueSpotter = "Nobody";
   $redSpotter = "Nobody";
   $blueInitCheck = false;
   $redInitCheck = false;

   $blueStartTime = 0;
   $redStartTime = 0;
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to DeathMatch Nuclear Ground Zero! Check the game info tab for the rules and information on using nukes. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   setHudTimer(0, 0, "", 2, %player); 
   %now = getCurrentTime();
   if((getTeam(%vehicleId) == *IDSTR_TEAM_BLUE)&&($blueNuke == "Building"))
   {
      %timeLeft = (180  - (%now - $blueStartTime));
      setHudTimer(%timeLeft, -1, "Building Nuke:", 2, %player); 
   }
   else if((getTeam(%vehicleId) == *IDSTR_TEAM_RED)&&($redNuke == "Building"))
   {
      %timeLeft = (180  - (%now - $redStartTime));
      setHudTimer(%timeLeft, -1, "Building Nuke:", 2, %player); 
   }
}

function onMissionLoad()
{
   cdAudioCycle("Terror", "Newtech", "Mechsoul"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Nuclear Team DeathMatch\n\n<F2>MISSION:<F0>  TDM_Nuclear_GroundZero\n\nWelcome to Team DeathMatch Nuclear Ground Zero! Scan your team's nuclear silo to begin production of your team's nuke. After your nuke is built, use LTADs to spot for the bomber air strike. To use LTADs, press the \"S\" key while locked on a hostile target. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function blueSilo::structure::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(getTeam(%scanner)==getTeam(%scanned))
   {
      if($blueNuke=="Used")
      {
         $blueNuke = "Building";
         $blueProd = "<F1>Production of Blue Team's nuke will now begin.";
         teamTransmissions($blueProd, *IDSTR_TEAM_BLUE);
         schedule("buildBlueNuke();",3);
      }
      else if($blueNuke=="Building")
      {
         say(%player, %player, "<F1>Blue Team's nuke is currently being built.");
      }
      else if($blueNuke=="Ready")
      {
         say(%player, %player, "<F1>Blue Team already has a nuke built & ready to use.");
      }
   }
   else
   {
      say(%player, %player, "<F1>This is not your team's nuclear silo.");
   }
}

function redSilo::structure::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(getTeam(%scanner)==getTeam(%scanned))
   {
      if($redNuke=="Used")
      {
         $redNuke = "Building";
         $redProd = "<F1>Production of Red Team's nuke will now begin.";
         teamTransmissions($redProd, *IDSTR_TEAM_RED);
         schedule("buildRedNuke();",3);
      }
      else if($redNuke=="Building")
      {
         say(%player, %player, "<F1>Red Team's nuke is currently being built.");
      }
      else if($redNuke=="Ready")
      {
         say(%player, %player, "<F1>Red Team already has a nuke built & ready to use.");
      }
   }
   else
   {
      say(%player, %player, "<F1>This is not your team's nuclear silo.");
   }
}

function buildBlueNuke()
{
   $blueBuild = "<F1>The nuke will be ready in 3 minutes...";
   teamTransmissions($blueBuild, *IDSTR_TEAM_BLUE);
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(getTeam(%player) == *IDSTR_TEAM_BLUE)
      {
         setHudTimer(180, -1, "Building Nuke:", 2, %player);
      }
   }
   $blueStartTime = getCurrentTime();
   schedule("blueNukeReady();",180);
}

function buildRedNuke()
{
   $redBuild = "<F1>The nuke will be ready in 3 minutes...";
   teamTransmissions($redBuild, *IDSTR_TEAM_RED);
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(getTeam(%player) == *IDSTR_TEAM_RED)
      {
         setHudTimer(180, -1, "Building Nuke:", 2, %player);
      }
   }
   $redStartTime = getCurrentTime();
   schedule("redNukeReady();",180);
}

function blueNukeReady()
{
   $blueNuke = "Ready";
   $blueReady = "<F1>Blue Team's nuke is ready to be used.";
   $blueReady2 = "<F5>NEXUS: WARNING, SENSORS INDICATE A NUKE//WEAPON HAS BEEN BUILT AT BLUE BASE.";
   teamTransmissions($blueReady, *IDSTR_TEAM_BLUE);
   teamTransmissions($blueReady2, *IDSTR_TEAM_RED);
   $blueLTADs = "<F1>Use LTADS to spot for the Draco bomber air strike.";
   schedule("teamTransmissions($blueLTADs, *IDSTR_TEAM_BLUE);",3);
}

function redNukeReady()
{
   $redNuke = "Ready";
   $redReady = "<F1>Red Team's nuke is ready to be used.";
   $redReady2 = "<F5>TAC-COM: Warning! Satellites have detected the presence of an enemy nuke at Red Base.";
   teamTransmissions($redReady, *IDSTR_TEAM_RED);
   teamTransmissions($redReady2, *IDSTR_TEAM_BLUE);
   $redLTADs = "<F1>Use LTADS to spot for the Consul bomber air strike.";
   schedule("teamTransmissions($redLTADs, *IDSTR_TEAM_RED);",3);
}

function vehicle::onSpot(%spotter, %target)
{
   %player = playerManager::vehicleIdToPlayerNum(%spotter);
   if(getTeam(%target)!=getTeam(%spotter))
   {
      if(getTeam(%spotter)==*IDSTR_TEAM_BLUE)
      {
         if($blueNuke=="Ready")
         {
            if(%target!="")
            { 
               if($blueSpotter=="Nobody")
               {
                  $blueSpotter = %spotter;
                  $blueTarget = %target;
                  $blueTargetSpotted = true;
                  $blueConfirm = "<F1>TAC-COM: Roger that " @ getHudName(%spotter) @ ", the Draco bomber has your position and is on its way.";
                  teamTransmissions($blueConfirm, *IDSTR_TEAM_BLUE);
                  if($blueDracoLaunched==false)
                  {
                     launchBlueDraco(%spotter, %target);
                  }
                  else
                  {
                     order($blueDraco, clear);
                     order($blueDraco, guard, "Missiongroup\\blueWaypoints");
                     %time = 5;
                     %cycle = 1;
                     %team = blue;
                     schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", 5);
                  }
               }
               else if($blueSpotter==%spotter)
               {
                  $blueSpotter = %spotter;
                  $blueTarget = %target;
                  $blueTargetSpotted = true;
                  $blueConfirm = "<F1>TAC-COM: Roger that " @ getHudName(%spotter) @ ", the Draco bomber has your position and is on its way.";
                  teamTransmissions($blueConfirm, *IDSTR_TEAM_BLUE);
                  if($blueDracoLaunched==false)
                  {
                     launchBlueDraco(%spotter, %target);
                  }
                  else
                  {
                     order($blueDraco, clear);
                     order($blueDraco, guard, "Missiongroup\\blueWaypoints");
                     %time = 5;
                     %cycle = 1;
                     %team = blue;
                     schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", 5);
                  }
               }
               else if($blueSpotter!=%spotter)
               {
                  $blueNegative = "<F1>DRACO: Negative " @ getHudName(%spotter) @ ", I have already aquired " @ getHudName($blueSpotter) @ "'s target.";
                  teamTransmissions($blueNegative, *IDSTR_TEAM_BLUE);
               }
            }
            else if(%target=="")
            {
               if($blueSpotter==%spotter)
               {
                  $blueSpotter = "Nobody";
                  $blueTargetSpotted = false;
                  $blueLostTarget = "<F1>DRACO: Tac-Com, I've lost the target. I need someone to spot it for me.";
                  teamTransmissions($blueLostTarget, *IDSTR_TEAM_BLUE);
                  order($blueDraco, guard, $redWaypoint2);
                  if($blueInitCheck==false)
                  {
                     $blueInitCheck = true;
                     schedule("checkSpotBlueDraco();",15);
                  }
               }
            }
         }
         else if(($blueNuke=="Building")&&(%target!=""))
         {
            say(%player, %player, "<F1>Your team's nuke is not ready yet.");
         }
         else if(($blueNuke=="Used")&&(%target!=""))
         {
            say(%player, %player, "<F1>Your team does not have a nuke built yet.");
         }
      }
      else if(getTeam(%spotter)==*IDSTR_TEAM_RED)
      { 
         if($redNuke=="Ready")
         {
            if(%target!="")
            { 
               if($redSpotter=="Nobody")
               {
                  $redSpotter = %spotter;
                  $redTarget = %target;
                  $redTargetSpotted = true;
                  $redConfirm = "<F1>NEXUS: CONFIRMED//ACKNOWLEDGED " @ getHudName(%spotter) @ ", THE CONSUL//BOMBER \\UNIT\\ HAS CONFIRMED YOUR LOCATION AND WILL DEMOLISH//DECIMATE THE \\TARGET\\.";
                  teamTransmissions($redConfirm, *IDSTR_TEAM_RED);
                  if($redDracoLaunched==false)
                  {
                     launchRedDraco(%spotter, %target);
                  }
                  else
                  {
                     order($redDraco, clear);
                     order($redDraco, guard, "Missiongroup\\redWaypoints");
                     %time = 5;
                     %cycle = 1;
                     %team = red;
                     schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", 5);
                  }
               }
               else if($redSpotter==%spotter)
               {
                  $redSpotter = %spotter;
                  $redTarget = %target;
                  $redTargetSpotted = true;
                  $redConfirm = "<F1>NEXUS: CONFIRMED//ACKNOWLEDGED " @ getHudName(%spotter) @ ", THE CONSUL//BOMBER \\UNIT\\ HAS CONFIRMED YOUR LOCATION AND WILL DEMOLISH//DECIMATE THE \\TARGET\\.";
                  teamTransmissions($redConfirm, *IDSTR_TEAM_RED);
                  if($redDracoLaunched==false)
                  {
                     launchRedDraco(%spotter, %target);
                  }
                  else
                  {
                     order($redDraco, clear);
                     order($redDraco, guard, "Missiongroup\\redWaypoints");
                     %time = 5;
                     %cycle = 1;
                     %team = red;
                     schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", 5);
                  }
               }
               else if($redSpotter!=%spotter)
               {
                  $redNegative = "<F1>CONSUL//BOMBER: NEGATIVE " @ getHudName(%spotter) @ ", THIS \\UNIT\\ HAS ALREADY //AQUIRED// " @ getHudName($redSpotter) @ "'s \\TARGET\\.";
                  teamTransmissions($redNegative, *IDSTR_TEAM_RED);
               }
            }
            else if(%target=="")
            {
               if($redSpotter==%spotter)
               {
                  $redSpotter = "Nobody";
                  $redTargetSpotted = false;
                  $redLostTarget = "<F1>CONSUL//BOMBER: NEXUS//SUPERIOR \\UNIT\\, THE PRIMARY DIRECTIVE HAS BEEN CANCELED//ABORTED//DELETED. THIS \\UNIT\\ REQUIRES A SPOTTER//WARFORM TO DESIGNATE THE TARGET//OBJECTIVE.";
                  teamTransmissions($redLostTarget, *IDSTR_TEAM_RED);
                  order($redDraco, guard, $blueWaypoint2);
                  if($redInitCheck==false)
                  {
                     $redInitCheck = true;
                     schedule("checkSpotRedDraco();",15);
                  }
               }
            }
         }
         else if(($redNuke=="Building")&&(%target!=""))
         {
            say(%player, %player, "<F1>Your team's nuke is not ready yet.");
         }
         else if(($redNuke=="Used")&&(%target!=""))
         {
            say(%player, %player, "<F1>Your team does not have a nuke built yet.");
         }
      }
   }
   else if(getTeam(%target)==getTeam(%spotter))
   {
      say(%player, %player, "<F1>You cannot spot your own team!");
   }
}

function launchBlueDraco(%spotter, %target)
{
   $blueDracoLaunched = true;
   %x = getPosition(%target, x);
   %y = getPosition(%target, y);
   %z = getPosition(%target, z) + 350;
   $blueDraco = newObject("blueDraco", flyer, 131);
   setTeam($blueDraco, *IDSTR_TEAM_BLUE);
   setPosition($blueDraco, -178.907, 4804.09, 563.102);
   setShapeVisibility($blueWaypoint, false);
   setPosition($blueWaypoint, %x, %y, %z);
   order($blueDraco, speed, high);
   order($blueDraco, guard, "Missiongroup\\blueWaypoints");
   %time = 5;
   %cycle = 1;
   %team = blue;
   schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", 5);
   echo("Updating Target Coordinates: " @ %team @ ", " @ %target @ ", " @ %time);
}

function launchRedDraco(%spotter, %target)
{
   $redDracoLaunched = true;
   %x = getPosition(%target, x);
   %y = getPosition(%target, y);
   %z = getPosition(%target, z) + 350;
   $redDraco = newObject("redDraco", flyer, 93);
   setTeam($redDraco, *IDSTR_TEAM_RED);
   setPosition($redDraco, -1376.63, 7624.54, 292.841);
   setShapeVisibility($redWaypoint, false);
   setPosition($redWaypoint, %x, %y, %z);
   order($redDraco, guard, "Missiongroup\\redWaypoints");
   %time = 5;
   %cycle = 1;
   %team = red;
   schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", 5);
   echo("Updating Target Coordinates: " @ %team @ ", " @ %target @ ", " @ %time);
}

function updatePosition(%target, %time, %cycle, %team)
{
   %x = getPosition(%target, x);
   %y = getPosition(%target, y);
   %z = getPosition(%target, z) + 350;
   if(%cycle == 1)
   {
      %cycle = 2;
   }
   else if(%cycle == 2)
   {
      %time = %time + 5;
      if(%time <= 10)
      {
         %cycle = 1;
      }
   }
   if(%team == blue)
   {
      if(($blueTargetSpotted == true)&&($blueDracoLaunched == true)&&($blueNuke == "Ready"))
      {
         setPosition($blueWaypoint, %x, %y, %z);
         order($blueDraco, guard, "Missiongroup\\blueWaypoints");
         schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", %time);
         echo("Updating Target Coordinates: " @ %team @ ", " @ %target @ ", " @ %time);
      }
   }
   else if(%team == red)
   {
      if(($redTargetSpotted == true)&&($redDracoLaunched == true)&&($redNuke == "Ready"))
      {
         setPosition($redWaypoint, %x, %y, %z);
         order($redDraco, guard, "Missiongroup\\redWaypoints");
         schedule("updatePosition(" @ %target @ ", " @ %time @ ", " @ %cycle @ ", " @ %team @ ");", %time);
         echo("Updating Target Coordinates: " @ %team @ ", " @ %target @ ", " @ %time);
      }
   }
}

function blueDraco::vehicle::onArrived(%this, %where)
{
   if(%where==$blueWayPoint)
   {  
      say("Everybody", 1,"<F1>DRACO: Payload Released.");
      dropBlueBomb(%this);
   }
   else if(%where==$blueWayPoint2)
   {  
      schedule("$blueDracoLaunched = false;",3);
      schedule("deleteObject($blueDraco);",3);
   }
}

function redDraco::vehicle::onArrived(%this, %where)
{
   if(%where==$redWayPoint)
   {
      say("Everybody", 1,"<F1>CONSUL//BOMBER: PAYLOAD RELEASED.");
      dropRedBomb(%this);
   }
   else if(%where==$redWayPoint2)
   {  
      schedule("$redDracoLaunched = false;",3);
      schedule("deleteObject($redDraco);",3);
   }
}

function dropBlueBomb(%this)
{
   $blueNuke = "Used";
   %x = getPosition($blueWaypoint, x);
   %y = getPosition($blueWaypoint, y);
   %z = getPosition($blueWaypoint, z);
   setPosition($blueBomb, %x, %y, %z);
   schedule("fall($blueBomb, 70);",0.1);
}

function dropRedBomb(%this)
{
   $redNuke = "Used";
   %x = getPosition($redWaypoint, x);
   %y = getPosition($redWaypoint, y);
   %z = getPosition($redWaypoint, z);
   setPosition($redBomb, %x, %y, %z);
   schedule("fall($redBomb, 70);",0.1);
}

function fall(%bomb, %frame)
{
   if(%frame < 1)
   {
      if(%bomb==$blueBomb)
      {
         nukeTarget($blueTarget, %bomb);
      }
      else if(%bomb==$redbomb)
      {
         nukeTarget($redTarget, %bomb);
      }
   }
   else
   {
      %frame--;
      %x = getPosition(%bomb, x);
      %y = getPosition(%bomb, y);
      %z = getPosition(%bomb, z) - 5;
      setPosition(%bomb, %x, %y, %z, 0, -90);
      schedule("fall(" @ %bomb @ ", " @ %frame @ ");",0.1);
   }
}

function nukeTarget(%target, %bomb)
{   
   %x = getPosition(%bomb, x);
   %y = getPosition(%bomb, y);
   %z = getTerrainHeight(%x, %y);
   %random = randomInt(0,2);
   if(%bomb == $blueBomb)
   {
      setPosition($blueExplosion, %x, %y, %z);
      setPosition($blueShockwave, %x, %y, (%z + 5));
      playAnimSequence($blueExplosion, 0, true);
      playAnimSequence($blueShockwave, 0, true);
      damageArea(%bomb, 0, 0, 0, 400, 1000000);
      if(getVehicleName(%target) == false)
      {
         damageObject(%target, 50000);
      }
      say("Everybody", 1, "<F1>Blue Team's nuke has detonated!", "sfx_fog.wav");
      if(%random==0)
      {
         schedule("say(\"Everybody\", 1, \"<F1>DRACO: Yeah! Boom-baby-boom! hahah.\", \"M6_Saxon_yeahboom.WAV\");",3);
      }
      else if(%random==1)
      {
         schedule("say(\"Everybody\", 1, \"<F1>DRACO: Target eliminated.\", \"M9_Delta6_targetel.WAV\");",3);
      }
      else if(%random==2)
      {
         schedule("say(\"Everybody\", 1, \"<F1>DRACO: Target destroyed.\", \"M9_Delta6_targetd.WAV\");",3);
      }
      $blueSpotter = "Nobody";
      $blueTargetSpotted = false;
      schedule("setPosition($blueExplosion, 5000, 5000, -1000);",1.067);
      schedule("setPosition($blueShockwave, 5000, 5000, -1000);",1.667);
      schedule("playAnimSequence($blueExplosion, 0, false);",5);
      schedule("playAnimSequence($blueShockwave, 0, false);",5);
   }
   else if(%bomb==$redbomb)
   {
      setPosition($redExplosion, %x, %y, %z);
      setPosition($redShockwave, %x, %y, (%z + 5));
      playAnimSequence($redExplosion, 0, true);
      playAnimSequence($redShockwave, 0, true);
      damageArea(%bomb, 0, 0, 0, 400, 1000000);
      if(getVehicleName(%target) == false)
      {
         damageObject(%target, 50000);
      }
      say("Everybody", 1, "<F1>Red Team's nuke has detonated!", "sfx_fog.wav");
      if(%random==0)
      {
         schedule("say(\"Everybody\", 1, \"<F1>CONSUL//BOMBER: TARGET ELIMINATED.\", \"C3_targeteliminated.WAV\");",3);
      }
      else if(%random==1)
      {
         schedule("say(\"Everybody\", 1, \"<F1>CONSUL//BOMBER: TARGET EXECUTED.\", \"C7_targetexec.WAV\");",3);
      }
      else if(%random==2)
      {
         schedule("say(\"Everybody\", 1, \"<F1>CONSUL//BOMBER: PROGRAM//TASK COMPLETED, PRAISE GIVER//OF//WILL.\", \"CYB_NEX04.WAV\");",3);
      }
      $redSpotter = "Nobody";
      $redTargetSpotted = false;
      schedule("setPosition($redExplosion, 5000, 5000, -1000);",1.067);
      schedule("setPosition($redShockwave, 5000, 5000, -1000);",1.667);
      schedule("playAnimSequence($redExplosion, 0, false);",5);
      schedule("playAnimSequence($redShockwave, 0, false);",5);
   }
   setPosition(%bomb, 5000, 5000, -1000);
}

function vehicle::ondestroyed(%destroyed, %destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   if(%destroyed==$blueDraco)
   {
      schedule("$blueDracoLaunched = false;",3);
      schedule("deleteObject($blueDraco);",3);
   }
   else if(%destroyed==$redDraco)
   {
      schedule("$redDracoLaunched = false;",3);
      schedule("deleteObject($redDraco);",3);
   }
   else
   {
      if(%player==0)
      {
         say("Everybody", 1, gethudname(%destroyed) @ " got caught in the nuclear blast!");
      }
      else
      {
         vehicle::onDestroyedLog(%destroyed, %destroyer);
      
         // this is weird but %destroyer isn't necessarily a vehicle
         %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
         if(%message != "")
         {
            say( 0, 0, %message);
         }
         
         // enforce the rules
         if($server::TeamPlay == true)
         {
            if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
            {
               antiTeamKill(%destroyer);
            }
         }   
      }
   }
}

function checkSpotBlueDraco()
{
   if($blueTargetSpotted==false)
   {
      schedule("$blueDracoLaunched = false;",3);
      schedule("deleteObject($blueDraco);",3);
   }
   $blueInitCheck = false;
}

function checkSpotRedDraco()
{
   if($redTargetSpotted==false)
   {
      schedule("$redDracoLaunched = false;",3);
      schedule("deleteObject($redDraco);",3);
   }
   $redInitCheck = false;
}

function teamTransmissions(%text, %team)
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(getTeam(%player)==%team)
      {
         say(%player, %player, %text);
      }
   }
}

function onMissionEnd()
{
   deleteObject($blueDraco);
   deleteObject($redDraco);
}