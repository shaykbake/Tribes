// FILENAME:	DM_Mars_Mess.cs
//
// AUTHORS:  	Maj. Stormtrooper [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Mars_Mess";                                                                                           <F5>I recommend using a smaller herc, because big hercs can get stuck sometimes";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");
exec("BoostStdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	marsSounds();
}

function player::onAdd(%player)
{
   say(%player, 0, "<F2>Welcome <F0>to <F5>Mars Mess!<F0> You can download this & other missions made by <F1>Maj. �t�rmtr��per [M.I.B.]<F0> in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
}

// Water Tower splash functionality
function structure::onDestroyed(%this, %attackerId){
	// Which water tower was destroyed?
	if(%this == getObjectId("MissionGroup\\BlueBase\\WaterTower1")){
		setShapeVisibility(getObjectId("MissionGroup\\BlueBase\\Splash1"), true);
		playAnimSequence(getObjectId("MissionGroup\\BlueBase\\Splash1"), 0, true);
	}
	else if(%this == getObjectId("MissionGroup\\BlueBase\\WaterTower2")){
		setShapeVisibility(getObjectId("MissionGroup\\BlueBase\\Splash2"), true);
		playAnimSequence(getObjectId("MissionGroup\\BlueBase\\Splash2"), 0, true);
	}
	else if(%this == getObjectId("MissionGroup\\BlueBase\\WaterTower3")){
		setShapeVisibility(getObjectId("MissionGroup\\BlueBase\\Splash3"), true);
		playAnimSequence(getObjectId("MissionGroup\\BlueBase\\Splash3"), 0, true);
	}
}

function vehicle::attacked(%attacked, %attacker)
{
   if(getHudName(%attacked)=="/<F1>Stormtrooper [MIB]")
   {
         $object = %attacker;
	   jumpNorth60(" @ $object @ ");
	   schedule("jumpNorth60(" @ $object @ ");",0.1);
         schedule("GrindNorthWest(" @ $object @ ");",0.2);
         schedule("jumpNorth60(" @ $object @ ");",0.3);
         schedule("grindNorth(" @ $object @ ");",0.4);
         schedule("fallNorth30(" @ $object @ ");",0.5);
         schedule("GrindSouth(" @ $object @ ");",0.6);
         schedule("fallNorth60(" @ $object @ ");",0.7);
         schedule("GrindSouth(" @ $object @ ");",0.8);
         schedule("GrindEast(" @ %object @ ");",0.9);
         schedule("JumpSouth60(" @ $object @ ");",1);
         schedule("GrindEast(" @ $object @ ");",1.1);
         schedule("GrindSouth(" @ $object @ ");",1.2);
         schedule("goUpSlow(" @ $object @ ");",1.3);
         schedule("JumpSouth60(" @ $object @ ");",1.4);
         schedule("GrindEast(" @ $object @ ");",1.5);
         schedule("GrindSouth(" @ $object @ ");",1.6);
         schedule("JumpSouth60(" @ $object @ ");",1.7);
         schedule("GrindSouth(" @ $object @ ");",1.8);
         schedule("goUpSlow(" @ $object @ ");",1.9);
         schedule("GrindSouth(" @ $object @ ");",2);
         schedule("GrindNorthWest(" @ $object @ ");",2.1);
         schedule("GrindEast(" @ $object @ ");",2.2);
         schedule("JumpSouth60(" @ $object @ ");",2.3);
         schedule("GrindNorthWest(" @ $object @ ");",2.4);
         schedule("GrindSouth(" @ $object @ ");",2.5);
         schedule("JumpSouth60(" @ $object @ ");",2.6);
   }
}

function JumpNorth60(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpSouth60(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpEast60(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpWest60(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function GrindNorth(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindSouth(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindEast(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindWest(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindNorthEast(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindNorthWest(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindSouthEast(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindSouthWest(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function goUp(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function goUpSlow(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function goDown(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function goDownSlow(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 5;
   setPosition(%object, %x, %y, %z);
}

function FallNorth45(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallSouth45(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallEast45(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallWest45(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}
