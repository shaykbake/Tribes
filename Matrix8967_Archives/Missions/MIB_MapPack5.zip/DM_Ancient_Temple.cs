// FILENAME:	DM_Ancient_Temple.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "DM_Ancient_Temple";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	desertSounds();
      $nav = getobjectId("Missiongroup\\CenterNav");
      $pyro1 = false;
      $pyro2 = false;
      $pyro3 = false;
      $pyro4 = false;
      $firedit = false;
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }     
   say(%player, 0, "Welcome to DeathMatch Ancient Temple! You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onremove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function onMissionLoad()
{
   cdAudioCycle("CloudBurst", "Cyberntx", "Mechsoul","Terror","Watching");
}

function pyro1::structure::onscan(%scanned,%scanner)
{
   $pyro1 = true;
   if(($pyro1==true) && ($pyro2==true) && ($pyro3==true) && ($pyro4==true) && ($firedit==false))
   {
      shootthebiggun();
   }  
}

function pyro2::structure::onscan(%scanned,%scanner)
{
   $pyro2 = true;
   if(($pyro1==true) && ($pyro2==true) && ($pyro3==true) && ($pyro4==true) && ($firedit==false))
   {
      shootthebiggun();
   }
}

function pyro3::structure::onscan(%scanned,%scanner)
{
   $pyro3 = true;
   if(($pyro1==true) && ($pyro2==true) && ($pyro3==true) && ($pyro4==true) && ($firedit==false))
   {
      shootthebiggun();
   }
}

function pyro4::structure::onscan(%scanned,%scanner)
{
   $pyro4 = true;
   if(($pyro1==true) && ($pyro2==true) && ($pyro3==true) && ($pyro4==true) && ($firedit==false))
   {
      shootthebiggun();
   }
}

function shootthebiggun()
{
   %x = getposition($nav,x);
   %y = getposition($nav,y);
   %z1 = getposition($nav,z);
   %z2 = getposition($nav,z)+1000;
   $firedit = true;
   playsound(0,"sfx_fog.wav",IDPRF_2D);
   droppod(%x,%y,%z1,%x,%y,%z2);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",0.25);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",0.5);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",0.75);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",1);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",1.25);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",1.5);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",1.75);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",2);
   schedule("droppod("@%x@","@%y@","@%z1@","@%x@","@%y@","@%z2@");",2.25);
   $pyro1 = false;
   $pyro2 = false;
   $pyro3 = false;
   $pyro4 = false;
   schedule("$firedit=false;",180);
}