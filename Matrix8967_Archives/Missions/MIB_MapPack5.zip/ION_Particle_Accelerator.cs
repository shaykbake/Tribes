// FILENAME:	ION_Particle_Accelerator.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "ION_Particle_Accelerator";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   desertSounds();
   $anim1 = getObjectId("MissionGroup\\anim1");
   $anim2 = getObjectId("MissionGroup\\anim2");
   $anim3 = getObjectId("MissionGroup\\anim3");
   $anim4 = getObjectId("MissionGroup\\anim4");
   $anim5 = getObjectId("MissionGroup\\anim5");
   $anim6 = getObjectId("MissionGroup\\anim6");
   $anim7 = getObjectId("MissionGroup\\anim7");
   $anim8 = getObjectId("MissionGroup\\anim8");
   playAnimSequence($anim1,0,true);
   schedule("playAnimSequence($anim2,0,true);",0.25);
   schedule("playAnimSequence($anim3,0,true);",0.5);
   schedule("playAnimSequence($anim4,0,true);",0.75);
   playAnimSequence($anim5,0,true);
   schedule("playAnimSequence($anim6,0,true);",0.25);
   schedule("playAnimSequence($anim7,0,true);",0.5);
   schedule("playAnimSequence($anim8,0,true);",0.75);
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "Cloudburst", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  DeathMatch\n\n<F2>MISSION:<F0>  ION_Particle_Accelerator\n\nWelcome to Ion Cannon Deathmatch! You can fire your Ion Cannon by scanning vehicles or structures, or by spotting them with LTADs. Your Ion Cannon must recharge for 90 seconds after each use. Run through a Particle Accelerator to propel your HERC skyward. Unfortunately, Adjudicators and all tanks are not able to use the Particle Accelerators due to structural differences. You can download ION_Particle_Accelerator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Ion Cannon DeathMatch! Check the Game Info tab for information on how to use the Ion Cannons. Run through a Particle Accelerator to propel your HERC skyward. Unfortunately, Adjudicators and all tanks are not able to use the Particle Accelerators due to structural differences. You can download ION_Particle_Accelerator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.boomkill = 0;
}
 
function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   schedule("setAlive("@%player@");",1);
   %vehicleId.ready = true;
   sethudtimer(0,0,"Ion Cannon Online",2,%player);
   //Easter egg (enable flyers to take off)
   order(%vehicleId,guard,0);
}

function setAlive(%player)
{
   %player.alive = true;
}

function vehicle::onspot(%spotter,%target)
{
    %player = playermanager::vehicleIdtoPlayerNum(%spotter);
    %player2 = playermanager::vehicleIdtoPlayerNum(%target);
    if($server::Teamplay==false)
    {
       if(%target!="")
       {
           if(%spotter.ready==true)
           {
               %target.killer = getname(%spotter);
               %player2.killer2 = %player;
               %spotter.ready = false;
               %spotterX = getposition(%spotter,x);
               %spotterY = getposition(%spotter,y);
               %spotterZ = getposition(%spotter,z)+10;
               %targetX = getposition(%target,x);
               %targetY = getposition(%target,y);
               %targetZ = getposition(%target,z);
               droppod(%spotterX,%spotterY,%spotterZ,%targetX,%targetY,%targetZ);
               %distance = getdistance(%spotter,%target);
               %time = %distance / 400; //400 m/s (speed of drop pod)
               schedule("damagearea("@%target@",0,0,0,150,875);",%time);
               schedule("playSound(%player2, \"explo3.wav\", IDPRF_2D);",%time);
               %spotter.firetime = getcurrenttime();
               schedule("ready("@%spotter@");",90);
               sethudtimer(90,-1,"Ion Cannon Recharging",2,%player);
               playSound(%player, "sfx_shrk.wav", IDPRF_2D);
           }
           else if(%spotter.ready==false)
           {
               %spotter.nowtime  = getcurrenttime();
               %spotter.timecharged = %spotter.nowtime - %spotter.firetime;
               %spotter.timeleft = 90 - %spotter.timecharged;
               say(%player,%player,"<f1>Ion Cannon charging - " @ %spotter.timeleft @ " seconds remaining.");
           }
       }
    }
    else if(($server::TeamPlay == true) && (getTeam(%spotter) != getTeam(%target)))
    {
       if(%target!="")
       {
           if(%spotter.ready==true)
           {
               %target.killer = getname(%spotter);
               %player2.killer2 = %player;
               %spotter.ready = false;
               %spotterX = getposition(%spotter,x);
               %spotterY = getposition(%spotter,y);
               %spotterZ = getposition(%spotter,z)+10;
               %targetX = getposition(%target,x);
               %targetY = getposition(%target,y);
               %targetZ = getposition(%target,z);
               droppod(%spotterX,%spotterY,%spotterZ,%targetX,%targetY,%targetZ);
               %distance = getdistance(%spotter,%target);
               %time = %distance / 400; //400 m/s (speed of drop pod)
               schedule("damagearea("@%target@",0,0,0,150,875);",%time);
               schedule("playSound(%player2, \"explo3.wav\", IDPRF_2D);",%time);
               %spotter.firetime = getcurrenttime();
               schedule("ready("@%spotter@");",90);
               sethudtimer(90,-1,"Ion Cannon Recharging",2,%player);
               playSound(%player, "sfx_shrk.wav", IDPRF_2D);
           }
           else if(%spotter.ready==false)
           {
               %spotter.nowtime  = getcurrenttime();
               %spotter.timecharged = %spotter.nowtime - %spotter.firetime;
               %spotter.timeleft = 90 - %spotter.timecharged;
               say(%player,%player,"<f1>Ion Cannon charging - " @ %spotter.timeleft @ " seconds remaining.");
           }
       }
   }          
   else
   {
      say(%player,%player,"<f5>You cannot fire on your own team!");
   } 
}

function vehicle::onscan(%scanned,%scanner)
{
    %player = playermanager::vehicleIdtoPlayerNum(%scanner);
    %player2 = playermanager::vehicleIdtoPlayerNum(%scanned);
    if($server::Teamplay==false)
    {
       if(%scanner.ready==true)
       {
           %scanned.killer = getname(%scanner);
           %player2.killer2 = %player;
           %scanner.ready = false;
           %scannerX = getposition(%scanner,x);
           %scannerY = getposition(%scanner,y);
           %scannerZ = getposition(%scanner,z)+10;
           %scannedX = getposition(%scanned,x);
           %scannedY = getposition(%scanned,y);
           %scannedZ = getposition(%scanned,z);
           droppod(%scannerX,%scannerY,%scannerZ,%scannedX,%scannedY,%scannedZ);
           %distance = getdistance(%scanner,%scanned);
           %time = %distance / 400; //400 m/s (speed of drop pod)
           schedule("damagearea("@%scanned@",0,0,0,150,875);",%time);
           schedule("playSound(%player2, \"explo3.wav\", IDPRF_2D);",%time);
           %scanner.firetime = getcurrenttime();
           schedule("ready2("@%scanner@");",90);
           sethudtimer(90,-1,"Ion Cannon Recharging",2,%player);
           playSound(%player, "sfx_shrk.wav", IDPRF_2D);
       }
       else if(%scanner.ready==false)
       {
           %scanner.nowtime  = getcurrenttime();
           %scanner.timecharged = %scanner.nowtime - %scanner.firetime;
           %scanner.timeleft = 90 - %scanner.timecharged;
           say(%player,%player,"<f1>Ion Cannon charging - " @ %scanner.timeleft @ " seconds remaining.");
       }
    }
    else if(($server::TeamPlay == true) && (getTeam(%scanner) != getTeam(%scanned)))
    {
       if(%scanner.ready==true)
       {
           %scanned.killer = getname(%scanner);
           %player2.killer2 = %player;
           %scanner.ready = false;
           %scannerX = getposition(%scanner,x);
           %scannerY = getposition(%scanner,y);
           %scannerZ = getposition(%scanner,z)+10;
           %scannedX = getposition(%scanned,x);
           %scannedY = getposition(%scanned,y);
           %scannedZ = getposition(%scanned,z);
           droppod(%scannerX,%scannerY,%scannerZ,%scannedX,%scannedY,%scannedZ);
           %distance = getdistance(%scanner,%scanned);
           %time = %distance / 400; //400 m/s (speed of drop pod)
           schedule("damagearea("@%scanned@",0,0,0,150,875);",%time);
           schedule("playSound(%player2, \"explo3.wav\", IDPRF_2D);",%time);
           %scanner.firetime = getcurrenttime();
           schedule("ready2("@%scanner@");",90);
           sethudtimer(90,-1,"Ion Cannon Recharging",2,%player);
           playSound(%player, "sfx_shrk.wav", IDPRF_2D);
       }
       else if(%scanner.ready==false)
       {
           %scanner.nowtime  = getcurrenttime();
           %scanner.timecharged = %scanner.nowtime - %scanner.firetime;
           %scanner.timeleft = 90 - %scanner.timecharged;
           say(%player,%player,"<f1>Ion Cannon charging - " @ %scanner.timeleft @ " seconds remaining.");
       }
   }
   else
   {
      say(%player,%player,"<f5>You cannot fire on your own team!");
   } 
}

function structure::onscan(%scanned,%scanner)
{
    %player = playermanager::vehicleIdtoPlayerNum(%scanner);
    if(%scanner.ready==true)
    {
        %scanner.ready = false;
        %scannerX = getposition(%scanner,x);
        %scannerY = getposition(%scanner,y);
        %scannerZ = getposition(%scanner,z)+10;
        %scannedX = getposition(%scanned,x);
        %scannedY = getposition(%scanned,y);
        %scannedZ = getposition(%scanned,z);
        droppod(%scannerX,%scannerY,%scannerZ,%scannedX,%scannedY,%scannedZ);
        %distance = getdistance(%scanner,%scanned);
        %time = %distance / 400; //400 m/s (speed of drop pod)
        schedule("damagearea("@%scanned@",0,0,0,150,875);",%time);
        schedule("damageobject("@%scanned@",100000);",%time);
        %scanner.firetime = getcurrenttime();
        schedule("ready2("@%scanner@");",90);
        sethudtimer(90,-1,"Ion Cannon Recharging",2,%player);
        playSound(%player, "sfx_shrk.wav", IDPRF_2D);
    }
    else if(%scanner.ready==false)
    {
        %scanner.nowtime  = getcurrenttime();
        %scanner.timecharged = %scanner.nowtime - %scanner.firetime;
        %scanner.timeleft = 90 - %scanner.timecharged;
        say(%player,%player,"<f1>Ion Cannon charging - " @ %scanner.timeleft @ " seconds remaining.");
    }
}

function ready(%spotter)
{  
      %spotter.ready = true;      
}

function ready2(%scanner)
{  
      %scanner.ready = true;      
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   %player2.alive = false;
   if(%player == 0)
   {
      %random = randomInt(0,2); 
      if(%destroyed.killer != "")
      {
         if(%random == 0)
         {
            say(0,2,"<f0>" @ %destroyed.killer @ " annihilated " @ gethudname(%destroyed) @ " with his Ion Cannon.","sfx_fog.wav");
         }
         else if(%random == 1)
         {
            say(0,2,"<f0>" @ gethudname(%destroyed) @ " was destroyed by " @ %destroyed.killer @ "'s Ion Cannon.","sfx_fog.wav");
         }
         else if(%random == 2)
         {
            say(0,2,"<f0>" @ gethudname(%destroyed) @ " didnt see " @ %destroyed.killer @ "'s Ion Cannon until it was too late.","sfx_fog.wav");    
         }
      }
      else if(%destroyed.killer == "")
      {
         say(0,2,"<f0>" @ gethudname(%destroyed) @ " got caught in an ionic shockwave.","sfx_fog.wav");    
      }
      
      %killer = %player2.killer2;
      %killer.boomkill = %killer.boomkill + 3;
   }
   else
   {   
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
      // enforce the rules
      if($server::TeamPlay == true)
      {
         if((getTeam(%destroyed) == getTeam(%destroyer))&&(%destroyed != %destroyer))
         {
            antiTeamKill(%destroyer);
         }
      }   
   }
}

function getPlayerScore(%player)
{
   return((getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints)) + %player.boomkill;
}

//Particle Accelerators
function springhigh::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(200,250);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function springmed::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(150,200);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function springlow::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(100,150);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function loop(%player,%num)
{
   if((%num > 0)&&(%player.alive==true))
   {
      %num--;
      %vehicleId = playermanager::playernumtovehicleid(%player);
      damageArea(%vehicleId,0,0,0,10,0);
      schedule("loop(" @ %player @ "," @ %num @ ");",0.1);
   }
}