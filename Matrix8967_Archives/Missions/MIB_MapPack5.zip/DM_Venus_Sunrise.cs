// FILENAME:	DM_Venus_Sunrise.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//
// RANDOM ADVICE: Never spit into the wind.
//                Never trust a monkey.
//                Never eat anything given to you by Tom Green.
//                Never bite a porcupine. (Trust me on this one.)
//------------------------------------------------------------------------------

$missionName = "DM_Venus_Sunrise";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$rockon = false;

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	venusSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DeathMatch Venus Sunrise! You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%vehicleId)
{
%vehicleId.name = getHUDName(%vehicleId);
}

function onMissionLoad()
{
   cdAudioCycle("Newtech", "Mechsoul", "Terror"); 
}

function rock::structure::OnAttacked(%attacked, %attacker)
{
   if($rockon == false)
   {
      $rockon=true;
      say("Everybody", 1, %attacker.name @ " shot a rock. Why?");
      schedule("$rockon = false;", 2);
   }
}

// No special scripting stuff except that rock thing, but 
// if you want to see something cool, go to the Northwest 
// corner of this map.