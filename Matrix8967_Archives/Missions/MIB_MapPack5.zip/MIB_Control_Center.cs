// FILENAME:	MIB_Control_Center.cs
//
// AUTHOR:  	Gen. Deathrow [M.I.B.]
//
// VERSION:       1.001
//------------------------------------------------------------------------------

$missionName = "MIB_Control_Center";
$nameOfTheGame = "Control_Center";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$shoot = false;
$help = false;

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = false;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = true;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
   
   $server::TimeLimit = 20;
}


function onMissionStart()
{
	marsSounds();
	
}

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.name = getHUDName(%vehicleId);
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to the M.I.B. Control Center! Choose which map you want to play by shooting one of the floating target drones. If you need additional help, the \"Help Desk\" target drone is in the Temple. You can download this & other missions made by Gen. Deathrow [M.I.B.] on the MIB website at www.starsiegemeninblack.cjb.net.", "TR_INTR01.WAV");
   %txt ="Welcome to the M.I.B. Control Center. Here, you can choose which map you want to play from a variety of M.I.B. maps.";
   messageBox(%this,%txt); 
   %txt ="Choose the map you want to play from inside the game by shooting the floating target drones.";
   messageBox(%this,%txt); 
   %txt ="If you need help while in the game, shoot the help desk drone.";
   messageBox(%this,%txt);
   %txt ="You can download this & other MIB maps in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.";
   messageBox(%this,%txt);	 
   %txt ="This map was created by Gen. Deathrow [M.I.B.] with help from Com. Sentinal [M.I.B.].";
   messageBox(%this,%txt);	 
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Command Center\n\n<F2>MISSION:<F0>  M.I.B. Control Center\n\nWelcome to the M.I.B. Control Center! Choose which map you want to play by shooting one of the floating target drones. If you need additional help, the \"Help Desk\" target drone is in the Temple. You can download this & other missions made by Gen. Deathrow [M.I.B.] on the MIB website at www.starsiegemeninblack.cjb.net.");
}


function battle::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Mars_Battle.");
      %txt ="DM_Mars_Battle will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Mars_Battle";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function tower::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Tower_Of_Death.");
	%txt ="DM_Tower_of_Death will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Tower_Of_Death";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function aquatica::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Aquatica.");
	%txt ="DM_Aquatica will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Aquatica";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function aquaticadam::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Aquatica_Dam.");
      %txt ="DM_Aquatica_Dam will start in 5 seconds.";
      messageBox("Everybody",%txt);  	
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Aquatica_Dam";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function sky::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Sky_Arena.");
      $shoot=true;
	%txt ="DM_Sky_Arena will start in 5 seconds.";
       messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = "DM_Sky_Arena";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}
	
function rome::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Rome.");
      $shoot=true;
	%txt ="DM_Rome will start in 5 seconds.";
      messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = "DM_Rome";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function nova::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Nova_Alexandria.");
      $shoot=true;
	%txt ="DM_Nova_Alexandria will start in 5 seconds.";
      messageBox("Everybody",%txt); 
	$MissionCycling::Stage0 = "DM_Nova_Alexandria";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function pit::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_PIT.");
      $shoot=true;
	%txt ="DM_PIT will start in 5 seconds.";
      messageBox(%this,%txt); 
	$MissionCycling::Stage0 = "DM_PIT";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}	

function mine::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Mineshaft.");
      $shoot=true;
	%txt ="DM_Mineshaft will start in 5 seconds.";
      messageBox(%this,%txt); 
	$MissionCycling::Stage0 = "DM_Mineshaft";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}	

function la::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_L.A.");
      $shoot=true;
	%txt ="DM_L.A. will start in 5 seconds.";
      messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = "DM_LA";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function venus::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Venus_Sunrise.");
      $shoot=true;
	%txt ="DM_Venus_Sunrise will start in 5 seconds.";
      messageBox("Everybody",%txt); 
	$MissionCycling::Stage0 = "DM_Venus_Sunrise";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function complex::structure::onAttacked(%this, %attacker)	
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Cybrid_Complex.");
      $shoot=true;
	%txt ="DM_Cybrid_Complex will start in 5 seconds.";
      messageBox("Everybody",%txt);  
	$MissionCycling::Stage0 = "DM_Cybrid_Complex";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}	

function bowl::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Death_Bowl.");
	%txt ="DM_Death_Bowl will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Death_Bowl";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function tube::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Death_Tube.");
	%txt ="DM_Death_Tube will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Death_Tube";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}
	
function rebel::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_RebelUnderground.");
	%txt ="DM_RebelUnderground will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "RebelUnderground";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function deep::structure::onAttacked(%this, %attacker)
{
   if($shoot == false)
   {
      say("Everybody", 1, %attacker.name @ " has chosen to play DM_Deep_Freeze.");
	%txt ="DM_Deep_Freeze will start in 5 seconds.";
      messageBox("Everybody",%txt); 
      $shoot=true;
	$MissionCycling::Stage0 = "DM_Deep_Freeze";
	$MissionCycling::Stage1 = "MIB_Control_Center";
	$server::Mission = $MissionCycling::Stage0;
	schedule("missionEndConditionMet();",5);
   }
}

function help::structure::onAttacked(%this, %attacker)
{
   if($help == false)
   {
      $help=true;
	%txt ="You have chosen the \"Help Desk\". Please read the chat window for your help info.";
      messageBox(%attacker,%txt); 
      say("Everybody", 1, "-----------------------------------------------------------------");	
      say("Everybody", 1, "Welcome to the M.I.B. Control Center! You have chosen the \"Help Desk\". Please choose which map you want to play by shooting one of the floating target drones. The server will then change the map to the one you have chosen. After the mission ends, you will be returned to the M.I.B. Control Center.", "M5_DM_hibuddy.wav");
      schedule("$help = false;", 10);
   }
}