// FILENAME:	CTF_Particle_Accelerator.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "CTF_Particle_Accelerator";

$maxFlagCount  = 12;         // no of flags required by a team to end the game
$flagValue     = 5;          // points your team gets for capturing
$carrierValue  = 2;          //  "      "    "    "    " killing carrier
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 180;

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
   desertSounds();
   $anim1 = getObjectId("MissionGroup\\anim1");
   $anim2 = getObjectId("MissionGroup\\anim2");
   $anim3 = getObjectId("MissionGroup\\anim3");
   $anim4 = getObjectId("MissionGroup\\anim4");
   $anim5 = getObjectId("MissionGroup\\anim5");
   $anim6 = getObjectId("MissionGroup\\anim6");
   $anim7 = getObjectId("MissionGroup\\anim7");
   $anim8 = getObjectId("MissionGroup\\anim8");
   playAnimSequence($anim1,0,true);
   schedule("playAnimSequence($anim2,0,true);",0.25);
   schedule("playAnimSequence($anim3,0,true);",0.5);
   schedule("playAnimSequence($anim4,0,true);",0.75);
   playAnimSequence($anim5,0,true);
   schedule("playAnimSequence($anim6,0,true);",0.25);
   schedule("playAnimSequence($anim7,0,true);",0.5);
   schedule("playAnimSequence($anim8,0,true);",0.75);

   initGlobalVars();
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "Cloudburst", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Capture the Flag\n\n<F2>MISSION:<F0>  CTF_Particle_Accelerator\n\nWelcome to CTF Particle Accelerator! Run through a Particle Accelerator to propel your HERC skyward. Unfortunately, Adjudicators and all tanks are not able to use the Particle Accelerators due to structural differences. You can download CTF_Particle_Accelerator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to CTF Particle Accelerator! Run through a Particle Accelerator to propel your HERC skyward. Unfortunately, Adjudicators and all tanks are not able to use the Particle Accelerators due to structural differences. You can download CTF_Particle_Accelerator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   schedule("setAlive("@%player@");",1);
   // CTF stuff
   %team = getTeam(playerManager::vehicleIdToPlayerNum(%vehicleId));
   %color = teamToColor(%team);
   %flagKey = strcat(%color, "FlagCount");
	
   adjTeamCount(%team, 1);
	
   //if the flag isn't at the base, but no one has it, correct situation
   if(dataRetrieve(0, %flagKey) && !dataRetrieve(0, strcat(%color, "FlagCarried")))
   {
   	setFlag(%team, true);
   }
}   

function setAlive(%player)
{
   %player.alive = true;
}

function vehicle::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   
   %player2.alive = false;   
   // CTF stuff
   %team = getTeam(%destroyed);
   adjTeamCount(%team, -1);
   %teamCount = getTeamPlayerCount(%team);      

   if(%teamCount < 1)
   {
	   setFlag(%team, false);					
   }

   %color = dataRetrieve(%destroyed, "hasFlag");
   %flagTeam = colorToTeam(%color);
   
   // if the destroyed vehicle has a flag, it goes back to it's base
   if (%color != "")
   {
      playerDropsFlag(%destroyed);
      
      // let everyone know this guy drops the flag
      %str =
         *IDMULT_CHAT_SURRENDER_FLAG_1 @
         getName( %destroyed )         @
         *IDMULT_CHAT_SURRENDER_FLAG_2 @ 
         %flagTeam                     @
         *IDMULT_CHAT_SURRENDER_FLAG_3;
      
      %soundFile = "";   
      if(%flagTeam == *IDSTR_TEAM_RED)
      {
         %soundFile = "red_flag_sur.wav";
      }
      else if(%flagTeam == *IDSTR_TEAM_BLUE)
      {
         %soundFile = "blue_flag_sur.wav";
      }
      else if(%flagTeam == *IDSTR_TEAM_YELLOW)
      {
         %soundFile = "yel_flag_sur.wav";
      }
      else
      {
         %soundFile = "purp_flag_sur.wav";
      }   
      
      say( 0, 0, %str, %soundFile );

            
      if($scoringFreeze == false)
      {     
         // destroyer's team gets credit for killing the carrier
         %destroyerTeam = getTeam(%destroyer);  
      
         // only give points if destroyed recovered his/her own flag
         if(%destroyerTeam == colorToTeam(%color))
         {
            %key = strcat(teamToColor(getTeam(%destroyer)), "CarriersKilled");
            dataStore(0, %key, 1 + dataRetrieve(0, %key));
            
            // player gets credit, too
            %player = playerManager::vehicleIdToPlayerNum(%destroyer);
            if(%player != 0)
            {
               %player.carriersKilled = %player.carriersKilled + 1;
            }
         }

         // echo the surrender to the console for logging
         echo(*IDSTR_CONSOLE_CTF_SURRENDER @ " " @ playerManager::vehicleIdToPlayerNum(%destroyed));                        
      }	  
   }
   else
   {
      // not a flag carrier ... is it an enemy?
      if($scoringFreeze == false)
      {
         if(getTeam(%destroyed) != getTeam(%destroyer))
         {
            %player = playerManager::vehicleIdToPlayerNum(%destroyer);
            if(%player != 0)
            {
               %player.genericKills = %player.genericKills + 1;
            }
         }
      }
   }
   vehicle::onDestroyedLog(%destroyed, %destroyer);
  
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }      
}

//Particle Accelerators
function springhigh::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(200,250);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function springmed::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(150,200);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function springlow::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(100,150);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function loop(%player,%num)
{
   if((%num > 0)&&(%player.alive==true))
   {
      %num--;
      %vehicleId = playermanager::playernumtovehicleid(%player);
      damageArea(%vehicleId,0,0,0,10,0);
      schedule("loop(" @ %player @ "," @ %num @ ");",0.1);
   }
}