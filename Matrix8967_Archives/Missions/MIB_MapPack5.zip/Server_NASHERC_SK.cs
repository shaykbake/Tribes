// FILENAME: Server_NASHERC_SK.cs
//
// NASHERC Racing Server Script
// Seeker Series (WC) Restrictions


exec(serverLocation);
//-------------------------------------------------
//  RC file to start a server automatically
//-------------------------------------------------

//-------------------------------------------------
// Edit the parameters of this file to configure
// your server options. Use notepad, not a word
// processor. File must be saved as text only.
//-------------------------------------------------

//-------------------------------------------------
// Type the name for your server inside the quotes
// Must be less then 22 characters
//-------------------------------------------------
$server::Hostname = strcat("NASHERC RACING!!!");

//-------------------------------------------------
// Password Protection. Leave blank for none.
// Quotes optional.
//-------------------------------------------------
$server::Password =                                 "";

//-------------------------------------------------
// Maximum player limit. 16 is highest recommended.
//-------------------------------------------------
$server::MaxPlayers =                              10;

//-------------------------------------------------
// Number of kills before server cycles.
// If zero, kills are never reset.
//-------------------------------------------------
$server::FragLimit =                               0;

//-------------------------------------------------
// Time limit in minutes before server cycles.
// Must be a positive integer.
//-------------------------------------------------
$server::TimeLimit =                               0;

//-------------------------------------------------
// Mass limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::MassLimit =                                0;

//-------------------------------------------------
// Combat Value limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::CombatValueLimit =                         0;

//-------------------------------------------------
// Team play options. TeamPlay false =  deathmatch.
// TeamPlay true = teams
//-------------------------------------------------
$server::TeamPlay =                                FALSE;

//-------------------------------------------------
// Team Mass limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamMassLimit =                            0;

//-------------------------------------------------
// Team Combat Value Limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamCombatValueLimit =                     0;

//-------------------------------------------------
// Tech Level Limit
// Must be a positive integer less then or
// equal to 128 or zero for no limit.
//-------------------------------------------------
$server::TechLevelLimit =                          0;

//-------------------------------------------------
// Drop In Progress
// Does server allow drop in progress??
//-------------------------------------------------
$server::DropInProgress =                            TRUE  ;

$server::AllowMixedTech =                           TRUE  ;
$server::FactoryVehOnly =                           FALSE  ;

//-------------------------------------------------
// Mission rotation list. This is the order the
// worlds will cycle in a game with either the frag
// or time limits set.
//-------------------------------------------------
$MissionCycling::Stage0 =                          "RACE_SK_Daytona";
$MissionCycling::Stage1 =                          "RACE_SK_Charlotte";
$MissionCycling::Stage2 =                          "RACE_SK_LA";
$MissionCycling::Stage3 =                          "RACE_SK_Bristol";
$MissionCycling::Stage4 =                          "RACE_SK_Rockingham";
$MissionCycling::Stage5 =                          "RACE_SK_Talladega";
$MissionCycling::Stage6 =                          "RACE_SK_Martinsville";
$MissionCycling::Stage7 =                          "RACE_SK_Sears_Point";
$MissionCycling::Stage8 =                          "RACE_SK_Manhattan";
$MissionCycling::Stage9 =                          "RACE_SK_Atlanta";
$MissionCycling::Stage10 =                         "RACE_SK_New_York";
$MissionCycling::Stage11 =                         "RACE_SK_RR_Spawne32";
//-------------------------------------------------
// Start mission. Defines which mission from the
// rotation list the server starts on.
//-------------------------------------------------
$server::Mission = $MissionCycling::Stage0;

// These items will be allowed by default -- your mission script can change these
// by calling allowVehicle, allowComponent, or allowWeapon
function setAllowedItems()
{
      allowVehicle(  all, FALSE  );
      allowVehicle(  20, TRUE  );

      allowWeapon(  all, FALSE  );
      allowWeapon(  101, TRUE  );
      allowWeapon(  105, TRUE  );
      allowWeapon(  116, TRUE  );
      allowWeapon(  118, TRUE  );     
      allowWeapon(  103, TRUE  );     
      allowWeapon(  114, TRUE  );
      allowWeapon(  104, TRUE  );
      
      allowComponent(  all, FALSE  );
      allowComponent(  125, TRUE  );
      allowComponent(  226, TRUE  );
      allowComponent(  300, TRUE  );
      allowComponent(  301, TRUE  );
      allowComponent(  302, TRUE  );
      allowComponent(  303, TRUE  );   
      allowComponent(  431, TRUE  );
      allowComponent(  805, TRUE  );
      allowComponent(  806, TRUE  );
      allowComponent(  807, TRUE  );
      allowComponent(  820, TRUE  );
      allowComponent(  830, TRUE  );
      allowComponent(  840, TRUE  );
      allowComponent(  845, TRUE  );
      allowComponent(  850, TRUE  );
      allowComponent(  865, TRUE  );
      allowComponent(  870, TRUE  );
      allowComponent(  880, TRUE  );
      allowComponent(  885, TRUE  );
      allowComponent(  890, TRUE  );
      allowComponent(  914, TRUE  );
      allowComponent(  225, TRUE  );
      allowComponent(  200, TRUE  );
      allowComponent(  201, TRUE  );
      allowComponent(  202, TRUE  );
      allowComponent(  203, TRUE  );
      allowComponent(  204, TRUE  );
      allowComponent(  205, TRUE  );
      allowComponent(  226, TRUE  );
      allowComponent(  227, TRUE  );
      allowComponent(  228, TRUE  );
      allowComponent(  229, TRUE  );
      allowComponent(  230, TRUE  );
      allowComponent(  400, TRUE  );
      allowComponent(  401, TRUE  );
      allowComponent(  408, TRUE  );
      allowComponent(  409, TRUE  );
      allowComponent(  410, TRUE  );
      allowComponent(  411, TRUE  );
      allowComponent(  412, TRUE  );
      allowComponent(  413, TRUE  );
      allowComponent(  414, TRUE  );
      allowComponent(  426, TRUE  );
      allowComponent(  427, TRUE  );
      allowComponent(  428, TRUE  );
      allowComponent(  429, TRUE  );
      allowComponent(  430, TRUE  );
      allowComponent(  432, TRUE  );
      allowComponent(  433, TRUE  );
      allowComponent(  434, TRUE  );
      allowComponent(  128, TRUE  );
      allowComponent(  129, TRUE  );
      allowComponent(  926, TRUE  );
      allowComponent(  927, TRUE  );
      allowComponent(  928, TRUE  );
      allowComponent(  929, TRUE  );
      allowComponent(  930, TRUE  );
}


