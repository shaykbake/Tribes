// FILENAME:	STF_Tibet.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "STF_Tibet";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
      $killPoints = 25;
      $deathPoints = 10;

	moonSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to SEIZE THE FORCE (STF)! Try to seize the FORCE at nav Alpha. Players recieve 1 point for every second that they maintain control of the FORCE. To seize the FORCE & gain points, merely stand inside the flame at nav Alpha. Kills are worth 25 points and deaths are worth -10. You can download STF_Tibet & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%this)
{
   setNavMarker( "MissionGroup/NavAlpha", true, %this );
}

function onMissionLoad()
{
   cdAudioCycle("Gnash", "Cloudburst", "Cyberntx"); 
   setGameInfo("<F2>GAME TYPE:<F0>  SEIZE THE FORCE!\n\n<F2>MISSION:<F0>  STF_Tibet\n\nWelcome to SEIZE THE FORCE (STF)! Try to seize the FORCE at nav Alpha. Players recieve <F3>1<F0> point for every second that they maintain control of the FORCE. To seize the FORCE & gain points, merely stand inside the flame at nav Alpha. Kills are worth <F3>25<F0> points and deaths are worth <F3>-10<F0>. You can download STF_Tibet & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

//Scores one point every second on contacting the trigger (THE FORCE)
function goal::trigger::OnContact(%this, %vehicleId)
{
%player = playerManager::vehicleIdToPlayerNum(%vehicleId);
%player.points++;
} 

function getPlayerScore(%player)
{
   return((%player.points) + (getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints));
}
