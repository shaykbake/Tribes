// FILENAME:	Stun_Grenades.cs
//
// CONCEPT BY:    Gen. Powio [MIB]
//
// SCRIPT BY:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Stun Grenades";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$server::HudMapViewOffsetX = -1500;
$server::HudMapViewOffsetY = 2500;

// Stun Grenade Options
//------------------------------------------------------------------------------
$damage = false;                        //Enable/disable damage
$damageAmount = 0;                      //Impact damage
$blastRadius = 0;                       //Impact blast radius
$projShape = "xobstacle.dts";           //Projectile Shape
$scanRange = 600;                       //Scanning weapon range (in meters)
$LTADsRange = 1500;                     //LTADs weapon range (in meters)
$speed = 60;                            //Projectile speed in m/s (# must be a multiple of 10)
$firingSound = "sfx_cmd.wav";           //Firing sound effect
$impactSound = "explo3.wav";            //Impact sound effect
$outOfRangeSound = "bptslct.wav";       //Out-of-range sound effect
$flashDuration = 20;                    //Flash duration (in seconds)
$flashColorRed = 3;                     //Flash color (red intensity)
$flashColorGreen = 3;                   //Flash color (green intensity)
$flashColorBlue = 3;                    //Flash color (blue intensity)
$flashRadius = 50;                      //Radius in which other players can get blinded (in meters)
$flashRadiusDuration = 7;               //Flash duration for players caught within flash radius (in seconds)
$depotWaitTime = 30;                    //Supply Depot wait time (in seconds)
$depotReadySound = "sfx_machine3.wav";  //Supply Depot ready sound effect
$flyers = false;                        //Enable/disable flyers
$impactFlashGlow = true;                //Enable/disable impact flash glow
$impactFlashGlowColor = yellow;         //Impact flash glow color (yellow, blue, red, or purple)
$radiusGlow = true;                     //Do the players caught in the flash radius glow too?
//------------------------------------------------------------------------------

$depot1Ready = true;
$depot2Ready = true;
$depot3Ready = true;
$depot4Ready = true;
$depot5Ready = true;

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
   temperateSounds();

   //This is needed for deleting all the projectiles when the mission cycles
   $projectiles = "Missiongroup/projectiles";
}

function onMissionLoad()
{
   cdAudioCycle("Mechsoul", "Terror", "Watching");
   setGameInfo("<F2>GAME TYPE:<F0>  Stun Grenade Deathmatch\n\n<F2>MISSION:<F0>  Stun Grenades\n\n<F2>MAP AND CONCEPT BY:<F0>  Gen. Powio [MIB]\n\n<F2>SCRIPT BY:<F0>  Com. Sentinal [M.I.B.]\n\nWelcome to Stun Grenade DeathMatch! Your vehicle is equipped with a stun grenade when you spawn. To fire your stun grenade, you can scan your target or spot them with LTADs. Scanning gives your stun grenade a " @ $scanRange @ "m range, while LTADs gives it a " @ $LTADsRange @ "m range. On impact, your stun grenade will blind your target for " @ $flashDuration @ " seconds. You can reload at the supply depots.\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download this and other missions made by Gen. Powio [MIB] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);      
      %player.plasmaPoints = 0;
   }
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Stun Grenade DeathMatch! Your vehicle is equipped with a stun grenade when you spawn. To fire your stun grenade, you can scan your target or spot them with LTADs. Scanning gives your stun grenade a " @ $scanRange @ "m range, while LTADs gives it a " @ $LTADsRange @ "m range. On impact, your stun grenade will blind your target for " @ $flashDuration @ " seconds. You can reload at the supply depots.");
   %player.plasmaPoints = 0;
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   %player.spawned = true;
   %player.killer = "Nobody";
   %vehicleId.hasGrenade = true;
   setHudTimer(0, 0, "", 2, %player);
   if(%player == 0)
   {
      %vehicleId.spawned = true;
   }
   //Flyer easter egg
   if($flyers == true)
   {
      order(%vehicleId, guard, 0);
   }
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%scanner.hasGrenade == true)
   {
      %scanner.hasGrenade = false;
      %range = ($scanRange / ($speed / 10));
      %projectile = newObject("proj", staticShape, $projShape);
      schedule("playAnimSequence(" @ %projectile @ ", 0, true);", 0.5);
      addToSet($projectiles, %projectile);
      %x = getPosition(%scanner, x);
      %y = getPosition(%scanner, y);
      if((getVehicleName(%scanner) == "Banshee") || (getVehicleName(%scanner) == "Knight's Banshee") || (getVehicleName(%scanner) == "Advocate"))
      {
         %z = getPosition(%scanner, z);
      }
      else
      {
         if($projShape == "xobstacle.dts")
         {
            %z = getTerrainHeight(%x1, %y1);
         }
         else
         {
            %z = getTerrainHeight(%x1, %y1) + 5;
         }
      }
      setPosition(%projectile, %x, %y, %z);
      playSound(%player, $firingSound, IDPRF_2D);
      schedule("homing(" @ %projectile @ ", " @ %scanned @ ", " @ %scanner @ ", " @ %range @ ");", 0.1);
   }
   else if(%scanner.hasGrenade == false)
   {
      say(%player, %player, "<F5>You are not equipped with a stun grenade!");
   }
}

function vehicle::onSpot(%spotter, %target)
{
   %player = playerManager::vehicleIdToPlayerNum(%spotter);
   if(%spotter.hasGrenade == true)
   {
      if(%target != "")
      {
         if(getVehicleName(%target) != false)
         {
            %spotter.hasGrenade = false;
            %range = ($LTADsRange / ($speed / 10));
            %projectile = newObject("proj", staticShape, $projShape);
            schedule("playAnimSequence(" @ %projectile @ ", 0, true);", 0.5);
            addToSet($projectiles, %projectile);
            %x = getPosition(%spotter, x);
            %y = getPosition(%spotter, y);
            if((getVehicleName(%spotter) == "Banshee") || (getVehicleName(%spotter) == "Knight's Banshee") || (getVehicleName(%spotter) == "Advocate"))
            {
               %z = getPosition(%spotter, z);
            }
            else
            {
               if($projShape == "xobstacle.dts")
               {
                  %z = getTerrainHeight(%x1, %y1);
               }
               else
               {
                  %z = getTerrainHeight(%x1, %y1) + 5;
               }
            }
            setPosition(%projectile, %x, %y, %z);
            playSound(%player, $firingSound, IDPRF_2D);
            schedule("homing(" @ %projectile @ ", " @ %target @ ", " @ %spotter @ ", " @ %range @ ");", 0.1);
         }
         else
         {
            say(%player, %player, "<F5>You cannot fire your stun grenade at a structure!");
         }  
      }
      else if(%target == "")
      {
         say(%player, %player, "<F5>Target lost.", "bptslct.wav");
      }
   }
   else if(%spotter.hasGrenade == false)
   {
      if(%target != "")
      {
         say(%player, %player, "<F5>You are not equipped with a stun grenade!");
      }
      else if(%target == "")
      {
         say(%player, %player, "<F5>Target lost.", "bptslct.wav");
      }
   }
}

function structure::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   say(%player, %player, "<F5>You cannot fire your stun grenade at a structure!");
}

function homing(%projectile, %target, %spotter, %range)
{
   %player = playerManager::vehicleIdToPlayerNum(%target);
   %player2 = playerManager::vehicleIdToPlayerNum(%spotter);
   if(%range > 0)
   {
      %range--;
      %distance = getDistance(%projectile, %target);
      if(%player == 0)
      {
         if((%distance > 10)&&(%target.spawned == true))
         {
            %x1 = getPosition(%projectile, x);
            %y1 = getPosition(%projectile, y);
            %x2 = getPosition(%target, x);
            %y2 = getPosition(%target, y);
            %increments = %distance / ($speed / 10);
            %xOffset = (%x2 - %x1) / %increments;
            %yOffset = (%y2 - %y1) / %increments;
            %x = %x1 + %xOffset;
            %y = %y1 + %yOffset;
            if((getVehicleName(%target) == "Banshee") || (getVehicleName(%target) == "Knight's Banshee") || (getVehicleName(%target) == "Advocate") || (getVehicleName(%spotter) == "Banshee") || (getVehicleName(%spotter) == "Knight's Banshee") || (getVehicleName(%spotter) == "Advocate"))
            {
               %z1 = getPosition(%projectile, z);
               %z2 = getPosition(%target, z);
               %increments = %distance / ($speed / 10);
               %zOffset = (%z2 - %z1) / %increments;
               %z = %z1 + %zOffset;
            }
            else
            {
               if($projShape == "xobstacle.dts")
               {
                  %z = getTerrainHeight(%x1, %y1);
               }
               else
               {
                  %z = getTerrainHeight(%x1, %y1) + 5;
               }
            }
            setPosition(%projectile, %x, %y, %z);
            schedule("homing(" @ %projectile @ ", " @ %target @ ", " @ %spotter @ ", " @ %range @ ");", 0.1);
         }
         else if((%distance <= 10)&&(%target.spawned == true))
         {
            impact(%projectile, %target, %spotter);
         }
         else
         {
            deleteObject(%projectile);
            echo("Projectile deleted.");
         }
      }
      else
      {
         if((%distance > 10)&&(%player.spawned == true))
         {
            %x1 = getPosition(%projectile, x);
            %y1 = getPosition(%projectile, y);
            %x2 = getPosition(%target, x);
            %y2 = getPosition(%target, y);
            %increments = %distance / ($speed / 10);
            %xOffset = (%x2 - %x1) / %increments;
            %yOffset = (%y2 - %y1) / %increments;
            %x = %x1 + %xOffset;
            %y = %y1 + %yOffset;
            if((getVehicleName(%target) == "Banshee") || (getVehicleName(%target) == "Knight's Banshee") || (getVehicleName(%target) == "Advocate") || (getVehicleName(%spotter) == "Banshee") || (getVehicleName(%spotter) == "Knight's Banshee") || (getVehicleName(%spotter) == "Advocate"))
            {
               %z1 = getPosition(%projectile, z);
               %z2 = getPosition(%target, z);
               %increments = %distance / ($speed / 10);
               %zOffset = (%z2 - %z1) / %increments;
               %z = %z1 + %zOffset;
            }
            else
            {
               if($projShape == "xobstacle.dts")
               {
                  %z = getTerrainHeight(%x1, %y1);
               }
               else
               {
                  %z = getTerrainHeight(%x1, %y1) + 5;
               }
            }
            setPosition(%projectile, %x, %y, %z);
            schedule("homing(" @ %projectile @ ", " @ %target @ ", " @ %spotter @ ", " @ %range @ ");", 0.1);
         }
         else if((%distance <= 10)&&(%player.spawned == true))
         {
            impact(%projectile, %target, %spotter);
         }
         else
         {
            deleteObject(%projectile);
            echo("Projectile deleted.");
         }
      }
   }
   else
   {
      deleteObject(%projectile);
      echo("Out of range: Projectile deleted.");
      if($outOfRangeSound != "none")
      {
         say(%player2, "<F5>Target out of range.", $outOfRangeSound);
      }
   }
}

function impact(%projectile, %target, %spotter)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%spotter);
   %player2 = playerManager::vehicleIdToPlayerNum(%target);
   deleteObject(%projectile);  
   echo("Impact " @ %player2 @ ": Projectile deleted.");
   fadeEvent(%player2, in, $flashDuration, $flashColorRed, $flashColorGreen, $flashColorBlue);
   if($impactFlashGlow == true)
   {
      setVehicleSpecialIdentity(%target, true, $impactFlashGlowColor);
      schedule("setVehicleSpecialIdentity(" @ %target @ ", false);", $flashDuration);
   }
   %count = playermanager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player3 = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player3);
      if((getDistance(%vehicleId, %target) <= $flashRadius) && (%vehicleId != %target))
      {
         fadeEvent(%player3, in, $flashRadiusDuration, $flashColorRed, $flashColorGreen, $flashColorBlue);
         if(($impactFlashGlow == true)&&($radiusGlow == true))
         {
            setVehicleSpecialIdentity(%vehicleId, true, $impactFlashGlowColor);
            schedule("setVehicleSpecialIdentity(" @ %vehicleId @ ", false);", $flashRadiusDuration);
         }
      }
   }
   if($damage == true)
   {
      %player2.killer = %player1;
      damageArea(%target, 0, 0, 0, $blastRadius, $damageAmount);
      schedule("noKiller(" @ %player2 @ ");", 2);
   }
   if(%player2 != 0)
   {
      playSound(%player2, $impactSound, IDPRF_2D);
   }
}

function noKiller(%player)
{
   %player2.killer = "Nobody";
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   %player.spawned = false;
   if(%player == 0)
   {
      %destroyed.spawned = false;
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);

   if(($damage == true)&&(%player2 == 0)&&(%player.killer != "Nobody"))
   {
      say("Everybody", 3, getName(%player) @ " was destroyed by " @ getName(%player.killer) @ "'s stun grenade!", $impactSound);
      %killer = %player.killer;
      %killer.plasmaPoints = %killer.plasmaPoints + 3;
   }   
   else
   {
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
   }

   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer))&&(%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }
}

function depot1::trigger::onEnter(%trigger, %vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(($depot1Ready == true)&&(%vehicleId.hasGrenade == false))
   {
      $depot1Ready = false;
      %vehicleId.hasGrenade = true;
      schedule("depot1Ready();", $depotWaitTime);
      say(%player, %player, "<F1>Your vehicle has been equipped with a stun grenade.");
   }
   else if(($depot1Ready == true)&&(%vehicleId.hasGrenade == true))
   {
      say(%player, %player, "<F1>Your vehicle is already equipped with a stun grenade!");
   }
   else if($depot1Ready == false)
   {
      say(%player, %player, "<F1>Supply Depot 001 is not ready.");
   }
}

function depot1Ready()
{
   $depot1Ready = true;
   say("Everybody", 2, "<F1>Supply Depot 001 is ready.", $depotReadySound);
}

function depot2::trigger::onEnter(%trigger, %vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(($depot2Ready == true)&&(%vehicleId.hasGrenade == false))
   {
      $depot2Ready = false;
      %vehicleId.hasGrenade = true;
      schedule("depot2Ready();", $depotWaitTime);
      say(%player, %player, "<F1>Your vehicle has been equipped with a stun grenade.");
   }
   else if(($depot2Ready == true)&&(%vehicleId.hasGrenade == true))
   {
      say(%player, %player, "<F1>Your vehicle is already equipped with a stun grenade!");
   }
   else if($depot2Ready == false)
   {
      say(%player, %player, "<F1>Supply Depot 002 is not ready.");
   }
}

function depot2Ready()
{
   $depot2Ready = true;
   say("Everybody", 2, "<F1>Supply Depot 002 is ready.", $depotReadySound);
}

function depot3::trigger::onEnter(%trigger, %vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(($depot3Ready == true)&&(%vehicleId.hasGrenade == false))
   {
      $depot3Ready = false;
      %vehicleId.hasGrenade = true;
      schedule("depot3Ready();", $depotWaitTime);
      say(%player, %player, "<F1>Your vehicle has been equipped with a stun grenade.");
   }
   else if(($depot3Ready == true)&&(%vehicleId.hasGrenade == true))
   {
      say(%player, %player, "<F1>Your vehicle is already equipped with a stun grenade!");
   }
   else if($depot3Ready == false)
   {
      say(%player, %player, "<F1>Supply Depot 003 is not ready.");
   }
}

function depot3Ready()
{
   $depot3Ready = true;
   say("Everybody", 2, "<F1>Supply Depot 003 is ready.", $depotReadySound);
}

function depot4::trigger::onEnter(%trigger, %vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(($depot4Ready == true)&&(%vehicleId.hasGrenade == false))
   {
      $depot4Ready = false;
      %vehicleId.hasGrenade = true;
      schedule("depot4Ready();", $depotWaitTime);
      say(%player, %player, "<F1>Your vehicle has been equipped with a stun grenade.");
   }
   else if(($depot4Ready == true)&&(%vehicleId.hasGrenade == true))
   {
      say(%player, %player, "<F1>Your vehicle is already equipped with a stun grenade!");
   }
   else if($depot4Ready == false)
   {
      say(%player, %player, "<F1>Supply Depot 004 is not ready.");
   }
}

function depot4Ready()
{
   $depot4Ready = true;
   say("Everybody", 2, "<F1>Supply Depot 004 is ready.", $depotReadySound);
}

function depot5::trigger::onEnter(%trigger, %vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(($depot5Ready == true)&&(%vehicleId.hasGrenade == false))
   {
      $depot5Ready = false;
      %vehicleId.hasGrenade = true;
      schedule("depot5Ready();", $depotWaitTime);
      say(%player, %player, "<F1>Your vehicle has been equipped with a stun grenade.");
   }
   else if(($depot5Ready == true)&&(%vehicleId.hasGrenade == true))
   {
      say(%player, %player, "<F1>Your vehicle is already equipped with a stun grenade!");
   }
   else if($depot5Ready == false)
   {
      say(%player, %player, "<F1>Supply Depot 005 is not ready.");
   }
}

function depot5Ready()
{
   $depot5Ready = true;
   say("Everybody", 2, "<F1>Supply Depot 005 is ready.", $depotReadySound);
}

function onMissionEnd()
{
   flushConsoleScheduler();
   deleteObject($projectiles);
   echo("All projectiles deleted.");
}

function getPlayerScore(%player)
{
   return((getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints)) + %player.plasmaPoints;
}
