MIB Map Pack #5
------------------------------------------------------------------------

MIB_MapPack5.zip contains 226 maps. Some maps are new, some are updates
to older maps. I recommend that you overwrite any older versions of the
maps with the updated versions when prompted.

Here is a list of the maps included in this pack:


- AI_Cardinal_Spear
- AI_Generator   (New!)
- AI_Mayhem
- AI_Rebellion
- Arctic_Infiltration   (New!)
- Artificial_Intelligence_01   (New!)
- Artificial_Intelligence_02   (New!)
- Artificial_Intelligence_03   (New!)
- ATR2_CTF_Stab_n_Grab
- ATR2_CTF_Titanic_Assault
- ATR2_DM_Cold_Titan_Night
- ATR2_DM_Heavens_Peak
- ATR2_DM_Terran_Conquest
- ATR2_DM_Twin_Siege
- Complexity
- Control_Center
- Covert_Strike   (New!)
- CTF_Broadside   (New!)
- CTF_Bunkers
- CTF_Darkside   (New!)
- CTF_EF_Circular_Logic   (New!)
- CTF_EF_First_World   (New!)
- CTF_EF_Stab_n_Grab   (New!)
- CTF_EF_Winter_Wasteland   (New!)
- CTF_Egyptian
- CTF_First_World   (New!)
- CTF_Particle_Accelerator   (New!)
- CTF_RPM_Circular_Logic   (New!)
- CTF_RPM_First_World   (New!)
- CTF_SPYDER_Circular_Logic   (New!)
- CTF_SPYDER_First_World   (New!)
- CTF_SPYDER_Tribal_Warfare   (New!)
- CTF_Tribal_Warfare   (New!)
- CvH_Blizzard
- Defend_Alexandria   (New!)
- DM_Ancient_Temple   (New!)
- DM_Aquatica
- DM_Aquatica_Dam
- DM_Blizzard
- DM_Broadside   (New!)
- DM_Canyon
- DM_Circles   (New!)
- DM_Cybrid_Complex
- DM_Dark_Side   (New!)
- DM_Death_Bowl
- DM_Death_From_Above
- DM_Death_Tube
- DM_Deathmatch   (New!)
- DM_Deep_Freeze
- DM_Desert_Base
- DM_Dullsville   (New!)
- DM_Egyptian
- DM_Electric_Cage
- DM_EXTREME
- DM_Fallout   (New!)
- DM_First_World   (New!)
- DM_Forts
- DM_FreakY_RuIns   (New!)
- DM_LA
- DM_Labyrinth   (New!)
- DM_LifeForce   (New!)
- DM_Mars_Battle
- DM_Mars_Mess   (New!)
- DM_M@X_on_the_Edge   (New!)
- DM_Medieval   (New!)
- DM_Mercury_Land   (New!)
- DM_Meteor_Shower
- DM_Mineshaft
- DM_NightStalker   (New!)
- DM_Nova_Alexandria
- DM_NY
- DM_Particle_Accelerator   (New!)
- DM_PIT
- DM_Plutonium   (New!)
- DM_Rome
- DM_Sand_Dunes   (New!)
- DM_Sandstorm
- DM_Sky_Arena
- DM_Snow_Blind
- DM_SS_Castle   (New!)
- DM_The_Crowd   (New!)
- DM_ThunderStorm   (New!)
- DM_Tower_Of_Death
- DM_Tribal_Warfare   (New!)
- DM_Venus_Sunrise
- EF_Avalanche   (New!)
- EF_Cold_Titan_Night   (New!)
- EF_First_World   (New!)
- EF_Lunacy   (New!)
- ES2_Plasma_Cannons   (New!)
- EXP_City_on_the_Edge   (New!)
- EXP_First_World   (New!)
- EXP_Sand_Dunes   (New!)
- EXP_Stadium_2000   (New!)
- EXP_Tribal_Warfare   (New!)
- EXP_Twilights_Hammer   (New!)
- Find_The_Cheese   (New!)
- FTAG_Death_Platform
- FTAG_Lunar_Crater   (New!)
- FTAG_ThunderStorm   (New!)
- FTAG_Titan_Base
- H&S_Canyon
- H&S_City_on_the_Edge
- H&S_Death_From_Above
- H&S_Deep_Freeze
- H&S_Labyrinth   (New!)
- H&S_Mars_Mess   (New!)
- H&S_Medieval   (New!)
- H&S_Mineshaft
- H&S_Nova_Alexandria
- H&S_Snow_Blind
- H&S_Titan
- Harv_Desert_of_Ice   (New!)
- Harv_Desolate   (New!)
- Interactive_Mission_Editor   (New!)
- ION_Ancient_Temple   (New!)
- ION_Avalanche   (New!)
- ION_Bloody_Brunch   (New!)
- ION_Cold_Titan_Night   (New!)
- ION_First_World   (New!)
- ION_Heavens_Peak   (New!)
- ION_Lunacy   (New!)
- ION_Mercury_Rising   (New!)
- ION_Particle_Accelerator   (New!)
- ION_Plutonium   (New!)
- ION_Sand_Dunes   (New!)
- ION_State_of_Confusion   (New!)
- ION_The_Guardian   (New!)
- Martian_Recon   (New!)
- MIB_Arena
- MIB_Control_Center
- MIB_Training
- New_Technology   (New!)
- RACE_BSH_Atlanta
- RACE_BSH_Bristol
- RACE_BSH_Charlotte
- RACE_BSH_Daytona
- RACE_BSH_LA
- RACE_BSH_Manhattan
- RACE_BSH_Martinsville
- RACE_BSH_New_York
- RACE_BSH_Rockingham
- RACE_BSH_RR_Spawne32   (New!)
- RACE_BSH_Sears_Point
- RACE_BSH_Talladega
- RACE_GT_Atlanta
- RACE_GT_Bristol
- RACE_GT_Charlotte
- RACE_GT_Daytona 
- RACE_GT_LA
- RACE_GT_Manhattan
- RACE_GT_Martinsville
- RACE_GT_New_York
- RACE_GT_Rockingham
- RACE_GT_RR_Spawne32   (New!)
- RACE_GT_Sears_Point
- RACE_GT_Talladega
- RACE_SK_Atlanta 
- RACE_SK_Bristol
- RACE_SK_Charlotte
- RACE_SK_Daytona
- RACE_SK_LA
- RACE_SK_Manhattan
- RACE_SK_Martinsville
- RACE_SK_New_York
- RACE_SK_Rockingham
- RACE_SK_RR_Spawne32   (New!)
- RACE_SK_Sears_Point
- RACE_SK_Talladega
- RACE_TK_Atlanta
- RACE_TK_Bristol
- RACE_TK_Charlotte
- RACE_TK_Daytona
- RACE_TK_LA
- RACE_TK_Manhattan
- RACE_TK_Martinsville
- RACE_TK_New_York
- RACE_TK_Rockingham
- RACE_TK_RR_Spawne32   (New!)
- RACE_TK_Sears_Point
- RACE_TK_Talladega
- RACE_WC_Atlanta
- RACE_WC_Bristol
- RACE_WC_Charlotte
- RACE_WC_Daytona
- RACE_WC_LA
- RACE_WC_Manhattan
- RACE_WC_Martinsville
- RACE_WC_New_York
- RACE_WC_Rockingham
- RACE_WC_RR_Spawne32   (New!)
- RACE_WC_Sears_Point
- RACE_WC_Talladega
- Rebel_Underground
- Rescue_Technician   (New!)
- RPM_City_on_the_Edge   (New!)
- RPM_First_World   (New!)
- RPM_Sand_Dunes   (New!)
- RPM_Twilights_Hammer   (New!)
- SPYDER_City_on_the_Edge   (New!)
- SPYDER_First_World   (New!)
- SPYDER_Sand_Dunes   (New!)
- SPYDER_Tribal_Warfare   (New!)
- SPYDER_Twilights_Hammer   (New!)
- SS_Millionaire   (Updated!)
- SS_X-Games   (New!)
- STF_Tibet
- STF_Zenith
- STUN_Heavens_Peak   (New!)
- TDM_AI_TagTeam
- TDM_AI_Warfare
- TDM_Bunkers
- TDM_Capture_The_AI
- TDM_Desolate_Night
- TDM_Mars_Assault
- TDM_MountainTop
- TDM_Nuclear_Fallout   (New!)
- TDM_Nuclear_GroundZero   (New!)
- TDM_Nuclear_Winter   (New!)
- TDM_Snatch   (New!)
- TDM_Stargate
- WAR_Bunkers
- War_Is_All
- WAR_Reversed
- WAR_Titan_Siege
- WAR_Titanic_Hotzone



MIB Multiplayer Campaign
------------------------------------------------------------------------

The campaign consists of 6 missions:

1. Martian_Recon
2. Covert_Strike
3. Rescue_Technician
4. New_Technology
5. Arctic_Infiltration
6. Defend_Alexandria

These missions will automatically cycle by default. You can toggle this
option on/off by going into the mission's .cs file and changing the
variable $cycleMissions from true to false.

There is also a dedicated server file included for the campaign:

Server_MIB_Campaign.cs



Harvester version 1.0 (with nuclear capability)
------------------------------------------------------------------------

Harvester is a game that is similar to Warcraft or Starcraft, only with
hercs instead. You can mine ore, build structures, build hercs,
order them around, and even build nuclear weapons and send in bomber
air strikes. Harvester maps begin with the HARV_ prefix. Look in
Harvest_StdLib.cs for more information about this game.

There is a dedicated server file included for these type of maps:

Server_Harvester.cs

Harvester maps/script by Dull.
Nuclear modification by Com. Sentinal [M.I.B.].



Ion Cannon Maps
------------------------------------------------------------------------

Ion cannon maps begin with the ION_ prefix. These maps allow you to fire
Ion cannons at other players by scanning them or using LTADs. The cannons
recharge after 90 seconds. 

There is a dedicated server file included for these type of maps:

Server_Ion_Cannons.cs



Explosives Maps
------------------------------------------------------------------------

Explosives maps begin with the EXP_ prefix. These maps allow you to lay
timed mines by powering down your vehicle. You can change the amount of
time on your explosives by scanning a structure or another vehicle. You
can reload with more explosives by going into the supply depots.

There is a dedicated server file included for these type of maps:

Server_Explosives.cs



Nuclear TDM Maps
------------------------------------------------------------------------

Nuclear TDM maps begin with the TDM_Nuclear_ prefix. These maps allow you
to build nuclear weapons in your team's nuclear silo, then spot for Draco
bomber air strikes to drop the nuke on your target.

There is a dedicated server file included for these type of maps:

Server_Nuclear_TDM.cs



Spyder Mine Maps
------------------------------------------------------------------------

Spyder Mine maps begin with the SPYDER_ prefix. These maps allow you to
deploy spyder mines, which run to your nav marker when you power down.
When the spyder mine reaches your nav, it will proceed to deploy an entire
proximity minefield to your specifications. You can change your minefield's
density by scanning a structure or another vehicle. You can reload with
another spyder mine by going into the supply depots.

There are also some CTF versions of the spyder mine maps. These maps begin
with the CTF_SPYDER_ prefix.

There are a few dedicated server files included for these type of maps:

For the DM version of Spyder mines use this file:

Server_Spyder_Mines.cs

For the TDM version of Spyder mines use this file:

Server_Spyder_Mines_TDM.cs

For the CTF version of Spyder mines use this file:

Server_Spyder_Mines_CTF.cs



Repulsor Mine Maps
------------------------------------------------------------------------

Repulsor Mine maps begin with the RPM_ prefix. These maps allow you to
deploy repulsor mines, which will repel any vehicle that gets near them.
You can reload with another repulsor mine by going into the supply depots.
You can delete your deployed mine by scanning a structure or another
vehicle.

There are also some CTF versions of the repulsor mine maps. These maps
begin with the CTF_RPM_ prefix.

There are a few dedicated server files included for these type of maps:

For the DM version of Repulsor mines use this file:

Server_Repulsor_Mines.cs

For the CTF version of Repulsor mines use this file:

Server_Repulsor_Mine_CTF.cs



Energy Field Maps
------------------------------------------------------------------------

Energy Field Maps begin with the EF_ prefix. These maps allow you to
deploy portable force-fields (like in the Tribes Renegades mod). Each
energy field that you deploy will be able to take several shots from
a fully-loaded heavy HERC. You can adjust your energy field's rotation
by scanning a structure or another vehicle. By default, the energy fields
will deploy perpendicular to the direction your vehicle is currently facing.
After deploying an energy field, it takes 40 seconds for your energy field
generator to recharge.

There are also some CTF versions of the energy field maps. These maps begin
with the CTF_EF_ prefix.

There are a few dedicated server files included for these type of maps:

For the DM version of Spyder mines use this file:

Server_Energy_Fields.cs

For the CTF version of Spyder mines use this file:

Server_Energy_Field_CTF.cs



EarthSiege 2 Plasma Cannons
------------------------------------------------------------------------

ES2_Plasma_Cannons is map that allows you to use the plasma cannon from
EarthSiege 2. You can fire your plasma cannon by scanning your target or
using LTADs to spot it. If you use the scanning method, your plasma cannon
is limited to a 700m maximum range. If you use LTADs, your plasma cannon
is capable of a 1500m maximum range. When you fire your plasma cannon,
your plasma pulse will track your target. On impact, the pulse delivers
huge amounts of damage to the target. It will most likely kill a light
herc in only one hit, but most heavy hercs will only be damaged.

There is also a flyer easter egg in this map. If you spawn in a flyer, it
will automatically take off. (think Razor, hehe)

There is a dedicated server file included for this map:

Server_ES2_Plasma.cs



Find The Cheese
------------------------------------------------------------------------

Find_The_Cheese is a new game, in which players are dropped into a giant
maze and must try to find the cheese. When a player finds the cheese,
he is scored 10 points, and the cheese is randomly re-hidden in the maze.
Each time the cheese is re-hidden, the maze changes. There are 12800
possible configurations that the maze can take on, insuring that the game
will be different every time it is played.

There is a dedicated server file included for this map:

Server_Find_The_Cheese.cs



AI Generator
------------------------------------------------------------------------

AI_Generator is a fully-customizable AI training map. You can control the
number of AI produced, their skill, and their vehicle types. You can also
randomly clone players. Other options include enabling/disabling repair
pads. The attack sequence can be initiated or stopped at any time.

You can enable host-lock by changing the variable $hostLock from false
to true at the top of the map's script. When host-lock is enabled, only
the server host can initiate or stop the AI attack sequence. Host-lock
is disabled by default.

There is a dedicated server file included for this map:

Server_AI_Generator.cs



Artificial Intelligence Maps
------------------------------------------------------------------------

These maps feature the smartest, most realistic AI ever scripted.
They chat, they randomly patrol, they react to players and other AI,
they use repair pads, and they have skill enough to match actual players
in battle. It's hilarious when people think that they are just other
players in the server. They even talk back to the AI, lol!

There is a dedicated server file included for these type of maps:

Server_Artificial_Intelligence.cs



Interactive Mission Editor
------------------------------------------------------------------------

Interactive_Mission_Editor is a map which lets players build up to 10
structures each, and gives them the ability to adjust their structures by
raising/lowering, rotating, tilting, offsetting, and much more. Players
also have the ability to delete any of the structures they have created.

This map requires the use of a special keymap:

Mission_Edit_Keymap.cs

To install the keymap, move Mission_Edit_Keymap.cs into your
C:\Dynamix\Starsiege\KeyMaps folder. Then start Starsiege and start the
map. Next, press F11 to bring up your options menu. Scroll down the list
of your keymaps and select Mission_Edit_Keymap.cs from the list. Then press
F11 once again to exit the menu.

After installing the keymap, read the game info tab of
Interactive_Mission_Editor for information about how to use the keys in-game.



Starsiege X-Games
------------------------------------------------------------------------

SS_X-Games is a map based on the real X-Games on ESPN2 and includes
vert skateboarding, grind rails, airtime, half-pipe transfers and much
more. All I can say is, this map is eXtReMe!!

There is a dedicated server file included for this map:

Server_SS_X-Games.cs



Stun Grenade Maps
------------------------------------------------------------------------

Stun Grenade maps begin with the STUN_ prefix. These maps allow players
to fire homing grenades at their target, which blinds them and anything
within the flash radius. They're kinda like flash-bangs. You can reload
with more stun greenades by walking into a supply depot reload station.

There is a dedicated server file included for this map:

Server_Stun_Grenades.cs



NASHERC Racing Maps
------------------------------------------------------------------------

There are 60 NASHERC Racing maps included with this pack. The maps have
the prefix "RACE". There are 12 tracks and 5 series (12 x 5 = 60). Each 
series restricts different vehicles, weapons, and components. The
following is a list of the series:

Winston Cup Series (WC) - Emancipators, Goads, Seekers, Talons
Busch Series (BSH) - Knight's Apocalypses (turbines allowed)
Seeker Series (SK) - Seekers (turbines & rockets allowed)
Craftsman Tank Series (TK) - Bolos, Predators, Disrupters (turbines allowed)
Goad/Talon Series (GT) - Goads, Talons

There are 5 versions of each track. Each one uses a different NASHERC series.
The series is designated on the maps by a secondary prefix after "RACE".
Examples include: WC, BSH, SK, TK, & GT
So a map that uses the track Daytona and uses the Winston Cup series would
be written like this: "RACE_WC_Daytona"

There are also some dedicated server files that are included with this pack.
They are:

Server_NASHERC_BSH.cs
Server_NASHERC_GT.cs
Server_NASHERC_SK.cs
Server_NASHERC_TK.cs
Server_NASHERC_WC.cs

If you want to make a custom track, look in one of the NASHERC Track scripts
for complete instructions on how to do it.

Update - The respawning bug has been fixed.



Starsiege: Who Wants To Be A Millionaire?
------------------------------------------------------------------------

This map is called "SS_Millionaire". It's based on the hit T.V. gameshow
on ABC. It's even hosted by Regis Philbin. You have to try this map out!

The pack also includes a dedicated server file for this:

Server_SS_Millionaire.cs

You have to use this file if you're going to create a dedicated server
because the map needs to have its specific settings.

Update - The wall has been raised to prevent cheating by firing missiles
over the wall. 



Flag Tag (FTAG)
------------------------------------------------------------------------

Flag Tag maps begin with the FTAG_ prefix. In this game, players try to
grab and hold the flag as long as they can. The flagholder gets scored
one point for every second that he holds the flag. Other players must
try to steal the flag from the flagholder by killing him. Whoever has
the most points when time runs out wins the game. 

You may remember this type of game from GoldenEye for the N64.



DM & H&S Death_From_Above
------------------------------------------------------------------------

This map uses a keymap to allow your vehicle to fly.
The keymap is called: "HercBoost Keymap.cs"
If you'd like to be able to fly in these two maps,
merely move this file to your Starsiege\KeyMaps folder.
Read the game info tab in these maps for further
information on how to use these keymaps to fly.



Repath.cs
------------------------------------------------------------------------

Many of these maps use campaign terrain. Repath.cs was included so that 
anyone could join your server without having to copy the campaign terrain
files to their multiplayer folder. You won't need to either. In fact, all 
of the maps from the MIB Map Pack #5 DO NOT require you to have any special 
terrain files to play. The repath.cs file should be placed in the
multiplayer folder along with all the maps. If you already have a file 
named repath.cs, overwrite it when prompted.



Hide & Seek (H&S) Info
------------------------------------------------------------------------

There are 11 Hide & Seek (H&S) maps included with this map pack.

There are also 2 dedicated server files included for running a Hide & Seek
dedicated server. The files are named:

Server_Hide&Seek.cs
Server_H&S_Teamplay.cs

If you would like to make your own Hide & Seek (H&S) map out of a DM or
TDM map, all you need to do is to copy & paste the H&S script in place of
the DM or TDM script. The only thing in the script you may want to change
(but it's not necessary) is the MISSION NAME in the intro & rules.



TrigonometryStdLib.cs
------------------------------------------------------------------------

This standard library file was included which contains several new commands
that can be very useful if your script deals with mathematical calculations
or trigonometry. Use exec("TrigonometryStdLib.cs"); at the top of your script
to enable the use of these commands. TrigonometryStdLib.cs must be included
with your map as a download if you used any of the commmands from it. If you
don't want to include the file, just copy the commands you need from
TrigonometryStdLib.cs over to your script and it will work the same.



Other Info on MIB
------------------------------------------------------------------------

I hope you enjoy the MIB Map Pack #5.
If you are interested in joining the Men In Black, visit the MIB Website at
www.starsiegemeninblack.cjb.net



Special Thanks
------------------------------------------------------------------------

Scripters & MapMakers:

Com. Sentinal [M.I.B.]            sentinal07@hotmail.com
Gen. Raven [M.I.B.]               sentinal07@hotmail.com
Maj. StormTrooper [M.I.B.]        stachowg@svol.org
Dull                              jmlaset@cstone.net
Gen. Powio [MIB]                  Powio@aol.com
M@J M@X D@M@Ge [M.I.B.]           Scooby3-uk@talk21.com
Gen. Deathrow [M.I.B.]            kennyd7@juno.com
Gen. DarkRaven [M.I.B.]           ravenhg@yahoo.com
{RR}Spawne32                      Spawne32b@home.com


Others:

Thanks to Buzzbum and S-110 for creating the mods to add extra shapes
to the SS mission editor. Many cool new maps were made because of this.

Thanks to all the people on the Starsiege Players Editing/Scripting 
MessageBoard for everything they've done to contribute. Orogogus,
Dull, Dolf Kooz, johnrich, mike the goad, and others; you have all
taken the time to answer my questions on the forum and I would have
never learned to script without you guys.

- Com. Sentinal [M.I.B.]
  Squad Leader of MIB
  Lead designer of the MIB Map Packs


------------------------------------------------------------------------

Dedicated to the memory of Dale Earnhardt, truly the greatest NASCAR
driver that ever lived. He will not be forgotten. We will miss you Dale!

                          333333333333333
                        3                33
                       3    33333333333    3
                       3   3           3    3 
                        3333            3   3
                                       3    3
                               33333333    3     
                               3           33
                                333333333    3
                                         3    3
                          3333            3   3
                         3   3           3    3
                         3    33333333333    3
                          3                33
                            333333333333333

                             DALE EARNHARDT
                            "The Intimidator"
                               (1951-2001)
                              A true legend.

------------------------------------------------------------------------             
