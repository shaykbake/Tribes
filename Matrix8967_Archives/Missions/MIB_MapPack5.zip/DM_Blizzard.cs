// FILENAME:	DM_Blizzard.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------

// this var 
$missionName = "DM_Blizzard";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	iceSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DeathMatch Blizzard! You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Gnash", "Cloudburst", "Cyberntx"); 
}