// FILENAME: Server_NASHERC_BSH.cs
//
// NASHERC Racing Server Script
// Busch Series (BSH) Restrictions


exec(serverLocation);
//-------------------------------------------------
//  RC file to start a server automatically
//-------------------------------------------------

//-------------------------------------------------
// Edit the parameters of this file to configure
// your server options. Use notepad, not a word
// processor. File must be saved as text only.
//-------------------------------------------------

//-------------------------------------------------
// Type the name for your server inside the quotes
// Must be less then 22 characters
//-------------------------------------------------
$server::Hostname = strcat("NASHERC RACING!!!");

//-------------------------------------------------
// Password Protection. Leave blank for none.
// Quotes optional.
//-------------------------------------------------
$server::Password =                                 "";

//-------------------------------------------------
// Maximum player limit. 16 is highest recommended.
//-------------------------------------------------
$server::MaxPlayers =                              10;

//-------------------------------------------------
// Number of kills before server cycles.
// If zero, kills are never reset.
//-------------------------------------------------
$server::FragLimit =                               0;

//-------------------------------------------------
// Time limit in minutes before server cycles.
// Must be a positive integer.
//-------------------------------------------------
$server::TimeLimit =                               0;

//-------------------------------------------------
// Mass limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::MassLimit =                                40;

//-------------------------------------------------
// Combat Value limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::CombatValueLimit =                         0;

//-------------------------------------------------
// Team play options. TeamPlay false =  deathmatch.
// TeamPlay true = teams
//-------------------------------------------------
$server::TeamPlay =                                FALSE;

//-------------------------------------------------
// Team Mass limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamMassLimit =                            0;

//-------------------------------------------------
// Team Combat Value Limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamCombatValueLimit =                     0;

//-------------------------------------------------
// Tech Level Limit
// Must be a positive integer less then or
// equal to 128 or zero for no limit.
//-------------------------------------------------
$server::TechLevelLimit =                          0;

//-------------------------------------------------
// Drop In Progress
// Does server allow drop in progress??
//-------------------------------------------------
$server::DropInProgress =                            TRUE  ;

$server::AllowMixedTech =                           TRUE  ;
$server::FactoryVehOnly =                           FALSE  ;

//-------------------------------------------------
// Mission rotation list. This is the order the
// worlds will cycle in a game with either the frag
// or time limits set.
//-------------------------------------------------
$MissionCycling::Stage0 =                          "RACE_BSH_Daytona";
$MissionCycling::Stage1 =                          "RACE_BSH_Charlotte";
$MissionCycling::Stage2 =                          "RACE_BSH_LA";
$MissionCycling::Stage3 =                          "RACE_BSH_Bristol";
$MissionCycling::Stage4 =                          "RACE_BSH_Rockingham";
$MissionCycling::Stage5 =                          "RACE_BSH_Talladega";
$MissionCycling::Stage6 =                          "RACE_BSH_Martinsville";
$MissionCycling::Stage7 =                          "RACE_BSH_Sears_Point";
$MissionCycling::Stage8 =                          "RACE_BSH_Manhattan";
$MissionCycling::Stage9 =                          "RACE_BSH_Atlanta";
$MissionCycling::Stage10 =                         "RACE_BSH_New_York";
$MissionCycling::Stage11 =                         "RACE_BSH_RR_Spawne32";
//-------------------------------------------------
// Start mission. Defines which mission from the
// rotation list the server starts on.
//-------------------------------------------------
$server::Mission = $MissionCycling::Stage0;

// These items will be allowed by default -- your mission script can change these
// by calling allowVehicle, allowComponent, or allowWeapon
function setAllowedItems()
{
      allowVehicle( all, FALSE );
      allowVehicle( 10, TRUE );
   
      allowWeapon( all, TRUE  );
      allowWeapon( 106, FALSE  );
      allowWeapon( 107, FALSE  );
      allowWeapon( 108, FALSE  );
      allowWeapon( 109, FALSE  );
      allowWeapon( 110, FALSE  );
      allowWeapon( 112, FALSE  );
      allowWeapon( 113, FALSE  );
      allowWeapon( 119, FALSE  );
      allowWeapon( 120, FALSE  );
      allowWeapon( 121, FALSE  );
      allowWeapon( 124, FALSE  );
      allowWeapon( 125, FALSE  );
      allowWeapon( 126, FALSE  );
      allowWeapon( 127, FALSE  );
      allowWeapon( 128, FALSE  );
      allowWeapon( 129, FALSE  );
      allowWeapon( 130, FALSE  );
      allowWeapon( 131, FALSE  );
      allowWeapon( 132, FALSE  );
      allowWeapon( 133, FALSE  );
      allowWeapon( 134, FALSE  );
      allowWeapon( 135, FALSE  );
      allowWeapon( 136, FALSE  );
      allowWeapon( 142, FALSE  );
      allowWeapon( 147, FALSE  );
      allowWeapon( 150, FALSE  );

      allowComponent( all, TRUE  );
      allowComponent( 100, FALSE  );
      allowComponent( 101, FALSE  );
      allowComponent( 102, FALSE  );
      allowComponent( 103, FALSE  );
      allowComponent( 104, FALSE  );
      allowComponent( 105, FALSE  );
      allowComponent( 111, FALSE  );
      allowComponent( 112, FALSE  );
      allowComponent( 113, FALSE  );
      allowComponent( 114, FALSE  );
      allowComponent( 115, FALSE  );
      allowComponent( 128, FALSE  );
      allowComponent( 129, FALSE  );
      allowComponent( 130, FALSE  );
      allowComponent( 131, FALSE  );
      allowComponent( 132, FALSE  );
      allowComponent( 133, FALSE  );
      allowComponent( 134, FALSE  );
      allowComponent( 135, FALSE  );
      allowComponent( 136, FALSE  );
      allowComponent( 137, FALSE  );
      allowComponent( 138, FALSE  );
      allowComponent( 139, FALSE  );
      allowComponent( 140, FALSE  );
      allowComponent( 141, FALSE  );
      allowComponent( 142, FALSE  );
      allowComponent( 143, FALSE  );
      allowComponent( 305, FALSE  );
      allowComponent( 307, FALSE  );
      allowComponent( 331, FALSE  );
      allowComponent( 333, FALSE  );
      allowComponent( 800, FALSE  );
      allowComponent( 801, FALSE  );
      allowComponent( 802, FALSE  );
      allowComponent( 810, FALSE  );
      allowComponent( 811, FALSE  );
      allowComponent( 812, FALSE  );
      allowComponent( 813, FALSE  );
      allowComponent( 825, FALSE  );
      allowComponent( 860, FALSE  );
      allowComponent( 875, FALSE  );
      allowComponent( 880, FALSE  );
      allowComponent( 900, FALSE  );
      allowComponent( 910, FALSE  );
      allowComponent( 912, FALSE  );
}


