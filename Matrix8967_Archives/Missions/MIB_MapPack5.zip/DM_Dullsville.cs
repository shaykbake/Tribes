// FILENAME:	DM_Dullsville.cs
//
// AUTHORS:  	Maj. Stormtrooper [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Dullsville";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
	marsSounds();
	$HercsAtDoor1 = 0;
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Dullsville! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %killed = getHudName(%destroyed);
   %killer = getHudName(%destroyer);
   say( 0, 0, "<F1>" @ %killer @ " killed " @ %killed @".");
}

function up::structure::onAttacked(%attacked, %attacker)
{
   %x = getPosition(%attacked, x);
   %y = getPosition(%attacked, y);
   %z = (getPosition(%attacked, z) * 2) - 15;
   setPosition(%attacker, %x, %y, %z);
}

function kill::trigger:onContact(%trigger, %vehicleId)
{
   damageArea(%trigger, 0, 0, -1, 15000, 0);
   damageArea(%trigger, 0, 0, -1, 15000, 0);
   healObject(%vehicleId, 50);
}

function door1::trigger::onEnter(%this, %vehicleId)
{
	if($hercsAtDoor1 == 0)
      {
		playAnimSequence(getObjectId("MissionGroup\\door"), 0, true);
		playAnimSequence(getObjectId("MissionGroup\\door4"), 0, true);
		playAnimSequence(getObjectId("MissionGroup\\door2"), 0, true);
		playAnimSequence(getObjectId("MissionGroup\\door3"), 0, true);
	}
	$hercsAtDoor1 = $hercsAtDoor1 + 1;
}

function door1::trigger::onLeave(%this, %vehicleId)
{
	$hercsAtDoor1 = $hercsAtDoor1 - 1;
	if($hercsAtDoor1 == 0)
      {
		playAnimSequence(getObjectId("MissionGroup\\door"), 0, false);
		playAnimSequence(getObjectId("MissionGroup\\door4"), 0, false);
		playAnimSequence(getObjectId("MissionGroup\\door2"), 0, false);
		playAnimSequence(getObjectId("MissionGroup\\door3"), 0, false);
	}
}

function vehicle::onscan(%scanned, %scanner)
{
   if((getHudName(%scanner) == "/<F1>Stormtrooper MIB"))
   {
	%x1 = getPosition(%scanned, x);
	%y1 = getPosition(%scanned, y);
	%nav = getVehicleNavMarkerId(%scanner);
	%x2 = getPosition(%nav, x);
	%y2 = getPosition(%nav, y);
	%distance = getDistance(%scanned, %nav);
	%increments = %distance / 10;
	%xDist = %x2 - %x1;
	%yDist = %y2 - %y1;
	%xOffset = %xDist / %increments;
	%yOffset = %yDist / %increments;
	repulse(%scanned, %xOffset, %yOffset, %increments);
   }
} 

function repulse(%vehicleId, %xOffset, %yOffset, %increments)
{
   if(%increments > 1)
   {
	%increments--;
	%x = getPosition(%vehicleId, x) + %xOffset;
	%y = getPosition(%vehicleId, y) + %yOffset;
	%z = getTerrainHeight(%x, %y);
	setPosition(%vehicleId, %x, %y, %z);
	schedule("repulse(" @ %vehicleId @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %increments @ ");", 0.1);
   }
}
