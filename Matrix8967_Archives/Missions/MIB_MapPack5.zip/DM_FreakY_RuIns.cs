// FILENAME:    DM_fREAKY_RUINS.cs
//
// AUTHOR:      Maj. Stormtrooper [M.I.B.]
//--------------------------------------------------------------------------------

$missionName = "DM_FreakY_RuIns";

exec("multiplayerStdLib.cs");
exec("dmStdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = False;
	$server::AllowDeathmatch = True;
	$server::AllowTeamPlay = True;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
      $on = randomInt(1,2);
	desertSounds();	
}

function onMissionLoad()
{
   cdAudioCycle("Newtech", "Mechsoul", "Terror"); 
}

//-------------------------------------------------------------
function player::onAdd(%this)
{
   say(%this, 0, "Welcome to FreakY RuIns! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function fix::trigger::onEnter(%this, %object)
{
   healObject(%object, 100000);
}

function thirsty::structure::onAttacked(%attacked, %attacker)
{
   setPosition(%attacker, 2434.25, 8563.5, 131.199);
}

function go::trigger::onEnter(%this, %object)
{
   if($on = 1)
   {
	setPosition(%object, -900.581, 930.775, 78.1999);
   }
   else if($on = 2)
   {
     setPosition(%object, -381.911, 729.435, 159.91);
   }
}

function toggle::structure::onAttacked(%attacked, %attacker)
{
   setPosition(%attacker, -114, 732.5, 911);
}

function toggle::structure::onScan(%attacked, %attacker)
{
   %num = randomInt(-2500, 50000);
   healObject(%attacker, %num);
}
