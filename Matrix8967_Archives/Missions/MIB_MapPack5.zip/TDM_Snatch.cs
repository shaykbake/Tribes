// FILENAME:	TDM_Snatch.cs
//
// AUTHOR:  	Maj. Stormtrooper [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "TDM_Snatch";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$server::HudMapViewOffsetX = -1400;
$server::HudMapViewOffsetY = 2400;

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
      $killPoints = 5;
      $deathPoints = 3;
	$capit = off;
	$turballoon = getObjectId( "MissionGroup\\turball" );
	earthquakeSounds();
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to TDM_Snatch!! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   messageBox(%player, "The central turret is at the nav point, we've gotta snatch it!");
}
	
function onMissionLoad()
{
   cdAudioCycle("Gnash", "Cloudburst", "Cyberntx"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Team Death Match!\n\n<F2>MISSION:<F0>  TDM_Snatch\n\nTake note that kills are worth <F3>5<F0> points and deaths are worth <F3>-3<F0>.");
}

//special safety thingie
function take::trigger::OnEnter(%this, %vehicleId)
{
	setTeam("MissionGroup\\turball", *IDSTR_TEAM_NEUTRAL);
	order("MissionGroup\\turball", Shutdown, true);
	setTeam("MissionGroup\\nav", *IDSTR_TEAM_NEUTRAL);
	say(0, 1, "<F1>The turret is currently <F4>neutral<F5> !");	
}

//snatch thingie [, change turball (and trigger) to whatever u name yours]
function take::trigger::OnLeave(%this, %vehicleId)
{
	%team = getTeam(%vehicleId);
   	setTeam($turballoon, %team);
	order("$turballoon", Shutdown, false);
	setTeam("MissionGroup\\nav", %team);
	say(0, 1, "<F5>" @ %team @ " has the center!");
}
