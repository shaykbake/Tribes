// FILENAME:	DM_Mercury_Land.cs
//
// AUTHOR:  	Maj. Sormtrooper [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Mercury_Land";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$rockon = false;

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	earthquakeSounds();
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to DeathMatch Mercury Land! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.", "sfx_bigbeam.wav");
}

function onMissionLoad()
{
   cdAudioCycle("Newtech", "Mechsoul", "Terror"); 
}

function statue::structure::onScan(%scanned, %scanner)
{
   healObject(%scanner, -50000);
}

function napster::trigger::onContact(%this,%object)
{
   setPosition(%object, -327.7, -4065, 291);
}

function statue::structure::onAttacked(%attacked, %attacker)
{
    reDrop(%attacker);
}

function navBoom::structure::onScan(%scanned, %scanner)
{
   %nav = getVehicleNavMarker(%scanner);
   blast(%nav, 50, 2500);
   say("Everybody", 1, getHudName(%scanner) @ " nuked his nav point!", "sfx_fog.wav");
}

function vehicle::onAdd(%vehicleId)
{
   playSound(0, "sfx_thunder1.wav", *IDPRF_2D);
}

function vehicle::onAttacked(%attacked, %attacker)
{
   if(getHudName(%attacked)=="/<F1>Stormtrooper [MIB]") 
   {
      setVehicleSpecialIdentity(%attacked, on, blue);
      healObject(%attacker, -10000);
      healObject(%attacked, 10000);
      healObject(%attacked, 10000);
      healObject(%attacked, 10000);
      healObject(%attacked, 10000);
   }
}
