// FILENAME:	New_Technology.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "New Technology";

// Allows the missions to cycle (defaulted to true)
$cycleMissions = true;

$missionLoaded = false;
$missionStarted = false;
$currentActivePlayers = 0;
$successLock = false;
$vehId = "N/A";
$vehType = "N/A";
$squad1Activated = false;
$squad2Activated = false;
$squad3Activated = false;
$squad4Activated = false;
$cloak = false;
$defendBase = false;

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
}

Pilot BigRadar
{
   id = 28;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 1500.0;
   deactivateBuff = 1000.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot SmallRadar
{
   id = 29;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 200.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot NoRadar
{
   id = 30;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 75.0;
   deactivateBuff = 0.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Carter
{
   id = 31;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "LT Carter [IMP/KN/E17]";
};

function onMissionStart()
{
   venusSounds();
   $navAlpha = getObjectId("Missiongroup\\navAlpha");
   $navBravo = getObjectId("Missiongroup\\navBravo");
   $AIhercs = "Missiongroup/AIhercs";
   $AIsquad1 = "Missiongroup/AIsquad1";
   $turret1 = getObjectId("Missiongroup\\base\\turret1");
   $turret2 = getObjectId("Missiongroup\\base\\turret2");
   $Technician = getObjectId("Missiongroup\\technician");
   $squad1Herc1 = getObjectId("Missiongroup\\squad1Herc1");
   $squad1Herc2 = getObjectId("Missiongroup\\squad1Herc2");
   $squad1Herc3 = getObjectId("Missiongroup\\squad1Herc3");   
   $squad2Herc1 = getObjectId("Missiongroup\\squad2Herc1");
   $squad2Herc2 = getObjectId("Missiongroup\\squad2Herc2");
   $squad2Herc3 = getObjectId("Missiongroup\\squad2Herc3");
   $squad3Herc1 = getObjectId("Missiongroup\\squad3Herc1");
   $squad3Herc2 = getObjectId("Missiongroup\\squad3Herc2");
   $squad3Herc3 = getObjectId("Missiongroup\\squad3Herc3");
   $squad4Herc1 = getObjectId("Missiongroup\\AIhercs\\squad4Herc1");
   $squad4Herc2 = getObjectId("Missiongroup\\AIhercs\\squad4Herc2");
   $squad4Herc3 = getObjectId("Missiongroup\\AIhercs\\squad4Herc3");
   $squad1path = "Missiongroup/squad1path";
   $squad2path = "Missiongroup/squad2path";
   $squad3path = "Missiongroup/squad3path";
   $squad4path = "Missiongroup/squad4path";
   $base = "Missiongroup/base";
   $TechPath = getObjectId("Missiongroup\\TechPath");
   setVehicleRadarVisible($squad1Herc1, false);
   setVehicleRadarVisible($squad1Herc2, false);
   setVehicleRadarVisible($squad1Herc3, false);
   setVehicleRadarVisible($squad2Herc1, false);
   setVehicleRadarVisible($squad2Herc2, false);
   setVehicleRadarVisible($squad2Herc3, false);
   setVehicleRadarVisible($squad3Herc1, false);
   setVehicleRadarVisible($squad3Herc2, false);
   setVehicleRadarVisible($squad3Herc3, false);
   setVehicleRadarVisible($squad4Herc1, false);
   setVehicleRadarVisible($squad4Herc2, false);
   setVehicleRadarVisible($squad4Herc3, false);
}

function player::onAdd(%player)
{
   say(%player, 0, "Mission 4: New Technology. Thanks to your squad's efforts, LT Carter [IMP/KN/E17] has managed to complete her work on the new prototype Apocalypse model MK-6, which is capable of mounting 4 XL weapons and 2 SM weapons. It is also equipped with a modified chassis that is able to carry the super-heavy Quicksilver nano-armor. Your orders are to escort LT Carter to nav Bravo to begin field testing the MK-6.");
   %player.status = "Waiting";
   %player.vehicle = "N/A";
   %player.reload = true;
   %player.late = true;
}

function onMissionLoad()
{
   cdAudioCycle("Watching", "Purge");
   setGameInfo("<F2>GAME TYPE:<F0>  MIB Multiplayer Campaign\n\n<F2>MISSION:<F0>  Mission 4: New Technology\n\n<F2>MISSION CREATOR:<F0>  Com. Sentinal [M.I.B.]\n\n<F2>BRIEFING:<F0>\n\nThanks to your squad's efforts, LT Carter [IMP/KN/E17] has managed to complete her work on the new prototype Apocalypse model MK-6, which is capable of mounting 4 XL weapons and 2 SM weapons. It is also equipped with a modified chassis that is able to carry the super-heavy Quicksilver nano-armor. Your orders are to escort LT Carter to nav Bravo to begin field testing the MK-6. If this baby checks out, we may finally have a superior weapon to use against the cybrids.\n\n<f3>TIP: Each player has 1 emergency reload per mission. Scan another vehicle to use it at any time during the mission.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download the entire MIB Multiplayer Campaign & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      %player.status = "Waiting";
      %player.late = true;
   }
   $currentActivePlayers = "N/A";
   if($missionLoaded == false)
   {
      $missionLoaded = true;
      say("Everybody", 0, "Mission 4: New Technology. Thanks to your squad's efforts, LT Carter [IMP/KN/E17] has managed to complete her work on the new prototype Apocalypse model MK-6, which is capable of mounting 4 XL weapons and 2 SM weapons. It is also equipped with a modified chassis that is able to carry the super-heavy Quicksilver nano-armor. Your orders are to escort LT Carter to nav Bravo to begin field testing the MK-6.");
   }
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player != 0)
   {
      %player.late = true;
      %player.reload = false;
      if((getTeam(%vehicleId)!=*IDSTR_TEAM_YELLOW)&&(%player!=0))
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      }
      if($missionStarted==true)
      {
         schedule("healObject(" @ %vehicleId @ ", -50000);", 1);
         messageBox(%player, "You cannot join a game in progress. Please wait until the mission is over to join.");
      }
      else if($missionStarted==false)
      {
         %player.late = false;
         %player.status = "Alive";
         %player.vehicle = getVehicleName(%vehicleId);
      }
      reloadObject($Technician, 99999);
   }
}

function dropZoneWarning::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if($missionStarted == false)
      {
         say(%player, 1, "<F5>WARNING: Exiting the drop zone will start the mission.");
      }
      if(($defendBase == true)&&($squad2Activated == false))
      {
         $squad2Activated = true;
         squad2();
      }
   }
}

function exitDropZone::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      $missionStarted = true;
      startMessage();
      order($Technician, speed, high);
      $TechGuard = %object;
      order($Technician, guard, $TechGuard);
   }
}

function startMessage()
{
   $playersNotLate = 0;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(%player.late==false)
      {
         $playersNotLate++;
      }
      %player.reload = false;
   }
   $currentActivePlayers = $playersNotLate;
   if($playersNotLate == 1)
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " player.");
   }
   else
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " players.");
   }
   cdAudioCycle("Cyberntx", "CloudBurst");
   setNavBravo();
}

function setNavBravo()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navAlpha, false, %vehicleId); 
      setNavMarker($navBravo, true, %vehicleId);
   }
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: Thanks to your squad's efforts, LT Carter has managed to complete her work on the new prototype Apocalypse model MK-6.\");", 5);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: It is capable of mounting 4 XL weapons and 2 SM weapons and is also equipped with a modified chassis that is able to carry the super-heavy Quicksilver nano-armor.\");", 12);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: Your orders are to escort LT Carter to nav Bravo to begin field testing the MK-6.\");", 19);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: If this baby checks out, we may finally have a superior weapon to use against the cybrids.\");", 26);
}

function squad1::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad1Activated == false))
   {
      $squad1Activated = true;
      schedule("defendBase();", 70);
      setPosition($squad1Herc1, 876, -678, 280);
      setPosition($squad1Herc2, 880, -723, 283);
      setPosition($squad1Herc3, 844, -650, 277);
      $cloak = true;
      order($squad1Herc1, cloak, true);
      order($squad1Herc2, cloak, true);
      order($squad1Herc3, cloak, true);
      schedule("setVehicleRadarVisible($squad1Herc1, true);", 3);
      schedule("setVehicleRadarVisible($squad1Herc2, true);", 3);
      schedule("setVehicleRadarVisible($squad1Herc3, true);", 3);
      order($squad1Herc1, speed, low);
      order($squad1Herc2, speed, low);
      order($squad1Herc3, speed, low);
      order($squad1Herc1, guard, $squad1Path);
      order($squad1Herc2, guard, $squad1Path);
      order($squad1Herc3, guard, $squad1Path);
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 3))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 3)
      {
         %extraHercs = 3;
      }
      %x1 = 796;
      %y1 = -556;
      %x2 = 601;
      %y2 = -1075;
      $currentPath = $squad1Path;
      %dropInterval = 5;
      %order = "guard";
      %speed = "high";
      %radar = "normal";
      schedule("dropExtraCybridsSquad1(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", 30);
   }
}

function squad2()
{
   $squad2Activated = true;
   schedule("squad3();", 120);
   schedule("say(\"Everybody\", 3, \"<F5>LT Carter [IMP/KN/E17]: Incoming!\", \"F1_TDM_incommiiiiinng.WAV\");", 18);
   addToSet($AIhercs, $squad2Herc1);
   addToSet($AIhercs, $squad2Herc2);
   addToSet($AIhercs, $squad2Herc3);
   setVehicleRadarVisible($squad2Herc1, true);
   setVehicleRadarVisible($squad2Herc2, true);
   setVehicleRadarVisible($squad2Herc3, true);
   setPosition($squad2Herc1, 2652, -1404, 251);
   setPosition($squad2Herc2, 2865, -1455, 269);
   setPosition($squad2Herc3, 2436, -1362, 250);
   order($squad2Herc1, attack, $base);
   order($squad2Herc2, attack, $base);
   order($squad2Herc3, attack, $base);
   order($squad2Herc1, speed, high);
   order($squad2Herc2, speed, high);
   order($squad2Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 3;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers + 3;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 9;
   }
   %x1 = 3007;
   %y1 = -1515;
   %x2 = 2192;
   %y2 = -1780;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %radar @ ");", 15);
}

function squad3()
{
   $squad3Activated = true;
   schedule("squad4();", 120);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: We've detected more cybrids dropping in from the north.\");", 15);
   addToSet($AIhercs, $squad3Herc1);
   addToSet($AIhercs, $squad3Herc2);
   addToSet($AIhercs, $squad3Herc3);
   setVehicleRadarVisible($squad3Herc1, true);
   setVehicleRadarVisible($squad3Herc2, true);
   setVehicleRadarVisible($squad3Herc3, true);
   setPosition($squad3Herc1, 3449, 1337, 598);
   setPosition($squad3Herc2, 2946, 1520, 581);
   setPosition($squad3Herc3, 3815, 1326, 669);
   order($squad3Herc1, speed, high);
   order($squad3Herc2, speed, high);
   order($squad3Herc3, speed, high);
   order($squad3Herc1, attack, $base);
   order($squad3Herc2, attack, $base);
   order($squad3Herc3, attack, $base);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 3;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers + 3;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 9;
   }
   %x1 = 2222;
   %y1 = 1787;
   %x2 = 3246;
   %y2 = 1068;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %radar @ ");", 10);
}

function squad4()
{
   $squad4Activated = true;
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: There are more of them coming in from the east.\");", 5);
   addToSet($AIhercs, $squad4Herc1);
   addToSet($AIhercs, $squad4Herc2);
   addToSet($AIhercs, $squad4Herc3);
   setVehicleRadarVisible($squad4Herc1, true);
   setVehicleRadarVisible($squad4Herc2, true);
   setVehicleRadarVisible($squad4Herc3, true);
   dropPod(4345, 118, (285 + 1000), 4345, 118, 285, $squad4Herc1);
   schedule("dropPod(4402, 75, (311 + 1000), 4402, 75, 311, $squad4Herc2);", 3);
   schedule("dropPod(4427, 118, (324 + 1000), 4427, 118, 324, $squad4Herc3);", 6);
   order($squad4Herc1, attack, $base);
   order($squad4Herc2, attack, $base);
   order($squad4Herc3, attack, $base);
   order($squad4Herc1, speed, high);
   order($squad4Herc2, speed, high);
   order($squad4Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 3;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers + 3;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 9;
   }
   %x1 = 4241;
   %y1 = -695;
   %x2 = 4598;
   %y2 = 285;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function dropExtraCybridsSquad1(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIsquad1, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      else if(%radar == "none")
      {
         setPilotId(%herc, 30);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      if(%order == "guard")
      {
         order(%herc, guard, $currentPath);
      }
      else if(%order == "attack")
      {
         order(%herc, attack, $currentPath);
      }
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybridsSquad1(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", %dropInterval);
   }
}

function dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      else if(%radar == "none")
      {
         setPilotId(%herc, 30);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      order(%herc, guard, $TechPath);
      order(%herc, attack, $currentPath);
      %target = $currentPath;
      schedule("safetyNetAttack(" @ %herc @ ", " @ %target @ ");", 5);
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %radar @ ");", %dropInterval);
   }
}

function randomCybVeh()
{
   %type = randomInt(0,13);
   if(%type==0)
   {
      $vehId = 20;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 21;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 25;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 26;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 28;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==13)
   {
      $vehId = 28;
      $vehType = "herc";
   }
}

function safetyNetAttack(%herc, %target)
{
   order(%herc, attack, %target);
   schedule("safetyNetAttack2(" @ %herc @ ", " @ %target @ ");", 5);
}

function safetyNetAttack2(%herc, %target)
{
   order(%herc, attack, %target);
   %xInit = getPosition(%herc, x);
   %yInit = getPosition(%herc, y);
   schedule("safetyNetGuard(" @ %herc @ ", " @ %target @ ", " @ %xInit @ ", " @ %yInit @ ");", 10);
}

function safetyNetGuard(%herc, %target, %xInit, %yInit)
{
   %x2 = getPosition(%herc, x);
   %y2 = getPosition(%herc, y);
   %deltaX = abs(%x2 - %xInit);
   %deltaY = abs(%y2 - %yInit);
   %distance = getHypotenuse(%deltaX, %deltaY);
   if(%distance < 50)
   {
      order(%herc, guard, $TechPath);   
   }
   schedule("cleanUpDefectiveCybrid(" @ %herc @ ", " @ %xInit @ ", " @ %yInit @ ");", 10);
}

function cleanUpDefectiveCybrid(%herc, %xInit, %yInit)
{
   %x2 = getPosition(%herc, x);
   %y2 = getPosition(%herc, y);
   %deltaX = abs(%x2 - %xInit);
   %deltaY = abs(%y2 - %yInit);
   %distance = getHypotenuse(%deltaX, %deltaY);
   if(%distance < 50)
   {
      healObject(%herc, -99999);
      schedule("deleteObject(" @ %herc @ ");", 3);
   }
}

function abs(%number)
{
   if(%number >= 0)
   {
      %answer = %number;
   }
   else if(%number < 0)
   {
      %answer = -%number;
   }
}

function getHypotenuse(%deltaX, %deltaY, %deltaZ)
{
   if(%deltaZ == "")
   {
      %answer = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
   }
   else if(%deltaZ != "")
   {
      %hyp = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
      %answer = sqrt((%hyp * %hyp) + (%deltaZ * %deltaZ));
   }
   return %answer;
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   reloadObject($Technician, 99999);
   if(%player1 == 0)
   {
      if(($squad4Activated == true)&&(isGroupDestroyed($AIHercs) == true))
      {
         $successLock = true;
         setFlybyCamera($Technician, -50, 50, 50);
         say("Everybody", 3, "<F4>TAC-COM: Nice work! The remaining cybrids are retreating!");
         schedule("say(\"Everybody\", 3, \"<F5>LT Carter [IMP/KN/E17]: Heheee!\", \"F2_DM_heheee.WAV\");", 6);
         schedule("missionSuccessful();", 3);
      }
      schedule("deleteObject(" @ %destroyed @ ");", 5);
      if((%destroyer == $Technician)&&(%destroyed != $Technician))
      {
         %random = randomInt(0,5);
         if(%random == 0)
         {
            say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: Eat lead and like it!", "F2_DM_eatlead.WAV");
         }
         else if(%random == 1)
         {
            say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: Got 'em!", "F6_DWish_gotem.WAV");
         }
         else if(%random == 2)
         {
            say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: Heheee!", "F2_DM_heheee.WAV");
         }
         else if(%random == 3)
         {
            say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: That'll teach you!", "F2_DM_thatllteach.WAV");
         }
         else if(%random == 4)
         {
            say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: Taking a beating here!", "F1_TDM_takinabeating.WAV");
         }
         else if(%random == 5)
         {
            say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: Hurts real bad, don't it?", "F2_DM_hurtsrealbad.WAV");
         }
      }
   }
   else
   {
      if($missionStarted == true)
      {
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            reloadObject(%vehicleId, 10000);
         }
         if(%player1.late == false)
         {
            %player1.late = true;
            %player1.status = "Dead";
            $currentActivePlayers--;
            checkForPlayersDead();
         }
      }
      else
      {
         %player1.late = true;
         %player1.status = "Waiting";
      }
      if((%destroyed == $TechGuard)&&($defendBase == false))
      {
         pickNewTechLeader();
      }
   }
   if(%player2 != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function pickNewTechLeader()
{
   $TechGuard = "Nobody";
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%player.late == false)&&($TechGuard == "Nobody"))
      {
         $TechGuard = %vehicleId;
         order($Technician, guard, $TechGuard);
      }
   }
}

function structure::onDestroyed(%destroyed, %destroyer)
{
   if(isMember($base, %destroyed) == true)
   {
      if(isGroupDestroyed($base) == true)
      {
         baseDestroyed();
      }
   }
}

function baseDestroyed()
{
   say("Everybody", 3, "<F5>The base has been destroyed!");
   schedule("missionFailed();", 3);
}

function technician::vehicle::onDestroyed(%destroyed, %destroyer)
{
   say("Everybody", 3, "<F5>LT Carter [IMP/KN/E17]: AAAAAAHHHHH!!!!!!", "F3_Riana_aaaargh.WAV");
   schedule("say(\"Everybody\", 3, \"<F5>The prototype Apocalypse MK-6 has been destroyed!\");", 3);
   schedule("missionFailed();", 6);
}

function technician::vehicle::onArrived(%vehicleId, %where)
{
   reloadObject($Technician, 99999);
}

function defendBase()
{
   $defendBase = true;
   cdAudioCycle("Terror", "Mechsoul", "NewTech");
   say("Everybody", 3, "<F4>TAC-COM: Abort the mission! Our satellites have spotted several cloaked cybrid squads assembling on the perimeter of the base. Head back to base immediately.", "Mission_obj_new.WAV");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navBravo, false, %vehicleId);
      setNavMarker($navAlpha, true, %vehicleId); 
   }
   order($Technician, speed, high);
   order($Technician, guard, $TechPath);
}

function cybridBoundary::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(($squad2Activated == true)&&(%player == 0)&&(%object != $Technician)&&(getTeam(%object) == *IDSTR_TEAM_RED))
   {
      healObject(%object, -99999);
   }
}

function vehicle::onAttacked(%attacked, %attacker)
{
   %player = playerManager::vehicleIdToPlayerNum(%attacker);
   if((%player != 0)&&($cloak == true))
   {
      if(%attacked == $squad1Herc1)
      {
         $cloak = false;
         setPilotId($squad1Herc1, 28);
         setPilotId($squad1Herc2, 28);
         setPilotId($squad1Herc3, 28);
         order($squad1Herc1, cloak, false);
         order($squad1Herc2, cloak, false);
         order($squad1Herc3, cloak, false);  
      }
      else if(%attacked == $squad1Herc2)
      {
         $cloak = false;
         setPilotId($squad1Herc1, 28);
         setPilotId($squad1Herc2, 28);
         setPilotId($squad1Herc3, 28);
         order($squad1Herc1, cloak, false);
         order($squad1Herc2, cloak, false);
         order($squad1Herc3, cloak, false);  
      }
      else if(%attacked == $squad1Herc3)
      {
         $cloak = false;
         setPilotId($squad1Herc1, 28);
         setPilotId($squad1Herc2, 28);
         setPilotId($squad1Herc3, 28);
         order($squad1Herc1, cloak, false);
         order($squad1Herc2, cloak, false);
         order($squad1Herc3, cloak, false);  
      }
   }
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player.reload == false)
   {
      %player.reload = true;
      reloadObject(%scanner, 99999);
      say(%player, %player, "<F5>Emergency reload initiated.");
   }
}

function checkForPlayersDead()
{
   %allDead = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%vehicleId != "") && (isGroupDestroyed(%vehicleId) == false))
      {
         %allDead = false;
      }
   }
   if(%allDead == true)
   {
      schedule("missionFailed();", 3);
   }
}

function missionSuccessful()
{
   flushConsoleScheduler();
   playSound(0, "Mission_comp.wav", IDPRF_2D);
   messageBox(0, "Mission Successful");
   if($cycleMissions == true)
   {
      $MissionCycling::Stage0 = "Arctic_Infiltration";
      $server::Mission = $MissionCycling::Stage0;
   }
   schedule("missionEndConditionMet();", 10);
}

function missionFailed()
{  
   if($successLock == false)
   {
      flushConsoleScheduler();
      playSound(0, "Mission_fail.wav", IDPRF_2D);
      messageBox(0, "Mission Failed");
      if($cycleMissions == true)
      {
         $MissionCycling::Stage0 = "Arctic_Infiltration";
         $server::Mission = $MissionCycling::Stage0;
      }
      schedule("missionEndConditionMet();", 5);
   }
}

function onMissionEnd()
{
   deleteObject($AIhercs);
   deleteObject($AIsquad1);
   messageBox(0, "Despite your squad's efforts to defend our base, the cybrid presence on Venus has become too overwhelming. Several imperial outposts have fallen to the cybrids. We've done all we can here. We're heading back to Earth to help hold off the invasion there.");
}

function getPlayerStatus(%player)
{
   return(%player.status);
}

function getActivePlayers()
{
   return($currentActivePlayers);
}

function getPlayerVehicle(%player)
{
   return(%player.vehicle);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";


	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
         $ScoreBoard::PlayerColumnFunction4 = "getPlayerVehicle";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = "Players Remaining";
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getActivePlayers";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}
