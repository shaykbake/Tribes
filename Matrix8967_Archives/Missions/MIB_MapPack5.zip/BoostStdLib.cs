//Beta Version
$pi = 3.1415;

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.turndelay = false;
}

function remoteBoostSwitch(%player)
{
   %object = playerManager::playerNumToVehicleId(%player);
   %object.cancel = false;
   %object.boost = true;
   boost(%object);
}

function remoteCancelswitch(%player)
{
   %object = playerManager::playerNumToVehicleId(%player);
   %object.boost = false;
   %object.hover = false;
   %object.cancel = true;
}

function remoteHoverSwitch(%player)
{
   %object = playerManager::playerNumToVehicleId(%player);
   %object.cancel = false;
   %object.boost = false;
   %object.hover = true;
   hover(%object);
}

function remoteForwardSwitch(%player)
{
   %object = playerManager::playerNumToVehicleId(%player);
   %object.boost = false;
   %object.hover = false;
   %object.cancel = true;
   forward(%object);
}

function remoteLeftTurnSwitch(%player)
{
   %object = playerManager::playerNumToVehicleId(%player);
   leftTurn(%object);
}

function remoteRightTurnSwitch(%player)
{
   %object = playerManager::playerNumToVehicleId(%player);
   rightTurn(%object);
}

function boost(%object)
{
   if(%object.cancel == true) return;
   else if(%object.boost == true)
   {
      %object.boostx = getposition(%object, x);
      %object.boosty = getposition(%object, y);
      %object.boostz = getposition(%object, z)+5;
      setposition(%object, %object.boostx, %object.boosty, %object.boostz);
      schedule("boost(" @ %object @ ");",0.1);
   }
}

function hover(%object)
{
   if(%object.cancel == true) return;
   else if(%object.hover == true)
   {
      %object.hoverx = getposition(%object, x);
      %object.hovery = getposition(%object, y);
      %object.hoverz = getposition(%object, z)+0.2;
      setposition(%object, %object.hoverx, %object.hovery, %object.hoverz);
      schedule("hover(" @ %object @ ");",0.1);
   }
}

function leftTurn(%object)
{
   if(%object.cancel == true) return;
   else if(%object.turndelay==false)
   {
      %object.turndelay = true;
      %Lrot=((getPosition(%object, rot)*360)/6.28);  //Convert Radians to Degrees
      %Lx=getPosition(%object, x);
      %Ly=getPosition(%object, y);
      %Lz=getPosition(%object, z);
      setposition(%object,%Lx,%Ly,%Lz,(%Lrot+1));
      schedule("setposition(" @ %object @ "," @ %Lx @ "," @ %Ly @ "," @ %Lz @ ",(" @ %Lrot @ "+2));",0.2);
      schedule("setposition(" @ %object @ "," @ %Lx @ "," @ %Ly @ "," @ %Lz @ ",(" @ %Lrot @ "+3));",0.4);
      schedule("setposition(" @ %object @ "," @ %Lx @ "," @ %Ly @ "," @ %Lz @ ",(" @ %Lrot @ "+4));",0.6);
      schedule("setposition(" @ %object @ "," @ %Lx @ "," @ %Ly @ "," @ %Lz @ ",(" @ %Lrot @ "+5));",0.8);
      schedule("resetTurnDelay(" @ %object @ ");", 1.0);
   }
}

function rightTurn(%object)
{
   if(%object.cancel == true) return;
   else if(%object.turndelay==false)
   {
      %object.turndelay = true;
      %Rrot=((getPosition(%object, rot)*360)/6.28);  //Convert Radians to Degrees
      %Rx=getPosition(%object, x);
      %Ry=getPosition(%object, y);
      %Rz=getPosition(%object, z);
      setposition(%object,%Rx,%Ry,%Rz,(%Rrot-1));
      schedule("setposition(" @ %object @ "," @ %Rx @ "," @ %Ry @ "," @ %Rz @ ",(" @ %Rrot @ "-2));",0.2);
      schedule("setposition(" @ %object @ "," @ %Rx @ "," @ %Ry @ "," @ %Rz @ ",(" @ %Rrot @ "-3));",0.4);
      schedule("setposition(" @ %object @ "," @ %Rx @ "," @ %Ry @ "," @ %Rz @ ",(" @ %Rrot @ "-4));",0.6);
      schedule("setposition(" @ %object @ "," @ %Rx @ "," @ %Ry @ "," @ %Rz @ ",(" @ %Rrot @ "-5));",0.8);
      schedule("resetTurnDelay(" @ %object @ ");", 1.0);
   }
}

function resetTurnDelay(%object)
{
   %object.turndelay = false;
}

//this was a very interesting problem.
//I dont know if this will help to visuallize but it helped me
//The conversion of degrees to radians is fine but I could see it better if i left
//the circle as radians. or rather portions of pi.  i included a diagram to show how i divied up
//the circle into 8 parts.  you may want to further subdivide using the same technique
//or you might want to stick with degrees if you can better envision that system.
//also since i didnt want to deal with that damn negative offset for numbers on the left
//half of the circle i just made it positive but made the increment negative...dare i say genius.
//now, each two parts accounts for one of the cardinal directions [1 and 8 are north (x),
//2 and 3 are east (y) and so on).

function forward(%object)
{
	//its not any faster to compute x,y,and z here
	//but i think it makes the script LOOK cleaner
	%fwx = getPosition(%object, x);
	%fwy = getPosition(%object, y);
	%fwz = getPosition(%object, z);

	%yincrement = 10;

   	%fwrot = getPosition(%object, rot);
	if(%fwrot < 0 )
	{
		%fwrot = -1* %fwrot;  //is there an abs()?
		%xincrement = 10;
	}
	else %xincrement = -10;
	
	//i prefer say to echo when debugging ;-)
	//say(0,1,"debug: rot= "@%fwrot);

	//i already initialized $pi as a globlal = 3.14;
   if((%fwrot>= 0 )&&(%fwrot<$pi/4))  //octet1 - 0 to .78
      %fwy+=%yincrement;
 
   else if((%fwrot>=$pi/4)&&(%fwrot<$pi*2/4)) //octet2  .78 to 1.57
      %fwx+=%xincrement;
   
   else if((%fwrot>=$pi*2/4)&&(%fwrot<$pi*3/4)) //octet3   1.57 thru 2.35
      %fwx+=%xincrement;	//same calculation as  octet 2

   else if((%fwrot>=$pi*3/4)&&(%fwrot<$pi))	//octet 4   2.35 to 3.14
		%fwy-=%yincrement;

	//i didnt notice any debugging stuff in you script
	//did you just clean it out for me or do you not use it
	//you might find it helpful.  i wouldve prefered it be left in
	//say(0,1,"debug: x= "@%fwx@" y= "@%fwy);
	
			   
   //setposition(%object,%fwx,%fwy,%fwz,%fwrot);  cant do rotation
   setposition(%object,%fwx,%fwy,%fwz);
      
   //else	  //i dont know what this does
   //{
   //   checkrotation(%object);
   //}
}


function Oldforward(%object)
{
   %fwrot=((getPosition(%object, rot)*360)/6.28); //Convert Radians to Degrees
   if((%fwrot>=-7.5)&&(%fwrot<7.5))
   {
      %fwx=getposition(%object,x)+10;
      %fwy=getposition(%object,y);
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=7.5)&&(%fwrot<22.5))
   {
      %fwx=getposition(%object,x)+10;
      %fwy=getposition(%object,y)+2.67;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   } 
   else if((%fwrot>=22.5)&&(%fwrot<37.5))
   {
      %fwx=getposition(%object,x)+8.65;
      %fwy=getposition(%object,y)+5;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=37.5)&&(%fwrot<52.5))
   {
      %fwx=getposition(%object,x)+7;
      %fwy=getposition(%object,y)+7;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=52.5)&&(%fwrot<67.5))
   {
      %fwx=getposition(%object,x)+5;
      %fwy=getposition(%object,y)+8.65;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=67.5)&&(%fwrot<82.5))
   {
      %fwx=getposition(%object,x)+2.67;
      %fwy=getposition(%object,y)+10;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=82.5)&&(%fwrot<97.5))
   {
      %fwx=getposition(%object,x);
      %fwy=getposition(%object,y)+10;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=97.5)&&(%fwrot<112.5))
   {
      %fwx=getposition(%object,x)-2.67;
      %fwy=getposition(%object,y)+10;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=112.5)&&(%fwrot<127.5))
   {
      %fwx=getposition(%object,x)-5;
      %fwy=getposition(%object,y)+8.65;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=127.5)&&(%fwrot<142.5))
   {
      %fwx=getposition(%object,x)-7;
      %fwy=getposition(%object,y)+7;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=142.5)&&(%fwrot<157.5))
   {
      %fwx=getposition(%object,x)-8.65;
      %fwy=getposition(%object,y)+5;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=157.5)&&(%fwrot<172.5))
   {
      %fwx=getposition(%object,x)-10;
      %fwy=getposition(%object,y)+2.67;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=172.5)&&(%fwrot<-172.5))
   {
      %fwx=getposition(%object,x)-10;
      %fwy=getposition(%object,y);
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-172.5)&&(%fwrot<-157.5))
   {
      %fwx=getposition(%object,x)+10;
      %fwy=getposition(%object,y)-2.67;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-157.5)&&(%fwrot<-142.5))
   {
      %fwx=getposition(%object,x)+8.65;
      %fwy=getposition(%object,y)-5;
      %fwz=getposition(%object,z);
      setposition(%v,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-142.5)&&(%fwrot<-127.5))
   {
      %fwx=getposition(%object,x)+7;
      %fwy=getposition(%object,y)-7;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-127.5)&&(%fwrot<-112.5))
   {
      %fwx=getposition(%object,x)+5;
      %fwy=getposition(%object,y)-8.65;
      %fwz=getposition(%object,z);
      setposition(%scanner,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-112.5)&&(%fwrot<-97.5))
   {
      %fwx=getposition(%object,x)+2.67;
      %fwy=getposition(%object,y)-10;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-97.5)&&(%fwrot<-82.5))
   {
      %fwx=getposition(%object,x);
      %fwy=getposition(%object,y)-10;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else
   {
      checkrotation(%object);
   }
}

function checkrotation(%object)
{
   %fwrot=getPosition(%object, rot);
   if((%fwrot>=-82.5)&&(%fwrot<-67.5))
   {
      %fwx=getposition(%object,x)-2.67;
      %fwy=getposition(%object,y)-10;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-67.5)&&(%fwrot<-52.5))
   {
      %fwx=getposition(%object,x)-5;
      %fwy=getposition(%object,y)-8.65;
      %fwz=getposition(%object,z);
      setposition(%scanner,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-52.5)&&(%fwrot<-37.5))
   {
      %fwx=getposition(%object,x)-7;
      %fwy=getposition(%object,y)-7;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-37.5)&&(%fwrot<-22.5))
   {
      %fwx=getposition(%object,x)-8.65;
      %fwy=getposition(%object,y)-5;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
   else if((%fwrot>=-22.5)&&(%fwrot<-7.5))
   {
      %fwx=getposition(%object,x)-10;
      %fwy=getposition(%object,y)-2.67;
      %fwz=getposition(%object,z);
      setposition(%object,%fwx,%fwy,%fwz,%fwrot);
   }   
}
