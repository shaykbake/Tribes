// FILENAME:	Covert_Strike.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Covert Strike";

// Allows the missions to cycle (defaulted to true)
$cycleMissions = true;

$missionLoaded = false;
$missionStarted = false;
$currentActivePlayers = 0;
$baseDestroyed = false;
$dropShip = false;
$firstTarget = false;
$playersBackAtBase = 0;
$successLock = false;
$vehId = "N/A";
$vehType = "N/A";
$squad2Activated = false;
$squad4Activated = false;

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
}

Pilot BigRadar
{
   id = 28;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 1500.0;
   deactivateBuff = 1000.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot SmallRadar
{
   id = 29;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 200.0;
   deactivateBuff = 800.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Hunter
{
   id = 30;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "MAJ Hunter [IMP/KN/G14]";
};

Pilot Smith
{
   id = 31;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "LT Smith [IMP/KN/G14]";
};

Pilot Riggs
{
   id = 32;
   skill = 0.8;
   accuracy = 0.8;
   aggressiveness = 0.9;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "LT Riggs [IMP/KN/G14]";
};

Pilot Harris
{
   id = 33;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.7;
   activateDist = 500.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "CPT Harris [IMP/KN/G14]";
};

function onMissionStart()
{
   marsSounds();
   $navAlpha = getObjectId("Missiongroup\\navAlpha");
   $navDelta = getObjectId("Missiongroup\\navDelta");
   $navOmega = getObjectId("Missiongroup\\navOmega");
   $navBravo = getObjectId("Missiongroup\\navBravo");
   $AIhercs = "Missiongroup/AIhercs";
   $base = "Missiongroup/base";
   $squad1Herc1 = getObjectId("Missiongroup\\squad1Herc1");
   $squad1Herc2 = getObjectId("Missiongroup\\squad1Herc2");
   $squad1Herc3 = getObjectId("Missiongroup\\squad1Herc3");   
   $squad2Herc1 = getObjectId("Missiongroup\\squad2Herc1");
   $squad2Herc2 = getObjectId("Missiongroup\\squad2Herc2");
   $squad2Herc3 = getObjectId("Missiongroup\\squad2Herc3");
   $squad3Herc1 = getObjectId("Missiongroup\\squad3Herc1");
   $squad3Herc2 = getObjectId("Missiongroup\\squad3Herc2");
   $squad3Herc3 = getObjectId("Missiongroup\\squad3Herc3");
   $squad4Herc1 = getObjectId("Missiongroup\\squad4Herc1");
   $squad4Herc2 = getObjectId("Missiongroup\\squad4Herc2");
   $squad4Herc3 = getObjectId("Missiongroup\\squad4Herc3");
   $squad4Herc4 = getObjectId("Missiongroup\\squad4Herc4");
   $squad5Herc1 = getObjectId("Missiongroup\\squad5Herc1");
   $squad5Herc2 = getObjectId("Missiongroup\\squad5Herc2");
   $squad5Herc3 = getObjectId("Missiongroup\\squad5Herc3");
   $squad5Herc4 = getObjectId("Missiongroup\\squad5Herc4");
   $squad1path = "Missiongroup/squad1path";
   $squad2path = "Missiongroup/squad2path";
   $squad3path = "Missiongroup/squad3path";
   $squad4path = "Missiongroup/squad4path";
   $squad4path3 = getObjectId("Missiongroup\\squad4path\\squad4path3");
   $squad5path = "Missiongroup/squad5path";
   $squad6Path = "Missiongroup/squad6path";
   setVehicleRadarVisible($squad2Herc1, false);
   setVehicleRadarVisible($squad2Herc2, false);
   setVehicleRadarVisible($squad2Herc3, false);
   setVehicleRadarVisible($squad3Herc1, false);
   setVehicleRadarVisible($squad3Herc2, false);
   setVehicleRadarVisible($squad3Herc3, false);
   setVehicleRadarVisible($squad4Herc1, false);
   setVehicleRadarVisible($squad4Herc2, false);
   setVehicleRadarVisible($squad4Herc3, false);
   setVehicleRadarVisible($squad4Herc4, false);
   setVehicleRadarVisible($squad5Herc1, false);
   setVehicleRadarVisible($squad5Herc2, false);
   setVehicleRadarVisible($squad5Herc3, false);
   setVehicleRadarVisible($squad5Herc4, false);
}

function player::onAdd(%player)
{
   say(%player, 0, "Mission 2: Covert Strike. Intelligence has confirmed the location of the hidden imperial base. Your orders are to proceed to nav Delta and destroy this base and any hostile resistance you may encounter. Your squad must strike quickly under the cover of darkness to maintain stealth. The imperials are not expecting an attack, so they'll never know what hit 'em.");
   %player.status = "Waiting";
   %player.vehicle = "N/A";
   %player.reload = true;
   %player.late = true;
}

function onMissionLoad()
{
   cdAudioCycle("Watching", "Purge", "Cyberntx");
   setGameInfo("<F2>GAME TYPE:<F0>  MIB Multiplayer Campaign\n\n<F2>MISSION:<F0>  Mission 2: Covert Strike\n\n<F2>MISSION CREATOR:<F0>  Com. Sentinal [M.I.B.]\n\n<F2>BRIEFING:<F0>\n\nIntelligence has confirmed the location of the hidden imperial base. Your orders are to proceed to nav Delta and destroy this base and any hostile resistance you may encounter. Your squad must strike quickly under the cover of darkness to maintain stealth. The imperials are not expecting an attack, so they'll never know what hit 'em.\n\n<F3>TIP: Each player has 1 emergency reload per mission. Scan another vehicle to use it at any time during the mission.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download the entire MIB Multiplayer Campaign & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      %player.status = "Waiting";
      %player.late = true;
   }
   $currentActivePlayers = "N/A";
   if($missionLoaded == false)
   {
      $missionLoaded = true;
      say("Everybody", 0, "Mission 2: Covert Strike. Intelligence has confirmed the location of the hidden imperial base. Your orders are to proceed to nav Delta and destroy this base and any hostile resistance you may encounter. Your squad must strike quickly under the cover of darkness to maintain stealth. The imperials are not expecting an attack, so they'll never know what hit 'em.");
   }
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player != 0)
   {
      %player.late = true;
      %player.reload = false;
      if((getTeam(%vehicleId)!=*IDSTR_TEAM_YELLOW)&&(%player!=0))
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      }
      if($missionStarted==true)
      {
         schedule("healObject(" @ %vehicleId @ ", -50000);", 1);
         messageBox(%player, "You cannot join a game in progress. Please wait until the mission is over to join.");
      }
      else if($missionStarted==false)
      {
         %player.late = false;
         %player.status = "Alive";
         %player.vehicle = getVehicleName(%vehicleId);
      }
      %vehicleId.backAtBase = false;
   }
}

function dropZoneWarning::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      say(%player, 1, "<F5>WARNING: Exiting the drop zone will start the mission.");
   }
}

function dropShip::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($dropShip==true))
   {
      if(%object.backAtBase == false)
      {
         %object.backAtBase = true;
         $playersBackAtBase++;
         if($playersBackAtBase >= $currentActivePlayers)
         {
            if($successLock == false)
            {
               $successLock = true;
               setFlybyCamera(%object, -50, 50, 50);
               missionSuccessful();
            }
         }
      }
   }
}

function exitDropZone::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      $missionStarted = true;
      startMessage();
   }
}

function startMessage()
{
   $playersNotLate = 0;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(%player.late==false)
      {
         $playersNotLate++;
      }
      %player.reload = false;
   }
   $currentActivePlayers = $playersNotLate;
   if($playersNotLate == 1)
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " player.");
   }
   else
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " players.");
   }
   schedule("setNavDelta();",5);
}

function setNavDelta()
{
   squad1();
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navOmega, false, %vehicleId); 
      setNavMarker($navAlpha, false, %vehicleId); 
      setNavMarker($navBravo, false, %vehicleId);
      setNavMarker($navDelta, true, %vehicleId); 
   }
   say("Everybody", 2, "<F1>TAC-COM: Intelligence has confirmed the location of the hidden imperial base.");
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Your orders are to proceed to nav Delta and destroy this base and any hostile resistance you may encounter.\");", 5);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Your squad must strike quickly under the cover of darkness to maintain stealth.\");", 10);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: The imperials are not expecting an attack, so they'll never know what hit 'em.\");", 15);
}

function squad1()
{
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 6;
   }
   %x1 = -712;
   %y1 = -19;
   %x2 = 96;
   %y2 = 181;
   %dropInterval = 3;
   %speed = "high";
   %order = "none";
   %radar = "normal";
   dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar);  
}

function squad2::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad2Activated==false)&&($dropShip == true))
   {
      $squad2Activated = true;
      schedule("randomDropPods(-4168, 3006, -4639, -229, 25);", 15);
      setVehicleRadarVisible($squad2Herc1, true);
      setVehicleRadarVisible($squad2Herc2, true);
      setVehicleRadarVisible($squad2Herc3, true);
      dropPod(-2697, 1892, (35 + 1000), -2697, 1892, 35, $squad2Herc1);
      schedule("dropPod(-2795, 1885, (41 + 1000), -2795, 1885, 41, $squad2Herc2);", 3);
      schedule("dropPod(-2778, 1978, (38 + 1000), -2778, 1978, 38, $squad2Herc3);", 6);
      order($squad2Herc1, attack, %object);
      order($squad2Herc2, attack, %object);
      order($squad2Herc3, attack, %object);
      order($squad2Herc1, speed, high);
      order($squad2Herc2, speed, high);
      order($squad2Herc3, speed, high);
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 4))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 4)
      {
         %extraHercs = 4;
      }
      %x1 = -2339;
      %y1 = 2044;
      %x2 = -3368;
      %y2 = 2532;
      $currentPath = $squad2Path;
      %dropInterval = 5;
      %speed = "high";
      %order = "guard";
      %radar = "big";
      dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar);
   }
}

function squad3()
{
   cdAudioCycle("Mechsoul", "Terror", "NewTech");
   playSound(0, "cin_ca_01.wav", IDPRF_2D);
   schedule("screaming();",5);
   setVehicleRadarVisible($squad3Herc1, true);
   setVehicleRadarVisible($squad3Herc2, true);
   setVehicleRadarVisible($squad3Herc3, true);
   setPosition($squad3Herc1, -189, 2645, 167);
   setPosition($squad3Herc2, -160, 2672, 160);
   setPosition($squad3Herc3, -200, 2692, 157);
   order($squad3Herc1, speed, high);
   order($squad3Herc2, speed, high);
   order($squad3Herc1, attack, $squad4Herc1);
   order($squad3Herc2, attack, $squad4Herc2);
   order($squad3Herc3, attack, $squad4Herc3);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 7))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 7)
   {
      %extraHercs = 7;
   }
   %x1 = -1411;
   %y1 = 1922;
   %x2 = 853;
   %y2 = 2897;
   $currentPath = $squad3Path;
   %dropInterval = 5;
   %speed = "high";
   %order = "guard";
   %radar = "big";
   schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", 20);
}

function squad4::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad4Activated == false)&&($baseDestroyed == true))
   {
      $squad4Activated = true;
      setVehicleRadarVisible($squad4Herc1, true);
      setVehicleRadarVisible($squad4Herc2, true);
      setVehicleRadarVisible($squad4Herc3, true);
      setVehicleRadarVisible($squad4Herc4, true);
      order($squad4Herc1, holdfire, true);
      order($squad4Herc2, holdfire, true);
      order($squad4Herc3, holdfire, true);
      order($squad4Herc4, holdfire, true);
      order($squad4Herc1, guard, $squad4Path);
      order($squad4Herc2, guard, $squad4Path);
      order($squad4Herc3, guard, $squad4Path);
      order($squad4Herc4, guard, $squad4Path);
      order($squad4Herc1, speed, high);
      order($squad4Herc2, speed, high);
      order($squad4Herc3, speed, high);
      order($squad4Herc4, speed, high);
      squad3();
      schedule("squad5();", 60);
   }
}

function squad5()
{
   say("Everybody", 2, "<F1>MAJ Hunter [IMP/KN/G14]: This is squad Gamma-14 of the Imperial Knights. Rebels, we have your position and are on the way. ETA: 1 minute.");
   schedule("say(\"Everybody\", 2, \"<F1>MAJ Hunter [IMP/KN/G14]: And don't worry, we're on the same side now. This squad is locked & loaded, and ready to burn some 'brids!\");", 5);
   schedule("say(\"Everybody\", 2, \"<F1>MAJ Hunter [IMP/KN/G14]: Regroup on me!\", \"M3_TDM_regroupon.WAV\");", 15);
   schedule("say(\"Everybody\", 2, \"<F1>LT Smith [IMP/KN/G14]: Killin' time is upon us!\", \"M4_killintime.WAV\");", 17);
   schedule("say(\"Everybody\", 2, \"<F1>LT Riggs [IMP/KN/G14]: Aiyeehah!\", \"M8_Hunter_aiyeehah.WAV\");", 20);
   schedule("say(\"Everybody\", 2, \"<F1>MAJ Hunter [IMP/KN/G14]: Cover my six.\", \"M2_WAR_covermysix.WAV\");", 23);
   setVehicleRadarVisible($squad5Herc1, true);
   setVehicleRadarVisible($squad5Herc2, true);
   setVehicleRadarVisible($squad5Herc3, true);
   setVehicleRadarVisible($squad5Herc4, true);
   setPosition($squad5Herc1, 1152, 1287, 21);
   setPosition($squad5Herc2, 1179, 1308, 21);
   setPosition($squad5Herc3, 1178, 1267, 21);
   setPosition($squad5Herc4, 1201, 1288, 21);
   order($squad5Herc1, guard, $squad5Path);
   order($squad5Herc2, guard, $squad5Path);
   order($squad5Herc3, guard, $squad5Path);
   order($squad5Herc4, guard, $squad5Path);
   order($squad5Herc1, speed, high);
   order($squad5Herc2, speed, high);
   order($squad5Herc3, speed, high);
   order($squad5Herc4, speed, high);
   schedule("squad6();", 60);
}

function squad6()
{
   schedule("dropShip();", 60);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 3;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers + 3;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 9;
   }
   %x1 = -404;
   %y1 = 3046;
   %x2 = 986;
   %y2 = 2492;
   $currentPath = $squad6Path;
   %dropInterval = 5;
   %speed = "high";
   %order = "guard";
   %radar = "big";
   schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", 10);
}

function dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      randomTransport(%herc, %x1, %y1, %x2, %y2);
      if(%order == "guard")
      {
         order(%herc, guard, $currentPath);
      }
      else if(%order == "attack")
      {
         order(%herc, attack, $currentPath);
      }
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraHercs(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", %dropInterval);
   }
}

function dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      if(%order == "guard")
      {
         order(%herc, guard, $currentPath);
      }
      else if(%order == "attack")
      {
         order(%herc, attack, $currentPath);
      }
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", %dropInterval);
   }
}

function randomVeh()
{
   %type = randomInt(0,21);
   if(%type==0)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 2;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 3;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 4;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 5;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 6;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 7;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 10;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 11;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 12;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 13;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 14;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 15;
      $vehType = "tank";
   }
   else if(%type==13)
   {
      $vehId = 16;
      $vehType = "tank";
   }
   else if(%type==14)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==15)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==16)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==17)
   {
      $vehId = 3;
      $vehType = "herc";
   }
   else if(%type==18)
   {
      $vehId = 3;
      $vehType = "herc";
   }
   else if(%type==19)
   {
      $vehId = 10;
      $vehType = "herc";
   }
   else if(%type==20)
   {
      $vehId = 12;
      $vehType = "herc";
   }
   else if(%type==21)
   {
      $vehId = 5;
      $vehType = "herc";
   }
}

function randomCybVeh()
{
   %type = randomInt(0,13);
   if(%type==0)
   {
      $vehId = 20;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 21;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 25;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 26;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 28;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==13)
   {
      $vehId = 28;
      $vehType = "herc";
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   if(%player1 == 0)
   {
      if(%destroyed == $squad4Herc1)
      {
         order($squad3Herc1, guard, $squad3Path);
      }
      else if(%destroyed == $squad4Herc2)
      {
         order($squad3Herc2, guard, $squad3Path);
      }
      else if(%destroyed == $squad4Herc3)
      {
         order($squad3Herc3, guard, $squad3Path);
      }
      schedule("deleteObject(" @ %destroyed @ ");", 5);
   }
   else
   {
      if($missionStarted == true)
      {
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            reloadObject(%vehicleId, 10000);
         }
         if(%player1.late == false)
         {
            %player1.late = true;
            %player1.status = "Dead";
            $currentActivePlayers--;
            checkForPlayersDead();
            if(($playersBackAtBase >= $currentActivePlayers)&&($playersBackAtBase > 0))
            {
               missionSuccessful();
            }
         }
      }
      else
      {
         %player1.late = true;
         %player1.status = "Waiting";
      }
   }
   if(%player2 != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function vehicle::onTargeted(%targeted, %targeter)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%targeted);
   %player2 = playerManager::vehicleIdToPlayerNum(%targeter);
   if((%player1 != 0)&&(%player2 == 0)&&($firstTarget == false))
   {
      $firstTarget = true;
      if($currentActivePlayers == 1)
      {
         say("Everybody", 2, "<F5>IMPERIAL SENTRY: Sir, I've spotted a hostile bogey on the perimeter!", "gen_icca03.wav");   
      }
      else if($currentActivePlayers > 1)
      {
         say("Everybody", 2, "<F5>IMPERIAL SENTRY: Sir, I've spotted multiple bogies on the perimeter!", "gen_icca03.wav");
      }
      if($currentActivePlayers == 1)
      {
         %random = randomInt(1, 3);
         if(%random1 == 1)
         {
            order($squad1Herc1, guard, $squad1Path);
         }
         else if(%random1 == 2)
         {
            order($squad1Herc2, guard, $squad1Path);
         }
         else if(%random1 == 3)
         {
            order($squad1Herc3, guard, $squad1Path);
         }
      }
      else
      {
         order($squad1Herc1, guard, $squad1Path);
         order($squad1Herc2, guard, $squad1Path);
         order($squad1Herc3, guard, $squad1Path);
      }
   }
}

function structure::onDestroyed(%destroyed, %destroyer)
{
   if(isMember($base, %destroyed) == true)
   {
      if(isGroupDestroyed($base) == true)
      {
         baseDestroyed();
      }
   }
}

function knightsDropShip::vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum(%destroyer);
   if(isGroupDestroyed($base) == true)
   {
      baseDestroyed();
   }
   if(%player != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function squad4Herc1::vehicle::onArrived(%vehicleId, %where)
{
   if(%where == $squad4Path3)
   {
      schedule("deleteObject(" @ %vehicleId @ ");", 5);
   }
}

function squad4Herc2::vehicle::onArrived(%vehicleId, %where)
{
   if(%where == $squad4Path3)
   {
      schedule("deleteObject(" @ %vehicleId @ ");", 5);
   }
}

function squad4Herc3::vehicle::onArrived(%vehicleId, %where)
{
   if(%where == $squad4Path3)
   {
      schedule("deleteObject(" @ %vehicleId @ ");", 5);
   }
}

function squad4Herc4::vehicle::onArrived(%vehicleId, %where)
{
   if(%where == $squad4Path3)
   {
      schedule("deleteObject(" @ %vehicleId @ ");", 5);
   }
}

function baseDestroyed()
{  
   $baseDestroyed = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navAlpha, false, %vehicleId);
      setNavMarker($navDelta, false, %vehicleId);
      setNavMarker($navBravo, false, %vehicleId);
      setNavMarker($navOmega, true, %vehicleId);
   }
   say("Everybody", 2, "<F1>TAC-COM: We've detected the presence of a small imperial squad to the north of the base at nav Omega.", "mission_obj_new.wav");
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: I'm sending you to investigate the situation. Your squad has permission to engage the enemy if necessary.\");", 3);
}

function dropShip()
{  
   $dropShip = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navAlpha, false, %vehicleId);
      setNavMarker($navDelta, false, %vehicleId);
      setNavMarker($navOmega, false, %vehicleId);
      setNavMarker($navBravo, true, %vehicleId);
   }
   say("Everybody", 2, "<F1>TAC-COM: We've detected cybrids dropping in all over the planet. Head to nav Bravo immediately to board the dropship to Venus.", "mission_obj_new.WAV");
   randomDropPods(1661, 3369, -579, 3669, 25);
   schedule("cybridTaunt1();", 3);
   order($squad5Herc1, guard, $navBravo);
   order($squad5Herc2, guard, $navBravo);
   order($squad5Herc3, guard, $navBravo);
   order($squad5Herc4, guard, $navBravo);
}

function randomDropPods(%x1, %y1, %x2, %y2, %num)
{
   if(%num > 0)
   {
      %num--;
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z);
      schedule("randomDropPods(" @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %num @ ");", 3);
   }
}

function screaming()
{
   say("Everybody", 3, "<F5>IMPERIAL 1: INCOMING!!!", "M5_TDM_incoming.WAV");
   schedule("say(\"Everybody\", 3, \"<F5>IMPERIAL 2: AAAAHHHHHH!!!!\", \"F3_Riana_aaaargh.WAV\");", 2);
   schedule("say(\"Everybody\", 3, \"<F5>IMPERIAL 3: GET 'EM OFF OF ME!!!!\", \"M7_getemoffamee.WAV\");", 4);
   schedule("say(\"Everybody\", 3, \"<F5>IMPERIAL 4: THERE'S TOO MANY OF THEM!\", \"M0_TDM_therestoo.WAV\");", 7);
   schedule("say(\"Everybody\", 3, \"<F5>IMPERIAL 2: OH GOD! OH GOD! OH GOD!!!\", \"F8_G_ogod.WAV\");", 9);
   schedule("say(\"Everybody\", 3, \"<F5>IMPERIAL 2: I'M HIT! DAMN IT HURTS!!\", \"F6_DWish_imhit.WAV\");", 12);
   schedule("cybridTaunt1();", 14);
}

function cybridTaunt1()
{
   playSound(0, "C1_executecore.wav", IDPRF_2D);
   schedule("cybridTaunt2();", 2);
}

function cybridTaunt2()
{
   playSound(0, "C1_submitto.wav", IDPRF_2D);
   schedule("cybridTaunt3();", 3);
}

function cybridTaunt3()
{
   playSound(0, "C4_eliminateanimals.wav", IDPRF_2D);
   schedule("cybridTaunt4();", 3);
}

function cybridTaunt4()
{
   playSound(0, "C7_excellent.wav", IDPRF_2D);
   schedule("cybridTaunt5();", 3);
}

function cybridTaunt5()
{
   playSound(0, "C1_hurtmaimkill.wav", IDPRF_2D);
   schedule("cybridTaunt6();", 4);
}

function cybridTaunt6()
{
   playSound(0, "C3_eliminating.wav", IDPRF_2D);
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player.reload == false)
   {
      %player.reload = true;
      reloadObject(%scanner, 99999);
      say(%player, %player, "<F5>Emergency reload initiated.");
   }
}

function checkForPlayersDead()
{
   %allDead = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%vehicleId != "") && (isGroupDestroyed(%vehicleId) == false))
      {
         %allDead = false;
      }
   }
   if(%allDead == true)
   {
      schedule("missionFailed();", 3);
   }
}

function missionSuccessful()
{
   flushConsoleScheduler();
   playSound(0, "Mission_comp.wav", IDPRF_2D);
   messageBox(0, "Mission Successful");
   if($cycleMissions == true)
   {      
      $MissionCycling::Stage0 = "Rescue_Technician";
      $server::Mission = $MissionCycling::Stage0;
   }
   schedule("missionEndConditionMet();", 15);
}

function missionFailed()
{  
   if($successLock == false)
   {
      flushConsoleScheduler();
      playSound(0, "Mission_fail.wav", IDPRF_2D);
      messageBox(0, "Mission Failed");
      if($cycleMissions == true)
      {
         $MissionCycling::Stage0 = "Rescue_Technician";
         $server::Mission = $MissionCycling::Stage0;
      }
      schedule("missionEndConditionMet();", 5);
   }
}

function onMissionEnd()
{
   deleteObject($AIhercs);
}

function getPlayerStatus(%player)
{
   return(%player.status);
}

function getActivePlayers()
{
   return($currentActivePlayers);
}

function getPlayerVehicle(%player)
{
   return(%player.vehicle);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";


	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
         $ScoreBoard::PlayerColumnFunction4 = "getPlayerVehicle";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = "Players Remaining";
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getActivePlayers";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}
