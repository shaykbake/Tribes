// FILENAME:	ATR2_CTF_Stab_n_Grab.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "ATR2_CTF_Stab_n_Grab";

$maxFlagCount  = 5;        
$flagValue     = 5;        
$carrierValue  = 2;        
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 0;

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

$server::HudMapViewOffsetX = -6300;
$server::HudMapViewOffsetY = 2400;

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;

      $server::MassLimit = 0;
}

function onMissionStart()
{
	initGlobalVars();

      $healRate = 100;   
	$ammoRate = 3;
   	$padWaitTime = 0;
  	$zenWaitTime = 0;

	titanSounds();
}   

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to ATR2 CTF_Stab_n_Grab! This is as close to the SS Alpha Tech Release 2 as you're gonna get! You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

// Ammo Pad Functionality
//------------------------------------------------------------------------------
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}

function setDefaultMissionItems()
{
   allowVehicle(                                          all, FALSE  );
   allowVehicle(                                            2, TRUE  );  //Minotaur
   allowVehicle(                                           30, TRUE  );  //Emancipator
   allowVehicle(                                           21, TRUE  );  //Goad
   allowVehicle(                                            7, TRUE  );  //Myrmidon
   
   allowWeapon(                                           all, FALSE  );
   allowWeapon(                                           101, TRUE  );  //Laser
   allowWeapon(                                           105, TRUE  );  //EMP
   allowWeapon(                                           107, TRUE  );  //Blaster
   allowWeapon(                                           116, TRUE  );  //ATC
   allowWeapon(                                           119, TRUE  );  //Blast Cannon
   allowWeapon(                                           126, TRUE  );  //Sparrow Missile Pack 6
   allowWeapon(                                           127, TRUE  );  //Sparrow Missile Pack 10

   allowComponent(                                        all, TRUE  );
   allowComponent(                                        800, FALSE  );  //Computers Restricted
   allowComponent(                                        802, FALSE  );  
   allowComponent(                                        805, FALSE  );  
   allowComponent(                                        806, FALSE  );  
   allowComponent(                                        807, FALSE  );  
   allowComponent(                                        809, FALSE  );  //Jammers Restricted
   allowComponent(                                        811, FALSE  );  
   allowComponent(                                        812, FALSE  );  
   allowComponent(                                        813, FALSE  );  
   allowComponent(                                        820, FALSE  );  //Thermal Diffuser
   allowComponent(                                        845, FALSE  );  //SCAP
   allowComponent(                                        850, FALSE  );  //SAMP
   allowComponent(                                        860, FALSE  );  //LTADs
   allowComponent(                                        865, FALSE  );  //Battery
   allowComponent(                                        870, FALSE  );  //CAP
   allowComponent(                                        875, FALSE  );  //Field Stabilizer
   allowComponent(                                        880, FALSE  );  //Rocket Booster
   allowComponent(                                        885, FALSE  );  //Turbine Booster
   allowComponent(                                        890, FALSE  );  //Nano-Repair Module
   allowComponent(                                        900, FALSE  );  //Angel Life Support
   allowComponent(                                        910, FALSE  );  //Anti-Gravity Gen
   allowComponent(                                        912, FALSE  );  //Electrohull
   allowComponent(                                        914, FALSE  );  //UAP
   allowComponent(                                        931, FALSE  );  //Quicksilver Nano-Armor
}

// Healing Pad Functionality
//------------------------------------------------------------------------------
function ZenHeal::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);  
}
function ZenHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, 0, $padWaitTime, true); 
}

// Ammo Pad Functionality
//------------------------------------------------------------------------------
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}

// ZenAll Pad Functionality
//------------------------------------------------------------------------------
function ZenAll::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
}
function ZenAll::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, $ammoRate, $padWaitTime, true); 
}
