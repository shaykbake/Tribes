// FILENAME:	CTF_Bunkers.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "CTF_Bunkers";

$maxFlagCount  = 5;           // no of flags required by a team to end the game
$flagValue     = 5;          // points your team gets for capturing
$carrierValue  = 2;          //  "      "    "    "    " killing carrier
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 0;

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
	initGlobalVars();

	marsSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to CTF Bunkers! Use the bunkers for cover & the towers for sniping. Enter the towers by walking under them. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

function setDefaultMissionItems()
{
   allowComponent(                                        880, FALSE  );  //Rocket Booster
}

function ZenTransporter::trigger::onContact(%this, %object)
{
	setPosition(%object, 1167.82, -560.213, 858);
}

function ZenTransporter2::trigger::onContact(%this, %object)
{
	setPosition(%object, 463.076, -575.612, 858);
}

function ZenTransporter3::trigger::onContact(%this, %object)
{
	setPosition(%object, 1072.38, 1743.04, 791);
}

function ZenTransporter4::trigger::onContact(%this, %object)
{
	setPosition(%object, 386.72, 2161.59, 819);
}

function ball1::structure::onAttacked(%this, %attacker){
{
	setPosition(%attacker, -1867.88, 1809.29, 423);
}

function ball2::structure::onAttacked(%this, %attacker){
{
	setPosition(%attacker, -1867.88, 1809.29, 423);
}

function ball3::structure::onAttacked(%this, %attacker){
{
	setPosition(%attacker, -1867.88, 1809.29, 423);
}

function ball4::structure::onAttacked(%this, %attacker){
{
	setPosition(%attacker, -1867.88, 1809.29, 423);
}
