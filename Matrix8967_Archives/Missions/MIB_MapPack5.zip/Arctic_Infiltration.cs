// FILENAME:	Arctic_Infiltration.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Arctic Infiltration";

// Allows the missions to cycle (defaulted to true)
$cycleMissions = true;

$missionLoaded = false;
$missionStarted = false;
$currentActivePlayers = 0;
$datalinkEngaged = false;
$playersUploading = 0;
$uploader = "Nobody";
$uploadTime = 0;
$uploadObjComp = false;
$uploadLock = false;
$dataProxLock = false;
$successLock = false;
$vehId = "N/A";
$vehType = "N/A";
$MetaVehType = "N/A";
$MetaVehId = "N/A";
$metaPilot = "N/A";
$squad1Activated = false;
$squad2Activated = false;
$squad3Activated = false;
$squad4Activated = false;
$squad5Activated = false;
$defendBase = false;
$targeted = false;
$bogies = false;

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
}

Pilot BigRadar
{
   id = 28;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 1500.0;
   deactivateBuff = 1000.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot SmallRadar
{
   id = 29;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 200.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot NoRadar
{
   id = 30;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 75.0;
   deactivateBuff = 0.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Medvinsky
{
   id = 31;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "COL Medvinsky [IMP/KN/L23]";
};

Pilot Zukovsky
{
   id = 32;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "MAJ Zukovsky [IMP/KN/L23]";
};

Pilot Turakov
{
   id = 33;
   skill = 0.6;
   accuracy = 0.6;
   aggressiveness = 0.6;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "SGT Turakov [IMP/KN/L23]";
};

Pilot InfectedExec
{
   id = 34;
   skill = 0.4;
   accuracy = 0.4;
   aggressiveness = 0.5;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Infected Executioner";
};

Pilot InfectedJudge
{
   id = 35;
   skill = 0.4;
   accuracy = 0.4;
   aggressiveness = 0.5;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Infected Adjudicator";
};

Pilot InfectedShep
{
   id = 36;
   skill = 0.4;
   accuracy = 0.4;
   aggressiveness = 0.5;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Infected Shepherd";
};

Pilot InfectedGoad
{
   id = 37;
   skill = 0.4;
   accuracy = 0.4;
   aggressiveness = 0.5;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Infected Goad";
};

Pilot InfectedSeek
{
   id = 38;
   skill = 0.4;
   accuracy = 0.4;
   aggressiveness = 0.5;
   activateDist = 350.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Infected Seeker";
};

function onMissionStart()
{
   iceSounds();
   $navAlpha = getObjectId("Missiongroup\\navAlpha");
   $navBravo = getObjectId("Missiongroup\\navBravo");
   $AIhercs = "Missiongroup/AIhercs";
   $AIhercs2 = "Missiongroup/AIhercs2";
   $Medvinsky = getObjectId("Missiongroup\\Medvinsky");
   $Zukovsky = getObjectId("Missiongroup\\Zukovsky");
   $Turakov = getObjectId("Missiongroup\\Turakov");
   $squad1Herc1 = getObjectId("Missiongroup\\squad1Herc1");
   $squad1Herc2 = getObjectId("Missiongroup\\squad1Herc2");
   $squad1Herc3 = getObjectId("Missiongroup\\squad1Herc3");   
   $squad1Herc4 = getObjectId("Missiongroup\\squad1Herc4");   
   $squad2Herc1 = getObjectId("Missiongroup\\squad2Herc1");
   $squad2Herc2 = getObjectId("Missiongroup\\squad2Herc2");
   $squad2Herc3 = getObjectId("Missiongroup\\squad2Herc3");
   $squad3Herc1 = getObjectId("Missiongroup\\squad3Herc1");
   $squad3Herc2 = getObjectId("Missiongroup\\squad3Herc2");
   $squad3Herc3 = getObjectId("Missiongroup\\squad3Herc3");
   $squad4Herc1 = getObjectId("Missiongroup\\squad4Herc1");
   $squad4Herc2 = getObjectId("Missiongroup\\squad4Herc2");
   $squad4Herc3 = getObjectId("Missiongroup\\squad4Herc3");
   $squad5Herc1 = getObjectId("Missiongroup\\AIhercs\\squad5Herc1");
   $squad5Herc2 = getObjectId("Missiongroup\\AIhercs\\squad5Herc2");
   $squad5Herc3 = getObjectId("Missiongroup\\AIhercs\\squad5Herc3");
   $squad1path = "Missiongroup/squad1path";
   $squad2path = "Missiongroup/squad2path";
   $squad3path = "Missiongroup/squad3path";
   $squad4path = "Missiongroup/squad4path";
   $squad5path = "Missiongroup/squad5path";
   $MedPath = getObjectId("Missiongroup\\MedPath");
   $ZukPath = "Missiongroup/ZukPath";
   $TurPath = "Missiongroup/TurPath";
   $base = "Missiongroup/base";
   $Monument = getObjectId("Missiongroup\\monument");
   $beam = getObjectId("Missiongroup\\beam");
   $Satellite = getObjectId("Missiongroup\\base\\satellite");
   $Array1 = getObjectId("Missiongroup\\CybridSensors\\array1");
   $Array2 = getObjectId("Missiongroup\\CybridSensors\\array2");
   $Uplink = getObjectId("Missiongroup\\CybridSensors\\uplink");
   $Jamma = getObjectId("Missiongroup\\CybridSensors\\jamma");
   setVehicleRadarVisible($squad2Herc1, false);
   setVehicleRadarVisible($squad2Herc2, false);
   setVehicleRadarVisible($squad2Herc3, false);
   setVehicleRadarVisible($squad3Herc1, false);
   setVehicleRadarVisible($squad3Herc2, false);
   setVehicleRadarVisible($squad3Herc3, false);
   setVehicleRadarVisible($squad4Herc1, false);
   setVehicleRadarVisible($squad4Herc2, false);
   setVehicleRadarVisible($squad4Herc3, false);
   setVehicleRadarVisible($squad5Herc1, false);
   setVehicleRadarVisible($squad5Herc2, false);
   setVehicleRadarVisible($squad5Herc3, false);
   order($Zukovsky, guard, $ZukPath);
   order($Turakov, guard, $TurPath);
   order($Zukovsky, speed, low);
   order($Turakov, speed, low);
}

function player::onAdd(%player)
{
   say(%player, 0, "Mission 5: Arctic Infiltration. The first of the cybrids to reach Earth are dropping down in western Siberia. The first nexus has been established near our arctic base there. Our techs have cooked up a virus to be uploaded into the nexus that will scramble the cybrid's IFF codes. Your mission is to proceed to nav Bravo and upload the virus into the nexus. If all goes as planned, the cybrids will have a hard time distinguishing friend from foe.");
   %player.datalink = false;
   %player.status = "Waiting";
   %player.vehicle = "N/A";
   %player.reload = true;
   %player.late = true;
}

function onMissionLoad()
{
   cdAudioCycle("SS4", "SS3");
   setGameInfo("<F2>GAME TYPE:<F0>  MIB Multiplayer Campaign\n\n<F2>MISSION:<F0>  Mission 5: Arctic Infiltration\n\n<F2>MISSION CREATOR:<F0>  Com. Sentinal [M.I.B.]\n\n<F2>BRIEFING:<F0>\n\nThe first of the cybrids are now reaching Earth. Their primary drop point seems to be centered around western Siberia. We have reports that the first cybrid nexus has been established on Earth not too far from our arctic base there. Preparing for the worst, our techs have cooked up a virus to be uploaded into the nexus that will scramble the cybrid's IFF codes. Your mission is to proceed to nav Bravo and upload the virus into the nexus. If all goes as planned, the cybrids will have a hard time distinguishing friend from foe.\n\n<f3>TIP: Each player has 1 emergency reload per mission. Scan another vehicle to use it at any time during the mission.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download the entire MIB Multiplayer Campaign & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      %player.status = "Waiting";
      %player.late = true;
   }
   $currentActivePlayers = "N/A";
   if($missionLoaded == false)
   {
      $missionLoaded = true;
      say("Everybody", 0, "Mission 5: Arctic Infiltration. The first of the cybrids to reach Earth are dropping down in western Siberia. The first nexus has been established near our arctic base there. Our techs have cooked up a virus to be uploaded into the nexus that will scramble the cybrid's IFF codes. Your mission is to proceed to nav Bravo and upload the virus into the nexus. If all goes as planned, the cybrids will have a hard time distinguishing friend from foe.");
   }
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player != 0)
   {
      %player.late = true;
      %player.reload = false;
      if((getTeam(%vehicleId)!=*IDSTR_TEAM_YELLOW)&&(%player!=0))
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      }
      if($missionStarted==true)
      {
         schedule("healObject(" @ %vehicleId @ ", -50000);", 1);
         messageBox(%player, "You cannot join a game in progress. Please wait until the mission is over to join.");
      }
      else if($missionStarted==false)
      {
         %player.late = false;
         %player.status = "Alive";
         %player.vehicle = getVehicleName(%vehicleId);
      }
      reloadObject($Medvinsky, 99999);
   }
}

function dropZoneWarning::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if($missionStarted == false)
      {
         say(%player, 1, "<F5>WARNING: Exiting the drop zone will start the mission.");
      }
   }
}

function exitDropZone::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      $missionStarted = true;
      startMessage();
      order($Medvinsky, speed, high);
      $MedGuard = %object;
      order($Medvinsky, guard, $MedGuard);
   }
}

function startMessage()
{
   $playersNotLate = 0;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(%player.late==false)
      {
         $playersNotLate++;
      }
      %player.reload = false;
   }
   $currentActivePlayers = $playersNotLate;
   if($playersNotLate == 1)
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " player.");
   }
   else
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " players.");
   }
   cdAudioCycle("Purge", "Watching");
   setNavBravo();
}

function setNavBravo()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navAlpha, false, %vehicleId); 
      setNavMarker($navBravo, true, %vehicleId);
   }
   schedule("say(\"Everybody\", 2, \"<F1>COL Medvinsky [IMP/KN/L23]: The first of the cybrids have reached Earth. Their primary drop point seems to be centered around western Siberia.\");", 5);
   schedule("say(\"Everybody\", 2, \"<F1>COL Medvinsky [IMP/KN/L23]: We have reports that the first cybrid nexus has been established on Earth not too far from our base.\");", 11);
   schedule("say(\"Everybody\", 2, \"<F1>COL Medvinsky [IMP/KN/L23]: Preparing for the worst, our techs have cooked up a virus to be uploaded into the nexus that will scramble the cybrid's IFF codes.\");", 17);
   schedule("say(\"Everybody\", 2, \"<F1>COL Medvinsky [IMP/KN/L23]: We must proceed to nav Bravo and upload the virus into the nexus.\");", 23);
   schedule("say(\"Everybody\", 2, \"<F1>COL Medvinsky [IMP/KN/L23]: If all goes as planned, the cybrids will have a hard time distinguishing friend from foe.\");", 29);
}

function squad1::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad1Activated == false))
   {
      $squad1Activated = true;
      squad1();
   }
}

function squad1()
{
   $squad1Activated = true;
   playAnimSequence($Array1, 0, true);
   playAnimSequence($Array2, 0, true);
   playAnimSequence($Uplink, 0, true);
   playAnimSequence($Jamma, 2, true);
   say("Everybody", 4, "<F5>NEXUS: Warning, human//animal warforms detected on attack vector.", "CYB_NEX06.WAV");
   addToSet($AIhercs2, $squad1Herc1);
   addToSet($AIhercs2, $squad1Herc2);
   addToSet($AIhercs2, $squad1Herc3);
   addToSet($AIhercs2, $squad1Herc4);
   order($squad1Herc1, speed, high);
   order($squad1Herc2, speed, high);
   order($squad1Herc3, speed, high);
   order($squad1Herc4, speed, high);
   order($squad1Herc1, guard, $squad1Path);
   order($squad1Herc2, guard, $squad1Path);
   order($squad1Herc3, guard, $squad1Path);
   order($squad1Herc4, guard, $squad1Path);
}

function squad2()
{
   $squad2Activated = true;
   addToSet($AIhercs2, $squad2Herc1);
   addToSet($AIhercs2, $squad2Herc2);
   addToSet($AIhercs2, $squad2Herc3);
   setVehicleRadarVisible($squad2Herc1, true);
   setVehicleRadarVisible($squad2Herc2, true);
   setVehicleRadarVisible($squad2Herc3, true);
   setPosition($squad2Herc1, -896, -913, 345);
   setPosition($squad2Herc2, -1010, -929, 345);
   setPosition($squad2Herc3, -783, -900, 345);
   order($squad2Herc1, guard, $squad2Path);
   order($squad2Herc2, guard, $squad2Path);
   order($squad2Herc3, guard, $squad2Path);
   order($squad2Herc1, speed, high);
   order($squad2Herc2, speed, high);
   order($squad2Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 5))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 5)
   {
      %extraHercs = 5;
   }
   %x1 = -1063;
   %y1 = -1382;
   %x2 = -1934;
   %y2 = -580;
   $currentPath = $squad2Path;
   %dropInterval = 5;
   %speed = "high";
   %order = "guard";
   %radar = "normal";
   %dropType = "drop";
   schedule("dropExtraCybrids2(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ", " @ %dropType @ ");", 30);
}

function squad3()
{
   $squad3Activated = true;
   if($uploadObjComp == true)
   {
      dropMetagensSquad3();
   }
   schedule("squad4();", 120);
   addToSet($AIhercs, $squad3Herc1);
   addToSet($AIhercs, $squad3Herc2);
   addToSet($AIhercs, $squad3Herc3);
   setVehicleRadarVisible($squad3Herc1, true);
   setVehicleRadarVisible($squad3Herc2, true);
   setVehicleRadarVisible($squad3Herc3, true);
   dropPod(890, -1476, (327 + 1000), 890, -1476, 327, $squad3Herc1);
   schedule("dropPod(831, -1557, (350 + 1000), 831, -1557, 350, $squad3Herc2);", 3);
   schedule("dropPod(953, -1575, (335 + 1000), 953, -1575, 335, $squad3Herc3);", 6);
   order($squad3Herc1, speed, high);
   order($squad3Herc2, speed, high);
   order($squad3Herc3, speed, high);
   order($squad3Herc1, attack, $base);
   order($squad3Herc2, attack, $base);
   order($squad3Herc3, attack, $base);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 1;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers + 1;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 7;
   }
   %x1 = 225;
   %y1 = -1642;
   %x2 = 1398;
   %y2 = -2371;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function dropMetagensSquad3()
{
   if($currentActivePlayers <= 2)
   {
      %num = 1;
   }
   else if($currentActivePlayers > 2)
   {
      %num = 2;
   }
   %x1 = 1231;
   %y1 = 1384;
   %x2 = 624;
   %y2 = 1919;
   dropMetagens(%num, %x1, %y1, %x2, %y2);
}

function squad4()
{
   $squad4Activated = true;
   if($uploadObjComp == true)
   {
      dropMetagensSquad4();
   }
   schedule("squad5();", 120);
   addToSet($AIhercs, $squad4Herc1);
   addToSet($AIhercs, $squad4Herc2);
   addToSet($AIhercs, $squad4Herc3);
   setVehicleRadarVisible($squad4Herc1, true);
   setVehicleRadarVisible($squad4Herc2, true);
   setVehicleRadarVisible($squad4Herc3, true);
   dropPod(2506, 1, (328 + 1000), 2506, 1, 328, $squad4Herc1);
   schedule("dropPod(2552, 137, (354 + 1000), 2552, 137, 354, $squad4Herc2);", 3);
   schedule("dropPod(2545, -113, (308 + 1000), 2545, -113, 308, $squad4Herc3);", 6);
   order($squad4Herc1, attack, $base);
   order($squad4Herc2, attack, $base);
   order($squad4Herc3, attack, $base);
   order($squad4Herc1, speed, high);
   order($squad4Herc2, speed, high);
   order($squad4Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 1;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 7))
   {
      %extraHercs = $currentActivePlayers + 1;
   }
   else if($currentActivePlayers > 7)
   {
      %extraHercs = 8;
   }
   %x1 = 2773;
   %y1 = -643;
   %x2 = 3553;
   %y2 = 887;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function dropMetagensSquad4()
{
   if($currentActivePlayers <= 2)
   {
      %num = 1;
   }
   else if(($currentActivePlayers > 2)&&($currentActivePlayers <= 5))
   {
      %num = 2;
   }
   else if($currentActivePlayers > 5)
   {
      %num = 3;
   }
   %x1 = -306;
   %y1 = 512;
   %x2 = -634;
   %y2 = -383;
   dropMetagens(%num, %x1, %y1, %x2, %y2);
}

function squad5()
{
   $squad5Activated = true;   
   if($uploadObjComp == true)
   {
      dropMetagensSquad5();
   }
   addToSet($AIhercs, $squad5Herc1);
   addToSet($AIhercs, $squad5Herc2);
   addToSet($AIhercs, $squad5Herc3);
   setVehicleRadarVisible($squad5Herc1, true);
   setVehicleRadarVisible($squad5Herc2, true);
   setVehicleRadarVisible($squad5Herc3, true);
   dropPod(307, 1485, (253 + 1000), 307, 1485, 253, $squad5Herc1);
   schedule("dropPod(193, 1411, (230 + 1000), 193, 1411, 230, $squad5Herc2);", 3);
   schedule("dropPod(398, 1651, (287 + 1000), 398, 1651, 287, $squad5Herc3);", 6);
   order($squad5Herc1, attack, $base);
   order($squad5Herc2, attack, $base);
   order($squad5Herc3, attack, $base);
   order($squad5Herc1, speed, high);
   order($squad5Herc2, speed, high);
   order($squad5Herc3, speed, high);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 1;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 8))
   {
      %extraHercs = $currentActivePlayers + 1;
   }
   else if($currentActivePlayers > 8)
   {
      %extraHercs = 9;
   }
   %x1 = 267;
   %y1 = 1640;
   %x2 = -296;
   %y2 = 2180;
   $currentPath = $base;
   %dropInterval = 5;
   %speed = "high";
   %radar = "normal";
   dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar);
}

function dropMetagensSquad5()
{
   if($currentActivePlayers <= 2)
   {
      %num = 1;
   }
   else if(($currentActivePlayers > 2)&&($currentActivePlayers <= 5))
   {
      %num = 2;
   }
   else if($currentActivePlayers > 5)
   {
      %num = 3;
   }
   %x1 = 1789;
   %y1 = -1071;
   %x2 = 2477;
   %y2 = -1693;
   dropMetagens(%num, %x1, %y1, %x2, %y2);
}

function dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      else if(%radar == "none")
      {
         setPilotId(%herc, 30);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      order(%herc, guard, $Monument);
      order(%herc, attack, $currentPath);
      %target = $currentPath;
      schedule("safetyNetAttack(" @ %herc @ ", " @ %target @ ");", 5);
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %radar @ ");", %dropInterval);
   }
}

function dropExtraCybrids2(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar, %dropType)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs2, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      else if(%radar == "none")
      {
         setPilotId(%herc, 30);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      if(%dropType == "drop")
      {
         dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      }
      else if(%dropType == "teleport")
      {
         setPosition(%herc, %x, %y, %z);
      }
      if(%order == "guard")
      {
         order(%herc, guard, $currentPath);
      }
      else if(%order == "attack")
      {
         order(%herc, attack, $currentPath);
      }
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybrids2(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ", " @ %dropType @ ");", %dropInterval);
   }
}

function dropMetagens(%num, %x1, %y1, %x2, %y2)
{
   if(%num > 0)
   {
      %num--;
      randomMetaVeh();
      %herc = newObject("Metagen", $MetaVehType, $MetaVehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs2, %herc);
      setTeam(%herc, *IDSTR_TEAM_YELLOW);
      if(getVehicleName(%herc) == "Metagen Executioner")
      {
         setPilotId(%herc, 34);
      }
      else if(getVehicleName(%herc) == "Metagen Adjudicator")
      {
         setPilotId(%herc, 35);
      }
      else if(getVehicleName(%herc) == "Metagen Shepherd")
      {
         setPilotId(%herc, 36);
      }
      else if(getVehicleName(%herc) == "Metagen Goad")
      {
         setPilotId(%herc, 37);
      }
      else if(getVehicleName(%herc) == "Metagen Seeker")
      {
         setPilotId(%herc, 38);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      order(%herc, guard, $monument);
      order(%herc, speed, high);
      schedule("dropMetagens(" @ %num @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ");", 5);
   }
}

function randomCybVeh()
{
   %type = randomInt(0,13);
   if(%type==0)
   {
      $vehId = 20;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 21;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 25;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 26;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 28;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==13)
   {
      $vehId = 28;
      $vehType = "herc";
   }
}

function randomMetaVeh()
{
   %type = randomInt(0,4);
   if(%type==0)
   {
      $metaVehId = 35;
      $metaVehType = "herc";
   }
   else if(%type==1)
   {
      $metaVehId = 36;
      $metaVehType = "herc";
   }
   else if(%type==2)
   {
      $metaVehId = 37;
      $metaVehType = "herc";
   }
   else if(%type==3)
   {
      $metaVehId = 38;
      $metaVehType = "herc";
   }
   else if(%type==4)
   {
      $metaVehId = 39;
      $metaVehType = "herc";
   }
}

function safetyNetAttack(%herc, %target)
{
   order(%herc, attack, %target);
   schedule("safetyNetAttack2(" @ %herc @ ", " @ %target @ ");", 5);
}

function safetyNetAttack2(%herc, %target)
{
   order(%herc, attack, %target);
   %xInit = getPosition(%herc, x);
   %yInit = getPosition(%herc, y);
   schedule("safetyNetGuard(" @ %herc @ ", " @ %target @ ", " @ %xInit @ ", " @ %yInit @ ");", 10);
}

function safetyNetGuard(%herc, %target, %xInit, %yInit)
{
   %x2 = getPosition(%herc, x);
   %y2 = getPosition(%herc, y);
   %deltaX = abs(%x2 - %xInit);
   %deltaY = abs(%y2 - %yInit);
   %distance = getHypotenuse(%deltaX, %deltaY);
   if(%distance < 50)
   {
      order(%herc, guard, $Monument);   
   }
   schedule("cleanUpDefectiveCybrid(" @ %herc @ ", " @ %xInit @ ", " @ %yInit @ ");", 10);
}

function cleanUpDefectiveCybrid(%herc, %xInit, %yInit)
{
   %x2 = getPosition(%herc, x);
   %y2 = getPosition(%herc, y);
   %deltaX = abs(%x2 - %xInit);
   %deltaY = abs(%y2 - %yInit);
   %distance = getHypotenuse(%deltaX, %deltaY);
   if(%distance < 50)
   {
      healObject(%herc, -99999);
      schedule("deleteObject(" @ %herc @ ");", 3);
   }
}

function abs(%number)
{
   if(%number >= 0)
   {
      %answer = %number;
   }
   else if(%number < 0)
   {
      %answer = -%number;
   }
}

function getHypotenuse(%deltaX, %deltaY, %deltaZ)
{
   if(%deltaZ == "")
   {
      %answer = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
   }
   else if(%deltaZ != "")
   {
      %hyp = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
      %answer = sqrt((%hyp * %hyp) + (%deltaZ * %deltaZ));
   }
   return %answer;
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   reloadObject($Medvinsky, 99999);
   if(%player1 == 0)
   {
      if(($squad5Activated == true)&&(isGroupDestroyed($AIHercs) == true))
      {
         $successLock = true;
         setFlybyCamera(%destroyer, -50, 50, 50);
         missionSuccessful();
      }
      schedule("deleteObject(" @ %destroyed @ ");", 5);
   }
   else
   {
      if($missionStarted == true)
      {
         %player.datalink = false;
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            reloadObject(%vehicleId, 10000);
         }
         if(%player1.late == false)
         {
            %player1.late = true;
            %player1.status = "Dead";
            $currentActivePlayers--;
            checkForPlayersDead();
         }
      }
      else
      {
         %player1.late = true;
         %player1.status = "Waiting";
      }
   }
   if(%player2 != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function structure::onDestroyed(%destroyed, %destroyer)
{
   if(isMember($base, %destroyed) == true)
   {
      if(isGroupDestroyed($base) == true)
      {
         baseDestroyed();
      }
   }
   if(%destroyed == $Satellite)
   {
      setPosition($beam, 10000, 10000, -1000);
   }
}

function baseDestroyed()
{
   say("Everybody", 3, "<F5>The base has been destroyed!");
   schedule("missionFailed();", 3);
}

function cybridBoundary::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(($squad3Activated == true)&&(%player == 0)&&(getTeam(%object) == *IDSTR_TEAM_RED)&&(%object != $Medvinsky)&&(%object != $Zukovsky)&&(%object != $Turakov))
   {
      healObject(%object, -99999);
   }
}

function vehicle::onTargeted(%targeted, %targeter)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%targeted);
   if((%player1 != 0)&&($squad1Activated == false))
   {
      if((%targeter == $squad1Herc1) || (%targeter == $squad1Herc2) || (%targeter == $squad1Herc3) || (%targeter == $squad1Herc4))
      {
         if($targeted == false)
         {
            $targeted = true;
            squad1();
         }
      }
   }
   if(($defendBase == true)&&(%player1 == 0)&&($bogies == false))
   {
      if((%targeter == $Zukovsky) || (%targeter == $Turakov) || (%targeter == $Medvinsky))
      {
         $bogies = true;
         say("Everybody", 5, "<F5>" @ getHudName(%targeter) @ ": Bogies on the perimeter!", "gen_icca03.wav");
      }
   }
}

function datalink::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {  
      $playersUploading++;
      %player.datalink = true;
      if($datalinkEngaged == false)
      {
         $uploader = %object;
         $datalinkEngaged = true;
         say("Everybody", 2, "<F5>Data-link Engaged.", "dlink_engaged.wav");
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %everybody = playerManager::getPlayerNum(%i);
            setHudTimer(180, -1, "Uploading Virus:", 1, %everybody);
         }
         if($dataProxLock == false)
         {
            $dataProxLock = true;
            schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Your squad must remain within close proximity of the nexus until the virus has been successfully uploaded.\");", 3);
         }
      }
      if($squad2Activated == false)
      {
         $squad2Activated = true;
         schedule("squad2();", 30);
         schedule("defendBase();", 90);
      }  
   }
}

function datalink::trigger::onLeave(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      $playersUploading--;
      %player.datalink = false;
      if(($datalinkEngaged == true)&&($UploadObjComp == false))
      {
         if(%object == $downloader)
         {
            if($playersUploading > 0)
            {
               pickNewUploader();
            }
            else
            {
               $uploader = "Nobody";
               $datalinkEngaged = false;
               $uploadTime = 0;
               setHudTimer(0, 1, "", 1, 0);
               %count = playerManager::getPlayerCount();
               for(%i = 0; %i < %count; %i++)
               {
                  %everybody = playerManager::getPlayerNum(%i);
                  setHudTimer(0, 1, "", 1, %everybody);
               }
               say("Everybody", 2, "<F5>Data Transfer Aborted.", "dlink_abort.wav");
            }
         }
      }
   }
}

function datalink::trigger::onContact(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if(($datalinkEngaged == true)&&($playersUploading > 0))
      {  
         if(%object == $uploader)
         {
            $uploadTime++;
            if(($uploadTime >= 174)&&($uploadLock == false))
            {
               $uploadLock = true;
               uploadComplete();
            }
         }
      }
   }
}

function pickNewUploader()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if(%player.datalink == true)
      {
         if($uploader == "Nobody")
         {
            $uploader = %vehicleId;
         }
      }
   }
}

function uploadComplete()
{  
   $uploadObjComp = true;
   cdAudioCycle("Terror", "Cyberntx", "Mechsoul");
   say("Everybody", 2, "<F5>Data Transfer Complete. Virus successfully uploaded.", "dlink_complete.wav");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navBravo, false, %vehicleId);
      setNavMarker($navAlpha, true, %vehicleId); 
   }
   order($Medvinsky, speed, high);
   order($Medvinsky, guard, $MedPath);
}

function defendBase()
{
   $defendBase = true;
   say("Everybody", 2, "<F1>TAC-COM: Satellites have spotted several cybrid squads dropping in! They are heading for our base, ETA 3 minutes and counting. Hurry up and finish uploading that virus and get back to base!", "Mission_obj_new.WAV");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %everybody = playerManager::getPlayerNum(%i);
      setHudTimer(180, -1, "Cybrid ETA:", 3, %everybody);
   }
   schedule("squad3();", 180);
}

function nexus::structure::onDestroyed(%destroyed, %destroyer)
{
   say("Everybody", 2, "<F5>The nexus has been destroyed!");
   schedule("missionFailed();", 3);
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player.reload == false)
   {
      %player.reload = true;
      reloadObject(%scanner, 99999);
      say(%player, %player, "<F5>Emergency reload initiated.");
   }
}

function checkForPlayersDead()
{
   %allDead = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%vehicleId != "") && (isGroupDestroyed(%vehicleId) == false))
      {
         %allDead = false;
      }
   }
   if(%allDead == true)
   {
      schedule("missionFailed();", 3);
   }
}

function missionSuccessful()
{
   flushConsoleScheduler();
   playSound(0, "Mission_comp.wav", IDPRF_2D);
   messageBox(0, "Mission Successful");
   if($cycleMissions == true)
   {
      $MissionCycling::Stage0 = "Defend_Alexandria";
      $server::Mission = $MissionCycling::Stage0;
   }
   schedule("missionEndConditionMet();", 5);
}

function missionFailed()
{  
   if($successLock == false)
   {
      flushConsoleScheduler();
      playSound(0, "Mission_fail.wav", IDPRF_2D);
      messageBox(0, "Mission Failed");
      if($cycleMissions == true)
      {
         $MissionCycling::Stage0 = "Defend_Alexandria";
         $server::Mission = $MissionCycling::Stage0;
      }
      schedule("missionEndConditionMet();", 5);
   }
}

function onMissionEnd()
{
   deleteObject($AIhercs);
   deleteObject($AIhercs2);
}

function getPlayerStatus(%player)
{
   return(%player.status);
}

function getActivePlayers()
{
   return($currentActivePlayers);
}

function getPlayerVehicle(%player)
{
   return(%player.vehicle);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";


	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
         $ScoreBoard::PlayerColumnFunction4 = "getPlayerVehicle";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = "Players Remaining";
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getActivePlayers";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}
