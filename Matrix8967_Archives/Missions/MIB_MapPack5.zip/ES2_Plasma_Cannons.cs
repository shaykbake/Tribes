// FILENAME:	ES2_Plasma_Cannons.cs
//
// AUTHORS:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "ES2_Plasma_Cannons";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$server::HudMapViewOffsetX = -1400;
$server::HudMapViewOffsetY = 2400;

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
   moonSounds();
   $projectiles = "Missiongroup/projectiles";
}

function onMissionLoad()
{
   cdAudioCycle("Mechsoul", "Terror", "Watching");
   setGameInfo("<F2>GAME TYPE:<F0>  EarthSiege 2 Plasma Cannon Deathmatch\n\n<F2>MISSION:<F0>  ES2_Plasma_Cannons\n\nWelcome to EarthSiege 2 Plasma Cannon DeathMatch! Your vehicle is equipped with the deadly ES2 Plasma Cannon. The plasma pulse will track your target and inflict huge amounts of damage. To use your plasma cannon, you can scan your target or spot them with LTADs. Scanning gives your plasma cannon a 700m range, while LTADs gives it a 1500m range. After firing, your plasma cannon will take 90 seconds to recharge.\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download ES2_Plasma_Cannons & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);      
      %player.plasmaPoints = 0;
   }
}

function player::onAdd(%player)
{
   say(%player, 0 , "Welcome to EarthSiege 2 Plasma Cannon DeathMatch! Your vehicle is equipped with the deadly ES2 Plasma Cannon. The plasma pulse will track your target and inflict huge amounts of damage. To use your plasma cannon, you can scan your target or spot them with LTADs. Scanning gives your plasma cannon a 700m range, while LTADs gives it a 1500m range. After firing, your plasma cannon will take 90 seconds to recharge.");
   %player.plasmaPoints = 0;
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   %player.spawned = true;
   %player.killer = "Nobody";
   %vehicleId.recharged = true;
   setHudTimer(0, 0, "", 2, %player);
   if(%player == 0)
   {
      %vehicleId.spawned = true;
   }
   //Flyer easter egg (think Razor, hehe)
   order(%vehicleId, guard, 0);
}

function recharge(%vehicleId)
{
   %vehicleId.recharged = true;
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%scanner.recharged == true)
   {
      %scanner.recharged = false;
      schedule("recharge(" @ %scanner @ ");", 90);
      setHudTimer(90, -1, "Plasma Cannon Recharging:", 2, %player);
      %range = 100;  //700m projectile range (or 10 seconds of travel)
      %projectile = newObject("proj", staticShape, "pr_empT.dts");
      schedule("playAnimSequence(" @ %projectile @ ", 0, true);", 0.5);
      addToSet($projectiles, %projectile);
      %x = getPosition(%scanner, x);
      %y = getPosition(%scanner, y);
      if((getVehicleName(%scanner) == "Banshee") || (getVehicleName(%scanner) == "Knight's Banshee") || (getVehicleName(%scanner) == "Advocate"))
      {
         %z = getPosition(%scanner, z);
      }
      else
      {
         %z = getTerrainHeight(%x, %y) + 5;
      }
      setPosition(%projectile, %x, %y, %z);
      playSound(%player, "plasma3.wav", IDPRF_2D);
      schedule("homing(" @ %projectile @ ", " @ %scanned @ ", " @ %scanner @ ", " @ %range @ ");", 0.1);
   }
   else if(%scanner.recharged == false)
   {
      say(%player, %player, "<F5>Plasma Cannon recharging...");
   }
}

function vehicle::onSpot(%spotter, %target)
{
   %player = playerManager::vehicleIdToPlayerNum(%spotter);
   if(%spotter.recharged == true)
   {
      if(%target != "")
      {
         if(getVehicleName(%target) != false)
         {
            %spotter.recharged = false;
            schedule("recharge(" @ %spotter @ ");", 90);
            setHudTimer(90, -1, "Plasma Cannon Recharging:", 2, %player);
            %range = 220;  //1540m projectile range (or 22 seconds of travel)
            %projectile = newObject("proj", staticShape, "pr_empT.dts");
            schedule("playAnimSequence(" @ %projectile @ ", 0, true);", 0.5);
            addToSet($projectiles, %projectile);
            %x = getPosition(%spotter, x);
            %y = getPosition(%spotter, y);
            if((getVehicleName(%spotter) == "Banshee") || (getVehicleName(%spotter) == "Knight's Banshee") || (getVehicleName(%spotter) == "Advocate"))
            {
               %z = getPosition(%spotter, z);
            }
            else
            {
               %z = getTerrainHeight(%x, %y) + 5;
            }
            setPosition(%projectile, %x, %y, %z);
            playSound(%player, "plasma3.wav", IDPRF_2D);
            schedule("homing(" @ %projectile @ ", " @ %target @ ", " @ %spotter @ ", " @ %range @ ");", 0.1);
         }
         else
         {
            say(%player, %player, "<F5>You cannot fire your plasma cannon at a structure!");
         }  
      }
      else if(%target == "")
      {
         say(%player, %player, "<F5>Target lost.");
      }
   }
   else if(%spotter.recharged == false)
   {
      if(%target != "")
      {
         say(%player, %player, "<F5>Plasma Cannon recharging...");
      }
      else if(%target == "")
      {
         say(%player, %player, "<F5>Target lost.");
      }
   }
}

function structure::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   say(%player, %player, "<F5>You cannot fire your plasma cannon at a structure!");
}

function homing(%projectile, %target, %spotter, %range)
{
   %player = playerManager::vehicleIdToPlayerNum(%target);
   %player2 = playerManager::vehicleIdToPlayerNum(%spotter);
   if(%range > 0)
   {
      %range--;
      %distance = getDistance(%projectile, %target);
      if(%player == 0)
      {
         if((%distance > 10)&&(%target.spawned == true))
         {
            %x1 = getPosition(%projectile, x);
            %y1 = getPosition(%projectile, y);
            %x2 = getPosition(%target, x);
            %y2 = getPosition(%target, y);
            %increments = %distance / 7;
            %xOffset = (%x2 - %x1) / %increments;
            %yOffset = (%y2 - %y1) / %increments;
            %x = %x1 + %xOffset;
            %y = %y1 + %yOffset;
            if((getVehicleName(%target) == "Banshee") || (getVehicleName(%target) == "Knight's Banshee") || (getVehicleName(%target) == "Advocate") || (getVehicleName(%spotter) == "Banshee") || (getVehicleName(%spotter) == "Knight's Banshee") || (getVehicleName(%spotter) == "Advocate"))
            {
               %z1 = getPosition(%projectile, z);
               %z2 = getPosition(%target, z);
               %increments = %distance / 7;
               %zOffset = (%z2 - %z1) / %increments;
               %z = %z1 + %zOffset;
            }
            else
            {
               %z = getTerrainHeight(%x1, %y1) + 5;
            }
            setPosition(%projectile, %x, %y, %z);
            schedule("homing(" @ %projectile @ ", " @ %target @ ", " @ %spotter @ ", " @ %range @ ");", 0.1);
         }
         else if((%distance <= 10)&&(%target.spawned == true))
         {
            impact(%projectile, %target, %spotter);
         }
         else
         {
            deleteObject(%projectile);
            echo("Projectile deleted.");
            playSound(%player, "sfx_electrical_bzzt.wav", IDPRF_2D);
            playSound(%player2, "sfx_electrical_bzzt.wav", IDPRF_2D);
         }
      }
      else
      {
         if((%distance > 10)&&(%player.spawned == true))
         {
            %x1 = getPosition(%projectile, x);
            %y1 = getPosition(%projectile, y);
            %x2 = getPosition(%target, x);
            %y2 = getPosition(%target, y);
            %increments = %distance / 7;
            %xOffset = (%x2 - %x1) / %increments;
            %yOffset = (%y2 - %y1) / %increments;
            %x = %x1 + %xOffset;
            %y = %y1 + %yOffset;
            if((getVehicleName(%target) == "Banshee") || (getVehicleName(%target) == "Knight's Banshee") || (getVehicleName(%target) == "Advocate") || (getVehicleName(%spotter) == "Banshee") || (getVehicleName(%spotter) == "Knight's Banshee") || (getVehicleName(%spotter) == "Advocate"))
            {
               %z1 = getPosition(%projectile, z);
               %z2 = getPosition(%target, z);
               %increments = %distance / 7;
               %zOffset = (%z2 - %z1) / %increments;
               %z = %z1 + %zOffset;
            }
            else
            {
               %z = getTerrainHeight(%x1, %y1) + 5;
            }
            setPosition(%projectile, %x, %y, %z);
            schedule("homing(" @ %projectile @ ", " @ %target @ ", " @ %spotter @ ", " @ %range @ ");", 0.1);
         }
         else if((%distance <= 10)&&(%player.spawned == true))
         {
            impact(%projectile, %target, %spotter);
         }
         else
         {
            deleteObject(%projectile);
            echo("Projectile deleted.");
            playSound(%player, "sfx_electrical_bzzt.wav", IDPRF_2D);
            playSound(%player2, "sfx_electrical_bzzt.wav", IDPRF_2D);
         }
      }
   }
   else
   {
      deleteObject(%projectile);
      echo("Out of range: Projectile deleted.");
   }
}

function impact(%projectile, %target, %spotter)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%spotter);
   %player2 = playerManager::vehicleIdToPlayerNum(%target);
   %player2.killer = %player1;
   deleteObject(%projectile);  
   echo("Impact " @ %player2 @ ": Projectile deleted.");
   damageArea(%target, 0, 0, 0, 50, 1200);
   if(%player2 != 0)
   {
      playSound(%player2, "explo3.wav", IDPRF_2D);
      playSound(%player2, "sfx_electrical_bzzt.wav", IDPRF_2D);
   }
   schedule("noKiller(" @ %player2 @ ");", 2);
}

function noKiller(%player)
{
   %player2.killer = "Nobody";
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   %player.spawned = false;
   if(%player == 0)
   {
      %destroyed.spawned = false;
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);

   if((%player2 == 0)&&(%player.killer != "Nobody"))
   {
      say("Everybody", 3, getName(%player) @ " was annihilated by " @ getName(%player.killer) @ "'s Plasma Cannon!", "explo3.wav");
      %killer = %player.killer;
      %killer.plasmaPoints = %killer.plasmaPoints + 3;
   }   
   else
   {
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
   }

   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer))&&(%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }
}

function onMissionEnd()
{
   flushConsoleScheduler();
   deleteObject($projectiles);
   echo("All projectiles deleted.");
}

function getPlayerScore(%player)
{
   return((getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints)) + %player.plasmaPoints;
}
