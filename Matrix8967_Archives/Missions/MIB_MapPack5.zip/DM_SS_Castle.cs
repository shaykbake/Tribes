// FILENAME:	DM_SS_Castle.cs
//
// AUTHORS:  	Maj. �t�rmtr��per [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_SS_Castle";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
     
   	$blastRadius = 100;   // for ammo boxes
	$blastDamage = 4000;   
      go();
	iceSounds();	

}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to the SS Castle! You can download this & other missions made by <F1>Maj. �t�rmtr��per [M.I.B.]<F0> in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Newtech", "SS4", "SS3"); 
   // custom rules for this mission ( teleporter )
   %rules = "<tIDMULT_DM_GAMETYPE>"   @        
            "<tIDMULT_DM_MAPNAME>"    @ 
            $missionName               @
            "<tIDMULT_DM_OBJECTIVES>" @
            "<tIDMULT_DM_SCORING_1>"  @
            "<tIDMULT_DM_SCORING_2>"  @
            $killPoints                @
            "<tIDMULT_DM_SCORING_3>"  @
            "<tIDMULT_DM_SCORING_4>"  @
            $deathPoints               @
            "<tIDMULT_DM_SCORING_5>"  @
            "<tIDMULT_DM_SCORING_6>"  @
            "<tIDMULT_STD_ITEMS>"      @
            "<tIDMULT_STD_HEAL>"       @
            "<tIDMULT_STD_RELOAD>";

   setGameInfo(%rules);
}

function turret::onAdd(%this)
{
	if($server::TeamPlay == false)
	{
		setTeam(%this, *IDSTR_TEAM_NEUTRAL);
	}
}

function sesame::structure::onAttacked(%attacked, %attacker)
{
   setPosition($cprmdoor, $okx, $oky, $okz, -90, 90);
   schedule("setPosition($cprmdoor, $okx, $oky, $okooz, -90, 90);", 5 );
}

function pah::structure::onAttacked(%attacked, %attacker)
{
   setPosition($halldoor, $nox, $noy, $noz, -90, 90);
   schedule("setPosition($halldoor, $nox, $noy, $noooz, -90, 90);", 5 );
}

function bounce::structure::onScan(%scanner, %scanned)
{
   bouncy(%scanned);
   schedule("bouncy(%scanned);", 0.5 );
}

function vehicle::onDestroyed(%this, %who)
{
   %wah = getHUDName(%this);
   %poluza = getHUDName(%who);
   %message = getFancyDeathMessage(%wah, %poluza);
   say(0, 0, %message);

   if ( %who == getObjectId( "MissionGroup/monsta" ) )
   {
     playSound(0, "sfx_steam.wav", IDPRF_2D);
   }
   else if ( %who == getObjectId( "MissionGroup/turret" ) )
   {
		playSound(0, "sfx_steam.wav", IDPRF_2D);
		$killtime = false;
		setTeam(%who, *IDSTR_TEAM_NEUTRAL);
   }
}

Pilot hit
{
   id = 28;
   
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 600.0;
   deactivateBuff = 500.0;
   targetFreq = 2.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Dungeon monster";
};

function kill::structure::onscan(%this, %object)
{
   setTeam(getObjectId( "MissionGroup/turret" ), *IDSTR_TEAM_RED);
   $killtime = true;
}

function kill::trigger::onEnter(%this, %object)
{
   order ($caanon, attack, %object);
}

function kill::trigger::onLeave(%this, %object)
{
   healObject(%object, -100000);
}

function go()
{
   $okx = getPosition(getObjectId("MissionGroup/apple"), x);
   $oky = getPosition(getObjectId("MissionGroup/apple"), y);
   $okz = getPosition(getObjectId("MissionGroup/apple"), z) - 1000;
   $okooz = getPosition(getObjectId("MissionGroup/apple"), z);
   $nox = getPosition(getObjectId("MissionGroup/door"), x);
   $noy = getPosition(getObjectId("MissionGroup/door"), y);
   $noz = getPosition(getObjectId("MissionGroup/door"), z) - 1000;
   $noooz = getPosition(getObjectId("MissionGroup/door"), z);
   $cprmdoor = getObjectId("MissionGroup/apple");
   $halldoor = getObjectId("MissionGroup/door");
   $caanon = getObjectId("MissionGroup/monsta");
   setPilotId($caanon, 28);
   $killtime = false;
}

function bouncy(%scanned)
{
   damageArea(%scanned, 0, 0, 0, 15000, 0);
   damageArea(%scanned, 0, 0, 0, 15000, 0);
   damageArea(%scanned, 0, 0, 0, 15000, 0);
   damageArea(%scanned, 0, 0, 0, 15000, 0);
   damageArea(%scanned, 0, 0, 0, 15000, 0);
   damageArea(%scanned, 0, 0, 0, 15000, 0);
}
