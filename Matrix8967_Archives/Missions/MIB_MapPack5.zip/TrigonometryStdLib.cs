// Trigonometry Standard Library
// by Com. Sentinal [M.I.B.]
//--------------------------------------------------------------------------
// This file contains the following new commands:
//
//  sin(%angle);
//  cos(%angle);
//  tan(%angle);
//  sec(%angle);
//  csc(%angle);
//  cot(%angle);
//  round(%number);
//  getAngle(%x1, %y1, %x2, %y2);
//  getVector(%deltaX, %deltaY);
//  getHypotenuse(%deltaX, %deltaY, [%deltaZ]);
//  getOtherSide(%hypotenuse, %side);
//  square(%number);
//  cube(%number);
//  raiseToPower(%number, %exponent);
//  isInteger(%number);
//  getAverage(%num1, %num2, [%num3, %num4, %num5, %num6, %num7, %num8, %num9, %num10]);
//  abs(%number);
//  degToRad(%degrees);
//  radToDeg(%radians);
//  simplifyAngle(%angle, [%axis]);
//  adjustAngle(%angle);
//  pi();
//
//--------------------------------------------------------------------------


function square(%number)
{
   %answer = (%number * %number);
   return %answer;
}

function cube(%number)
{
   %answer = (%number * %number * %number);
   return %answer;
}

function isInteger(%number)
{
   %excess = (%number - floor(%number));
   if(%excess == 0)
   {
      return true;
   }
   else
   {
      return false;
   }
}

function raiseToPower(%number, %exponent)
{
   if(isInteger(%exponent) == false)
   {
      echo("raiseToPower() - Exponents must be integers!");
      %exponent = round(%exponent);
      echo("Exponent rounded to " @ %exponent);
   }
   %answer = %number;
   if(%exponent == 0)
   {
      %answer = 1;
   }
   else if(%exponent == 1)
   {
      %answer = %number;
   }
   else if(%exponent < 0)
   {
      if(%exponent == -1)
      {
         %answer = (1 / %number);
      }
      else if(%exponent <= -2)
      {
         %count = -2;
         while(%count >= %exponent)
         {
            %count--;
            %answer = (%answer * %number); 
         }
         %answer = (1 / %answer);
      }
   }
   else if(%exponent >= 2)
   {
      %count = 2;
      while(%count <= %exponent)
      {
         %count++;
         %answer = (%answer * %number); 
      }
   }
   return %answer;
}

function getHypotenuse(%deltaX, %deltaY, %deltaZ)
{
   if(%deltaZ == "")
   {
      %answer = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
   }
   else if(%deltaZ != "")
   {
      %hyp = sqrt((%deltaX * %deltaX) + (%deltaY * %deltaY));
      %answer = sqrt((%hyp * %hyp) + (%deltaZ * %deltaZ));
   }
   return %answer;
}

function getOtherSide(%hypotenuse, %side)
{
   %answer = sqrt((%hypotenuse * %hypotenuse) - (%side * %side));
   return %answer; 
}

function getAverage(%num1, %num2, %num3, %num4, %num5, %num6, %num7, %num8, %num9, %num10)
{
   if(%num1 == "")
   {
      echo("getAverage() - You must input at least 2 numbers.");
      %answer = "";
   }
   else if((%num1 != "")&&(%num2 == ""))
   {
      echo("getAverage() - You must input at least 2 numbers.");
      %answer = %num1;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 == ""))
   {
      %answer = (%num1 + %num2) / 2;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 == ""))
   {
      %answer = (%num1 + %num2 + %num3) / 3;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 == ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4) / 4;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 != "")&&(%num6 == ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4 + %num5) / 5;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 != "")&&(%num6 != "")&&(%num7 == ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4 + %num5 + %num6) / 6;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 != "")&&(%num6 != "")&&(%num7 != "")&&(%num8 == ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4 + %num5 + %num6 + %num7) / 7;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 != "")&&(%num6 != "")&&(%num7 != "")&&(%num8 != "")&&(%num9 == ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4 + %num5 + %num6 + %num7 + %num8) / 8;
   }   
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 != "")&&(%num6 != "")&&(%num7 != "")&&(%num8 != "")&&(%num9 != "")&&(%num10 == ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4 + %num5 + %num6 + %num7 + %num8 + %num9) / 9;
   }      
   else if((%num1 != "")&&(%num2 != "")&&(%num3 != "")&&(%num4 != "")&&(%num5 != "")&&(%num6 != "")&&(%num7 != "")&&(%num8 != "")&&(%num9 != "")&&(%num10 != ""))
   {
      %answer = (%num1 + %num2 + %num3 + %num4 + %num5 + %num6 + %num7 + %num8 + %num9 + %num10) / 10;
   }
   return %answer;
}

function abs(%number)
{
   if(%number >= 0)
   {
      %answer = %number;
   }
   else if(%number < 0)
   {
      %answer = -%number;
   }
}

function simplifyAngle(%angle, %axis)
{
   if(%axis == "")
   {
      %axis = x;
   }
   if(%axis == x)
   {
      %angle = adjustAngle(%angle);
      if((%angle > 0)&&(%angle < 90))
      {
         %answer = %angle;
      }
      else if((%angle > 90)&&(%angle < 180))
      {
         %answer = (180 - %angle);
      }
      else if((%angle > 180)&&(%angle < 270))
      {
         %answer = (%angle - 180);
      }
      else if((%angle > 270)&&(%angle < 360))
      {
         %answer = (360 - %angle);
      }
      else if((%angle == 90) || (%angle == 270))
      {
         %answer = 90;
      }   
      else if((%angle == 0) || (%angle == 180) || (%angle == 360))
      {
         %answer = 0;
      }
   }
   else if(%axis == y)
   {
      %angle = adjustAngle(%angle);
      if((%angle > 0)&&(%angle < 90))
      {
         %answer = (90 - %angle);
      }
      else if((%angle > 90)&&(%angle < 180))
      {
         %answer = (%angle - 90);
      }
      else if((%angle > 180)&&(%angle < 270))
      {
         %answer = (270 - %angle);
      }
      else if((%angle > 270)&&(%angle < 360))
      {
         %answer = (%angle - 270);
      }
      else if((%angle == 90) || (%angle == 270))
      {
         %answer = 0;
      }   
      else if((%angle == 0) || (%angle == 180) || (%angle == 360))
      {
         %answer = 90;
      }
   }
   else
   {
      echo("simplifyAngle() - axis must be either x or y");
      echo("If axis is given no value, it defaults to x.");
      %answer = "";
   }
   return %answer;
}

function DegToRad(%degrees)
{
   %radians = (%degrees * 3.14159) / 180;
   return %radians;
}

function RadToDeg(%radians)
{
   %degrees = (%radians * 180) / 3.14159;
   return %degrees;
}

function pi()
{
   %pi = 3.14159;
   return %pi;
}

function round(%number)
{
   %roundNum = %number;
   if(%number > 0)
   {
      %excess = (%number - floor(%number));
      if(%excess >= 0.5)
      {
         %roundNum = (floor(%number) + 1);
      }
      else
      {
         %roundNum = floor(%number);
      }
   }
   if(%number < 0)
   {
      %excess = (floor(%number) - %number);
      if(%excess <= 0.5)
      {
         %roundNum = floor(%number);
      }
      else
      {
         %roundNum = (floor(%number) - 1);
      }
   }
   return %roundNum;
}

function adjustAngle(%angle)
{
   if(%angle >= 360)
   {
      while(%angle >= 360)
      {
         %angle = (%angle - 360);
      }
   }
   else if(%angle < 0)
   {
      while(%angle < 0)
      {
         %angle = (%angle + 360);
      }
   }
   return %angle;
}

function getAngle(%x1, %y1, %x2, %y2)
{
   //Angle is defined from point A (x1, y1) to point B (x2, y2)
   //Point A (x1, y1) is the base point (center of the protractor)
   //Be sure to enter the coordinates for the base point first (x1, y1)

   %deltaX = %x2 - %x1;
   %deltaY = %y2 - %y1;
   %angle = getVector(%deltaX, %deltaY);
   return %angle;
}

function csc(%angle)
{
   %answer = (1 / sin(%angle));
   return %answer;
}

function sec(%angle)
{
   %answer = (1 / cos(%angle));
   return %answer;
}

function cot(%angle)
{
   %answer = (cos(%angle) / sin(%angle));
   return %answer;
}

function tan(%angle)
{
   %answer = (sin(%angle) / cos(%angle));
   return %answer;
}

function sin(%angle)
{
   %angle = adjustAngle(%angle);
   if((round(%angle) == 0) || (round(%angle) == 180) || (round(%angle) == 360))
   {
      %answer = 0;
      return %answer;
   }
   else if((round(%angle) == 1) || (round(%angle) == 179) || (round(%angle) == 181) || (round(%angle) == 359))
   {
      %answer = 0.017452;
      if((round(%angle) == 181) || (round(%angle) == 359))
      {
         %answer = -0.017452;
      }
      return %answer;
   }
   else if((round(%angle) == 2) || (round(%angle) == 178) || (round(%angle) == 182) || (round(%angle) == 358))
   {
      %answer = 0.034899;
      if((round(%angle) == 182) || (round(%angle) == 358))
      {
         %answer = -0.034899;
      }
      return %answer;
   }
   else if((round(%angle) == 3) || (round(%angle) == 177) || (round(%angle) == 183) || (round(%angle) == 357))
   {
      %answer = 0.052335;
      if((round(%angle) == 183) || (round(%angle) == 357))
      {
         %answer = -0.052335;
      }
      return %answer;
   }
   else if((round(%angle) == 4) || (round(%angle) == 176) || (round(%angle) == 184) || (round(%angle) == 356))
   {
      %answer = 0.069756;
      if((round(%angle) == 184) || (round(%angle) == 356))
      {
         %answer = -0.069756;
      }
      return %answer;
   }
   else if((round(%angle) == 5) || (round(%angle) == 175) || (round(%angle) == 185) || (round(%angle) == 355))
   {
      %answer = 0.087156;
      if((round(%angle) == 185) || (round(%angle) == 355))
      {
         %answer = -0.087156;
      }
      return %answer;
   }
   else if((round(%angle) == 6) || (round(%angle) == 174) || (round(%angle) == 186) || (round(%angle) == 354))
   {
      %answer = 0.104528;
      if((round(%angle) == 186) || (round(%angle) == 354))
      {
         %answer = -0.104528;
      }
      return %answer;
   }
   else if((round(%angle) == 7) || (round(%angle) == 173) || (round(%angle) == 187) || (round(%angle) == 353))
   {
      %answer = 0.121869;
      if((round(%angle) == 187) || (round(%angle) == 353))
      {
         %answer = -0.121869;
      }
      return %answer;
   }
   else if((round(%angle) == 8) || (round(%angle) == 172) || (round(%angle) == 188) || (round(%angle) == 352))
   {
      %answer = 0.139173;
      if((round(%angle) == 188) || (round(%angle) == 352))
      {
         %answer = -0.139173;
      }
      return %answer;
   }
   else if((round(%angle) == 9) || (round(%angle) == 171) || (round(%angle) == 189) || (round(%angle) == 351))
   {
      %answer = 0.156434;
      if((round(%angle) == 189) || (round(%angle) == 351))
      {
         %answer = -0.156434;
      }
      return %answer;
   }
   else if((round(%angle) == 10) || (round(%angle) == 170) || (round(%angle) == 190) || (round(%angle) == 350))
   {
      %answer = 0.173648;
      if((round(%angle) == 190) || (round(%angle) == 350))
      {
         %answer = -0.173648;
      }
      return %answer;
   }
   else if((round(%angle) == 11) || (round(%angle) == 169) || (round(%angle) == 191) || (round(%angle) == 349))
   {
      %answer = 0.190809;
      if((round(%angle) == 191) || (round(%angle) == 349))
      {
         %answer = -0.190809;
      }
      return %answer;
   }
   else if((round(%angle) == 12) || (round(%angle) == 168) || (round(%angle) == 192) || (round(%angle) == 348))
   {
      %answer = 0.207912;
      if((round(%angle) == 192) || (round(%angle) == 348))
      {
         %answer = -0.207912;
      }
      return %answer;
   }
   else if((round(%angle) == 13) || (round(%angle) == 167) || (round(%angle) == 193) || (round(%angle) == 347))
   {
      %answer = 0.224951;
      if((round(%angle) == 193) || (round(%angle) == 347))
      {
         %answer = -0.224951;
      }
      return %answer;
   }
   else if((round(%angle) == 14) || (round(%angle) == 166) || (round(%angle) == 194) || (round(%angle) == 346))
   {
      %answer = 0.241922;
      if((round(%angle) == 194) || (round(%angle) == 346))
      {
         %answer = -0.241922;
      }
      return %answer;
   }
   else if((round(%angle) == 15) || (round(%angle) == 165) || (round(%angle) == 195) || (round(%angle) == 345))
   {
      %answer = 0.258819;
      if((round(%angle) == 195) || (round(%angle) == 345))
      {
         %answer = -0.258819;
      }
      return %answer;
   }
   else if((round(%angle) == 16) || (round(%angle) == 164) || (round(%angle) == 196) || (round(%angle) == 344))
   {
      %answer = 0.275637;
      if((round(%angle) == 196) || (round(%angle) == 344))
      {
         %answer = -0.275637;
      }
      return %answer;
   }
   else if((round(%angle) == 17) || (round(%angle) == 163) || (round(%angle) == 197) || (round(%angle) == 343))
   {
      %answer = 0.292372;
      if((round(%angle) == 197) || (round(%angle) == 343))
      {
         %answer = -0.292372;
      }
      return %answer;
   }
   else if((round(%angle) == 18) || (round(%angle) == 162) || (round(%angle) == 198) || (round(%angle) == 342))
   {
      %answer = 0.309017;
      if((round(%angle) == 198) || (round(%angle) == 342))
      {
         %answer = -0.309017;
      }
      return %answer;
   }
   else if((round(%angle) == 19) || (round(%angle) == 161) || (round(%angle) == 199) || (round(%angle) == 341))
   {
      %answer = 0.325568;
      if((round(%angle) == 199) || (round(%angle) == 341))
      {
         %answer = -0.325568;
      }
      return %answer;
   }
   else if((round(%angle) == 20) || (round(%angle) == 160) || (round(%angle) == 200) || (round(%angle) == 340))
   {
      %answer = 0.342020;
      if((round(%angle) == 200) || (round(%angle) == 340))
      {
         %answer = -0.342020;
      }
      return %answer;
   }
   else
   {
      %answer = sin2(%angle);
      return %answer;
   }
}

function sin2(%angle)
{
   if((round(%angle) == 21) || (round(%angle) == 159) || (round(%angle) == 201) || (round(%angle) == 339))
   {
      %answer = 0.358368;
      if((round(%angle) == 201) || (round(%angle) == 339))
      {
         %answer = -0.358368;
      }
      return %answer;
   }
   else if((round(%angle) == 22) || (round(%angle) == 158) || (round(%angle) == 202) || (round(%angle) == 338))
   {
      %answer = 0.374607;
      if((round(%angle) == 202) || (round(%angle) == 338))
      {
         %answer = -0.374607;
      }
      return %answer;
   }
   else if((round(%angle) == 23) || (round(%angle) == 157) || (round(%angle) == 203) || (round(%angle) == 337))
   {
      %answer = 0.390731;
      if((round(%angle) == 203) || (round(%angle) == 337))
      {
         %answer = -0.390731;
      }
      return %answer;
   }
   else if((round(%angle) == 24) || (round(%angle) == 156) || (round(%angle) == 204) || (round(%angle) == 336))
   {
      %answer = 0.406737;
      if((round(%angle) == 204) || (round(%angle) == 336))
      {
         %answer = -0.406737;
      }
      return %answer;
   }
   else if((round(%angle) == 25) || (round(%angle) == 155) || (round(%angle) == 205) || (round(%angle) == 335))
   {
      %answer = 0.422618;
      if((round(%angle) == 205) || (round(%angle) == 335))
      {
         %answer = -0.422618;
      }
      return %answer;
   }
   else if((round(%angle) == 26) || (round(%angle) == 154) || (round(%angle) == 206) || (round(%angle) == 334))
   {
      %answer = 0.438371;
      if((round(%angle) == 206) || (round(%angle) == 334))
      {
         %answer = -0.438371;
      }
      return %answer;
   }
   else if((round(%angle) == 27) || (round(%angle) == 153) || (round(%angle) == 207) || (round(%angle) == 333))
   {
      %answer = 0.453990;
      if((round(%angle) == 207) || (round(%angle) == 333))
      {
         %answer = -0.453990;
      }
      return %answer;
   }
   else if((round(%angle) == 28) || (round(%angle) == 152) || (round(%angle) == 208) || (round(%angle) == 332))
   {
      %answer = 0.469472;
      if((round(%angle) == 208) || (round(%angle) == 332))
      {
         %answer = -0.469472;
      }
      return %answer;
   }
   else if((round(%angle) == 29) || (round(%angle) == 151) || (round(%angle) == 209) || (round(%angle) == 331))
   {
      %answer = 0.484810;
      if((round(%angle) == 209) || (round(%angle) == 331))
      {
         %answer = -0.484810;
      }
      return %answer;
   }
   else if((round(%angle) == 30) || (round(%angle) == 150) || (round(%angle) == 210) || (round(%angle) == 330))
   {
      %answer = 0.5;
      if((round(%angle) == 210) || (round(%angle) == 330))
      {
         %answer = -0.5;
      }
      return %answer;
   }
   else if((round(%angle) == 31) || (round(%angle) == 149) || (round(%angle) == 211) || (round(%angle) == 329))
   {
      %answer = 0.515038;
      if((round(%angle) == 211) || (round(%angle) == 329))
      {
         %answer = -0.515038;
      }
      return %answer;
   }
   else if((round(%angle) == 32) || (round(%angle) == 148) || (round(%angle) == 212) || (round(%angle) == 328))
   {
      %answer = 0.529919;
      if((round(%angle) == 212) || (round(%angle) == 328))
      {
         %answer = -0.529919;
      }
      return %answer;
   }
   else if((round(%angle) == 33) || (round(%angle) == 147) || (round(%angle) == 213) || (round(%angle) == 327))
   {
      %answer = 0.544639;
      if((round(%angle) == 213) || (round(%angle) == 327))
      {
         %answer = -0.544639;
      }
      return %answer;
   }
   else if((round(%angle) == 34) || (round(%angle) == 146) || (round(%angle) == 214) || (round(%angle) == 326))
   {
      %answer = 0.559193;
      if((round(%angle) == 214) || (round(%angle) == 326))
      {
         %answer = -0.559193;
      }
      return %answer;
   }
   else if((round(%angle) == 35) || (round(%angle) == 145) || (round(%angle) == 215) || (round(%angle) == 325))
   {
      %answer = 0.573576;
      if((round(%angle) == 215) || (round(%angle) == 325))
      {
         %answer = -0.573576;
      }
      return %answer;
   }
   else if((round(%angle) == 36) || (round(%angle) == 144) || (round(%angle) == 216) || (round(%angle) == 324))
   {
      %answer = 0.587785;
      if((round(%angle) == 216) || (round(%angle) == 324))
      {
         %answer = -0.587785;
      }
      return %answer;
   }
   else if((round(%angle) == 37) || (round(%angle) == 143) || (round(%angle) == 217) || (round(%angle) == 323))
   {
      %answer = 0.601815;
      if((round(%angle) == 217) || (round(%angle) == 323))
      {
         %answer = -0.601815;
      }
      return %answer;
   }
   else if((round(%angle) == 38) || (round(%angle) == 142) || (round(%angle) == 218) || (round(%angle) == 322))
   {
      %answer = 0.615661;
      if((round(%angle) == 218) || (round(%angle) == 322))
      {
         %answer = -0.615661;
      }
      return %answer;
   }
   else if((round(%angle) == 39) || (round(%angle) == 141) || (round(%angle) == 219) || (round(%angle) == 321))
   {
      %answer = 0.629320;
      if((round(%angle) == 219) || (round(%angle) == 321))
      {
         %answer = -0.629320;
      }
      return %answer;
   }
   else if((round(%angle) == 40) || (round(%angle) == 140) || (round(%angle) == 220) || (round(%angle) == 320))
   {
      %answer = 0.642788;
      if((round(%angle) == 220) || (round(%angle) == 320))
      {
         %answer = -0.642788;
      }
      return %answer;
   }
   else
   {
      %answer = sin3(%angle);      
      return %answer;
   }
}

function sin3(%angle)
{
   if((round(%angle) == 41) || (round(%angle) == 139) || (round(%angle) == 221) || (round(%angle) == 319))
   {
      %answer = 0.656059;
      if((round(%angle) == 221) || (round(%angle) == 319))
      {
         %answer = -0.656059;
      }
      return %answer;
   }
   else if((round(%angle) == 42) || (round(%angle) == 138) || (round(%angle) == 222) || (round(%angle) == 318))
   {
      %answer = 0.669131;
      if((round(%angle) == 222) || (round(%angle) == 318))
      {
         %answer = -0.669131;
      }
      return %answer;
   }
   else if((round(%angle) == 43) || (round(%angle) == 137) || (round(%angle) == 223) || (round(%angle) == 317))
   {
      %answer = 0.681998;
      if((round(%angle) == 223) || (round(%angle) == 317))
      {
         %answer = -0.681998;
      }
      return %answer;
   }
   else if((round(%angle) == 44) || (round(%angle) == 136) || (round(%angle) == 224) || (round(%angle) == 316))
   {
      %answer = 0.694658;
      if((round(%angle) == 224) || (round(%angle) == 316))
      {
         %answer = -0.694658;
      }
      return %answer;
   }
   else if((round(%angle) == 45) || (round(%angle) == 135) || (round(%angle) == 225) || (round(%angle) == 315))
   {
      %answer = 0.707107;
      if((round(%angle) == 225) || (round(%angle) == 315))
      {
         %answer = -0.707107;
      }
      return %answer;
   }
   else if((round(%angle) == 46) || (round(%angle) == 134) || (round(%angle) == 226) || (round(%angle) == 314))
   {
      %answer = 0.719340;
      if((round(%angle) == 226) || (round(%angle) == 314))
      {
         %answer = -0.719340;
      }
      return %answer;
   }
   else if((round(%angle) == 47) || (round(%angle) == 133) || (round(%angle) == 227) || (round(%angle) == 313))
   {
      %answer = 0.731354;
      if((round(%angle) == 227) || (round(%angle) == 313))
      {
         %answer = -0.731354;
      }
      return %answer;
   }
   else if((round(%angle) == 48) || (round(%angle) == 132) || (round(%angle) == 228) || (round(%angle) == 312))
   {
      %answer = 0.743145;
      if((round(%angle) == 228) || (round(%angle) == 312))
      {
         %answer = -0.743145;
      }
      return %answer;
   }
   else if((round(%angle) == 49) || (round(%angle) == 131) || (round(%angle) == 229) || (round(%angle) == 311))
   {
      %answer = 0.754710;
      if((round(%angle) == 229) || (round(%angle) == 311))
      {
         %answer = -0.754710;
      }
      return %answer;
   }
   else if((round(%angle) == 50) || (round(%angle) == 130) || (round(%angle) == 230) || (round(%angle) == 310))
   {
      %answer = 0.766044;
      if((round(%angle) == 230) || (round(%angle) == 310))
      {
         %answer = -0.766044;
      }
      return %answer;
   }
   else if((round(%angle) == 51) || (round(%angle) == 129) || (round(%angle) == 231) || (round(%angle) == 309))
   {
      %answer = 0.777146;
      if((round(%angle) == 231) || (round(%angle) == 309))
      {
         %answer = -0.777146;
      }
      return %answer;
   }
   else if((round(%angle) == 52) || (round(%angle) == 128) || (round(%angle) == 232) || (round(%angle) == 308))
   {
      %answer = 0.788011;
      if((round(%angle) == 232) || (round(%angle) == 308))
      {
         %answer = -0.788011;
      }
      return %answer;
   }
   else if((round(%angle) == 53) || (round(%angle) == 127) || (round(%angle) == 233) || (round(%angle) == 307))
   {
      %answer = 0.798636;
      if((round(%angle) == 233) || (round(%angle) == 307))
      {
         %answer = -0.798636;
      }
      return %answer;
   }
   else if((round(%angle) == 54) || (round(%angle) == 126) || (round(%angle) == 234) || (round(%angle) == 306))
   {
      %answer = 0.809017;
      if((round(%angle) == 234) || (round(%angle) == 306))
      {
         %answer = -0.809017;
      }
      return %answer;
   }
   else if((round(%angle) == 55) || (round(%angle) == 125) || (round(%angle) == 235) || (round(%angle) == 305))
   {
      %answer = 0.819152;
      if((round(%angle) == 235) || (round(%angle) == 305))
      {
         %answer = -0.819152;
      }
      return %answer;
   }
   else if((round(%angle) == 56) || (round(%angle) == 124) || (round(%angle) == 236) || (round(%angle) == 304))
   {
      %answer = 0.829038;
      if((round(%angle) == 236) || (round(%angle) == 304))
      {
         %answer = -0.829038;
      }
      return %answer;
   }
   else if((round(%angle) == 57) || (round(%angle) == 123) || (round(%angle) == 237) || (round(%angle) == 303))
   {
      %answer = 0.838671;
      if((round(%angle) == 237) || (round(%angle) == 303))
      {
         %answer = -0.838671;
      }
      return %answer;
   }
   else if((round(%angle) == 58) || (round(%angle) == 122) || (round(%angle) == 238) || (round(%angle) == 302))
   {
      %answer = 0.848048;
      if((round(%angle) == 238) || (round(%angle) == 302))
      {
         %answer = -0.848048;
      }
      return %answer;
   }
   else if((round(%angle) == 59) || (round(%angle) == 121) || (round(%angle) == 239) || (round(%angle) == 301))
   {
      %answer = 0.857167;
      if((round(%angle) == 239) || (round(%angle) == 301))
      {
         %answer = -0.857167;
      }
      return %answer;
   }
   else if((round(%angle) == 60) || (round(%angle) == 120) || (round(%angle) == 240) || (round(%angle) == 300))
   {
      %answer = 0.866025;
      if((round(%angle) == 240) || (round(%angle) == 300))
      {
         %answer = -0.866025;
      }
      return %answer;
   }   
   else
   {
      %answer = sin4(%angle);      
      return %answer;
   }
}

function sin4(%angle)
{
   if((round(%angle) == 61) || (round(%angle) == 119) || (round(%angle) == 241) || (round(%angle) == 299))
   {
      %answer = 0.874620;
      if((round(%angle) == 241) || (round(%angle) == 299))
      {
         %answer = -0.874620;
      }
      return %answer;
   }
   else if((round(%angle) == 62) || (round(%angle) == 118) || (round(%angle) == 242) || (round(%angle) == 298))
   {
      %answer = 0.882948;
      if((round(%angle) == 242) || (round(%angle) == 298))
      {
         %answer = -0.882948;
      }
      return %answer;
   }
   else if((round(%angle) == 63) || (round(%angle) == 117) || (round(%angle) == 243) || (round(%angle) == 297))
   {
      %answer = 0.891007;
      if((round(%angle) == 243) || (round(%angle) == 297))
      {
         %answer = -0.891007;
      }
      return %answer;
   }
   else if((round(%angle) == 64) || (round(%angle) == 116) || (round(%angle) == 244) || (round(%angle) == 296))
   {
      %answer = 0.898794;
      if((round(%angle) == 244) || (round(%angle) == 296))
      {
         %answer = -0.898794;
      }
      return %answer;
   }
   else if((round(%angle) == 65) || (round(%angle) == 115) || (round(%angle) == 245) || (round(%angle) == 295))
   {
      %answer = 0.906308;
      if((round(%angle) == 245) || (round(%angle) == 295))
      {
         %answer = -0.906308;
      }
      return %answer;
   }
   else if((round(%angle) == 66) || (round(%angle) == 114) || (round(%angle) == 246) || (round(%angle) == 294))
   {
      %answer = 0.913545;
      if((round(%angle) == 246) || (round(%angle) == 294))
      {
         %answer = -0.913545;
      }
      return %answer;
   }
   else if((round(%angle) == 67) || (round(%angle) == 113) || (round(%angle) == 247) || (round(%angle) == 293))
   {
      %answer = 0.920505;
      if((round(%angle) == 247) || (round(%angle) == 293))
      {
         %answer = -0.920505;
      }
      return %answer;
   }
   else if((round(%angle) == 68) || (round(%angle) == 112) || (round(%angle) == 248) || (round(%angle) == 292))
   {
      %answer = 0.927184;
      if((round(%angle) == 248) || (round(%angle) == 292))
      {
         %answer = -0.927184;
      }
      return %answer;
   }
   else if((round(%angle) == 69) || (round(%angle) == 111) || (round(%angle) == 249) || (round(%angle) == 291))
   {
      %answer = 0.933580;
      if((round(%angle) == 249) || (round(%angle) == 291))
      {
         %answer = -0.933580;
      }
      return %answer;
   }
   else if((round(%angle) == 70) || (round(%angle) == 110) || (round(%angle) == 250) || (round(%angle) == 290))
   {
      %answer = 0.939693;
      if((round(%angle) == 250) || (round(%angle) == 290))
      {
         %answer = -0.939693;
      }
      return %answer;
   }
   else if((round(%angle) == 71) || (round(%angle) == 109) || (round(%angle) == 251) || (round(%angle) == 289))
   {
      %answer = 0.945519;
      if((round(%angle) == 251) || (round(%angle) == 289))
      {
         %answer = -0.945519;
      }
      return %answer;
   }
   else if((round(%angle) == 72) || (round(%angle) == 108) || (round(%angle) == 252) || (round(%angle) == 288))
   {
      %answer = 0.951057;
      if((round(%angle) == 252) || (round(%angle) == 288))
      {
         %answer = -0.951057;
      }
      return %answer;
   }
   else if((round(%angle) == 73) || (round(%angle) == 107) || (round(%angle) == 253) || (round(%angle) == 287))
   {
      %answer = 0.956305;
      if((round(%angle) == 253) || (round(%angle) == 287))
      {
         %answer = -0.956305;
      }
      return %answer;
   }
   else if((round(%angle) == 74) || (round(%angle) == 106) || (round(%angle) == 254) || (round(%angle) == 286))
   {
      %answer = 0.961262;
      if((round(%angle) == 254) || (round(%angle) == 286))
      {
         %answer = -0.961262;
      }
      return %answer;
   }
   else if((round(%angle) == 75) || (round(%angle) == 105) || (round(%angle) == 255) || (round(%angle) == 285))
   {
      %answer = 0.965926;
      if((round(%angle) == 255) || (round(%angle) == 285))
      {
         %answer = -0.965926;
      }
      return %answer;
   }
   else if((round(%angle) == 76) || (round(%angle) == 104) || (round(%angle) == 256) || (round(%angle) == 284))
   {
      %answer = 0.970296;
      if((round(%angle) == 256) || (round(%angle) == 284))
      {
         %answer = -0.970296;
      }
      return %answer;
   }
   else if((round(%angle) == 77) || (round(%angle) == 103) || (round(%angle) == 257) || (round(%angle) == 283))
   {
      %answer = 0.974370;
      if((round(%angle) == 257) || (round(%angle) == 283))
      {
         %answer = -0.974370;
      }
      return %answer;
   }
   else if((round(%angle) == 78) || (round(%angle) == 102) || (round(%angle) == 258) || (round(%angle) == 282))
   {
      %answer = 0.978148;
      if((round(%angle) == 258) || (round(%angle) == 282))
      {
         %answer = -0.978148;
      }
      return %answer;
   }
   else if((round(%angle) == 79) || (round(%angle) == 101) || (round(%angle) == 259) || (round(%angle) == 281))
   {
      %answer = 0.981627;
      if((round(%angle) == 259) || (round(%angle) == 281))
      {
         %answer = -0.981627;
      }
      return %answer;
   }
   else if((round(%angle) == 80) || (round(%angle) == 100) || (round(%angle) == 260) || (round(%angle) == 280))
   {
      %answer = 0.984808;
      if((round(%angle) == 260) || (round(%angle) == 280))
      {
         %answer = -0.984808;
      }
      return %answer;
   }   
   else
   {
      %answer = sin5(%angle);      
      return %answer;
   }
}

function sin5(%angle)
{
   if((round(%angle) == 81) || (round(%angle) == 99) || (round(%angle) == 261) || (round(%angle) == 279))
   {
      %answer = 0.987688;
      if((round(%angle) == 261) || (round(%angle) == 279))
      {
         %answer = -0.987688;
      }
      return %answer;
   }
   else if((round(%angle) == 82) || (round(%angle) == 98) || (round(%angle) == 262) || (round(%angle) == 278))
   {
      %answer = 0.990268;
      if((round(%angle) == 262) || (round(%angle) == 278))
      {
         %answer = -0.990268;
      }
      return %answer;
   }
   else if((round(%angle) == 83) || (round(%angle) == 97) || (round(%angle) == 263) || (round(%angle) == 277))
   {
      %answer = 0.992546;
      if((round(%angle) == 263) || (round(%angle) == 277))
      {
         %answer = -0.992546;
      }
      return %answer;
   }
   else if((round(%angle) == 84) || (round(%angle) == 96) || (round(%angle) == 264) || (round(%angle) == 276))
   {
      %answer = 0.994522;
      if((round(%angle) == 264) || (round(%angle) == 276))
      {
         %answer = -0.994522;
      }
      return %answer;
   }
   else if((round(%angle) == 85) || (round(%angle) == 95) || (round(%angle) == 265) || (round(%angle) == 275))
   {
      %answer = 0.996195;
      if((round(%angle) == 265) || (round(%angle) == 275))
      {
         %answer = -0.996195;
      }
      return %answer;
   }
   else if((round(%angle) == 86) || (round(%angle) == 94) || (round(%angle) == 266) || (round(%angle) == 274))
   {
      %answer = 0.997564;
      if((round(%angle) == 266) || (round(%angle) == 274))
      {
         %answer = -0.997564;
      }
      return %answer;
   }
   else if((round(%angle) == 87) || (round(%angle) == 93) || (round(%angle) == 267) || (round(%angle) == 273))
   {
      %answer = 0.998630;
      if((round(%angle) == 267) || (round(%angle) == 273))
      {
         %answer = -0.998630;
      }
      return %answer;
   }
   else if((round(%angle) == 88) || (round(%angle) == 92) || (round(%angle) == 268) || (round(%angle) == 272))
   {
      %answer = 0.999391;
      if((round(%angle) == 268) || (round(%angle) == 272))
      {
         %answer = -0.999391;
      }
      return %answer;
   }
   else if((round(%angle) == 89) || (round(%angle) == 91) || (round(%angle) == 269) || (round(%angle) == 271))
   {
      %answer = 0.999848;
      if((round(%angle) == 269) || (round(%angle) == 271))
      {
         %answer = -0.999848;
      }
      return %answer;
   }
   else if((round(%angle) == 90) || (round(%angle) == 270))
   {
      %answer = 1;
      if(round(%angle) == 270)
      {
         %answer = -1;
      }
      return %answer;
   }
}

function cos(%angle)
{
   %angle = adjustAngle(%angle);
   if((round(%angle) == 0) || (round(%angle) == 180) || (round(%angle) == 360))
   {
      %answer = 1;
      if(round(%angle) == 180)
      {
         %answer = -1;
      }
      return %answer;
   }
   else if((round(%angle) == 1) || (round(%angle) == 179) || (round(%angle) == 181) || (round(%angle) == 359))
   {
      %answer = 0.999848;
      if((round(%angle) == 179) || (round(%angle) == 181))
      {
         %answer = -0.999848;
      }
      return %answer;
   }
   else if((round(%angle) == 2) || (round(%angle) == 178) || (round(%angle) == 182) || (round(%angle) == 358))
   {
      %answer = 0.999391;
      if((round(%angle) == 178) || (round(%angle) == 182))
      {
         %answer = -0.999391;
      }
      return %answer;
   }
   else if((round(%angle) == 3) || (round(%angle) == 177) || (round(%angle) == 183) || (round(%angle) == 357))
   {
      %answer = 0.998630;
      if((round(%angle) == 177) || (round(%angle) == 183))
      {
         %answer = -0.998630;
      }
      return %answer;
   }
   else if((round(%angle) == 4) || (round(%angle) == 176) || (round(%angle) == 184) || (round(%angle) == 356))
   {
      %answer = 0.997564;
      if((round(%angle) == 176) || (round(%angle) == 184))
      {
         %answer = -0.997564;
      }
      return %answer;
   }
   else if((round(%angle) == 5) || (round(%angle) == 175) || (round(%angle) == 185) || (round(%angle) == 355))
   {
      %answer = 0.996195;
      if((round(%angle) == 175) || (round(%angle) == 185))
      {
         %answer = -0.996195;
      }
      return %answer;
   }
   else if((round(%angle) == 6) || (round(%angle) == 174) || (round(%angle) == 186) || (round(%angle) == 354))
   {
      %answer = 0.994522;
      if((round(%angle) == 174) || (round(%angle) == 186))
      {
         %answer = -0.994522;
      }
      return %answer;
   }
   else if((round(%angle) == 7) || (round(%angle) == 173) || (round(%angle) == 187) || (round(%angle) == 353))
   {
      %answer = 0.992546;
      if((round(%angle) == 173) || (round(%angle) == 187))
      {
         %answer = -0.992546;
      }
      return %answer;
   }
   else if((round(%angle) == 8) || (round(%angle) == 172) || (round(%angle) == 188) || (round(%angle) == 352))
   {
      %answer = 0.990268;
      if((round(%angle) == 172) || (round(%angle) == 188))
      {
         %answer = -0.990268;
      }
      return %answer;
   }
   else if((round(%angle) == 9) || (round(%angle) == 171) || (round(%angle) == 189) || (round(%angle) == 351))
   {
      %answer = 0.987688;
      if((round(%angle) == 171) || (round(%angle) == 189))
      {
         %answer = -0.987688;
      }
      return %answer;
   }
   else if((round(%angle) == 10) || (round(%angle) == 170) || (round(%angle) == 190) || (round(%angle) == 350))
   {
      %answer = 0.984808;
      if((round(%angle) == 170) || (round(%angle) == 190))
      {
         %answer = -0.984808;
      }
      return %answer;
   }
   else if((round(%angle) == 11) || (round(%angle) == 169) || (round(%angle) == 191) || (round(%angle) == 349))
   {
      %answer = 0.981627;
      if((round(%angle) == 169) || (round(%angle) == 191))
      {
         %answer = -0.981627;
      }
      return %answer;
   }
   else if((round(%angle) == 12) || (round(%angle) == 168) || (round(%angle) == 192) || (round(%angle) == 348))
   {
      %answer = 0.978148;
      if((round(%angle) == 168) || (round(%angle) == 192))
      {
         %answer = -0.978148;
      }
      return %answer;
   }
   else if((round(%angle) == 13) || (round(%angle) == 167) || (round(%angle) == 193) || (round(%angle) == 347))
   {
      %answer = 0.974370;
      if((round(%angle) == 167) || (round(%angle) == 193))
      {
         %answer = -0.974370;
      }
      return %answer;
   }
   else if((round(%angle) == 14) || (round(%angle) == 166) || (round(%angle) == 194) || (round(%angle) == 346))
   {
      %answer = 0.970296;
      if((round(%angle) == 166) || (round(%angle) == 194))
      {
         %answer = -0.970296;
      }
      return %answer;
   }
   else if((round(%angle) == 15) || (round(%angle) == 165) || (round(%angle) == 195) || (round(%angle) == 345))
   {
      %answer = 0.965926;
      if((round(%angle) == 165) || (round(%angle) == 195))
      {
         %answer = -0.965926;
      }
      return %answer;
   }
   else if((round(%angle) == 16) || (round(%angle) == 164) || (round(%angle) == 196) || (round(%angle) == 344))
   {
      %answer = 0.961262;
      if((round(%angle) == 164) || (round(%angle) == 196))
      {
         %answer = -0.961262;
      }
      return %answer;
   }
   else if((round(%angle) == 17) || (round(%angle) == 163) || (round(%angle) == 197) || (round(%angle) == 343))
   {
      %answer = 0.956305;
      if((round(%angle) == 163) || (round(%angle) == 197))
      {
         %answer = -0.956305;
      }
      return %answer;
   }
   else if((round(%angle) == 18) || (round(%angle) == 162) || (round(%angle) == 198) || (round(%angle) == 342))
   {
      %answer = 0.951057;
      if((round(%angle) == 162) || (round(%angle) == 198))
      {
         %answer = -0.951057;
      }
      return %answer;
   }
   else if((round(%angle) == 19) || (round(%angle) == 161) || (round(%angle) == 199) || (round(%angle) == 341))
   {
      %answer = 0.945519;
      if((round(%angle) == 161) || (round(%angle) == 199))
      {
         %answer = -0.945519;
      }
      return %answer;
   }
   else if((round(%angle) == 20) || (round(%angle) == 160) || (round(%angle) == 200) || (round(%angle) == 340))
   {
      %answer = 0.939693;
      if((round(%angle) == 160) || (round(%angle) == 200))
      {
         %answer = -0.939693;
      }
      return %answer;
   }
   else
   {
      %answer = cos2(%angle);
      return %answer;
   }
}

function cos2(%angle)
{
   if((round(%angle) == 21) || (round(%angle) == 159) || (round(%angle) == 201) || (round(%angle) == 339))
   {
      %answer = 0.933580;
      if((round(%angle) == 159) || (round(%angle) == 201))
      {
         %answer = -0.933580;
      }
      return %answer;
   }
   else if((round(%angle) == 22) || (round(%angle) == 158) || (round(%angle) == 202) || (round(%angle) == 338))
   {
      %answer = 0.927184;
      if((round(%angle) == 158) || (round(%angle) == 202))
      {
         %answer = -0.927184;
      }
      return %answer;
   }
   else if((round(%angle) == 23) || (round(%angle) == 157) || (round(%angle) == 203) || (round(%angle) == 337))
   {
      %answer = 0.920505;
      if((round(%angle) == 157) || (round(%angle) == 203))
      {
         %answer = -0.920505;
      }
      return %answer;
   }
   else if((round(%angle) == 24) || (round(%angle) == 156) || (round(%angle) == 204) || (round(%angle) == 336))
   {
      %answer = 0.913545;
      if((round(%angle) == 156) || (round(%angle) == 204))
      {
         %answer = -0.913545;
      }
      return %answer;
   }
   else if((round(%angle) == 25) || (round(%angle) == 155) || (round(%angle) == 205) || (round(%angle) == 335))
   {
      %answer = 0.906308;
      if((round(%angle) == 155) || (round(%angle) == 205))
      {
         %answer = -0.906308;
      }
      return %answer;
   }
   else if((round(%angle) == 26) || (round(%angle) == 154) || (round(%angle) == 206) || (round(%angle) == 334))
   {
      %answer = 0.898794;
      if((round(%angle) == 154) || (round(%angle) == 206))
      {
         %answer = -0.898794;
      }
      return %answer;
   }
   else if((round(%angle) == 27) || (round(%angle) == 153) || (round(%angle) == 207) || (round(%angle) == 333))
   {
      %answer = 0.891007;
      if((round(%angle) == 153) || (round(%angle) == 207))
      {
         %answer = -0.891007;
      }
      return %answer;
   }
   else if((round(%angle) == 28) || (round(%angle) == 152) || (round(%angle) == 208) || (round(%angle) == 332))
   {
      %answer = 0.882948;
      if((round(%angle) == 152) || (round(%angle) == 208))
      {
         %answer = -0.882948;
      }
      return %answer;
   }
   else if((round(%angle) == 29) || (round(%angle) == 151) || (round(%angle) == 209) || (round(%angle) == 331))
   {
      %answer = 0.874620;
      if((round(%angle) == 151) || (round(%angle) == 209))
      {
         %answer = -0.874620;
      }
      return %answer;
   }
   else if((round(%angle) == 30) || (round(%angle) == 150) || (round(%angle) == 210) || (round(%angle) == 330))
   {
      %answer = 0.866025;
      if((round(%angle) == 150) || (round(%angle) == 210))
      {
         %answer = -0.866025;
      }
      return %answer;
   }
   else if((round(%angle) == 31) || (round(%angle) == 149) || (round(%angle) == 211) || (round(%angle) == 329))
   {
      %answer = 0.857167;
      if((round(%angle) == 149) || (round(%angle) == 211))
      {
         %answer = -0.857167;
      }
      return %answer;
   }
   else if((round(%angle) == 32) || (round(%angle) == 148) || (round(%angle) == 212) || (round(%angle) == 328))
   {
      %answer = 0.848048;
      if((round(%angle) == 148) || (round(%angle) == 212))
      {
         %answer = -0.848048;
      }
      return %answer;
   }
   else if((round(%angle) == 33) || (round(%angle) == 147) || (round(%angle) == 213) || (round(%angle) == 327))
   {
      %answer = 0.838671;
      if((round(%angle) == 147) || (round(%angle) == 213))
      {
         %answer = -0.838671;
      }
      return %answer;
   }
   else if((round(%angle) == 34) || (round(%angle) == 146) || (round(%angle) == 214) || (round(%angle) == 326))
   {
      %answer = 0.829038;
      if((round(%angle) == 146) || (round(%angle) == 214))
      {
         %answer = -0.829038;
      }
      return %answer;
   }
   else if((round(%angle) == 35) || (round(%angle) == 145) || (round(%angle) == 215) || (round(%angle) == 325))
   {
      %answer = 0.819152;
      if((round(%angle) == 145) || (round(%angle) == 215))
      {
         %answer = -0.819152;
      }
      return %answer;
   }
   else if((round(%angle) == 36) || (round(%angle) == 144) || (round(%angle) == 216) || (round(%angle) == 324))
   {
      %answer = 0.809017;
      if((round(%angle) == 144) || (round(%angle) == 216))
      {
         %answer = -0.809017;
      }
      return %answer;
   }
   else if((round(%angle) == 37) || (round(%angle) == 143) || (round(%angle) == 217) || (round(%angle) == 323))
   {
      %answer = 0.798636;
      if((round(%angle) == 143) || (round(%angle) == 217))
      {
         %answer = -0.798636;
      }
      return %answer;
   }
   else if((round(%angle) == 38) || (round(%angle) == 142) || (round(%angle) == 218) || (round(%angle) == 322))
   {
      %answer = 0.788011;
      if((round(%angle) == 142) || (round(%angle) == 218))
      {
         %answer = -0.788011;
      }
      return %answer;
   }
   else if((round(%angle) == 39) || (round(%angle) == 141) || (round(%angle) == 219) || (round(%angle) == 321))
   {
      %answer = 0.777146;
      if((round(%angle) == 141) || (round(%angle) == 219))
      {
         %answer = -0.777146;
      }
      return %answer;
   }
   else if((round(%angle) == 40) || (round(%angle) == 140) || (round(%angle) == 220) || (round(%angle) == 320))
   {
      %answer = 0.766044;
      if((round(%angle) == 140) || (round(%angle) == 220))
      {
         %answer = -0.766044;
      }
      return %answer;
   }
   else
   {
      %answer = cos3(%angle);      
      return %answer;
   }
}

function cos3(%angle)
{
   if((round(%angle) == 41) || (round(%angle) == 139) || (round(%angle) == 221) || (round(%angle) == 319))
   {
      %answer = 0.754710;
      if((round(%angle) == 139) || (round(%angle) == 221))
      {
         %answer = -0.754710;
      }
      return %answer;
   }
   else if((round(%angle) == 42) || (round(%angle) == 138) || (round(%angle) == 222) || (round(%angle) == 318))
   {
      %answer = 0.743145;
      if((round(%angle) == 138) || (round(%angle) == 222))
      {
         %answer = -0.743145;
      }
      return %answer;
   }
   else if((round(%angle) == 43) || (round(%angle) == 137) || (round(%angle) == 223) || (round(%angle) == 317))
   {
      %answer = 0.731354;
      if((round(%angle) == 137) || (round(%angle) == 223))
      {
         %answer = -0.731354;
      }
      return %answer;
   }
   else if((round(%angle) == 44) || (round(%angle) == 136) || (round(%angle) == 224) || (round(%angle) == 316))
   {
      %answer = 0.719340;
      if((round(%angle) == 136) || (round(%angle) == 224))
      {
         %answer = -0.719340;
      }
      return %answer;
   }
   else if((round(%angle) == 45) || (round(%angle) == 135) || (round(%angle) == 225) || (round(%angle) == 315))
   {
      %answer = 0.707107;
      if((round(%angle) == 135) || (round(%angle) == 225))
      {
         %answer = -0.707107;
      }
      return %answer;
   }
   else if((round(%angle) == 46) || (round(%angle) == 134) || (round(%angle) == 226) || (round(%angle) == 314))
   {
      %answer = 0.694658;
      if((round(%angle) == 134) || (round(%angle) == 226))
      {
         %answer = -0.694658;
      }
      return %answer;
   }
   else if((round(%angle) == 47) || (round(%angle) == 133) || (round(%angle) == 227) || (round(%angle) == 313))
   {
      %answer = 0.681998;
      if((round(%angle) == 133) || (round(%angle) == 227))
      {
         %answer = -0.681998;
      }
      return %answer;
   }
   else if((round(%angle) == 48) || (round(%angle) == 132) || (round(%angle) == 228) || (round(%angle) == 312))
   {
      %answer = 0.669131;
      if((round(%angle) == 132) || (round(%angle) == 228))
      {
         %answer = -0.669131;
      }
      return %answer;
   }
   else if((round(%angle) == 49) || (round(%angle) == 131) || (round(%angle) == 229) || (round(%angle) == 311))
   {
      %answer = 0.656059;
      if((round(%angle) == 131) || (round(%angle) == 229))
      {
         %answer = -0.656059;
      }
      return %answer;
   }
   else if((round(%angle) == 50) || (round(%angle) == 130) || (round(%angle) == 230) || (round(%angle) == 310))
   {
      %answer = 0.642788;
      if((round(%angle) == 130) || (round(%angle) == 230))
      {
         %answer = -0.642788;
      }
      return %answer;
   }
   else if((round(%angle) == 51) || (round(%angle) == 129) || (round(%angle) == 231) || (round(%angle) == 309))
   {
      %answer = 0.629320;
      if((round(%angle) == 129) || (round(%angle) == 231))
      {
         %answer = -0.629320;
      }
      return %answer;
   }
   else if((round(%angle) == 52) || (round(%angle) == 128) || (round(%angle) == 232) || (round(%angle) == 308))
   {
      %answer = 0.615661;
      if((round(%angle) == 128) || (round(%angle) == 232))
      {
         %answer = -0.615661;
      }
      return %answer;
   }
   else if((round(%angle) == 53) || (round(%angle) == 127) || (round(%angle) == 233) || (round(%angle) == 307))
   {
      %answer = 0.601815;
      if((round(%angle) == 127) || (round(%angle) == 233))
      {
         %answer = -0.601815;
      }
      return %answer;
   }
   else if((round(%angle) == 54) || (round(%angle) == 126) || (round(%angle) == 234) || (round(%angle) == 306))
   {
      %answer = 0.587785;
      if((round(%angle) == 126) || (round(%angle) == 234))
      {
         %answer = -0.587785;
      }
      return %answer;
   }
   else if((round(%angle) == 55) || (round(%angle) == 125) || (round(%angle) == 235) || (round(%angle) == 305))
   {
      %answer = 0.573576;
      if((round(%angle) == 125) || (round(%angle) == 235))
      {
         %answer = -0.573576;
      }
      return %answer;
   }
   else if((round(%angle) == 56) || (round(%angle) == 124) || (round(%angle) == 236) || (round(%angle) == 304))
   {
      %answer = 0.559193;
      if((round(%angle) == 124) || (round(%angle) == 236))
      {
         %answer = -0.559193;
      }
      return %answer;
   }
   else if((round(%angle) == 57) || (round(%angle) == 123) || (round(%angle) == 237) || (round(%angle) == 303))
   {
      %answer = 0.544639;
      if((round(%angle) == 123) || (round(%angle) == 237))
      {
         %answer = -0.544639;
      }
      return %answer;
   }
   else if((round(%angle) == 58) || (round(%angle) == 122) || (round(%angle) == 238) || (round(%angle) == 302))
   {
      %answer = 0.529919;
      if((round(%angle) == 122) || (round(%angle) == 238))
      {
         %answer = -0.529919;
      }
      return %answer;
   }
   else if((round(%angle) == 59) || (round(%angle) == 121) || (round(%angle) == 239) || (round(%angle) == 301))
   {
      %answer = 0.515038;
      if((round(%angle) == 121) || (round(%angle) == 239))
      {
         %answer = -0.515038;
      }
      return %answer;
   }
   else if((round(%angle) == 60) || (round(%angle) == 120) || (round(%angle) == 240) || (round(%angle) == 300))
   {
      %answer = 0.5;
      if((round(%angle) == 120) || (round(%angle) == 240))
      {
         %answer = -0.5;
      }
      return %answer;
   }   
   else
   {
      %answer = cos4(%angle);      
      return %answer;
   }
}

function cos4(%angle)
{
   if((round(%angle) == 61) || (round(%angle) == 119) || (round(%angle) == 241) || (round(%angle) == 299))
   {
      %answer = 0.484810;
      if((round(%angle) == 119) || (round(%angle) == 241))
      {
         %answer = -0.484810;
      }
      return %answer;
   }
   else if((round(%angle) == 62) || (round(%angle) == 118) || (round(%angle) == 242) || (round(%angle) == 298))
   {
      %answer = 0.469472;
      if((round(%angle) == 118) || (round(%angle) == 242))
      {
         %answer = -0.469472;
      }
      return %answer;
   }
   else if((round(%angle) == 63) || (round(%angle) == 117) || (round(%angle) == 243) || (round(%angle) == 297))
   {
      %answer = 0.453990;
      if((round(%angle) == 117) || (round(%angle) == 243))
      {
         %answer = -0.453990;
      }
      return %answer;
   }
   else if((round(%angle) == 64) || (round(%angle) == 116) || (round(%angle) == 244) || (round(%angle) == 296))
   {
      %answer = 0.438371;
      if((round(%angle) == 116) || (round(%angle) == 244))
      {
         %answer = -0.438371;
      }
      return %answer;
   }
   else if((round(%angle) == 65) || (round(%angle) == 115) || (round(%angle) == 245) || (round(%angle) == 295))
   {
      %answer = 0.422618;
      if((round(%angle) == 115) || (round(%angle) == 245))
      {
         %answer = -0.422618;
      }
      return %answer;
   }
   else if((round(%angle) == 66) || (round(%angle) == 114) || (round(%angle) == 246) || (round(%angle) == 294))
   {
      %answer = 0.406737;
      if((round(%angle) == 114) || (round(%angle) == 246))
      {
         %answer = -0.406737;
      }
      return %answer;
   }
   else if((round(%angle) == 67) || (round(%angle) == 113) || (round(%angle) == 247) || (round(%angle) == 293))
   {
      %answer = 0.390731;
      if((round(%angle) == 113) || (round(%angle) == 247))
      {
         %answer = -0.390731;
      }
      return %answer;
   }
   else if((round(%angle) == 68) || (round(%angle) == 112) || (round(%angle) == 248) || (round(%angle) == 292))
   {
      %answer = 0.374607;
      if((round(%angle) == 112) || (round(%angle) == 248))
      {
         %answer = -0.374607;
      }
      return %answer;
   }
   else if((round(%angle) == 69) || (round(%angle) == 111) || (round(%angle) == 249) || (round(%angle) == 291))
   {
      %answer = 0.358368;
      if((round(%angle) == 111) || (round(%angle) == 249))
      {
         %answer = -0.358368;
      }
      return %answer;
   }
   else if((round(%angle) == 70) || (round(%angle) == 110) || (round(%angle) == 250) || (round(%angle) == 290))
   {
      %answer = 0.342020;
      if((round(%angle) == 110) || (round(%angle) == 250))
      {
         %answer = -0.342020;
      }
      return %answer;
   }
   else if((round(%angle) == 71) || (round(%angle) == 109) || (round(%angle) == 251) || (round(%angle) == 289))
   {
      %answer = 0.325568;
      if((round(%angle) == 109) || (round(%angle) == 251))
      {
         %answer = -0.325568;
      }
      return %answer;
   }
   else if((round(%angle) == 72) || (round(%angle) == 108) || (round(%angle) == 252) || (round(%angle) == 288))
   {
      %answer = 0.309017;
      if((round(%angle) == 108) || (round(%angle) == 252))
      {
         %answer = -0.309017;
      }
      return %answer;
   }
   else if((round(%angle) == 73) || (round(%angle) == 107) || (round(%angle) == 253) || (round(%angle) == 287))
   {
      %answer = 0.292372;
      if((round(%angle) == 107) || (round(%angle) == 253))
      {
         %answer = -0.292372;
      }
      return %answer;
   }
   else if((round(%angle) == 74) || (round(%angle) == 106) || (round(%angle) == 254) || (round(%angle) == 286))
   {
      %answer = 0.275637;
      if((round(%angle) == 106) || (round(%angle) == 254))
      {
         %answer = -0.275637;
      }
      return %answer;
   }
   else if((round(%angle) == 75) || (round(%angle) == 105) || (round(%angle) == 255) || (round(%angle) == 285))
   {
      %answer = 0.258819;
      if((round(%angle) == 105) || (round(%angle) == 255))
      {
         %answer = -0.258819;
      }
      return %answer;
   }
   else if((round(%angle) == 76) || (round(%angle) == 104) || (round(%angle) == 256) || (round(%angle) == 284))
   {
      %answer = 0.241922;
      if((round(%angle) == 104) || (round(%angle) == 256))
      {
         %answer = -0.241922;
      }
      return %answer;
   }
   else if((round(%angle) == 77) || (round(%angle) == 103) || (round(%angle) == 257) || (round(%angle) == 283))
   {
      %answer = 0.224951;
      if((round(%angle) == 103) || (round(%angle) == 257))
      {
         %answer = -0.224951;
      }
      return %answer;
   }
   else if((round(%angle) == 78) || (round(%angle) == 102) || (round(%angle) == 258) || (round(%angle) == 282))
   {
      %answer = 0.207912;
      if((round(%angle) == 102) || (round(%angle) == 258))
      {
         %answer = -0.207912;
      }
      return %answer;
   }
   else if((round(%angle) == 79) || (round(%angle) == 101) || (round(%angle) == 259) || (round(%angle) == 281))
   {
      %answer = 0.190809;
      if((round(%angle) == 101) || (round(%angle) == 259))
      {
         %answer = -0.190809;
      }
      return %answer;
   }
   else if((round(%angle) == 80) || (round(%angle) == 100) || (round(%angle) == 260) || (round(%angle) == 280))
   {
      %answer = 0.173648;
      if((round(%angle) == 100) || (round(%angle) == 260))
      {
         %answer = -0.173648;
      }
      return %answer;
   }   
   else
   {
      %answer = cos5(%angle);      
      return %answer;
   }
}

function cos5(%angle)
{
   if((round(%angle) == 81) || (round(%angle) == 99) || (round(%angle) == 261) || (round(%angle) == 279))
   {
      %answer = 0.156434;
      if((round(%angle) == 99) || (round(%angle) == 261))
      {
         %answer = -0.156434;
      }
      return %answer;
   }
   else if((round(%angle) == 82) || (round(%angle) == 98) || (round(%angle) == 262) || (round(%angle) == 278))
   {
      %answer = 0.139173;
      if((round(%angle) == 98) || (round(%angle) == 262))
      {
         %answer = -0.139173;
      }
      return %answer;
   }
   else if((round(%angle) == 83) || (round(%angle) == 97) || (round(%angle) == 263) || (round(%angle) == 277))
   {
      %answer = 0.121869;
      if((round(%angle) == 97) || (round(%angle) == 263))
      {
         %answer = -0.121869;
      }
      return %answer;
   }
   else if((round(%angle) == 84) || (round(%angle) == 96) || (round(%angle) == 264) || (round(%angle) == 276))
   {
      %answer = 0.104528;
      if((round(%angle) == 96) || (round(%angle) == 264))
      {
         %answer = -0.104528;
      }
      return %answer;
   }
   else if((round(%angle) == 85) || (round(%angle) == 95) || (round(%angle) == 265) || (round(%angle) == 275))
   {
      %answer = 0.087156;
      if((round(%angle) == 95) || (round(%angle) == 265))
      {
         %answer = -0.087156;
      }
      return %answer;
   }
   else if((round(%angle) == 86) || (round(%angle) == 94) || (round(%angle) == 266) || (round(%angle) == 274))
   {
      %answer = 0.069756;
      if((round(%angle) == 94) || (round(%angle) == 266))
      {
         %answer = -0.069756;
      }
      return %answer;
   }
   else if((round(%angle) == 87) || (round(%angle) == 93) || (round(%angle) == 267) || (round(%angle) == 273))
   {
      %answer = 0.052336;
      if((round(%angle) == 93) || (round(%angle) == 267))
      {
         %answer = -0.052336;
      }
      return %answer;
   }
   else if((round(%angle) == 88) || (round(%angle) == 92) || (round(%angle) == 268) || (round(%angle) == 272))
   {
      %answer = 0.034899;
      if((round(%angle) == 92) || (round(%angle) == 268))
      {
         %answer = -0.034899;
      }
      return %answer;
   }
   else if((round(%angle) == 89) || (round(%angle) == 91) || (round(%angle) == 269) || (round(%angle) == 271))
   {
      %answer = 0.017452;
      if((round(%angle) == 91) || (round(%angle) == 269))
      {
         %answer = -0.017452;
      }
      return %answer;
   }
   else if((round(%angle) == 90) || (round(%angle) == 270))
   {
      %answer = 0;
      return %answer;
   }
}

function getVector(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);   
   if((%tan >= -0.008728)&&(%tan < 0.008728))
   {
      if(%deltaX > 0)
      {
         %angle = 0;
      }
      else if(%deltaX < 0)
      {
         %angle = 180;
      }
      return %angle;
   }
   else if((%tan >= 0.008728)&&(%tan < 0.026188))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 1;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 181;
      }
      return %angle;
   }
   else if((%tan >= 0.026188)&&(%tan < 0.043664))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 2;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 182;
      }
      return %angle;
   }
   else if((%tan >= 0.043664)&&(%tan < 0.061167))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 3;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 183;
      }
      return %angle;
   }
   else if((%tan >= 0.061167)&&(%tan < 0.078708))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 4;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 184;
      }
      return %angle;
   }
   else if((%tan >= 0.078708)&&(%tan < 0.096296))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 5;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 185;
      }
      return %angle;
   }
   else if((%tan >= 0.096296)&&(%tan < 0.113944))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 6;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 186;
      }
      return %angle;
   }
   else if((%tan >= 0.113944)&&(%tan < 0.131663))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 7;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 187;
      }
      return %angle;
   }
   else if((%tan >= 0.131663)&&(%tan < 0.149463))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 8;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 188;
      }
      return %angle;
   }
   else if((%tan >= 0.149463)&&(%tan < 0.167356))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 9;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 189;
      }
      return %angle;
   }
   else if((%tan >= 0.167356)&&(%tan < 0.185354))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 10;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 190;
      }
      return %angle;
   }
   else if((%tan >= 0.185354)&&(%tan < 0.203468))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 11;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 191;
      }
      return %angle;
   }
   else if((%tan >= 0.203468)&&(%tan < 0.221712))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 12;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 192;
      }
      return %angle;
   }
   else if((%tan >= 0.221712)&&(%tan < 0.240098))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 13;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 193;
      }
      return %angle;
   }
   else if((%tan >= 0.240098)&&(%tan < 0.258639))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 14;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 194;
      }
      return %angle;
   }
   else if((%tan >= 0.258639)&&(%tan < 0.277347))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 15;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 195;
      }
      return %angle;
   }
   else if((%tan >= 0.277347)&&(%tan < 0.296238))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 16;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 196;
      }
      return %angle;
   }
   else if((%tan >= 0.296238)&&(%tan < 0.315325))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 17;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 197;
      }
      return %angle;
   }
   else if((%tan >= 0.315325)&&(%tan < 0.334624))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 18;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 198;
      }
      return %angle;
   }
   else if((%tan >= 0.334624)&&(%tan < 0.354149))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 19;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 199;
      }
      return %angle;
   }
   else if((%tan >= 0.354149)&&(%tan < 0.373917))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 20;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 200;
      }
      return %angle;
   }
   else
   {
      getVector2(%deltaX, %deltaY);
   }
}

function getVector2(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 0.373917)&&(%tan < 0.393945))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 21;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 201;
      }
      return %angle;
   }
   else if((%tan >= 0.393945)&&(%tan < 0.414251))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 22;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 202;
      }
      return %angle;
   }
   else if((%tan >= 0.414251)&&(%tan < 0.434852))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 23;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 203;
      }
      return %angle;
   }
   else if((%tan >= 0.434852)&&(%tan < 0.455768))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 24;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 204;
      }
      return %angle;
   }
   else if((%tan >= 0.455768)&&(%tan < 0.477020))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 25;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 205;
      }
      return %angle;
   }
   else if((%tan >= 0.477020)&&(%tan < 0.498629))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 26;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 206;
      }
      return %angle;
   }
   else if((%tan >= 0.498629)&&(%tan < 0.520617))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 27;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 207;
      }
      return %angle;
   }
   else if((%tan >= 0.520617)&&(%tan < 0.543009))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 28;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 208;
      }
      return %angle;
   }
   else if((%tan >= 0.543009)&&(%tan < 0.565830))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 29;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 209;
      }
      return %angle;
   }
   else if((%tan >= 0.565830)&&(%tan < 0.589105))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 30;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 210;
      }
      return %angle;
   }
   else if((%tan >= 0.589105)&&(%tan < 0.612865))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 31;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 211;
      }
      return %angle;
   }
   else if((%tan >= 0.612865)&&(%tan < 0.637138))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 32;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 212;
      }
      return %angle;
   }
   else if((%tan >= 0.637138)&&(%tan < 0.661958))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 33;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 213;
      }
      return %angle;
   }
   else if((%tan >= 0.661958)&&(%tan < 0.687358))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 34;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 214;
      }
      return %angle;
   }
   else if((%tan >= 0.687358)&&(%tan < 0.713375))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 35;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 215;
      }
      return %angle;
   }
   else if((%tan >= 0.713375)&&(%tan < 0.740048))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 36;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 216;
      }
      return %angle;
   }
   else if((%tan >= 0.740048)&&(%tan < 0.767420))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 37;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 217;
      }
      return %angle;
   }
   else if((%tan >= 0.767420)&&(%tan < 0.795535))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 38;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 218;
      }
      return %angle;
   }
   else if((%tan >= 0.795535)&&(%tan < 0.824442))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 39;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 219;
      }
      return %angle;
   }
   else if((%tan >= 0.824442)&&(%tan < 0.854193))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 40;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 220;
      }
      return %angle;
   }
   else
   {
      getVector3(%deltaX, %deltaY);
   }
}

function getVector3(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 0.854193)&&(%tan < 0.884845))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 41;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 221;
      }
      return %angle;
   }
   else if((%tan >= 0.884845)&&(%tan < 0.916460))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 42;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 222;
      }
      return %angle;
   }
   else if((%tan >= 0.916460)&&(%tan < 0.949102))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 43;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 223;
      }
      return %angle;
   }
   else if((%tan >= 0.949102)&&(%tan < 0.982844))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 44;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 224;
      }
      return %angle;
   }
   else if((%tan >= 0.982844)&&(%tan < 1.017765))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 45;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 225;
      }
      return %angle;
   }
   else if((%tan >= 1.017765)&&(%tan < 1.053950))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 46;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 226;
      }
      return %angle;
   }
   else if((%tan >= 1.053950)&&(%tan < 1.091491))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 47;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 227;
      }
      return %angle;
   }
   else if((%tan >= 1.091491)&&(%tan < 1.130490))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 48;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 228;
      }
      return %angle;
   }
   else if((%tan >= 1.130490)&&(%tan < 1.171061))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 49;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 229;
      }
      return %angle;
   }
   else if((%tan >= 1.171061)&&(%tan < 1.213325))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 50;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 230;
      }
      return %angle;
   }
   else if((%tan >= 1.213325)&&(%tan < 1.257419))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 51;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 231;
      }
      return %angle;
   }
   else if((%tan >= 1.257419)&&(%tan < 1.303493))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 52;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 232;
      }
      return %angle;
   }
   else if((%tan >= 1.303493)&&(%tan < 1.351713))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 53;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 233;
      }
      return %angle;
   }
   else if((%tan >= 1.351713)&&(%tan < 1.402265))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 54;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 234;
      }
      return %angle;
   }
   else if((%tan >= 1.402265)&&(%tan < 1.455354))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 55;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 235;
      }
      return %angle;
   }
   else if((%tan >= 1.455354)&&(%tan < 1.511213))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 56;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 236;
      }
      return %angle;
   }
   else if((%tan >= 1.511213)&&(%tan < 1.570100))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 57;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 237;
      }
      return %angle;
   }
   else if((%tan >= 1.570100)&&(%tan < 1.632307))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 58;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 238;
      }
      return %angle;
   }
   else if((%tan >= 1.632307)&&(%tan < 1.698165))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 59;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 239;
      }
      return %angle;
   }
   else if((%tan >= 1.698165)&&(%tan < 1.768049))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 60;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 240;
      }
      return %angle;
   }
   else
   {
      getVector4(%deltaX, %deltaY);
   }
}

function getVector4(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 1.768049)&&(%tan < 1.842387))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 61;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 241;
      }
      return %angle;
   }
   else if((%tan >= 1.842387)&&(%tan < 1.921668))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 62;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 242;
      }
      return %angle;
   }
   else if((%tan >= 1.921668)&&(%tan < 2.006457))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 63;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 243;
      }
      return %angle;
   }
   else if((%tan >= 2.006457)&&(%tan < 2.097405))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 64;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 244;
      }
      return %angle;
   }
   else if((%tan >= 2.097405)&&(%tan < 2.195272))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 65;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 245;
      }
      return %angle;
   }
   else if((%tan >= 2.195272)&&(%tan < 2.300945))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 66;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 246;
      }
      return %angle;
   }
   else if((%tan >= 2.300945)&&(%tan < 2.415470))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 67;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 247;
      }
      return %angle;
   }
   else if((%tan >= 2.415470)&&(%tan < 2.540088))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 68;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 248;
      }
      return %angle;
   }
   else if((%tan >= 2.540088)&&(%tan < 2.676283))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 69;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 249;
      }
      return %angle;
   }
   else if((%tan >= 2.676283)&&(%tan < 2.825844))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 70;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 250;
      }
      return %angle;
   }
   else if((%tan >= 2.825844)&&(%tan < 2.990947))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 71;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 251;
      }
      return %angle;
   }
   else if((%tan >= 2.990947)&&(%tan < 3.174268))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 72;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 252;
      }
      return %angle;
   }
   else if((%tan >= 3.174268)&&(%tan < 3.379134))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 73;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 253;
      }
      return %angle;
   }
   else if((%tan >= 3.379134)&&(%tan < 3.609733))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 74;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 254;
      }
      return %angle;
   }
   else if((%tan >= 3.609733)&&(%tan < 3.871416))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 75;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 255;
      }
      return %angle;
   }
   else if((%tan >= 3.871416)&&(%tan < 4.171128))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 76;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 256;
      }
      return %angle;
   }
   else if((%tan >= 4.171128)&&(%tan < 4.518053))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 77;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 257;
      }
      return %angle;
   }
   else if((%tan >= 4.518053)&&(%tan < 4.924592))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 78;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 258;
      }
      return %angle;
   }
   else if((%tan >= 4.924592)&&(%tan < 5.407918))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 79;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 259;
      }
      return %angle;
   }
   else if((%tan >= 5.407918)&&(%tan < 5.992517))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 80;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 260;
      }
      return %angle;
   }
   else
   {
      getVector5(%deltaX, %deltaY);
   }
}

function getVector5(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 5.992517)&&(%tan < 6.714561))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 81;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 261;
      }
      return %angle;
   }
   else if((%tan >= 6.714561)&&(%tan < 7.629858))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 82;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 262;
      }
      return %angle;
   }
   else if((%tan >= 7.629858)&&(%tan < 8.829355))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 83;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 263;
      }
      return %angle;
   }
   else if((%tan >= 8.829355)&&(%tan < 10.472208))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 84;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 264;
      }
      return %angle;
   }
   else if((%tan >= 10.472208)&&(%tan < 12.865359))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 85;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 265;
      }
      return %angle;
   }
   else if((%tan >= 12.865359)&&(%tan < 16.690901))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 86;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 266;
      }
      return %angle;
   }
   else if((%tan >= 16.690901)&&(%tan < 23.858695))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 87;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 267;
      }
      return %angle;
   }
   else if((%tan >= 23.858695)&&(%tan < 42.963107))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 88;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 268;
      }
      return %angle;
   }
   else if(%tan >= 42.963107)
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 89;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 269;
      }
      return %angle;
   }
   else if(%deltaX == 0)
   {
      if(%deltaY > 0)
      {
         %angle = 90;
      }
      else if(%deltaY < 0)
      {
         %angle = 270;
      }
      return %angle;
   }
   else if(%tan < -42.963107)
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 91;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 271;
      }
      return %angle;
   }
   else if((%tan < -23.858695)&&(%tan >= -42.963107))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 92;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 272;
      }
      return %angle;
   }
   else if((%tan < -16.690901)&&(%tan >= -23.858695))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 93;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 273;
      }
      return %angle;
   }
   else if((%tan < -12.865359)&&(%tan >= -16.690901))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 94;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 274;
      }
      return %angle;
   }
   else if((%tan < -10.472208)&&(%tan >= -12.865359))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 95;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 275;
      }
      return %angle;
   }
   else if((%tan < -8.829355)&&(%tan >= -10.472208))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 96;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 276;
      }
      return %angle;
   }
   else if((%tan < -7.629858)&&(%tan >= -8.829355))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 97;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 277;
      }
      return %angle;
   }
   else if((%tan < -6.714561)&&(%tan >= -7.629858))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 98;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 278;
      }
      return %angle;
   }
   else if((%tan < -5.992517)&&(%tan >= -6.714561))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 99;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 279;
      }
      return %angle;
   }
   else if((%tan < -5.407918)&&(%tan >= -5.992517))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 100;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 280;
      }
      return %angle;
   }
   else
   {
      getVector6(%deltaX, %deltaY);
   }
}

function getVector6(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -4.924592)&&(%tan >= -5.407918))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 101;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 281;
      }
      return %angle;
   }
   else if((%tan < -4.518053)&&(%tan >= -4.924592))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 102;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 282;
      }
      return %angle;
   }
   else if((%tan < -4.171128)&&(%tan >= -4.518053))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 103;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 283;
      }
      return %angle;
   }
   else if((%tan < -3.871416)&&(%tan >= -4.171128))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 104;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 284;
      }
      return %angle;
   }
   else if((%tan < -3.609733)&&(%tan >= -3.871416))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 105;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 285;
      }
      return %angle;
   }
   else if((%tan < -3.379134)&&(%tan >= -3.609733))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 106;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 286;
      }
      return %angle;
   }
   else if((%tan < -3.174268)&&(%tan >= -3.379134))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 107;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 287;
      }
      return %angle;
   }
   else if((%tan < -2.990947)&&(%tan >= -3.174268))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 108;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 288;
      }
      return %angle;
   }
   else if((%tan < -2.825844)&&(%tan >= -2.990947))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 109;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 289;
      }
      return %angle;
   }
   else if((%tan < -2.676283)&&(%tan >= -2.825844))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 110;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 290;
      }
      return %angle;
   }
   else if((%tan < -2.540088)&&(%tan >= -2.676283))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 111;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 291;
      }
      return %angle;
   }
   else if((%tan < -2.415470)&&(%tan >= -2.540088))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 112;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 292;
      }
      return %angle;
   }
   else if((%tan < -2.300945)&&(%tan >= -2.415470))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 113;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 293;
      }
      return %angle;
   }
   else if((%tan < -2.195272)&&(%tan >= -2.300945))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 114;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 294;
      }
      return %angle;
   }
   else if((%tan < -2.097405)&&(%tan >= -2.195272))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 115;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 295;
      }
      return %angle;
   }
   else if((%tan < -2.006457)&&(%tan >= -2.097405))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 116;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 296;
      }
      return %angle;
   }
   else if((%tan < -1.921668)&&(%tan >= -2.006457))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 117;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 297;
      }
      return %angle;
   }
   else if((%tan < -1.842387)&&(%tan >= -1.921668))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 118;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 298;
      }
      return %angle;
   }
   else if((%tan < -1.768049)&&(%tan >= -1.842387))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 119;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 299;
      }
      return %angle;
   }
   else if((%tan < -1.698165)&&(%tan >= -1.768049))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 120;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 300;
      }
      return %angle;
   }
   else
   {
      getVector7(%deltaX, %deltaY);
   }
}

function getVector7(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -1.632307)&&(%tan >= -1.698165))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 121;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 301;
      }
      return %angle;
   }
   else if((%tan < -1.570100)&&(%tan >= -1.632307))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 122;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 302;
      }
      return %angle;
   }
   else if((%tan < -1.511213)&&(%tan >= -1.570100))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 123;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 303;
      }
      return %angle;
   }
   else if((%tan < -1.455354)&&(%tan >= -1.511213))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 124;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 304;
      }
      return %angle;
   }
   else if((%tan < -1.402265)&&(%tan >= -1.455354))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 125;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 305;
      }
      return %angle;
   }
   else if((%tan < -1.351713)&&(%tan >= -1.402265))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 126;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 306;
      }
      return %angle;
   }
   else if((%tan < -1.303493)&&(%tan >= -1.351713))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 127;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 307;
      }
      return %angle;
   }
   else if((%tan < -1.257419)&&(%tan >= -1.303493))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 128;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 308;
      }
      return %angle;
   }
   else if((%tan < -1.213325)&&(%tan >= -1.257419))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 129;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 309;
      }
      return %angle;
   }
   else if((%tan < -1.171061)&&(%tan >= -1.213325))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 130;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 310;
      }
      return %angle;
   }
   else if((%tan < -1.130490)&&(%tan >= -1.171061))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 131;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 311;
      }
      return %angle;
   }
   else if((%tan < -1.091491)&&(%tan >= -1.130490))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 132;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 312;
      }
      return %angle;
   }
   else if((%tan < -1.053950)&&(%tan >= -1.091491))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 133;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 313;
      }
      return %angle;
   }
   else if((%tan < -1.017765)&&(%tan >= -1.053950))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 134;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 314;
      }
      return %angle;
   }
   else if((%tan < -0.982844)&&(%tan >= -1.017765))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 135;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 315;
      }
      return %angle;
   }
   else if((%tan < -0.949102)&&(%tan >= -0.982844))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 136;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 316;
      }
      return %angle;
   }
   else if((%tan < -0.916460)&&(%tan >= -0.949102))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 137;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 317;
      }
      return %angle;
   }
   else if((%tan < -0.884845)&&(%tan >= -0.916460))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 138;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 318;
      }
      return %angle;
   }
   else if((%tan < -0.854193)&&(%tan >= -0.884845))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 139;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 319;
      }
      return %angle;
   }
   else if((%tan < -0.824442)&&(%tan >= -0.854193))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 140;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 320;
      }
      return %angle;
   }
   else
   {
      getVector8(%deltaX, %deltaY);
   }
}

function getVector8(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -0.795535)&&(%tan >= -0.824442))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 141;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 321;
      }
      return %angle;
   }
   else if((%tan < -0.767420)&&(%tan >= -0.795535))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 142;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 322;
      }
      return %angle;
   }
   else if((%tan < -0.740048)&&(%tan >= -0.767420))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 143;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 323;
      }
      return %angle;
   }
   else if((%tan < -0.713375)&&(%tan >= -0.740048))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 144;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 324;
      }
      return %angle;
   }
   else if((%tan < -0.687358)&&(%tan >= -0.713375))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 145;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 325;
      }
      return %angle;
   }
   else if((%tan < -0.661958)&&(%tan >= -0.687358))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 146;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 326;
      }
      return %angle;
   }
   else if((%tan < -0.637138)&&(%tan >= -0.661958))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 147;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 327;
      }
      return %angle;
   }
   else if((%tan < -0.612865)&&(%tan >= -0.637138))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 148;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 328;
      }
      return %angle;
   }
   else if((%tan < -0.589105)&&(%tan >= -0.612865))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 149;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 329;
      }
      return %angle;
   }
   else if((%tan < -0.565830)&&(%tan >= -0.589105))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 150;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 330;
      }
      return %angle;
   }
   else if((%tan < -0.543009)&&(%tan >= -0.565830))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 151;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 331;
      }
      return %angle;
   }
   else if((%tan < -0.520617)&&(%tan >= -0.543009))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 152;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 332;
      }
      return %angle;
   }
   else if((%tan < -0.498629)&&(%tan >= -0.520617))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 153;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 333;
      }
      return %angle;
   }
   else if((%tan < -0.477020)&&(%tan >= -0.498629))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 154;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 334;
      }
      return %angle;
   }
   else if((%tan < -0.455768)&&(%tan >= -0.477020))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 155;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 335;
      }
      return %angle;
   }
   else if((%tan < -0.434852)&&(%tan >= -0.455768))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 156;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 336;
      }
      return %angle;
   }
   else if((%tan < -0.414251)&&(%tan >= -0.434852))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 157;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 337;
      }
      return %angle;
   }
   else if((%tan < -0.393945)&&(%tan >= -0.414251))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 158;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 338;
      }
      return %angle;
   }
   else if((%tan < -0.373917)&&(%tan >= -0.393945))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 159;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 339;
      }
      return %angle;
   }
   else if((%tan < -0.354149)&&(%tan >= -0.373917))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 160;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 340;
      }
      return %angle;
   }
   else
   {
      getVector9(%deltaX, %deltaY);
   }
}

function getVector9(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -0.334624)&&(%tan >= -0.354149))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 161;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 341;
      }
      return %angle;
   }
   else if((%tan < -0.315325)&&(%tan >= -0.334624))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 162;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 342;
      }
      return %angle;
   }
   else if((%tan < -0.296238)&&(%tan >= -0.315325))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 163;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 343;
      }
      return %angle;
   }
   else if((%tan < -0.277347)&&(%tan >= -0.296238))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 164;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 344;
      }
      return %angle;
   }
   else if((%tan < -0.258639)&&(%tan >= -0.277347))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 165;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 345;
      }
      return %angle;
   }
   else if((%tan < -0.240098)&&(%tan >= -0.258639))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 166;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 346;
      }
      return %angle;
   }
   else if((%tan < -0.221712)&&(%tan >= -0.240098))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 167;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 347;
      }
      return %angle;
   }
   else if((%tan < -0.203468)&&(%tan >= -0.221712))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 168;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 348;
      }
      return %angle;
   }
   else if((%tan < -0.185354)&&(%tan >= -0.203468))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 169;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 349;
      }
      return %angle;
   }
   else if((%tan < -0.167356)&&(%tan >= -0.185354))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 170;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 350;
      }
      return %angle;
   }
   else if((%tan < -0.149463)&&(%tan >= -0.167356))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 171;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 351;
      }
      return %angle;
   }
   else if((%tan < -0.131663)&&(%tan >= -0.149463))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 172;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 352;
      }
      return %angle;
   }
   else if((%tan < -0.113944)&&(%tan >= -0.131663))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 173;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 353;
      }
      return %angle;
   }
   else if((%tan < -0.096296)&&(%tan >= -0.113944))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 174;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 354;
      }
      return %angle;
   }
   else if((%tan < -0.078708)&&(%tan >= -0.096296))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 175;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 355;
      }
      return %angle;
   }
   else if((%tan < -0.061167)&&(%tan >= -0.078708))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 176;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 356;
      }
      return %angle;
   }
   else if((%tan < -0.043664)&&(%tan >= -0.061167))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 177;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 357;
      }
      return %angle;
   }
   else if((%tan < -0.026188)&&(%tan >= -0.043664))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 178;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 358;
      }
      return %angle;
   }
   else if((%tan < -0.008728)&&(%tan >= -0.026188))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 179;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 359;
      }
      return %angle;
   }
}