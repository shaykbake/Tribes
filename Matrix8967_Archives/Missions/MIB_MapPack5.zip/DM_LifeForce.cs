// FILENAME:	DM_LifeForce.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "DM_LifeForce";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	desertSounds();
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/")&&($server::TeamPlay == false))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
        say(%player, 0, "Welcome to DeathMatch LifeForce! Scan another player's vehicle to heal him, but it uses some of your health to do so. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   }
   else if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/")&&($server::TeamPlay == true))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
        say(%player, 0, "Welcome to Team DeathMatch LifeForce! Scan a teammate's vehicle to heal him, but it uses some of your health to do so. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   }
   else
   {
      if($server::TeamPlay == false)
      {
         say(%player, 0, "Welcome to DeathMatch LifeForce! Scan another player's vehicle to heal him, but it uses some of your health to do so. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
      }
      else if($server::TeamPlay == true)
      {
         say(%player, 0, "Welcome to Team DeathMatch LifeForce! Scan a teammate's vehicle to heal him, but it uses some of your health to do so. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
      }
   }
}

function player::onremove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   if($server::TeamPlay == true)
   {
      if(getTeam(%vehicleId) == *IDSTR_TEAM_BLUE)
      {
         setNavMarker("MissionGroup/RedBase/RedNav", true, %vehicleId);
      }
      else
      {
         setNavMarker("MissionGroup/BlueBase/BlueNav", true, %vehicleId);
      }
   }
}

function onMissionLoad()
{
   cdAudioCycle("Mechsoul", "NewTech", "Terror"); 
   if($server::TeamPlay == false)
   {
      setGameInfo("<F2>GAME TYPE:<F0>  DeathMatch\n\n<F2>MISSION:<F0>  DM_LifeForce\n\nWelcome to DeathMatch LifeForce! Scan another player's vehicle to heal him, but it uses some of your health to do so. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   }
   else
   {
      setGameInfo("<F2>GAME TYPE:<F0>  Team DeathMatch\n\n<F2>MISSION:<F0>  DM_LifeForce\n\nWelcome to Team DeathMatch LifeForce! Scan a teammate's vehicle to heal him, but it uses some of your health to do so. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   }
}

function vehicle::onscan(%scanned,%scanner)
{  
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if($server::TeamPlay == false)
   {
   healobject(%scanned,5000);
   reloadobject(%scanned,5000);
   say(0,0,"<f5>"@gethudname(%scanner)@" transfered some of his lifeforce to "@gethudname(%scanned)@".");
   healobject(%scanner,-3000);
   reloadobject(%scanner,-15);
   }
   else if($server::TeamPlay == true)
   {
      if(getteam(%scanned)!=getteam(%scanner))
      {
         say(%player,%player,"<f5>You cannot heal "@gethudname(%scanned)@". He is not on your team!");
      }
      else
      {
         healobject(%scanned,5000);
         reloadobject(%scanned,5000);
         say(0,0,"<f5>"@gethudname(%scanner)@" transfered some of his lifeforce to "@gethudname(%scanned)@".");
         healobject(%scanner,-3000);
         reloadobject(%scanner,-15);
      }
   }
}