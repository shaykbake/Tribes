// FILENAME:	TDM_Bunkers.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "TDM_Bunkers";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	marsSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to Team DeathMatch Bunkers! Use the bunkers for cover & the towers for sniping. Enter the towers by walking under them. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

function ZenTransporter::trigger::onContact(%this, %object)
{
	setPosition(%object, 1167.82, -560.213, 858);
}

function ZenTransporter2::trigger::onContact(%this, %object)
{
	setPosition(%object, 463.076, -575.612, 858);
}

function ZenTransporter3::trigger::onContact(%this, %object)
{
	setPosition(%object, 1072.38, 1743.04, 791);
}

function ZenTransporter4::trigger::onContact(%this, %object)
{
	setPosition(%object, 386.72, 2161.59, 819);
}