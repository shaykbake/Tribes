// FILENAME:	H&S_Labyrinth.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "H&S_Labyrinth";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function setDefaultMissionItems()
{
   allowComponent(                                        all, TRUE  );
   allowComponent(                                        400, FALSE  );
   allowComponent(                                        401, FALSE  );
   allowComponent(                                        408, FALSE  );
   allowComponent(                                        409, FALSE  );
   allowComponent(                                        410, FALSE  );
   allowComponent(                                        411, FALSE  );
   allowComponent(                                        412, FALSE  );
   allowComponent(                                        413, FALSE  );
   allowComponent(                                        414, FALSE  );
   allowComponent(                                        426, FALSE  );
   allowComponent(                                        427, FALSE  );
   allowComponent(                                        428, FALSE  );
   allowComponent(                                        429, FALSE  );
   allowComponent(                                        430, FALSE  );
   allowComponent(                                        431, FALSE  );
   allowComponent(                                        432, FALSE  );
   allowComponent(                                        433, FALSE  );
   allowComponent(                                        434, FALSE  );
}

function onMissionStart()
{
      $killPoints = 0;
      $deathPoints = 2;
      $healRate = 100;   
	$ammoRate = 3;
   	$padWaitTime = 45;
  	$zenWaitTime = 90;

	marsSounds();	
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Hide & Seek (H&S)! Find other players & \"tag\" them to destroy them. To tag an enemy vehicle, lock onto your target & scan him with the \" I \" key. Radar is NOT allowed. Tags are worth 3 points & deaths are worth -2. You DO NOT recieve points for normal kills. You can download H&S_Labyrinth & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.points = 0;
}

function vehicle::onAdd(%vehicleId)
{
   setVehicleRadarVisible(%vehicleId, false);
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
// left over from missionStdLib.cs
//   vehicle::onDestroyedLog(%destroyed, %destroyer);
//   
// this is weird but %destroyer isn't necessarily a vehicle
//   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
//   if(%message != "")
//   {
//      say( 0, 0, %message);
//   }
//   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if(
         (getTeam(%destroyed) == getTeam(%destroyer)) &&
         (%destroyed != %destroyer)
      )
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function onMissionLoad()
{
   cdAudioCycle("SS3", "SS4", "Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Hide & Seek\n\n<F2>MISSION:<F0>  H&S_Labyrinth\n\nWelcome to Hide & Seek (H&S)! Find other players & \"tag\" them to destroy them. To tag an enemy vehicle, lock onto your target & scan him with the \" <F3>I<F0> \" key. Radar is NOT allowed. Tags are worth <F3>3<F0> points & deaths are worth <F3>-2<F0>. You DO NOT recieve points for normal kills. You can download H&S_Labyrinth & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.points = 0;
   }
}

function vehicle::OnScan(%scanned, %scanner, %string)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(($server::TeamPlay == true) && (getTeam(%scanner) == getTeam(%scanned)))
   {  
      say(%player, %player, getHudName(%scanned) @ " is on your team!");
   }
   else
   {
      healObject(%scanned, -10000);
	healObject(%scanned, -10000);
	healObject(%scanned, -10000);
	healObject(%scanned, -10000);
	healObject(%scanned, -10000);
      %player.points = %player.points + 3;
      say("everybody", 0, getHudName(%scanned) @ " was tagged by " @ getHudName(%scanner) @ "!");
   } 
}

function getPlayerScore(%player)
{
   return((%player.points) + (getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints));
}