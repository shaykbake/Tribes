// FILENAME:	DM_ThunderStorm.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "DM_ThunderStorm";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

// move the map
$server::HudMapViewOffsetX = 4646;
$server::HudMapViewOffsetY = 942;

function onMissionStart()
{
   temperateSounds();
   stormsounds();
   $StormStarted = false;
   $bolt = getObjectId("MissionGroup\\Bolt");
   $rod1 = getObjectId("MissionGroup\\Rods\\rod1");
   $rod2 = getObjectId("MissionGroup\\Rods\\rod2");
   $rod3 = getObjectId("MissionGroup\\Rods\\rod3");
   $rod4 = getObjectId("MissionGroup\\Rods\\rod4");
   $rod5 = getObjectId("MissionGroup\\Rods\\rod5");
   $rod6 = getObjectId("MissionGroup\\Rods\\rod6");
   $rod7 = getObjectId("MissionGroup\\Rods\\rod7");
   $rod8 = getObjectId("MissionGroup\\Rods\\rod8");
   $rod9 = getObjectId("MissionGroup\\Rods\\rod9");
   $rod10 = getObjectId("MissionGroup\\Rods\\rod10");
}

function onMissionLoad()
{
   cdAudioCycle("Terror", "Cyberntx", "Cloudburst","Mechsoul","Watching"); 
}

function player::onadd(%player)
{
   %player.spawned = false;
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player,0,"Welcome to DeathMatch ThunderStorm! Severe thunderstorms have been detected in the area. Watch out for lightning strikes! You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.","sfx_thunder1.wav");
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %player.spawned = true;
   if($StormStarted==false)
   {
      $StormStarted = true;
      schedule("storm();",15);
      unAnimate();
   }   
}

function storm()
{
   %count = playerManager::getPlayerCount();
   if(%count<3)
   {
      %random1 = randomint(1,3);
      if((%random1==1) && (%count>1))
      {
         %num = 0;
         %random2 = randomInt(1,%count);   
         for(%i=0;%i<%count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %num++;
            if(%num==%random2)
            {
               strike(%player);
            }
         }
      }
      else
      {
         strikeRod();
      }
   }
   else
   {
      %random1 = randomint(1,2);
      if(%random1==1)
      {
         %num = 0;
         %random2 = randomInt(1,%count);   
         for(%i=0;%i<%count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %num++;
            if(%num==%random2)
            {
               strike(%player);
            }
         }
      }
      else
      {
         strikeRod();
      }
   }
}

function strike(%player)
{
   %target = playermanager::playernumtovehicleid(%player);
   %x = getposition(%target,x);
   %y = getposition(%target,y);
   %z = getposition(%target,z)-150;
   setposition($bolt,%x,%y,%z);
   if(%player.spawned==true)
   {
      say(0,2,"<f1>"@getname(%player)@" got struck by lightning!","sfx_thunder1.wav");
   }
   else if(%player.spawned==false)
   {
      playsound(0,"sfx_thunder1.wav",IDPRF_2D);
   }
   damagearea(%target,0,0,0,150,1000);
   fadeevent(%player,in,0.3,1,1,1);
   schedule("fadeevent("@%player@",in,0.3,1,1,1);",0.7);
   schedule("fadeevent("@%player@",in,0.3,1,1,1);",1.2);
   schedule("setposition($bolt,8000,-12000,-1000);",1.3);
   %count = playermanager::getPlayerCount();
   for(%i=0;%i<%count; %i++)
   {
      %player2 = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playernumtovehicleId(%player2);
      if((getDistance(%vehicleId,%target)<=300) && (%vehicleId!=%target))
      {
         fadeevent(%player2,in,0.3,1,1,1);
         schedule("fadeevent("@%player2@",in,0.3,1,1,1);",0.7);
      }
   }
   %time = randomInt(20,90);
   schedule("storm();",%time);
}

function strikeRod()
{
   %random = randomInt(1,10);
   if(%random==1)
   {
      %rod = $rod1;
   }
   else if(%random==2)
   {
      %rod = $rod2;
   }
   else if(%random==3)
   {
      %rod = $rod3;
   }
   else if(%random==4)
   {
      %rod = $rod4;
   }
   else if(%random==5)
   {
      %rod = $rod5;
   }
   else if(%random==6)
   {
      %rod = $rod6;
   }
   else if(%random==7)
   {
      %rod = $rod7;
   }
   else if(%random==8)
   {
      %rod = $rod8;
   }
   else if(%random==9)
   {
      %rod = $rod9;
   }
   else if(%random==10)
   {
      %rod = $rod10;
   }
   %x = getposition(%rod,x);
   %y = getposition(%rod,y);
   %z = getposition(%rod,z)-150;
   setposition($bolt,%x,%y,%z);
   damagearea(%rod,0,0,0,150,1000);
   playsound(0,"sfx_thunder1.wav",IDPRF_2D);
   schedule("setposition($bolt,8000,-12000,-1000);",1.3);
   %count = playermanager::getPlayerCount();
   for(%i=0;%i<%count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playernumtovehicleId(%player);
      if(getDistance(%vehicleId,%rod)<=300)
      {
         fadeevent(%player,in,0.3,1,1,1);
         schedule("fadeevent("@%player@",in,0.3,1,1,1);",0.7);
      }
   }
   %time = randomInt(20,90);
   schedule("storm();",%time);

}

function Animate()
{
   playAnimSequence($rod8,0,true);
   schedule("unAnimate();",60);
}

function unAnimate()
{
   playAnimSequence($rod8,0,false);
   schedule("Animate();",60);
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   %player2.spawned = false;
   if(%player == 0)
   {
      say(0,0,"<f0>" @ getname(%destroyed) @ " died.");
   }
   else
   {   
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
      // enforce the rules
      if($server::TeamPlay == true)
      {
         if((getTeam(%destroyed) == getTeam(%destroyer))&&(%destroyed != %destroyer))
         {
            antiTeamKill(%destroyer);
         }
      }   
   }
}