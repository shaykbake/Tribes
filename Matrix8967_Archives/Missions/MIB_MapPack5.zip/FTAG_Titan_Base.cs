// FILENAME:	 FTAG_Titan_Base.cs
//
// AUTHOR:  	 Gen. Raven [M.I.B.]
//
// RANDOM THOUGHT: COOKIE COOKIE COOKIE COOKIE COOKIE COOKIE COOKIE!
//                 COOKIE COOKIE COOKIE COOKIE COOKIE COOKIE COOKIE!
//                 COOKIE COOKIE COOKIE COOKIE COOKIE COOKIE COOKIE!
//                
//                 ...I bet right now you want cookies.
//------------------------------------------------------------------------------

$missionName = "FTAG_Titan_Base";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
      $server::disableTeamRed = false;
      $server::disableTeamBlue = false;
      $server::disableTeamYellow = true;
      $server::disableTeamPurple = true;

   // Time limit
      $server::TimeLimit = 20;
}

function onMissionStart()
{
	titanSounds();
     
      $startTime = getCurrentTime(); 
 
      $flag = getobjectId("MissionGroup\\blueflag");
      $CenterNav = getobjectId("MissionGroup\\CenterNav");
      $gamestart = false;
      $triggeron = true;
      $flagholder = "nobody";

      $healRate = 100;   
	$ammoRate = 3;
   	$padWaitTime = 45;
  	$zenWaitTime = 90;
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Flag Tag\n\n<F2>MISSION:<F0>  FTAG_Titan_Base\n\nWelcome to Flag Tag (FTAG)! After there is at least 2 players in the game, grab the flag & hold it to score 1 point each second. There are no points awarded for kills, so you must have the flag to score. You can steal the flag by killing the flagholder. Padkilling the flagholder is encouraged. If you go 600 meters away from Nav Alpha, you will be killed for going out of bounds. You can download FTAG_Titan_Base & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.score = 0;
   }
}

function player::onadd(%this) 
{
   say(%this, 0, "Welcome to Flag Tag! Check the game info tab for the rules. You can download FTAG_Titan_Base & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %this.score = 0;
}

function vehicle::onadd(%vehicleId)
{
   %vehicleId.name = getHUDName(%vehicleId);
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId); 
   %player.spawn = true;
 
   %now = getCurrentTime(); 
   %totalTime = ($server::TimeLimit * 60); 
   %timeLeft = (%totalTime - (%now - $startTime));
   setHudTimer(%timeLeft, -1, "Mission Time Left", 1, %player); 
}

function player::onRemove(%this)
{
   if(playerManager::getPlayerCount()==2)
   {
      messageBox("Everybody", "All other players have left the game. You are the winner!");
      schedule("missionEndConditionMet();", 5);
   }
   else if(playerManager::getPlayerCount()==1)
   {
      schedule("missionEndConditionMet();", 1);
   }
}

function flag::trigger::onEnter(%this,%object)
{
   if(($triggeron == true) && ($gamestart == false) && (playerManager::getPlayerCount()>=2))
   {      
      setvehiclespecialidentity(%object, on, red);
      setshapevisibility($flag, false);
      $gamestart = true;
      $triggeron = false;
      $flagholder = %object;
      scoreflagholder();
      say("everybody",1, "<f5>" @ %object.name @ " has the flag!");
   }
   else if(($triggeron == true) && ($gamestart == false) && (playerManager::getPlayerCount()<2))
   {
      say("everybody",1,"<f5>There must be two players in the server before you can play!");
   }
   else if(($triggeron == true) && ($gamestart == true))
   {
      setvehiclespecialidentity(%object, on, red);
      setshapevisibility($flag, false);
      $triggeron = false;
      $flagholder = %object;
      say("everybody",1, "<f5>" @ %object.name @ " has the flag!");
   } 
}

function scoreflagholder()
{
   %player = playerManager::vehicleIdToPlayerNum($flagholder);
   %player.score++;
   %distance = getdistance($flagholder, $CenterNav);
  
   if(%distance >= 1500) // Flag tag boundary
   {
      healobject($flagholder, -50000);
      say("everybody",1, "<f5>The Flag Holder went out of bounds!"); 
   }
   schedule("scoreflagholder();",1);
}     
     
function vehicle::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   %player2.spawn=false;
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if(
         (getTeam(%destroyed) == getTeam(%destroyer)) &&
         (%destroyed != %destroyer)
      )
      {
         antiTeamKill(%destroyer);
      }
   }   
   if((%destroyed == $flagholder) && (%player.spawn == true))
   {
      $flagholder = %destroyer;
      setvehiclespecialidentity(%destroyer, on, red);
      say("everybody",1, "<f5>" @ %destroyer.name @ " has the flag!");
   }
   else if((%destroyed == $flagholder) && (%player.spawn == false))
   {
      $flagholder = "nobody";
      setshapevisibility($flag, true);
      $triggeron = true;
      say("everybody",1,"<f5>The flag has been returned to Nav Alpha!");
   }
}
   
function getPlayerScore(%player) 
{ 
   return(%player.score);
}    

function onMissionEnd()
{
   flushConsoleScheduler();
}

// Take away light, fast hercs so they cant run around like crazy.
function setDefaultMissionItems()
{
   allowVehicle(all, true); // All Hercs
   allowVehicle(4, false);  // No talons
   allowVehicle(13, false); // No knight's talons
   allowVehicle(20, false); // No seekers
   allowVehicle(35, false); // No metagen seekers
   allowVehicle(21, false); // No goads
   allowVehicle(36, false); // No metagen goads

// No Tracking weapons 
   allowWeapon(all, true);
   allowWeapon(124, false);
   allowWeapon(125, false);
   allowWeapon(126, false);
   allowWeapon(127, false);
   allowWeapon(128, false);
   allowWeapon(129, false);
   allowWeapon(130, false);
   allowWeapon(131, false);
   allowWeapon(132, false);
   allowWeapon(133, false);
   allowWeapon(147, false);
   allowWeapon(150, false);   
}

// Healing Pad Functionality
//------------------------------------------------------------------------------
function ZenHeal::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);  
}
function ZenHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, 0, $padWaitTime, true); 
}

// Ammo Pad Functionality
//------------------------------------------------------------------------------
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}

// ZenAll Pad Functionality
//------------------------------------------------------------------------------
function ZenAll::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
}
function ZenAll::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, $ammoRate, $padWaitTime, true); 
}

