// FILENAME:	MIB_Training.cs
//
// AUTHORS:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "MIB_Training";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
	marsSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to the M.I.B. Training Map! Choose different teams for different types of training. Yellow team is target practice, blue team is teamwork training, and red & purple teams are for TDM practice. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
}

Pilot Goad
{
   id = 28;
   
   name = Goad;
   
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 250.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

