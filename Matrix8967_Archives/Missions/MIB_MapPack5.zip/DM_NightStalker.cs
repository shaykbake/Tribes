// AUTHOR:  	Maj. DarkRaven[M.I.B]
//
//------------------------------------------------------------------------------
$missionName = "DM_NightStalker";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$killPoints    = 3; 
$deathPoints   = 2; 

function onMissionLoad()
{
   cdAudioCycle("Terror", "Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Deathmatch\n\n<F2>Mission Name<F0>  " @ $missionName @ "\n\nWelcome to Deathmatch NightStalker. \nWatch your back, someone just might be back there. <f0>\n\nLook for teleporters, Fusion reactors, and the Buddha. Do not destroy any fusion reactors or attack Buddha!\n <f0>"); 
}
function onMissionStart()
{
	marsSounds();
	startmapdefault();
}

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}
function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DM_NightStalker! You can download this & other missions made by Maj. Darkraven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at http://Starsiegemeninblack.cjb.net");
}
// Teleporters 'n stuf
function tele1::trigger::oncontact(%this, %who)
{
	setposition(%who, 2178, 231, 311);
}
function tele2::trigger::oncontact(%this, %who)
{
	setposition(%who, 1283, 356, 256);
}
function tele3::trigger::oncontact(%this, %who)
{
	setposition(%who, 64, -472, 311);
}
function tele4::trigger::oncontact(%this, %who)
{
	setposition(%who, 9, 170, 281);
}
function tele5::trigger::oncontact(%this, %who)
{
	setposition(%who, 368, 179, 335);
}
function tele6::trigger::oncontact(%this, %who)
{
	setposition(%who, 0, 0, 2000);
}
function tele7::trigger::oncontact(%this, %who)
{
	setposition(%who, -121, 35, 105);
}
function tele8::trigger::oncontact(%this, %who)
{
	setposition(%who, 1316, 17, 500);
}
function freact::building::ondestroyed(%this, %destroyer)
{
	blast(%this, 1200, 1000000, 0);
}
function buddha::structure::onattacked(%this, %who)
{
	%var = withindistance(%this, %who, 5);
	if(%var == false)
	{
		%name = gethudname(%who);
		%mes = "The Buddha was attacked by " @ %name @ ", So EVERYBODY dies!";
		messagebox(0, %mes);
		blast(%this, 12000000, 10000000000, 0);
		setshapevisibility(%this, false);
		schedule("setshapevisibility(" @ %this @ ", true);", 300);
	}
}