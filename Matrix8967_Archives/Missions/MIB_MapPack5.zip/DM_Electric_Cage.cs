// FILENAME:	DM_Electric_Cage.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Electric_Cage";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
      $killPoints = 3;
      $deathPoints = 2;
      $healRate = 100;   
	$ammoRate = 3;
   	$padWaitTime = 45;
  	$zenWaitTime = 90;

	titanSounds();	
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to the ELECTRIC CAGE! Players will fight to the death in this arena. But beware the electric fence surrounding the arena....OR PAY THE CONSEQUENCES! You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.name = getHUDName(%vehicleId);
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

function fence::trigger::OnEnter(%this, %object)
{
      healObject(%object, -10000);
	healObject(%object, -10000);
	healObject(%object, -10000);
	healObject(%object, -10000);
	healObject(%object, -10000);
      say("everybody", 0, %object.name @ " was shocked to death by the electric fence!","sfx_electrical_bzzt.WAV");
}