// FILENAME:	CTF_Dark_Side.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//
// RANDOM QUOTE:  "Feel the power of the dark side."
//                             - Darth Vader
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "CTF_Dark_Side";

$maxFlagCount  = 8;          // no of flags required by a team to end the game
$flagValue     = 5;          // points your team gets for capturing
$carrierValue  = 2;          //  "      "    "    "    " killing carrier
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 0;               // I don't want a flag timer in this map. 
                             // I have an out-of-bounds kill trigger instead.

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
   moonSounds();
   initGlobalVars();
}

function onMissionLoad()
{
   cdAudioCycle("Terror", "Mechsoul", "Cloudburst","Cyberntx","Yougot"); 
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to CTF on the Dark Side of the Moon! Cloaks are not allowed. Flag timers have been disabled. You can download CTF_Dark_Side & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onRemove(%this)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onAdd(%this)
{
      // CTFstdLib.cs stuff
	%team = getTeam(playerManager::vehicleIdToPlayerNum(%this));
	%color = teamToColor(%team);
	%flagKey = strcat(%color, "FlagCount");
	
   	adjTeamCount(%team, 1);
	
	//if the flag isn't at the base, but no one has it, correct situation
	if(dataRetrieve(0, %flagKey) && !dataRetrieve(0, strcat(%color, "FlagCarried")))
	{
		setFlag(%team, true);
	}

      // CTF_Dark_Side stuff
      %player = playerManager::vehicleIdToPlayerNum(%this);
      %componentCount = getComponentCount(%this);
      %index = 0;
      while (%index < %componentCount) 
      {
         %id = getComponentId(%this, %index);
         if(%id==830)
         {
            healobject(%this,-50000);
            messagebox(%player,"Cloaks are not allowed.");
         }
         else if(%id==831)
         {
            healobject(%this,-50000);
            messagebox(%player,"Cloaks are not allowed.");
         }
         %index++;
      }
}

function kill::trigger::onenter(%this,%object)
{
   //Dont let them run off with flag
   if(dataRetrieve(%object, "hasFlag") != "")
   {
      %player = playermanager::vehicleidtoplayernum(%object);
      healobject(%object,-50000);
      say(0,1,"<f5>"@getname(%object)@" went out of bounds.");
      messagebox(%player,"You were killed for taking the flag out of bounds.");
   }
}

function setDefaultMissionItems()
{
   allowComponent(all, true);   // All Components
   allowComponent(830, false);  // No Cloaks
   allowComponent(831, false);  // No Cloaks
}
