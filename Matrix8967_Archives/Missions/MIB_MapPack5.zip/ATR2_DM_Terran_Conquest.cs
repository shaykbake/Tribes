// FILENAME:	ATR2_DM_Terran_Conquest.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "ATR2_DM_Terran_Conquest";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

      $server::MassLimit = 0;
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to ATR2 DM_Terran_Conquest! This is as close to the SS Alpha Tech Release 2 as you're gonna get! You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Newtech", "Cyberntx"); 
}

// move the map
$server::HudMapViewOffsetX = -1500;
$server::HudMapViewOffsetY = 2500;

function onMissionStart()
{
	$padWaitTime = 0;
  	$zenWaitTime = 0;
	
	temperateSounds();
}

function setDefaultMissionItems()
{
   allowVehicle(                                          all, FALSE  );
   allowVehicle(                                            2, TRUE  );  //Minotaur
   allowVehicle(                                           30, TRUE  );  //Emancipator
   allowVehicle(                                           21, TRUE  );  //Goad
   allowVehicle(                                            7, TRUE  );  //Myrmidon
   
   allowWeapon(                                           all, FALSE  );
   allowWeapon(                                           101, TRUE  );  //Laser
   allowWeapon(                                           105, TRUE  );  //EMP
   allowWeapon(                                           107, TRUE  );  //Blaster
   allowWeapon(                                           116, TRUE  );  //ATC
   allowWeapon(                                           119, TRUE  );  //Blast Cannon
   allowWeapon(                                           126, TRUE  );  //Sparrow Missile Pack 6
   allowWeapon(                                           127, TRUE  );  //Sparrow Missile Pack 10

   allowComponent(                                        all, TRUE  );
   allowComponent(                                        800, FALSE  );  //Computers Restricted
   allowComponent(                                        802, FALSE  );  
   allowComponent(                                        805, FALSE  );  
   allowComponent(                                        806, FALSE  );  
   allowComponent(                                        807, FALSE  );  
   allowComponent(                                        809, FALSE  );  //Jammers Restricted
   allowComponent(                                        811, FALSE  );  
   allowComponent(                                        812, FALSE  );  
   allowComponent(                                        813, FALSE  );  
   allowComponent(                                        820, FALSE  );  //Thermal Diffuser
   allowComponent(                                        845, FALSE  );  //SCAP
   allowComponent(                                        850, FALSE  );  //SAMP
   allowComponent(                                        860, FALSE  );  //LTADs
   allowComponent(                                        865, FALSE  );  //Battery
   allowComponent(                                        870, FALSE  );  //CAP
   allowComponent(                                        875, FALSE  );  //Field Stabilizer
   allowComponent(                                        880, FALSE  );  //Rocket Booster
   allowComponent(                                        885, FALSE  );  //Turbine Booster
   allowComponent(                                        890, FALSE  );  //Nano-Repair Module
   allowComponent(                                        900, FALSE  );  //Angel Life Support
   allowComponent(                                        910, FALSE  );  //Anti-Gravity Gen
   allowComponent(                                        912, FALSE  );  //Electrohull
   allowComponent(                                        914, FALSE  );  //UAP
   allowComponent(                                        931, FALSE  );  //Quicksilver Nano-Armor
}

// Healing Pad Functionality
//------------------------------------------------------------------------------
function ZenHeal::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);  
}
function ZenHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, 0, $padWaitTime, true); 
}

// Ammo Pad Functionality
//------------------------------------------------------------------------------
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}

// ZenAll Pad Functionality
//------------------------------------------------------------------------------
function ZenAll::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
}
function ZenAll::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, $ammoRate, $padWaitTime, true); 
}

function Buddha::structure::onAttacked(%destroyed, %destroyer){
	%sayTo = playerManager::vehicleIdToPlayerNum(%destroyer);
	Say(%sayTo, %sayTo, *IDMULT_YOU_KILLED_BUDDHA);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
}

function Door1::trigger::onEnter(%this, %vehicleId){
	playAnimSequence(getObjectId("MissionGroup\\Triggers\\Door"), 0, true);
}
function Door1::trigger::onLeave(%this, %vehicleId){
	playAnimSequence(getObjectId("MissionGroup\\Triggers\\Door"), 0, false);
}

