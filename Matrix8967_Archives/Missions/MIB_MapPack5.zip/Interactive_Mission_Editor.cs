// FILENAME:	Interactive_Mission_Editor.cs
// 
// AUTHOR:  	Com. Sentinal [M.I.B.]
//
// Standard Library for the Interactive Mission Editor.
// To enable it in your own map type exec("Interactive_Mission_Editor.cs");
// at the top of your map's script.
//------------------------------------------------------------------------------

$missionName = "Interactive Mission Editor";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   marsSounds();
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to the Starsiege Interactive Mission Editor! Read the game info tab for instructions on how to build & edit your own structures. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.delay = false;
   %player.keymap = "structure";
   %player.structureNum = 0;
   %player.structure = 0;
   %player.rotation = 0;
   %player.angle = 0;
   %player.offsetx = 0;
   %player.offsety = 0;
   %player.offsetz = 0;
   %player.static = "StaticInterior";
   %player.shape = "hplatformm.dis";
   %player.shapename = "Mars Platform";
   %player.firefunction = "delete";
   %player.build1 = 0;
   %player.build2 = 0;
   %player.build3 = 0;
   %player.build4 = 0;
   %player.build5 = 0;
   %player.build6 = 0;
   %player.build7 = 0;
   %player.build8 = 0;
   %player.build9 = 0;
   %player.build10 = 0;
   %player.structure1rot = 0;
   %player.structure2rot = 0;
   %player.structure3rot = 0;
   %player.structure4rot = 0;
   %player.structure5rot = 0;
   %player.structure6rot = 0;
   %player.structure7rot = 0;
   %player.structure8rot = 0;
   %player.structure9rot = 0;
   %player.structure10rot = 0;
}

function player::onRemove(%player)
{
   deleteObject(%player.structure1);
   deleteObject(%player.structure2);
   deleteObject(%player.structure3);
   deleteObject(%player.structure4);
   deleteObject(%player.structure5);
   deleteObject(%player.structure6);
   deleteObject(%player.structure7);
   deleteObject(%player.structure8);
   deleteObject(%player.structure9);
   deleteObject(%player.structure10);
}

function onMissionLoad()
{
   cdAudioCycle("Terror", "Newtech", "Mechsoul");
   setGameInfo("<F2>GAME TYPE:<F0>  Interactive Mission Editor\n\n<F2>RULES:<F0>  " @ $missionName @ "\n\nWelcome to the Starsiege Interactive Mission Editor! Build & edit up to 10 of your own structures in-game! To build and edit your own structures in-game, you must first download Mission_Edit_Keymap.cs included in the latest MIB Map Pack. Then move the file to your C:\\Dynamix\\Starsiege\\Keymaps folder.\n\n<F2>KEYMAP CONTROLS:<F0>\n\nCTRL + S          Build Selected Structure\nCTRL + W          Toggle Selection Mode\nCTRL + A          Decrease Selection Number\nCTRL + D          Increase Selection Number\nCTRL + E          Toggle Weapon Fire Function\nCTRL + Q          Reset Selected Option to Zero/Default\nCTRL + F          Delete All Structures\n\n<F3>NOTE:  Weapon Fire Function is defaulted to delete individual structures when attacked.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.\n");
}

function onMissionEnd()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      deleteObject(%player.structure1);
      deleteObject(%player.structure2);
      deleteObject(%player.structure3);
      deleteObject(%player.structure4);
      deleteObject(%player.structure5);
      deleteObject(%player.structure6);
      deleteObject(%player.structure7);
      deleteObject(%player.structure8);
      deleteObject(%player.structure9);
      deleteObject(%player.structure10);
      %player.structureNum = 0;
      %player.build1 = 0;
      %player.structure1 = "deleted";
      %player.structure1rot = 0;
      %player.build2 = 0;
      %player.structure2 = "deleted";
      %player.structure2rot = 0;
      %player.build3 = 0;
      %player.structure3 = "deleted";
      %player.structure3rot = 0;
      %player.build4 = 0;
      %player.structure4 = "deleted";
      %player.structure4rot = 0;
      %player.build5 = 0;
      %player.structure5 = "deleted";
      %player.structure5rot = 0;
      %player.build6 = 0;
      %player.structure6 = "deleted";
      %player.structure6rot = 0;
      %player.build7 = 0;
      %player.structure7 = "deleted";
      %player.structure7rot = 0;
      %player.build8 = 0;
      %player.structure8 = "deleted";
      %player.structure8rot = 0;
      %player.build9 = 0;
      %player.structure9 = "deleted";
      %player.structure9rot = 0;
      %player.build10 = 0;
      %player.structure10 = "deleted";
      %player.structure10rot = 0;
      %player.keymap = "structure";
      %player.structure = 0;
      %player.rotation = 0;
      %player.angle = 0;
      %player.offsetx = 0;
      %player.offsety = 0;
      %player.offsetz = 0;
      %player.static = "StaticInterior";
      %player.shape = "hplatformm.dis";
      %player.shapename = "Mars Platform";
      %player.firefunction = "delete";
      %player.delay = false;
   }
}

function remoteGlobalDelete(%player)
{
   deleteObject(%player.structure1);
   deleteObject(%player.structure2);
   deleteObject(%player.structure3);
   deleteObject(%player.structure4);
   deleteObject(%player.structure5);
   deleteObject(%player.structure6);
   deleteObject(%player.structure7);
   deleteObject(%player.structure8);
   deleteObject(%player.structure9);
   deleteObject(%player.structure10);
   %player.structureNum = 0;
   %player.build1 = 0;
   %player.structure1 = "deleted";
   %player.structure1rot = 0;
   %player.build2 = 0;
   %player.structure2 = "deleted";
   %player.structure2rot = 0;
   %player.build3 = 0;
   %player.structure3 = "deleted";
   %player.structure3rot = 0;
   %player.build4 = 0;
   %player.structure4 = "deleted";
   %player.structure4rot = 0;
   %player.build5 = 0;
   %player.structure5 = "deleted";
   %player.structure5rot = 0;
   %player.build6 = 0;
   %player.structure6 = "deleted";
   %player.structure6rot = 0;
   %player.build7 = 0;
   %player.structure7 = "deleted";
   %player.structure7rot = 0;
   %player.build8 = 0;
   %player.structure8 = "deleted";
   %player.structure8rot = 0;
   %player.build9 = 0;
   %player.structure9 = "deleted";
   %player.structure9rot = 0;
   %player.build10 = 0;
   %player.structure10 = "deleted";
   %player.structure10rot = 0;
   say(%player, %player, "<F1>All structures deleted.");
}

function remoteResetZero(%player)
{
   if(%player.keymap=="structure")
   {
      %player.structure = 0;
      %player.static = "StaticInterior";
      %player.shape = "hplatformm.dis";
      %player.shapename = "Mars Platform";
      say(%player, %player, "<F1>Default Structure: <F5>" @ %player.shapename);
   }
   else if(%player.keymap=="rotation")
   {
      %player.rotation = 0;
      say(%player, %player, "<F1>Default Rotation: <F5>" @ %player.rotation);
   }
   else if(%player.keymap=="angle")
   {
      %player.angle = 0;
      say(%player, %player, "<F1>Default Angle: <F5>" @ %player.angle);
   }
   else if(%player.keymap=="offsetx")
   {
      %player.offsetx = 0;
      say(%player, %player, "<F1>Default Offset X: <F5>" @ %player.offsetx);
   }
   else if(%player.keymap=="offsety")
   {
      %player.offsety = 0;
      say(%player, %player, "<F1>Default Offset Y: <F5>" @ %player.offsety);
   }
   else if(%player.keymap=="offsetz")
   {
      %player.offsetz = 0;
      say(%player, %player, "<F1>Default Offset Z: <F5>" @ %player.offsetz);
   }
}

function remoteFireToggle(%player)
{
   if(%player.firefunction=="delete")
   {
      %player.firefunction = "adjustxPos";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Adjust East (X + 1 meter)");
   }
   else if(%player.firefunction=="adjustxPos")
   {
      %player.firefunction = "adjustxNeg";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Adjust West (X - 1 meter)");
   }
   else if(%player.firefunction=="adjustxNeg")
   {
      %player.firefunction = "adjustyPos";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Adjust North (Y + 1 meter)");
   }
   else if(%player.firefunction=="adjustyPos")
   {
      %player.firefunction = "adjustyNeg";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Adjust South (Y - 1 meter)");
   }
   else if(%player.firefunction=="adjustyNeg")
   {
      %player.firefunction = "adjustzPos";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Adjust Up (Z + 1 meter)");
   }
   else if(%player.firefunction=="adjustzPos")
   {
      %player.firefunction = "adjustzNeg";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Adjust Down (Z - 1 meter)");
   }
   else if(%player.firefunction=="adjustzNeg")
   {
      %player.firefunction = "adjustRotPos";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Increase Rotation (R + 15 degrees)");
   }
   else if(%player.firefunction=="adjustRotPos")
   {
      %player.firefunction = "adjustRotNeg";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Decrease Rotation (R - 15 degrees)");
   }
   else if(%player.firefunction=="adjustRotNeg")
   {
      %player.firefunction = "fire";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Normal Weapon Fire");
   }
   else if(%player.firefunction=="fire")
   {
      %player.firefunction = "delete";
      say(%player, %player, "<F1>Toggle Weapon Function: <F5>Delete Structure");
   }
}

function remoteFunctionToggle(%player)
{
   if(%player.keymap=="structure")
   {
      %player.keymap = "rotation";
      say(%player, %player, "<F1>Adjust Current Rotation: <F5>" @ %player.rotation);
   }
   else if(%player.keymap=="rotation")
   {
      %player.keymap = "angle";
      say(%player, %player, "<F1>Adjust Current Angle: <F5>" @ %player.angle);
   }
   else if(%player.keymap=="angle")
   {
      %player.keymap = "offsetx";
      say(%player, %player, "<F1>Adjust Current Offset X: <F5>" @ %player.offsetx);
   }
   else if(%player.keymap=="offsetx")
   {
      %player.keymap = "offsety";      
      say(%player, %player, "<F1>Adjust Current Offset Y: <F5>" @ %player.offsety);
   }
   else if(%player.keymap=="offsety")
   {
      %player.keymap = "offsetz";
      say(%player, %player, "<F1>Adjust Current Offset Z: <F5>" @ %player.offsetz);
   }
   else if(%player.keymap=="offsetz")
   {
      %player.keymap = "structure";
      say(%player, %player, "<F1>Adjust Current Structure: <F5>" @ %player.shapename);
   }
}

function remoteDecreaseNum(%player)
{
   if(%player.keymap=="structure")
   {
      structureToggleDown(%player);
   }
   else if(%player.keymap=="rotation")
   {
      rotationToggleDown(%player);
   }
   else if(%player.keymap=="angle")
   {
      angleToggleDown(%player);
   }
   else if(%player.keymap=="offsetx")
   {
      offsetxToggleDown(%player);
   }
   else if(%player.keymap=="offsety")
   {
      offsetyToggleDown(%player);
   }
   else if(%player.keymap=="offsetz")
   {
      offsetzToggleDown(%player);
   }
}

function remoteIncreaseNum(%player)
{
   if(%player.keymap=="structure")
   {
      structureToggle(%player);
   }
   else if(%player.keymap=="rotation")
   {
      rotationToggle(%player);
   }
   else if(%player.keymap=="angle")
   {
      angleToggle(%player);
   }
   else if(%player.keymap=="offsetx")
   {
      offsetxToggle(%player);
   }
   else if(%player.keymap=="offsety")
   {
      offsetyToggle(%player);
   }
   else if(%player.keymap=="offsetz")
   {
      offsetzToggle(%player);
   }
}

function structureToggle(%player)
{
   if(%player.structure==0)
   {
      %player.structure = 1;
      %player.static = "StaticInterior";
      %player.shape = "hTroophouseE.dis";
      %player.shapename = "Titan Trooper Hangar";
   }
   else if(%player.structure==1)
   {
      %player.structure = 2;
      %player.static = "StaticInterior";
      %player.shape = "hgaragem.dis";
      %player.shapename = "Mars Garage";
   }
   else if(%player.structure==2)
   {
      %player.structure = 3;
      %player.static = "StaticInterior";
      %player.shape = "hhangarm.dis";
      %player.shapename = "Mars Hangar";
   }
   else if(%player.structure==3)
   {
      %player.structure = 4;
      %player.static = "StaticInterior";
      %player.shape = "hbighousem.dis";
      %player.shapename = "Mars Big House #1";
   }
   else if(%player.structure==4)
   {
      %player.structure = 5;
      %player.static = "StaticInterior";
      %player.shape = "hbighouse2m.dis";
      %player.shapename = "Mars Big House #2";
   }
   else if(%player.structure==5)
   {
      %player.structure = 6;
      %player.static = "StaticInterior";
      %player.shape = "hbighumpm.dis";
      %player.shapename = "Mars Big Hump";
   }
   else if(%player.structure==6)
   {
      %player.structure = 7;
      %player.static = "StaticInterior";
      %player.shape = "hbridge2m.dis";
      %player.shapename = "Mars Small Bridge";
   }
   else if(%player.structure==7)
   {
      %player.structure = 8;
      %player.static = "StaticInterior";
      %player.shape = "hbridgem.dis";
      %player.shapename = "Mars Large Bridge";
   }
   else if(%player.structure==8)
   {
      %player.structure = 9;
      %player.static = "StaticInterior";
      %player.shape = "xbridgehub2.dis";
      %player.shapename = "Bridge Hub (2-way)";
   }
   else if(%player.structure==9)
   {
      %player.structure = 10;
      %player.static = "StaticInterior";
      %player.shape = "xbridgehub4.dis";
      %player.shapename = "Bridge Hub (4-way)";
   }
   else if(%player.structure==10)
   {
      %player.structure = 11;
      %player.static = "StaticInterior";
      %player.shape = "hHongTemple.dis";
      %player.shapename = "Hong Temple";
   }
   else if(%player.structure==11)
   {
      %player.structure = 12;
      %player.static = "StaticInterior";
      %player.shape = "hkonghide.dis";
      %player.shapename = "Tunnel #1";
   }
   else if(%player.structure==12)
   {
      %player.structure = 13;
      %player.static = "StaticInterior";
      %player.shape = "hkonghide2.dis";
      %player.shapename = "Tunnel #2";
   }
   else if(%player.structure==13)
   {
      %player.structure = 14;
      %player.static = "StaticInterior";
      %player.shape = "hlunaport.dis";
      %player.shapename = "Space Port";
   }
   else if(%player.structure==14)
   {
      %player.structure = 15;
      %player.static = "StaticInterior";
      %player.shape = "hbigluna5.dis";
      %player.shapename = "Moon Base";
   }
   else if(%player.structure==15)
   {
      %player.structure = 16;
      %player.static = "StaticInterior";
      %player.shape = "hairporta.dis";
      %player.shapename = "Airport";
   }
   else if(%player.structure==16)
   {
      %player.structure = 17;
      %player.static = "StaticInterior";
      %player.shape = "hgaragee.dis";
      %player.shapename = "Terran Garage";
   }
   else if(%player.structure==17)
   {
      %player.structure = 18;
      %player.static = "StaticInterior";
      %player.shape = "hpyramid.dis";
      %player.shapename = "Pyramid";
   }
   else if(%player.structure==18)
   {
      %player.structure = 19;
      %player.static = "StaticInterior";
      %player.shape = "cPromBase.dis";
      %player.shapename = "Prometheus Base";
   }
   else if(%player.structure==19)
   {
      %player.structure = 20;
      %player.static = "StaticInterior";
      %player.shape = "football.dis";
      %player.shapename = "Football Uprights";
   }
   else if(%player.structure==20)
   {
      %player.structure = 21;
      %player.static = "StaticShape";
      %player.shape = "hTitanbigdish.DTS";
      %player.shapename = "Satellite Dish";
   }
   else if(%player.structure==21)
   {
      %player.structure = 22;
      %player.static = "StaticShape";
      %player.shape = "hTroopcomm.dts";
      %player.shapename = "Tac-Com";
   }
   else
   {
      structureToggle2(%player);
   }
   say(%player, %player, "<F1>Structure: <F5>" @ %player.shapename);
}

function structureToggle2(%player)
{
   if(%player.structure==22)
   {
      %player.structure = 23;
      %player.static = "StaticShape";
      %player.shape = "hVenusdrill.dts";
      %player.shapename = "Venus Drill";
   }
   else if(%player.structure==23)
   {
      %player.structure = 24;
      %player.static = "StaticShape";
      %player.shape = "hMoongenerator.dts";
      %player.shapename = "Generator";
   }
   else if(%player.structure==24)
   {
      %player.structure = 25;
      %player.static = "StaticShape";
      %player.shape = "hCrane.dts";
      %player.shapename = "Mars Crane";
   }
   else if(%player.structure==25)
   {
      %player.structure = 26;
      %player.static = "StaticInterior";
      %player.shape = "hnovagated.dis";
      %player.shapename = "Nova Alexandria Gate";
   }
   else if(%player.structure==26)
   {
      %player.structure = 27;
      %player.static = "StaticShape";
      %player.shape = "kn_APOC.DTS";
      %player.shapename = "Apocalypse Husk";
   }
   else if(%player.structure==27)
   {
      %player.structure = 28;
      %player.static = "StaticShape";
      %player.shape = "pl_EXEC.DTS";
      %player.shapename = "Executioner Husk";
   }
   else if(%player.structure==28)
   {
      %player.structure = 29;
      %player.static = "StaticShape";
      %player.shape = "cy_GOAD.DTS";
      %player.shapename = "Goad Husk";
   }
   else if(%player.structure==29)
   {
      %player.structure = 30;
      %player.static = "StaticShape";
      %player.shape = "kn_BASL.DTS";
      %player.shapename = "Basilisk Husk";
   }
   else if(%player.structure==30)
   {
      %player.structure = 31;
      %player.static = "StaticShape";
      %player.shape = "kn_GORG.DTS";
      %player.shapename = "Gorgon Husk";
   }
   else if(%player.structure==31)
   {
      %player.structure = 32;
      %player.static = "StaticShape";
      %player.shape = "rb_OLY.DTS";
      %player.shapename = "Olympian Husk";
   }
   else if(%player.structure==32)
   {
      %player.structure = 33;
      %player.static = "StaticShape";
      %player.shape = "cy_drop.DTS";
      %player.shapename = "Cybrid Dropship Husk";
   }
   else if(%player.structure==33)
   {
      %player.structure = 34;
      %player.static = "StaticShape";
      %player.shape = "cy_spac.DTS";
      %player.shapename = "Cybrid Spacecraft";
   }
   else if(%player.structure==34)
   {
      %player.structure = 35;
      %player.static = "StaticInterior";
      %player.shape = "hlandpadv.dis";
      %player.shapename = "Venus Landing Pad";
   }
   else if(%player.structure==35)
   {
      %player.structure = 36;
      %player.static = "StaticInterior";
      %player.shape = "hbridgev.dis";
      %player.shapename = "Venus Bridge";
   }
   else if(%player.structure==36)
   {
      %player.structure = 37;
      %player.static = "StaticInterior";
      %player.shape = "hlgoilv.dis";
      %player.shapename = "Venus Oil Rig";
   }
   else if(%player.structure==37)
   {
      %player.structure = 0;
      %player.static = "StaticInterior";
      %player.shape = "hplatformm.dis";
      %player.shapename = "Mars Platform";
   }
}

function structureToggleDown(%player)
{
   if(%player.structure==2)
   {
      %player.structure = 1;
      %player.static = "StaticInterior";
      %player.shape = "hTroophouseE.dis";
      %player.shapename = "Titan Trooper Hangar";
   }
   else if(%player.structure==3)
   {
      %player.structure = 2;
      %player.static = "StaticInterior";
      %player.shape = "hgaragem.dis";
      %player.shapename = "Mars Garage";
   }
   else if(%player.structure==4)
   {
      %player.structure = 3;
      %player.static = "StaticInterior";
      %player.shape = "hhangarm.dis";
      %player.shapename = "Mars Hangar";
   }
   else if(%player.structure==5)
   {
      %player.structure = 4;
      %player.static = "StaticInterior";
      %player.shape = "hbighousem.dis";
      %player.shapename = "Mars Big House #1";
   }
   else if(%player.structure==6)
   {
      %player.structure = 5;
      %player.static = "StaticInterior";
      %player.shape = "hbighouse2m.dis";
      %player.shapename = "Mars Big House #2";
   }
   else if(%player.structure==7)
   {
      %player.structure = 6;
      %player.static = "StaticInterior";
      %player.shape = "hbighumpm.dis";
      %player.shapename = "Mars Big Hump";
   }
   else if(%player.structure==8)
   {
      %player.structure = 7;
      %player.static = "StaticInterior";
      %player.shape = "hbridge2m.dis";
      %player.shapename = "Mars Small Bridge";
   }
   else if(%player.structure==9)
   {
      %player.structure = 8;
      %player.static = "StaticInterior";
      %player.shape = "hbridgem.dis";
      %player.shapename = "Mars Large Bridge";
   }
   else if(%player.structure==10)
   {
      %player.structure = 9;
      %player.static = "StaticInterior";
      %player.shape = "xbridgehub2.dis";
      %player.shapename = "Bridge Hub (2-way)";
   }
   else if(%player.structure==11)
   {
      %player.structure = 10;
      %player.static = "StaticInterior";
      %player.shape = "xbridgehub4.dis";
      %player.shapename = "Bridge Hub (4-way)";
   }
   else if(%player.structure==12)
   {
      %player.structure = 11;
      %player.static = "StaticInterior";
      %player.shape = "hHongTemple.dis";
      %player.shapename = "Hong Temple";
   }
   else if(%player.structure==13)
   {
      %player.structure = 12;
      %player.static = "StaticInterior";
      %player.shape = "hkonghide.dis";
      %player.shapename = "Tunnel #1";
   }
   else if(%player.structure==14)
   {
      %player.structure = 13;
      %player.static = "StaticInterior";
      %player.shape = "hkonghide2.dis";
      %player.shapename = "Tunnel #2";
   }
   else if(%player.structure==15)
   {
      %player.structure = 14;
      %player.static = "StaticInterior";
      %player.shape = "hlunaport.dis";
      %player.shapename = "Space Port";
   }
   else if(%player.structure==16)
   {
      %player.structure = 15;
      %player.static = "StaticInterior";
      %player.shape = "hbigluna5.dis";
      %player.shapename = "Moon Base";
   }
   else if(%player.structure==17)
   {
      %player.structure = 16;
      %player.static = "StaticInterior";
      %player.shape = "hairporta.dis";
      %player.shapename = "Airport";
   }
   else if(%player.structure==18)
   {
      %player.structure = 17;
      %player.static = "StaticInterior";
      %player.shape = "hgaragee.dis";
      %player.shapename = "Terran Garage";
   }
   else if(%player.structure==19)
   {
      %player.structure = 18;
      %player.static = "StaticInterior";
      %player.shape = "hpyramid.dis";
      %player.shapename = "Pyramid";
   }
   else if(%player.structure==20)
   {
      %player.structure = 19;
      %player.static = "StaticInterior";
      %player.shape = "cPromBase.dis";
      %player.shapename = "Prometheus Base";
   }
   else if(%player.structure==21)
   {
      %player.structure = 20;
      %player.static = "StaticInterior";
      %player.shape = "football.dis";
      %player.shapename = "Football Uprights";
   }
   else if(%player.structure==22)
   {
      %player.structure = 21;
      %player.static = "StaticShape";
      %player.shape = "hTitanbigdish.DTS";
      %player.shapename = "Satellite Dish";
   }
   else if(%player.structure==23)
   {
      %player.structure = 22;
      %player.static = "StaticShape";
      %player.shape = "hTroopcomm.dts";
      %player.shapename = "Tac-Com";
   }
   else
   {
      structureToggle2Down(%player);
   }
   say(%player, %player, "<F1>Structure: <F5>" @ %player.shapename);
}

function structureToggle2Down(%player)
{
   if(%player.structure==24)
   {
      %player.structure = 23;
      %player.static = "StaticShape";
      %player.shape = "hVenusdrill.dts";
      %player.shapename = "Venus Drill";
   }
   else if(%player.structure==25)
   {
      %player.structure = 24;
      %player.static = "StaticShape";
      %player.shape = "hMoongenerator.dts";
      %player.shapename = "Generator";
   }
   else if(%player.structure==26)
   {
      %player.structure = 25;
      %player.static = "StaticShape";
      %player.shape = "hCrane.dts";
      %player.shapename = "Mars Crane";
   }
   else if(%player.structure==27)
   {
      %player.structure = 26;
      %player.static = "StaticInterior";
      %player.shape = "hnovagated.dis";
      %player.shapename = "Nova Alexandria Gate";
   }
   else if(%player.structure==28)
   {
      %player.structure = 27;
      %player.static = "StaticShape";
      %player.shape = "kn_APOC.DTS";
      %player.shapename = "Apocalypse Husk";
   }
   else if(%player.structure==29)
   {
      %player.structure = 28;
      %player.static = "StaticShape";
      %player.shape = "pl_EXEC.DTS";
      %player.shapename = "Executioner Husk";
   }
   else if(%player.structure==30)
   {
      %player.structure = 29;
      %player.static = "StaticShape";
      %player.shape = "cy_GOAD.DTS";
      %player.shapename = "Goad Husk";
   }
   else if(%player.structure==31)
   {
      %player.structure = 30;
      %player.static = "StaticShape";
      %player.shape = "kn_BASL.DTS";
      %player.shapename = "Basilisk Husk";
   }
   else if(%player.structure==32)
   {
      %player.structure = 31;
      %player.static = "StaticShape";
      %player.shape = "kn_GORG.DTS";
      %player.shapename = "Gorgon Husk";
   }
   else if(%player.structure==33)
   {
      %player.structure = 32;
      %player.static = "StaticShape";
      %player.shape = "rb_OLY.DTS";
      %player.shapename = "Olympian Husk";
   }
   else if(%player.structure==34)
   {
      %player.structure = 33;
      %player.static = "StaticShape";
      %player.shape = "cy_drop.DTS";
      %player.shapename = "Cybrid Dropship Husk";
   }
   else if(%player.structure==35)
   {
      %player.structure = 34;
      %player.static = "StaticShape";
      %player.shape = "cy_spac.DTS";
      %player.shapename = "Cybrid Spacecraft";
   }
   else if(%player.structure==36)
   {
      %player.structure = 35;
      %player.static = "StaticInterior";
      %player.shape = "hlandpadv.dis";
      %player.shapename = "Venus Landing Pad";
   }
   else if(%player.structure==37)
   {
      %player.structure = 36;
      %player.static = "StaticInterior";
      %player.shape = "hbridgev.dis";
      %player.shapename = "Venus Bridge";
   }
   else if(%player.structure==0)
   {
      %player.structure = 37;
      %player.static = "StaticInterior";
      %player.shape = "hlgoilv.dis";
      %player.shapename = "Venus Oil Rig";
   }
   else if(%player.structure==1)
   {
      %player.structure = 0;
      %player.static = "StaticInterior";
      %player.shape = "hplatformm.dis";
      %player.shapename = "Mars Platform";
   }
}

function rotationToggle(%player)
{
   if(%player.rotation==0)
   {
      %player.rotation = 15;
   }
   else if(%player.rotation==15)
   {
      %player.rotation = 30;
   }
   else if(%player.rotation==30)
   {
      %player.rotation = 45;
   }
   else if(%player.rotation==45)
   {
      %player.rotation = 60;
   }
   else if(%player.rotation==60)
   {
      %player.rotation = 75;
   }
   else if(%player.rotation==75)
   {
      %player.rotation = 90;
   }
   else if(%player.rotation==90)
   {
      %player.rotation = 105;
   }
   else if(%player.rotation==105)
   {
      %player.rotation = 120;
   }
   else if(%player.rotation==120)
   {
      %player.rotation = 135;
   }
   else if(%player.rotation==135)
   {
      %player.rotation = 150;
   }
   else if(%player.rotation==150)
   {
      %player.rotation = 165;
   }
   else if(%player.rotation==165)
   {
      %player.rotation = 180;
   }
   else if(%player.rotation==180)
   {
      %player.rotation = 195;
   }
   else if(%player.rotation==195)
   {
      %player.rotation = 210;
   }
   else if(%player.rotation==210)
   {
      %player.rotation = 225;
   }
   else if(%player.rotation==225)
   {
      %player.rotation = 240;
   }
   else if(%player.rotation==240)
   {
      %player.rotation = 255;
   }
   else if(%player.rotation==255)
   {
      %player.rotation = 270;
   }
   else if(%player.rotation==270)
   {
      %player.rotation = 285;
   }
   else if(%player.rotation==285)
   {
      %player.rotation = 300;
   }
   else if(%player.rotation==300)
   {
      %player.rotation = 315;
   }
   else if(%player.rotation==315)
   {
      %player.rotation = 330;
   }
   else
   {
      rotationToggle2(%player);
   }
   say(%player, %player, "<F1>Rotation: <F5>" @ %player.rotation @ " Degrees");
}

function rotationToggleDown(%player)
{
   if(%player.rotation==30)
   {
      %player.rotation = 15;
   }
   else if(%player.rotation==45)
   {
      %player.rotation = 30;
   }
   else if(%player.rotation==60)
   {
      %player.rotation = 45;
   }
   else if(%player.rotation==75)
   {
      %player.rotation = 60;
   }
   else if(%player.rotation==90)
   {
      %player.rotation = 75;
   }
   else if(%player.rotation==105)
   {
      %player.rotation = 90;
   }
   else if(%player.rotation==120)
   {
      %player.rotation = 105;
   }
   else if(%player.rotation==135)
   {
      %player.rotation = 120;
   }
   else if(%player.rotation==150)
   {
      %player.rotation = 135;
   }
   else if(%player.rotation==165)
   {
      %player.rotation = 150;
   }
   else if(%player.rotation==180)
   {
      %player.rotation = 165;
   }
   else if(%player.rotation==195)
   {
      %player.rotation = 180;
   }
   else if(%player.rotation==210)
   {
      %player.rotation = 195;
   }
   else if(%player.rotation==225)
   {
      %player.rotation = 210;
   }
   else if(%player.rotation==240)
   {
      %player.rotation = 225;
   }
   else if(%player.rotation==255)
   {
      %player.rotation = 240;
   }
   else if(%player.rotation==270)
   {
      %player.rotation = 255;
   }
   else if(%player.rotation==285)
   {
      %player.rotation = 270;
   }
   else if(%player.rotation==300)
   {
      %player.rotation = 285;
   }
   else if(%player.rotation==315)
   {
      %player.rotation = 300;
   }
   else if(%player.rotation==330)
   {
      %player.rotation = 315;
   }
   else if(%player.rotation==345)
   {
      %player.rotation = 330;
   }
   else
   {
      rotationToggle2Down(%player);
   }
   say(%player, %player, "<F1>Rotation: <F5>" @ %player.rotation @ " Degrees");
}

function rotationToggle2Down(%player)
{
   if(%player.rotation==0)
   {
      %player.rotation = 345;
   }
   else if(%player.rotation==15)
   {
      %player.rotation = 0;
   }
}

function angleToggle(%player)
{
   if((%player.angle>=315)&&(%player.angle<359))
   {
      %player.angle++;
   }
   else if(%player.angle==359)
   {
      %player.angle = 0;
   }
   else if((%player.angle>=0)&&(%player.angle<45))
   {
      %player.angle++;
   }
   else if((%player.angle>=45)&&(%player.angle<90))
   {
      %player.angle = %player.angle + 5;
   }
   else if((%player.angle>=90)&&(%player.angle<270))
   {
      %player.angle = %player.angle + 15;
   }
   else if((%player.angle>=270)&&(%player.angle<315))
   {
      %player.angle = %player.angle + 5;
   }
   say(%player, %player, "<F1>Angle: <F5>" @ %player.angle @ " Degrees");
}

function angleToggleDown(%player)
{
   if((%player.angle>315)&&(%player.angle<360))
   {
      %player.angle--;
   }
   else if(%player.angle==0)
   {
      %player.angle = 359;
   }
   else if((%player.angle>0)&&(%player.angle<=45))
   {
      %player.angle--;
   }
   else if((%player.angle>45)&&(%player.angle<=90))
   {
      %player.angle = %player.angle - 5;
   }
   else if((%player.angle>90)&&(%player.angle<=270))
   {
      %player.angle = %player.angle - 15;
   }
   else if((%player.angle>270)&&(%player.angle<=315))
   {
      %player.angle = %player.angle - 5;
   }
   say(%player, %player, "<F1>Angle: <F5>" @ %player.angle @ " Degrees");
}

function offsetxToggle(%player)
{
   if((%player.offsetx>=0)&&(%player.offsetx<25))
   {
      %player.offsetx++;
   }
   else if((%player.offsetx>=25)&&(%player.offsetx<100))
   {
      %player.offsetx = %player.offsetx + 5;
   }
   else if((%player.offsetx>=100)&&(%player.offsetx<200))
   {
      %player.offsetx = %player.offsetx + 10;
   }
   else if((%player.offsetx>=200)&&(%player.offsetx<300))
   {
      %player.offsetx = %player.offsetx + 25;
   }
   else if((%player.offsetx>=300)&&(%player.offsetx<500))
   {
      %player.offsetx = %player.offsetx + 50;
   }
   else if(%player.offsetx==500)
   {
      %player.offsetx = -500;
   }
   else if((%player.offsetx>=-500)&&(%player.offsetx<-300))
   {
      %player.offsetx = %player.offsetx + 50;
   }
   else if((%player.offsetx>=-300)&&(%player.offsetx<-200))
   {
      %player.offsetx = %player.offsetx + 25;
   }
   else if((%player.offsetx>=-200)&&(%player.offsetx<-100))
   {
      %player.offsetx = %player.offsetx + 10;
   }
   else if((%player.offsetx>=-100)&&(%player.offsetx<-25))
   {
      %player.offsetx = %player.offsetx + 5;
   }
   else if((%player.offsetx>=-25)&&(%player.offsetx<0))
   {
      %player.offsetx = %player.offsetx + 1;
   }
   say(%player, %player, "<F1>Offset X: <F5>" @ %player.offsetx @ " Meters");
}

function offsetxToggleDown(%player)
{
   if((%player.offsetx<=0)&&(%player.offsetx>-25))
   {
      %player.offsetx--;
   }
   else if((%player.offsetx<=-25)&&(%player.offsetx>-100))
   {
      %player.offsetx = %player.offsetx - 5;
   }
   else if((%player.offsetx<=-100)&&(%player.offsetx>-200))
   {
      %player.offsetx = %player.offsetx - 10;
   }
   else if((%player.offsetx<=-200)&&(%player.offsetx>-300))
   {
      %player.offsetx = %player.offsetx - 25;
   }
   else if((%player.offsetx<=-300)&&(%player.offsetx>-500))
   {
      %player.offsetx = %player.offsetx - 50;
   }
   else if(%player.offsetx==-500)
   {
      %player.offsetx = 500;
   }
   else if((%player.offsetx<=500)&&(%player.offsetx>300))
   {
      %player.offsetx = %player.offsetx - 50;
   }
   else if((%player.offsetx<=300)&&(%player.offsetx>200))
   {
      %player.offsetx = %player.offsetx - 25;
   }
   else if((%player.offsetx<=200)&&(%player.offsetx>100))
   {
      %player.offsetx = %player.offsetx - 10;
   }
   else if((%player.offsetx<=100)&&(%player.offsetx>25))
   {
      %player.offsetx = %player.offsetx - 5;
   }
   else if((%player.offsetx<=25)&&(%player.offsetx>0))
   {
      %player.offsetx = %player.offsetx - 1;
   }
   say(%player, %player, "<F1>Offset X: <F5>" @ %player.offsetx @ " Meters");
}

function offsetyToggle(%player)
{
   if((%player.offsety>=0)&&(%player.offsety<25))
   {
      %player.offsety++;
   }
   else if((%player.offsety>=25)&&(%player.offsety<100))
   {
      %player.offsety = %player.offsety + 5;
   }
   else if((%player.offsety>=100)&&(%player.offsety<200))
   {
      %player.offsety = %player.offsety + 10;
   }
   else if((%player.offsety>=200)&&(%player.offsety<300))
   {
      %player.offsety = %player.offsety + 25;
   }
   else if((%player.offsety>=300)&&(%player.offsety<500))
   {
      %player.offsety = %player.offsety + 50;
   }
   else if(%player.offsety==500)
   {
      %player.offsety = -500;
   }
   else if((%player.offsety>=-500)&&(%player.offsety<-300))
   {
      %player.offsety = %player.offsety + 50;
   }
   else if((%player.offsety>=-300)&&(%player.offsety<-200))
   {
      %player.offsety = %player.offsety + 25;
   }
   else if((%player.offsety>=-200)&&(%player.offsety<-100))
   {
      %player.offsety = %player.offsety + 10;
   }
   else if((%player.offsety>=-100)&&(%player.offsety<-25))
   {
      %player.offsety = %player.offsety + 5;
   }
   else if((%player.offsety>=-25)&&(%player.offsety<0))
   {
      %player.offsety = %player.offsety + 1;
   }
   say(%player, %player, "<F1>Offset Y: <F5>" @ %player.offsety @ " Meters");
}

function offsetyToggleDown(%player)
{
   if((%player.offsety<=0)&&(%player.offsety>-25))
   {
      %player.offsety--;
   }
   else if((%player.offsety<=-25)&&(%player.offsety>-100))
   {
      %player.offsety = %player.offsety - 5;
   }
   else if((%player.offsety<=-100)&&(%player.offsety>-200))
   {
      %player.offsety = %player.offsety - 10;
   }
   else if((%player.offsety<=-200)&&(%player.offsety>-300))
   {
      %player.offsety = %player.offsety - 25;
   }
   else if((%player.offsety<=-300)&&(%player.offsety>-500))
   {
      %player.offsety = %player.offsety - 50;
   }
   else if(%player.offsety==-500)
   {
      %player.offsety = 500;
   }
   else if((%player.offsety<=500)&&(%player.offsety>300))
   {
      %player.offsety = %player.offsety - 50;
   }
   else if((%player.offsety<=300)&&(%player.offsety>200))
   {
      %player.offsety = %player.offsety - 25;
   }
   else if((%player.offsety<=200)&&(%player.offsety>100))
   {
      %player.offsety = %player.offsety - 10;
   }
   else if((%player.offsety<=100)&&(%player.offsety>25))
   {
      %player.offsety = %player.offsety - 5;
   }
   else if((%player.offsety<=25)&&(%player.offsety>0))
   {
      %player.offsety = %player.offsety - 1;
   }
   say(%player, %player, "<F1>Offset Y: <F5>" @ %player.offsety @ " Meters");
}

function offsetzToggle(%player)
{
   if((%player.offsetz>=0)&&(%player.offsetz<25))
   {
      %player.offsetz++;
   }
   else if((%player.offsetz>=25)&&(%player.offsetz<100))
   {
      %player.offsetz = %player.offsetz + 5;
   }
   else if((%player.offsetz>=100)&&(%player.offsetz<200))
   {
      %player.offsetz = %player.offsetz + 10;
   }
   else if((%player.offsetz>=200)&&(%player.offsetz<300))
   {
      %player.offsetz = %player.offsetz + 25;
   }
   else if((%player.offsetz>=300)&&(%player.offsetz<500))
   {
      %player.offsetz = %player.offsetz + 50;
   }
   else if(%player.offsetz==500)
   {
      %player.offsetz = -500;
   }
   else if((%player.offsetz>=-500)&&(%player.offsetz<-300))
   {
      %player.offsetz = %player.offsetz + 50;
   }
   else if((%player.offsetz>=-300)&&(%player.offsetz<-200))
   {
      %player.offsetz = %player.offsetz + 25;
   }
   else if((%player.offsetz>=-200)&&(%player.offsetz<-100))
   {
      %player.offsetz = %player.offsetz + 10;
   }
   else if((%player.offsetz>=-100)&&(%player.offsetz<-25))
   {
      %player.offsetz = %player.offsetz + 5;
   }
   else if((%player.offsetz>=-25)&&(%player.offsetz<0))
   {
      %player.offsetz = %player.offsetz + 1;
   }
   say(%player, %player, "<F1>Offset Z: <F5>" @ %player.offsetz @ " Meters");
}

function offsetzToggleDown(%player)
{
   if((%player.offsetz<=0)&&(%player.offsetz>-25))
   {
      %player.offsetz--;
   }
   else if((%player.offsetz<=-25)&&(%player.offsetz>-100))
   {
      %player.offsetz = %player.offsetz - 5;
   }
   else if((%player.offsetz<=-100)&&(%player.offsetz>-200))
   {
      %player.offsetz = %player.offsetz - 10;
   }
   else if((%player.offsetz<=-200)&&(%player.offsetz>-300))
   {
      %player.offsetz = %player.offsetz - 25;
   }
   else if((%player.offsetz<=-300)&&(%player.offsetz>-500))
   {
      %player.offsetz = %player.offsetz - 50;
   }
   else if(%player.offsetz==-500)
   {
      %player.offsetz = 500;
   }
   else if((%player.offsetz<=500)&&(%player.offsetz>300))
   {
      %player.offsetz = %player.offsetz - 50;
   }
   else if((%player.offsetz<=300)&&(%player.offsetz>200))
   {
      %player.offsetz = %player.offsetz - 25;
   }
   else if((%player.offsetz<=200)&&(%player.offsetz>100))
   {
      %player.offsetz = %player.offsetz - 10;
   }
   else if((%player.offsetz<=100)&&(%player.offsetz>25))
   {
      %player.offsetz = %player.offsetz - 5;
   }
   else if((%player.offsetz<=25)&&(%player.offsetz>0))
   {
      %player.offsetz = %player.offsetz - 1;
   }
   say(%player, %player, "<F1>Offset Z: <F5>" @ %player.offsetz @ " Meters");
}

function remoteSetStructure(%player)
{
   %vehicleId = playerManager::playerNumToVehicleId(%player);
   if(%player.structureNum==10)
   {
      say(%player, %player, "<F1>You have reached your maximum number of structures allowed (10). You must delete some of your existing structures to create new ones.");
      return;
   }
   else if(%player.build1==0)
   {
      %player.build1 = 1;
      %player.structure1 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure1;
      %player.structure1rot = %player.rotation;
   }
   else if(%player.build2==0)
   {
      %player.build2 = 1;
      %player.structure2 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure2;
      %player.structure2rot = %player.rotation;
   }
   else if(%player.build3==0)
   {
      %player.build3 = 1;
      %player.structure3 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure3;
      %player.structure3rot = %player.rotation;
   }
   else if(%player.build4==0)
   {
      %player.build4 = 1;
      %player.structure4 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure4;
      %player.structure4rot = %player.rotation;
   }
   else if(%player.build5==0)
   {
      %player.build5 = 1;
      %player.structure5 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure5;
      %player.structure5rot = %player.rotation;
   }
   else if(%player.build6==0)
   {
      %player.build6 = 1;
      %player.structure6 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure6;
      %player.structure6rot = %player.rotation;
   }
   else if(%player.build7==0)
   {
      %player.build7 = 1;
      %player.structure7 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure7;
      %player.structure7rot = %player.rotation;
   }
   else if(%player.build8==0)
   {
      %player.build8 = 1;
      %player.structure8 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure8;
      %player.structure8rot = %player.rotation;
   }
   else if(%player.build9==0)
   {
      %player.build9 = 1;
      %player.structure9 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure9;
      %player.structure9rot = %player.rotation;
   }
   else if(%player.build10==0)
   {
      %player.build10 = 1;
      %player.structure10 = newObject(%player.shapename, %player.static, %player.shape);
      %structure = %player.structure10;
      %player.structure10rot = %player.rotation;
   }
   %player.structureNum++;
   setTeam(%structure, *IDSTR_TEAM_NEUTRAL);
   %x = getPosition(%vehicleId, x);
   %y = getPosition(%vehicleId, y);
   %z = getPosition(%vehicleId, z);
   setPosition(%structure, (%x + %player.offsetx), (%y + %player.offsety), (%z + %player.offsetz), %player.rotation, %player.angle);
   say(%player, %player, "<F1>Structure created.");
   schedule("playAnimSequence(" @ %structure @ ", 0, true);",3);
}

function structure::onAttacked(%attacked, %attacker)
{
   %player = playerManager::vehicleIdToPlayerNum(%attacker);
   if(%player.firefunction=="delete")
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         schedule("deleteStructure(" @ %player @ ", " @ %attacked @ ");", 0.5);
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
   else if(%player.firefunction=="adjustxPos")
   {
      adjustxPos(%player, %attacked);
   }
   else if(%player.firefunction=="adjustxNeg")
   {
      adjustxNeg(%player, %attacked);
   }
   else if(%player.firefunction=="adjustyPos")
   {
      adjustyPos(%player, %attacked);
   }
   else if(%player.firefunction=="adjustyNeg")
   {
      adjustyNeg(%player, %attacked);
   }
   else if(%player.firefunction=="adjustzPos")
   {
      adjustzPos(%player, %attacked);
   }
   else if(%player.firefunction=="adjustzNeg")
   {
      adjustzNeg(%player, %attacked);
   }
   else if(%player.firefunction=="adjustRotPos")
   {
      adjustRotPos(%player, %attacked);
   }
   else if(%player.firefunction=="adjustRotNeg")
   {
      adjustRotNeg(%player, %attacked);
   }
}

function deleteStructure(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build1 = 0;
      %player.structure1 = "deleted";
      %player.structure1rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure2)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build2 = 0;
      %player.structure2 = "deleted";
      %player.structure2rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure3)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build3 = 0;
      %player.structure3 = "deleted";
      %player.structure3rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure4)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build4 = 0;
      %player.structure4 = "deleted";
      %player.structure4rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure5)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build5 = 0;
      %player.structure5 = "deleted";
      %player.structure5rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure6)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build6 = 0;
      %player.structure6 = "deleted";
      %player.structure6rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure7)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build7 = 0;
      %player.structure7 = "deleted";
      %player.structure7rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure8)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build8 = 0;
      %player.structure8 = "deleted";
      %player.structure8rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure9)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build9 = 0;
      %player.structure9 = "deleted";
      %player.structure9rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else if(%attacked==%player.structure10)
   {
      deleteObject(%attacked);
      %player.structureNum--;
      %player.build10 = 0;
      %player.structure10 = "deleted";
      %player.structure10rot = 0;
      say(%player, %player, "<F1>Structure deleted.");
   }
   else
   {
      say(%player, %player, "<F1>You cannot delete another player's structure.");
   }
}

function adjustxPos(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
   }
   else if(%attacked==%player.structure2)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
   }
   else if(%attacked==%player.structure3)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
   }
   else if(%attacked==%player.structure4)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
   }
   else if(%attacked==%player.structure5)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
   }
   else if(%attacked==%player.structure6)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
   }
   else if(%attacked==%player.structure7)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
   }
   else if(%attacked==%player.structure8)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
   }
   else if(%attacked==%player.structure9)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
   }
   else if(%attacked==%player.structure10)
   {
      %x = getPosition(%attacked, x) + 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustxNeg(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
   }
   else if(%attacked==%player.structure2)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
   }
   else if(%attacked==%player.structure3)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
   }
   else if(%attacked==%player.structure4)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
   }
   else if(%attacked==%player.structure5)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
   }
   else if(%attacked==%player.structure6)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
   }
   else if(%attacked==%player.structure7)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
   }
   else if(%attacked==%player.structure8)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
   }
   else if(%attacked==%player.structure9)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
   }
   else if(%attacked==%player.structure10)
   {
      %x = getPosition(%attacked, x) - 1;
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustyPos(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
   }
   else if(%attacked==%player.structure2)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
   }
   else if(%attacked==%player.structure3)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
   }
   else if(%attacked==%player.structure4)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
   }
   else if(%attacked==%player.structure5)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
   }
   else if(%attacked==%player.structure6)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
   }
   else if(%attacked==%player.structure7)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
   }
   else if(%attacked==%player.structure8)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
   }
   else if(%attacked==%player.structure9)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
   }
   else if(%attacked==%player.structure10)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) + 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustyNeg(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
   }
   else if(%attacked==%player.structure2)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
   }
   else if(%attacked==%player.structure3)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
   }
   else if(%attacked==%player.structure4)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
   }
   else if(%attacked==%player.structure5)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
   }
   else if(%attacked==%player.structure6)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
   }
   else if(%attacked==%player.structure7)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
   }
   else if(%attacked==%player.structure8)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
   }
   else if(%attacked==%player.structure9)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
   }
   else if(%attacked==%player.structure10)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y) - 1;
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustzPos(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
   }
   else if(%attacked==%player.structure2)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
   }
   else if(%attacked==%player.structure3)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
   }
   else if(%attacked==%player.structure4)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
   }
   else if(%attacked==%player.structure5)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
   }
   else if(%attacked==%player.structure6)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
   }
   else if(%attacked==%player.structure7)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
   }
   else if(%attacked==%player.structure8)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
   }
   else if(%attacked==%player.structure9)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
   }
   else if(%attacked==%player.structure10)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) + 1;
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustzNeg(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
   }
   else if(%attacked==%player.structure2)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
   }
   else if(%attacked==%player.structure3)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
   }
   else if(%attacked==%player.structure4)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
   }
   else if(%attacked==%player.structure5)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
   }
   else if(%attacked==%player.structure6)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
   }
   else if(%attacked==%player.structure7)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
   }
   else if(%attacked==%player.structure8)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
   }
   else if(%attacked==%player.structure9)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
   }
   else if(%attacked==%player.structure10)
   {
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z) - 1;
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustRotPos(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {  
      if(%player.structure1rot==345)
      {
         %player.structure1rot = 0;
      }
      else
      {
         %player.structure1rot = %player.structure1rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure1rot @ " degrees.");
   }
   else if(%attacked==%player.structure2)
   {
      if(%player.structure2rot==345)
      {
         %player.structure2rot = 0;
      }
      else
      {
         %player.structure2rot = %player.structure2rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure2rot @ " degrees.");
   }
   else if(%attacked==%player.structure3)
   {
      if(%player.structure3rot==345)
      {
         %player.structure3rot = 0;
      }
      else
      {
         %player.structure3rot = %player.structure3rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure3rot @ " degrees.");
   }
   else if(%attacked==%player.structure4)
   {
      if(%player.structure4rot==345)
      {
         %player.structure4rot = 0;
      }
      else
      {
         %player.structure4rot = %player.structure4rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure4rot @ " degrees.");
   }
   else if(%attacked==%player.structure5)
   {
      if(%player.structure5rot==345)
      {
         %player.structure5rot = 0;
      }
      else
      {
         %player.structure5rot = %player.structure5rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure5rot @ " degrees.");
   }
   else if(%attacked==%player.structure6)
   {
      if(%player.structure6rot==345)
      {
         %player.structure6rot = 0;
      }
      else
      {
         %player.structure6rot = %player.structure6rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure6rot @ " degrees.");
   }
   else if(%attacked==%player.structure7)
   {
      if(%player.structure7rot==345)
      {
         %player.structure7rot = 0;
      }
      else
      {
         %player.structure7rot = %player.structure7rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure7rot @ " degrees.");
   }
   else if(%attacked==%player.structure8)
   {
      if(%player.structure8rot==345)
      {
         %player.structure8rot = 0;
      }
      else
      {
         %player.structure8rot = %player.structure8rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure8rot @ " degrees.");
   }
   else if(%attacked==%player.structure9)
   {
      if(%player.structure9rot==345)
      {
         %player.structure9rot = 0;
      }
      else
      {
         %player.structure9rot = %player.structure9rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure9rot @ " degrees.");
   }
   else if(%attacked==%player.structure10)
   {
      if(%player.structure10rot==345)
      {
         %player.structure10rot = 0;
      }
      else
      {
         %player.structure10rot = %player.structure10rot + 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure10rot @ " degrees.");
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function adjustRotNeg(%player, %attacked)
{
   if(%attacked==%player.structure1)
   {  
      if(%player.structure1rot==0)
      {
         %player.structure1rot = 345;
      }
      else
      {
         %player.structure1rot = %player.structure1rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure1rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure1rot @ " degrees.");
   }
   else if(%attacked==%player.structure2)
   {
      if(%player.structure2rot==0)
      {
         %player.structure2rot = 345;
      }
      else
      {
         %player.structure2rot = %player.structure2rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure2rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure2rot @ " degrees.");
   }
   else if(%attacked==%player.structure3)
   {
      if(%player.structure3rot==0)
      {
         %player.structure3rot = 345;
      }
      else
      {
         %player.structure3rot = %player.structure3rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure3rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure3rot @ " degrees.");
   }
   else if(%attacked==%player.structure4)
   {
      if(%player.structure4rot==0)
      {
         %player.structure4rot = 345;
      }
      else
      {
         %player.structure4rot = %player.structure4rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure4rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure4rot @ " degrees.");
   }
   else if(%attacked==%player.structure5)
   {
      if(%player.structure5rot==0)
      {
         %player.structure5rot = 345;
      }
      else
      {
         %player.structure5rot = %player.structure5rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure5rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure5rot @ " degrees.");
   }
   else if(%attacked==%player.structure6)
   {
      if(%player.structure6rot==0)
      {
         %player.structure6rot = 345;
      }
      else
      {
         %player.structure6rot = %player.structure6rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure6rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure6rot @ " degrees.");
   }
   else if(%attacked==%player.structure7)
   {
      if(%player.structure7rot==0)
      {
         %player.structure7rot = 345;
      }
      else
      {
         %player.structure7rot = %player.structure7rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure7rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure7rot @ " degrees.");
   }
   else if(%attacked==%player.structure8)
   {
      if(%player.structure8rot==0)
      {
         %player.structure8rot = 345;
      }
      else
      {
         %player.structure8rot = %player.structure8rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure8rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure8rot @ " degrees.");
   }
   else if(%attacked==%player.structure9)
   {
      if(%player.structure9rot==0)
      {
         %player.structure9rot = 345;
      }
      else
      {
         %player.structure9rot = %player.structure9rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure9rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure9rot @ " degrees.");
   }
   else if(%attacked==%player.structure10)
   {
      if(%player.structure10rot==0)
      {
         %player.structure10rot = 345;
      }
      else
      {
         %player.structure10rot = %player.structure10rot - 15;
      }
      %x = getPosition(%attacked, x);
      %y = getPosition(%attacked, y);
      %z = getPosition(%attacked, z);
      setPosition(%attacked, %x, %y, %z, %player.structure10rot);
      say(%player, %player, "<F1>Structure rotated to " @ %player.structure10rot @ " degrees.");
   }
   else
   {
      if(%player.delay==false)
      {
         %player.delay = true;
         say(%player, %player, "<F1>You cannot adjust another player's structure.");
         schedule("playerDelayFalse(" @ %player @ ");",1);
      }
   }
}

function playerDelayFalse(%player)
{
   %player.delay = false;
}