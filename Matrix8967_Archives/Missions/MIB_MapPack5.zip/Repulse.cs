// Repulser Script by Com. Sentinal [M.I.B.]

function setStuff()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.lock = false;
      %player.alive = true;
   }
}

focusserver(); setStuff(); focusclient();

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   %player.lock = false;
   %player.alive = true;
}

function vehicle::onScan(%scanned, %scanner)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%scanner);
   %player2 = playerManager::vehicleIdToPlayerNum(%scanned);
   if((getConnection(%player1) == "LOOPBACK")&&(%player2.lock == false))
   {
      %player2.lock = true;
      %x1 = getPosition(%scanned, x);
      %y1 = getPosition(%scanned, y);
      %nav = getVehicleNavMarkerId(%scanner);
      %x2 = getPosition(%nav, x);
      %y2 = getPosition(%nav, y);
      %distance = getDistance(%scanned, %nav);
      %increments = %distance / 10;
      %xDist = %x2 - %x1;
      %yDist = %y2 - %y1;
      %xOffset = %xDist / %increments;
      %yOffset = %yDist / %increments;
      repulse(%scanned, %xOffset, %yOffset, %increments);
   }
}

function vehicle::onSpot(%spotter, %target)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%spotter);
   %player2 = playerManager::vehicleIdToPlayerNum(%target);
   if((getConnection(%player1) == "LOOPBACK")&&(%player2.lock == false))
   {
      %player2.lock = true;
      %x1 = getPosition(%target, x);
      %y1 = getPosition(%target, y);
      %nav = getVehicleNavMarkerId(%spotter);
      %x2 = getPosition(%nav, x);
      %y2 = getPosition(%nav, y);
      %distance = getDistance(%target, %nav);
      %increments = %distance / 10;
      %xDist = %x2 - %x1;
      %yDist = %y2 - %y1;
      %xOffset = %xDist / %increments;
      %yOffset = %yDist / %increments;
      repulse(%target, %xOffset, %yOffset, %increments);
   }
}

function repulse(%vehicleId, %xOffset, %yOffset, %increments)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if((%increments > 1)&&(%player.alive == true))
   {
      %increments--;
      %x = getPosition(%vehicleId, x) + %xOffset;
      %y = getPosition(%vehicleId, y) + %yOffset;
      %z = getTerrainHeight(%x, %y);
      setPosition(%vehicleId, %x, %y, %z);
      schedule("repulse(" @ %vehicleId @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %increments @ ");", 0.1);
   }
   else
   {
      %player.lock = false;
      if(%player.alive == true)
      {
         say("Everybody", 2, "<F5>" @ getName(%player) @ " has reached his destination.", "alarm2.wav");
      }
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player.alive = false;

   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer))&&(%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}