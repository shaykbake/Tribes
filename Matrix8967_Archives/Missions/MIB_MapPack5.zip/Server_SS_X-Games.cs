// FILENAME: Server_SS_X-Games.cs
//
// Starsiege X-Games Dedicated Server file


exec(serverLocation);
//-------------------------------------------------
//  RC file to start a server automatically
//-------------------------------------------------

//-------------------------------------------------
// Edit the parameters of this file to configure
// your server options. Use notepad, not a word
// processor. File must be saved as text only.
//-------------------------------------------------

//-------------------------------------------------
// Type the name for your server inside the quotes
// Must be less then 22 characters
//-------------------------------------------------
$server::Hostname = strcat($Location, ": SS X-Games!!!");

//-------------------------------------------------
// Password Protection. Leave blank for none.
// Quotes optional.
//-------------------------------------------------
$server::Password =                                 "";

//-------------------------------------------------
// Maximum player limit. 16 is highest recommended.
//-------------------------------------------------
$server::MaxPlayers =                              20;

//-------------------------------------------------
// Number of kills before server cycles.
// If zero, kills are never reset.
//-------------------------------------------------
$server::FragLimit =                               0;

//-------------------------------------------------
// Time limit in minutes before server cycles.
// Must be a positive integer.
//-------------------------------------------------
$server::TimeLimit =                               0;

//-------------------------------------------------
// Mass limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::MassLimit =                                0;

//-------------------------------------------------
// Combat Value limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::CombatValueLimit =                         0;

//-------------------------------------------------
// Team play options. TeamPlay false =  deathmatch.
// TeamPlay true = teams
//-------------------------------------------------
$server::TeamPlay =                                FALSE;

//-------------------------------------------------
// Team Mass limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamMassLimit =                            0;

//-------------------------------------------------
// Team Combat Value Limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamCombatValueLimit =                     0;

//-------------------------------------------------
// Tech Level Limit
// Must be a positive integer less then or
// equal to 128 or zero for no limit.
//-------------------------------------------------
$server::TechLevelLimit =                          0;

//-------------------------------------------------
// Drop In Progress
// Does server allow drop in progress??
//-------------------------------------------------
$server::DropInProgress =                            TRUE  ;

$server::AllowMixedTech =                            TRUE  ;
$server::FactoryVehOnly =                           FALSE  ;

//-------------------------------------------------
// Mission rotation list. This is the order the
// worlds will cycle in a game with either the frag
// or time limits set.
//-------------------------------------------------
$MissionCycling::Stage0 =                          "SS_X-Games";

//-------------------------------------------------
// Start mission. Defines which mission from the
// rotation list the server starts on.
//-------------------------------------------------
$server::Mission = $MissionCycling::Stage0;

// These items will be allowed by default -- your mission script can change these
// by calling allowVehicle, allowComponent, or allowWeapon
function setAllowedItems()
{
	//Vehicles
	exec("defaultVehicles.cs");

      allowVehicle(  all, TRUE  );
      allowVehicle(  1, FALSE  );
      allowVehicle(  3, FALSE  );
      allowVehicle(  5, FALSE  );
      allowVehicle(  7, FALSE  );
      allowVehicle(  10, FALSE  );
      allowVehicle(  12, FALSE  );
      allowVehicle(  14, FALSE  );
      allowVehicle(  16, FALSE  );
      allowVehicle(  22, FALSE  );
      allowVehicle(  23, FALSE  );
      allowVehicle(  24, FALSE  );
      allowVehicle(  27, FALSE  );
      allowVehicle(  28, FALSE  );
      allowVehicle(  29, FALSE  );
      allowVehicle(  33, FALSE  );
      allowVehicle(  37, FALSE  );
      allowVehicle(  38, FALSE  );
      allowVehicle(  39, FALSE  );
      allowVehicle(  55, FALSE  );
      allowVehicle(  56, FALSE  );
   
      allowWeapon( all, TRUE );
      allowWeapon( 3, FALSE );    //Disrupter Weapon  
      allowWeapon( 110, FALSE );  //Plasma Cannon    
      allowWeapon( 124, FALSE );  //Missiles
      allowWeapon( 125, FALSE );
      allowWeapon( 126, FALSE );
      allowWeapon( 127, FALSE );
      allowWeapon( 128, FALSE );

      allowWeapon( 129, FALSE );
      allowWeapon( 130, FALSE );
      allowWeapon( 131, FALSE );  //Arachnitrons
      allowWeapon( 132, FALSE );
      allowWeapon( 133, FALSE );
      allowWeapon( 134, FALSE );  //Proximity Mines
      allowWeapon( 135, FALSE );
      allowWeapon( 136, FALSE );
      allowWeapon( 142, FALSE );  //Radiation Gun
      allowWeapon( 147, FALSE );  //More Missiles
      allowWeapon( 150, FALSE );  //Smart Gun
      
      allowComponent( all, TRUE );
}

