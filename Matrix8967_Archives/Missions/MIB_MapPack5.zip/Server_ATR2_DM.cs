// FILENAME: Server_ATR2_DM.cs
//
//Regular Deathmatch Server with no limitations


exec(serverLocation);
//-------------------------------------------------
//  RC file to start a server automatically
//-------------------------------------------------

//-------------------------------------------------
// Edit the parameters of this file to configure
// your server options. Use notepad, not a word
// processor. File must be saved as text only.
//-------------------------------------------------

//-------------------------------------------------
// Type the name for your server inside the quotes
// Must be less then 22 characters
//-------------------------------------------------
$server::Hostname = strcat("ATR2 Deathmatch");

//-------------------------------------------------
// Password Protection. Leave blank for none.
// Quotes optional.
//-------------------------------------------------
$server::Password =                                 "";

//-------------------------------------------------
// Maximum player limit. 16 is highest recommended.
//-------------------------------------------------
$server::MaxPlayers =                              16;

//-------------------------------------------------
// Number of kills before server cycles.
// If zero, kills are never reset.
//-------------------------------------------------
$server::FragLimit =                               0;

//-------------------------------------------------
// Time limit in minutes before server cycles.
// Must be a positive integer.
//-------------------------------------------------
$server::TimeLimit =                               30;

//-------------------------------------------------
// Mass limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::MassLimit =                                0;

//-------------------------------------------------
// Combat Value limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::CombatValueLimit =                         0;

//-------------------------------------------------
// Team play options. TeamPlay false =  deathmatch.
// TeamPlay true = teams
//-------------------------------------------------
$server::TeamPlay =                                FALSE;

//-------------------------------------------------
// Team Mass limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamMassLimit =                            0;

//-------------------------------------------------
// Team Combat Value Limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamCombatValueLimit =                     0;

//-------------------------------------------------
// Tech Level Limit
// Must be a positive integer less then or
// equal to 128 or zero for no limit.
//-------------------------------------------------
$server::TechLevelLimit =                          0;

//-------------------------------------------------
// Drop In Progress
// Does server allow drop in progress??
//-------------------------------------------------
$server::DropInProgress =                            TRUE  ;

$server::AllowMixedTech =                            TRUE  ;
$server::FactoryVehOnly =                           FALSE  ;

//-------------------------------------------------
// Mission rotation list. This is the order the
// worlds will cycle in a game with either the frag
// or time limits set.
//-------------------------------------------------
$MissionCycling::Stage0 =                          "ATR2_DM_Cold_Titan_Night";
$MissionCycling::Stage1 =                          "ATR2_DM_Heavens_Peak";
$MissionCycling::Stage2 =                          "ATR2_DM_Terran_Conquest";
$MissionCycling::Stage3 =                          "ATR2_DM_Twin_Siege";

//-------------------------------------------------
// Start mission. Defines which mission from the
// rotation list the server starts on.
//-------------------------------------------------
$server::Mission = $MissionCycling::Stage0;

// These items will be allowed by default -- your mission script can change these
// by calling allowVehicle, allowComponent, or allowWeapon
function setAllowedItems()
{
//Vehicles
   exec("defaultVehicles.cs");
   allowVehicle(                                          all, FALSE  );
   allowVehicle(                                            2, TRUE  );  //Minotaur
   allowVehicle(                                           30, TRUE  );  //Emancipator
   allowVehicle(                                           21, TRUE  );  //Goad
   allowVehicle(                                            7, TRUE  );  //Myrmidon
   
   allowWeapon(                                           all, FALSE  );
   allowWeapon(                                           101, TRUE  );  //Laser
   allowWeapon(                                           105, TRUE  );  //EMP
   allowWeapon(                                           107, TRUE  );  //Blaster
   allowWeapon(                                           116, TRUE  );  //ATC
   allowWeapon(                                           119, TRUE  );  //Blast Cannon
   allowWeapon(                                           126, TRUE  );  //Sparrow Missile Pack 6
   allowWeapon(                                           127, TRUE  );  //Sparrow Missile Pack 10

   allowComponent(                                        all, TRUE  );
   allowComponent(                                        800, FALSE  );  //Computers Restricted
   allowComponent(                                        802, FALSE  );  
   allowComponent(                                        805, FALSE  );  
   allowComponent(                                        806, FALSE  );  
   allowComponent(                                        807, FALSE  );  
   allowComponent(                                        809, FALSE  );  //Jammers Restricted
   allowComponent(                                        811, FALSE  );  
   allowComponent(                                        812, FALSE  );  
   allowComponent(                                        813, FALSE  );  
   allowComponent(                                        820, FALSE  );  //Thermal Diffuser
   allowComponent(                                        845, FALSE  );  //SCAP
   allowComponent(                                        850, FALSE  );  //SAMP
   allowComponent(                                        860, FALSE  );  //LTADs
   allowComponent(                                        865, FALSE  );  //Battery
   allowComponent(                                        870, FALSE  );  //CAP
   allowComponent(                                        875, FALSE  );  //Field Stabilizer
   allowComponent(                                        880, FALSE  );  //Rocket Booster
   allowComponent(                                        885, FALSE  );  //Turbine Booster
   allowComponent(                                        890, FALSE  );  //Nano-Repair Module
   allowComponent(                                        900, FALSE  );  //Angel Life Support
   allowComponent(                                        910, FALSE  );  //Anti-Gravity Gen
   allowComponent(                                        912, FALSE  );  //Electrohull
   allowComponent(                                        914, FALSE  );  //UAP
   allowComponent(                                        931, FALSE  );  //Quicksilver Nano-Armor
}


