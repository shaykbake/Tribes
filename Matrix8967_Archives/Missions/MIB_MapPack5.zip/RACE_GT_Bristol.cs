// FILENAME: RACE_GT_Bristol.cs
//
// TRACK CREATOR: Com. Sentinal [M.I.B.]
//
// Original NASHERC Racing script created by Com. Sentinal [M.I.B.].
//------------------------------------------------------------------------------ 

//Fill out these global variables before you make a custom race track!!!
//------------------------------------------------------------------------------
$missionName = "Bristol Motor Speedway"; //Track Name

//Different series allow different vehicles, weapons, components,
//mass limits, and tech mixing options.
//Keep the series name & abbreviation the same if you don't want 
//to change the current restrictions.
//If you want to change the series, merely change the series name
//and abbreviation to one of the following:
//
//1.  "Winston Cup" & "WC"        //Allows Emans, Goads, Talons, & Seekers
//2.  "Busch" & "BSH"             //Allows Knight's Apocs (turbines)
//3.  "Seeker" & "SK"             //Allows Seekers (turbines & rockets)
//4.  "Craftsman Tank" & "TK"     //Allows Bolos, Preds, & Disrupters (turbines)
//5.  "Goad/Talon" & "GT"         //Allows Goads & Talons
//
//The script will automatically recognize the series name you chose
//and will use it's restriction settings in the game.

$Series = "Goad/Talon";  //Series name
$SeriesAbbreviation = "GT";  //Series Abbreviation

//The mission creator is used in the download message.
//The download message is used if you have any custom message you would 
//like to add when a player joins the game.

$missionCreator = "Com. Sentinal [M.I.B.]";
$downloadMessage = "You can download this & other missions made by " @ $missionCreator @ " in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.";

//These are the coordinates where you respawn if you die during the race.
//You always start at the last checkpoint you crossed.
//Be sure to fill these out if you're making a custom track.
//------------------------------------------------------------------------------

//Checkpoint #1 coordinates
$checkpoint1x = -191.844; //Checkpoint #1 x coordinate
$checkpoint1y = 829.709;  //Checkpoint #1 y coordinate
$checkpoint1z = 114;  //Checkpoint #1 z coordinate
$checkpoint1rot = 180;  //Checkpoint #1 rotation coordinate

//Checkpoint #2 coordinates
$checkpoint2x = -189.988;  //Checkpoint #2 x coordinate
$checkpoint2y = 201.014;  //Checkpoint #2 y coordinate
$checkpoint2z = 111;  //Checkpoint #2 z coordinate
$checkpoint2rot = 180;  //Checkpoint #2 rotation coordinate

//Making a custom NASHERC RaceTrack
//------------------------------------------------------------------------------
//First, make sure you filled out all of the global variables above.
//You do not need to change anything below this point in the script to
//make a custom track.
//The following is instructions on how to make a custom race track in the
//Starsiege Mission Editor:
//
//#1 - First you must have a track built that is fully enclosed and has
//a pit road. Make sure that the pit road is placed so that it doesn't
//become a short-cut. I recommend that your pit road contain 2-3 zen pads.
//Make sure that your Zen pad triggers have the script class "ZenAll".
//
//#2 - Next, you must place certain triggers around the track.
//VERY IMPORTANT: Make sure that all of the triggers in the map have
//"Is Sphere" disabled. IF they DO NOT have it disabled, then errors in 
//lap scoring WILL occur. The following is a list of the triggers that 
//you need and where they must be placed in order to work correctly. 
//The name of each trigger refers to the script class that must be used:
//
//    A. - The "finishline" trigger should be placed at the start/finish line.
//    B. - The "checkpoint1" trigger should be placed 1/3 of the way around
//         the track.
//    C. - The "checkpoint2" trigger should be placed 2/3 of the way around
//         the track.
//    D. - The "pitroad" trigger should be placed at the beginning of pit road.
//    E. - The "exitpitroad" trigger should be placed at the end of pit road.
//
//#3 - Next, you must make a folder in Missiongroup called "StartGates".
//Inside that folder, you must put in 2 bridges. Name one of them "StartGate"
//and name the other one "BackWall". Make sure that their script class is
//named this as well as their object names. Rotate the bridges so that they
//become walls. Place the one called "StartGate" right before the
//"finishline" trigger. Make sure that you allow enough space between the
//"startGate" wall and the "finishline" trigger. Then, lower the "StartGate"
//wall into the ground so that a herc can see over it. Next, place the
//"BackWall" wall about 100-150 meters behind the "StartGate" wall. Leave
//the "BackWall" wall high, so that nothing can see over it.
//
//#4 - Next, place 10 deathmatch drop points between the "StartGate" & the
//"Backwall".
//
//#5 - Finally, get the coordinates for the checkpoint triggers & write them
//in their proper location at the top of the script.
//
//Now, your custom NASHERC RaceTrack should work perfect IF you followed
//the directions above for making the track & filled in the global variables
//at the top of the script.
//------------------------------------------------------------------------------ 

exec("multiplayerStdLib.cs"); 

function setDefaultMissionOptions()
{
   $server::TeamPlay = false;
   $server::AllowDeathmatch = true;
   $server::AllowTeamPlay = false;
 
   // what can the client choose for a team
   $server::AllowTeamRed = true;
   $server::AllowTeamBlue = true;
   $server::AllowTeamYellow = false;
   $server::AllowTeamPurple = false;
 
   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
   
   if($Series=="Winston Cup")
   {
      $server::AllowMixedTech = "False";
      $server::MassLimit = 0;
   }
   else if($Series=="Busch")
   {
      $server::AllowMixedTech = "True";
      $server::MassLimit = 40;
   }
   else if($Series=="Seeker")
   {
      $server::AllowMixedTech = "True";
      $server::MassLimit = 0;
   }
   else if($Series=="Craftsman Tank")
   {
      $server::AllowMixedTech = "False";
      $server::MassLimit = 45;
   }
   else if($Series=="Goad/Talon")
   {
      $server::AllowMixedTech = "False";
      $server::MassLimit = 0;
   }
   else
   {
      $server::AllowMixedTech = "True";
      $server::MassLimit = 0;
   }
} 

   $healRate = 100;   
   $ammoRate = 3;
   $padWaitTime = 0;
   $zenWaitTime = 0;
   $ThirtySecondsLeft = false;
   $racing = false;
   $winner = false;
   $countdown = false;
   $delay = false;
   $dm1 = true;
   $dm2 = false;
   $dm3 = false;
   $leader1 = true;
   $leader2 = true;
   $leader3 = true;
   $leader4 = true;
   $leader5 = true;

function onMissionStart()
{
   marsSounds();
   $startgate = getObjectId("MissionGroup\\startgates\\startgate");
   $backwall = getObjectId("MissionGroup\\startgates\\backwall");
   $ExtraWall = getObjectId("MissionGroup\\startgates\\extrawall");
} 

function onMissionLoad()
{
   cdAudioCycle("CloudBurst", "NewTech", "Mechsoul");
   setGameInfo("<F2>GAME TYPE:<F0>  NASHERC Racing\n\n<F2>TRACK:<F0>  " @ $missionName @ "\n\n<F2>SERIES:<F0>  " @ $Series @ "\n\nWelcome to NASHERC's " @ $missionName @ "! NASHERC's " @ $Series @ " Series (" @ $SeriesAbbreviation @ ") will be racing here today. When at least 2 players have joined the game, a 3-minute timer will begin counting down to the start of the race. During this time, players can setup their racing vehicles for optimum performance. After the race begins, players race around the track, trying to stay in front & destroy any other players they encounter. The first player to complete 5 laps is the winner. If a player's vehicle becomes damaged during the race, he can use the pits to repair/reload. " @ $downloadMessage @ " You can download the official NASHERC Racing skins in the \"Skinpack 2\" at www.starsiegeplayers.com.\n\n<F3>NASHERC Racing script created by Com. Sentinal [M.I.B.].<F0>"); 
   
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %playerId = playerManager::getPlayerNum(%i);
      %playerId.points = 0;
      %playerId.lapsled = 0;
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.lock = false;
      %playerId.fastestlap = "None";
      %playerId.late = false;
      %playerId.winnings = 0;
      %playerId.leadalap = 0;
      %playerId.record = %playerId.temp;
   }
}  

function player::onAdd(%playerId)
{
   say(%playerId, 0, "Welcome to NASHERC's " @ $missionName @ "! NASHERC's " @ $Series @ " Series (" @ $SeriesAbbreviation @ ") will be racing here today. Check the game info tab for the rules. " @ $downloadMessage @ " You can download the official NASHERC skins in the \"Skinpack 2\" at www.starsiegeplayers.com.");
   %playerId.points = 0;
   %playerId.check1 = 0;
   %playerId.check2 = 0;
   %playerId.lapsled = 0;
   %playerId.lock = false;
   %playerId.fastestlap = "None";
   %playerId.winnings = 0;
   %playerId.leadalap = 0;
   %playerId.record = 0;
   %playerId.temp = 0;
   %playerId.vehtype = "Unavailable";
   if($racing==true)
   {
      %playerId.late = true;
      messageBox(%playerId, "Welcome to NASHERC's " @ $missionName @ "! There is currently a race in progress. Please wait until the next race to play.");
   }
   else
   {
      %playerId.late = false;
   }
} 

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.name = getHUDName(%vehicleId);
   %vehicleId.vehicle = getVehicleName(%vehicleId);
   %playerId = playerManager::vehicleIdToPlayerNum(%vehicleId);
   %playerId.vehtype = %vehicleId.vehicle;
   if($countdown==false)
   {
      if(playerManager::getPlayerCount()==1)
      {
      %first = playerManager::vehicleIdToPlayerNum(%vehicleId);
      messageBox(%first, "At least 2 players must be in the server before the countdown to the race will begin. Please wait until another player joins the server to race.");
      }
      else if(playerManager::getPlayerCount()>=2)
      {
         $countdown = true;
         $countdownStartTime = getCurrentTime();
         countdown();
         say("Everybody", 1, "3 minutes until the race begins...");
         %sayTo = "\"Everybody\"";
         %txt1 = "\"2 minutes until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt1 @ ");", 60);
         %txt2 = "\"1 minute until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt2 @ ");", 120);
         schedule("$ThirtySecondsLeft = true;", 150);
         %txt3 = "\"30 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt3 @ ");", 150);
         %txt4 = "\"15 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt4 @ ");", 165);
         %txt5 = "\"10 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt5 @ ");", 170);
         %txt6 = "\"9 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt6 @ ");", 171);
         %txt7 = "\"8 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt7 @ ");", 172);
         %txt8 = "\"7 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt8 @ ");", 173);
         %txt9 = "\"6 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt9 @ ");", 174);
         %txt10 = "\"5 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt10 @ ");", 175);
         %txt11 = "\"4 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt11 @ ");", 176);
         %txt12 = "\"3 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt12 @ ");", 177);
         %txt13 = "\"2 seconds until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt13 @ ");", 178);
         %txt14 = "\"1 second until the race begins...\"";
         schedule("say(" @ %sayTo @ ", 1, " @ %txt14 @ ");", 179);
         schedule("startrace();", 180);
      }
   }
   if(($racing==false)&&($countdown==true))
   {
      $timeLeft = 180 - (getCurrentTime() -  $countdownStartTime);
      if($ThirtySecondsLeft==false)
      {
         setHudTimer($timeLeft, -1, "Race begins in:", 1, %vehicleId);
         %person = playerManager::vehicleIdToPlayerNum(%vehicleId);
         messagebox(%person, "The race has not started yet, please wait until the timer reaches zero to race.");
      }
      else if($ThirtySecondsLeft==true)
      {
         setHudTimer($timeLeft, -1, "Race begins in:", 1, %vehicleId);
         %person = playerManager::vehicleIdToPlayerNum(%object);
         say(%person, %person, "Get ready to race!");
      }
   }
   else if($racing==true)
   {
      if(%playerId.late==true)
      {
         healObject(%vehicleId, -50000); 
         %joiner = playerManager::vehicleIdToPlayerNum(%vehicleId);
         messageBox(%joiner, "You cannot enter the game while a race is in progress. Please wait until the next race to join.");
      }
      else if((%playerId.check1==1)&&(%playerId.check2==0))
      {
         setPosition(%vehicleId, $checkpoint1x, $checkpoint1y, $checkpoint1z, $checkpoint1rot);
         %person = playerManager::vehicleIdToPlayerNum(%vehicleId);
         say(%person, %person, "Hurry up " @ %vehicleId.name @ "! You can still catch up with the pack!");
      }
      else if((%playerId.check1==1)&&(%playerId.check2==1))
      {
         setPosition(%vehicleId, $checkpoint2x, $checkpoint2y, $checkpoint2z, $checkpoint2rot);
         %person = playerManager::vehicleIdToPlayerNum(%vehicleId);
         say(%person, %person, "Hurry up " @ %vehicleId.name @ "! You can still catch up with the pack!");  
      }
      else
      {
         %person = playerManager::vehicleIdToPlayerNum(%vehicleId);
         say(%person, %person, "Hurry up " @ %vehicleId.name @ "! You can still catch up with the pack!");
      }
   }
} 

function player::onRemove(%playerId)
{
   if($countdown==true)
   {
      if(playerManager::getPlayerCount()==2)
      {
         messageBox("Everybody", "All other players have forfeited the race. You are the winner!");
         schedule("missionEndConditionMet();", 5);
      }
      else if(playerManager::getPlayerCount()==1)
      {
         schedule("missionEndConditionMet();", 1);
      }
   }
}

function vehicle::onAttacked(%attacked, %attacker)
{
   if($racing==false)
   {
      healObject(%attacked, 10000);
      if($delay==false)
      {
         $delay = true;
         %offender = playerManager::vehicleIdToPlayerNum(%attacker);
         say(%offender, %offender, "You cannot attack a player until after the race begins!");
         schedule("$delay = false;", 3);
      }
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer) 
{ 
   %playerId = playerManager::vehicleIdToPlayerNum(%destroyed);
   if(($racing==true)&&($dm1==true)&&($dm2==false)&&($dm3==false)&&(%playerId.late==false))
   {  
      if(%destroyed!=%destroyer)
      {
         $dm1 = false;
         $dm2 = true;
         $dm3 = false;
         say("Everybody", 1, %destroyer.name @ " slammed " @ %destroyed.name @ " into the wall!");
      }
      else if(%destroyed==%destroyer)
      {
         $dm1 = false;
         $dm2 = true;
         $dm3 = false;
         say("Everybody", 1, %destroyed.name @ " has crashed!");
      }
   }
   else if(($racing==true)&&($dm1==false)&&($dm2==true)&&($dm3==false)&&(%playerId.late==false))
   {  
      $dm1 = false;
      $dm2 = false;
      $dm3 = true;
      say("Everybody", 1, %destroyed.name @ " has crashed!");
   }
   else if(($racing==true)&&($dm1==false)&&($dm2==false)&&($dm3==true)&&(%playerId.late==false))
   {  
      if(%destroyed!=%destroyer)
      {
         $dm1 = true;
         $dm2 = false;
         $dm3 = false;
         say("Everybody", 1, %destroyed.name @ " was crashed out of the race by " @ %destroyer.name @ "!");
      }
      else if(%destroyed==%destroyer)
      {
         $dm1 = true;
         $dm2 = false;
         $dm3 = false;
         say("Everybody", 1, %destroyed.name @ " has crashed!");
      }
   }
   else if($racing==false)
   {
      say("Everybody", 1, %destroyed.name @ " went back to the garage to work on his racing setup.");
   }
}

function checkpoint1::trigger::OnEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %playerId.check1 = 1;
   %player = playerManager::vehicleIdToPlayerNum(%object);
   say(%player, %player, "Checkpoint 1!");
} 

function checkpoint2::trigger::OnEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   if(%playerId.check1==1)
   {
   %playerId.check2 = 1;
   %player = playerManager::vehicleIdToPlayerNum(%object);
   say(%player, %player, "Checkpoint 2!");
   }
} 

function finishline::trigger::OnEnter(%this, %object)
{  
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   if((%playerId.check1==0)&&(%playerId.check2==0)&&(%playerId.points==0))
   {
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.time1 = getCurrentTime();
      say(%playerId, %playerId, "LAP 1!");
      if($leader1==true)
      {
         $leader1 = false;
         say("Everybody", 1, %object.name @ " takes the lead on lap 1!");
      }
   }
   else if((%playerId.check1==1)&&(%playerId.check2==1)&&(%playerId.points==0))
   {
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.laptime1 = timeDifference(getCurrentTime(), %playerId.time1);
      %playerId.time2 = getCurrentTime();
      %playerId.points++;
      say(%playerId, %playerId, "LAPTIME: " @ %playerId.laptime1);
      say(%playerId, %playerId, "LAP 2!");
      %playerId.fastlap = %playerId.laptime1;
      %playerId.fastestlap = "Lap 1 - " @ %playerId.laptime1;
      if($leader2==true)
      {  
         $leader2 = false;
         %playerId.lapsled++;
         say("Everybody", 1, "The leader, " @ %object.name @ ", is currently on lap 2.");
         if(%playerId.lapsled==1)
         {
            %playerId.leadalap = 4;
         }
      }
   }
   else if((%playerId.check1==1)&&(%playerId.check2==1)&&(%playerId.points==1))
   {
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.laptime2 = timeDifference(getCurrentTime(), %playerId.time2);
      %playerId.time3 = getCurrentTime();
      %playerId.points++;
      say(%playerId, %playerId, "LAPTIME: " @ %playerId.laptime2);
      say(%playerId, %playerId, "LAP 3!");
      if($leader3==true)
      {  
         $leader3 = false;
         %playerId.lapsled++;
         say("Everybody", 1, "The leader, " @ %object.name @ ", is currently on lap 3.");
         if(%playerId.lapsled==1)
         {
            %playerId.leadalap = 4;
         }
      }
      if(%playerId.laptime2<%playerId.fastlap)
      {
         %playerId.fastlap = %playerId.laptime2;
         %playerId.fastestlap = "Lap 2 - " @ %playerId.laptime2;
      }
   }
   else if((%playerId.check1==1)&&(%playerId.check2==1)&&(%playerId.points==2))
   {
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.laptime3 = timeDifference(getCurrentTime(), %playerId.time3);
      %playerId.time4 = getCurrentTime();
      %playerId.points++;
      say(%playerId, %playerId, "LAPTIME: " @ %playerId.laptime3);
      say(%playerId, %playerId, "LAP 4!");
      if($leader4==true)
      {  
         $leader4 = false;
         %playerId.lapsled++;
         say("Everybody", 1, "The leader, " @ %object.name @ ", is currently on lap 4.");
         if(%playerId.lapsled==1)
         {
            %playerId.leadalap = 4;
         }
      }
      if(%playerId.laptime3<%playerId.fastlap)
      {
         %playerId.fastlap = %playerId.laptime3;
         %playerId.fastestlap = "Lap 3 - " @ %playerId.laptime3;
      }
   }
   else if((%playerId.check1==1)&&(%playerId.check2==1)&&(%playerId.points==3))
   {
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.laptime4 = timeDifference(getCurrentTime(), %playerId.time4);
      %playerId.time5 = getCurrentTime();
      %playerId.points++;
      say(%playerId, %playerId, "LAPTIME: " @ %playerId.laptime4);
      say(%playerId, %playerId, "FINAL LAP!");
      if($leader5==true)
      {  
         $leader5 = false;
         %playerId.lapsled++;
         say("Everybody", 1, "The leader, " @ %object.name @ ", is on the final lap!");
         if(%playerId.lapsled==1)
         {
            %playerId.leadalap = 4;
         }
      }
      if(%playerId.laptime4<%playerId.fastlap)
      {
         %playerId.fastlap = %playerId.laptime4;
         %playerId.fastestlap = "Lap 4 - " @ %playerId.laptime4;
      }
   }
   else if((%playerId.check1==1)&&(%playerId.check2==1)&&(%playerId.points==4)&&($winner==false))
   {
      $winner = true;
      %playerId.winnings = 10;
      %playerId.check1 = 0;
      %playerId.check2 = 0;
      %playerId.laptime5 = timeDifference(getCurrentTime(), %playerId.time5);
      %playerId.points++;
      %playerId.lapsled++;
      if(%playerId.lapsled==1)
      {
         %playerId.leadalap = 4;
      }
      say(%playerId, %playerId, "LAPTIME: " @ %playerId.laptime5);
      if(%playerId.laptime5<%playerId.fastlap)
      {
         %playerId.fastlap = %playerId.laptime5;
         %playerId.fastestlap = "Lap 5 - " @ %playerId.laptime5;
      }
      say("Everybody", 1, %object.name @ " has won the race!");
      setFlybyCamera(%object , -15, 0, 15);
      messagebox("Everybody", %object.name @ " has won the race!");
      %count = playerManager::getPlayerCount();
      for(%i = 0; %i < %count; %i++)
      {
         %playerNumber = playerManager::getPlayerNum(%i);
         %playerNumber.temp = getStandings(%playerNumber);
      }
      schedule("missionEndConditionMet();",10);
   }
} 

function pitroad::trigger::OnEnter(%this, %object)
{
   %pitter = playerManager::vehicleIdToPlayerNum(%object);
   %pitter.lock = true;
   %pitter.pit = getCurrentTime();
   say("Everybody", 1, %object.name @ " is pitting.");
   say(%pitter, %pitter, "Entering pit road.");
}

function exitpitroad::trigger::OnEnter(%this, %object)
{
   %pitter = playerManager::vehicleIdToPlayerNum(%object);
   if(%pitter.lock==true)
   {
      %pitter.pittime = timeDifference(getCurrentTime(), %pitter.pit);
      say("Everybody", 1, %object.name @ "'s pitstop lasted " @ %pitter.pittime @ ". Now he's back out on the track!");
      say(%pitter, %pitter, "Leaving pit road.");
      %pitter.lock = false; 
   }
}

function startRace()
{
   $racing = true;
   setPosition($startgate, 900, 900, -500);
   setPosition($ExtraWall, 900, 900, -500);  //this is used only if you need an extra wall to move at the start of the race
   schedule("setPosition(" @ $backwall @ ", 900, 900, -500);", 7);
   say("Everybody", 1, "GREEN FLAG! GO GO GO!", "sfx_fog.WAV");
}

function countdown()
{
   countdownTimer(%time, %increment, %string, %channel);
}

function countdownTimer(%time, %increment, %string, %channel)
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %everybody = playerManager::getPlayerNum(%i);
      setHudTimer(180, -1, "Race begins in:", 1, %everybody);
   }
} 

function getPlayerScore(%playerId)
{
   return(%playerId.points);
}

function getLapsLed(%playerId)
{
   return(%playerId.lapsled);
}

function getFastestLap(%playerId)
{
   return(%playerId.fastestlap);
}

function getStandings(%playerId)
{
   return((getKills(%playerId)) + (%playerId.lapsled) + (%playerId.leadalap) + (%playerId.points) + (%playerId.winnings) + (%playerId.record));
}

function getVehicle(%playerId)
{  
   return(%playerId.vehtype);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_TEAM;
	   $ScoreBoard::PlayerColumnHeader2 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader3 = "Laps Completed";
	   $ScoreBoard::PlayerColumnHeader4 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader5 = *IDMULT_SCORE_DEATHS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getTeam";
	   $ScoreBoard::PlayerColumnFunction2 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction3 = "getPlayerScore";
	   $ScoreBoard::PlayerColumnFunction4 = "getKills";
	   $ScoreBoard::PlayerColumnFunction5 = "getDeaths";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
         $ScoreBoard::PlayerColumnHeader2 = "Laps Completed";
	   $ScoreBoard::PlayerColumnHeader3 = "Laps Led";
         $ScoreBoard::PlayerColumnHeader4 = "Fastest Lap";
         $ScoreBoard::PlayerColumnHeader5 = "Point Standings";
	   $ScoreBoard::PlayerColumnHeader6 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader7 = *IDMULT_SCORE_DEATHS;
         $ScoreBoard::PlayerColumnHeader8 = "Vehicle";
         
	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
         $ScoreBoard::PlayerColumnFunction2 = "getPlayerScore";
	   $ScoreBoard::PlayerColumnFunction3 = "getLapsLed";
         $ScoreBoard::PlayerColumnFunction4 = "getFastestLap";
         $ScoreBoard::PlayerColumnFunction5 = "getStandings";
	   $ScoreBoard::PlayerColumnFunction6 = "getKills";
	   $ScoreBoard::PlayerColumnFunction7 = "getDeaths";
         $ScoreBoard::PlayerColumnFunction8 = "getVehicle";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = "Laps Completed";
   $ScoreBoard::TeamColumnHeader2 = *IDMULT_SCORE_PLAYERS;
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;
   $ScoreBoard::TeamColumnHeader4 = *IDMULT_SCORE_DEATHS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getNumberOfPlayersOnTeam";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";
   $ScoreBoard::TeamColumnFunction4 = "getTeamDeaths";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}

//Series Restrictions
//----------------------------------------------------------------------
function setDefaultMissionItems()
{  
   //Winston Cup Series Restrictions
   if($Series=="Winston Cup")
   {
      allowVehicle(  all, FALSE  );
      allowVehicle(  13, TRUE  );
      allowVehicle(  20, TRUE  );
      allowVehicle(  21, TRUE  );
      allowVehicle(  30, TRUE  );   
   
      allowWeapon(  all, TRUE  );
      allowWeapon(  106, FALSE  );
      allowWeapon(  107, FALSE  );
      allowWeapon(  109, FALSE  );
      allowWeapon(  110, FALSE  );
      allowWeapon(  112, FALSE  );
      allowWeapon(  113, FALSE  );
      allowWeapon(  115, FALSE  );
      allowWeapon(  120, FALSE  );
      allowWeapon(  121, FALSE  );
      allowWeapon(  124, FALSE  );
      allowWeapon(  125, FALSE  );
      allowWeapon(  126, FALSE  );
      allowWeapon(  127, FALSE  );
      allowWeapon(  128, FALSE  );
      allowWeapon(  129, FALSE  );
      allowWeapon(  130, FALSE  );
      allowWeapon(  131, FALSE  );
      allowWeapon(  132, FALSE  );
      allowWeapon(  133, FALSE  );
      allowWeapon(  134, FALSE  );
      allowWeapon(  135, FALSE  );
      allowWeapon(  136, FALSE  );
      allowWeapon(  142, FALSE  );
      allowWeapon(  147, FALSE  );
      allowWeapon(  150, FALSE  );

      allowComponent(  all, TRUE  );
      allowComponent(  102, FALSE  );
      allowComponent(  106, FALSE  );
      allowComponent(  107, FALSE  );
      allowComponent(  108, FALSE  );
      allowComponent(  109, FALSE  );
      allowComponent(  110, FALSE  );
      allowComponent(  111, FALSE  );
      allowComponent(  112, FALSE  );
      allowComponent(  113, FALSE  );
      allowComponent(  114, FALSE  );
      allowComponent(  115, FALSE  );
      allowComponent(  129, FALSE  );
      allowComponent(  130, FALSE  );
      allowComponent(  131, FALSE  );
      allowComponent(  133, FALSE  );
      allowComponent(  134, FALSE  );
      allowComponent(  135, FALSE  );
      allowComponent(  136, FALSE  );
      allowComponent(  137, FALSE  );
      allowComponent(  138, FALSE  );
      allowComponent(  139, FALSE  );
      allowComponent(  140, FALSE  );
      allowComponent(  141, FALSE  );
      allowComponent(  142, FALSE  );
      allowComponent(  143, FALSE  );
      allowComponent(  225, FALSE  );
      allowComponent(  227, FALSE  );
      allowComponent(  228, FALSE  );
      allowComponent(  230, FALSE  );
      allowComponent(  305, FALSE  );
      allowComponent(  307, FALSE  );
      allowComponent(  329, FALSE  );
      allowComponent(  330, FALSE  );
      allowComponent(  331, FALSE  );
      allowComponent(  332, FALSE  );
      allowComponent(  333, FALSE  );
      allowComponent(  426, FALSE  );
      allowComponent(  427, FALSE  );
      allowComponent(  428, FALSE  );
      allowComponent(  429, FALSE  );
      allowComponent(  430, FALSE  );
      allowComponent(  431, FALSE  );
      allowComponent(  433, FALSE  );
      allowComponent(  434, FALSE  );
      allowComponent(  809, FALSE  );
      allowComponent(  810, FALSE  );
      allowComponent(  811, FALSE  );
      allowComponent(  812, FALSE  );
      allowComponent(  813, FALSE  );
      allowComponent(  830, FALSE  );
      allowComponent(  860, FALSE  );
      allowComponent(  875, FALSE  );
      allowComponent(  880, FALSE  );
      allowComponent(  885, FALSE  );
      allowComponent(  900, FALSE  );
      allowComponent(  910, FALSE  );
      allowComponent(  912, FALSE  );
   }
   //Busch Series Restrictions
   else if($Series=="Busch")
   {
      allowVehicle( all, FALSE );
      allowVehicle( 10, TRUE );
   
      allowWeapon( all, TRUE  );
      allowWeapon( 106, FALSE  );
      allowWeapon( 107, FALSE  );
      allowWeapon( 108, FALSE  );
      allowWeapon( 109, FALSE  );
      allowWeapon( 110, FALSE  );
      allowWeapon( 112, FALSE  );
      allowWeapon( 113, FALSE  );
      allowWeapon( 119, FALSE  );
      allowWeapon( 120, FALSE  );
      allowWeapon( 121, FALSE  );
      allowWeapon( 124, FALSE  );
      allowWeapon( 125, FALSE  );
      allowWeapon( 126, FALSE  );
      allowWeapon( 127, FALSE  );
      allowWeapon( 128, FALSE  );
      allowWeapon( 129, FALSE  );
      allowWeapon( 130, FALSE  );
      allowWeapon( 131, FALSE  );
      allowWeapon( 132, FALSE  );
      allowWeapon( 133, FALSE  );
      allowWeapon( 134, FALSE  );
      allowWeapon( 135, FALSE  );
      allowWeapon( 136, FALSE  );
      allowWeapon( 142, FALSE  );
      allowWeapon( 147, FALSE  );
      allowWeapon( 150, FALSE  );

      allowComponent( all, TRUE  );
      allowComponent( 100, FALSE  );
      allowComponent( 101, FALSE  );
      allowComponent( 102, FALSE  );
      allowComponent( 103, FALSE  );
      allowComponent( 104, FALSE  );
      allowComponent( 105, FALSE  );
      allowComponent( 111, FALSE  );
      allowComponent( 112, FALSE  );
      allowComponent( 113, FALSE  );
      allowComponent( 114, FALSE  );
      allowComponent( 115, FALSE  );
      allowComponent( 128, FALSE  );
      allowComponent( 129, FALSE  );
      allowComponent( 130, FALSE  );
      allowComponent( 131, FALSE  );
      allowComponent( 132, FALSE  );
      allowComponent( 133, FALSE  );
      allowComponent( 134, FALSE  );
      allowComponent( 135, FALSE  );
      allowComponent( 136, FALSE  );
      allowComponent( 137, FALSE  );
      allowComponent( 138, FALSE  );
      allowComponent( 139, FALSE  );
      allowComponent( 140, FALSE  );
      allowComponent( 141, FALSE  );
      allowComponent( 142, FALSE  );
      allowComponent( 143, FALSE  );
      allowComponent( 305, FALSE  );
      allowComponent( 307, FALSE  );
      allowComponent( 331, FALSE  );
      allowComponent( 333, FALSE  );
      allowComponent( 800, FALSE  );
      allowComponent( 801, FALSE  );
      allowComponent( 802, FALSE  );
      allowComponent( 810, FALSE  );
      allowComponent( 811, FALSE  );
      allowComponent( 812, FALSE  );
      allowComponent( 813, FALSE  );
      allowComponent( 825, FALSE  );
      allowComponent( 860, FALSE  );
      allowComponent( 875, FALSE  );
      allowComponent( 880, FALSE  );
      allowComponent( 900, FALSE  );
      allowComponent( 910, FALSE  );
      allowComponent( 912, FALSE  );
   }
   //Seeker Series Restrictions
   else if($Series=="Seeker")
   {
      allowVehicle(  all, FALSE  );
      allowVehicle(  20, TRUE  );

      allowWeapon(  all, FALSE  );
      allowWeapon(  101, TRUE  );
      allowWeapon(  105, TRUE  );
      allowWeapon(  116, TRUE  );
      allowWeapon(  118, TRUE  );     
      allowWeapon(  103, TRUE  );     
      allowWeapon(  114, TRUE  );
      allowWeapon(  104, TRUE  );
      
      allowComponent(  all, FALSE  );
      allowComponent(  125, TRUE  );
      allowComponent(  226, TRUE  );
      allowComponent(  300, TRUE  );
      allowComponent(  301, TRUE  );
      allowComponent(  302, TRUE  );
      allowComponent(  303, TRUE  );   
      allowComponent(  431, TRUE  );
      allowComponent(  805, TRUE  );
      allowComponent(  806, TRUE  );
      allowComponent(  807, TRUE  );
      allowComponent(  820, TRUE  );
      allowComponent(  830, TRUE  );
      allowComponent(  840, TRUE  );
      allowComponent(  845, TRUE  );
      allowComponent(  850, TRUE  );
      allowComponent(  865, TRUE  );
      allowComponent(  870, TRUE  );
      allowComponent(  880, TRUE  );
      allowComponent(  885, TRUE  );
      allowComponent(  890, TRUE  );
      allowComponent(  914, TRUE  );
      allowComponent(  225, TRUE  );
      allowComponent(  200, TRUE  );
      allowComponent(  201, TRUE  );
      allowComponent(  202, TRUE  );
      allowComponent(  203, TRUE  );
      allowComponent(  204, TRUE  );
      allowComponent(  205, TRUE  );
      allowComponent(  226, TRUE  );
      allowComponent(  227, TRUE  );
      allowComponent(  228, TRUE  );
      allowComponent(  229, TRUE  );
      allowComponent(  230, TRUE  );
      allowComponent(  400, TRUE  );
      allowComponent(  401, TRUE  );
      allowComponent(  408, TRUE  );
      allowComponent(  409, TRUE  );
      allowComponent(  410, TRUE  );
      allowComponent(  411, TRUE  );
      allowComponent(  412, TRUE  );
      allowComponent(  413, TRUE  );
      allowComponent(  414, TRUE  );
      allowComponent(  426, TRUE  );
      allowComponent(  427, TRUE  );
      allowComponent(  428, TRUE  );
      allowComponent(  429, TRUE  );
      allowComponent(  430, TRUE  );
      allowComponent(  432, TRUE  );
      allowComponent(  433, TRUE  );
      allowComponent(  434, TRUE  );
      allowComponent(  128, TRUE  );
      allowComponent(  129, TRUE  );
      allowComponent(  926, TRUE  );
      allowComponent(  927, TRUE  );
      allowComponent(  928, TRUE  );
      allowComponent(  929, TRUE  );
      allowComponent(  930, TRUE  );
   }
   //Craftsman Tank Series Restrictions
   else if($Series=="Craftsman Tank")
   {
      allowVehicle(  all, FALSE  );
      allowVehicle(  17, TRUE  );
      allowVehicle(  25, TRUE  );
      allowVehicle(  41, TRUE  );
      
      allowWeapon(  all, FALSE  );
      allowWeapon(  3, FALSE  );
      allowWeapon(  101, TRUE  );
      allowWeapon(  102, TRUE  );
      allowWeapon(  103, TRUE  );
      allowWeapon(  104, TRUE  );
      allowWeapon(  105, TRUE  );
      allowWeapon(  111, TRUE  );
      allowWeapon(  114, TRUE  );
      allowWeapon(  115, TRUE  );
      allowWeapon(  116, TRUE  );
      allowWeapon(  117, TRUE  );
      allowWeapon(  118, TRUE  );
      allowWeapon(  121, TRUE  );
      allowWeapon(  111, TRUE  );
            
      allowComponent(  all, TRUE  );
      allowComponent(  809, FALSE );
      allowComponent(  810, FALSE );
      allowComponent(  811, FALSE );
      allowComponent(  812, FALSE );
      allowComponent(  813, FALSE );
      allowComponent(  820, FALSE );
      allowComponent(  840, FALSE );
      allowComponent(  845, FALSE );
      allowComponent(  850, FALSE );
      allowComponent(  860, FALSE );
      allowComponent(  875, FALSE );
      allowComponent(  880, FALSE );
      allowComponent(  900, FALSE );
      allowComponent(  910, FALSE );
   }
   //Goad/Talon Series Restrictions
   else if($Series=="Goad/Talon")
   {
      allowVehicle( all, FALSE  );
      allowVehicle( 13, TRUE  );
      allowVehicle( 21, TRUE  );
     
      allowWeapon( all, TRUE  );
      allowWeapon( 106, FALSE  );
      allowWeapon( 107, FALSE  );
      allowWeapon( 108, FALSE  );
      allowWeapon( 109, FALSE  );
      allowWeapon( 110, FALSE  );
      allowWeapon( 112, FALSE  );
      allowWeapon( 113, FALSE  );
      allowWeapon( 115, FALSE  );
      allowWeapon( 119, FALSE  );
      allowWeapon( 120, FALSE  );
      allowWeapon( 121, FALSE  );
      allowWeapon( 124, FALSE  );
      allowWeapon( 125, FALSE  );
      allowWeapon( 126, FALSE  );
      allowWeapon( 127, FALSE  );
      allowWeapon( 128, FALSE  );
      allowWeapon( 129, FALSE  );
      allowWeapon( 130, FALSE  );
      allowWeapon( 131, FALSE  );
      allowWeapon( 132, FALSE  );
      allowWeapon( 133, FALSE  );
      allowWeapon( 134, FALSE  );
      allowWeapon( 135, FALSE  );
      allowWeapon( 136, FALSE  );
      allowWeapon( 142, FALSE  );
      allowWeapon( 147, FALSE  );
      allowWeapon( 150, FALSE  );
   
      allowComponent( all, TRUE  );
      allowComponent( 102, FALSE  );
      allowComponent( 103, FALSE  );
      allowComponent( 104, FALSE  );
      allowComponent( 105, FALSE  );
      allowComponent( 106, FALSE  );
      allowComponent( 107, FALSE  );
      allowComponent( 108, FALSE  );
      allowComponent( 109, FALSE  );
      allowComponent( 110, FALSE  );
      allowComponent( 111, FALSE  );
      allowComponent( 112, FALSE  );
      allowComponent( 113, FALSE  );
      allowComponent( 114, FALSE  );
      allowComponent( 115, FALSE  );
      allowComponent( 128, FALSE  );
      allowComponent( 129, FALSE  );
      allowComponent( 130, FALSE  );
      allowComponent( 131, FALSE  );
      allowComponent( 133, FALSE  );
      allowComponent( 134, FALSE  );
      allowComponent( 135, FALSE  );
      allowComponent( 136, FALSE  );
      allowComponent( 137, FALSE  );
      allowComponent( 138, FALSE  );
      allowComponent( 139, FALSE  );
      allowComponent( 140, FALSE  );
      allowComponent( 141, FALSE  );
      allowComponent( 142, FALSE  );
      allowComponent( 143, FALSE  );
      allowComponent( 225, FALSE  );
      allowComponent( 227, FALSE  );
      allowComponent( 228, FALSE  );
      allowComponent( 230, FALSE  );
      allowComponent( 305, FALSE  );
      allowComponent( 307, FALSE  );
      allowComponent( 329, FALSE  );
      allowComponent( 330, FALSE  );
      allowComponent( 331, FALSE  );
      allowComponent( 332, FALSE  );
      allowComponent( 333, FALSE  );
      allowComponent( 426, FALSE  );
      allowComponent( 427, FALSE  );
      allowComponent( 428, FALSE  );
      allowComponent( 429, FALSE  );
      allowComponent( 430, FALSE  );
      allowComponent( 431, FALSE  );
      allowComponent( 433, FALSE  );
      allowComponent( 434, FALSE  );
      allowComponent( 809, FALSE  );
      allowComponent( 810, FALSE  );
      allowComponent( 811, FALSE  );
      allowComponent( 812, FALSE  );
      allowComponent( 813, FALSE  );
      allowComponent( 831, FALSE  );
      allowComponent( 860, FALSE  );
      allowComponent( 875, FALSE  );
      allowComponent( 880, FALSE  );
      allowComponent( 885, FALSE  );
      allowComponent( 900, FALSE  );
      allowComponent( 910, FALSE  );
      allowComponent( 912, FALSE  );
   }
   //Custom Series Restrictions
   //Unrestricted except for unfair weapons
   //Ready to edit
   else
   {
      allowVehicle( all, TRUE );
      
      allowWeapon( all, TRUE );
      allowWeapon( 3, FALSE );    //Disrupter Weapon  
      allowWeapon( 110, FALSE );  //Plasma Cannon    
      allowWeapon( 124, FALSE );  //Missiles
      allowWeapon( 125, FALSE );
      allowWeapon( 126, FALSE );
      allowWeapon( 127, FALSE );
      allowWeapon( 128, FALSE );

      allowWeapon( 129, FALSE );
      allowWeapon( 130, FALSE );
      allowWeapon( 131, FALSE );  //Arachnitrons
      allowWeapon( 132, FALSE );
      allowWeapon( 133, FALSE );
      allowWeapon( 134, FALSE );  //Proximity Mines
      allowWeapon( 135, FALSE );
      allowWeapon( 136, FALSE );
      allowWeapon( 142, FALSE );  //Radiation Gun
      allowWeapon( 147, FALSE );  //More Missiles
      allowWeapon( 150, FALSE );  //Smart Gun
      
      allowComponent( all, TRUE );
   }
}


