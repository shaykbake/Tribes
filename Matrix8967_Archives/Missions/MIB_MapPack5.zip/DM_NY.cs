$carpet = "MissionGroup/carpet";
$yRod1 = "MissionGroup/yrod1";
$yRod2 = "MissionGroup/yrod2";
$shoot = false;
$truck1     =   "MissionGroup/vehicles/drone/truck1";
$truck2     =   "MissionGroup/vehicles/drone/truck2";
$truck3     =   "MissionGroup/vehicles/drone/truck3";
$truck6     =   "MissionGroup/vehicles/drone/truck6";
// FILENAME:	DM_NY.cs
//
// AUTHORS:  	Gen. Deathrow
//------------------------------------------------------------------------------

$missionName = "DM_New_York_City.";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionLoad()
{
   cdAudioCycle(Gnash, Cloudburst, Cyberntx); 
    temperateSounds();
    stormSounds();
}


function onMissionStart()
{
   initPatrols();
     defineRoutes();
    temperateSounds();
//    stormSounds();
//    cdAudioCycle(Gnash, Cloudburst, Cyberntx);
}


function defineRoutes()
{
    $Route1    =   "MissionGroup/route";
    $Route2     =   "MissionGroup/route";
    $Route3     =   "MissionGroup/route";
}


function initPatrols()
{
    order( $truck1,guard, $Route1 );
    order( $truck2, guard, $Route2 );
    order( $truck3, guard, $Route3 );
    order( $truck6, guard, $Route2 );
}


function player::onAdd(%this)
{
   %player.name = getName(%player);
  %player.location = 0; 

 %player.IP = getConnection(%player);
  %player.name = getName(%player);
  %nowDate = getDate();
  %nowTime = getTime();
  %timeEnd = getCurrentTime();
  %timeIn = timeDifference( %timeEnd, %player.startTime);
  %outputString =  %nowDate @ ", " @ %nowTime @ " -- " @ %player.name @ " entered the game and his IP is" @ %player.IP @ "--";

  fileWrite("multiplayer\\serverlog.txt", append, %outputString);
  say(%this, 0, "Welcome to DeathMatch in New York City! You can download this & other missions made by Gen. Deathrow [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}




function yRod1::structure::OnAttacked(%target, %attacker)
{
	if($shoot == false){
 	%player = playerManager::vehicleIdToPlayerNum(%attacker);
  $veh = %attacker;
  if(getDistance(%attacker, $carpet) < 35) moveThingZPlus(%rider);
  else say(%player, 0, "Please stand between the two monuments before shooting them");
}
}



function player::OnRemove(%player)
{
  %player.name = getName(%player);

  %player.IP = getConnection(%player);
  %player.name = getName(%player);
  %nowDate = getDate();
  %nowTime = getTime();
  %timeEnd = getCurrentTime();
  %timeIn = timeDifference( %timeEnd, %player.startTime);
  %outputString =  %nowDate @ ", " @ %nowTime @ " -- " @ %player.name @ " left the game and his IP is" @ %player.IP @ "--";

  fileWrite("multiplayer\\serverlog.txt", append, %outputString);
}

function yRod2::structure::OnAttacked(%target, %attacker)
{
  if($shoot == false){
  %player = playerManager::vehicleIdToPlayerNum(%attacker);
  $veh = %attacker;
   %posA = getPosition($carpet, z) - 1;
  if(%posA < $carpetHeight) return;
  if(getDistance(%attacker, $carpet) < 35) moveThingZMinus(%rider);
  else say(%player, 0, "Please stand between the two monuments before shooting them");
}
}

//function loophole()
//{
//schedule("moveThingZMinus(%rider);",0.5);
//schedule("loophole2();",120);
//}

//loophole2()
//{
//schedule("moveThingZMinus(%rider);",0.5);
//schedule("loophole();",120);
//}


function moveThingZPlus()
{
   
  if(%newZ > 166)
  {
  return;
  }  

  %posX = getPosition($carpet, x);
  %posY = getPosition($carpet, y);
  %posZ = getPosition($carpet, z);

  %pos1X = getPosition($yRod1, x);
  %pos1Y = getPosition($yRod1, y);
  %pos1Z = getPosition($yRod1, z);

  %pos2X = getPosition($yRod2, x);
  %pos2Y = getPosition($yRod2, y);
  %pos2Z = getPosition($yRod2, z);

  %pos3X = getPosition($veh, x);
  %pos3Y = getPosition($veh, y);
  %pos3Z = getPosition($veh, z);

  %newZ = %posZ + 3;
  %new1Z = %pos1Z + 3;
  %new2Z = %pos2Z + 3;
  %new3Z = %pos3Z + 4;

  setPosition($carpet, %posX, %posY, %newZ);
  setPosition($yRod1, %pos1X, %pos1Y, %new1Z);
  setPosition($yRod2, %pos2X, %pos2Y, %new2Z);
  setPosition($veh, %pos3X, %pos3Y, %new3Z);


  if(%newZ == 166)
  {
  return;
  }  
   if(%newZ >166)
  {
  return;
  }

schedule("moveThingZPlus(%rider);",0.5);
}

function moveThingZMinus(%rider)
{

  

  %posX = getPosition($carpet, x);
  %posY = getPosition($carpet, y);
  %posZ = getPosition($carpet, z);

  %pos1X = getPosition($yRod1, x);
  %pos1Y = getPosition($yRod1, y);
  %pos1Z = getPosition($yRod1, z);

  %pos2X = getPosition($yRod2, x);
  %pos2Y = getPosition($yRod2, y);
  %pos2Z = getPosition($yRod2, z);

  %pos3X = getPosition($veh, x);
  %pos3Y = getPosition($veh, y);
  %pos3Z = getPosition($veh, z);

  %newZ = %posZ - 3;
  %new1Z = %pos1Z - 3;
  %new2Z = %pos1Z - 3;
  %new3Z = %pos1Z - 1;

  setPosition($carpet, %posX, %posY, %newZ);
  setPosition($yRod1, %pos1X, %pos1Y, %new1Z);
  setPosition($yRod2, %pos2X, %pos2Y, %new2Z);
  setPosition($veh, %pos3X, %pos3Y, %new3Z);
   
  if(%newZ == $carpetHeight)
  {
  return;
  }
  if(%newZ < $carpetHeight)
  {
  return;
  } 
  
schedule("moveThingZMinus(%rider);",0.5);
}

function onMissionStart()
{
  $carpetHeight = getPosition($carpet, z);
  $yRod1Height = getPosition($yRod1, z);
  $yRod2Height = getPosition($yRod2, z);

//  schedule("dropCarpet();", 60);
}

function dropCarpet()
{
  %posX = getPosition($carpet, x);
  %posY = getPosition($carpet, y);
  %posZ = getPosition($carpet, z);

  %pos1X = getPosition($yRod1, x);
  %pos1Y = getPosition($yRod1, y);
  %pos1Z = getPosition($yRod1, z);

  %pos2X = getPosition($yRod2, x);
  %pos2Y = getPosition($yRod2, y);
  %pos2Z = getPosition($yRod2, z);

  setPosition($carpet, %posX, %posY, $carpetHeight);
  setPosition($yRod1, %pos1X, %pos1Y, $yRod1Height);
  setPosition($yRod2, %pos2X, %pos2Y, $yRod2Height);

  say("everybody", 0, "Dropping the Elevator back down!");

//  schedule("dropCarpet();", 30);
}



//function player::OnAdd(%player)
//{
//  %player.name = getName(%player);
//  %player.location = 0;
//}


//function player::OnRemove(%player)
//{
//  %player.name = getName(%player);
//}
