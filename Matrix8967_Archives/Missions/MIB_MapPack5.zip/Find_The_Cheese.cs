// FILENAME:	Find_The_Cheese.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Find The Cheese!";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

$killPoints = 3;
$deathPoints = 2;
$cheesePoints = 10;    //Number of points scored per cheese found
$cheeseFound = false;
$firstHide = true;
$lastNum = 0;
$totalCheese = 0;

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   temperateSounds();
   $cheese = getObjectId("Missiongroup\\cheese");
   $cheeseTrigger = getObjectId("Missiongroup\\cheeseTrigger");
   $cheeseFlag = getObjectId("Missiongroup\\cheeseFlag");
   $door1 = getObjectId("Missiongroup\\door1");
   $door2 = getObjectId("Missiongroup\\door2");
   $door3 = getObjectId("Missiongroup\\door3");
   $door4 = getObjectId("Missiongroup\\door4");
   $door5 = getObjectId("Missiongroup\\door5");
   $door6 = getObjectId("Missiongroup\\door6");
   $door7 = getObjectId("Missiongroup\\door7");
   $door8 = getObjectId("Missiongroup\\door8");
   $door9 = getObjectId("Missiongroup\\door9");
   $door10 = getObjectId("Missiongroup\\door10");
   $hide1 = getObjectId("Missiongroup\\hide\\hide1");
   $hide2 = getObjectId("Missiongroup\\hide\\hide2");
   $hide3 = getObjectId("Missiongroup\\hide\\hide3");
   $hide4 = getObjectId("Missiongroup\\hide\\hide4");
   $hide5 = getObjectId("Missiongroup\\hide\\hide5");
   $hide6 = getObjectId("Missiongroup\\hide\\hide6");
   $hide7 = getObjectId("Missiongroup\\hide\\hide7");
   $hide8 = getObjectId("Missiongroup\\hide\\hide8");
   $hide9 = getObjectId("Missiongroup\\hide\\hide9");
   $hide10 = getObjectId("Missiongroup\\hide\\hide10");
   $hide11 = getObjectId("Missiongroup\\hide\\hide11");
   $hide12 = getObjectId("Missiongroup\\hide\\hide12");
   $hide13 = getObjectId("Missiongroup\\hide\\hide13");
   $hide14 = getObjectId("Missiongroup\\hide\\hide14");
   $hide15 = getObjectId("Missiongroup\\hide\\hide15");
   $hide16 = getObjectId("Missiongroup\\hide\\hide16");
   $hide17 = getObjectId("Missiongroup\\hide\\hide17");
   $hide18 = getObjectId("Missiongroup\\hide\\hide18");
   $hide19 = getObjectId("Missiongroup\\hide\\hide19");
   $hide20 = getObjectId("Missiongroup\\hide\\hide20");
   $hide21 = getObjectId("Missiongroup\\hide\\hide21");
   $hide22 = getObjectId("Missiongroup\\hide\\hide22");
   $hide23 = getObjectId("Missiongroup\\hide\\hide23");
   $hide24 = getObjectId("Missiongroup\\hide\\hide24");
   $hide25 = getObjectId("Missiongroup\\hide\\hide25");
   changeMaze();
   schedule("hideCheese();", 3);
}

function onMissionLoad()
{
   cdAudioCycle("Watching", "Cyberntx", "Terror", "Purge");
   setGameInfo("<F2>GAME TYPE:<F0>  Find The Cheese!\n\n<F2>MISSION:<F0>  Find_The_Cheese\n\nWelcome to Find The Cheese! Players are placed inside a giant ever-changing maze. The cheese is hidden somewhere in the maze and you must try to find it before other players do. Every time the cheese is found, the maze changes and the cheese is re-hidden somewhere else in the maze. Players get " @ $cheesePoints @ " points for every piece of cheese they find.\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download Find_The_Cheese & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);      
      %player.cheesePoints = 0;      
      %player.cheeseFound = 0;
   }
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Find The Cheese! The cheese is hidden somewhere in the maze and you must try to find it before other players do. Every time the cheese is found, the maze changes and the cheese is re-hidden somewhere else. Players get " @ $cheesePoints @ " points for each piece of cheese they find. You can download Find_The_Cheese & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.cheesePoints = 0;
   %player.cheeseFound = 0;
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   setVehicleRadarVisible(%vehicleId, false);
   if(%player != 0)
   {
      say(%player, %player, "<F5>Try to find the cheese!");
   }
}

function cheeseTrigger::trigger::onEnter(%trigger, %vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if($cheeseFound == false)
   {
      $cheeseFound = true;
      $totalCheese++;
      %x = getPosition($cheese, x);
      %y = getPosition($cheese, y);
      %z = getTerrainHeight(%x, %y);
      setPosition($cheeseFlag, %x, %y, %z);
      say("Everybody", 3, "<F5>" @ getName(%player) @ " has found the cheese!");
      %player.cheesePoints = %player.cheesePoints + $cheesePoints;
      %player.cheeseFound = %player.cheeseFound + 1;      
      changeMaze();
      schedule("hideCheese();", 3);
   }
}

function changeMaze()
{
   %num1 = randomInt(0, 1);
   %num2 = randomInt(0, 1);
   %num3 = randomInt(0, 1);
   %num4 = randomInt(0, 1);
   if((%num1 == 0)&&(%num2 == 0)&&(%num3 == 0)&&(%num4 == 0))
   {
      while((%num1 == 0)&&(%num2 == 0)&&(%num3 == 0)&&(%num4 == 0))
      {
         %num1 = randomInt(0, 1);
         %num2 = randomInt(0, 1);
         %num3 = randomInt(0, 1);
         %num4 = randomInt(0, 1);
      }
   }
   %num5 = randomInt(0, 1);
   %num6 = randomInt(0, 1);
   %num7 = randomInt(0, 1);
   %num8 = randomInt(0, 1);
   %num9 = randomInt(0, 1);
   %num10 = randomInt(0, 1);
   %i = 1;
   while(%i <= 10)
   {      
      if(%num[%i] == 0)
      {
         %state[%i] = false;
      }
      else if(%num[%i] == 1)
      {
         %state[%i] = true;
      }
      %i++;
   }
   playAnimSequence($door1, 0, %state1);
   playAnimSequence($door2, 0, %state2);
   playAnimSequence($door3, 0, %state3);
   playAnimSequence($door4, 0, %state4);
   playAnimSequence($door5, 0, %state5);
   playAnimSequence($door6, 0, %state6);
   playAnimSequence($door7, 0, %state7);
   playAnimSequence($door8, 0, %state8);
   playAnimSequence($door9, 0, %state9);
   playAnimSequence($door10, 0, %state10);
   echo("Changing Maze: " @ %num1 @ " " @ %num2 @ " " @ %num3 @ " " @ %num4 @ " " @ %num5 @ " " @ %num6 @ " " @ %num7 @ " " @ %num8 @ " " @ %num9 @ " " @ %num10);
}

function hideCheese()
{
   %num = randomHide(1, 25);
   echo("Hiding Cheese: " @ %num);
   setPosition($cheeseFlag, 10000, 10000, -1000);
   %x = getPosition($hide[%num], x);
   %y = getPosition($hide[%num], y);
   %z = getTerrainHeight(%x, %y);
   setPosition($cheese, %x, %y, %z);   
   setPosition($cheeseTrigger, %x, %y, %z);
   if($firstHide == true)
   {
      $firstHide = false;      
   }
   else if($firstHide == false)
   {
      say("Everybody", 3, "<F5>The cheese has been hidden! Try to find the cheese!");
   }
   $cheeseFound = false;
}

function randomHide(%low, %high)
{
   %num = randomInt(%low, %high);
   if(%num == $lastNum)
   {
      while(%num == $lastNum)
      {
         %num = randomInt(%low, %high);
      }
   }
   $lastNum = %num;
   return %num;
}
           
function getPlayerScore(%player)
{
   return(((getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints)) + %player.cheesePoints);
}

function getCheeseFound(%player)
{
   return(%player.cheeseFound);
}

function getTotalCheeseFound(%player)
{
   return($totalCheese);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_TEAM;
	   $ScoreBoard::PlayerColumnHeader2 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_SCORE;
	   $ScoreBoard::PlayerColumnHeader4 = "Cheese Found";
	   $ScoreBoard::PlayerColumnHeader5 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader6 = *IDMULT_SCORE_DEATHS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getTeam";
	   $ScoreBoard::PlayerColumnFunction2 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction3 = "getPlayerScore";
	   $ScoreBoard::PlayerColumnFunction4 = "getCheeseFound";
	   $ScoreBoard::PlayerColumnFunction5 = "getKills";
	   $ScoreBoard::PlayerColumnFunction6 = "getDeaths";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = *IDMULT_SCORE_SCORE;
	   $ScoreBoard::PlayerColumnHeader3 = "Cheese Found";
	   $ScoreBoard::PlayerColumnHeader4 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader5 = *IDMULT_SCORE_DEATHS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerScore";
	   $ScoreBoard::PlayerColumnFunction3 = "getCheeseFound";
	   $ScoreBoard::PlayerColumnFunction4 = "getKills";
	   $ScoreBoard::PlayerColumnFunction5 = "getDeaths";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = *IDMULT_SCORE_PLAYERS;
   $ScoreBoard::TeamColumnHeader3 = "Total Cheese Found";
   $ScoreBoard::TeamColumnHeader4 = *IDMULT_SCORE_KILLS;
   $ScoreBoard::TeamColumnHeader5 = *IDMULT_SCORE_DEATHS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getNumberOfPlayersOnTeam";
   $ScoreBoard::TeamColumnFunction3 = "getTotalCheeseFound";
   $ScoreBoard::TeamColumnFunction4 = "getTeamKills";
   $ScoreBoard::TeamColumnFunction5 = "getTeamDeaths";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}

