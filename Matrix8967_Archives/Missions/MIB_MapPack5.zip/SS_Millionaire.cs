// FILENAME:	SS_Millionaire.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Starsiege: Who Wants To Be A Millionaire?";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::TimeLimit = 0;
}

function onMissionStart()
{
   desertSounds();
   $gamestart = false;
   $hotseat = "Nobody";
   $hotseatname = "Nobody";
   $gameover = false;
   $countdown = false;
   $double = false;
   $lifeline1 = false;
   $lifeline2 = false;
   $lifeline3 = false;
   $lifelinelock = false;
   $askingAudience = false;
   $cloning = false;
   $doingFifty = false;
   $walkaway = false;
   $pad = true;
   $quietRegis = false;
   $seeker100destroyed = false;
   $goad200destroyed = false;
   $eman300destroyed = false;
   $mino500destroyed = false;
   $goad1000destroyed = false;
   $goad10002destroyed = false;
   $eman2000destroyed = false;
   $eman20002destroyed = false;
   $shep4000destroyed = false;
   $basilisk8000destroyed = false;
   $gorgon16000destroyed = false;
   $judge32000destroyed = false;
   $olympian64000destroyed = false;
   $apoc125000destroyed = false;
   $exec250000destroyed = false;
   $exec500000destroyed = false;
   $exec5000002destroyed = false;
   $promieMilliondestroyed = false;
   $execguarddestroyed = false;
   $txt1 = "\"Walk Away\"";
   $txt2 = "\"Fastest Shooter\"";
   $txt3 = "\"Who Wants To Be A Millionaire?\"";
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Starsiege: Who Wants To Be A Millionaire! Check the game info tab for the rules. You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.winnings = 0;
   %player.money = 0;
   %player.lifelines = 0;
   %player.askaudience = "N/A";
   %player.clonefriend = "N/A";
   %player.fiftyfifty = "N/A";
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(getTeam(%vehicleId)==*IDSTR_TEAM_BLUE)
   {
      setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      redrop(%vehicleId);
   }
   else if(getTeam(%vehicleId)==*IDSTR_TEAM_RED)
   {
      setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      redrop(%vehicleId);
   }
   else if(getTeam(%vehicleId)==*IDSTR_TEAM_PURPLE)
   {
      setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      redrop(%vehicleId);
   }
   if($gamestart==false)
   {
      if($countdown==false)
      {
         $countdown = true;
         say("Everybody", 1, "REGIS: Regis Philbin here, from MIB's \"Who Wants To Be A Millionaire?\". The game will begin in one minute in order to allow other contestants to join the game.");
         $countdownStartTime = getCurrentTime();
         setHUDTimerAll(%time, %increment, %string, %channel);
         schedule("fastestShooter();",60);
      }
      else if($countdown==true)
      {
         $timeLeft = 60 - (getCurrentTime() -  $countdownStartTime);
         setHudTimer($timeLeft, -1, "Game begins in:", 1, %vehicleId);
      }
   }
   else if(($gamestart==true)&&(%vehicleId!=$hotseat))
   {
      messagebox(%vehicleId, "If you would like to watch the game in progress, press ctrl + v, then cycle through the cameras by pressing the \"Home\" key until you're watching the player in the hotseat.");
   }
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Starsiege: Who Wants To Be A Millionaire?\n\n<F2>MISSION:<F0>  SS_Millionaire\n\n<F2>RULES:<F0>\n\nThe rules of the game are simple. At the beginning of the game, players compete in a \"Fastest Shooter\" round in which 1 goad is spawned in an arena. The contestant who destroys it goes to the hotseat. Once in the hotseat, you will be faced with increasingly harder waves of AI units. For each round you survive, you double your money. You begin at $100 and work your way up to a million. You can walk away with your money at any time by shutting down on the \"Walk Away\" pad. If you make it to the $1,000 or $32,000 level, you are guaranteed to walk away with no less than that amount. You will also be healed and reloaded when you reach those levels. If you die, you will be reduced back down to $0 or the last safe level you've reached. You get 3 lifelines: Ask the audience, clone a friend, & 50/50. You can use them at any time during the game by scanning the corresponding drone balls."); 
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.money = %player.record;
      %player.winnings = 0;
      %player.lifelines = 0;
      %player.askaudience = "N/A";
      %player.clonefriend = "N/A";
      %player.fiftyfifty = "N/A";
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   if($gameover==false)
   {  
      if(($askingAudience==false)&&($cloning==false))
      {
         DestroyedNormal(%destroyed, %destroyer);
      }
      else if(($askingAudience==true)&&($cloning==false))
      {   
         DestroyedAud(%destroyed, %destroyer);
      }
      else if(($askingAudience==false)&&($cloning==true))
      {
         DestroyedClone(%destroyed, %destroyer);
      }
   }
}

function DestroyedNormal(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   if(%destroyed==$fastGoad)
   {
      if(%destroyer!=$fastGoad)
      {
         hotseat(%destroyer);
      }
      else if(%destroyer==$fastGoad)
      {
         say("Everybody", 1, "REGIS: Well it looks like our goad has destroyed itself. That's odd.");
         schedule("say(\"Everybody\", 1, \"Let's try this again, shall we?\");", 2);
         schedule("dropGoad();",5);
      }
   }
   else if(%destroyed==$hotseat)
   {
      if(%destroyer!=$hotseat)
      {
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " is history!");
         schedule("GameOver();",3);
      }
      else if(%destroyer==$hotseat)
      {
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " has forfieted the game!");
         schedule("forfiet();",3);
      }
   }
   else if(%destroyed==$seeker100)
   {  
      %player.winnings = 1;
      $lifelinelock = true;
      $seeker100destroyed = true;
      say("Everybody", 1, "REGIS: And he's got it!");
      reloadObject($hotseat, 10000);
      schedule("Goad200();", 3);
   } 
   else if(%destroyed==$goad200)
   {  
      %player.winnings = 2;
      $lifelinelock = true;
      $goad200destroyed = true;
      say("Everybody", 1, "REGIS: Nice one, " @ $hotseatname @ "!");
      reloadObject($hotseat, 10000);
      schedule("Eman300();", 3);
   } 
   else if(%destroyed==$eman300)
   {  
      %player.winnings = 3;
      $lifelinelock = true;
      $eman300destroyed = true;
      say("Everybody", 1, "REGIS: It's a good one!!");
      reloadObject($hotseat, 10000);
      schedule("Mino500();", 3);
   } 
   else if(%destroyed==$mino500)
   {  
      %player.winnings = 5;
      $lifelinelock = true;
      $mino500destroyed = true;
      say("Everybody", 1, "REGIS: And he got it for $500!");
      reloadObject($hotseat, 10000);
      schedule("TwoGoads1000();", 3);
   } 
   else if(%destroyed==$goad1000)
   {  
      $goad1000destroyed = true;
      if($goad10002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10;
         say("Everybody", 1, "<F3>" @ $hotseatname @ ": Yes Regis, that's my final answer...");
         schedule("say(\"Everybody\", 1, \"REGIS: Well, it's a good one!!\");",2);
         reloadObject($hotseat, 10000);
         schedule("Intermission1000();",5);
      }
      else if($goad10002destroyed==false)
      {
         say("Everybody", 1, "REGIS: You've almost got it...");
         schedule("say(\"Everybody\", 1, \"REGIS: Is that your final answer?\");",5);
         schedule("RegisComment2();", 30);
      }
   } 
   else if(%destroyed==$goad10002)
   {  
      $goad10002destroyed = true;
      if($goad1000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10;
         say("Everybody", 1, "<F3>" @ $hotseatname @ ": Yes Regis, that's my final answer...");
         schedule("say(\"Everybody\", 1, \"REGIS: Well, it's a good one!!\");",2);
         reloadObject($hotseat, 10000);
         schedule("Intermission1000();",5);
      }
      else if($goad1000destroyed==false)
      {
         say("Everybody", 1, "REGIS: You've almost got it...");
         schedule("say(\"Everybody\", 1, \"REGIS: Is that your final answer?\");",5);
         schedule("RegisComment2();", 30);
      }
   } 
   else if(%destroyed==$eman2000)
   {  
      $eman2000destroyed = true;
      if($eman20002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 20;
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: Okay then, are you ready for the next round?\");",3);
         reloadObject($hotseat, 10000);
         schedule("Shep4000();",6);
      }
      else if($eman20002destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
         schedule("RegisComment3();", 30);
      }
   } 
   else if(%destroyed==$eman20002)
   {  
      $eman20002destroyed = true;
      if($eman2000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 20;
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: Okay then, are you ready for the next round?\");",3);
         reloadObject($hotseat, 10000);
         schedule("Shep4000();",6);
      }
      else if($eman2000destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
         schedule("RegisComment3();", 30);
      }
   } 
   else if(%destroyed==$shep4000)
   {  
      %player.winnings = 40;
      $lifelinelock = true;
      $shep4000destroyed = true;
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " is on fire!!");
      reloadObject($hotseat, 10000);
      schedule("Basilisk8000();", 3);
   } 
   else if(%destroyed==$basilisk8000)
   {  
      %player.winnings = 80;
      $lifelinelock = true;
      $basilisk8000destroyed = true;
      say("Everybody", 1, "REGIS: " @ $hotseatname @ ", you've just won yourself $8,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: Getting a little harder, isn't it?\");",5);
      schedule("say(\"Everybody\", 1, \"REGIS: Well, you're doing good...only 7 away from a million!!\");",8);
      schedule("say(\"Everybody\", 1, \"REGIS: Are you ready? Then let's play!\");",11);
      reloadObject($hotseat, 10000);
      schedule("Gorgon16000();", 14);
   } 
   else if(%destroyed==$gorgon16000)
   {  
      %player.winnings = 160;
      $lifelinelock = true;
      $gorgon16000destroyed = true;
      say("Everybody", 1, "REGIS: And he did it again, for $16,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: You realize that if you miss here, you'll be reduced back to $1,000...\");",5);
      schedule("say(\"Everybody\", 1, \"REGIS: ...but if you get this one, you'll be guaranteed to leave with at least $32,000.\");",10);
      schedule("say(\"Everybody\", 1, \"REGIS: Now remember, you can still use your lifelines at any time.\");",15);
      schedule("say(\"Everybody\", 1, \"REGIS: Ready, here we go...\");",18);
      reloadObject($hotseat, 10000);
      schedule("Judge32000();", 20);
   } 
   else if(%destroyed==$judge32000)
   {  
      %player.winnings = 320;
      $lifelinelock = true;
      $judge32000destroyed = true;
      say("Everybody", 1, "REGIS: " @ $hotseatname @", on fire!!!");
      reloadObject($hotseat, 10000);
      schedule("Intermission32000();", 5);
   } 
   else if(%destroyed==$olympian64000)
   {  
      %player.winnings = 640;
      $lifelinelock = true;
      $olympian64000destroyed = true;
      say("Everybody", 1, "REGIS: It's a good one!!!");
      schedule("say(\"Everybody\", 1, \"REGIS: Alright, you're only 4 away from a million...\");",5);
      reloadObject($hotseat, 10000);
      schedule("Apoc125000();", 8);
   } 
   else if(%destroyed==$apoc125000)
   {  
      %player.winnings = 1250;
      $lifelinelock = true;
      $apoc125000destroyed = true;
      say("Everybody", 1, "REGIS: " @ $hotseatname @ ", you've just won $125,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: You seem a little nervous....\");",5);
      schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": No...I'm not nervous.\");",8);
      schedule("say(\"Everybody\", 1, \"REGIS: Well, you should be....I know I would...\");",11);
      schedule("say(\"Everybody\", 1, \"REGIS: Alright, you're only 3 away from a million...\");",14);
      reloadObject($hotseat, 10000);
      schedule("Exec250000();", 17);
   } 
   else if(%destroyed==$exec250000)
   {  
      %player.winnings = 2500;
      $lifelinelock = true;
      $exec250000destroyed = true;
      say("Everybody", 1, "REGIS: He's done it again, for $250,000!!");
      reloadObject($hotseat, 10000);
      schedule("TwoExecs500000();", 3);
   } 
   else if(%destroyed==$exec500000)
   {  
      $exec500000destroyed = true;
      if($exec5000002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 5000;
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you've just won half a million dollars!!!\");",3);
         schedule("say(\"Everybody\", 1, \"REGIS: Alright, we're going for the final challenge. We're going for a million!!\");",8);         
         reloadObject($hotseat, 10000);
         schedule("promieMillion();",10);
      }
      else if($exec5000002destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
      }
   } 
   else if(%destroyed==$exec5000002)
   {  
      $exec5000002destroyed = true;
      if($exec500000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 5000;
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you've just won half a million dollars!!!\");",3);
         schedule("say(\"Everybody\", 1, \"REGIS: Alright, we're going for the final challenge. We're going for a million!!\");",8);         
         reloadObject($hotseat, 10000);
         schedule("promieMillion();",10);
      }
      else if($exec500000destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
      }
   } 
   else if(%destroyed==$promieMillion)
   {
      destPromCont();
   }
   else if(%destroyed==$execguard)
   {
      destGuardCont();
   } 
}

function destPromCont()
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   $promieMilliondestroyed = true;
   if($execguarddestroyed==true)
   {
      $lifelinelock = true;
      %player.winnings = 10000;
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just won the MILLION!!!!");
      healHotseat();
      reloadObject($hotseat, 10000);
      schedule("WinTheMillion();", 3);
   }
   else if($execguarddestroyed==false)
   {
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has completely totalled Prometheus!!!");
   }
}

function destGuardCont()
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   $execguarddestroyed = true;
   if($promieMilliondestroyed==true)
   {
      $lifelinelock = true;
      %player.winnings = 10000;
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just won the MILLION!!!!");
      healHotseat();
      reloadObject($hotseat, 10000);
      schedule("WinTheMillion();", 3);
   }
   else if($promieMilliondestroyed==false)
   {
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just obliterated Prometheus's bodyguard!!");
   }
}

function DestroyedAud(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   if(%destroyed==$hotseat)
   {
      if(%destroyer!=$hotseat)
      {
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " is history!");
         $askingAudience = false;
         returnAudience();
         schedule("GameOver();",3);
      }
      else if(%destroyer==$hotseat)
      {
         say("Everybody", 1, "REGIS: " @ hotseatname @ " has forfieted the game!");
         $askingAudience = false;
         returnAudience();
         schedule("forfiet();",3);
      }
   }
   else if(%destroyed==$seeker100)
   {  
      %player.winnings = 1;
      $lifelinelock = true;
      $askingAudience = false;
      $seeker100destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: And he's got it!");
      reloadObject($hotseat, 10000);
      schedule("Goad200();", 3);
   } 
   else if(%destroyed==$goad200)
   {  
      %player.winnings = 2;
      $lifelinelock = true;
      $askingAudience = false;
      $goad200destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: Nice one, " @ $hotseatname @ "!");
      reloadObject($hotseat, 10000);
      schedule("Eman300();", 3);
   } 
   else if(%destroyed==$eman300)
   {  
      %player.winnings = 3;
      $lifelinelock = true;
      $askingAudience = false;
      $eman300destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: It's a good one!!");
      reloadObject($hotseat, 10000);
      schedule("Mino500();", 3);
   } 
   else if(%destroyed==$mino500)
   {  
      %player.winnings = 5;
      $lifelinelock = true;
      $askingAudience = false;
      $mino500destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: And he got it for $500!");
      reloadObject($hotseat, 10000);
      schedule("TwoGoads1000();", 3);
   } 
   else if(%destroyed==$goad1000)
   {  
      $goad1000destroyed = true;
      if($goad10002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "<F3>" @ $hotseatname @ ": Yes Regis, that's my final answer...");
         schedule("say(\"Everybody\", 1, \"REGIS: Well, it's a good one!!\");",2);
         reloadObject($hotseat, 10000);
         schedule("Intermission1000();",5);
      }
      else if($goad10002destroyed==false)
      {
         say("Everybody", 1, "REGIS: You've almost got it...");
         schedule("say(\"Everybody\", 1, \"REGIS: Is that your final answer?\");",5);
         schedule("RegisComment2();", 30);
      }
   } 
   else if(%destroyed==$goad10002)
   {  
      $goad10002destroyed = true;
      if($goad1000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "<F3>" @ $hotseatname @ ": Yes Regis, that's my final answer...");
         schedule("say(\"Everybody\", 1, \"REGIS: Well, it's a good one!!\");",2);
         reloadObject($hotseat, 10000);
         schedule("Intermission1000();",5);
      }
      else if($goad1000destroyed==false)
      {
         say("Everybody", 1, "REGIS: You've almost got it...");
         schedule("say(\"Everybody\", 1, \"REGIS: Is that your final answer?\");",5);
         schedule("RegisComment2();", 30);
      }
   } 
   else if(%destroyed==$eman2000)
   {  
      $eman2000destroyed = true;
      if($eman20002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 20;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: Okay then, are you ready for the next round?\");",3);
         reloadObject($hotseat, 10000);
         schedule("Shep4000();",6);
      }
      else if($eman20002destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
         schedule("RegisComment3();", 30);
      }
   } 
   else if(%destroyed==$eman20002)
   {  
      $eman20002destroyed = true;
      if($eman2000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 20;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: Okay then, are you ready for the next round?\");",3);
         reloadObject($hotseat, 10000);
         schedule("Shep4000();",6);
      }
      else if($eman2000destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
         schedule("RegisComment3();", 30);
      }
   } 
   else if(%destroyed==$shep4000)
   {  
      %player.winnings = 40;
      $lifelinelock = true;
      $askingAudience = false;
      $shep4000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " is on fire!!");
      reloadObject($hotseat, 10000);
      schedule("Basilisk8000();", 3);
   } 
   else if(%destroyed==$basilisk8000)
   {  
      %player.winnings = 80;
      $lifelinelock = true;
      $askingAudience = false;
      $basilisk8000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ ", you've just won yourself $8,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: Getting a little harder, isn't it?\");",5);
      schedule("say(\"Everybody\", 1, \"REGIS: Well, you're doing good...only 7 away from a million!!\");",8);
      schedule("say(\"Everybody\", 1, \"REGIS: Are you ready? Then let's play!\");",11);
      reloadObject($hotseat, 10000);
      schedule("Gorgon16000();", 14);
   } 
   else if(%destroyed==$gorgon16000)
   {  
      %player.winnings = 160;
      $lifelinelock = true;
      $askingAudience = false;
      $gorgon16000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: And he did it again, for $16,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: You realize that if you miss here, you'll be reduced back to $1,000...\");",5);
      schedule("say(\"Everybody\", 1, \"REGIS: ...but if you get this one, you'll be guaranteed to leave with at least $32,000.\");",10);
      schedule("say(\"Everybody\", 1, \"REGIS: Now remember, you can still use your lifelines at any time.\");",15);
      schedule("say(\"Everybody\", 1, \"REGIS: Ready, here we go...\");",18);
      reloadObject($hotseat, 10000);
      schedule("Judge32000();", 20);
   } 
   else if(%destroyed==$judge32000)
   {  
      %player.winnings = 320;
      $lifelinelock = true;
      $askingAudience = false;
      $judge32000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: " @ $hotseatname @", on fire!!!");
      reloadObject($hotseat, 10000);
      schedule("Intermission32000();", 5);
   } 
   else if(%destroyed==$olympian64000)
   {  
      %player.winnings = 640;
      $lifelinelock = true;
      $askingAudience = false;
      $olympian64000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: It's a good one!!!");
      schedule("say(\"Everybody\", 1, \"REGIS: Alright, you're only 4 away from a million...\");",5);
      reloadObject($hotseat, 10000);
      schedule("Apoc125000();", 8);
   } 
   else if(%destroyed==$apoc125000)
   {  
      %player.winnings = 1250;
      $lifelinelock = true;
      $askingAudience = false;
      $apoc125000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ ", you've just won $125,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: You seem a little nervous....\");",5);
      schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": No...I'm not nervous.\");",8);
      schedule("say(\"Everybody\", 1, \"REGIS: Well, you should be....I know I would...\");",11);
      schedule("say(\"Everybody\", 1, \"REGIS: Alright, you're only 3 away from a million...\");",14);
      reloadObject($hotseat, 10000);
      schedule("Exec250000();", 17);
   } 
   else if(%destroyed==$exec250000)
   {  
      %player.winnings = 2500;
      $lifelinelock = true;
      $askingAudience = false;
      $exec250000destroyed = true;
      returnAudience();
      say("Everybody", 1, "REGIS: He's done it again, for $250,000!!");
      reloadObject($hotseat, 10000);
      schedule("TwoExecs500000();", 3);
   } 
   else if(%destroyed==$exec500000)
   {  
      $exec500000destroyed = true;
      if($exec5000002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 5000;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you've just won half a million dollars!!!\");",3);
         schedule("say(\"Everybody\", 1, \"REGIS: Alright, we're going for the final challenge. We're going for a million!!\");",8);         
         reloadObject($hotseat, 10000);
         schedule("promieMillion();",10);
      }
      else if($exec5000002destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
      }
   } 
   else if(%destroyed==$exec5000002)
   {  
      $exec5000002destroyed = true;
      if($exec500000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 5000;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you've just won half a million dollars!!!\");",3);
         schedule("say(\"Everybody\", 1, \"REGIS: Alright, we're going for the final challenge. We're going for a million!!\");",8);         
         reloadObject($hotseat, 10000);
         schedule("promieMillion();",10);
      }
      else if($exec500000destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
      }
   } 
   else if(%destroyed==$promieMillion)
   {  
      $promieMilliondestroyed = true;
      if($execguarddestroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10000;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just won the MILLION!!!!");
         healHotseat();
         reloadObject($hotseat, 10000);
         schedule("WinTheMillion();", 3);
      }
      else if($execguarddestroyed==false)
      {
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " has completely totalled Prometheus!!!");
      }
   }
   else if(%destroyed==$execguard)
   {  
      $execguarddestroyed = true;
      if($promieMilliondestroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10000;
         $askingAudience = false;
         returnAudience();
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just won the MILLION!!!!");
         healHotseat();
         reloadObject($hotseat, 10000);
         schedule("WinTheMillion();", 3);
      }
      else if($promieMilliondestroyed==false)
      {
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just obliterated Prometheus's bodyguard!!");
      }
   } 
}

function DestroyedClone(%destroyed, %destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   if(%destroyed==$hotseat)
   {
      if(%destroyer!=$hotseat)
      {
         say("Everybody", 1, "REGIS: " @ $hotseatname @ " is history!");
         schedule("GameOver();",3);
      }
      else if(%destroyer==$hotseat)
      {
         say("Everybody", 1, "REGIS: " @ hotseatname @ " has forfieted the game!");
         schedule("forfiet();",3);
      }
   }
   else if(%destroyed==$clone)
   {
      $cloning = false;
   }
   else if(%destroyed==$seeker100)
   {  
      %player.winnings = 1;
      $lifelinelock = true;
      $seeker100destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: And he's got it!");
      reloadObject($hotseat, 10000);
      schedule("Goad200();", 3);
   } 
   else if(%destroyed==$goad200)
   {  
      %player.winnings = 2;
      $lifelinelock = true;
      $goad200destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: Nice one, " @ $hotseatname @ "!");
      reloadObject($hotseat, 10000);
      schedule("Eman300();", 3);
   } 
   else if(%destroyed==$eman300)
   {  
      %player.winnings = 3;
      $lifelinelock = true;
      $eman300destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: It's a good one!!");
      reloadObject($hotseat, 10000);
      schedule("Mino500();", 3);
   } 
   else if(%destroyed==$mino500)
   {  
      %player.winnings = 5;
      $lifelinelock = true;
      $mino500destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: And he got it for $500!");
      reloadObject($hotseat, 10000);
      schedule("TwoGoads1000();", 3);
   } 
   else if(%destroyed==$goad1000)
   {  
      $goad1000destroyed = true;
      if($goad10002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10;
         $cloning = false;
         killClone();
         say("Everybody", 1, "<F3>" @ $hotseatname @ ": Yes Regis, that's my final answer...");
         schedule("say(\"Everybody\", 1, \"REGIS: Well, it's a good one!!\");",2);
         reloadObject($hotseat, 10000);
         schedule("Intermission1000();",5);
      }
      else if($goad10002destroyed==false)
      {
         say("Everybody", 1, "REGIS: You've almost got it...");
         schedule("say(\"Everybody\", 1, \"REGIS: Is that your final answer?\");",5);
         schedule("RegisComment2();", 30);
      }
   } 
   else if(%destroyed==$goad10002)
   {  
      $goad10002destroyed = true;
      if($goad1000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 10;
         $cloning = false;
         killClone();
         say("Everybody", 1, "<F3>" @ $hotseatname @ ": Yes Regis, that's my final answer...");
         schedule("say(\"Everybody\", 1, \"REGIS: Well, it's a good one!!\");",2);
         reloadObject($hotseat, 10000);
         schedule("Intermission1000();",5);
      }
      else if($goad1000destroyed==false)
      {
         say("Everybody", 1, "REGIS: You've almost got it...");
         schedule("say(\"Everybody\", 1, \"REGIS: Is that your final answer?\");",5);
         schedule("RegisComment2();", 30);
      }
   } 
   else if(%destroyed==$eman2000)
   {  
      $eman2000destroyed = true;
      if($eman20002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 20;
         $cloning = false;
         killClone();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: Okay then, are you ready for the next round?\");",3);
         reloadObject($hotseat, 10000);
         schedule("Shep4000();",6);
      }
      else if($eman20002destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
         schedule("RegisComment3();", 30);
      }
   } 
   else if(%destroyed==$eman20002)
   {  
      $eman20002destroyed = true;
      if($eman2000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 20;
         $cloning = false;
         killClone();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: Okay then, are you ready for the next round?\");",3);
         reloadObject($hotseat, 10000);
         schedule("Shep4000();",6);
      }
      else if($eman2000destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
         schedule("RegisComment3();", 30);
      }
   } 
   else if(%destroyed==$shep4000)
   {  
      %player.winnings = 40;
      $lifelinelock = true;
      $shep4000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " is on fire!!");
      reloadObject($hotseat, 10000);
      schedule("Basilisk8000();", 3);
   } 
   else if(%destroyed==$basilisk8000)
   {  
      %player.winnings = 80;
      $lifelinelock = true;
      $basilisk8000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ ", you've just won yourself $8,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: Getting a little harder, isn't it?\");",5);
      schedule("say(\"Everybody\", 1, \"REGIS: Well, you're doing good...only 7 away from a million!!\");",8);
      schedule("say(\"Everybody\", 1, \"REGIS: Are you ready? Then let's play!\");",11);
      reloadObject($hotseat, 10000);
      schedule("Gorgon16000();", 14);
   } 
   else if(%destroyed==$gorgon16000)
   {  
      %player.winnings = 160;
      $lifelinelock = true;
      $gorgon16000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: And he did it again, for $16,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: You realize that if you miss here, you'll be reduced back to $1,000...\");",5);
      schedule("say(\"Everybody\", 1, \"REGIS: ...but if you get this one, you'll be guaranteed to leave with at least $32,000.\");",10);
      schedule("say(\"Everybody\", 1, \"REGIS: Now remember, you can still use your lifelines at any time.\");",15);
      schedule("say(\"Everybody\", 1, \"REGIS: Ready, here we go...\");",18);
      reloadObject($hotseat, 10000);
      schedule("Judge32000();", 20);
   } 
   else if(%destroyed==$judge32000)
   {  
      %player.winnings = 320;
      $lifelinelock = true;
      $judge32000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: " @ $hotseatname @", on fire!!!");
      reloadObject($hotseat, 10000);
      schedule("Intermission32000();", 5);
   } 
   else if(%destroyed==$olympian64000)
   {  
      %player.winnings = 640;
      $lifelinelock = true;
      $olympian64000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: It's a good one!!!");
      schedule("say(\"Everybody\", 1, \"REGIS: Alright, you're only 4 away from a million...\");",5);
      reloadObject($hotseat, 10000);
      schedule("Apoc125000();", 8);
   } 
   else if(%destroyed==$apoc125000)
   {  
      %player.winnings = 1250;
      $lifelinelock = true;
      $apoc125000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ ", you've just won $125,000!!");
      schedule("say(\"Everybody\", 1, \"REGIS: You seem a little nervous....\");",5);
      schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": No...I'm not nervous.\");",8);
      schedule("say(\"Everybody\", 1, \"REGIS: Well, you should be....I know I would...\");",11);
      schedule("say(\"Everybody\", 1, \"REGIS: Alright, you're only 3 away from a million...\");",14);
      reloadObject($hotseat, 10000);
      schedule("Exec250000();", 17);
   } 
   else if(%destroyed==$exec250000)
   {  
      %player.winnings = 2500;
      $lifelinelock = true;
      $exec250000destroyed = true;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: He's done it again, for $250,000!!");
      reloadObject($hotseat, 10000);
      schedule("TwoExecs500000();", 3);
   } 
   else if(%destroyed==$exec500000)
   {  
      $exec500000destroyed = true;
      if($exec5000002destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 5000;
         $cloning = false;
         killClone();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you've just won half a million dollars!!!\");",3);
         schedule("say(\"Everybody\", 1, \"REGIS: Alright, we're going for the final challenge. We're going for a million!!\");",8);         
         reloadObject($hotseat, 10000);
         schedule("promieMillion();",10);
      }
      else if($exec5000002destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
      }
   } 
   else if(%destroyed==$exec5000002)
   {  
      $exec5000002destroyed = true;
      if($exec500000destroyed==true)
      {
         $lifelinelock = true;
         %player.winnings = 5000;
         $cloning = false;
         killClone();
         say("Everybody", 1, "REGIS: He's got both of them!!");
         schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you've just won half a million dollars!!!\");",3);
         schedule("say(\"Everybody\", 1, \"REGIS: Alright, we're going for the final challenge. We're going for a million!!\");",8);         
         reloadObject($hotseat, 10000);
         schedule("promieMillion();",10);
      }
      else if($exec500000destroyed==false)
      {
         say("Everybody", 1, "REGIS: He's got one of them!");
      }
   } 
   else if(%destroyed==$promieMillion)
   {
       destClonePromCont();   
   }
   else if(%destroyed==$execguard)
   {  
       destCloneGuardCont();
   } 
}

function destClonePromCont()
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   $promieMilliondestroyed = true;
   if($execguarddestroyed==true)
   {
      $lifelinelock = true;
      %player.winnings = 10000;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just won the MILLION!!!!");
      healHotseat();
      reloadObject($hotseat, 10000);
      schedule("WinTheMillion();", 3);
   }
   else if($execguarddestroyed==false)
   {
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has completely totalled Prometheus!!!");
   }
}

function destCloneGuardCont()
{
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   $execguarddestroyed = true;
   if($promieMilliondestroyed==true)
   {
      $lifelinelock = true;
      %player.winnings = 10000;
      $cloning = false;
      killClone();
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just won the MILLION!!!!");
      healHotseat();
      reloadObject($hotseat, 10000);
      schedule("WinTheMillion();", 3);
   }
   else if($promieMilliondestroyed==false)
   {
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " has just obliterated Prometheus's bodyguard!!");
   }
}

function healHotseat()
{
   healObject($hotseat, 50000);
   healObject($hotseat, 50000);
   healObject($hotseat, 50000);
   healObject($hotseat, 50000);
   healObject($hotseat, 50000);
   healObject($hotseat, 50000);
}

function setHUDTimerAll(%time, %increment, %string, %channel)
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %everybody = playerManager::getPlayerNum(%i);
      setHudTimer(60, -1, "Game begins in:", 1, %everybody);
   }
} 

function Audience::structure::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if($lifelinelock==true) return;
   if(playerManager::getPlayerCount()>1)
   {
      if(%scanner==$hotseat)
      {
         if(($cloning==false)&&($doingFifty==false))
         {
            if($lifeline1==false)
            {
               $lifeline1 = true;
               $askingAudience = true;
               say("Everybody", 1, "REGIS: Well it looks like " @ $hotseatname @ " is going to use one of his lifelines...");
               schedule("say(\"Everybody\", 1, \"REGIS: He's going to ask the audience for help. In a moment, all audience members will be teleported into the arena in order to help \" @ $hotseatname @ \" destroy his opponents.\");",3);
               %player.lifelines--;
               %player.askaudience = "Used";
               schedule("teleportAudience();",8);
            }
            else if($lifeline1==true)
            {
               say(%player, %player, "REGIS: I'm sorry, but you've already used that lifeline.");
            }
         }
         else
         {
            say(%player, %player, "REGIS: I'm sorry, but you can't use more than one lifeline at a time.");
         }
      }
   }
   else
   {
      say(%player, %player, "REGIS: I'm sorry, but there doesn't seem to be an audience present. You can use this lifeline later if another player joins the game.");
   }
}

function Clone::structure::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if($lifelinelock==true) return;
   if(%scanner==$hotseat)
   {
      if(($askingAudience==false)&&($doingFifty==false))
      {
         if($lifeline2==false)
         {
            $lifeline2 = true;
            $cloning = true;
            say("Everybody", 1, "REGIS: Well it looks like " @ $hotseatname @ " is going to use one of his lifelines...");
            schedule("say(\"Everybody\", 1, \"REGIS: He's going to clone a friend. In a moment, the server will clone an AI unit identical to \" @ $hotseatname @ \"'s vehicle which will help him destroy his opponents.\");",3);
            %player.lifelines--;
            %player.clonefriend = "Used";
            $clone = cloneVehicle($hotseat);
            Clone.name = getHUDname($hotseat) @ "'s Cloned Friend";
            setPilotId($clone, 44);
            setTeam($clone, *IDSTR_TEAM_YELLOW);
            randomTransport($clone, -436.464, -407.849, 149.685, 247.432);
            order($clone, guard, $hotseat);
            sethercowner($clone, $hotseat);
         }
         else if($lifeline2==true)
         {
            say(%player, %player, "REGIS: I'm sorry, but you've already used that lifeline.");
         }
      }
      else
      {
         say(%player, %player, "REGIS: I'm sorry, but you can't use more than one lifeline at a time.");
      }
   }
}

function FiftyFifty::structure::onScan(%scanned, %scanner)
{
   if($lifelinelock==true) return;
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%scanner==$hotseat)
   {
      if(($askingAudience==false)&&($cloning==false))
      {
         if($lifeline3==false)
         {
            $lifeline3 = true;
            $doingFifty = true;
            say("Everybody", 1, "REGIS: Well it looks like " @ $hotseatname @ " is going to use one of his lifelines...");
            schedule("say(\"Everybody\", 1, \"REGIS: He's gonna do a 50/50. Computer, please give \" @ $hotseatname @ \"'s enemy a 50/50 chance of spontaneously combusting...\");",2);
            %player.lifelines--;
            %player.fiftyfifty = "Used";
            $FiftyFifty = RandomInt(0,1);
            if($double==false)
            {
               if($FiftyFifty==0)
               {
                  schedule("healObject($enemy, -50000);",5);
                  schedule("$doingFifty = false;",7);
               }
               else if($FiftyFifty==1)
               {
                  schedule("say(\"Everybody\", 1, \"REGIS: Well, that didn't work. Didn't seem to help much, did it?\");",5);
                  schedule("$doingFifty = false;",7);
               }
            }
            else if($double==true)
            {
               if($enemy==$goad1000)
               {
                  if(($goad1000destroyed==true)&&($goad10002destroyed==false))
                  {
                     schedule("healObject($goad10002, -50000);",5);
                  }
                  else if(($goad1000destroyed==false)&&($goad10002destroyed==true))
                  {
                     schedule("healObject($goad1000, -50000);",5);
                  }
                  else if(($goad1000destroyed==false)&&($goad10002destroyed==false))
                  {
                     schedule("healObject($enemy, -50000);",5);
                  }
               }
               else if($enemy==$eman2000)
               {
                  if(($eman2000destroyed==true)&&($eman20002destroyed==false))
                  {
                     schedule("healObject($eman20002, -50000);",5);
                  }
                  else if(($eman2000destroyed==false)&&($eman20002destroyed==true))
                  {
                     schedule("healObject($eman2000, -50000);",5);
                  }
                  else if(($eman2000destroyed==false)&&($eman20002destroyed==false))
                  {
                     schedule("healObject($enemy, -50000);",5);
                  }
               }
               else if($enemy==$exec500000)
               {
                  if(($exec500000destroyed==true)&&($exec5000002destroyed==false))
                  {
                     schedule("healObject($exec5000002, -50000);",5);
                  }
                  else if(($exec500000destroyed==false)&&($exec5000002destroyed==true))
                  {
                     schedule("healObject($exec500000, -50000);",5);
                  }
                  else if(($exec500000destroyed==false)&&($exec5000002destroyed==false))
                  {
                     schedule("healObject($enemy, -50000);",5);
                  }
               }
               else if($enemy==$promieMillion)
               {
                  if(($promieMilliondestroyed==true)&&($execguarddestroyed==false))
                  {
                     schedule("healObject($execguard, -50000);",5);
                  }
                  else if(($promieMilliondestroyed==false)&&($execguarddestroyed==true))
                  {
                     schedule("healObject($promieMillion, -50000);",5);
                  }
                  else if(($promieMilliondestroyed==false)&&($execguarddestroyed==false))
                  {
                     schedule("healObject($enemy, -50000);",5);
                  }
               }
               else if($enemy==$execguard)
               {
                  if(($promieMilliondestroyed==true)&&($execguarddestroyed==false))
                  {
                     schedule("healObject($execguard, -50000);",5);
                  }
                  else if(($promieMilliondestroyed==false)&&($execguarddestroyed==true))
                  {
                     schedule("healObject($promieMillion, -50000);",5);
                  }
                  else if(($promieMilliondestroyed==false)&&($execguarddestroyed==false))
                  {
                     schedule("healObject($enemy, -50000);",5);
                  }
               }
               schedule("$doingFifty = false;",7);
            }
         }
         else if($lifeline3==true)
         {
            say(%player, %player, "REGIS: I'm sorry, but you've already used that lifeline.");
         }
      }
      else
      {
         say(%player, %player, "REGIS: I'm sorry, but you can't use more than one lifeline at a time.");
      }
   }
}

function fastestShooter()
{
   say("Everybody", 1, "REGIS: Get ready! It's time for our \"Fastest Shooter\" round.");
   schedule("say(\"Everybody\", 1, \"REGIS: The first contestant to destroy our \" @ $txt2 @ \" goad will go on to play \" @ $txt3 @ \"!!\");",5);
   schedule("say(\"Everybody\", 1, \"REGIS: Are you ready? Then let's begin!\");",10);
   schedule("dropGoad();",11);
}

function dropGoad()
{
   $fastGoad = NewObject("FastGoad", Herc, 21);
   setPilotId($fastGoad, 28);
   setTeam($fastGoad, *IDSTR_TEAM_RED);
   randomTransport($fastGoad, -423.642, 406.586, 101.674, 996.623);
}

function hotseat(%destroyer)
{
   %player = playerManager::vehicleIdToPlayerNum(%destroyer);
   %player.audience = false;
   $hotseat = %destroyer;
   $hotseatname = getHUDName($hotseat);
   %player.lifelines = 3;
   %player.askaudience = "Intact";
   %player.clonefriend = "Intact";
   %player.fiftyfifty = "Intact";
   say("Everybody", 1, "REGIS: Okay, let's see who got it...");
   schedule("say(\"Everybody\", 1, \"REGIS: And in the fastest time...\");",3);
   schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", you're going to the hotseat!\");",4);
   schedule("millionaire();",6);
}

function millionaire()
{
   $lifelinelock = true;
   setPosition($hotseat, -143.137, -81.2576, 52);
   setTeam($hotseat, *IDSTR_TEAM_YELLOW);
   healHotseat();
   reloadObject($hotseat, 10000);
   globalMessagebox();
   $gamestart = true;
   $hotseatComment = randomInt(0,3);
   if($hotseatComment==0)
   {
      say("Everybody", 1, "<F3>" @ $hotseatname @ ": Hi Regis, I like your tie.");
      schedule("say(\"Everybody\", 1, \"REGIS: Thanks, I get that alot...\");",3);   
      schedule("say(\"Everybody\", 1, \"REGIS: The rules of the game are simple. For each round you survive, you double your money.\");",6);
      schedule("say(\"Everybody\", 1, \"REGIS: You begin at $100 and work your way up to a million.\");",9);
      schedule("say(\"Everybody\", 1, \"REGIS: You can walk away with your money at any time by shutting down on the \" @ $txt1 @ \" pad.\");",12);
      schedule("say(\"Everybody\", 1, \"REGIS: If you make it to the $1,000 or $32,000 level, you are guaranteed to walk away with no less than that amount.\");",15);
      schedule("say(\"Everybody\", 1, \"REGIS: If you die, you will be reduced back down to $0 or the last safe level you've reached.\");",18);
      schedule("say(\"Everybody\", 1, \"REGIS: You get 3 lifelines: Ask the audience, clone a friend, & 50/50.\");",21);
      schedule("say(\"Everybody\", 1, \"REGIS: You can use them at any time during the game by scanning the corresponding drone balls.\");",24);
      schedule("say(\"Everybody\", 1, \"REGIS: Now if you're ready \" @ $hotseatname @ \", let's play Who Wants To Be A Millionaire!\");",27);
      schedule("Seeker100();",30);
   }
   else
   {
      say("Everybody", 1, "REGIS: The rules of the game are simple. For each round you survive, you double your money.");
      schedule("say(\"Everybody\", 1, \"REGIS: You begin at $100 and work your way up to a million.\");",3);
      schedule("say(\"Everybody\", 1, \"REGIS: You can walk away with your money at any time by shutting down on the \" @ $txt1 @ \" pad.\");",6);
      schedule("say(\"Everybody\", 1, \"REGIS: If you make it to the $1,000 or $32,000 level, you are guaranteed to walk away with no less than that amount.\");",9);
      schedule("say(\"Everybody\", 1, \"REGIS: If you die, you will be reduced back down to $0 or the last safe level you've reached.\");",12);
      schedule("say(\"Everybody\", 1, \"REGIS: You get 3 lifelines: Ask the audience, clone a friend, & 50/50.\");",15);
      schedule("say(\"Everybody\", 1, \"REGIS: You can use them at any time during the game by scanning the corresponding drone balls.\");",18);
      schedule("say(\"Everybody\", 1, \"REGIS: Now if you're ready \" @ $hotseatname @ \", let's play Who Wants To Be A Millionaire!\");",21);
      schedule("Seeker100();",24);
   }
}

function globalMessagebox()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::PlayerNumToVehicleId(%player);
      if(%vehicleId!=$hotseat)
      {
         messagebox(%player, "If you would like to watch the game in progress, press ctrl + v, then cycle through the cameras by pressing the \"Home\" key until you're watching the player in the hotseat.");
      }
   }
}

function teleportAudience()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::PlayerNumToVehicleId(%player);
      if(%vehicleId!=$hotseat)
      {  
         setTeam(%vehicleId, *IDSTR_TEAM_BLUE);
         schedule("redrop(" @ %vehicleId @ ");",1);
         schedule("setTeam(" @ %vehicleId @ ", *IDSTR_TEAM_YELLOW);",2);
         setPlayerCamera();
      }
   }
}

function returnAudience()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::PlayerNumToVehicleId(%player);
      if(%vehicleId!=$hotseat)
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
         schedule("redrop(" @ %vehicleId @ ");",1);
      }
   }
}

function killClone()
{
   healObject($clone, -50000);
}

function Intermission1000()
{
   $hotseatplayer = playerManager::vehicleIdToPlayerNum($hotseat);
   $lifelinelock = true;
   healHotseat();
   reloadObject($hotseat, 10000);
   say("Everybody", 1, "REGIS: Well, you've made to the $1,000 level, " @ $hotseatname @ ", which means that you're guaranteed to go home with at least $1,000.");
   if($hotseatplayer.lifelines>1)
   {
      schedule("say(\"Everybody\", 1, \"REGIS: You've also got \" @ $hotseatplayer.lifelines @ \" lifelines intact and you're only 10 rounds away from a million!\");",5);
   }
   else if($hotseatplayer.lifelines==1)
   {
      schedule("say(\"Everybody\", 1, \"REGIS: You've also got \" @ $hotseatplayer.lifelines @ \" lifeline intact and you're only 10 rounds away from a million!\");",5);
   }
   else if($hotseatplayer.lifelines==0)
   {
      schedule("say(\"Everybody\", 1, \"REGIS: You're out of lifelines, but you're only 10 rounds away from a million.\");",5);
   }
   schedule("say(\"Everybody\", 1, \"REGIS: Now if you're ready, \" @ $hotseatname @ \", let's play!\");",10);
   schedule("TwoEmans2000();", 13);
}

function Intermission32000()
{
   $hotseatplayer = playerManager::vehicleIdToPlayerNum($hotseat);
   $lifelinelock = true;
   healHotseat();
   reloadObject($hotseat, 10000);
   say("Everybody", 1, "REGIS: Well, you've made to the $32,000 level, " @ $hotseatname @ ", which means that you're guaranteed to go home with at least $32,000. It's yours to keep.");
   if($hotseatplayer.lifelines>1)
   {
      schedule("say(\"Everybody\", 1, \"REGIS: You've got \" @ $hotseatplayer.lifelines @ \" lifelines intact and you're only 5 away from a million!\");",5);
   }
   else if($hotseatplayer.lifelines==1)
   {
      schedule("say(\"Everybody\", 1, \"REGIS: You've got \" @ $hotseatplayer.lifelines @ \" lifeline intact and you're only 5 away from a million!\");",5);
   }
   else if($hotseatplayer.lifelines==0)
   {
      schedule("say(\"Everybody\", 1, \"REGIS: You're out of lifelines, but you're only 5 rounds away from a million!\");",5);
   }
   schedule("say(\"Everybody\", 1, \"REGIS: I was just wondering, \" @ $hotseatname @ \", what are you gonna do if you win the million?\");",10);
   schedule("HotseatChat();",13);
   schedule("say(\"Everybody\", 1, \"REGIS: Well, are you ready for the next round?\");",23);
   schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": Sure.\");",26);
   schedule("say(\"Everybody\", 1, \"REGIS: Alright then, let's play Who Wants To Be A Millionaire!\");",29);
   schedule("Olympian64000();", 32);
}

function Seeker100()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $100, attempt to destroy this Seeker.");
   $double = false;
   $seeker100 = NewObject("Seeker100", Herc, 20);
   setPilotId($seeker100, 29);
   setTeam($seeker100, *IDSTR_TEAM_RED);
   randomTransport($seeker100, -436.464, -407.849, 149.685, 247.432);
   $enemy = $seeker100;
   order($seeker100, attack, $hotseat);
   schedule("RegisComment1();",45);
}

function Goad200()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $200, attempt to destroy this Goad.");
   $double = false;
   $goad200 = NewObject("Goad200", Herc, 21);
   setPilotId($goad200, 30);
   setTeam($goad200, *IDSTR_TEAM_RED);
   randomTransport($goad200, -436.464, -407.849, 149.685, 247.432);
   $enemy = $goad200;
   order($goad200, attack, $hotseat);
}

function Eman300()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $300, attempt to destroy this Emancipator.");
   $double = false;
   $eman300 = NewObject("Eman300", Herc, 30);
   setPilotId($eman300, 31);
   setTeam($eman300, *IDSTR_TEAM_RED);
   randomTransport($eman300, -436.464, -407.849, 149.685, 247.432);
   $enemy = $eman300;
   order($eman300, attack, $hotseat);
}

function Mino500()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $500, attempt to destroy this Minotaur.");
   $double = false;
   $mino500 = NewObject("Mino500", Herc, 11);
   setPilotId($mino500, 32);
   setTeam($mino500, *IDSTR_TEAM_RED);
   randomTransport($mino500, -436.464, -407.849, 149.685, 247.432);
   $enemy = $mino500;
   order($mino500, attack, $hotseat);
}

function TwoGoads1000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $1,000, attempt to destroy these two Goads.");
   $double = true;
   $goad1000 = NewObject("Goad1000", Herc, 21);
   $goad10002 = NewObject("Goad1000", Herc, 21);
   setPilotId($goad1000, 33);
   setPilotId($goad10002, 33);
   setTeam($goad1000, *IDSTR_TEAM_RED);
   setTeam($goad10002, *IDSTR_TEAM_RED);
   randomTransport($goad1000, -436.464, -407.849, 149.685, 247.432);
   randomTransport($goad10002, -436.464, -407.849, 149.685, 247.432);
   $enemy = $goad1000;
   order($goad1000, attack, $hotseat);
   order($goad10002, attack, $hotseat);
}

function TwoEmans2000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: Alright. For $2,000, attempt to destroy these two Emancipators.");
   $double = true;
   $eman2000 = NewObject("Eman2000", Herc, 30);
   $eman20002 = NewObject("Eman2000", Herc, 30);
   setPilotId($eman2000, 34);
   setPilotId($eman20002, 34);
   setTeam($eman2000, *IDSTR_TEAM_RED);
   setTeam($eman20002, *IDSTR_TEAM_RED);
   randomTransport($eman2000, -436.464, -407.849, 149.685, 247.432);
   randomTransport($eman20002, -436.464, -407.849, 149.685, 247.432);
   $enemy = $eman2000;
   order($eman2000, attack, $hotseat);
   order($eman20002, attack, $hotseat);
}

function Shep4000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: Alright then. For $4,000, attempt to destroy this Shepherd.");
   $double = false;
   $shep4000 = NewObject("shep4000", Herc, 22);
   setPilotId($shep4000, 35);
   setTeam($shep4000, *IDSTR_TEAM_RED);
   randomTransport($shep4000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $shep4000;
   order($shep4000, attack, $hotseat);
}

function Basilisk8000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: Okay then. For $8,000, attempt to destroy this Basilisk.");
   $double = false;
   $basilisk8000 = NewObject("Basilisk8000", Herc, 5);
   setPilotId($basilisk8000, 36);
   setTeam($basilisk8000, *IDSTR_TEAM_RED);
   randomTransport($basilisk8000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $basilisk8000;
   order($basilisk8000, attack, $hotseat);
}

function Gorgon16000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $16,000, attempt to destroy this Gorgon.");
   $double = false;
   $gorgon16000 = NewObject("Gorgon16000", Herc, 3);
   setPilotId($gorgon16000, 37);
   setTeam($gorgon16000, *IDSTR_TEAM_RED);
   randomTransport($gorgon16000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $gorgon16000;
   order($gorgon16000, attack, $hotseat);
}

function Judge32000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $32,000, attempt to destroy this Adjudicator.");
   $double = false;
   $judge32000 = NewObject("Judge32000", Herc, 27);
   setPilotId($judge32000, 38);
   setTeam($judge32000, *IDSTR_TEAM_RED);
   randomTransport($judge32000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $judge32000;
   order($judge32000, attack, $hotseat);
}

function Olympian64000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $64,000, attempt to destroy this Olympian!");
   $double = false;
   $olympian64000 = NewObject("Olympian64000", Herc, 33);
   setPilotId($olympian64000, 39);
   setTeam($olympian64000, *IDSTR_TEAM_RED);
   randomTransport($olympian64000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $olympian64000;
   order($olympian64000, attack, $hotseat);
}

function Apoc125000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: Here we go for $125,000...");
   schedule("say(\"Everybody\", 1, \"REGIS: Attempt to destroy this Apocalypse!\");",2);
   $double = false;
   $apoc125000 = NewObject("Apoc125000", Herc, 1);
   setPilotId($apoc125000, 40);
   setTeam($apoc125000, *IDSTR_TEAM_RED);
   randomTransport($apoc125000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $apoc125000;
   order($apoc125000, attack, $hotseat);
}

function Exec250000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: Alright, going for $250,000...");
   schedule("say(\"Everybody\", 1, \"REGIS: Attempt to destroy this Executioner!\");",3);
   $double = false;
   $exec250000 = NewObject("Exec250000", Herc, 28);
   setPilotId($exec250000, 41);
   setTeam($exec250000, *IDSTR_TEAM_RED);
   randomTransport($exec250000, -436.464, -407.849, 149.685, 247.432);
   $enemy = $exec250000;
   order($exec250000, attack, $hotseat);
}

function TwoExecs500000()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: Alright, going for $500,000, let's see if you can destroy these two Executioners!!");
   $double = true;
   $exec500000 = NewObject("Exec500000", Herc, 28);
   $exec5000002 = NewObject("Exec500000", Herc, 28);
   setPilotId($exec500000, 42);
   setPilotId($exec5000002, 42);
   setTeam($exec500000, *IDSTR_TEAM_RED);
   setTeam($exec5000002, *IDSTR_TEAM_RED);
   randomTransport($exec500000, -436.464, -407.849, 149.685, 247.432);
   randomTransport($exec5000002, -436.464, -407.849, 149.685, 247.432);
   $enemy = $exec500000;
   order($exec500000, attack, $hotseat);
   order($exec5000002, attack, $hotseat);
}

function PromieMillion()
{
   $lifelinelock = false;
   say("Everybody", 1, "REGIS: For $1 MILLION, attempt to destroy Prometheus and his bodyguard!!!");
   $double = true;
   $promieMillion = NewObject("PromieMillion", Herc, 29);
   $execguard = NewObject("ExecGuard", Herc, 28);
   setPilotId($promieMillion, 43);
   setPilotId($execguard, 45);
   setTeam($promieMillion, *IDSTR_TEAM_RED);
   setTeam($execguard, *IDSTR_TEAM_RED);
   randomTransport($promieMillion, -436.464, -407.849, 149.685, 247.432);
   randomTransport($execguard, -436.464, -407.849, 149.685, 247.432);
   $randomEnemy = randomInt(0,1);
   if($randomEnemy==0)
   {
      $enemy = $promieMillion;
   }
   else if($randomEnemy==1)
   {
      $enemy = $execguard;
   }
   order($promieMillion, attack, $hotseat);
   order($execguard, attack, $hotseat);
}

function HotseatChat()
{
   $HotseatChat = randomInt(0,2);
   if($HotseatChat==0)
   {
      say("Everybody", 1, "<F3>" @ $hotseatname @ ": Hmmm....I never really thought about that. I really don't know.");
      schedule("say(\"Everybody\", 1, \"REGIS: You never thought about what you're gonna do with a million dollars? Then what are you doing playing this game???\");",3);
      schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": *whistling*\", \"M6_Saxon_whistle.wav\");",5);      
   }
   else if($HotseatChat==1)
   {
      say("Everybody", 1, "<F3>" @ $hotseatname @ ": Well Regis, I'm going to give it all to charity.");
      schedule("say(\"Everybody\", 1, \"REGIS: Well, that's pretty generous of you...I'm sure it'll be helping a lot of people.\");",3);
      schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": Yep, it's going to the charity to buy me a brand new Ferrari!!!\");",5);
   }
   else if($HotseatChat==2)
   {
      say("Everybody", 1, "<F3>" @ $hotseatname @ ": Well, I was thinking about buying one of those New Volkswagon Beetles...");
      schedule("say(\"Everybody\", 1, \"REGIS: Sure, sounds great...\");",3);
      schedule("say(\"Everybody\", 1, \"REGIS: Whatever you want to do with your money...\");",5);      
   }
}

function RegisComment1()
{
   if(($seeker100destroyed==false)&&($askingAudience==false)&&($cloning==false)&&($doingFifty==false)&&($quietRegis==false))
   {
      $RegisComment1 = randomInt(0,1);
      if($RegisComment1==0)
      {
         say("Everybody", 1, "REGIS: Not too good at this, are you?");
      }
      else if($RegisComment1==1)
      {
         say("Everybody", 1, "REGIS: Hmmm....I figured you would have killed him faster than this.");
      }
   }
}

function RegisComment2()
{
   if(($goad1000destroyed==true)&&($goad10002destroyed==false)&&($askingAudience==false)&&($cloning==false)&&($doingFifty==false)&&($quietRegis==false))
   {
      say("Everybody", 1, "REGIS: Did you hear me? I said.....Is that your final answer?");
   }
   else if(($goad1000destroyed==false)&&($goad10002destroyed==true)&&($askingAudience==false)&&($cloning==false)&&($doingFifty==false)&&($quietRegis==false))
   {
      say("Everybody", 1, "REGIS: Did you hear me? I said.....Is that your final answer?");
   }
}

function RegisComment3()
{
   if(($eman2000destroyed==true)&&($eman20002destroyed==false)&&($askingAudience==false)&&($cloning==false)&&($doingFifty==false)&&($quietRegis==false))
   {
      say("Everybody", 1, "REGIS: Settle down audience....it's not as easy as it looks.");
   }
   else if(($eman2000destroyed==false)&&($eman20002destroyed==true)&&($askingAudience==false)&&($cloning==false)&&($doingFifty==false)&&($quietRegis==false))
   {
      say("Everybody", 1, "REGIS: Settle down audience....it's not as easy as it looks.");
   }
}

function walkaway::trigger::onEnter(%this, %object)
{
   if((%object==$hotseat)&&($pad==true))
   {
      say("Everybody", 1, "REGIS: " @ $hotseatname @ " is entering the \"Walk Away\" pad...");
      schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \", are you sure that you want to take your money and walk away?\");",3);
   }
}

function walkaway::trigger::onContact(%this, %object)
{
   if((%object==$hotseat)&&(isShutDown(%object)==true)&&($walkaway==false)&&($pad==true))
   {
      $walkaway = true; 
      $quietRegis = true;   
      healHotseat(); 
      schedule("say(\"Everybody\", 1, \"<F3>\" @ $hotseatname @ \": Yes!\");",4);
      schedule("redrop($hotseat);",5);
      schedule("healHotseat();",6);
      schedule("WalkAway();",7);
   }
}

function GameOver()
{
   $gameover = true;
   deleteAIs();
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   say("Everybody", 1, "REGIS: Well, I'm sorry it had to end this way, " @ $hotseatname @ "...");
   if(($goad1000destroyed==true)&&($goad10002destroyed==true)&&($judge32000destroyed==false))
   {
      %player.winnings = 10;
      schedule("say(\"Everybody\", 1, \"REGIS: But you did walk away with $1,000...\");",4);
   }
   else if($judge32000destroyed==true)
   {
      %player.winnings = 320;
      schedule("say(\"Everybody\", 1, \"REGIS: But you did walk away with $32,000...you gotta be happy about that!\");",4);
   }
   else
   {
      %player.winnings = 0;
      schedule("say(\"Everybody\", 1, \"REGIS: Sometimes this happens to our contestants....it was just bad luck I guess.\");",4);
   }
   schedule("EndGame();",7);
}

function forfiet()
{
   $gameover = true;
   deleteAIs();
   %player = playerManager::vehicleIdToPlayerNum($hotseat);
   say("Everybody", 1, "REGIS: I can't imagine why anyone would want to forfiet...");
   if(($goad1000destroyed==true)&&($goad10002destroyed==true)&&($judge32000destroyed==false))
   {
      %player.winnings = 10;
      schedule("say(\"Everybody\", 1, \"REGIS: ...but that means that he's only going home with $1,000...\");",3);
   }
   else if($judge32000destroyed==true)
   {
      %player.winnings = 320;
      schedule("say(\"Everybody\", 1, \"REGIS: ...but that means that he's only going home with $32,000...\");",3);
   }
   else
   {
      %player.winnings = 0;
      schedule("say(\"Everybody\", 1, \"REGIS: ...but since he didn't make it to any of the guaranteed levels, he will walk away empty-handed.\");",3);
   }
   schedule("EndGame();",6);
}

function WalkAway()
{
   $gameover = true;
   deleteAIs();
   $hotseatplayer = playerManager::vehicleIdToPlayerNum($hotseat);
   say("Everybody", 1, "REGIS: Okay then, there's definitely no shame in that...");
   schedule("say(\"Everybody\", 1, \"REGIS: \" @ $hotseatname @ \" is walking away with \" @ getWinnings($hotseatplayer) @ \"!\");",4);
   schedule("EndGame();", 9);   
}

function WinTheMillion()
{
   $gameover = true;
   deleteAIs();
   say("Everybody", 1, "REGIS: How does it feel to be a millionaire, " @ $hotseatname @ "?!??");
   $millionMessage = randomInt(0,2);
   if($millionMessage==0)
   {
      schedule("say(\"Everybody\", 1, \"<f3>\" @ $hotseatname @ \": I FEEL LIKE A MILLION BUCKS!!!\");",3);
      schedule("say(\"Everybody\", 1, \"REGIS: Oh, I bet you do!\");",6);
   }
   else if($millionMessage==1)
   {
      schedule("say(\"Everybody\", 1, \"<f3>\" @ $hotseatname @ \": I FEEL EXCELLENT!\", \"ee_pd35.WAV\");",3);
      schedule("say(\"Everybody\", 1, \"REGIS: Congratulations, \" @ $hotseatname @ \"!\");",6);
   }
   else if($millionMessage==2)
   {
      schedule("say(\"Everybody\", 1, \"<f3>\" @ $hotseatname @ \": WOOOOOOH!! AWESOME!!!\", \"M10_Jaguar_wooh.WAV\");",3);
      schedule("say(\"Everybody\", 1, \"REGIS: I'm glad you're excited...\");",6);
   }
   schedule("EndGame();",9);
}

function deleteAIs()
{
   deleteobject($fastgoad);
   deleteobject($seeker100);
   deleteobject($goad200);
   deleteobject($eman300);
   deleteobject($mino500);
   deleteobject($goad1000);
   deleteobject($goad10002);
   deleteobject($eman2000);
   deleteobject($eman20002);
   deleteobject($shep4000);
   deleteobject($basilisk8000);
   deleteobject($gorgon16000);
   deleteobject($judge32000);
   deleteobject($olympian64000);
   deleteobject($apoc125000);
   deleteobject($exec250000);
   deleteobject($exec500000);
   deleteobject($exec5000002);
   deleteobject($promieMillion);
   deleteobject($Clone);
}

function EndGame()
{
   deleteAIs();
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.record = getRecord(%player);
   }
   say("Everybody", 1, "REGIS: Now let's get ready for our next game...");
   schedule("say(\"Everybody\", 1, \"REGIS: Who will be the next contestant to make it to the hotseat? Stay tuned, we'll be right back after we take a short break!\");",4);
   schedule("missionEndConditionMet();",14);
}

function onMissionEnd()
{
   flushConsoleScheduler();
}

function getRecord(%player)
{
   return(%player.winnings + %player.money);
}

function getTotalMoney(%player)
{
   if((%player.winnings==0)&&(%player.money==0))
   {
      return("$" @ (%player.winnings + %player.money));
   }
   else
   {
      return("$" @ (%player.winnings + %player.money) @ "00");
   }
}

function getWinnings(%player)
{
   if(%player.winnings==0)
   {
      return("$" @ (%player.winnings));
   }
   else
   {
      return("$" @ (%player.winnings) @ "00");
   }
}

function getLifeLines(%player)
{
   return(%player.lifelines);
}

function getAudience(%player)
{
   return(%player.askaudience);
}

function getClone(%player)
{
   return(%player.clonefriend);
}

function getFifty(%player)
{
   return(%player.fiftyfifty);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
         $ScoreBoard::PlayerColumnHeader2 = "Total Winnings";
	   $ScoreBoard::PlayerColumnHeader3 = "Current Winnings";
         $ScoreBoard::PlayerColumnHeader4 = "Lifelines";
         $ScoreBoard::PlayerColumnHeader5 = "Ask The Audience";
	   $ScoreBoard::PlayerColumnHeader6 = "Clone A Friend";
	   $ScoreBoard::PlayerColumnHeader7 = "50/50";
         $ScoreBoard::PlayerColumnHeader8 = *IDMULT_SCORE_KILLS;
         
	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
         $ScoreBoard::PlayerColumnFunction2 = "getTotalMoney";
	   $ScoreBoard::PlayerColumnFunction3 = "getWinnings";
         $ScoreBoard::PlayerColumnFunction4 = "getLifeLines";
         $ScoreBoard::PlayerColumnFunction5 = "getAudience";
         $ScoreBoard::PlayerColumnFunction6 = "getClone";
         $ScoreBoard::PlayerColumnFunction7 = "getFifty";
         $ScoreBoard::PlayerColumnFunction8 = "getKills";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
         $ScoreBoard::PlayerColumnHeader2 = "Total Winnings";
	   $ScoreBoard::PlayerColumnHeader3 = "Current Winnings";
         $ScoreBoard::PlayerColumnHeader4 = "Lifelines";
         $ScoreBoard::PlayerColumnHeader5 = "Ask The Audience";
	   $ScoreBoard::PlayerColumnHeader6 = "Clone A Friend";
	   $ScoreBoard::PlayerColumnHeader7 = "50/50";
         $ScoreBoard::PlayerColumnHeader8 = *IDMULT_SCORE_KILLS;
         
	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
         $ScoreBoard::PlayerColumnFunction2 = "getTotalMoney";
	   $ScoreBoard::PlayerColumnFunction3 = "getWinnings";
         $ScoreBoard::PlayerColumnFunction4 = "getLifeLines";
         $ScoreBoard::PlayerColumnFunction5 = "getAudience";
         $ScoreBoard::PlayerColumnFunction6 = "getClone";
         $ScoreBoard::PlayerColumnFunction7 = "getFifty";
         $ScoreBoard::PlayerColumnFunction8 = "getKills";
	   
   }
   serverInitScoreBoard();
}

function setDefaultMissionItems()
{  
      allowVehicle(  all, TRUE  ); //All Vehicles
               
      allowWeapon(  all, TRUE  );   //Do Not Restrict Missiles (AI's use them)
      allowWeapon(  134, FALSE  );  //No Mines (6-pack)
      allowWeapon(  135, FALSE  );  //No Mines (10-pack)
      allowWeapon(  136, FALSE  );  //No Mines (15-pack)
      allowWeapon(  150, FALSE  );  //No Sguns

      allowComponent(  all, TRUE  );
}

Pilot FastGoad
{
   id = 28;
   name = "Fastest Shooter Goad";
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 1.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Seeker100
{
   id = 29;
   name = "$100 Seeker";
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 1.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Goad200
{
   id = 30;
   name = "$200 Goad";
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 1.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Eman300
{
   id = 31;
   name = "$300 Emancipator";
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 1.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Mino500
{
   id = 32;
   name = "$500 Minotaur";
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 1.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Goad1000
{
   id = 33;
   name = "$1,000 Goad";
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 1.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Eman2000
{
   id = 34;
   name = "$2,000 Emancipator";
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Shep4000
{
   id = 35;
   name = "$4,000 Shepherd";
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Basilisk8000
{
   id = 36;
   name = "$8,000 Basilisk";
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Gorgon16000
{
   id = 37;
   name = "$16,000 Gorgon";
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Judge32000
{
   id = 38;
   name = "$32,000 Adjudicator";
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Olympian64000
{
   id = 39;
   name = "$64,000 Olympian";
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 0.4;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Apoc125000
{
   id = 40;
   name = "$125,000 Apocalypse";
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 0.4;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Exec250000
{
   id = 41;
   name = "$250,000 Executioner";
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 0.4;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Exec500000
{
   id = 42;
   name = "$500,000 Executioner";
   skill = 2.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 0.4;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot PromieMillion
{
   id = 43;
   name = "$1,000,000 Prometheus";
   skill = 2.0;
   accuracy = 2.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 0.4;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot Clone
{
   id = 44;
   name = "Cloned Friend";
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 2.0;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot ExecGuard
{
   id = 45;
   name = "Prometheus's Bodyguard";
   skill = 2.0;
   accuracy = 2.0;
   aggressiveness = 2.0;
   activateDist = 850.0;
   deactivateBuff = 300.0;
   targetFreq = 0.4;
   trackFreq = 0.0;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};
