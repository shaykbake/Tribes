// FILENAME:	Artificial_Intelligence_01.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "Artificial_Intelligence_01";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}

Pilot Pilot1
{
   id = 28;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 800.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Pilot1";
};

Pilot Pilot2
{
   id = 29;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 800.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Pilot2";
};

Pilot Pilot3
{
   id = 30;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 800.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Pilot3";
};

Pilot Pilot4
{
   id = 31;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 800.0;
   deactivateBuff = 100.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "Pilot4";
};

// move the map
$server::HudMapViewOffsetX = -1500;
$server::HudMapViewOffsetY = 2500;

function onMissionStart()
{
      temperateSounds();
      $droppedAIs = false;
      $dontsayhi = true;
      $path1 = getobjectId("MissionGroup\\Paths\\Path1");
      $path2 = getobjectId("MissionGroup\\Paths\\Path2");
      $path3 = getobjectId("MissionGroup\\Paths\\Path3");
      $path4 = getobjectId("MissionGroup\\Paths\\Path4");
      $path5 = getobjectId("MissionGroup\\Paths\\Path5");
      $path6 = getobjectId("MissionGroup\\Paths\\Path6");
      $path7 = getobjectId("MissionGroup\\Paths\\Path7");
      $path8 = getobjectId("MissionGroup\\Paths\\Path8");
      $path9 = getobjectId("MissionGroup\\Paths\\Path9");
      $path10 = getobjectId("MissionGroup\\Paths\\Path10");
      $pad1 = getobjectId("MissionGroup\\Paths\\Pad1");
      $pad2 = getobjectId("MissionGroup\\Paths\\Pad2");
      $pad3 = getobjectId("MissionGroup\\Paths\\Pad3");
      $pad4 = getobjectId("MissionGroup\\Paths\\Pad4");
}

function onMissionLoad()
{
   cdAudioCycle("Terror","Cloudburst","Mechsoul","Cyberntx","Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  DeathMatch\n\n<F2>MISSION:<F0>  Artificial Intelligence 01\n\nWelcome to Artificial Intelligence DeathMatch! Prepare to fight realistic & intelligent AI pilots. They patrol, talk, use heal pads, change vehicles, & interact with other players. You can download Artificial_Intelligence_01 & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player,0, "Welcome to Artificial Intelligence DeathMatch! Prepare to fight realistic & intelligent AI pilots. They patrol, talk, use heal pads, change vehicles, & interact with other players. You can download Artificial_Intelligence_01 & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   if($dontsayhi==false)
   {
      %random = randomInt(1,4);
      if(%random==1)
      {
         schedule("say(0,1,\"<f3>\" @ $AI1name @ \": hi\");",4);
      }
      else if(%random==2)
      {
         schedule("say(0,1,\"<f3>\" @ $AI2name @ \": hey\");",4);
      }
      else if(%random==3)
      {
         schedule("say(0,1,\"<f3>\" @ $AI3name @ \": hello\");",4);
      }
      else if(%random==4)
      {
         schedule("say(0,1,\"<f3>\" @ $AI4name @ \": hey, what's up?\");",4);
      }
   }
}

function player::onRemove(%player)
{
   if($dontsayhi==false)
   {
      %randomcya = randomInt(1,4);
      if(%randomcya==1)
      {
         say(0,1,"<f3>" @ $AI1name @ ": cya");
      }
      else if(%randomcya==2)
      {
         say(0,1,"<f3>" @ $AI2name @ ": bye");
      }
      else if(%randomcya==3)
      {
         say(0,1,"<f3>" @ $AI3name @ ": l8r");
      }
      else if(%randomcya==4)
      {
         say(0,1,"<f3>" @ $AI4name @ ": cya later");
      }
   }
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   if($droppedAIs==false)
   {
      $droppedAIs = true;
      schedule("$dontsayhi=false;",9);
      schedule("dropAI1();",2);
      schedule("dropAI2();",4);
      schedule("dropAI3();",6);
      schedule("dropAI4();",8);
   }
}

function dropAI1()
{
   %randomId = randomint(1,33);
   // Replace unwanted AIs with better ones
   if(%randomId==6)
   {
      %randomId = 33;
   }
   else if(%randomId==9)
   {
      %randomId = 3;
   }
   else if(%randomId==12)
   {
      %randomId = 3;
   }
   else if(%randomId==14)
   {
      %randomId = 33;
   }
   else if(%randomId==18)
   {
      %randomId = 1;
   }
   else if(%randomId==19)
   {
      %randomId = 28;
   }
   else if(%randomId==24)
   {
      %randomId = 28;
   }
   else if(%randomId==29)
   {
      %randomId = 41;
   }
   // Determine if its a herc or tank
   %type = Herc;
   if((%randomId > 5) && (%randomId <= 8))
   {
      %type = Tank;
   }
   else if((%randomId > 14) && (%randomId <= 17))
   {
      %type = Tank;
   }
   else if((%randomId > 24) && (%randomId <= 26))
   {
      %type = Tank;
   }
   else if((%randomId > 30) && (%randomId <= 32))
   {
      %type = Tank;
   }
   else if(%randomId ==41)
   {
      %type = Tank;
   }
   $AI1 = newObject("AI 1",%type,%randomId);
   Pilot1.name = getVehicleName($AI1);
   $AI1name = getVehicleName($AI1);
   setPilotId($AI1,28);
   $AI1.vehType = %type;
   setTeam($AI1,*IDSTR_TEAM_RED);
   if($server::teamplay==true)
   {
      setTeam($AI1,*IDSTR_TEAM_YELLOW);
   }
   redrop($AI1);
   $AI1.weaponcount = getWeaponCount($AI1);
   order($AI1,cloak,true);
   %randomPath = randomInt(1,10);
   if(%randomPath==1)
   {
      order($AI1,guard,$path1);
      order($AI1,speed,high);
   }
   else if(%randomPath==2)
   {
      order($AI1,guard,$path2);
      order($AI1,speed,high);
   }
   else if(%randomPath==3)
   {
      order($AI1,guard,$path3);
      order($AI1,speed,high);
   }
   else if(%randomPath==4)
   {
      order($AI1,guard,$path4);
      order($AI1,speed,high);
   }
   else if(%randomPath==5)
   {
      order($AI1,guard,$path5);
      order($AI1,speed,high);
   }
   else if(%randomPath==6)
   {
      order($AI1,guard,$path6);
      order($AI1,speed,high);
   }
   else if(%randomPath==7)
   {
      order($AI1,guard,$path7);
      order($AI1,speed,high);
   }
   else if(%randomPath==8)
   {
      order($AI1,guard,$path8);
      order($AI1,speed,high);
   }
   else if(%randomPath==9)
   {
      order($AI1,guard,$path9);
      order($AI1,speed,high);
   }
   else if(%randomPath==10)
   {
      order($AI1,guard,$path10);
      order($AI1,speed,high);
   }
}

function dropAI2()
{
   %randomId = randomint(1,33);
   // Replace unwanted AIs with better ones
   if(%randomId==6)
   {
      %randomId = 33;
   }
   else if(%randomId==9)
   {
      %randomId = 3;
   }
   else if(%randomId==12)
   {
      %randomId = 3;
   }
   else if(%randomId==14)
   {
      %randomId = 33;
   }
   else if(%randomId==18)
   {
      %randomId = 1;
   }
   else if(%randomId==19)
   {
      %randomId = 28;
   }
   else if(%randomId==24)
   {
      %randomId = 28;
   }
   else if(%randomId==29)
   {
      %randomId = 41;
   }
   // Determine if its a herc or tank
   %type = Herc;
   if((%randomId > 5) && (%randomId <= 8))
   {
      %type = Tank;
   }
   else if((%randomId > 14) && (%randomId <= 17))
   {
      %type = Tank;
   }
   else if((%randomId > 24) && (%randomId <= 26))
   {
      %type = Tank;
   }
   else if((%randomId > 30) && (%randomId <= 32))
   {
      %type = Tank;
   }
   else if(%randomId ==41)
   {
      %type = Tank;
   }
   $AI2 = newObject("AI 2",%type,%randomId);
   Pilot2.name = getVehicleName($AI2);
   $AI2name = getVehicleName($AI2);
   setPilotId($AI2,29);
   $AI2.vehType = %type;
   setTeam($AI2,*IDSTR_TEAM_RED);
   if($server::teamplay==true)
   {
      setTeam($AI2,*IDSTR_TEAM_BLUE);
   }
   redrop($AI2);
   $AI2.weaponcount = getWeaponCount($AI2);
   order($AI2,cloak,true);
   %randomPath = randomInt(1,10);
   if(%randomPath==1)
   {
      order($AI2,guard,$path1);
      order($AI2,speed,high);
   }
   else if(%randomPath==2)
   {
      order($AI2,guard,$path2);
      order($AI2,speed,high);
   }
   else if(%randomPath==3)
   {
      order($AI2,guard,$path3);
      order($AI2,speed,high);
   }
   else if(%randomPath==4)
   {
      order($AI2,guard,$path4);
      order($AI2,speed,high);
   }
   else if(%randomPath==5)
   {
      order($AI2,guard,$path5);
      order($AI2,speed,high);
   }
   else if(%randomPath==6)
   {
      order($AI2,guard,$path6);
      order($AI2,speed,high);
   }
   else if(%randomPath==7)
   {
      order($AI2,guard,$path7);
      order($AI2,speed,high);
   }
   else if(%randomPath==8)
   {
      order($AI2,guard,$path8);
      order($AI2,speed,high);
   }
   else if(%randomPath==9)
   {
      order($AI2,guard,$path9);
      order($AI2,speed,high);
   }
   else if(%randomPath==10)
   {
      order($AI2,guard,$path10);
      order($AI2,speed,high);
   }
}

function dropAI3()
{
   %randomId = randomint(1,33);
   // Replace unwanted AIs with better ones
   if(%randomId==6)
   {
      %randomId = 33;
   }
   else if(%randomId==9)
   {
      %randomId = 3;
   }
   else if(%randomId==12)
   {
      %randomId = 3;
   }
   else if(%randomId==14)
   {
      %randomId = 33;
   }
   else if(%randomId==18)
   {
      %randomId = 1;
   }
   else if(%randomId==19)
   {
      %randomId = 28;
   }
   else if(%randomId==24)
   {
      %randomId = 28;
   }
   else if(%randomId==29)
   {
      %randomId = 41;
   }
   // Determine if its a herc or tank
   %type = Herc;
   if((%randomId > 5) && (%randomId <= 8))
   {
      %type = Tank;
   }
   else if((%randomId > 14) && (%randomId <= 17))
   {
      %type = Tank;
   }
   else if((%randomId > 24) && (%randomId <= 26))
   {
      %type = Tank;
   }
   else if((%randomId > 30) && (%randomId <= 32))
   {
      %type = Tank;
   }
   else if(%randomId ==41)
   {
      %type = Tank;
   }
   $AI3 = newObject("AI 3",%type,%randomId);
   Pilot3.name = getVehicleName($AI3);
   $AI3name = getVehicleName($AI3);
   setPilotId($AI3,30);
   $AI3.vehType = %type;
   setTeam($AI3,*IDSTR_TEAM_RED);
   if($server::teamplay==true)
   {
      setTeam($AI3,*IDSTR_TEAM_RED);
   }
   redrop($AI3);
   $AI3.weaponcount = getWeaponCount($AI3);
   order($AI3,cloak,true);
   %randomPath = randomInt(1,10);
   if(%randomPath==1)
   {
      order($AI3,guard,$path1);
      order($AI3,speed,high);
   }
   else if(%randomPath==2)
   {
      order($AI3,guard,$path2);
      order($AI3,speed,high);
   }
   else if(%randomPath==3)
   {
      order($AI3,guard,$path3);
      order($AI3,speed,high);
   }
   else if(%randomPath==4)
   {
      order($AI3,guard,$path4);
      order($AI3,speed,high);
   }
   else if(%randomPath==5)
   {
      order($AI3,guard,$path5);
      order($AI3,speed,high);
   }
   else if(%randomPath==6)
   {
      order($AI3,guard,$path6);
      order($AI3,speed,high);
   }
   else if(%randomPath==7)
   {
      order($AI3,guard,$path7);
      order($AI3,speed,high);
   }
   else if(%randomPath==8)
   {
      order($AI3,guard,$path8);
      order($AI3,speed,high);
   }
   else if(%randomPath==9)
   {
      order($AI3,guard,$path9);
      order($AI3,speed,high);
   }
   else if(%randomPath==10)
   {
      order($AI3,guard,$path10);
      order($AI3,speed,high);
   }
}

function dropAI4()
{
   %randomId = randomint(1,33);
   // Replace unwanted AIs with better ones
   if(%randomId==6)
   {
      %randomId = 33;
   }
   else if(%randomId==9)
   {
      %randomId = 3;
   }
   else if(%randomId==12)
   {
      %randomId = 3;
   }
   else if(%randomId==14)
   {
      %randomId = 33;
   }
   else if(%randomId==18)
   {
      %randomId = 1;
   }
   else if(%randomId==19)
   {
      %randomId = 28;
   }
   else if(%randomId==24)
   {
      %randomId = 28;
   }
   else if(%randomId==29)
   {
      %randomId = 41;
   }
   // Determine if its a herc or tank
   %type = Herc;
   if((%randomId > 5) && (%randomId <= 8))
   {
      %type = Tank;
   }
   else if((%randomId > 14) && (%randomId <= 17))
   {
      %type = Tank;
   }
   else if((%randomId > 24) && (%randomId <= 26))
   {
      %type = Tank;
   }
   else if((%randomId > 30) && (%randomId <= 32))
   {
      %type = Tank;
   }
   else if(%randomId ==41)
   {
      %type = Tank;
   }
   $AI4 = newObject("AI 4",%type,%randomId);
   Pilot4.name = getVehicleName($AI4);
   $AI4name = getVehicleName($AI4);
   setPilotId($AI4,31);
   $AI4.vehType = %type;
   setTeam($AI4,*IDSTR_TEAM_RED);
   if($server::teamplay==true)
   {
      setTeam($AI4,*IDSTR_TEAM_PURPLE);
   }
   redrop($AI4);
   $AI4.weaponcount = getWeaponCount($AI4);
   order($AI4,cloak,true);
   %randomPath = randomInt(1,14);
   if(%randomPath==1)
   {
      order($AI4,guard,$path1);
      order($AI4,speed,high);
   }
   else if(%randomPath==2)
   {
      order($AI4,guard,$path2);
      order($AI4,speed,high);
   }
   else if(%randomPath==3)
   {
      order($AI4,guard,$path3);
      order($AI4,speed,high);
   }
   else if(%randomPath==4)
   {
      order($AI4,guard,$path4);
      order($AI4,speed,high);
   }
   else if(%randomPath==5)
   {
      order($AI4,guard,$path5);
      order($AI4,speed,high);
   }
   else if(%randomPath==6)
   {
      order($AI4,guard,$path6);
      order($AI4,speed,high);
   }
   else if(%randomPath==7)
   {
      order($AI4,guard,$path7);
      order($AI4,speed,high);
   }
   else if(%randomPath==8)
   {
      order($AI4,guard,$path8);
      order($AI4,speed,high);
   }
   else if(%randomPath==9)
   {
      order($AI4,guard,$path9);
      order($AI4,speed,high);
   }
   else if(%randomPath==10)
   {
      order($AI4,guard,$path10);
      order($AI4,speed,high);
   }
}

function vehicle::onarrived(%this,%where)
{
   randomChat(%this);
   reloadObject(%this,500);
   order(%this,cloak,true);
   if((%where!=$pad1) && (%where!=$pad2) && (%where!=$pad3) && (%where!=$pad4))
   {
      %randomPath = randomInt(1,14);
      if(%randomPath==1)
      {
         order(%this,guard,$path1);
         order(%this,speed,high);
      }
      else if(%randomPath==2)
      {
         order(%this,guard,$path2);
         order(%this,speed,high);
      }
      else if(%randomPath==3)
      {
         order(%this,guard,$path3);
         order(%this,speed,high);
      }
      else if(%randomPath==4)
      {
         order(%this,guard,$path4);
         order(%this,speed,high);
      }
      else if(%randomPath==5)
      {
         order(%this,guard,$path5);
         order(%this,speed,high);
      }
      else if(%randomPath==6)
      {
         order(%this,guard,$path6);
         order(%this,speed,high);
      }
      else if(%randomPath==7)
      {
         order(%this,guard,$path7);
         order(%this,speed,high);
      }
      else if(%randomPath==8)
      {
         order(%this,guard,$path8);
         order(%this,speed,high);
      }
      else if(%randomPath==9)
      {
         order(%this,guard,$path9);
         order(%this,speed,high);
      }
      else if(%randomPath==10)
      {
         order(%this,guard,$path10);
         order(%this,speed,high);
      }
      else if(%randomPath==11)
      {
         order(%this,guard,$pad1);
         order(%this,speed,high);
      }
      else if(%randomPath==12)
      {
         order(%this,guard,$pad2);
         order(%this,speed,high);
      }
      else if(%randomPath==13)
      {
         order(%this,guard,$pad3);
         order(%this,speed,high);
      }
      else if(%randomPath==14)
      {
         order(%this,guard,$pad4);
         order(%this,speed,high);
      }
      %currentWeaponCount = getWeaponCount(%this);      
      if(%currentweaponcount < %this.weaponcount)
      {
         %distance1 = getdistance(%this,$pad1);
         %distance2 = getdistance(%this,$pad2);
         %distance3 = getdistance(%this,$pad3);
         %distance4 = getdistance(%this,$pad4);
         %distance = %distance1;
         %pad = $pad1;
         if(%distance2 < %distance)
         {
            %distance = %distance2;
            %pad = $pad2;
         }
         if(%distance3 < %distance)
         {
            %distance = %distance3;
            %pad = $pad3;
         }
         if(%distance4 < %distance)
         {
            %distance = %distance4;
            %pad = $pad4;
         }
         order(%this,guard,%pad);
         order(%this,speed,high);
      }
   }
   else
   {
      order(%this,clear);
      order(%this,shutdown,true);
      schedule("order("@%this@",shutdown,false);",15);
      schedule("order("@%this@",cloak,true);",20);
      %randomPath = randomInt(1,10);
      if(%randomPath==1)
      {
         schedule("order("@%this@",guard,$path1);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==2)
      {
         schedule("order("@%this@",guard,$path2);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==3)
      {
         schedule("order("@%this@",guard,$path3);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==4)
      {
         schedule("order("@%this@",guard,$path4);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==5)
      {
         schedule("order("@%this@",guard,$path5);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==6)
      {
         schedule("order("@%this@",guard,$path6);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==7)
      {
         schedule("order("@%this@",guard,$path7);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==8)
      {
         schedule("order("@%this@",guard,$path8);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==9)
      {
         schedule("order("@%this@",guard,$path9);",16);
         schedule("order("@%this@",speed,high);",16);
      }
      else if(%randomPath==10)
      {
         schedule("order("@%this@",guard,$path10);",16);
         schedule("order("@%this@",speed,high);",16);
      }
   }
}

function randomChat(%this)
{
   %chat = randomInt(1,75);
   if(%chat==1)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": where is everyone?");
   }
   else if(%chat==2)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": lag");
   }
   else if(%chat==3)
   {
      say(0,1, "<F5>" @ getVehicleName(%this) @ ": *whistle*","M6_Saxon_whistle.WAV");
   }
   else if(%chat==4)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": i love these MIB maps");
   }
   else if(%chat==5)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": need ammo");
   }
   else if(%chat==6)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": anyone wanna duel?");
   }
   else if(%chat==7)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": who's got missles?");
   }
   else if(%chat==8)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": wtf");
   }
   else if(%chat==9)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": anyone want this setup?");
   }
   else if(%chat==10)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": cool");
   }
   else if(%chat==11)
   {
      %randomtext = randomInt(1,4);
      if(%randomtext==1)
      {
         %text = "apoc";
      }
      else if(%randomtext==2)
      {
         %text = "exec";
      }
      else if(%randomtext==3)
      {
         %text = "oly";
      }
      else if(%randomtext==4)
      {
         %text = "gorgon";
      }
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": anyone got a good "@%text@" setup?");
   }
   else if(%chat==12)
   {
      say(0,1, "<F5>" @ getVehicleName(%this) @ ": I found my thrill on blueberry hill.","M6_Saxon_ifoundmy.WAV");
   }
   else if(%chat==13)
   {  
      %randomtext = randomInt(1,4);
      if(%randomtext==1)
      {
         %text = "make pads work?";
      }
      else if(%randomtext==2)
      {
         %text = "make AI respawn?";
      }
      else if(%randomtext==3)
      {
         %text = "script?";
      }
      else if(%randomtext==4)
      {
         %text = "enable the console?";
      }
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": does anyone here know how to " @ %text);
   }
   else if(%chat==14)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": huh?");
   }
   else if(%chat==15)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": is anyone else laggin?");
   }
   else if(%chat==16)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": this thing's an energy hog");
   }
   else if(%chat==17)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": stupid moues!");
      schedule("say(0,1,\"<f3>\" @ getVehicleName("@%this@") @ \": mouse*\");",2);
   }
   else if(%chat==18)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": i need a faster PC");
   }
   else if(%chat==19)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": im gonna get cable soon :)");
   }
   else 
   {
      morechat(%this, %chat);
   }
}

function morechat(%this,%chat)
{
   if(%chat==20)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": hehe");
   }
   else if(%chat==21)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": lol");
   }
   else if(%chat==22)
   {
      say(0,1, "<F5>" @ getVehicleName(%this) @ ": Eliminate human//animals.","C4_eliminateanimals.WAV");
   }
   else if(%chat==23)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": hehe");
   }
   else if(%chat==24)
   {
      say(0,1, "<F3>" @ getVehicleName(%this) @ ": lol");
   }
   else if(%chat==25)
   {
      say(0,1, "<F5>" @ getVehicleName(%this) @ ": Bring it on!","F4_Tiger_bringiton.WAV");
   }
}

function vehicle::ondestroyed(%destroyed,%destroyer)
{
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed)==getTeam(%destroyer)) && (%destroyed!=%destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }
   if(%destroyed==$AI1)
   {
      %spawntime = randomInt(7,20);
      schedule("dropAI1();",%spawntime);
      schedule("deleteobject($AI1);",%spawntime-3);
      if(%spawntime >= 15)
      {
         %deathChat = randomInt(1,15);
         if(%deathchat==1)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": gf\");",3);
         }
         else if(%deathchat==2)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": gf\");",3);
         }
         else if(%deathchat==3)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": i gotta get a better config\");",3);
         }
         else if(%deathchat==4)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI1) @ \": Niiiceone!\",\"M7_niiiceone.WAV\");",3);
         }
         else if(%deathchat==5)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": dang\");",3);
         }
         else if((%deathchat==6) && ($AI1.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": scap blew\");",3);
         }
         else if(%deathchat==7)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": whatcha got on that thing?\");",3);
         }
         else if(%deathchat==8)
         {
            %randomtext = randomInt(1,4);
            if(%randomtext==1)
            {
               $text1 = "got disconnected";
            }
            else if(%randomtext==2)
            {
               $text1 = "got kicked";
            }
            else if(%randomtext==3)
            {
               $text1 = "lagged out";
            }
            else if(%randomtext==4)
            {
               $text1 = "ss crashed";
            }
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI1) @ \" left the game.\");",1);
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI1) @ \" joined the game.\");",4);
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": \" @ $text1 );",8);
         }
         else if(%deathchat==9)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": testin new setups...\");",3);
         }
         else if(%deathchat==10)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": vgf\");",3);
         }
         else if(%deathchat==11)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": awwww :(\");",3);
         }
         else if((%deathchat==12) && ($AI1.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": forgot to focus shields :(\");",3);
         }
         else if(%deathchat==13)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": ouch...gf\");",3);
         }
         else if(%deathchat==14)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI1) @ \": nice shot\");",3);
         }
         else if((%deathchat==15) && ($AI1.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName$AI1) @ \": dang scap\");",3);
         }
         else if(%deathchat==16)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI1) @ \": AAAAAAHHHH!!!!\",\"GEN_DTH05.WAV\");",3);
         }
      }
   }
   else if(%destroyed==$AI2)
   {
      %spawntime = randomInt(7,20);
      schedule("dropAI2();",%spawntime);
      schedule("deleteobject($AI2);",%spawntime-3);
      if(%spawntime >= 15)
      {
         %deathChat = randomInt(1,15);
         if(%deathchat==1)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": gf\");",3);
         }
         else if(%deathchat==2)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": gf\");",3);
         }
         else if(%deathchat==3)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": i gotta get a better config\");",3);
         }
         else if(%deathchat==4)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI2) @ \": Niiiceone!\",\"M7_niiiceone.WAV\");",3);
         }
         else if(%deathchat==5)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": dang\");",3);
         }
         else if((%deathchat==6) && ($AI2.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": scap blew\");",3);
         }
         else if(%deathchat==7)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": whatcha got on that thing?\");",3);
         }
         else if(%deathchat==8)
         {
            %randomtext = randomInt(1,4);
            if(%randomtext==1)
            {
               $text2 = "got disconnected";
            }
            else if(%randomtext==2)
            {
               $text2 = "got kicked";
            }
            else if(%randomtext==3)
            {
               $text2 = "lagged out";
            }
            else if(%randomtext==4)
            {
               $text2 = "ss crashed";
            }
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI2) @ \" left the game.\");",1);
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI2) @ \" joined the game.\");",4);
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": \" @ $text2 );",8);
         }
         else if(%deathchat==9)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": testin new setups...\");",3);
         }
         else if(%deathchat==10)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": vgf\");",3);
         }
         else if(%deathchat==11)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": awwww :(\");",3);
         }
         else if((%deathchat==12) && ($AI2.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": forgot to focus shields :(\");",3);
         }
         else if(%deathchat==13)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": ouch...gf\");",3);
         }
         else if(%deathchat==14)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": nice shot\");",3);
         }
         else if((%deathchat==15) && ($AI2.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI2) @ \": dang scap\");",3);
         }
         else if(%deathchat==16)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI2) @ \": AAAAAAHHHH!!!!\",\"GEN_DTH05.WAV\");",3);
         }
      }
   }
   else if(%destroyed==$AI3)
   {
      %spawntime = randomInt(7,20);
      schedule("dropAI3();",%spawntime);
      schedule("deleteobject($AI3);",%spawntime-3);
      if(%spawntime >= 15)
      {
         %deathChat = randomInt(1,15);
         if(%deathchat==1)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": gf\");",3);
         }
         else if(%deathchat==2)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": gf\");",3);
         }
         else if(%deathchat==3)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": i gotta get a better config\");",3);
         }
         else if(%deathchat==4)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI3) @ \": Niiiceone!\",\"M7_niiiceone.WAV\");",3);
         }
         else if(%deathchat==5)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": dang\");",3);
         }
         else if((%deathchat==6) && ($AI3.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": scap blew\");",3);
         }
         else if(%deathchat==7)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": whatcha got on that thing?\");",3);
         }
         else if(%deathchat==8)
         {
            %randomtext = randomInt(1,4);
            if(%randomtext==1)
            {
               $text3 = "got disconnected";
            }
            else if(%randomtext==2)
            {
               $text3 = "got kicked";
            }
            else if(%randomtext==3)
            {
               $text3 = "lagged out";
            }
            else if(%randomtext==4)
            {
               $text3 = "ss crashed";
            }
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI3) @ \" left the game.\");",1);
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI3) @ \" joined the game.\");",4);
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": \" @ $text3 );",8);
         }
         else if(%deathchat==9)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": testin new setups...\");",3);
         }
         else if(%deathchat==10)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": vgf\");",3);
         }
         else if(%deathchat==11)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": awwww :(\");",3);
         }
         else if((%deathchat==12) && ($AI3.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": forgot to focus shields :(\");",3);
         }
         else if(%deathchat==13)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": ouch...gf\");",3);
         }
         else if(%deathchat==14)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": nice shot\");",3);
         }
         else if((%deathchat==15) && ($AI3.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI3) @ \": dang scap\");",3);
         }
         else if(%deathchat==16)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI3) @ \": AAAAAAHHHH!!!!\",\"GEN_DTH05.WAV\");",3);
         }
      }
   }
   else if(%destroyed==$AI4)
   {
      %spawntime = randomInt(7,20);
      schedule("dropAI4();",%spawntime);
      schedule("deleteobject($AI4);",%spawntime-3);
      if(%spawntime >= 15)
      {
         %deathChat = randomInt(1,15);
         if(%deathchat==1)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": gf\");",3);
         }
         else if(%deathchat==2)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": gf\");",3);
         }
         else if(%deathchat==3)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": i gotta get a better config\");",3);
         }
         else if(%deathchat==4)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI4) @ \": Niiiceone!\",\"M7_niiiceone.WAV\");",3);
         }
         else if(%deathchat==5)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": dang\");",3);
         }
         else if((%deathchat==6) && ($AI4.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": scap blew\");",3);
         }
         else if(%deathchat==7)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": whatcha got on that thing?\");",3);
         }
         else if(%deathchat==8)
         {
            %randomtext = randomInt(1,4);
            if(%randomtext==1)
            {
               $text4 = "got disconnected";
            }
            else if(%randomtext==2)
            {
               $text4 = "got kicked";
            }
            else if(%randomtext==3)
            {
               $text4 = "lagged out";
            }
            else if(%randomtext==4)
            {
               $text4 = "ss crashed";
            }
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI4) @ \" left the game.\");",1);
            schedule("say(0,1,\"<f4>\" @ getvehicleName($AI4) @ \" joined the game.\");",4);
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": \" @ $text4 );",8);
         }
         else if(%deathchat==9)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": testin new setups...\");",3);
         }
         else if(%deathchat==10)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": vgf\");",3);
         }
         else if(%deathchat==11)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": awwww :(\");",3);
         }
         else if((%deathchat==12) && ($AI4.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": forgot to focus shields :(\");",3);
         }
         else if(%deathchat==13)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": ouch...gf\");",3);
         }
         else if(%deathchat==14)
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": nice shot\");",3);
         }
         else if((%deathchat==15) && ($AI4.vehType==Herc))
         {
            schedule("say(0,1,\"<f3>\" @ getvehicleName($AI4) @ \": dang scap\");",3);
         }
         else if(%deathchat==16)
         {
            schedule("say(0,1,\"<f5>\" @ getvehicleName($AI4) @ \": AAAAAAHHHH!!!!\",\"GEN_DTH05.WAV\");",3);
         }
      }      
   }
   if(%destroyer==$AI1)
   {
      schedule("AI1killchat("@%destroyer@");",4);
   }
   else if(%destroyer==$AI2)
   {
      schedule("AI2killchat("@%destroyer@");",4);
   }
   else if(%destroyer==$AI3)
   {
      schedule("AI3killchat("@%destroyer@");",4);
   }
   else if(%destroyer==$AI4)
   {
      schedule("AI4killchat("@%destroyer@");",4);
   }
}

function AI1killchat(%destroyer)
{
   %currentWeaponCount = getWeaponCount(%destroyer);      
   if(%currentweaponcount < %destroyer.weaponcount)
   {
      %distance1 = getdistance(%destroyer,$pad1);
      %distance2 = getdistance(%destroyer,$pad2);
      %distance3 = getdistance(%destroyer,$pad3);
      %distance4 = getdistance(%destroyer,$pad4);
      %distance = %distance1;
      %pad = $pad1;
      if(%distance2 < %distance)
      {
         %distance = %distance2;
         %pad = $pad2;
      }
      if(%distance3 < %distance)
      {
         %distance = %distance3;
         %pad = $pad3;
      }
      if(%distance4 < %distance)
      {
         %distance = %distance4;
         %pad = $pad4;
      }
      order(%destroyer,guard,%pad);
      order(%destroyer,speed,high);
   }
   %randomtalk = randomInt(1,48);
   if(%randomtalk==1)
   {
      say(0,1,"<f3>" @ getVehicleName($AI1) @ ": gf");
   }
   else if(%randomtalk==2)
   {
      say(0,1,"<f3>" @ getVehicleName($AI1) @ ": gf");
   }
   else if(%randomtalk==3)
   {
      say(0,1,"<f3>" @ getVehicleName($AI1) @ ": cool, i actually killed someone!");
   }
   else if(%randomtalk==4)
   {
      say(0,1,"<f3>" @ getVehicleName($AI1) @ ": u need better protection");
   }
   else if(%randomtalk==5)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Target eliminated.","C3_targeteliminated.WAV");
   }
   else if(%randomtalk==6)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Target executed.","C7_targetexec.WAV");
   }
   else if(%randomtalk==7)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Hahaa...Music to my ears!","M6_Saxon_musictomyears.WAV");
   }
   else if(%randomtalk==8)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Success is the sole judge of right and wrong.","C2_success.WAV");
   }
   else if(%randomtalk==9)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Happiness is a bunch of smokin human steaks.","ee_pd43.WAV");
   }
   else if(%randomtalk==10)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Bring it on!","F4_Tiger_bringiton.WAV");
   }
   else if(%randomtalk==11)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Huh. Seem to have destroyed you. Sorry.","ee_pd36.WAV");
   }
   else if(%randomtalk==12)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Hurts real bad don't it?","F2_DM_hurtsrealbad.wav");
   }
   else if(%randomtalk==13)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": I'm really sorry about that.","ee_pd20.WAV");
   }
   else if(%randomtalk==14)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Human//animals are fascinating.","C5_humansfascin.WAV");
   }
   else if(%randomtalk==15)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Excellent//efficient.","C7_excellent.WAV");
   }
   else if(%randomtalk==16)
   {
      say(0,1,"<f5>" @ getVehicleName($AI1) @ ": Yeah! Boom-baby-boom! hahah.","M6_Saxon_yeahboom.WAV");
   }
}

function AI2killchat(%destroyer)
{
   %currentWeaponCount = getWeaponCount(%destroyer);      
   if(%currentweaponcount < %destroyer.weaponcount)
   {
      %distance1 = getdistance(%destroyer,$pad1);
      %distance2 = getdistance(%destroyer,$pad2);
      %distance3 = getdistance(%destroyer,$pad3);
      %distance4 = getdistance(%destroyer,$pad4);
      %distance = %distance1;
      %pad = $pad1;
      if(%distance2 < %distance)
      {
         %distance = %distance2;
         %pad = $pad2;
      }
      if(%distance3 < %distance)
      {
         %distance = %distance3;
         %pad = $pad3;
      }
      if(%distance4 < %distance)
      {
         %distance = %distance4;
         %pad = $pad4;
      }
      order(%destroyer,guard,%pad);
      order(%destroyer,speed,high);
   }
   %randomtalk = randomInt(1,48);
   if(%randomtalk==1)
   {
      say(0,1,"<f3>" @ getVehicleName($AI2) @ ": gf");
   }
   else if(%randomtalk==2)
   {
      say(0,1,"<f3>" @ getVehicleName($AI2) @ ": gf");
   }
   else if(%randomtalk==3)
   {
      say(0,1,"<f3>" @ getVehicleName($AI2) @ ": cool, i actually killed someone!");
   }
   else if(%randomtalk==4)
   {
      say(0,1,"<f3>" @ getVehicleName($AI2) @ ": u need better protection");
   }
   else if(%randomtalk==5)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Target eliminated.","C3_targeteliminated.WAV");
   }
   else if(%randomtalk==6)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Target executed.","C7_targetexec.WAV");
   }
   else if(%randomtalk==7)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Hahaa...Music to my ears!","M6_Saxon_musictomyears.WAV");
   }
   else if(%randomtalk==8)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Success is the sole judge of right and wrong.","C2_success.WAV");
   }
   else if(%randomtalk==9)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Happiness is a bunch of smokin human steaks.","ee_pd43.WAV");
   }
   else if(%randomtalk==10)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Bring it on!","F4_Tiger_bringiton.WAV");
   }
   else if(%randomtalk==11)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Huh. Seem to have destroyed you. Sorry.","ee_pd36.WAV");
   }
   else if(%randomtalk==12)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Hurts real bad don't it?","F2_DM_hurtsrealbad.wav");
   }
   else if(%randomtalk==13)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": I'm really sorry about that.","ee_pd20.WAV");
   }
   else if(%randomtalk==14)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Human//animals are fascinating.","C5_humansfascin.WAV");
   }
   else if(%randomtalk==15)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Excellent//efficient.","C7_excellent.WAV");
   }
   else if(%randomtalk==16)
   {
      say(0,1,"<f5>" @ getVehicleName($AI2) @ ": Yeah! Boom-baby-boom! hahah.","M6_Saxon_yeahboom.WAV");
   }
}

function AI3killchat(%destroyer)
{
   %currentWeaponCount = getWeaponCount(%destroyer);      
   if(%currentweaponcount < %destroyer.weaponcount)
   {
      %distance1 = getdistance(%destroyer,$pad1);
      %distance2 = getdistance(%destroyer,$pad2);
      %distance3 = getdistance(%destroyer,$pad3);
      %distance4 = getdistance(%destroyer,$pad4);
      %distance = %distance1;
      %pad = $pad1;
      if(%distance2 < %distance)
      {
         %distance = %distance2;
         %pad = $pad2;
      }
      if(%distance3 < %distance)
      {
         %distance = %distance3;
         %pad = $pad3;
      }
      if(%distance4 < %distance)
      {
         %distance = %distance4;
         %pad = $pad4;
      }
      order(%destroyer,guard,%pad);
      order(%destroyer,speed,high);
   }
   %randomtalk = randomInt(1,48);
   if(%randomtalk==1)
   {
      say(0,1,"<f3>" @ getVehicleName($AI3) @ ": gf");
   }
   else if(%randomtalk==2)
   {
      say(0,1,"<f3>" @ getVehicleName($AI3) @ ": gf");
   }
   else if(%randomtalk==3)
   {
      say(0,1,"<f3>" @ getVehicleName($AI3) @ ": cool, i actually killed someone!");
   }
   else if(%randomtalk==4)
   {
      say(0,1,"<f3>" @ getVehicleName($AI3) @ ": u need better protection");
   }
   else if(%randomtalk==5)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Target eliminated.","C3_targeteliminated.WAV");
   }
   else if(%randomtalk==6)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Target executed.","C7_targetexec.WAV");
   }
   else if(%randomtalk==7)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Hahaa...Music to my ears!","M6_Saxon_musictomyears.WAV");
   }
   else if(%randomtalk==8)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Success is the sole judge of right and wrong.","C2_success.WAV");
   }
   else if(%randomtalk==9)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Happiness is a bunch of smokin human steaks.","ee_pd43.WAV");
   }
   else if(%randomtalk==10)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Bring it on!","F4_Tiger_bringiton.WAV");
   }
   else if(%randomtalk==11)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Huh. Seem to have destroyed you. Sorry.","ee_pd36.WAV");
   }
   else if(%randomtalk==12)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Hurts real bad don't it?","F2_DM_hurtsrealbad.wav");
   }
   else if(%randomtalk==13)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": I'm really sorry about that.","ee_pd20.WAV");
   }
   else if(%randomtalk==14)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Human//animals are fascinating.","C5_humansfascin.WAV");
   }
   else if(%randomtalk==15)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Excellent//efficient.","C7_excellent.WAV");
   }
   else if(%randomtalk==16)
   {
      say(0,1,"<f5>" @ getVehicleName($AI3) @ ": Yeah! Boom-baby-boom! hahah.","M6_Saxon_yeahboom.WAV");
   }
}

function AI4killchat(%destroyer)
{
   %currentWeaponCount = getWeaponCount(%destroyer);      
   if(%currentweaponcount < %destroyer.weaponcount)
   {
      %distance1 = getdistance(%destroyer,$pad1);
      %distance2 = getdistance(%destroyer,$pad2);
      %distance3 = getdistance(%destroyer,$pad3);
      %distance4 = getdistance(%destroyer,$pad4);
      %distance = %distance1;
      %pad = $pad1;
      if(%distance2 < %distance)
      {
         %distance = %distance2;
         %pad = $pad2;
      }
      if(%distance3 < %distance)
      {
         %distance = %distance3;
         %pad = $pad3;
      }
      if(%distance4 < %distance)
      {
         %distance = %distance4;
         %pad = $pad4;
      }
      order(%destroyer,guard,%pad);
      order(%destroyer,speed,high);
   }
   %randomtalk = randomInt(1,48);
   if(%randomtalk==1)
   {
      say(0,1,"<f3>" @ getVehicleName($AI4) @ ": gf");
   }
   else if(%randomtalk==2)
   {
      say(0,1,"<f3>" @ getVehicleName($AI4) @ ": gf");
   }
   else if(%randomtalk==3)
   {
      say(0,1,"<f3>" @ getVehicleName($AI4) @ ": cool, i actually killed someone!");
   }
   else if(%randomtalk==4)
   {
      say(0,1,"<f3>" @ getVehicleName($AI4) @ ": u need better protection");
   }
   else if(%randomtalk==5)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Target eliminated.","C3_targeteliminated.WAV");
   }
   else if(%randomtalk==6)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Target executed.","C7_targetexec.WAV");
   }
   else if(%randomtalk==7)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Hahaa...Music to my ears!","M6_Saxon_musictomyears.WAV");
   }
   else if(%randomtalk==8)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Success is the sole judge of right and wrong.","C2_success.WAV");
   }
   else if(%randomtalk==9)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Happiness is a bunch of smokin human steaks.","ee_pd43.WAV");
   }
   else if(%randomtalk==10)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Bring it on!","F4_Tiger_bringiton.WAV");
   }
   else if(%randomtalk==11)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Huh. Seem to have destroyed you. Sorry.","ee_pd36.WAV");
   }
   else if(%randomtalk==12)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Hurts real bad don't it?","F2_DM_hurtsrealbad.wav");
   }
   else if(%randomtalk==13)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": I'm really sorry about that.","ee_pd20.WAV");
   }
   else if(%randomtalk==14)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Human//animals are fascinating.","C5_humansfascin.WAV");
   }
   else if(%randomtalk==15)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Excellent//efficient.","C7_excellent.WAV");
   }
   else if(%randomtalk==16)
   {
      say(0,1,"<f5>" @ getVehicleName($AI4) @ ": Yeah! Boom-baby-boom! hahah.","M6_Saxon_yeahboom.WAV");
   }
}

function onmissionend()
{
   flushConsoleScheduler();
   deleteobject($AI1);
   deleteobject($AI2);
   deleteobject($AI3);
   deleteobject($AI4);
}
