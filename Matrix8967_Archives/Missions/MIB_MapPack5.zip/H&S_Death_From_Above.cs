// FILENAME:	H&S_Death_From_Above.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//
// RANDOM QUOTE: "Who throws a shoe? Honestly...
//               You could put an eye out with that thing!"
//                                 - Austin Powers
//------------------------------------------------------------------------------

$missionName = "H&S_Death_From_Above";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");
exec("BoostStdLib.cs"); //Beta version...doesn't work too well.

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function setDefaultMissionItems()
{
   allowComponent(                                        all, TRUE  );
   allowComponent(                                        400, FALSE  );
   allowComponent(                                        401, FALSE  );
   allowComponent(                                        408, FALSE  );
   allowComponent(                                        409, FALSE  );
   allowComponent(                                        410, FALSE  );
   allowComponent(                                        411, FALSE  );
   allowComponent(                                        412, FALSE  );
   allowComponent(                                        413, FALSE  );
   allowComponent(                                        414, FALSE  );
   allowComponent(                                        426, FALSE  );
   allowComponent(                                        427, FALSE  );
   allowComponent(                                        428, FALSE  );
   allowComponent(                                        429, FALSE  );
   allowComponent(                                        430, FALSE  );
   allowComponent(                                        431, FALSE  );
   allowComponent(                                        432, FALSE  );
   allowComponent(                                        433, FALSE  );
   allowComponent(                                        434, FALSE  );
}

function onMissionStart()
{
	marsSounds();

      $killPoints = 0;
      $deathPoints = 2;

      $active=true;
      $path="Missiongroup/Path";
}     

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to Hide & Seek (H&S)! Check the game info tab for the rules & information on how to fly. You can download H&S_Death_From_Above & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.points = 0;
}

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.turndelay = false;
   setVehicleRadarVisible(%vehicleId, false);
}

function onMissionLoad() 
{
   cdAudioCycle("NewTech", "Mechsoul", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Hide & Seek\n\n<F2>MISSION:<F0>  H&S_Death_From_Above\n\n<F2>RULES:<F0>\n\nFind other players & \"tag\" them to destroy them. To tag an enemy vehicle, lock onto your target & scan him with the \" <F3>I<F0> \" key. Radar is NOT allowed. Tags are worth <F3>3<F0> points & deaths are worth <F3>-2<F0>. You DO NOT recieve points for normal kills.\n\n<F2>FLYING:<F0>\n\nScan a structure to boost up & hover for a few seconds. If you have the HercBoost Keymap, you can steer in mid-air & fly indefinitely. You can download the keymaps in the \"MIB Map Packs\" on the MIB website at www.starsiegemeninblack.cjb.net.\n\n<f2>HercBoost Keymap Controls:<f0>\n\nBoost:                             <f3>Ctrl + S<F0>\nHover:                            <f3>Ctrl + D<f0>\nBoost Forward:                    <f3>Ctrl + W<f0>\nCancel Boost or Hover:            <f3>Ctrl + A<f0>\nSteer Left (Tanks Only):           <f3>Left Arrow<f0>\nSteer Right (Tanks Only):          <f3>Right Arrow<f0>");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.points = 0;
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
// left over from missionStdLib.cs
//   vehicle::onDestroyedLog(%destroyed, %destroyer);
//   
// this is weird but %destroyer isn't necessarily a vehicle
//   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
//   if(%message != "")
//   {
//      say( 0, 0, %message);
//   }
//   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if(
         (getTeam(%destroyed) == getTeam(%destroyer)) &&
         (%destroyed != %destroyer)
      )
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function vehicle::OnScan(%scanned, %scanner, %string)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(($server::TeamPlay == true) && (getTeam(%scanner) == getTeam(%scanned)))
   {  
      say(%player, %player, gethudname(%scanned) @ " is on your team!");
   }
   else
   {
      healObject(%scanned, -10000);
	healObject(%scanned, -10000);
	healObject(%scanned, -10000);
	healObject(%scanned, -10000);
	healObject(%scanned, -10000);
      %player.points = %player.points + 3;
      say("everybody", 0, gethudname(%scanned) @ " was tagged by " @ gethudname(%scanner) @ "!");
   } 
}

function getPlayerScore(%player)
{
   return((%player.points) + (getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints));
}

//------------------------------------------------------------------
// Scan something to jump up, then hover.

function structure::onscan(%scanned,%scanner)
{
   jump(%scanner);
   schedule("jump("@%scanner@");",0.1);
   schedule("jump("@%scanner@");",0.2);
   schedule("jump("@%scanner@");",0.3);
   schedule("jump("@%scanner@");",0.4);
   schedule("jump("@%scanner@");",0.5);
   schedule("hover2("@%scanner@");",0.6);
   schedule("hover2("@%scanner@");",0.7);
   schedule("hover2("@%scanner@");",0.8);
   schedule("hover2("@%scanner@");",0.9);
   schedule("hover2("@%scanner@");",1.0);
   schedule("hover2("@%scanner@");",1.1);
   schedule("hover2("@%scanner@");",1.2);
   schedule("hover2("@%scanner@");",1.3);
   schedule("hover2("@%scanner@");",1.4);
   schedule("hover2("@%scanner@");",1.5);
   schedule("hover2("@%scanner@");",1.6);
   schedule("hover2("@%scanner@");",1.7);
   schedule("hover2("@%scanner@");",1.8);
   schedule("hover2("@%scanner@");",1.9);
   schedule("hover2("@%scanner@");",2.0);
   schedule("hover2("@%scanner@");",2.1);
   schedule("hover2("@%scanner@");",2.2);
   schedule("hover2("@%scanner@");",2.3);
   schedule("hover2("@%scanner@");",2.4);
   schedule("hover2("@%scanner@");",2.5);
   schedule("hover2("@%scanner@");",2.6);
   schedule("hover2("@%scanner@");",2.7);
   schedule("hover2("@%scanner@");",2.8);
   schedule("hover2("@%scanner@");",2.9);
   schedule("hover2("@%scanner@");",3.0);
   schedule("hover2("@%scanner@");",3.1);
   schedule("hover2("@%scanner@");",3.2);
   schedule("hover2("@%scanner@");",3.3);
   schedule("hover2("@%scanner@");",3.4);
   schedule("hover2("@%scanner@");",3.5);
   schedule("hover2("@%scanner@");",3.6);
   schedule("hover2("@%scanner@");",3.7);
   schedule("hover2("@%scanner@");",3.8);
   schedule("hover2("@%scanner@");",3.9);
   schedule("hover2("@%scanner@");",4.0);
}

function jump(%scanner)
{
   %posx=getposition(%scanner,x);
   %posy=getposition(%scanner,y);
   %posz=getposition(%scanner,z)+5;
   setposition(%scanner,%posx,%posy,%posz);
}

function hover2(%scanner)
{
   %posx=getposition(%scanner,x);
   %posy=getposition(%scanner,y);
   %posz=getposition(%scanner,z)+0.2;
   setposition(%scanner,%posx,%posy,%posz);
}
