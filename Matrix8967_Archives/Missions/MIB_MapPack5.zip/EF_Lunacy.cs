// FILENAME:	EF_Lunacy.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "EF_Lunacy";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;  //Cant have yellow team because the fields are on yellow team
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;  //Cant have yellow team because the fields are on yellow team
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   moonSounds();
   $EnergyFields = "MissionGroup/EnergyFields";

   //DM_Lunacy stuff
   $instantPadWaitTime = 120;
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "Cloudburst", "Terror","Mechsoul","NewTech"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Energy Field DeathMatch\n\n<F2>MISSION:<F0>  EF_Lunacy\n\nWelcome to Energy Field DeathMatch! Your vehicle is equipped with an Energy Field generator when you spawn. Shut down to set an Energy Force Field. Your Energy Field generator must charge for 40 seconds after each use. Scan another vehicle or a structure to adjust the rotation of Energy Field. You cannot set an Energy Field while in a pad. Energy fields can be destroyed. You can download EF_Lunacy & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   //reset deathdelay
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.deathdelay = false;
   }
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Energy Field DeathMatch! Your vehicle is equipped with an energy field generator when you spawn. Shut down to set an Energy Force Field. Your Energy Field generator must charge for 40 seconds after each use. Check the game info tab for more information. You can download EF_Lunacy & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.deathdelay = false;
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %vehicleId.ready = true;
   %vehicleId.angle = "Auto";
   sethudtimer(0,0,"Energy Field Ready",2,%player);
   %player.InPad = false;
   %player.spawndelay = true;
   schedule("spawndelay("@%player@");",5);   
}   

function spawndelay(%player)
{
   %player.spawndelay = false;
}

function RadToDeg(%radians)
{
   %degrees = (%radians * 180) / 3.14159;
   return %degrees;
}

function round(%number)
{
   %roundNum = %number;
   if(%number > 0)
   {
      %excess = (%number - floor(%number));
      if(%excess >= 0.5)
      {
         %roundNum = (floor(%number) + 1);
      }
      else
      {
         %roundNum = floor(%number);
      }
   }
   if(%number < 0)
   {
      %excess = (floor(%number) - %number);
      if(%excess <= 0.5)
      {
         %roundNum = floor(%number);
      }
      else
      {
         %roundNum = (floor(%number) - 1);
      }
   }
   return %roundNum;
}

function adjustAngle(%angle)
{
   if(%angle >= 360)
   {
      while(%angle >= 360)
      {
         %angle = (%angle - 360);
      }
   }
   else if(%angle < 0)
   {
      while(%angle < 0)
      {
         %angle = (%angle + 360);
      }
   }
   return %angle;
}

function vehicle::onscan(%scanned,%scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%scanner.angle=="Auto")
   {
      %scanner.angle = 0;
      say(%player,%player,"<f1>Energy Field rotation: 0�");
   }
   else if(%scanner.angle==0)
   {
      %scanner.angle = 45;
      say(%player,%player,"<f1>Energy Field rotation: 45�");
   }
   else if(%scanner.angle==45)
   {
      %scanner.angle = 90;
      say(%player,%player,"<f1>Energy Field rotation: 90�");
   }
   else if(%scanner.angle==90)
   {
      %scanner.angle = 135;
      say(%player,%player,"<f1>Energy Field rotation: 135�");
   }
   else if(%scanner.angle==135)
   {
      %scanner.angle = "Auto";
      say(%player,%player,"<f1>Energy Field rotation: Automatic Rotation");
   }
}

function structure::onscan(%scanned,%scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%scanner.angle=="Auto")
   {
      %scanner.angle = 0;
      say(%player,%player,"<f1>Energy Field rotation: 0�");
   }
   else if(%scanner.angle==0)
   {
      %scanner.angle = 45;
      say(%player,%player,"<f1>Energy Field rotation: 45�");
   }
   else if(%scanner.angle==45)
   {
      %scanner.angle = 90;
      say(%player,%player,"<f1>Energy Field rotation: 90�");
   }
   else if(%scanner.angle==90)
   {
      %scanner.angle = 135;
      say(%player,%player,"<f1>Energy Field rotation: 135�");
   }
   else if(%scanner.angle==135)
   {
      %scanner.angle = "Auto";
      say(%player,%player,"<f1>Energy Field rotation: Automatic Rotation");
   }
}

function vehicle::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyed);
   
   %player.deathdelay = true;
   schedule("deathdelay("@%player@");",5);   
   vehicle::onDestroyedLog(%destroyed, %destroyer);
  
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function deathdelay(%player)
{
   %player.deathdelay = false;
}

function field::trigger::oncontact(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(isshutdown(%object)==false)
   {
      %player.justlaid = false;
   }
   if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%object.ready==true)&&(%player.deathdelay==false))
   {  
      %player.justlaid = true;
      setField(%object);
   }  
   else if((%player.InPad==false)&&(isshutdown(%object)==true)&&(%object.ready==false)&&(%player.justlaid==false))
   {  
      %player.justlaid = true;
      say(%player,%player,"<f1>Your Energy Field has not finished charging.");
   }
}

function setField(%object)
{
   %player = playerManager::vehicleIdtoPlayerNum(%object);  
   %object.ready = false;
   %x = getposition(%object,x);
   %y = getposition(%object,y);
   %z = getposition(%object,z)-10;
   %Field1 = newobject("Field",staticshape,"fx_tele_t.DTS");
   addToSet($EnergyFields,%Field1);   
   setTeam(%Field1,*IDSTR_TEAM_YELLOW);
   schedule("playAnimSequence(" @ %Field1 @ ",0,true);",1);
   %Field2 = newobject("Field",staticshape,"fx_tele_t.DTS");
   addToSet($EnergyFields,%Field2);   
   setposition(%Field2,%x,%y,%z,%object.angle);
   setTeam(%Field2,*IDSTR_TEAM_YELLOW);
   schedule("playAnimSequence(" @ %Field2 @ ",0,true);",1);
   %Field3 = newobject("Field",staticshape,"fx_tele_t.DTS");
   addToSet($EnergyFields,%Field3);   
   setposition(%Field3,%x,%y,%z,%object.angle);
   setTeam(%Field3,*IDSTR_TEAM_YELLOW);
   schedule("playAnimSequence(" @ %Field3 @ ",0,true);",1);
   if(%object.angle=="Auto")
   {
      %rotRad = getPosition(%object,rot);
      %rotDeg = RadToDeg(%rotRad)+90;
      %rot = round(adjustAngle(%rotDeg));
      setposition(%Field1,%x,%y,%z,%rot);      
      setposition(%Field2,%x,%y,%z,%rot);
      setposition(%Field3,%x,%y,%z,%rot);
   }
   else
   {
      setposition(%Field1,%x,%y,%z,%object.angle);      
      setposition(%Field2,%x,%y,%z,%object.angle);
      setposition(%Field3,%x,%y,%z,%object.angle);
   }
   say(%player,%player,"<f1>Energy Field deployed.");
   schedule("ready("@%object@");",40);   
   sethudtimer(40,-1,"Energy Field Charging",2,%player);
   playSound(%player, "sfx_electrical_bzzt.wav", IDPRF_2D);
}

function ready(%object)
{
   %object.ready = true;
}

function structure::ondestroyed(%destroyed,%destroyer)
{
   if(getObjectName(%destroyed)=="Field")
   {
      schedule("deleteObject("@%destroyed@");",1);
   }
}

function onMissionEnd()
{
   flushConsoleScheduler();
   deleteObject($EnergyFields);
}

//  Special Pads
//  BombZen Pad Functionality
function BombZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);
      %player.InPad = true; 
}

function BombZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 40, 70, true); 
}

function BombZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombHeal Pad Functionality
function BombHeal::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);
      %player.InPad = true; 
}

function BombHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 0, 0, true); 
}

function BombHeal::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombAmmo Pad Functionality
function BombAmmo::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);
      %player.InPad = true; 
}

function BombAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, 40, 40, true); 
}

function BombAmmo::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

function Field::trigger::onEnter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.spawndelay==false)
   {
      say(%player,%player,"<f1>Re-entering mission area. Energy Field back online.");
   }
}

function Field::trigger::onLeave(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.deathdelay==false)
   {
      say(%player,%player,"<f1>Leaving mission area. Energy Field disabled.");
   }
}


//DM_Lunacy stuff
// Instant Pad stuff
//------------------------------------------------------------------------------
function ZenInstant::trigger::onEnter(%this, %object)
{
   Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
}
function ZenInstant::trigger::onContact(%this, %object)
{
   // completely heal and reload instantly -- no reset time
   // shutdown necessary
   Zen::work(%this, %object, 10000, 100, $instantPadWaitTime, true); 
}
function ZenInstant::trigger::onLeave(%this, %object)
{
   Zen::onLeave(%this, %object);
}

// Special pads
// no message, no shutdown, no reset
function ZenAll1::trigger::onEnter(%this, %object)
{
   // instant work, no shutdown, no reset
    Zen::onEnter(%this, %object, "", false, false);  
	if(%this.wait != true){
		Zen::work(%this, %object, $specialHealRate, $specialAmmoRate, 20 , false);
	   // damage everyone else within %blastRadiusSmall meters
   		blast(%this, $blastRadiusSmall, $blastDamageSmall, %object);
		explosion1();
	}
}

function ZenAll2::trigger::onEnter(%this, %object)
{
   // instant work, no shutdown, no reset
    Zen::onEnter(%this, %object, "", false, false);  
	if(%this.wait != true){
		Zen::work(%this, %object, $specialHealRate, $specialAmmoRate, 20 , false);
	   // damage everyone else within %blastRadiusSmall meters
   		blast(%this, $blastRadiusSmall, $blastDamageSmall, %object);
		explosion2();
	}
}

function ZenAll3::trigger::onEnter(%this, %object)
{
   // instant work, no shutdown, no reset
    Zen::onEnter(%this, %object, "", false, false);  
	if(%this.wait != true){
		Zen::work(%this, %object, $specialHealRate, $specialAmmoRate, 20 , false);
	   // damage everyone else within %blastRadiusSmall meters
   		blast(%this, $blastRadiusSmall, $blastDamageSmall, %object);
		explosion3();
	}
}

function ZenAll4::trigger::onEnter(%this, %object)
{
   // instant work, no shutdown, no reset
    Zen::onEnter(%this, %object, "", false, false);  
	if(%this.wait != true){
		Zen::work(%this, %object, $specialHealRate, $specialAmmoRate, 20 , false);
	   // damage everyone else within %blastRadiusSmall meters
   		blast(%this, $blastRadiusSmall, $blastDamageSmall, %object);
		explosion4();
	}
} 
function ZenAll1::trigger::onLeave(%this, %object)
{
   Zen::onLeave(%this, %object);
}
function ZenAll2::trigger::onLeave(%this, %object)
{
   Zen::onLeave(%this, %object);
}
function ZenAll3::trigger::onLeave(%this, %object)
{
   Zen::onLeave(%this, %object);
}
function ZenAll4::trigger::onLeave(%this, %object)
{
   Zen::onLeave(%this, %object);
}

function explosion1()
{
	dropPod(-686, 688, 117, -759, 688, 117);
	dropPod(-759, 688, 117, -686, 688, 117);
}
function explosion2()
{
	dropPod(-686, 720, 117, -759, 720, 117);
	dropPod(-759, 720, 117, -686, 720, 117);
}
function explosion3()
{
	dropPod(-686, 752, 117, -759, 752, 117);
	dropPod(-759, 752, 117, -686, 752, 117);
}
function explosion4()
{
	dropPod(-686, 784, 117, -759, 784, 117);
	dropPod(-759, 784, 117, -686, 784, 117);
}

// Easter Egg
//--------------------------------------------------------------------------------
function EasterEgg::trigger::onEnter(%this, %object)
{
	Say(playerManager::vehicleIdToPlayerNum(%object), %object, *IDMULT_MOON_LANDER_FOUND);
}
function EasterEgg::trigger::onContact(%this, %object)
{
	damageObject(%object, 250);
}