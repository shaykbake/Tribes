// MISSION NAME:   WAR_Titanic_Hotzone
//
// AUTHOR:         Maj. DarkRaven [M.I.B.]
//------------------------------------------------------------------------------
$missionName = "WAR: Titanic Hotzone";

exec("multiplayerStdLib.cs");
// move the map
$server::HudMapViewOffsetX = 7500;
$server::HudMapViewOffsetY = -6000;
////
$redlost = 0; // who lost?
$yellowlost = 0;
$bluelost = 0;
$purplelost = 0;
$redKills = 0; 
$yellowKills = 0;
$blueKills = 0;
$purpleKills = 0;
$yellowHerc1RespawnTime = 0;
$yellowHerc2RespawnTime = 0;
$yellowHerc3RespawnTime = 0;
$redHerc1RespawnTime = 0;
$redHerc2RespawnTime = 0;
$redHerc3RespawnTime = 0;
$blueHerc1RespawnTime = 0;
$blueHerc2RespawnTime = 0;
$blueHerc3RespawnTime = 0;
$purpleHerc1RespawnTime = 0;
$purpleHerc2RespawnTime = 0;
$purpleHerc3RespawnTime = 0;
$RedHerc1Path = "MissionGroup/redBase/RedhercPath1";
$RedHerc2Path = "MissionGroup/redBase/RedhercPath2";
$RedHerc3Path = "MissionGroup/redBase/RedhercPath3";
$YellowHerc1Path = "MissionGroup/yellowBase/YellowhercPath1";
$YellowHerc2Path = "MissionGroup/yellowBase/YellowhercPath2";
$YellowHerc3Path = "MissionGroup/yellowBase/YellowhercPath3";
$BlueHerc1Path = "MissionGroup/blueBase/BluehercPath1";
$BlueHerc2Path = "MissionGroup/blueBase/BluehercPath2";
$BlueHerc3Path = "MissionGroup/blueBase/BluehercPath3";
$PurpleHerc1Path = "MissionGroup/purpleBase/PurplehercPath1";
$PurpleHerc2Path = "MissionGroup/purpleBase/PurplehercPath2";
$PurpleHerc3Path = "MissionGroup/purpleBase/PurplehercPath3";
////
// Buildings
function defaultstuffnmore()
{
	$purplebuildings = 8;
	$redbuildings = 8;
	$bluebuildings = 8;
	$yellowbuildings = 8;

	$redBuildingsDestroyed = 0;
	$yellowBuildingsDestroyed = 0;
	$blueBuildingsDestroyed = 0;
	$purpleBuildingsDestroyed = 0;

	$rcomndes = 0;
	$bcomndes = 0;
	$ycomndes = 0;
	$pcomndes = 0; 

	$yhqdes = 0; 
	$rhqdes = 0;
	$bhqdes = 0;
	$phqdes = 0;

	$rgen1Des = 0; 
	$rgen2Des = 0; 
	$rgen3Des = 0; 
	$rgen4Des = 0;
	$rgen5Des = 0;
	$rgen6Des = 0;

	$bgen1Des = 0;
	$bgen2Des = 0;
	$bgen3Des = 0;
	$bgen4Des = 0;
	$bgen5Des = 0;
	$bgen6Des = 0;

	$ygen1Des = 0;
	$ygen2Des = 0;
	$ygen3Des = 0;
	$ygen4Des = 0;
	$ygen5Des = 0;
	$ygen6Des = 0;

	$pgen1Des = 0;
	$pgen2Des = 0;
	$pgen3Des = 0;
	$pgen4Des = 0;
	$pgen5Des = 0;
	$pgen6Des = 0;
}
//comn Buildings
function pcomn::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
        $pcomndes = 1;
	partilleryClearTarget();
	$purplebuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed the purple communication building.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed the purple communication building.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed the purple communication building.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own communication building.";
	}
	say(0, 0, %hmm);
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
}
function rcomn::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$rcomndes = 1;
	$redbuildings--;
	rartilleryClearTarget();
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed the red communication building.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed the red communication building.";
		$purpleBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed the red communication building.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own communication building.";
	}
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function ycomn::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$ycomndes = 1;
	$yellowbuildings--;
	yartilleryClearTarget();
	if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed the yellow communication building.";
		$purpleBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed the yellow communication building.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed the yellow communication building.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own communication building.";
	}
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bcomn::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bcomndes = 1;
	$bluebuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed the blue communication building.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed the blue communication building.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed the blue communication building.";
		$purpleBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own communication building.";
	}
	bartilleryClearTarget();
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
//HEADQUARTERS
function phq::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$purplebuildings--;
	$phqdes = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed the purple headquarters.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed the purple headquarters.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed the purple headquarters.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own headquarters.";
	}
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function rhq::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$redbuildings--;
	$rhqdes = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed the red headquarters.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed the red headquarters.";
		$purpleBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed the red headquarters.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own headquarters.";
	}
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function yhq::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$yellowbuildings--;
	$yhqdes = 1;
	if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed the yellow headquarters.";
		$purpleBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed the yellow headquarters.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed the yellow headquarters.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own headquarters.";
	}
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bhq::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bluebuildings--;
	$bhqdes = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed the blue headquarters.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed the blue headquarters.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed the blue headquarters.";
		$purpleBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own headquarters.";
	}
	say(0, 0, %hmm);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
//PURPLE GENERATORS
function pgen1::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$purplebuildings--;
	$pgen1des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed purple generator #1.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed purple generator #1.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed purple generator #1.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($pt11, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function pgen2::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$purplebuildings--;
	$pgen2des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed purple generator #2.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed purple generator #2.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed purple generator #2.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($pt21, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function pgen3::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed purple generator #3.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed purple generator #3.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed purple generator #3.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($pt31, shutdown, true);
	$pgen3des = 1;
	$purplebuildings--;
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function pgen4::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$purplebuildings--;
	$pgen4des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed purple generator #4.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed purple generator #4.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed purple generator #4.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($pt41, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function pgen5::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$purplebuildings--;
	$pgen5des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed purple generator #5.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed purple generator #5.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed purple generator #5.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($pt51, shutdown, true);
	order($pt52, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function pgen6::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$pgen6des = 1;
	$purplebuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed purple generator #6.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed purple generator #6.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed purple generator #6.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($pt61, shutdown, true);
	order($pt62, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_PURPLE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
//BLUE GENERATORS
function bgen1::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bluebuildings--;
	$bgen1des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed blue generator #1.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed blue generator #1.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed blue generator #1.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($bt11, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bgen2::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bgen2des = 1;
	$bluebuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed blue generator #2.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed blue generator #2.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed blue generator #2.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($bt21, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bgen3::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bgen3des = 1;
	$bluebuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed blue generator #3.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed blue generator #3.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed blue generator #3.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($bt31, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bgen4::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bluebuildings--;
	$bgen4des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed blue generator #4.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed blue generator #4.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed blue generator #4.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($bt41, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bgen5::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bgen5des = 1;
	$bluebuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed blue generator #5.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed blue generator #5.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed blue generator #5.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($bt51, shutdown, true);
	order($bt52, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function bgen6::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$bluebuildings--;
	$bgen6des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed blue generator #6.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed blue generator #6.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed blue generator #6.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($bt61, shutdown, true);
	order($bt62, shutdown, true);
	%txt = "";
  say(IDSTR_TEAM_BLUE, 1234, %txt, "friend_struct_des.wav");    
checkwin();
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
}
//RED GENERATORS
function rgen1::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$redbuildings--;
	$rgen1des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed red generator #1.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed red generator #1.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed red generator #1.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($rt11, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function rgen2::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$rgen2des = 1;
	$redbuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed red generator #2.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed red generator #2.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed red generator #2.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($rt21, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function rgen3::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$redbuildings--;
	$rgen3des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed red generator #3.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed red generator #3.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed red generator #3.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($rt31, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function rgen4::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$redbuildings--;
	$rgen4des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed red generator #4.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed red generator #4.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed red generator #4.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($rt41, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function rgen5::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$rgen5des = 1;
	$redbuildings--;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed red generator #5.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed red generator #5.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed red generator #5.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($rt51, shutdown, true);
	order($rt52, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function rgen6::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$redbuildings--;
	$rgen6des = 1;
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Yellow team has destroyed red generator #6.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed red generator #6.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed red generator #6.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($rt61, shutdown, true);
	order($rt62, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
//YELLOW GENERATORS
function ygen1::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$ygen1des = 1;
	$yellowbuildings--;
	if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed yellow generator #1.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed yellow generator #1.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed yellow generator #1.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($yt11, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function ygen2::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$yellowbuildings--;
	$ygen2des = 1;
	if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed yellow generator #2.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed yellow generator #2.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed yellow generator #2.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($yt21, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function ygen3::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$ygen3des = 1;
	$yellowbuildings--;
	if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed yellow generator #3.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed yellow generator #3.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed yellow generator #3.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($yt31, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function ygen4::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$yellowbuildings--;
	$ygen4des = 1;
	if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed yellow generator #4.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed yellow generator #4.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed yellow generator #4.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($yt41, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function ygen5::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$ygen5des = 1;
	$yellowbuildings--;
	if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed yellow generator #5.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed yellow generator #5.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed yellow generator #5.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($yt51, shutdown, true);
	order($yt52, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
function ygen6::structure::ondestroyed(%this, %destroyer)
{
	%team = getteam(%destroyer);
	$ygen6des = 1;
	$yellowbuildings--;
	if(%team == *IDSTR_TEAM_BLUE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Blue team has destroyed yellow generator #6.";
		$yellowBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_RED)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Red team has destroyed yellow generator #6.";
		$redBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " of Purple team has destroyed yellow generator #6.";
		$blueBuildingsDestroyed++;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		%hmm = "<F5>" @ gethudname(%destroyer) @ " destroyed his own generator!";
	}
	say(0, 0, %hmm);
	order($yt61, shutdown, true);
	order($yt62, shutdown, true);
  %player = playerManager::vehicleIdToPlayerNum( %destroyer );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }
	%txt = "";
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
checkwin();
}
/////
$respawnDelay = 60;
$respawnDelayNoHq = 180;
$BUILDINGS_TO_DESTROY = 8;
/////
Pilot humanPilot
{
   id = 28;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.6;
   activateDist = 850.0;
   deactivateBuff = 400.0;
   targetFreq = 3.0;
   trackFreq = 0.3;
   fireFreq = 0.7;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};
Pilot cybridPilot
{
   id = 29;
   skill = 0.4;
   accuracy = 0.4;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 400.0;
   targetFreq = 2.0;
   trackFreq = 0.1;
   fireFreq = 0.7;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};
function initGlobalVars()
{
   $scoringFreeze = false;
   
   %playerCount = playerManager::getPlayerCount();
	// clear all points for the players
   for (%p = 0; %p < %playerCount; %p++)
	{
		%player = playerManager::getPlayerNum(%p);
      %player.numKills = 0;
      %player.buildingsDestroyed = 0;
   }
}
function endturn()
{
   %playerCount = playerManager::getPlayerCount();
   for (%p = 0; %p < %playerCount; %p++)
	{
			%player = playerManager::getPlayerNum(%p);
			%person = gethudname(%p);
                        %msg = "" @ %person @ " had " @ %player.numkills @ " kills and destroyed " @ %player.buildingsDestroyed @ " buildings.";
			say(0, 0, %msg);
      }
}
function setDefaultMissionOptions()
{
	$server::TeamPlay = True;
	$server::AllowDeathmatch = False;
	$server::AllowTeamPlay = True;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}
function setDefaultMissionItems()
{
   allowComponent(        all, TRUE  );      
   allowComponent(        830, FALSE  );      //Chameleon
   allowComponent(        831, FALSE  );      //Cuttlefish cloak
}
function makehercs()
{
   $yellowHerc1 = getObjectId( "MissionGroup/yellowBase/yellowHerc1/herc1" );
   $yellowHerc2 = getObjectId( "MissionGroup/yellowBase/yellowHerc2/herc1" );
   $yellowHerc3 = getObjectId( "MissionGroup/yellowBase/yellowHerc3/herc1" );
   $redHerc1 = getObjectId( "MissionGroup/redBase/redHerc1/herc1" );
   $redHerc2 = getObjectId( "MissionGroup/redBase/redHerc2/herc1" );
   $redHerc3 = getObjectId( "MissionGroup/redBase/redHerc3/herc1" );
   $blueHerc1 = getObjectId( "MissionGroup/blueBase/blueHerc1/herc1" );
   $blueHerc2 = getObjectId( "MissionGroup/blueBase/blueHerc2/herc1" );
   $blueHerc3 = getObjectId( "MissionGroup/blueBase/blueHerc3/herc1" );
   $purpleHerc1 = getObjectId( "MissionGroup/purpleBase/purpleHerc1/herc1" );
   $purpleHerc2 = getObjectId( "MissionGroup/purpleBase/purpleHerc2/herc1" );
   $purpleHerc3 = getObjectId( "MissionGroup/purpleBase/purpleHerc3/herc1" );
	makeartillery();
	makebasegen();
	makebasetur();
	starporttur();
	defaultstuffnmore();
}
function makeartillery()
{
	$rart = getObjectId( "MissionGroup/redBase/ART/tank1" );
	$yart = getObjectId( "MissionGroup/yellowBase/ART/tank1" );
	$bart = getObjectId( "MissionGroup/blueBase/ART/tank1" );
	$part = getObjectId( "MissionGroup/purpleBase/ART/tank1" );
	order($rart, shutdown, true); // artillery tanks are online only when someone spots.
	order($yart, shutdown, true);
	order($bart, shutdown, true);
	order($part, shutdown, true);
}
function makebasegen()
{
	$rgen1 = "missiongroup/redbase/gen1";
	$rgen2 = "missiongroup/redbase/gen2";
	$rgen3 = "missiongroup/redbase/gen3";
	$rgen4 = "missiongroup/redbase/gen4";
	$rgen5 = "missiongroup/redbase/gen5";
	$rgen6 = "missiongroup/redbase/gen6";

	$ygen1 = "missiongroup/yellowbase/gen1";
	$ygen2 = "missiongroup/yellowbase/gen2";
	$ygen3 = "missiongroup/yellowbase/gen3";
	$ygen4 = "missiongroup/yellowbase/gen4";
	$ygen5 = "missiongroup/yellowbase/gen5";
	$ygen6 = "missiongroup/yellowbase/gen6";

	$bgen1 = "missiongroup/bluebase/gen1";
	$bgen2 = "missiongroup/bluebase/gen2";
	$bgen3 = "missiongroup/bluebase/gen3";
	$bgen4 = "missiongroup/bluebase/gen4";
	$bgen5 = "missiongroup/bluebase/gen5";
	$bgen6 = "missiongroup/bluebase/gen6";

	$pgen1 = "missiongroup/purplebase/gen1";
	$pgen2 = "missiongroup/purplebase/gen2";
	$pgen3 = "missiongroup/purplebase/gen3";
	$pgen4 = "missiongroup/purplebase/gen4";
	$pgen5 = "missiongroup/purplebase/gen5";
	$pgen6 = "missiongroup/purplebase/gen6";
}
function makebasetur()
{
	$rt11 = "missiongroup/redbase/turrets/t11";
	$rt21 = "missiongroup/redbase/turrets/t21";
	$rt31 = "missiongroup/redbase/turrets/t31";
	$rt41 = "missiongroup/redbase/turrets/t41";
	$rt51 = "missiongroup/redbase/turrets/t51";
	$rt61 = "missiongroup/redbase/turrets/t61";

	$yt11 = "missiongroup/yellowbase/turrets/t11";
	$yt21 = "missiongroup/yellowbase/turrets/t21";
	$yt31 = "missiongroup/yellowbase/turrets/t31";
	$yt41 = "missiongroup/yellowbase/turrets/t41";
	$yt51 = "missiongroup/yellowbase/turrets/t51";
	$yt61 = "missiongroup/yellowbase/turrets/t61";

	$bt11 = "missiongroup/bluebase/turrets/t11";
	$bt21 = "missiongroup/bluebase/turrets/t21";
	$bt31 = "missiongroup/bluebase/turrets/t31";
	$bt41 = "missiongroup/bluebase/turrets/t41";
	$bt51 = "missiongroup/bluebase/turrets/t51";
	$bt61 = "missiongroup/bluebase/turrets/t61";

	$pt11 = "missiongroup/purplebase/turrets/t11";
	$pt21 = "missiongroup/purplebase/turrets/t21";
	$pt31 = "missiongroup/purplebase/turrets/t31";
	$pt41 = "missiongroup/purplebase/turrets/t41";
	$pt51 = "missiongroup/purplebase/turrets/t51";
	$pt61 = "missiongroup/purplebase/turrets/t61";
}
function starporttur()
{
		$st1 = "missiongroup/starportstuff/t1";
		$st2 = "missiongroup/starportstuff/t2";
		$st3 = "missiongroup/starportstuff/t3";
		$st4 = "missiongroup/starportstuff/t4";
}
$mytext = "There are 4 teams and 5 bases; Red = Knights, Yellow = Rebels, Blue = Cybrids, Purple = Metagen Cybrids. The 5th base is a captureable starport with its own turrets and defenders located in the center of the map. To capture the starport, you must go into the main building on the top. After it is captured a few times 2 talons will appear and defend the starport. Each base is slightly different, and each has a weakness. Knowing each weakness will make winning much easier.\n\n";
function onMissionLoad()
{
   cdAudioCycle("Watching", "Terror"); 
   %rules = "<tIDMULT_WAR_GAMETYPE>"      		@
            "<tIDMULT_WAR_MAPNAME>"       		@
            $missionName                  		@
            "<tIDMULT_WAR_OBJECTIVES_1>" 			@
            timeDifference($respawnDelay, 0)		@
            "<tIDMULT_WAR_OBJECTIVES_2>"  		@
            timeDifference($respawnDelayNoHq, 0)	@
            "<tIDMULT_WAR_OBJECTIVES_3>"  		@
            "<tIDMULT_WAR_OBJECTIVES_4>"  		@
            $BUILDINGS_TO_DESTROY         		@
            "<tIDMULT_WAR_OBJECTIVES_5>"  		@
   		$mytext						@
            "<tIDMULT_WAR_SCORING_1>"     		@
            "<tIDMULT_WAR_SCORING_2>"     		@
            "<tIDMULT_STD_ITEMS>"         		@
            "<tIDMULT_WAR_HQ>"            		@
            "<tIDMULT_WAR_GENERATORS>"    		@
            "<tIDMULT_WAR_TURRETS>"       		@
            "<tIDMULT_WAR_FLAGS>"         		@
            "<tIDMULT_WAR_GLOW>"          		@
            "<tIDMULT_STD_HEAL>"          		@
            "<tIDMULT_STD_RELOAD_1>"     	 		@
            $PadWaitTime                  		@
            "<tIDMULT_STD_RELOAD_2>";
      setGameInfo(%rules);

}
$players = 0;
function player::onAdd(%this)
{
	$players++;
   say( %this, 0, "Welcome to 4-Team WAR! You can download WAR_Titanic_Hotzone & other missions made by Maj. DarkRaven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
	playerses();
}
function player::onremove()
{
	$players--;
}
function playerses()
{
	%pnum = "" @ $players @ " player(s) in the game.";
	say(0, 0, %pnum);
}
function vehicle::onAdd(%this)
{
   // see if it is a player
   %player = playerManager::vehicleIdToPlayerNum(%this);

	%playteam = getteam(%this);

	if(%playteam == *IDSTR_TEAM_YELLOW)
	{
		if($yellowlost == 1)
		{
			say(%this, 0, "WARNING!!! Yellow team has already lost this match!!");
		}
	}
	else if(%playteam == *IDSTR_TEAM_RED)
	{
		if($redlost == 1)
		{
			say(%this, 0, "WARNING!!! Red team has already lost this match!!");
		}
	}
	else if(%playteam == *IDSTR_TEAM_BLUE)
	{
		if($bluelost == 1)
		{
			say(%this, 0, "WARNING!!! Blue team has already lost this match!!");
		}
	}
	else if(%playteam == *IDSTR_TEAM_PURPLE)
	{
		if($purplelost == 1)
		{
			say(%this, 0, "WARNING!!! Purple team has already lost this match!!");
		}
	}
}
function vehicle::onDestroyed( %this, %destroyer )
{
   if( getTeam( %destroyer ) != getTeam( %this ) )
   {
      %player = playerManager::vehicleIdToPlayerNum( %destroyer );
      if(%player != 0)
      {
         %player.numKills++;      
      }
	   if( getTeam( %destroyer ) == *IDSTR_TEAM_YELLOW )
	   {
	      $yellowKills++;
	   }
	   else if( getTeam( %destroyer ) == *IDSTR_TEAM_RED )
	   {
	      $redKills++;
	   }
	   else if( getTeam( %destroyer ) == *IDSTR_TEAM_BLUE )
	   {
	      $blueKills++;
	   }
	   else if( getTeam( %destroyer ) == *IDSTR_TEAM_PURPLE )
	   {
	      $purpleKills++;
	   }
   }
   if($yellowlost == 0)
   {	
	if( %this == $yellowHerc1 )
	   {
	      
	      if( $yhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$yellowHerc1\", " @ %this @ ", 9942, -5473, 50);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$yellowHerc1\", " @ %this @ ", -9942, -5473, 40);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $yellowHerc2 )
	   {
	
	      if( $yhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$yellowHerc2\", " @ %this @ ", 10443, -5226, 50);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$yellowHerc2\", " @ %this @ ", 10443, -5226, 40);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $yellowHerc3 )
	   {
	      
	      if( $yhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$yellowHerc3\", " @ %this @ ", 10383, -5727, 50);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$yellowHerc3\", " @ %this @ ", 10383, -5727, 40);", $respawnDelayNoHq);
	      }
	   }
   }
   if($redlost == 0)
   {	
	   if( %this == $redHerc1 )
	   {
	      
	      if( $rhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$redHerc1\", " @ %this @ ", 7283, -5624, 50);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$redHerc1\", " @ %this @ ", 7283, -5624, 50);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $redHerc2 )
	   {
	      
	      if( $rhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$redHerc2\", " @ %this @ ", 7581, -5867, 50);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$redHerc2\", " @ %this @ ", 7581, -5867, 50);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $redHerc3 )
	   {
	      
	      if( $rhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$redHerc3\", " @ %this @ ", 6976, -5954, 50);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$redHerc3\", " @ %this @ ", 6976, -5954, 50);", $respawnDelayNoHq);
	      }
	   }
   }
   if($bluelost == 0)
   {	
	   if( %this == $blueHerc1 )
	   {
	      
	      if( $bhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$blueHerc1\", " @ %this @ ", 9189, -6779, 380);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$blueHerc1\", " @ %this @ ", 9189, -6779, 380);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $blueHerc2 )
	   {
	      
	      if( $bhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$blueHerc2\", " @ %this @ ", 8929, -6899, 380);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$blueHerc2\", " @ %this @ ", 8929, -6899, 380);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $blueHerc3 )
	   {
	      
	      if( $bhqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$blueHerc3\", " @ %this @ ", 9360, -7118, 380);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$blueHerc3\", " @ %this @ ", 9360, -7118, 380);", $respawnDelayNoHq);
	      }
	   }
   }
   if($purplelost == 0)
   {	
	   if( %this == $purpleHerc1 )
	   {
	      
	      if( $phqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$purpleHerc1\", " @ %this @ ", 7678, -3994, 70);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$purpleHerc1\", " @ %this @ ", 7678, -3994, 70);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $purpleHerc2 )
	   {
	      
	      if( $phqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$purpleHerc2\", " @ %this @ ", 7987, -3744, 110);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$purpleHerc2\", " @ %this @ ", 7987, -3744, 110);", $respawnDelayNoHq);
	      }
	   }
	   if( %this == $purpleHerc3 )
	   {
	      
	      if( $phqdes == 0 )
	      {
	         schedule( "trevorsCloneVehicle(\"$purpleHerc3\", " @ %this @ ", 7468, -3615, 130);", $respawnDelay);
	      }
	      else
	      {
	         schedule( "trevorsCloneVehicle(\"$purpleHerc3\", " @ %this @ ", 7468, -3615, 130);", $respawnDelayNoHq);
	      }
	   }
   }
   if( %this == $yartilleryTarget)
   {
       yartilleryClearTarget();
   }
   if( %this == $rartilleryTarget)
   {
       rartilleryClearTarget();
   }
   if( %this == $bartilleryTarget)
   {
       bartilleryClearTarget();
   }
   if( %this == $partilleryTarget)
   {
       partilleryClearTarget();
   }
   vehicle::onDestroyedLog(%this, %destroyer);
   
   %message = getFancyDeathMessage(getHUDName(%this), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   if(
      (getTeam(%this) == getTeam(%destroyer)) &&
      (%this != %destroyer)
   )
   {
      antiTeamKill(%destroyer);
   }
}
function structure::ondestroyed(%this, %destroyer)
{
        if( %this == $yartilleryTarget)
        {
            yartilleryClearTarget();
        }
        if( %this == $rartilleryTarget)
        {
            rartilleryClearTarget();
        }
        if( %this == $bartilleryTarget)
        {
            bartilleryClearTarget();
        }
        if( %this == $partilleryTarget)
        {
            partilleryClearTarget();
        }
}
function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

	$ScoreBoard::PlayerColumnHeader1 = "Team";
	$ScoreBoard::PlayerColumnHeader2 = "Kills";
	$ScoreBoard::PlayerColumnHeader3 = "Buildings Destroyed";

	$ScoreBoard::PlayerColumnFunction1 = "getTeam2";
	$ScoreBoard::PlayerColumnFunction2 = "getKills";
	$ScoreBoard::PlayerColumnFunction3 = "getBuildingsDestroyed";

   $ScoreBoard::TeamColumnHeader1 = "Structures Remaining";
   $ScoreBoard::TeamColumnHeader2 = "Team Status";
   $ScoreBoard::TeamColumnHeader3 = "Team Kills";
   $ScoreBoard::TeamColumnFunction1 = "getBuildingstokill2";
   $ScoreBoard::TeamColumnFunction2 = "getTeamKills";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills2";
 
   serverInitScoreBoard();
}
function getTeam2(%player)
{
   if(getTeam(%player) == *IDSTR_TEAM_BLUE)
   {
      return *IDMULT_BLUE;
   }
   else if (getteam(%player) == *IDSTR_TEAM_PURPLE)
   {
      return *IDMULT_PURPLE;
   }
   else if (getteam(%player) == *IDSTR_TEAM_RED)
   {
      return *IDMULT_RED;
   }
   else if (getteam(%player) == *IDSTR_TEAM_YELLOW)
   {
      return *IDMULT_YELLOW;
   }
}
function getKills(%player)
{
   if( %player.numKills != "")
      return %player.numKills;
   return "0";
}
$l = "Lost Match";
$a = "Active";
function getTeamKills(%team)
{
   if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_YELLOW )
   {
      if($yellowlost == 0)
	{
		return $a;
	}
	else
	{
		return $l;
	}
   }
   else   if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_RED )

   {
        if($redlost == 1)
	{
		return $l;
	}
	else
	{
		return $a;
	}
   }   
   else   if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_BLUE )

   {
       if($bluelost == 1)
	{
		return $l;
	}
	else
	{
		return $a;
	}
   }   
   else   if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_PURPLE )

   {
        if($purplelost == 1)
	{
		return $l;
	}
	else
	{
		return $a;
	}
    }   
}
function getBuildingstokill2(%team)
{
	if(getTeamNameFromTeamId(%team) == *IDSTR_TEAM_PURPLE)
	{
	        	if($purplebuildings == 8)
		  	{
				return "Eight (ALL)";
			}
	        	else if($purplebuildings == 7)
		  	{
				return "Seven";
			}
	        	else if($purplebuildings == 6)
		  	{
				return "Six";
			}
	        	else if($purplebuildings == 5)
		  	{
				return "Five";
			}
	        	else if($purplebuildings == 4)
		  	{
				return "FOUR";
			}
	        	else if($purplebuildings == 3)
		  	{
				return "THREE";
			}
	        	else if($purplebuildings == 2)
		  	{
				return "TWO";
			}
	        	else if($purplebuildings == 1)
		  	{
				return "ONE";
			}
	        	else if($purplebuildings == 0)
		  	{
				return "ZERO";
			}
	}
	else if(getTeamNameFromTeamId(%team) == *IDSTR_TEAM_BLUE)
	{
	        	if($bluebuildings == 8)
		  	{
				return "Eight (ALL)";
			}
	        	else if($bluebuildings == 7)
		  	{
				return "Seven";
			}
	        	else if($bluebuildings == 6)
		  	{
				return "Six";
			}
	        	else if($bluebuildings == 5)
		  	{
				return "Five";
			}
	        	else if($bluebuildings == 4)
		  	{
				return "FOUR";
			}
	        	else if($bluebuildings == 3)
		  	{
				return "THREE";
			}
	        	else if($bluebuildings == 2)
		  	{
				return "TWO";
			}
	        	else if($bluebuildings == 1)
		  	{
				return "ONE";
			}
	        	else if($bluebuildings == 0)
		  	{
				return "ZERO";
			}
	}
	else if(getTeamNameFromTeamId(%team) == *IDSTR_TEAM_RED)
	{
	        	if($redbuildings == 8)
		  	{
				return "Eight (ALL)";
			}
	        	else if($redbuildings == 7)
		  	{
				return "Seven";
			}
	        	else if($redbuildings == 6)
		  	{
				return "Six";
			}
	        	else if($redbuildings == 5)
		  	{
				return "Five";
			}
	        	else if($redbuildings == 4)
		  	{
				return "FOUR";
			}
	        	else if($redbuildings == 3)
		  	{
				return "THREE";
			}
	        	else if($redbuildings == 2)
		  	{
				return "TWO";
			}
	        	else if($redbuildings == 1)
		  	{
				return "ONE";
			}
	        	else if($redbuildings == 0)
		  	{
				return "ZERO";
			}
	}
	else if(getTeamNameFromTeamId(%team) == *IDSTR_TEAM_YELLOW)
	{
	        	if($yellowbuildings == 8)
		  	{
				return "Eight (ALL)";
			}
	        	else if($yellowbuildings == 7)
		  	{
				return "Seven";
			}
	        	else if($yellowbuildings == 6)
		  	{
				return "Six";
			}
	        	else if($yellowbuildings == 5)
		  	{
				return "Five";
			}
	        	else if($yellowbuildings == 4)
		  	{
				return "FOUR";
			}
	        	else if($yellowbuildings == 3)
		  	{
				return "THREE";
			}
	        	else if($yellowbuildings == 2)
		  	{
				return "TWO";
			}
	        	else if($yellowbuildings == 1)
		  	{
				return "ONE";
			}
	        	else if($yellowbuildings == 0)
		  	{
				return "ZERO";
			}
	}
}
function getTeamKills2(%team)
{
	if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_YELLOW )
 	{
      	return $yellowKills;
	}
 	else if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_RED )
  	{
      	return $redKills;
  	}   
 	else if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_BLUE )
  	{
      	return $blueKills;
  	}   

 	else if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_PURPLE )
  	{
      	return $purpleKills;
  	}   
}
function getBuildingsDestroyed(%player)
{
   if( %player.buildingsDestroyed != "")
      return %player.buildingsDestroyed;
   
   return "0";
}
function onMissionStart()
{
	$healRate = 120;   
	$ammoRate = 7;
 	$padWaitTime = 65;

	titanSounds();	

	makehercs();

   initGlobalVars();
	orderhercs();   
}
function orderhercs()
{
   order( $redHerc1, guard, $redHerc1Path );
   order( $redHerc2, guard, $redHerc2Path );
   order( $redHerc3, guard, $redHerc3Path );

   order( $yellowHerc1, guard, $yellowHerc1Path );
   order( $yellowHerc2, guard, $yellowHerc2Path );
   order( $yellowHerc3, guard, $yellowHerc3Path );

   order( $blueHerc1, guard, $blueHerc1Path );
   order( $blueHerc2, guard, $blueHerc2Path );
   order( $blueHerc3, guard, $blueHerc3Path );

   order( $purpleHerc1, guard, $purpleHerc1Path );
   order( $purpleHerc2, guard, $purpleHerc2Path );
   order( $purpleHerc3, guard, $purpleHerc3Path );

order( $yellowHerc1, speed , high );
order( $yellowHerc2, speed , medium );
order( $yellowHerc3, speed , low );
order( $redHerc1, speed , high );
order( $redHerc2, speed , medium );
order( $redHerc3, speed , low );
order( $blueHerc1, speed , high );
order( $blueHerc2, speed , medium );
order( $blueHerc3, speed , low );
order( $purpleHerc1, speed , high );
order( $purpleHerc2, speed , medium );
order( $purpleHerc3, speed , low );
}
function checkwin()
{
	if($redbuildings == 0) 
	{
		$redlost = 1;
		%los = "Red Team has been defeated!! Go back to earth imperial knights!";
		say(0, 0, %los);
	}
	if($yellowbuildings == 0) 
	{
		$yellowlost = 1;
		%los = "Yellow Team has been defeated!! Foolish Rebels!";
		say(0, 0, %los);
	}
	if($bluebuildings == 0) 
	{
		$bluelost = 1;
		%los = "Blue Team has been defeated!!  Giver-of-Will shall punish\\torture you!";
		say(0, 0, %los);
	}
	if($purplebuildings == 0) 
	{
		$purplelost = 1;
		%los = "Purple Team has been defeated!!  Metagen\\Bug-Thought has been purged\\deleted!";
		say(0, 0, %los);
	}
	checkwiners();
}

function checkwiners()
{
	if($purplelost == 1)
	{
		if($yellowlost == 1)
		{
			if($bluelost == 1)
			{
				redwin();
			}
		}
	}
	else if($redlost == 1)
	{
		if($purplelost == 1)
		{
			if($bluelost == 1)
			{
				yellowwin();
			}
		}
		else if($yellowlost == 1)
		{
			if($purplelost == 1)
			{
				bluewin();
			}
			else if($bluelost == 1)
			{
				purplewin();
			}
		}
	}
}
function redwin()
{
	%win = "Red Team has survived the war! Earth is safe! for now..";
      schedule( "missionEndConditionMet();", 20.8 );
	say(0, 0, %win);
	endturn();
}
function yellowwin()
{
	%win = "Yellow Team has survived the war! The colonies are free! I think...";
      schedule( "missionEndConditionMet();", 20.8 );
	say(0, 0, %win);
	endturn();
}
function bluewin()
{
	%win = "Blue Team has survived the war! Core-directive executed, Hurt\\Maim\\Kill.";
      schedule( "missionEndConditionMet();", 20.8 );
	say(0, 0, %win);
	endturn();
}
function purplewin()
{
	%win = "Purple Team has survived the war! Metagen <UNITS> celebrate!";
      schedule( "missionEndConditionMet();", 20.8 );
	say(0, 0, %win);
	endturn();
}
// Healing Pad Functionality
function ZenHeal::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);  
}
function ZenHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, 0, $padWaitTime, true); 
}
// Ammo Pad Functionality
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}
// ZenAll Pad Functionality
function ZenAll::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
}
function ZenAll::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, $ammoRate, $padWaitTime, true); 
}
//ARTILLERY TURRETS REACT TO SPOTTING! 
function rartAttack( %target ) 
{
	order($rart, shutdown, false);
	order($rart, Attack, %target);
	$rartilleryTarget = %target;
	reloadobject($rart, 1000);
}
function yartAttack( %target )
{
	order($yart, shutdown, false);
	order($yart, Attack, %target);
	$yartilleryTarget = %target;
	reloadobject($yart, 1000);
}
function bartAttack( %target )
{
	order($bart, shutdown, false);
	order($bart, Attack, %target);
	$bartilleryTarget = %target;
	reloadobject($bart, 1000);
}
function partAttack( %target )
{
	order($part, shutdown, false);
	order($part, Attack, %target);
	$partilleryTarget = %target;
	reloadobject($part, 1000);
}
function vehicle::onSpot(%spotter, %target) 
{
	%team = getteam(%spotter); 
	%check = getteam(%target);
   if(%target != " ")
   {
	if(%team == *IDSTR_TEAM_RED)
	{
		if($rcomndes == 0)
		{
			if(%check != %team) // dont use artillery on your own team...
			{
				rartAttack(%target);
			}
		}
		else if($rcomndes != 0)
		{
			%nono = "Communications Building Destroyed! Artillery offline.";
			say(%spotter, 0, %nono);
		}
	}
	if(%team == *IDSTR_TEAM_YELLOW)
	{
		if($ycomndes == 0)
		{
			if(%check != %team)
			{
				yartAttack(%target);
			}
		}
		else if($ycomndes != 0)
		{
			%nono = "Communications Building Destroyed! Artillery offline.";
			say(%spotter, 0, %nono);
		}
	}
	if(%team == *IDSTR_TEAM_BLUE)
	{
		if($bcomndes == 0)
		{
			if(%check != %team)
			{
				bartAttack(%target);
			}
		}
		else if($bcomndes != 0)
		{
			%nono = "Communications Building Destroyed! Artillery offline.";
			say(%spotter, 0, %nono);
		}
	}
	if(%team == *IDSTR_TEAM_PURPLE)
	{
		if($pcomndes == 0)
		{
			if(%check != %team)
			{
				partAttack(%target);
			}
		}
		else if($pcomndes != 0)
		{
			%nono = "Communications Building Destroyed! Artillery offline.";
			say(%spotter, 0, %nono);
		}
	}
    }
    if( (%target == " ") && ($artilleryTarget != " ") ) //no target
    {
		%fr = "Theres no target.";
	      say(%spotter, 0, %fr);
	  	if(%team == *IDSTR_TEAM_RED)
	  	{
			rartillerycleartarget();
	  	}
	  	else if(%team == *IDSTR_TEAM_YELLOW)
	  	{
			yartillerycleartarget();
		}
		else if(%team == *IDSTR_TEAM_BLUE)
	  	{
			bartillerycleartarget();
	  	}
	  	else if(%team == *IDSTR_TEAM_PURPLE)
	  	{
			partillerycleartarget();
	  	}
    } 
}
function yartilleryClearTarget()
{
    order($yart, Clear, True );
    $yartilleryTarget = " ";
    order($yart, shutdown, true);
}
function rartilleryClearTarget()
{
    order($rart, Clear, True );
    $rartilleryTarget = " ";
    order($rart, shutdown, true);
}
function bartilleryClearTarget()
{
    order($bart, Clear, True );
    $bartilleryTarget = " ";
    order($bart, shutdown, true);
}
function partilleryClearTarget()
{
    order($part, Clear, True );
    $partilleryTarget = " ";
    order($part, shutdown, true);
}
function arty::vehicle::onattacked(%this, %attacker) // artillery attack you if you shoot them, and they will respawn. if you want to destroy them go after the comn Building. even if the comn Building is destroyed, the artillery will still attack you if they are attacked. without the copmn building, the ltads doesnt work anymore for that team.
{
	reloadobject(%this, 100);
	healobject(%this, 500);
	%teama = getteam(%this);
	%teamb = getteam(%attacker);
	%art = gettargetofattackee(%this);
	if(%teama != %teamb)
	{
		if(%art == "")
		{
			order(%this, shutdown, false);
			order(%this, attack, %attacker);
     		      schedule("order(" @ %this @ ",shutdown, true);",10);
		}
		else if(%art != "")
		{
			reloadobject(%this, 100);
			order(%this, shutdown, false);
			order(%this, attack, %attacker);
     		      schedule("order(" @ %this @ ",attack," @ %art @ ");",10);
		}	
	}
}
function gettargetofattackee(%this)
{
	%team = getteam(%this);
	if(%team == *IDSTR_TEAM_RED)
	{
		return $rartilleryTarget;
	}
	else if(%team == *IDSTR_TEAM_YELLOW)
	{
		return $yartilleryTarget;
	}
	else if(%team == *IDSTR_TEAM_PURPLE)
	{
		return $partilleryTarget;
	}
	else if(%team == *IDSTR_TEAM_BLUE)
	{
		return $bartilleryTarget;
	}
}
function tur::turret::ondestroyed(%this, %destroyer)
{
        if(%this == $rartilleryTarget)
        {
            rartilleryClearTarget();
        }
        else if(%this == $yartilleryTarget)
        {
            yartilleryClearTarget();
        }
        else if(%this == $bartilleryTarget)
        {
            bartilleryClearTarget();
        }
        else if(%this == $partilleryTarget)
        {
            partilleryClearTarget();
        }
}
function tur::turret::onattacked(%this, %attacker)
{
	%say = "Artillery: We cannot get a lock on that target, you'll have to spot it for us again.";
	%teamuno = getteam(%attacker);
	%teamdos = getteam(%this);
	if(%attacker == $rart)
	{
		rartilleryClearTarget(); 
		say(%teamuno, 0, %say);
	}         
	else if(%attacker == $yart)
	{
		yartilleryClearTarget();
 		say(%teamuno, 0, %say);
      }         
	else if(%attacker == $bart)
	{
		bartilleryClearTarget();
 		say(%teamuno, 0, %say);
      }         
	else if(%attacker == $part)
	{
		partilleryClearTarget();
		say(%teamuno, 0, %say);
      }         
	if(%teamuno != %teamdos) 
	{
		order(%this, attack, %attacker);
	}
	healobject(%this, 1270);
}
function arty::vehicle::ondestroyed(%this, %destroyer)
{
	if(%this == $rart)
	{
		schedule( "trevorsCloneVehicle(\"$rart\", " @ %this @ ", 7330, -6070, 29);", 40);
		rartillerycleartarget();
		rartmes();
	}
	else if(%this == $yart)
	{
		schedule( "trevorsCloneVehicle(\"$yart\", " @ %this @ ", 10219, -5478, 34);", 40);
		yartillerycleartarget();
		yartmes();
	}
	else if(%this == $bart)
	{
		schedule( "trevorsCloneVehicle(\"$bart\", " @ %this @ ", 9392, -6991, 381);", 40);
		bartillerycleartarget();
		bartmes();
	}
	else if(%this == $part)
	{
		schedule( "trevorsCloneVehicle(\"$part\", " @ %this @ ", 7817, -3767, 79);", 40);
		partillerycleartarget();
		partmes();
	}
}
function rartmes()
{
	%mes = "Red Artillery Destroyed. Respawn in 40 seconds.";
	say(*IDSTR_TEAM_RED, *IDSTR_TEAM_RED, %mes);
	%mes2 = "Red Artillery Ready";
	schedule( "say( " @ *IDSTR_TEAM_RED @ ", " @ *IDSTR_TEAM_RED @ ", " @ %mes2 @ " );", 40 );
}
function yartmes()
{
	%mes = "Yellow Artillery Destroyed. Respawn in 40 seconds.";
	say(*IDSTR_TEAM_YELLOW, *IDSTR_TEAM_YELLOW, %mes);
	%mes2 = "Yellow Artillery Ready";
	schedule( "say( " @ *IDSTR_TEAM_YELLOW @ ", " @ *IDSTR_TEAM_YELLOW @ ", " @ %mes2 @ " );", 40 );
}
function bartmes()
{
	%mes = "Blue Artillery Destroyed. Respawn in 40 seconds.";
	say(*IDSTR_TEAM_BLUE, *IDSTR_TEAM_BLUE, %mes);
	%mes2 = "Blue Artillery Ready";
	schedule( "say( " @ *IDSTR_TEAM_BLUE @ ", " @ *IDSTR_TEAM_BLUE @ ", " @ %mes2 @ " );", 40 );
}
function partmes()
{
	%mes = "Purple Artillery Destroyed. Respawn in 40 seconds.";
	say(*IDSTR_TEAM_PURPLE, *IDSTR_TEAM_PURPLE, %mes);
	%mes2 = "Purple Artillery Ready";
	schedule( "say( " @ *IDSTR_TEAM_PURPLE @ ", " @ *IDSTR_TEAM_PURPLE @ ", " @ %mes2 @ " );", 40 );
}
// finally the end of the artillery script!!!! 
function trevorsCloneVehicle(%globalVarName, %old, %x, %y, %z)
{
   %clone = cloneVehicle(%old);
   setPosition(%clone, %x, %y, %z);
   schedule( "deleteObject(" @ %old @ ");", $respawnDelayNoHq + 50 );
   schedule( %globalVarName @ " = " @ %clone @ ";", 0);
   addToSet( "MissionGroup", %clone );
   %path = %globalVarName @ "Path";
   schedule( "order( " @ %clone @ ", guard, " @ %path @ " );", 1 );
}
function trevorsCloneVehicle2(%globalVarName, %old, %x, %y, %z)
{
   %clone = cloneVehicle(%old);
   setPosition(%clone, %x, %y, %z);
   %globalVarName = %clone;
   addToSet( "MissionGroup", %clone );
}
// when someone captures the starport, everyone else has to wait 15 seconds before they can recapture it for their teams.
$capwait = 0;
$captured = 0;
function capstar::trigger::onenter(%this, %object)
{
	if($capwait == 0)
	{
		%teamchange = getteam(%object);
		%check = getteam($st1);
		if(%teamchange != %check)
		{
			setteam($st1, %teamchange); // change the turrets to your team
			setteam($st2, %teamchange);	
			setteam($st3, %teamchange);
			setteam($st4, %teamchange);
			%cap = "<f5>" @ gethudname(%object) @ " captured the starport for " @ getteam(%object) @ ".";
			say(0, 0, %cap);
			changewait();
			$captured++;
			defenders(%teamchange);
		}
	}
}
function changewait()
{
	$capwait = $capwait + 1;
	schedule("changeback();", 25);
}
function changeback()
{
	$capwait = $capwait - 1;
}
function defenders(%team)
{
	if($captured >= 6)
	{
		$herc1 = getObjectId("missiongroup/starportstuff/Sherc1/herc1");
		$herc2 = getObjectId("missiongroup/starportstuff/Sherc2/herc1"); 
		$path1 = getObjectId("MissionGroup/Path");

		trevorsCloneVehicle2($herc1, $herc1, 8930, -5221, 155); // terran talon
		setTeam( $herc1, %team );
		order( $herc1, guard, $path1);

		trevorsCloneVehicle2($herc2, $herc2, 8267, -4167, 140); // knight's talon
		setTeam( $herc2, %team );
		order( $herc2, guard, $path1);
	}
}
// SENSORS > informs players if base is threatened
function psen::trigger::onenter(%this, %object)
{
	%t = getteam(%object);
	if(%t != *IDSTR_TEAM_PURPLE)
	{
			%mes = "Enemy in Purple Base.";
			say(*IDSTR_TEAM_PURPLE, *IDSTR_TEAM_PURPLE, %mes);
	}
}
function rsen::trigger::onenter(%this, %object)
{
	%t = getteam(%object);
	if(%t != *IDSTR_TEAM_RED)
	{
			%mes = "Enemy in Red Base.";
			say(*IDSTR_TEAM_RED, *IDSTR_TEAM_RED, %mes);
	}
}
function ysen::trigger::onenter(%this, %object)
{
	%t = getteam(%object);
	if(%t != *IDSTR_TEAM_YELLOW)
	{
			%mes = "Enemy in Yellow Base.";
			say(*IDSTR_TEAM_YELLOW, *IDSTR_TEAM_YELLOW, %mes);
	}
}
function bsen::trigger::onenter(%this, %object)
{
	%t = getteam(%object);
	if(%t != *IDSTR_TEAM_BLUE)
	{
			%mes = "Enemy in Blue Base.";
			say(*IDSTR_TEAM_BLUE, *IDSTR_TEAM_BLUE, %mes);
	}
}
// ------------------------------------------------------------------------------
// Sorry, there are no easter eggs on this map. Nope, none. Not even one. What are these you ask? Umm. My, err... um, my grocery list.
// ------------------------------------------------------------------------------
function help::trigger::oncontact(%this, %object) 
{						// Um, can you help me sir?? Would you teleport me to my nav point please?
	%markerId = getVehicleNavMarkerId(%object);
	getposition(%markerId, %x, %y, %z);
	setposition(%object, %x, %y, %z + 50);
	damageobject(%object, 4000);	// Thank you sir. How much do I owe you?
}
function tele::trigger::oncontact(%this, %object)
{
	setposition(%object, 5750, -5605, 200);
}
function tele2::trigger::oncontact(%this, %object)
{
	setposition(%object, 5740, -5585, 200);
}
