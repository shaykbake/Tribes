// FILENAME:	SS_X-Games.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Starsiege X-Games";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   temperateSounds();
   $vertGrind1E = getObjectId("Missiongroup\\VertGrind1E");
   $vertGrind1W = getObjectId("Missiongroup\\VertGrind1W");
   $vertGrind2E = getObjectId("Missiongroup\\VertGrind2E");
   $vertGrind2W = getObjectId("Missiongroup\\VertGrind2W");
   $vertGrind3E = getObjectId("Missiongroup\\VertGrind3E");
   $vertGrind3W = getObjectId("Missiongroup\\VertGrind3W");
   $vertGrind4E = getObjectId("Missiongroup\\VertGrind4E");
   $vertGrind4W = getObjectId("Missiongroup\\VertGrind4W");
   $railGrind1N = getObjectId("Missiongroup\\railGrind1N");
   $railGrind1S = getObjectId("Missiongroup\\railGrind1S");
   $boxGrind1E = getObjectId("Missiongroup\\BoxGrind1E");
   $boxGrind1W = getObjectId("Missiongroup\\BoxGrind1W");
   $boxGrind2E = getObjectId("Missiongroup\\BoxGrind2E");
   $boxGrind2W = getObjectId("Missiongroup\\BoxGrind2W");
   $StairGrind1 = getObjectId("Missiongroup\\StairGrind1");
}

function player::onAdd(%playerId)
{
   say(%playerId, 0, "Welcome to the Starsiege X-Games on ESPN2! You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %playerId.points = 0;
   %playerId.wipeoutNum = 0;
   %playerId.vehtype = "N/A";
}

function vehicle::onAdd(%vehicleId)
{
   %vehicleId.vehicle = getVehicleName(%vehicleId);
   %vehicleId.crash = false;
   %vehicleId.airtime = 0;
   %vehicleId.totalAirTime = 0;
   %vehicleId.contact = 0;
   %playerId = playerManager::vehicleIdToPlayerNum(%vehicleId);
   %playerId.vehtype = %vehicleId.vehicle;
   %playerId.verttoggle = "grind";
   %playerId.QPtoggle = "jump";
   %playerId.stunt = "ready";
   %playerId.stuntlock = "clear";
   
   //Easter Egg for Flyers
   //---------------------------------------------------
   if(getVehicleName(%vehicleId)=="Banshee")
   {
      order(%vehicleId, guard, $vertGrind1E);
   }
   else if(getVehicleName(%vehicleId)=="Knight's Banshee")
   {
      order(%vehicleId, guard, $vertGrind1E);
   }
   else if(getVehicleName(%vehicleId)=="Advocate")
   {
      order(%vehicleId, guard, $vertGrind1E);
   }
}

function onMissionLoad()
{
   cdAudioCycle("Terror", "Newtech", "Mechsoul");
   setGameInfo("<F2>GAME TYPE:<F0>  Starsiege X-Games\n\n<F2>RULES:<F0>\n\nWelcome to the Starsiege X-Games on ESPN2! Run up ramps and jump on grind rails to pull off stunts. The better the stunt, the more points you score. You can also score points for Half-Pipe Transfers, Airtime, and Trick Combos. Scan the target drone balls to toggle the Vert & Quarter Pipe ramps from Big Air Mode to Grind Mode. The rules are: THERE ARE NO RULES!!!\n\n<F2>DOWNLOAD STUFF:<F0>\n\nYou can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net."); 
   
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %playerId = playerManager::getPlayerNum(%i);
      %playerId.points = 0;
      %playerId.wipeoutNum = 0;
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   //Blank function to disable deathmessages
}

function VertToggle::structure::onScan(%scanned, %scanner)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%scanner);
   if(%playerId.verttoggle=="jump")
   {
      %playerId.verttoggle = "grind";
      say(%playerId, %playerId, "<F1>Vert grind session in progress!");
   }
   else if(%playerId.verttoggle=="grind")
   {
      %playerId.verttoggle = "jump";
      say(%playerId, %playerId, "<F1>Vert big air mode activated!");
   }
}

function QPToggle::structure::onScan(%scanned, %scanner)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%scanner);
   if(%playerId.QPtoggle=="jump")
   {
      %playerId.QPtoggle = "grind";
      say(%playerId, %playerId, "<F1>Quarter Pipe grind session in progress!");
   }
   else if(%playerId.QPtoggle=="grind")
   {
      %playerId.QPtoggle = "jump";
      say(%playerId, %playerId, "<F1>Quarter Pipe big air mode activated!");
   }
}

function Vert1E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %object.wipeout = randomInt(0,14);
      if(%object.wipeout==0)
      {
         %object.crash = true;
         if(%playerId.verttoggle=="jump")
         {
            vertJump1Wipeout(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind1EWipeout(%object);
         }
      }
      else
      {
         %object.crash = false;
         if(%playerId.verttoggle=="jump")
         {
            vertJump1(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind1E(%object);
         }
      }
   }
}

function Vert1W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %object.wipeout = randomInt(0,14);
      if(%object.wipeout==0)
      {
         %object.crash = true;
         if(%playerId.verttoggle=="jump")
         {
            vertJump1Wipeout(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind1WWipeout(%object);
         }
      }
      else
      {
         %object.crash = false;
         if(%playerId.verttoggle=="jump")
         {
            vertJump1(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind1W(%object);
         }
      }
   }
}

function Vert2E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %randomTransfer = randomInt(0,4);
      if(%randomTransfer==0)
      {
         if(%playerId.verttoggle=="jump")
         {
            VertTransferJumpSouth(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            VertTransferGrindSouthE(%object);
         }
      }
      else if(%randomTransfer>0)
      {
         %object.wipeout = randomInt(0,14);
         if(%object.wipeout==0)
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump2(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = true;
               vertGrind2EWipeout(%object);
            }
         }
         else
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump2(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = false;
               vertGrind2E(%object);
            }
         }
      }
   }
}

function Vert2W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %randomTransfer = randomInt(0,4);
      if(%randomTransfer==0)
      {
         if(%playerId.verttoggle=="jump")
         {
            VertTransferJumpSouth(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            VertTransferGrindSouthW(%object);
         }
      }
      else if(%randomTransfer>0)
      {
         %object.wipeout = randomInt(0,14);
         if(%object.wipeout==0)
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump2(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = true;
               vertGrind2WWipeout(%object);
            }
         }
         else
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump2(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = false;
               vertGrind2W(%object);
            }
         }
      }
   }
}

function Vert3E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %randomTransfer = randomInt(0,4);
      if(%randomTransfer==0)
      {
         if(%playerId.verttoggle=="jump")
         {
            VertTransferJumpNorth(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            VertTransferGrindNorthE(%object);
         }
      }
      else if(%randomTransfer>0)
      {
         %object.wipeout = randomInt(0,14);
         if(%object.wipeout==0)
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump3(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = true;
               vertGrind3EWipeout(%object);
            }
         }
         else
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump3(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = false;
               vertGrind3E(%object);
            }
         }
      }
   }
}

function Vert3W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %randomTransfer = randomInt(0,4);
      if(%randomTransfer==0)
      {
         if(%playerId.verttoggle=="jump")
         {
            VertTransferJumpNorth(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            VertTransferGrindNorthW(%object);
         }
      }
      else if(%randomTransfer>0)
      {
         %object.wipeout = randomInt(0,14);
         if(%object.wipeout==0)
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump3(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = true;
               vertGrind3WWipeout(%object);
            }
         }
         else
         {
            if(%playerId.verttoggle=="jump")
            {
               %object.crash = false;
               vertJump3(%object);
            }
            else if(%playerId.verttoggle=="grind")
            {
               %object.crash = false;
               vertGrind3W(%object);
            }
         }
      }
   }
}

function Vert4E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %object.wipeout = randomInt(0,14);
      if(%object.wipeout==0)
      {
         %object.crash = true;
         if(%playerId.verttoggle=="jump")
         {
            vertJump4Wipeout(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind4EWipeout(%object);
         }
      }
      else
      {
         %object.crash = false;
         if(%playerId.verttoggle=="jump")
         {
            vertJump4(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind4E(%object);          
         }
      }
   }
}

function Vert4W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %object.wipeout = randomInt(0,14);
      if(%object.wipeout==0)
      {
         %object.crash = true;
         if(%playerId.verttoggle=="jump")
         {
            vertJump4Wipeout(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind4WWipeout(%object);
         }
      }
      else
      {
         %object.crash = false;
         if(%playerId.verttoggle=="jump")
         {
            vertJump4(%object);
         }
         else if(%playerId.verttoggle=="grind")
         {
            vertGrind4W(%object);          
         }
      }
   }
}

function vertGrind1E(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,2);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind1E);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind1ECount(" @ %object @ ");",0.6);
}

function vertGrind1EWipeout(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind1E);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind1ECount(" @ %object @ ");",0.6);
}

function vertGrind1W(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,2);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind1W);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind1WCount(" @ %object @ ");",0.6);
}

function vertGrind1WWipeout(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind1W);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind1WCount(" @ %object @ ");",0.6);
}

function vertGrind2E(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,2);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind2E);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind2ECount(" @ %object @ ");",0.6);
}

function vertGrind2EWipeout(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind2E);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind2ECount(" @ %object @ ");",0.6);
}

function vertGrind2W(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,5);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind2W);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind2WCount(" @ %object @ ");",0.6);
}

function vertGrind2WWipeout(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind2W);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind2WCount(" @ %object @ ");",0.6);
}

function vertGrind3E(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,2);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind3E);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind3ECount(" @ %object @ ");",0.6);
}

function vertGrind3EWipeout(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind3E);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind3ECount(" @ %object @ ");",0.6);
}

function vertGrind3W(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,2);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind3W);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind3WCount(" @ %object @ ");",0.6);
}

function vertGrind3WWipeout(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind3W);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind3WCount(" @ %object @ ");",0.6);
}

function vertGrind4E(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,2);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind4E);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind4ECount(" @ %object @ ");",0.6);
}

function vertGrind4EWipeout(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind4E);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind4ECount(" @ %object @ ");",0.6);
}

function vertGrind4W(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.randomtype = randomInt(0,5);
   if(%object.randomtype==0)
   {
      %object.stunttype = "Front-Side Nose";
      %object.grindvalue = 300;
   }
   else if(%object.randomtype==1)
   {
      %object.stunttype = "Dark-Slide";
      %object.grindvalue = 250;
   }
   else if(%object.randomtype==2)
   {
      %object.stunttype = "Back-Side Tail";
      %object.grindvalue = 200;
   }
   else if(%object.randomtype==3)
   {
      %object.stunttype = "Back-Side";
      %object.grindvalue = 150;
   }
   else if(%object.randomtype==4)
   {
      %object.stunttype = "50/50";
      %object.grindvalue = 100;
   }
   else if(%object.randomtype==5)
   {
      %object.stunttype = "Smith";
      %object.grindvalue = 50;
   }
   %object.integer = randomInt(4,10);
   %object.percent = (%object.integer * 0.1);
   %object.grindtotal = (%object.grindvalue * %object.percent) + 0.001;
   %object.distance = getDistance(%object, $vertGrind4W);
   %object.grindlength = (%object.distance * %object.percent);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind4WCount(" @ %object @ ");",0.6);
}

function vertGrind4WWipeout(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind4W);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / 10);
   schedule("vertGrind4WCount(" @ %object @ ");",0.6);
}

function vertGrind1ECount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindEast(%object);
         schedule("GrindEast(" @ %object @ ");",0.1);
         schedule("GrindEast(" @ %object @ ");",0.2);
         schedule("GrindEast(" @ %object @ ");",0.3);
         schedule("fallEast30(" @ %object @ ");",0.4);
         schedule("fallEast30(" @ %object @ ");",0.5);
         schedule("fallEast45(" @ %object @ ");",0.6);
         schedule("fallEast45(" @ %object @ ");",0.7);
         schedule("fallEast60(" @ %object @ ");",0.8);
         schedule("fallEast60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind1E(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("vertGrind1ECount(" @ %object @ ");", 0.1);
   }
}

function vertGrind1WCount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindWest(%object);
         schedule("grindWest(" @ %object @ ");",0.1);
         schedule("grindWest(" @ %object @ ");",0.2);
         schedule("grindWest(" @ %object @ ");",0.3);
         schedule("fallWest30(" @ %object @ ");",0.4);
         schedule("fallWest30(" @ %object @ ");",0.5);
         schedule("fallWest45(" @ %object @ ");",0.6);
         schedule("fallWest45(" @ %object @ ");",0.7);
         schedule("fallWest60(" @ %object @ ");",0.8);
         schedule("fallWest60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind1W(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("vertGrind1WCount(" @ %object @ ");", 0.1);
   }
}

function vertGrind2ECount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindEast(%object);
         schedule("GrindEast(" @ %object @ ");",0.1);
         schedule("GrindEast(" @ %object @ ");",0.2);
         schedule("GrindEast(" @ %object @ ");",0.3);
         schedule("fallEast30(" @ %object @ ");",0.4);
         schedule("fallEast30(" @ %object @ ");",0.5);
         schedule("fallEast45(" @ %object @ ");",0.6);
         schedule("fallEast45(" @ %object @ ");",0.7);
         schedule("fallEast60(" @ %object @ ");",0.8);
         schedule("fallEast60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind2E(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("vertGrind2ECount(" @ %object @ ");", 0.1);
   }
}

function vertGrind2WCount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindWest(%object);
         schedule("grindWest(" @ %object @ ");",0.1);
         schedule("grindWest(" @ %object @ ");",0.2);
         schedule("grindWest(" @ %object @ ");",0.3);
         schedule("fallWest30(" @ %object @ ");",0.4);
         schedule("fallWest30(" @ %object @ ");",0.5);
         schedule("fallWest45(" @ %object @ ");",0.6);
         schedule("fallWest45(" @ %object @ ");",0.7);
         schedule("fallWest60(" @ %object @ ");",0.8);
         schedule("fallWest60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind2W(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("vertGrind2WCount(" @ %object @ ");", 0.1);
   }
}

function vertGrind3ECount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindEast(%object);
         schedule("GrindEast(" @ %object @ ");",0.1);
         schedule("GrindEast(" @ %object @ ");",0.2);
         schedule("GrindEast(" @ %object @ ");",0.3);
         schedule("fallEast30(" @ %object @ ");",0.4);
         schedule("fallEast30(" @ %object @ ");",0.5);
         schedule("fallEast45(" @ %object @ ");",0.6);
         schedule("fallEast45(" @ %object @ ");",0.7);
         schedule("fallEast60(" @ %object @ ");",0.8);
         schedule("fallEast60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind3E(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("vertGrind3ECount(" @ %object @ ");", 0.1);
   }
}

function vertGrind3WCount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindWest(%object);
         schedule("grindWest(" @ %object @ ");",0.1);
         schedule("grindWest(" @ %object @ ");",0.2);
         schedule("grindWest(" @ %object @ ");",0.3);
         schedule("fallWest30(" @ %object @ ");",0.4);
         schedule("fallWest30(" @ %object @ ");",0.5);
         schedule("fallWest45(" @ %object @ ");",0.6);
         schedule("fallWest45(" @ %object @ ");",0.7);
         schedule("fallWest60(" @ %object @ ");",0.8);
         schedule("fallWest60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind3W(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("vertGrind3WCount(" @ %object @ ");", 0.1);
   }
}

function vertGrind4ECount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindEast(%object);
         schedule("GrindEast(" @ %object @ ");",0.1);
         schedule("GrindEast(" @ %object @ ");",0.2);
         schedule("GrindEast(" @ %object @ ");",0.3);
         schedule("fallEast30(" @ %object @ ");",0.4);
         schedule("fallEast30(" @ %object @ ");",0.5);
         schedule("fallEast45(" @ %object @ ");",0.6);
         schedule("fallEast45(" @ %object @ ");",0.7);
         schedule("fallEast60(" @ %object @ ");",0.8);
         schedule("fallEast60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind4E(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("vertGrind4ECount(" @ %object @ ");", 0.1);
   }
}

function vertGrind4WCount(%object)
{
   if(%object.grindNum<1)
   {
      if(%object.wipeout==0)
      {
         grindWest(%object);
         schedule("grindWest(" @ %object @ ");",0.1);
         schedule("grindWest(" @ %object @ ");",0.2);
         schedule("grindWest(" @ %object @ ");",0.3);
         schedule("fallWest30(" @ %object @ ");",0.4);
         schedule("fallWest30(" @ %object @ ");",0.5);
         schedule("fallWest45(" @ %object @ ");",0.6);
         schedule("fallWest45(" @ %object @ ");",0.7);
         schedule("fallWest60(" @ %object @ ");",0.8);
         schedule("fallWest60(" @ %object @ ");",0.9);
         schedule("Wipeout(" @ %object @ ");",1);
      }
      else
      {
         stopVertGrind4W(%object);
      }
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("vertGrind4WCount(" @ %object @ ");", 0.1);
   }
}

function stopVertGrind1E(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindSouth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind1W(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindSouth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind2E(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindNorth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind2W(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindNorth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind3E(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindSouth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind3W(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindSouth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind4E(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindNorth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function stopVertGrind4W(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   grindNorth(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.integer @ "0% " @ %object.stunttype @ " Grind! (" @ %object.grindtotal @ " points)");
   %playerId.points = %playerId.points + %object.grindtotal;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function vertJump1(%object)
{
   %object.vertside = 1;
   %object.height = randomInt(4,12);
   %object.heightmeters = %object.height @ "0";
   %object.heightscore = (%object.heightmeters * 2);
   jumpNorth45(%object);
   schedule("jumpNorth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth45(" @ %object @ ");",0.3);
   schedule("jumpHeight(" @ %object @ ");",0.4);
}

function vertJump1Wipeout(%object)
{
   %object.vertside = 1;
   %object.height = 12;
   jumpNorth45(%object);
   schedule("jumpNorth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth45(" @ %object @ ");",0.3);
   schedule("jumpHeight(" @ %object @ ");",0.4);
}

function vertJump2(%object)
{
   %object.vertside = 2;
   %object.height = randomInt(4,12);
   %object.heightmeters = %object.height @ "0";
   %object.heightscore = (%object.heightmeters * 2);
   jumpSouth45(%object);
   schedule("jumpSouth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpSouth45(" @ %object @ ");",0.3);
   schedule("jumpHeight(" @ %object @ ");",0.4);   
}

function vertJump3(%object)
{
   %object.vertside = 1;
   %object.height = randomInt(4,12);
   %object.heightmeters = %object.height @ "0";
   %object.heightscore = (%object.heightmeters * 2);
   jumpNorth45(%object);
   schedule("jumpNorth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth45(" @ %object @ ");",0.3);
   schedule("jumpHeight(" @ %object @ ");",0.4);
}

function vertJump4(%object)
{
   %object.vertside = 2;
   %object.height = randomInt(4,12);
   %object.heightmeters = %object.height @ "0";
   %object.heightscore = (%object.heightmeters * 2);
   jumpSouth45(%object);
   schedule("jumpSouth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpSouth45(" @ %object @ ");",0.3);
   schedule("jumpHeight(" @ %object @ ");",0.4);   
}

function vertJump4Wipeout(%object)
{
   %object.vertside = 2;
   %object.height = 12;
   jumpSouth45(%object);
   schedule("jumpSouth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpSouth45(" @ %object @ ");",0.3);
   schedule("jumpHeight(" @ %object @ ");",0.4);
}

function jumpHeight(%object)
{
   if(%object.height<1)
   {
      if(%object.crash==true)
      {
         if(%object.vertside==1)
         {
            jumpNorth60(%object);
            schedule("jumpNorth60(" @ %object @ ");",0.1);
            schedule("jumpNorth45(" @ %object @ ");",0.2);
            schedule("jumpNorth30(" @ %object @ ");",0.3);
            schedule("grindNorth(" @ %object @ ");",0.4);
            schedule("fallNorth30(" @ %object @ ");",0.5);
            schedule("fallNorth45(" @ %object @ ");",0.6);
            schedule("fallNorth60(" @ %object @ ");",0.7);
            schedule("fallNorth60(" @ %object @ ");",0.8);
            schedule("goDown(" @ %object @ ");",0.9);
            schedule("goDown(" @ %object @ ");",1);
            schedule("goDown(" @ %object @ ");",1.1);
            schedule("goDown(" @ %object @ ");",1.2);
            schedule("goDown(" @ %object @ ");",1.3);
            schedule("goDown(" @ %object @ ");",1.4);
            schedule("goDown(" @ %object @ ");",1.5);
            schedule("goDown(" @ %object @ ");",1.6);
            schedule("goDown(" @ %object @ ");",1.7);
            schedule("goDown(" @ %object @ ");",1.8);
            schedule("goDown(" @ %object @ ");",1.9);
            schedule("goDown(" @ %object @ ");",2);
            schedule("goDown(" @ %object @ ");",2.1);
            schedule("goDown(" @ %object @ ");",2.2);
            schedule("goDown(" @ %object @ ");",2.3);
            schedule("goDown(" @ %object @ ");",2.4);
            schedule("goDown(" @ %object @ ");",2.5);
            schedule("goDown(" @ %object @ ");",2.6);
         }
         else if(%object.vertside==2)
         {
            jumpSouth60(%object);
            schedule("jumpSouth60(" @ %object @ ");",0.1);
            schedule("jumpSouth45(" @ %object @ ");",0.2);
            schedule("jumpSouth30(" @ %object @ ");",0.3);
            schedule("grindSouth(" @ %object @ ");",0.4);
            schedule("fallSouth30(" @ %object @ ");",0.5);
            schedule("fallSouth45(" @ %object @ ");",0.6);
            schedule("fallSouth60(" @ %object @ ");",0.7);
            schedule("fallSouth60(" @ %object @ ");",0.8);
            schedule("goDown(" @ %object @ ");",0.9);
            schedule("goDown(" @ %object @ ");",1);
            schedule("goDown(" @ %object @ ");",1.1);
            schedule("goDown(" @ %object @ ");",1.2);
            schedule("goDown(" @ %object @ ");",1.3);
            schedule("goDown(" @ %object @ ");",1.4);
            schedule("goDown(" @ %object @ ");",1.5);
            schedule("goDown(" @ %object @ ");",1.6);
            schedule("goDown(" @ %object @ ");",1.7);
            schedule("goDown(" @ %object @ ");",1.8);
            schedule("goDown(" @ %object @ ");",1.9);
            schedule("goDown(" @ %object @ ");",2);
            schedule("goDown(" @ %object @ ");",2.1);
            schedule("goDown(" @ %object @ ");",2.2);
            schedule("goDown(" @ %object @ ");",2.3);
            schedule("goDown(" @ %object @ ");",2.4);
            schedule("goDown(" @ %object @ ");",2.5);
            schedule("goDown(" @ %object @ ");",2.6);
         }
         schedule("Wipeout(" @ %object @ ");",2.7);
      }
      else if(%object.crash==false)
      {
         stopJumpHeight(%object);
      }
   }
   else
   {
      %object.height--;
      goUp(%object);
      schedule("jumpHeight(" @ %object @ ");", 0.1);
   }
}

function stopJumpHeight(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   if(%object.vertside==1)
   {
      grindSouth(%object);
   }
   else if(%object.vertside==2)
   {
      grindNorth(%object);
   }
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.heightmeters @ " meters in the air! (" @ %object.heightscore @ " points)");
   %playerId.points = %playerId.points + %object.heightscore;
   schedule("stuntReady(" @ %playerId @ ");",6);
}

function VertTransfer::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %stunttype = randomInt(0,8);
      if(%stunttype<2)
      {
         vertTransferGrind(%object);
      }
      else if((%stunttype>1)&&(%stunttype<5))
      {
         vertTransfer(%object);
      }
      else if((%stunttype>4)&&(%stunttype<9))
      {
         vertJump1(%object);
      }
   }
}

function vertTransfer(%object)
{
   jumpNorth45(%object);
   schedule("jumpNorth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth45(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("goUp(" @ %object @ ");",0.5);
   schedule("goUp(" @ %object @ ");",0.6);
   schedule("goUp(" @ %object @ ");",0.7);
   schedule("jumpWest60(" @ %object @ ");",0.8);
   schedule("jumpWest60(" @ %object @ ");",0.9);
   schedule("jumpWest45(" @ %object @ ");",1);
   schedule("jumpWest45(" @ %object @ ");",1.1);
   schedule("jumpWest30(" @ %object @ ");",1.2);
   schedule("jumpWest30(" @ %object @ ");",1.3);
   schedule("grindWest(" @ %object @ ");",1.4);
   schedule("grindWest(" @ %object @ ");",1.5);
   schedule("grindWest(" @ %object @ ");",1.6);   
   schedule("grindWest(" @ %object @ ");",1.7);   
   schedule("grindWest(" @ %object @ ");",1.8);   
   schedule("grindWest(" @ %object @ ");",1.9);      
   schedule("FallWest30(" @ %object @ ");",2);
   schedule("FallWest30(" @ %object @ ");",2.1);
   schedule("FallWest45(" @ %object @ ");",2.2);
   schedule("FallWest45(" @ %object @ ");",2.3);
   schedule("FallWest60(" @ %object @ ");",2.4);
   schedule("FallWest60(" @ %object @ ");",2.5);
   schedule("goDown(" @ %object @ ");",2.6);
   schedule("goDown(" @ %object @ ");",2.7);
   schedule("goDown(" @ %object @ ");",2.8);
   schedule("goDown(" @ %object @ ");",2.9);
   schedule("grindSouth(" @ %object @ ");",3.0);
   schedule("stopVertTransfer(" @ %object @ ");",3.1);                                                
}

function vertTransferGrind(%object)
{
   jumpNorth45(%object);
   schedule("jumpNorth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth45(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("goUp(" @ %object @ ");",0.5);
   schedule("goUp(" @ %object @ ");",0.6);
   schedule("goUp(" @ %object @ ");",0.7);
   schedule("jumpWest60(" @ %object @ ");",0.8);
   schedule("jumpWest60(" @ %object @ ");",0.9);
   schedule("jumpWest45(" @ %object @ ");",1);
   schedule("jumpWest45(" @ %object @ ");",1.1);
   schedule("jumpWest30(" @ %object @ ");",1.2);
   schedule("jumpWest30(" @ %object @ ");",1.3);
   schedule("grindWest(" @ %object @ ");",1.4);
   schedule("grindWest(" @ %object @ ");",1.5);
   schedule("grindWest(" @ %object @ ");",1.6);   
   schedule("grindWest(" @ %object @ ");",1.7);   
   schedule("grindWest(" @ %object @ ");",1.8);   
   schedule("grindWest(" @ %object @ ");",1.9);      
   schedule("FallWest30(" @ %object @ ");",2);
   schedule("FallWest30(" @ %object @ ");",2.1);
   schedule("FallWest45(" @ %object @ ");",2.2);
   schedule("FallWest45(" @ %object @ ");",2.3);
   schedule("FallWest60(" @ %object @ ");",2.4);
   schedule("FallWest60(" @ %object @ ");",2.5);
   schedule("goDown(" @ %object @ ");",2.6);
   schedule("goDown(" @ %object @ ");",2.7);
   schedule("goDown(" @ %object @ ");",2.8);
   schedule("goNorth(" @ %object @ ");",2.9);
   schedule("grindWest(" @ %object @ ");",3.0);
   schedule("grindWest(" @ %object @ ");",3.1);
   schedule("grindWest(" @ %object @ ");",3.2);
   schedule("grindWest(" @ %object @ ");",3.3);
   schedule("grindWest(" @ %object @ ");",3.4);
   schedule("grindWest(" @ %object @ ");",3.5);
   schedule("grindWest(" @ %object @ ");",3.6);
   schedule("grindWest(" @ %object @ ");",3.7);
   schedule("grindWest(" @ %object @ ");",3.8);
   schedule("grindWest(" @ %object @ ");",3.9);
   schedule("grindWest(" @ %object @ ");",4.0);
   schedule("grindWest(" @ %object @ ");",4.1);
   schedule("grindWest(" @ %object @ ");",4.2);
   schedule("grindWest(" @ %object @ ");",4.3);
   schedule("grindWest(" @ %object @ ");",4.4);
   schedule("grindWest(" @ %object @ ");",4.5);
   schedule("grindWest(" @ %object @ ");",4.6);
   schedule("grindSouth(" @ %object @ ");",4.7);
   schedule("stopVertTransferGrind(" @ %object @ ");",4.8);                                                
}

function stopVertTransfer(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - HP Transfer! (300 points)");
   %playerId.points = %playerId.points + 300;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",5);
}

function stopVertTransferGrind(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - HP Transfer + Dark-Slide Grind! (500 points)");
   %playerId.points = %playerId.points + 500;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function VertTransferJumpSouth(%object)
{
   jumpSouth45(%object);
   schedule("jumpSouth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpSouth45(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("goUp(" @ %object @ ");",0.5);
   schedule("goUp(" @ %object @ ");",0.6);
   schedule("goUp(" @ %object @ ");",0.7);
   schedule("goUp(" @ %object @ ");",0.8);
   schedule("goUp(" @ %object @ ");",0.9);
   schedule("goUp(" @ %object @ ");",1);
   schedule("goUp(" @ %object @ ");",1.1);
   schedule("goUp(" @ %object @ ");",1.2);
   schedule("goUp(" @ %object @ ");",1.3);
   schedule("jumpSouth60(" @ %object @ ");",1.4);
   schedule("jumpSouth45(" @ %object @ ");",1.5);
   schedule("grindSouth(" @ %object @ ");",1.6);
   schedule("FallSouth45(" @ %object @ ");",1.7);
   schedule("FallSouth60(" @ %object @ ");",1.8);
   schedule("goDown(" @ %object @ ");",1.9);
   schedule("goDown(" @ %object @ ");",2);
   schedule("goDown(" @ %object @ ");",2.1);
   schedule("goDown(" @ %object @ ");",2.2);
   schedule("goDown(" @ %object @ ");",2.3);
   schedule("goDown(" @ %object @ ");",2.4);
   schedule("goDown(" @ %object @ ");",2.5);
   schedule("goDown(" @ %object @ ");",2.6);
   schedule("goDown(" @ %object @ ");",2.7);
   schedule("goDown(" @ %object @ ");",2.8);
   schedule("stopVertTransferJump(" @ %object @ ");",2.9);
}

function VertTransferJumpNorth(%object)
{
   jumpNorth45(%object);
   schedule("jumpNorth45(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth45(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("goUp(" @ %object @ ");",0.5);
   schedule("goUp(" @ %object @ ");",0.6);
   schedule("goUp(" @ %object @ ");",0.7);
   schedule("goUp(" @ %object @ ");",0.8);
   schedule("goUp(" @ %object @ ");",0.9);
   schedule("goUp(" @ %object @ ");",1);
   schedule("goUp(" @ %object @ ");",1.1);
   schedule("goUp(" @ %object @ ");",1.2);
   schedule("goUp(" @ %object @ ");",1.3);
   schedule("jumpNorth60(" @ %object @ ");",1.4);
   schedule("jumpNorth45(" @ %object @ ");",1.5);
   schedule("grindNorth(" @ %object @ ");",1.6);
   schedule("FallNorth45(" @ %object @ ");",1.7);
   schedule("FallNorth60(" @ %object @ ");",1.8);
   schedule("goDown(" @ %object @ ");",1.9);
   schedule("goDown(" @ %object @ ");",2);
   schedule("goDown(" @ %object @ ");",2.1);
   schedule("goDown(" @ %object @ ");",2.2);
   schedule("goDown(" @ %object @ ");",2.3);
   schedule("goDown(" @ %object @ ");",2.4);
   schedule("goDown(" @ %object @ ");",2.5);
   schedule("goDown(" @ %object @ ");",2.6);
   schedule("goDown(" @ %object @ ");",2.7);
   schedule("goDown(" @ %object @ ");",2.8);
   schedule("stopVertTransferJump(" @ %object @ ");",2.9);
}

function stopVertTransferJump(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - HP Transfer! (300 points)");
   %playerId.points = %playerId.points + 300;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function VertTransferGrindSouthE(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind2E);
   %object.grindlength = (%object.distance / 2);
   %object.grindNum = (%object.grindlength / 10);
   schedule("VertTransferGrindSouthECount1(" @ %object @ ");",0.6);
}

function VertTransferGrindSouthECount1(%object)
{
   if(%object.grindNum<1)
   {
      ContVertTransferGrindSouthE(%object);
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("VertTransferGrindSouthECount1(" @ %object @ ");", 0.1);
   }
}

function ContVertTransferGrindSouthE(%object)
{
   %object.grindNum = (%object.grindlength / 10);
   goUp(%object);
   schedule("goUp(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpSouth60(" @ %object @ ");",0.3);
   schedule("jumpSouth30(" @ %object @ ");",0.4);
   schedule("grindSouth(" @ %object @ ");",0.5);
   schedule("FallSouth30(" @ %object @ ");",0.6);
   schedule("FallSouth60(" @ %object @ ");",0.7);
   schedule("goDown(" @ %object @ ");",0.8);
   schedule("goDown(" @ %object @ ");",0.9);
   schedule("goDownSlow(" @ %object @ ");",1);
   schedule("VertTransferGrindSouthECount2(" @ %object @ ");",1.1);
}

function VertTransferGrindSouthECount2(%object)
{
   if(%object.grindNum<1)
   {
      stopVertTransferGrindSouthE(%object);
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("VertTransferGrindSouthECount2(" @ %object @ ");", 0.1);
   }
}

function stopVertTransferGrindSouthE(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Grind + HP Transfer + Grind! (500 points)");
   %playerId.points = %playerId.points + 500;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function VertTransferGrindSouthW(%object)
{
   goUp(%object);
   schedule("GrindSouth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindSouth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoSouth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind2W);
   %object.grindlength = (%object.distance / 2);
   %object.grindNum = (%object.grindlength / 10);
   schedule("VertTransferGrindSouthWCount1(" @ %object @ ");",0.6);
}

function VertTransferGrindSouthWCount1(%object)
{
   if(%object.grindNum<1)
   {
      ContVertTransferGrindSouthW(%object);
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("VertTransferGrindSouthWCount1(" @ %object @ ");", 0.1);
   }
}

function ContVertTransferGrindSouthW(%object)
{
   %object.grindNum = (%object.grindlength / 10);
   goUp(%object);
   schedule("goUp(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpSouth60(" @ %object @ ");",0.3);
   schedule("jumpSouth30(" @ %object @ ");",0.4);
   schedule("grindSouth(" @ %object @ ");",0.5);
   schedule("FallSouth30(" @ %object @ ");",0.6);
   schedule("FallSouth60(" @ %object @ ");",0.7);
   schedule("goDown(" @ %object @ ");",0.8);
   schedule("goDown(" @ %object @ ");",0.9);
   schedule("goDownSlow(" @ %object @ ");",1);
   schedule("VertTransferGrindSouthWCount2(" @ %object @ ");",1.1);
}

function VertTransferGrindSouthWCount2(%object)
{
   if(%object.grindNum<1)
   {
      stopVertTransferGrindSouthW(%object);
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("VertTransferGrindSouthWCount2(" @ %object @ ");", 0.1);
   }
}

function stopVertTransferGrindSouthW(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Grind + HP Transfer + Grind! (500 points)");
   %playerId.points = %playerId.points + 500;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function VertTransferGrindNorthE(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind3E);
   %object.grindlength = (%object.distance / 2);
   %object.grindNum = (%object.grindlength / 10);
   schedule("VertTransferGrindNorthECount1(" @ %object @ ");",0.6);
}

function VertTransferGrindNorthECount1(%object)
{
   if(%object.grindNum<1)
   {
      ContVertTransferGrindNorthE(%object);
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("VertTransferGrindNorthECount1(" @ %object @ ");", 0.1);
   }
}

function ContVertTransferGrindNorthE(%object)
{
   %object.grindNum = (%object.grindlength / 10);
   goUp(%object);
   schedule("goUp(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth60(" @ %object @ ");",0.3);
   schedule("jumpNorth30(" @ %object @ ");",0.4);
   schedule("grindNorth(" @ %object @ ");",0.5);
   schedule("FallNorth30(" @ %object @ ");",0.6);
   schedule("FallNorth60(" @ %object @ ");",0.7);
   schedule("goDown(" @ %object @ ");",0.8);
   schedule("goDown(" @ %object @ ");",0.9);
   schedule("goDownSlow(" @ %object @ ");",1);
   schedule("VertTransferGrindNorthECount2(" @ %object @ ");",1.1);
}

function VertTransferGrindNorthECount2(%object)
{
   if(%object.grindNum<1)
   {
      stopVertTransferGrindNorthE(%object);
   }
   else
   {
      %object.grindNum--;
      GrindEast(%object);
      schedule("VertTransferGrindNorthECount2(" @ %object @ ");", 0.1);
   }
}

function stopVertTransferGrindNorthE(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Grind + HP Transfer + Grind! (500 points)");
   %playerId.points = %playerId.points + 500;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function VertTransferGrindNorthW(%object)
{
   goUp(%object);
   schedule("GrindNorth(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("GrindNorth(" @ %object @ ");",0.3);
   schedule("goUp(" @ %object @ ");",0.4);
   schedule("GoNorth(" @ %object @ ");",0.5);
   %object.distance = getDistance(%object, $vertGrind3W);
   %object.grindlength = (%object.distance / 2);
   %object.grindNum = (%object.grindlength / 10);
   schedule("VertTransferGrindNorthWCount1(" @ %object @ ");",0.6);
}

function VertTransferGrindNorthWCount1(%object)
{
   if(%object.grindNum<1)
   {
      ContVertTransferGrindNorthW(%object);
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("VertTransferGrindNorthWCount1(" @ %object @ ");", 0.1);
   }
}

function ContVertTransferGrindNorthW(%object)
{
   %object.grindNum = (%object.grindlength / 10);
   goUp(%object);
   schedule("goUp(" @ %object @ ");",0.1);
   schedule("goUp(" @ %object @ ");",0.2);
   schedule("jumpNorth60(" @ %object @ ");",0.3);
   schedule("jumpNorth30(" @ %object @ ");",0.4);
   schedule("grindNorth(" @ %object @ ");",0.5);
   schedule("FallNorth30(" @ %object @ ");",0.6);
   schedule("FallNorth60(" @ %object @ ");",0.7);
   schedule("goDown(" @ %object @ ");",0.8);
   schedule("goDown(" @ %object @ ");",0.9);
   schedule("goDownSlow(" @ %object @ ");",1);
   schedule("VertTransferGrindNorthWCount2(" @ %object @ ");",1.1);
}

function VertTransferGrindNorthWCount2(%object)
{
   if(%object.grindNum<1)
   {
      stopVertTransferGrindNorthW(%object);
   }
   else
   {
      %object.grindNum--;
      GrindWest(%object);
      schedule("VertTransferGrindNorthWCount2(" @ %object @ ");", 0.1);
   }
}

function stopVertTransferGrindNorthW(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Grind + HP Transfer + Grind! (500 points)");
   %playerId.points = %playerId.points + 500;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function railGrind1NEnd::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpNorth50Small(%object);
      %object.distance = getDistance(%object, $railGrind1N);
      %object.grindNum = (%object.distance / 5);
      schedule("railGrindN(" @ %object @ ");",0.1);
   }
}

function railGrindN(%object)
{
   if(%object.grindNum<1)
   {
      finishRailGrindN(%object);
   }
   else
   {
      %object.grindNum--;
      goNorth(%object);
      schedule("railGrindN(" @ %object @ ");", 0.1);
   }
}

function finishRailGrindN(%object)
{
   grindNorth(%object);
   %eastwest = randomInt(0,1);
   if(%eastwest==0)
   {
      schedule("grindEast(" @ %object @ ");",0.1);
   }
   else if(%eastwest==1)
   {
      schedule("grindWest(" @ %object @ ");",0.1);
   }
   schedule("stopRailGrindN(" @ %object @ ");",0.2);
}

function stopRailGrindN(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Rail Grind! (200 points)");
   %playerId.points = %playerId.points + 200;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function railGrind1SEnd::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpSouth50Small(%object);
      %object.distance = getDistance(%object, $railGrind1S);
      %object.grindNum = (%object.distance / 5);
      schedule("railGrindS(" @ %object @ ");",0.1);
   }
}

function railGrindS(%object)
{
   if(%object.grindNum<1)
   {
      finishRailGrindS(%object);
   }
   else
   {
      %object.grindNum--;
      goSouth(%object);
      schedule("railGrindS(" @ %object @ ");", 0.1);
   }
}

function finishRailGrindS(%object)
{
   grindSouth(%object);
   %eastwest = randomInt(0,1);
   if(%eastwest==0)
   {
      schedule("grindEast(" @ %object @ ");",0.1);
   }
   else if(%eastwest==1)
   {
      schedule("grindWest(" @ %object @ ");",0.1);
   }
   schedule("stopRailGrindS(" @ %object @ ");",0.2);
}

function stopRailGrindS(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Rail Grind! (200 points)");
   %playerId.points = %playerId.points + 200;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function railGrind1N::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpEast50Small(%object);
      %object.distance = getDistance(%object, $railGrind1N);
      %object.grindNum = (%object.distance / 5);
      schedule("railGrindN(" @ %object @ ");",0.1);
   }
}

function railGrind2N::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpWest50Small(%object);
      %object.distance = getDistance(%object, $railGrind1N);
      %object.grindNum = (%object.distance / 5);
      schedule("railGrindN(" @ %object @ ");",0.1);
   }
}

function railGrind1S::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpEast50Small(%object);
      %object.distance = getDistance(%object, $railGrind1S);
      %object.grindNum = (%object.distance / 5);
      schedule("railGrindS(" @ %object @ ");",0.1);
   }
}

function railGrind2S::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpWest50Small(%object);
      %object.distance = getDistance(%object, $railGrind1S);
      %object.grindNum = (%object.distance / 5);
      schedule("railGrindS(" @ %object @ ");",0.1);
   }
}

function AirTime1::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %playerId.stuntlock = "locked";
}

function AirTime1::trigger::onContact(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.airtime = %object.airtime + 0.1000056;
   %object.contact = %object.contact + 10;
   %playerId.points = %playerId.points + 10;
}

function AirTime1::trigger::onLeave(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.totalAirTime = (%object.airtime - 0.00004);
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.totalAirTime @ " seconds of Air Time! (" @ %object.contact @ " points)");   
   %object.airtime = 0;
   %object.totalAirTime = 0;
   %object.contact = 0;
   stuntWaiting(%playerId);
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function deathPit::trigger::onEnter(%this, %object)
{
   WipeOut(%object);
}

function hoop1A::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.hoop1A = true;
   schedule("hoop1false(" @ %object @ ");",2);
   if(%object.hoop1B==true)
   {
      say("Everybody", 0, "<F1>" @ %object.name @ " - Through the hoop! (100 points)");
      %playerId.points = %playerId.points + 100;
   }
}

function hoop1B::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.hoop1B = true;
   schedule("hoop1false(" @ %object @ ");",2);
   if(%object.hoop1A==true)
   {
      say("Everybody", 0, "<F1>" @ %object.name @ " - Through the hoop! (100 points)");
      %playerId.points = %playerId.points + 100;
   }
}

function hoop1false(%object)
{
   %object.hoop1A = false;
   %object.hoop1B = false;
}

function hoop2A::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.hoop2A = true;
   schedule("hoop2false(" @ %object @ ");",2);
   if(%object.hoop2B==true)
   {
      say("Everybody", 0, "<F1>" @ %object.name @ " - Through the hoop! (100 points)");
      %playerId.points = %playerId.points + 100;
   }
}

function hoop2B::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.hoop2B = true;
   schedule("hoop2false(" @ %object @ ");",2);
   if(%object.hoop2A==true)
   {
      say("Everybody", 0, "<F1>" @ %object.name @ " - Through the hoop! (100 points)");
      %playerId.points = %playerId.points + 100;
   }
}

function hoop2false(%object)
{
   %object.hoop2A = false;
   %object.hoop2B = false;
}

function bighoop1::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.bighoop1 = true;
   schedule("bighoopfalse(" @ %object @ ");",3);
   if(%object.bighoop2==true)
   {
      say("Everybody", 0, "<F1>" @ %object.name @ " - Through the triple hoops! (300 points)");
      %playerId.points = %playerId.points + 300;
   }
}

function bighoop2::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::vehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.bighoop2 = true;
   schedule("bighoopfalse(" @ %object @ ");",3);
   if(%object.bighoop1==true)
   {
      say("Everybody", 0, "<F1>" @ %object.name @ " - Through the triple hoops! (300 points)");
      %playerId.points = %playerId.points + 300;
   }
}

function bighoopfalse(%object)
{
   %object.bighoop1 = false;
   %object.bighoop2 = false;
}

function BridgeOllie1::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpSouth30(%object);
      schedule("jumpSouth30(" @ %object @ ");",0.1);
      schedule("grindSouth(" @ %object @ ");",0.2);      
      schedule("grindSouth(" @ %object @ ");",0.3);      
      schedule("grindSouth(" @ %object @ ");",0.4);      
      schedule("grindSouth(" @ %object @ ");",0.5);       
      schedule("grindSouth(" @ %object @ ");",0.6);       
      schedule("grindSouth(" @ %object @ ");",0.7);       
      schedule("fallSouth30(" @ %object @ ");",0.8);
      schedule("EndBridgeOllie(" @ %object @ ");",0.9);
   }
}

function BridgeOllie2::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpNorth30(%object);
      schedule("jumpNorth30(" @ %object @ ");",0.1);
      schedule("grindNorth(" @ %object @ ");",0.2);      
      schedule("grindNorth(" @ %object @ ");",0.3);      
      schedule("grindNorth(" @ %object @ ");",0.4);      
      schedule("grindNorth(" @ %object @ ");",0.5);      
      schedule("grindNorth(" @ %object @ ");",0.6);      
      schedule("grindNorth(" @ %object @ ");",0.7);      
      schedule("fallNorth30(" @ %object @ ");",0.8);
      schedule("EndBridgeOllie(" @ %object @ ");",0.9);
   }
}

function EndBridgeOllie(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %playerId.stunt = "waiting";
   stuntLockClear(%playerId);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Ollie over the gap! (200 points)");
   %playerId.points = %playerId.points + 200;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function BoxOllie1E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpEast45(%object);
      schedule("jumpEast30(" @ %object @ ");",0.1);
      schedule("goEast(" @ %object @ ");",0.2);      
      schedule("goEast(" @ %object @ ");",0.3);      
      schedule("goEast(" @ %object @ ");",0.4);      
      schedule("goEast(" @ %object @ ");",0.5);      
      schedule("goEast(" @ %object @ ");",0.6);      
      schedule("fallEast30(" @ %object @ ");",0.7);
      schedule("fallEast30(" @ %object @ ");",0.8);
      schedule("EndBoxOllie(" @ %object @ ");",0.9);
   }
}

function BoxOllie1W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpWest45(%object);
      schedule("jumpWest30(" @ %object @ ");",0.1);
      schedule("goWest(" @ %object @ ");",0.2);      
      schedule("goWest(" @ %object @ ");",0.3);      
      schedule("goWest(" @ %object @ ");",0.4);      
      schedule("goWest(" @ %object @ ");",0.5);      
      schedule("goWest(" @ %object @ ");",0.6);      
      schedule("fallWest30(" @ %object @ ");",0.7);
      schedule("fallWest30(" @ %object @ ");",0.8);
      schedule("EndBoxOllie(" @ %object @ ");",0.9);
   }
}

function EndBoxOllie(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %playerId.stunt = "waiting";
   stuntLockClear(%playerId);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Ollie over the boxes! (150 points)");
   %playerId.points = %playerId.points + 150;
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function BoxGrind1E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %z = getPosition(%object, z);
      setPosition(%object, 272.148, 593.324, %z);
      schedule("jumpEast45(" @ %object @ ");",0.1);
      %object.distance = getDistance(%object, $boxGrind1E);
      %object.grindNum = (%object.distance / 5);
      schedule("boxGrindE(" @ %object @ ");",0.2);
   }
}

function BoxGrind2E::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %z = getPosition(%object, z);
      setPosition(%object, 272.352, 610.645, %z);
      schedule("jumpEast45(" @ %object @ ");",0.1);
      %object.distance = getDistance(%object, $boxGrind2E);
      %object.grindNum = (%object.distance / 5);
      schedule("boxGrindE(" @ %object @ ");",0.2);
   }
}

function boxGrindE(%object)
{
   if(%object.grindNum<1)
   {
      finishBoxGrindE(%object);
   }
   else
   {
      %object.grindNum--;
      goEast(%object);
      schedule("boxGrindE(" @ %object @ ");", 0.1);
   }
}

function finishBoxGrindE(%object)
{
   grindEast(%object);
   schedule("fallEast30(" @ %object @ ");",0.1);
   schedule("stopBoxGrindE(" @ %object @ ");",0.2);
}

function stopBoxGrindE(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Box Grind! (200 points)");
   %playerId.points = %playerId.points + 200;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function BoxGrind1W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %z = getPosition(%object, z);
      setPosition(%object, 362.26, 593.466, %z);
      schedule("jumpWest45(" @ %object @ ");",0.1);
      %object.distance = getDistance(%object, $boxGrind1W);
      %object.grindNum = (%object.distance / 5);
      schedule("boxGrindW(" @ %object @ ");",0.2);
   }
}

function BoxGrind2W::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %z = getPosition(%object, z);
      setPosition(%object, 362.448, 610.416, %z);
      schedule("jumpWest45(" @ %object @ ");",0.1);
      %object.distance = getDistance(%object, $boxGrind2W);
      %object.grindNum = (%object.distance / 5);
      schedule("boxGrindW(" @ %object @ ");",0.2);
   }
}

function boxGrindW(%object)
{
   if(%object.grindNum<1)
   {
      finishBoxGrindW(%object);
   }
   else
   {
      %object.grindNum--;
      goWest(%object);
      schedule("boxGrindW(" @ %object @ ");", 0.1);
   }
}

function finishBoxGrindW(%object)
{
   grindEast(%object);
   schedule("fallWest30(" @ %object @ ");",0.1);
   schedule("stopBoxGrindW(" @ %object @ ");",0.2);
}

function stopBoxGrindW(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Box Grind! (200 points)");
   %playerId.points = %playerId.points + 200;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function StairGrind1::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpEast50Small(%object);
      %object.distance = getDistance(%object, $StairGrind1);
      %object.grindNum = (%object.distance / 11.18);
      schedule("StairGrindLength1(" @ %object @ ");",0.1);
   }
}

function StairGrind1N::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpNorth50Small(%object);
      %object.distance = getDistance(%object, $StairGrind1);
      %object.grindNum = (%object.distance / 11.18);
      schedule("StairGrindLength1(" @ %object @ ");",0.1);
   }
}

function StairGrind1S::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      jumpSouth50Small(%object);
      %object.distance = getDistance(%object, $StairGrind1);
      %object.grindNum = (%object.distance / 11.18);
      schedule("StairGrindLength1(" @ %object @ ");",0.1);
   }
}

function StairGrindLength1(%object)
{
   if(%object.grindNum<1)
   {
      finishStairGrind1(%object);
   }
   else
   {
      %object.grindNum--;
      fallEast30(%object);
      schedule("StairGrindLength1(" @ %object @ ");", 0.1);
   }
}

function finishStairGrind1(%object)
{
   grindEast(%object);
   schedule("stopStairGrind1(" @ %object @ ");",0.2);
}

function stopStairGrind1(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   say("Everybody", 0, "<F1>" @ %object.name @ " - Stair Rail Grind! (300 points)");
   %playerId.points = %playerId.points + 300;
   %playerId.stunt = "waiting";
   stuntlockClear(%playerId);
   schedule("stuntReady(" @ %playerId @ ");",3);
}

function theWall::trigger::onEnter(%this, %object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      %playerId.stuntlock = "locked";
      %object.height = randomInt(8,20);
      %object.heightmeters = %object.height @ "0";
      %object.heightscore = (%object.heightmeters * 3);
      jumpNorth45(%object);
      schedule("jumpNorth45(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("jumpNorth60(" @ %object @ ");",0.3);
      schedule("jumpNorth60(" @ %object @ ");",0.4);
      schedule("jumpNorth60(" @ %object @ ");",0.5);
      schedule("goUp(" @ %object @ ");",0.6);
      schedule("goUp(" @ %object @ ");",0.7);
      schedule("goUp(" @ %object @ ");",0.8);
      schedule("goUp(" @ %object @ ");",0.9);
      schedule("goUp(" @ %object @ ");",1);
      schedule("goUp(" @ %object @ ");",1.1);
      schedule("wallJumpHeight(" @ %object @ ");",1.2);
   }
}

function wallJumpHeight(%object)
{
   if(%object.height<1)
   {
      stopWallJumpHeight(%object);
   }
   else
   {
      %object.height--;
      goUp(%object);
      schedule("wallJumpHeight(" @ %object @ ");", 0.1);
   }
}

function stopWallJumpHeight(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   say("Everybody", 0, "<F1>" @ %object.name @ " - HUGE AIR! " @ %object.heightmeters @ " meters above the ramp! (" @ %object.heightscore @ " points)");
   %playerId.points = %playerId.points + %object.heightscore;
   schedule("stuntReady(" @ %playerId @ ");",10);
}

function quarterPipeLL::trigger::onEnter(%this, %object)
{  
   $QPGrindL = "Missiongroup/quarterGrindL";
   $QPGrindML = "Missiongroup/quarterGrindML";
   $QPGrindMR = "Missiongroup/quarterGrindMR";
   $QPGrindR = "Missiongroup/quarterGrindR";
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.vertside = 1;
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      goUp(%object);
      schedule("GrindNorth(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("GrindNorth(" @ %object @ ");",0.3);
      schedule("goUp(" @ %object @ ");",0.4);
      schedule("GoNorth(" @ %object @ ");",0.5);
      if(%playerId.QPtoggle=="jump")
      {
         schedule("QPJump(" @ %object @ ", 1);",0.6);
      }
      else if(%playerId.QPtoggle=="grind")
      {
         schedule("QPGrind(" @ %object @ ", $QPGrindML, 3, 123, 10);",0.6);
      }
   }
}

function quarterPipeLR::trigger::onEnter(%this, %object)
{  
   $QPGrindL = "Missiongroup/quarterGrindL";
   $QPGrindML = "Missiongroup/quarterGrindML";
   $QPGrindMR = "Missiongroup/quarterGrindMR";
   $QPGrindR = "Missiongroup/quarterGrindR";
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.vertside = 1;
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      goUp(%object);
      schedule("GrindNorth(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("GrindNorth(" @ %object @ ");",0.3);
      schedule("goUp(" @ %object @ ");",0.4);
      schedule("GoNorth(" @ %object @ ");",0.5);
      if(%playerId.QPtoggle=="jump")
      {
         schedule("QPJump(" @ %object @ ", 1);",0.6);
      }
      else if(%playerId.QPtoggle=="grind")
      {  
         %object.randomQP = randomInt(0,1);
         if(%object.randomQP==0)
         {
            schedule("QPGrind(" @ %object @ ", $QPGrindL, 4, 10, 10);",0.6);
         }
         else if(%object.randomQP==1)
         {
            schedule("QPGrind(" @ %object @ ", $QPGrindML, 3, 123, 10);",0.6);
         }
      }
   }
}

function quarterPipeML::trigger::onEnter(%this, %object)
{  
   $QPGrindL = "Missiongroup/quarterGrindL";
   $QPGrindML = "Missiongroup/quarterGrindML";
   $QPGrindMR = "Missiongroup/quarterGrindMR";
   $QPGrindR = "Missiongroup/quarterGrindR";
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      goUp(%object);
      schedule("GrindNorthEast(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("GrindNorthEast(" @ %object @ ");",0.3);
      schedule("goUp(" @ %object @ ");",0.4);
      if(%playerId.QPtoggle=="jump")
      {
         schedule("QPJump(" @ %object @ ", 2);",0.5);
      }
      else if(%playerId.QPtoggle=="grind")
      {  
         %object.randomQP = randomInt(0,2);
         if(%object.randomQP==0)
         {
            %object.vertside = "2to1";
            schedule("QPGrind(" @ %object @ ", $QPGrindML, 6, 210, 14.142);",0.5);
         }
         else if(%object.randomQP==1)
         {
            %object.vertside = "2to3";
            schedule("QPGrind(" @ %object @ ", $QPGrindMR, 7, 230, 14.142);",0.5);
         }
         else if(%object.randomQP==2)
         {
            %object.vertside = "2to3";
            schedule("QPGrind(" @ %object @ ", $QPGrindMR, 7, 230, 14.142);",0.5);
         }
      }
   }
}

function quarterPipeMR::trigger::onEnter(%this, %object)
{  
   $QPGrindL = "Missiongroup/quarterGrindL";
   $QPGrindML = "Missiongroup/quarterGrindML";
   $QPGrindMR = "Missiongroup/quarterGrindMR";
   $QPGrindR = "Missiongroup/quarterGrindR";
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      goUp(%object);
      schedule("GrindNorthEast(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("GrindNorthEast(" @ %object @ ");",0.3);
      schedule("goUp(" @ %object @ ");",0.4);
      if(%playerId.QPtoggle=="jump")
      {
         schedule("QPJump(" @ %object @ ", 2);",0.5);
      }
      else if(%playerId.QPtoggle=="grind")
      {  
         %object.randomQP = randomInt(0,2);
         if(%object.randomQP==0)
         {
            %object.vertside = "2to1";
            schedule("QPGrind(" @ %object @ ", $QPGrindML, 6, 210, 14.142);",0.5);
         }
         else if(%object.randomQP==1)
         {
            %object.vertside = "2to1";
            schedule("QPGrind(" @ %object @ ", $QPGrindML, 6, 210, 14.142);",0.5);
         }
         else if(%object.randomQP==2)
         {
            %object.vertside = "2to3";
            schedule("QPGrind(" @ %object @ ", $QPGrindMR, 7, 230, 14.142);",0.5);
         }
      }
   }
}

function quarterPipeRL::trigger::onEnter(%this, %object)
{  
   $QPGrindL = "Missiongroup/quarterGrindL";
   $QPGrindML = "Missiongroup/quarterGrindML";
   $QPGrindMR = "Missiongroup/quarterGrindMR";
   $QPGrindR = "Missiongroup/quarterGrindR";
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.vertside = 3;
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      goUp(%object);
      schedule("GrindEast(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("GrindEast(" @ %object @ ");",0.3);
      schedule("goUp(" @ %object @ ");",0.4);
      schedule("GoEast(" @ %object @ ");",0.5);
      if(%playerId.QPtoggle=="jump")
      {
         schedule("QPJump(" @ %object @ ", 3);",0.6);
      }
      else if(%playerId.QPtoggle=="grind")
      {  
         %object.randomQP = randomInt(0,1);
         if(%object.randomQP==0)
         {
            schedule("QPGrind(" @ %object @ ", $QPGrindMR, 1, 321, 10);",0.6);
         }
         else if(%object.randomQP==1)
         {
            schedule("QPGrind(" @ %object @ ", $QPGrindR, 2, 30, 10);",0.6);
         }
      }
   }
}

function quarterPipeRR::trigger::onEnter(%this, %object)
{  
   $QPGrindL = "Missiongroup/quarterGrindL";
   $QPGrindML = "Missiongroup/quarterGrindML";
   $QPGrindMR = "Missiongroup/quarterGrindMR";
   $QPGrindR = "Missiongroup/quarterGrindR";
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %object.name = getHudName(%object);
   %object.vertside = 3;
   if((%playerId.stunt=="ready")&&(%playerId.stuntlock=="clear"))
   {
      goUp(%object);
      schedule("GrindEast(" @ %object @ ");",0.1);
      schedule("goUp(" @ %object @ ");",0.2);
      schedule("GrindEast(" @ %object @ ");",0.3);
      schedule("goUp(" @ %object @ ");",0.4);
      schedule("GoEast(" @ %object @ ");",0.5);
      if(%playerId.QPtoggle=="jump")
      {
         schedule("QPJump(" @ %object @ ", 3);",0.6);
      }
      else if(%playerId.QPtoggle=="grind")
      {
         schedule("QPGrind(" @ %object @ ", $QPGrindMR, 1, 321, 10);",0.6);
      }
   }
}

function QPGrind(%object, %waypoint, %direction, %path, %divisor)
{
   %object.distance = getDistance(%object, %waypoint);
   %object.grindlength = (%object.distance);
   %object.grindNum = (%object.grindlength / %divisor);
   schedule("QPGrindCount(" @ %object @ ", " @ %waypoint @ ", " @ %direction @ ", " @ %path @ ", " @ %divisor @ ");",0.1);
}

function QPGrindCount(%object, %waypoint, %direction, %path, %divisor)
{
   if(%object.grindNum<1)
   {
      finishQPGrind(%object, %waypoint, %direction, %path, %divisor);
   }
   else
   {
      %object.grindNum--;
      if(%direction==1)
      {
         GrindNorth(%object);
      }
      else if(%direction==2)
      {
         GrindSouth(%object);
      }
      else if(%direction==3)
      {
         GrindEast(%object);
      }
      else if(%direction==4)
      {
         GrindWest(%object);
      }
      else if(%direction==5)
      {
         GrindNorthEast(%object);
      }
      else if(%direction==6)
      {
         GrindNorthWest(%object);
      }
      else if(%direction==7)
      {
         GrindSouthEast(%object);
      }
      else if(%direction==8)
      {
         GrindSouthWest(%object);
      }
      schedule("QPGrindCount(" @ %object @ ", " @ %waypoint @ ", " @ %direction @ ", " @ %path @ ", " @ %divisor @ ");",0.1);
   }
}

function finishQPGrind(%object, %waypoint, %direction, %path, %divisor)
{
   if(%path==123)
   {
      if(%direction==3)
      {
         QPGrind(%object, $QPGrindMR, 7, 123, 14.142);
      }
      else if(%direction==7)
      {
         QPGrind(%object, $QPGrindR, 2, 123, 10);
      }
      else if(%direction==2)
      {
         stopQPGrind(%object);
      }
   }
   else if(%path==321)
   {
      if(%direction==1)
      {
         QPGrind(%object, $QPGrindML, 6, 321, 14.142);
      }
      else if(%direction==6)
      {
         QPGrind(%object, $QPGrindL, 4, 321, 10);
      }
      else if(%direction==4)
      {
         stopQPGrind(%object);
      }
   }
   else if(%path==210)
   {
      if(%direction==6)
      {
         QPGrind(%object, $QPGrindL, 4, 210, 10);
      }
      else if(%direction==4)
      {
         stopQPGrindHalf(%object);
      }
   }
   else if(%path==230)
   {  
      if(%direction==7)
      {
         QPGrind(%object, $QPGrindR, 2, 230, 10);
      }
      else if(%direction==2)
      {
         stopQPGrindHalf(%object);
      }
   }
   else
   {
      stopQPGrindSmall(%object);
   }   
}

function stopQPGrind(%object)
{
   if(%object.vertside==1)
   {
      grindWest(%object);
   }
   else if(%object.vertside==3)
   {
      grindSouth(%object);
   }
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   say("Everybody", 0, "<F1>" @ %object.name @ " - 100% Quarter Pipe Grind! (500 points)");
   %playerId.points = %playerId.points + 500;
   schedule("stuntReady(" @ %playerId @ ");",6);
}

function stopQPGrindHalf(%object)
{
   if(%object.vertside=="2to1")
   {
      grindSouth(%object);
   }
   else if(%object.vertside=="2to3")
   {
      grindWest(%object);
   }
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   say("Everybody", 0, "<F1>" @ %object.name @ " - 60% Quarter Pipe Grind! (300 points)");
   %playerId.points = %playerId.points + 300;
   schedule("stuntReady(" @ %playerId @ ");",6);
}

function stopQPGrindSmall(%object)
{
   if(%object.vertside==1)
   {
      grindSouth(%object);
   }
   else if(%object.vertside==3)
   {
      grindWest(%object);
   }
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   say("Everybody", 0, "<F1>" @ %object.name @ " - 30% Quarter Pipe Grind! (100 points)");
   %playerId.points = %playerId.points + 100;
   schedule("stuntReady(" @ %playerId @ ");",6);
}

function QPJump(%object, %side)
{
   %object.height = randomInt(6,14);
   %object.heightmeters = %object.height @ "0";
   %object.heightscore = (%object.heightmeters * 2);
   schedule("QPjumpHeight(" @ %object @ ", " @ %side @ ");",0.1);
}

function QPJumpHeight(%object, %side)
{
   if(%object.height<1)
   {
      stopQPJumpHeight(%object, %side);
   }
   else
   {
      %object.height--;
      goUp(%object);
      schedule("QPJumpHeight(" @ %object @ ", " @ %side @ ");", 0.1);
   }
}

function stopQPJumpHeight(%object, %side)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   if(%side==1)
   {
      grindSouth(%object);
   }
   else if(%side==2)
   {
      grindSouthWest(%object);
   }
   else if(%side==3)
   {
      grindWest(%object);
   }
   %playerId.stunt = "waiting";
   %playerId.stuntlock = "clear";
   say("Everybody", 0, "<F1>" @ %object.name @ " - " @ %object.heightmeters @ " meters in the air! (" @ %object.heightscore @ " points)");
   %playerId.points = %playerId.points + %object.heightscore;
   schedule("stuntReady(" @ %playerId @ ");",6);
}

function Wipeout(%object)
{
   %playerId = playerManager::VehicleIdToPlayerNum(%object);
   healObject(%object, -50000);
   say("Everybody", 0, "<F5>" @ %object.name @ " - WIPEOUT!!!!!");
   %playerId.wipeoutNum++;
}

function stuntlockClear(%playerId)
{
   %playerId.stuntlock = "clear";
}

function stuntReady(%playerId)
{
   %playerId.stunt = "ready";
}

function stuntWaiting(%playerId)
{
   %playerId.stunt = "waiting";
}

function FallNorth45(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallSouth45(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallEast45(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallWest45(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallNorth30(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z) - 5;
   setPosition(%object, %x, %y, %z);
}

function FallSouth30(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z) - 5;
   setPosition(%object, %x, %y, %z);
}

function FallEast30(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 5;
   setPosition(%object, %x, %y, %z);
}

function FallWest30(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 5;
   setPosition(%object, %x, %y, %z);
}

function FallNorth60(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallSouth60(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallEast60(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function FallWest60(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function JumpNorth45(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpSouth45(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpEast45(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpWest45(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpNorth50Small(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z) + 7;
   setPosition(%object, %x, %y, %z);
}

function JumpSouth50Small(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z) + 7;
   setPosition(%object, %x, %y, %z);
}

function JumpEast50Small(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 7;
   setPosition(%object, %x, %y, %z);
}

function JumpWest50Small(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 7;
   setPosition(%object, %x, %y, %z);
}

function JumpNorth45Small(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpSouth45Small(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpEast45Small(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpWest45Small(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpNorth30(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpSouth30(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpEast30(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpWest30(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function JumpNorth60(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpSouth60(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpEast60(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function JumpWest60(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function GrindNorth(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindSouth(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindEast(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindWest(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoNorth(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoSouth(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoEast(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoWest(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y);
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoNorthEast(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoNorthWest(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y) + 5;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoSouthEast(%object)
{
   %x = getPosition(%object, x) + 5;
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GoSouthWest(%object)
{
   %x = getPosition(%object, x) - 5;
   %y = getPosition(%object, y) - 5;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindNorthEast(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindNorthWest(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y) + 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindSouthEast(%object)
{
   %x = getPosition(%object, x) + 10;
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function GrindSouthWest(%object)
{
   %x = getPosition(%object, x) - 10;
   %y = getPosition(%object, y) - 10;
   %z = getPosition(%object, z);
   setPosition(%object, %x, %y, %z);
}

function goUp(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 10;
   setPosition(%object, %x, %y, %z);
}

function goUpSlow(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) + 5;
   setPosition(%object, %x, %y, %z);
}

function goDown(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 10;
   setPosition(%object, %x, %y, %z);
}

function goDownSlow(%object)
{
   %x = getPosition(%object, x);
   %y = getPosition(%object, y);
   %z = getPosition(%object, z) - 5;
   setPosition(%object, %x, %y, %z);
}

function onMissionEnd()
{
   flushConsoleScheduler();
}

function getPlayerScore(%playerId)
{
   return(%playerId.points);
}

function getWipeouts(%playerId)
{
   return(%playerId.wipeoutNum);
}

function getVehicle(%playerId)
{  
   return(%playerId.vehtype);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_TEAM;
	   $ScoreBoard::PlayerColumnHeader2 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader3 = "Score";
	   $ScoreBoard::PlayerColumnHeader4 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader5 = *IDMULT_SCORE_DEATHS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getTeam";
	   $ScoreBoard::PlayerColumnFunction2 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction3 = "getPlayerScore";
	   $ScoreBoard::PlayerColumnFunction4 = "getKills";
	   $ScoreBoard::PlayerColumnFunction5 = "getDeaths";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
         $ScoreBoard::PlayerColumnHeader2 = "Score";
         $ScoreBoard::PlayerColumnHeader3 = "Wipeouts";
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";
	   $ScoreBoard::PlayerColumnHeader5 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader6 = *IDMULT_SCORE_DEATHS;
                  
	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
         $ScoreBoard::PlayerColumnFunction2 = "getPlayerScore";
         $ScoreBoard::PlayerColumnFunction3 = "getWipeouts";
         $ScoreBoard::PlayerColumnFunction4 = "getVehicle";
	   $ScoreBoard::PlayerColumnFunction5 = "getKills";
	   $ScoreBoard::PlayerColumnFunction6 = "getDeaths";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = "Score";
   $ScoreBoard::TeamColumnHeader2 = *IDMULT_SCORE_PLAYERS;
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;
   $ScoreBoard::TeamColumnHeader4 = *IDMULT_SCORE_DEATHS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getNumberOfPlayersOnTeam";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";
   $ScoreBoard::TeamColumnFunction4 = "getTeamDeaths";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}

function setDefaultMissionItems()
{  
      allowVehicle(  all, TRUE  );
      allowVehicle(  1, FALSE  );
      allowVehicle(  3, FALSE  );
      allowVehicle(  5, FALSE  );
      allowVehicle(  7, FALSE  );
      allowVehicle(  10, FALSE  );
      allowVehicle(  12, FALSE  );
      allowVehicle(  14, FALSE  );
      allowVehicle(  16, FALSE  );
      allowVehicle(  22, FALSE  );
      allowVehicle(  23, FALSE  );
      allowVehicle(  24, FALSE  );
      allowVehicle(  27, FALSE  );
      allowVehicle(  28, FALSE  );
      allowVehicle(  29, FALSE  );
      allowVehicle(  33, FALSE  );
      allowVehicle(  37, FALSE  );
      allowVehicle(  38, FALSE  );
      allowVehicle(  39, FALSE  );
      allowVehicle(  55, FALSE  );
      allowVehicle(  56, FALSE  );
   
      allowWeapon( all, TRUE );
      allowWeapon( 3, FALSE );    //Disrupter Weapon  
      allowWeapon( 110, FALSE );  //Plasma Cannon    
      allowWeapon( 124, FALSE );  //Missiles
      allowWeapon( 125, FALSE );
      allowWeapon( 126, FALSE );
      allowWeapon( 127, FALSE );
      allowWeapon( 128, FALSE );

      allowWeapon( 129, FALSE );
      allowWeapon( 130, FALSE );
      allowWeapon( 131, FALSE );  //Arachnitrons
      allowWeapon( 132, FALSE );
      allowWeapon( 133, FALSE );
      allowWeapon( 134, FALSE );  //Proximity Mines
      allowWeapon( 135, FALSE );
      allowWeapon( 136, FALSE );
      allowWeapon( 142, FALSE );  //Radiation Gun
      allowWeapon( 147, FALSE );  //More Missiles
      allowWeapon( 150, FALSE );  //Smart Gun
      
      allowComponent( all, TRUE );
}