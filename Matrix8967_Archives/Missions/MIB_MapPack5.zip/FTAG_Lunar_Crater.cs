// FILENAME:	 FTAG_Lunar_Crater.cs
//
// AUTHOR:  	 Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "FTAG_Lunar_Crater";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = false;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
      $server::disableTeamRed = false;
      $server::disableTeamBlue = false;
      $server::disableTeamYellow = true;
      $server::disableTeamPurple = true;

   // Time limit
      $server::TimeLimit = 20;
}

// move the map
$server::HudMapViewOffsetX = 1746.63;
$server::HudMapViewOffsetY = -951.804;

function onMissionStart()
{
	moonSounds();
     
      $startTime = getCurrentTime(); 
 
      $flag = getobjectId("MissionGroup\\blueflag");
      $CenterNav = getobjectId("MissionGroup\\CenterNav");
      $gamestart = false;
      $triggeron = true;
      $flagholder = "nobody";

      // Start the meteor showers
	dropMeteor("default", -40, -1, 1246, -1450, 2546, -650, 1546, -1650, 2846, -850);
	 
	// Schedule a meteor storm
	%randomTime = randomInt(30, 100);
	schedule("randomDeathStorm();", %randomTime);
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Flag Tag\n\n<F2>MISSION:<F0>  FTAG_Lunar_Crater\n\nWelcome to Flag Tag (FTAG)! After there is at least 2 players in the game, grab the flag & hold it to score 1 point each second. There are no points awarded for kills, so you must have the flag to score. You can steal the flag by killing the flagholder. Padkilling the flagholder is encouraged. If you go 600 meters away from Nav Alpha, you will be killed for going out of bounds. You can download FTAG_Lunar_Crater & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.score = 0;
   }
}

function player::onadd(%player) 
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Flag Tag! Check the game info tab for the rules. You can download FTAG_Lunar_Crater & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %player.score = 0;
}

function vehicle::onadd(%vehicleId)
{
   %vehicleId.name = getHUDName(%vehicleId);
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId); 
   %player.spawn = true;
 
   %now = getCurrentTime(); 
   %totalTime = ($server::TimeLimit * 60); 
   %timeLeft = (%totalTime - (%now - $startTime));
   setHudTimer(%timeLeft, -1, "Mission Time Left", 1, %player); 
}

function player::onRemove(%this)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
   if(playerManager::getPlayerCount()==2)
   {
      messageBox("Everybody", "All other players have left the game. You are the winner!");
      schedule("missionEndConditionMet();", 5);
   }
   else if(playerManager::getPlayerCount()==1)
   {
      schedule("missionEndConditionMet();", 1);
   }   
}

function flag::trigger::onEnter(%this,%object)
{
   if(($triggeron == true) && ($gamestart == false) && (playerManager::getPlayerCount()>=2))
   {      
      setvehiclespecialidentity(%object, on, blue);
      setshapevisibility($flag, false);
      $gamestart = true;
      $triggeron = false;
      $flagholder = %object;
      scoreflagholder();
      say("everybody",1, "<f5>" @ %object.name @ " has the flag!");
   }
   else if(($triggeron == true) && ($gamestart == false) && (playerManager::getPlayerCount()<2))
   {
      say("everybody",1,"<f5>There must be two players in the server before you can play!");
   }
   else if(($triggeron == true) && ($gamestart == true))
   {
      setvehiclespecialidentity(%object, on, blue);
      setshapevisibility($flag, false);
      $triggeron = false;
      $flagholder = %object;
      say("everybody",1, "<f5>" @ %object.name @ " has the flag!");
   } 
}

function scoreflagholder()
{
   %player = playerManager::vehicleIdToPlayerNum($flagholder);
   %player.score++;
   %distance = getdistance($flagholder, $CenterNav);
  
   if(%distance >= 600) // Flag tag boundary
   {
      healobject($flagholder, -50000);
      say("everybody",1, "<f5>The Flag Holder went out of bounds!"); 
   }
   schedule("scoreflagholder();",1);
}     
     
function vehicle::ondestroyed(%destroyed,%destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   %player2.spawn=false;
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if(
         (getTeam(%destroyed) == getTeam(%destroyer)) &&
         (%destroyed != %destroyer)
      )
      {
         antiTeamKill(%destroyer);
      }
   }   
   if((%destroyed == $flagholder) && (%player.spawn == true))
   {
      $flagholder = %destroyer;
      setvehiclespecialidentity(%destroyer, on, blue);
      say("everybody",1, "<f5>" @ %destroyer.name @ " has the flag!");
   }
   else if((%destroyed == $flagholder) && (%player.spawn == false))
   {
      $flagholder = "nobody";
      setshapevisibility($flag, true);
      $triggeron = true;
      say("everybody",1,"<f5>The flag has been returned to Nav Alpha!");
   }
   else if((%destroyed == $flagholder) && (%player==0))
   {
      $flagholder = "nobody";
      setshapevisibility($flag, true);
      $triggeron = true;
      say("everybody",1,"<f5>The flag has been returned to Nav Alpha!");
   }
}
   
function getPlayerScore(%player) 
{ 
   return(%player.score);
}    

function onMissionEnd()
{
   flushConsoleScheduler();
}

function randomDeathStorm()
{
	%nextStorm = randomInt(30, 180);

	Say(0, 0, "WARNING:  Meteor shower detected!");
	dropMeteor("default", 1, 3, 1246, -1450, 2546, -650, 1546, -1650, 2846, -850);
    
    %dropMeteors = "dropMeteor(\"default\", 1, 3, 1246, -1450, 2546, -650, 1546, -1650, 2846, -850);";

	schedule(%dropMeteors, 4);
	schedule(%dropMeteors, 8);
	schedule(%dropMeteors, 12);
	schedule(%dropMeteors, 16);
	schedule(%dropMeteors, 20);
	schedule(%dropMeteors, 24);
	schedule(%dropMeteors, 28);
	schedule(%dropMeteors, 32);
	schedule(%dropMeteors, 36);

	schedule("randomDeathStorm();", %nextStorm);
}

// ---------------------------------------------------------------------------------------------------
function dropMeteor(%type, %rate, %count, %xHigh1, %yHigh1, %xHigh2, %yHigh2, %xLow1, %yLow1, %xLow2, %yLow2){

	%ceiling = 1800;

	if(%xHigh2 == "") %xHigh2 = 0;
	if(%yHigh2 == "") %yHigh2 = 0;
	if(%xLow1 == "") %xLow1 = 0;
	if(%yLow1 == "") %yLow1 = 0;
	if(%xLow2 == "") %xLow2 = 0;
	if(%yLow2 == "") %yLow2 = 0;

	if(%xLow1 == 0 && %xLow2 == 0 && %yLow1 == 0 && %yLow2 == 0){
		%xLow1 = %xHigh1;
		%xLow2 = %xHigh2;
		%yLow1 = %yHigh1;
		%yLow2 = %yHigh2;
	}

	%startX = randomInt(%xHigh1, %xHigh2);
	%startY = randomInt(%yHigh1, %yHigh2);

	%endX = randomInt(%xLow1, %xLow2);
	%endY = randomInt(%yLow1, %yLow2);

	if(%type == "focus"){
		%startX = %endX = %xHigh1;
		%startY = %endY = %yHigh1;		
	}
	else if(%type == "focalStart"){
		%startX = %xLow1;
		%startY = %yLow1;
	}
	else if(%type == "focalEnd"){
		%endX = %xLow1;
		%endY = %yLow1;
	}
	else if(%type == "vertical"){
		%startX = %endX;
		%startY = %endY;
	}

	%endZ = getTerrainHeight(%endX, %endY);

	// Determine when the next meteorite will fall
	%when = %rate;
	if(%when < 0){
		%when = %when * -1;
		%when = randomFloat(0, %when);
	}

	if(count != -1)
		%count = %count - 1;

	%nextMeteorite = "dropMeteor(";
	%nextMeteorite = strcat(%nextMeteorite, %type, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %rate, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %count, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xHigh1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yHigh1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xHigh2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yHigh2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xLow1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yLow1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xLow2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yLow2, ");");

	dropPod(%startX, %startY, %ceiling, %endX, %endY, %endZ, "MissionGroup\\meteorite");
	%doDamage = "blast(";
	%doDamage = strcat(%doDamage, "\"MissionGroup\\\\meteorite\", 100, 8000, \"MissionGroup\\\\meteorite\");");

	// This next bit calculates when the meteor hits the ground and damages the herc when it does...
	%timeDrop = ((%endX - %startX) * (%endX - %startX));
	%timeDrop = %timeDrop + ((%endY - %startY) * (%endY - %startY));
	%timeDrop = %timeDrop + ((%ceiling - %endZ) * (%ceiling - %endZ));
	%timeDrop = sqrt(%timeDrop);
	%timeDrop = %timeDrop / 400;
	schedule(%doDamage, %timeDrop);

	if(%count != 0)
		schedule(%nextMeteorite, %when);
}

// Take away light, fast hercs so they cant run around like crazy.
function setDefaultMissionItems()
{
   allowVehicle(all, true); // All Hercs
   allowVehicle(4, false);  // No talons
   allowVehicle(13, false); // No knight's talons
   allowVehicle(20, false); // No seekers
   allowVehicle(35, false); // No metagen seekers
   allowVehicle(21, false); // No goads
   allowVehicle(36, false); // No metagen goads

// No Tracking weapons 
   allowWeapon(all, true);
   allowWeapon(124, false);
   allowWeapon(125, false);
   allowWeapon(126, false);
   allowWeapon(127, false);
   allowWeapon(128, false);
   allowWeapon(129, false);
   allowWeapon(130, false);
   allowWeapon(131, false);
   allowWeapon(132, false);
   allowWeapon(133, false);
   allowWeapon(147, false);
   allowWeapon(150, false);   
}
