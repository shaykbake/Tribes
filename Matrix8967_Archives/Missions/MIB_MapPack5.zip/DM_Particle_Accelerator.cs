// FILENAME:	DM_Particle_Accelerator.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "DM_Particle_Accelerator";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   desertSounds();
   $anim1 = getObjectId("MissionGroup\\anim1");
   $anim2 = getObjectId("MissionGroup\\anim2");
   $anim3 = getObjectId("MissionGroup\\anim3");
   $anim4 = getObjectId("MissionGroup\\anim4");
   $anim5 = getObjectId("MissionGroup\\anim5");
   $anim6 = getObjectId("MissionGroup\\anim6");
   $anim7 = getObjectId("MissionGroup\\anim7");
   $anim8 = getObjectId("MissionGroup\\anim8");
   playAnimSequence($anim1,0,true);
   schedule("playAnimSequence($anim2,0,true);",0.25);
   schedule("playAnimSequence($anim3,0,true);",0.5);
   schedule("playAnimSequence($anim4,0,true);",0.75);
   playAnimSequence($anim5,0,true);
   schedule("playAnimSequence($anim6,0,true);",0.25);
   schedule("playAnimSequence($anim7,0,true);",0.5);
   schedule("playAnimSequence($anim8,0,true);",0.75);
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "Cloudburst", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  DeathMatch\n\n<F2>MISSION:<F0>  DM_Particle_Accelerator\n\nWelcome to DeathMatch Particle Accelerator! Run through a Particle Accelerator to propel your HERC skyward. Unfortunately, Adjudicators and all tanks are not able to use the Particle Accelerators due to structural differences. You can download DM_Particle_Accelerator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to DeathMatch Particle Accelerator! Run through a Particle Accelerator to propel your HERC skyward. Unfortunately, Adjudicators and all tanks are not able to use the Particle Accelerators due to structural differences. You can download DM_Particle_Accelerator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   schedule("setAlive("@%player@");",1);   
}

function setAlive(%player)
{
   %player.alive = true;
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyed);
   %player.alive = false;   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if(
         (getTeam(%destroyed) == getTeam(%destroyer)) &&
         (%destroyed != %destroyer)
      )
      {
         antiTeamKill(%destroyer);
      }
   }   
}

//Particle Accelerators
function springhigh::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(200,250);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function springmed::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(150,200);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function springlow::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleidtoplayernum(%object);
   if((getVehicleName(%object)!="Avenger") && (getVehicleName(%object)!="Bolo") && (getVehicleName(%object)!="Disrupter") && (getVehicleName(%object)!="Dreadlock") && (getVehicleName(%object)!="Harabec's Predator") && (getVehicleName(%object)!="Knight's Disruptor") && (getVehicleName(%object)!="Knight's Myrmidon") && (getVehicleName(%object)!="Knight's Paladin") && (getVehicleName(%object)!="Myrmidon") && (getVehicleName(%object)!="Paladin") && (getVehicleName(%object)!="Recluse") && (getVehicleName(%object)!="Avenger"))
   {
      %num = randomInt(100,150);
      loop(%player,%num);
      playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
      playsound(%player,"sfx_steam.wav",IDPRF_2D);
      playsound(%player,"sfx_shrk.wav",IDPRF_2D);
   }
   else
   {
      say(%player,%player,"<f5>Your vehicle is not able to use the Particle Accelerators due to structural differences.");
   }
}

function loop(%player,%num)
{
   if((%num > 0)&&(%player.alive==true))
   {
      %num--;
      %vehicleId = playermanager::playernumtovehicleid(%player);
      damageArea(%vehicleId,0,0,0,10,0);
      schedule("loop(" @ %player @ "," @ %num @ ");",0.1);
   }
}