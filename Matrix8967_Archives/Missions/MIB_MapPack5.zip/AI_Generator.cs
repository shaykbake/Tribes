// FILENAME:	AI_Generator.cs
//
// AUTHOR:  	Gen. Raven [M.I.B.]
//------------------------------------------------------------------------------
// Host Lock - set to true to allow only the server host to start or stop
// the AI attack.

$HostLock = false;      //Defaulted to false

//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "AI_Generator";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;
}

Pilot Elite
{
   id = 28;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 1000.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Veteran
{
   id = 29;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Professional
{
   id = 30;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Average
{
   id = 31;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Rookie
{
   id = 32;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.1;
};

Pilot Idiot
{
   id = 33;
   skill = 0.1;
   accuracy = 0.1;
   aggressiveness = 0.1;
   activateDist = 700.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.5;
   LOSFreq = 0.1;
};

Pilot Elite1
{
   id = 38;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 1000.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Veteran1
{
   id = 39;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Professional1
{
   id = 40;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Average1
{
   id = 41;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Rookie1
{
   id = 42;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.1;
};

Pilot Idiot1
{
   id = 43;
   skill = 0.1;
   accuracy = 0.1;
   aggressiveness = 0.1;
   activateDist = 700.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.5;
   LOSFreq = 0.1;
};

Pilot Elite2
{
   id = 48;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 1000.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Veteran2
{
   id = 49;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Professional2
{
   id = 50;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Average2
{
   id = 51;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Rookie2
{
   id = 52;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.1;
};

Pilot Idiot2
{
   id = 53;
   skill = 0.1;
   accuracy = 0.1;
   aggressiveness = 0.1;
   activateDist = 700.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.5;
   LOSFreq = 0.1;
};

Pilot Elite3
{
   id = 58;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 1000.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Veteran3
{
   id = 59;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Professional3
{
   id = 60;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Average3
{
   id = 61;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Rookie3
{
   id = 62;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.1;
};

Pilot Idiot3
{
   id = 63;
   skill = 0.1;
   accuracy = 0.1;
   aggressiveness = 0.1;
   activateDist = 700.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.5;
   LOSFreq = 0.1;
};

Pilot Elite4
{
   id = 68;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 1000.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Veteran4
{
   id = 69;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Professional4
{
   id = 70;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Average4
{
   id = 71;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Rookie4
{
   id = 72;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.1;
};

Pilot Idiot4
{
   id = 73;
   skill = 0.1;
   accuracy = 0.1;
   aggressiveness = 0.1;
   activateDist = 700.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.5;
   LOSFreq = 0.1;
};

Pilot Elite5
{
   id = 78;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 1000.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Veteran5
{
   id = 79;
   skill = 0.9;
   accuracy = 0.9;
   aggressiveness = 0.9;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Professional5
{
   id = 80;
   skill = 0.7;
   accuracy = 0.7;
   aggressiveness = 0.7;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Average5
{
   id = 81;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Rookie5
{
   id = 82;
   skill = 0.3;
   accuracy = 0.3;
   aggressiveness = 0.4;
   activateDist = 800.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.1;
};

Pilot Idiot5
{
   id = 83;
   skill = 0.1;
   accuracy = 0.1;
   aggressiveness = 0.1;
   activateDist = 700.0;
   deactivateBuff = 200.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.5;
   LOSFreq = 0.1;
};

function onMissionStart()
{
   titanSounds();
   $AI1 = getObjectId("MissionGroup\\AI1"); 
   $AI2 = getObjectId("MissionGroup\\AI2"); 
   $AI3 = getObjectId("MissionGroup\\AI3"); 
   $AI4 = getObjectId("MissionGroup\\AI4"); 
   $AI5 = getObjectId("MissionGroup\\AI5"); 
   $AIall = getObjectId("MissionGroup\\AIall"); 
   $AIskill = getObjectId("MissionGroup\\AIskill"); 
   $AInum = getObjectId("MissionGroup\\AInum"); 
   $TogglePads = getObjectId("MissionGroup\\TogglePads");
   $Pad1 = getObjectId("MissionGroup\\Pad1");
   $Pad2 = getObjectId("MissionGroup\\Pad2");
   $AIs = "MissionGroup/AIs";
   $started = false;
   $hercallId = 23;
   $herc1Id = 23;
   $herc2Id = 23;   
   $herc3Id = 23;   
   $herc4Id = 23;   
   $herc5Id = 23;
   $herc1type = Herc;
   $herc2type = Herc;   
   $herc3type = Herc;   
   $herc4type = Herc;   
   $herc5type = Herc;
   $skillLevel = "31";
   $number = 2;
   $pads = true;
   $lock = false;
}

function onMissionLoad()
{
   cdAudioCycle("Cloudburst", "Cyberntx", "Terror","Mechsoul","Watching"); 
   setGameInfo("<F2>GAME TYPE:<F0>  AI Training\n\n<F2>MISSION:<F0>  AI Generator\n\n<F2>USING THE AI GENERATOR:<f0>\n\nScan the <f3>Options<f0> target drones to select the number & skill of the AIs, and to toggle Heal/Reload pads on or off. Scan the <f3>AI Selection<f0> target drones to select each AI's vehicle type. Shut down and scan them to scroll through the list of vehicles in reverse. Scan the <f3>Select All AIs<f0> target drone to set all the AIs to the same vehicle simultaneously. Then scan the center target drone to begin or abort the training simulation.\n\n<f2>DOWNLOAD INFO:<f0>\n\nYou can download AI_Generator & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function player::onAdd(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to the AI Generator! Scan the target drones to choose the number, type, & skill of the AI that you want to fight. Then scan the center target drone to begin or abort the training simulation. Check the game info tab for more specific details on how to operate the AI Generator. You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
} 

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
}

function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   if(%player!=0)
   {
      setTeam(%vehicleId,*IDSTR_TEAM_YELLOW);
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyed);
   if(%player==0)
   {
      schedule("deleteObject("@%destroyed@");",3);
      if(isGroupDestroyed($AIs)==true)
      {
         $started = false;
         say(0,3,"<f5>All hostile targets have been destroyed!","GEN_OC01.wav");
         setShapeVisibility($AIskill,true);
         setShapeVisibility($AInum,true);
         setShapeVisibility($TogglePads,true);
         setShapeVisibility($AI1,true);
         setShapeVisibility($AIall,true);
         if($number>1)
         {
            setShapeVisibility($AI2,true);
            if($number>2)
            {
               setShapeVisibility($AI3,true);
               if($number>3)
               {
                  setShapeVisibility($AI4,true);
                  if($number>4)
                  {
                     setShapeVisibility($AI5,true);
                  }
               }
            }
         }
         %count = playermanager::getPlayerCount();
         for(%i=0;%i<%count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playermanager::playerNumtoVehicleId(%player);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);            
            reloadobject(%vehicleId,99999);
         }
      }      
   }
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed)==getTeam(%destroyer))&&(%destroyed!=%destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function startstop::structure::onscan(%scanned,%scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(($HostLock==true)&&(getConnection(%player)!="LOOPBACK"))
   {
      say(%player,%player,"<f5>Host Lock is active. Only the server host can start or stop the AI attack."); 
      return;
   }
   if($lock==false)
   {
      $lock = true;
      if($started==false)
      {
         $started = true;
         say(0,3,"<f5>Attack sequence initiated!","TR_INTR01.wav");
         setShapeVisibility($AI1,false);
         setShapeVisibility($AI2,false);
         setShapeVisibility($AI3,false);
         setShapeVisibility($AI4,false);
         setShapeVisibility($AI5,false);
         setShapeVisibility($AIall,false);
         setShapeVisibility($AIskill,false);
         setShapeVisibility($AInum,false);
         setShapeVisibility($TogglePads,false);
         if($number==1)
         {
            dropAI1(%scanner);
         }
         else if($number==2)
         {
            dropAI1(%scanner);
            dropAI2(%scanner);
         }
         else if($number==3)
         {
            dropAI1(%scanner);
            dropAI2(%scanner);
            dropAI3(%scanner);
         }
         else if($number==4)
         {
            dropAI1(%scanner);
            dropAI2(%scanner);
            dropAI3(%scanner);
            dropAI4(%scanner);
         }
         else if($number==5)
         {
            dropAI1(%scanner);
            dropAI2(%scanner);
            dropAI3(%scanner);
            dropAI4(%scanner);
            dropAI5(%scanner);
         }
      }
      else if($started==true)
      {
         $started = false;
         say(0,3,"<f5>Attack sequence aborted!","TR_OUTR01.wav");
         deleteObject($herc1);
         deleteObject($herc2);
         deleteObject($herc3);
         deleteObject($herc4);
         deleteObject($herc5);
         setShapeVisibility($AIskill,true);
         setShapeVisibility($AInum,true);
         setShapeVisibility($TogglePads,true);
         setShapeVisibility($AI1,true);
         setShapeVisibility($AIall,true);
         if($number>1)
         {
            setShapeVisibility($AI2,true);
            if($number>2)
            {
               setShapeVisibility($AI3,true);
               if($number>3)
               {
                  setShapeVisibility($AI4,true);
                  if($number>4)
                  {
                     setShapeVisibility($AI5,true);
                  }
               }
            }
         }        
         %count = playermanager::getPlayerCount();
         for(%i=0;%i<%count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playermanager::playerNumtoVehicleId(%player);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);
            healobject(%vehicleId,99999);            
            reloadobject(%vehicleId,99999);
         }
      }
      schedule("$lock=false;",3);
   }
}

function AIskill::structure::onscan(%scanned,%scanner)
{
   if($started==false)
   {
      if($skillLevel==30)
      {
         $skillLevel = 29;
         say(0,3,"<f6>AI Skill Level - Veteran");
      }
      else if($skillLevel==29)
      {
         $skillLevel = 28;
         say(0,3,"<f6>AI Skill Level - Elite");
      }
      else if($skillLevel==28)
      {
         $skillLevel = 33;
         say(0,3,"<f6>AI Skill Level - Idiot");
      }
      else if($skillLevel==33)
      {
         $skillLevel = 32;
         say(0,3,"<f6>AI Skill Level - Rookie");
      }
      else if($skillLevel==32)
      {
         $skillLevel = 31;
         say(0,3,"<f6>AI Skill Level - Average");
      }
      else if($skillLevel==31)
      {
         $skillLevel = 30;
         say(0,3,"<f6>AI Skill Level - Professional");
      }
   }
}

function AInum::structure::onscan(%scanned,%scanner)
{
   if($started==false)
   {
      if($number==1)
      {
         $number = 2;
         say(0,3,"<f6>Number of AI - 2");
         setShapeVisibility($AI2,true);
      }
      else if($number==2)
      {
         $number = 3;
         say(0,3,"<f6>Number of AI - 3");
         setShapeVisibility($AI3,true);
      }
      else if($number==3)
      {
         $number = 4;
         say(0,3,"<f6>Number of AI - 4");
         setShapeVisibility($AI4,true);
      }
      else if($number==4)
      {
         $number = 5;
         say(0,3,"<f6>Number of AI - 5");
         setShapeVisibility($AI5,true);
      }
      else if($number==5)
      {
         $number = 1;
         say(0,3,"<f6>Number of AI - 1");
         setShapeVisibility($AI2,false);
         setShapeVisibility($AI3,false);
         setShapeVisibility($AI4,false);
         setShapeVisibility($AI5,false);
      }
   }
}

function TogglePads::structure::onscan(%scanned,%scanner)
{
   if($started==false)
   {
      if($pads==true)
      {
         $pads = false;
         setPosition($Pad1,-973.713,112.325,-500);
         setPosition($Pad2,-460.888,127.692,-500);
         say(0,3,"<f6>Heal/Reload pads disabled.");
      }
      else if($pads==false)
      {
         $pads = true;
         setPosition($Pad1,-973.713,112.325,89.1996);
         setPosition($Pad2,-460.888,127.692,90);
         say(0,3,"<f6>Heal/Reload pads enabled.");
      }
   }
}

function dropAI1(%scanner)
{
   if($herc1Id=="Clone")
   {
      $herc1 = cloneVehicle(%scanner);
      if($skillLevel==28)
      {
         Elite1.name = getName(%scanner)@"'s Clone";
         setPilotId($herc1,38);
      }     
      else if($skillLevel==29)
      {
         Veteran1.name = getName(%scanner)@"'s Clone";
         setPilotId($herc1,39);
      }     
      else if($skillLevel==30)
      {
         Professional1.name = getName(%scanner)@"'s Clone";
         setPilotId($herc1,40);
      }          
      else if($skillLevel==31)
      {
         Average1.name = getName(%scanner)@"'s Clone";
         setPilotId($herc1,41);
      }          
      else if($skillLevel==32)
      {
         Rookie1.name = getName(%scanner)@"'s Clone";
         setPilotId($herc1,42);
      }             
      else if($skillLevel==33)
      {
         Idiot1.name = getName(%scanner)@"'s Clone";
         setPilotId($herc1,43);
      }
   }
   else if($herc1Id=="CloneRandom")
   {
      %count = playerManager::getPlayerCount();
      %num = 0;
      %random = randomInt(1,%count);   
      for(%i=0;%i<%count; %i++)
      {
         %player = playerManager::getPlayerNum(%i);
         %vehicleId = playermanager::playerNumtoVehicleId(%player);
         %num++;
         if(%num==%random)
         {
            $herc1 = cloneVehicle(%vehicleId);
            if(%vehicleId=="")
            {              
               $herc1 = newObject("Herc1",Herc,23);
               setPilotId($herc1,$skillLevel);    
            }
            else
            {
               if($skillLevel==28)
               {
                  Elite1.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc1,38);
               }     
               else if($skillLevel==29)
               {
                  Veteran1.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc1,39);
               }     
               else if($skillLevel==30)
               {
                  Professional1.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc1,40);
               }          
               else if($skillLevel==31)
               {
                  Average1.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc1,41);
               }          
               else if($skillLevel==32)
               {
                  Rookie1.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc1,42);
               }             
               else if($skillLevel==33)
               {
                  Idiot1.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc1,43);
               }
            }
         }
      }
   }
   else
   {
      $herc1 = newObject("Herc1",$herc1type,$herc1Id);  
      setPilotId($herc1,$skillLevel);    
   }
   addToSet($AIs, $herc1);
   setTeam($herc1,*IDSTR_TEAM_RED);
   redrop($herc1);
}

function dropAI2(%scanner)
{
   if($herc2Id=="Clone")
   {
      $herc2 = cloneVehicle(%scanner);  
      if($skillLevel==28)
      {
         Elite2.name = getName(%scanner)@"'s Clone";
         setPilotId($herc2,48);
      }     
      else if($skillLevel==29)
      {
         Veteran2.name = getName(%scanner)@"'s Clone";
         setPilotId($herc2,49);
      }     
      else if($skillLevel==30)
      {
         Professional2.name = getName(%scanner)@"'s Clone";
         setPilotId($herc2,50);
      }          
      else if($skillLevel==31)
      {
         Average2.name = getName(%scanner)@"'s Clone";
         setPilotId($herc2,51);
      }          
      else if($skillLevel==32)
      {
         Rookie2.name = getName(%scanner)@"'s Clone";
         setPilotId($herc2,52);
      }             
      else if($skillLevel==33)
      {
         Idiot2.name = getName(%scanner)@"'s Clone";
         setPilotId($herc2,53);
      }
   }
   else if($herc2Id=="CloneRandom")
   {
      %count = playerManager::getPlayerCount();
      %num = 0;
      %random = randomInt(1,%count);   
      for(%i=0;%i<%count; %i++)
      {
         %player = playerManager::getPlayerNum(%i);
         %vehicleId = playermanager::playerNumtoVehicleId(%player);
         %num++;
         if(%num==%random)
         {
            $herc2 = cloneVehicle(%vehicleId);
            if(%vehicleId=="")
            {              
               $herc2 = newObject("Herc2",Herc,23);
               setPilotId($herc2,$skillLevel);    
            }
            else
            {
               if($skillLevel==28)
               {
                  Elite2.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc2,48);
               }     
               else if($skillLevel==29)
               {
                  Veteran2.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc2,49);
               }    
               else if($skillLevel==30)
               {
                  Professional2.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc2,50);
               }          
               else if($skillLevel==31)
               {
                  Average2.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc2,51);
               }          
               else if($skillLevel==32)
               {
                  Rookie2.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc2,52);
               }             
               else if($skillLevel==33)
               {
                  Idiot2.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc2,53);
               }
            }   
         }
      }
   }
   else
   {
      $herc2 = newObject("Herc2",$herc2type,$herc2Id);  
      setPilotId($herc2,$skillLevel);    
   }
   addToSet($AIs, $herc2);
   setTeam($herc2,*IDSTR_TEAM_RED);
   redrop($herc2);
}

function dropAI3(%scanner)
{
   if($herc3Id=="Clone")
   {
      $herc3 = cloneVehicle(%scanner);  
      if($skillLevel==28)
      {
         Elite3.name = getName(%scanner)@"'s Clone";
         setPilotId($herc3,58);
      }     
      else if($skillLevel==29)
      {
         Veteran3.name = getName(%scanner)@"'s Clone";
         setPilotId($herc3,59);
      }     
      else if($skillLevel==30)
      {
         Professional3.name = getName(%scanner)@"'s Clone";
         setPilotId($herc3,60);
      }          
      else if($skillLevel==31)
      {
         Average3.name = getName(%scanner)@"'s Clone";
         setPilotId($herc3,61);
      }          
      else if($skillLevel==32)
      {
         Rookie3.name = getName(%scanner)@"'s Clone";
         setPilotId($herc3,62);
      }             
      else if($skillLevel==33)
      {
         Idiot3.name = getName(%scanner)@"'s Clone";
         setPilotId($herc3,63);
      }
   }
   else if($herc3Id=="CloneRandom")
   {
      %count = playerManager::getPlayerCount();
      %num = 0;
      %random = randomInt(1,%count);   
      for(%i=0;%i<%count; %i++)
      {
         %player = playerManager::getPlayerNum(%i);
         %vehicleId = playermanager::playerNumtoVehicleId(%player);
         %num++;
         if(%num==%random)
         {
            $herc3 = cloneVehicle(%vehicleId);
            if(%vehicleId=="")
            {              
               $herc3 = newObject("Herc3",Herc,23);
               setPilotId($herc3,$skillLevel);    
            }
            else
            {
               if($skillLevel==28)
               {
                  Elite3.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc3,58);
               }     
               else if($skillLevel==29)
               {
                  Veteran3.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc3,59);
               }     
               else if($skillLevel==30)
               {
                  Professional3.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc3,60);
               }          
               else if($skillLevel==31)
               {
                  Average3.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc3,61);
               }          
               else if($skillLevel==32)
               {
                  Rookie3.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc3,62);
               }             
               else if($skillLevel==33)
               {
                  Idiot3.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc3,63);
               }
            }
         }
      }
   }
   else
   {
      $herc3 = newObject("Herc3",$herc3type,$herc3Id);  
      setPilotId($herc3,$skillLevel);    
   }
   addToSet($AIs, $herc3);
   setTeam($herc3,*IDSTR_TEAM_RED);
   redrop($herc3);
}

function dropAI4(%scanner)
{
   if($herc4Id=="Clone")
   {
      $herc4 = cloneVehicle(%scanner);     
      if($skillLevel==28)
      {
         Elite4.name = getName(%scanner)@"'s Clone";
         setPilotId($herc4,68);
      }     
      else if($skillLevel==29)
      {
         Veteran4.name = getName(%scanner)@"'s Clone";
         setPilotId($herc4,69);
      }     
      else if($skillLevel==30)
      {
         Professional4.name = getName(%scanner)@"'s Clone";
         setPilotId($herc4,70);
      }          
      else if($skillLevel==31)
      {
         Average4.name = getName(%scanner)@"'s Clone";
         setPilotId($herc4,71);
      }          
      else if($skillLevel==32)
      {
         Rookie4.name = getName(%scanner)@"'s Clone";
         setPilotId($herc4,72);
      }             
      else if($skillLevel==33)
      {
         Idiot4.name = getName(%scanner)@"'s Clone";
         setPilotId($herc4,73);
      }
   }
   else if($herc4Id=="CloneRandom")
   {
      %count = playerManager::getPlayerCount();
      %num = 0;
      %random = randomInt(1,%count);   
      for(%i=0;%i<%count; %i++)
      {
         %player = playerManager::getPlayerNum(%i);
         %vehicleId = playermanager::playerNumtoVehicleId(%player);
         %num++;
         if(%num==%random)
         {
            $herc4 = cloneVehicle(%vehicleId);
            if(%vehicleId=="")
            {              
               $herc4 = newObject("Herc4",Herc,23);
               setPilotId($herc4,$skillLevel);    
            }
            else
            {
               if($skillLevel==28)
               {
                  Elite4.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc4,68);
               }     
               else if($skillLevel==29)
               {
                  Veteran4.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc4,69);
               }     
               else if($skillLevel==30)
               {
                  Professional4.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc4,70);
               }          
               else if($skillLevel==31)
               {
                  Average4.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc4,71);
               }          
               else if($skillLevel==32)
               {
                  Rookie4.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc4,72);
               }             
               else if($skillLevel==33)
               {
                  Idiot4.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc4,73);
               }
            }
         }
      }
   }
   else
   {
      $herc4 = newObject("Herc4",$herc4type,$herc4Id);  
      setPilotId($herc4,$skillLevel);    
   }
   addToSet($AIs, $herc4);   
   setTeam($herc4,*IDSTR_TEAM_RED);
   redrop($herc4);
}

function dropAI5(%scanner)
{
   if($herc5Id=="Clone")
   {
      $herc5 = cloneVehicle(%scanner);   
      if($skillLevel==28)
      {
         Elite5.name = getName(%scanner)@"'s Clone";
         setPilotId($herc5,78);
      }     
      else if($skillLevel==29)
      {
         Veteran5.name = getName(%scanner)@"'s Clone";
         setPilotId($herc5,79);
      }     
      else if($skillLevel==30)
      {
         Professional5.name = getName(%scanner)@"'s Clone";
         setPilotId($herc5,80);
      }          
      else if($skillLevel==31)
      {
         Average5.name = getName(%scanner)@"'s Clone";
         setPilotId($herc5,81);
      }          
      else if($skillLevel==32)
      {
         Rookie5.name = getName(%scanner)@"'s Clone";
         setPilotId($herc5,82);
      }             
      else if($skillLevel==33)
      {
         Idiot5.name = getName(%scanner)@"'s Clone";
         setPilotId($herc5,83);
      }
   }
   else if($herc5Id=="CloneRandom")
   {
      %count = playerManager::getPlayerCount();
      %num = 0;
      %random = randomInt(1,%count);   
      for(%i=0;%i<%count; %i++)
      {
         %player = playerManager::getPlayerNum(%i);
         %vehicleId = playermanager::playerNumtoVehicleId(%player);
         %num++;
         if(%num==%random)
         {
            $herc5 = cloneVehicle(%vehicleId);
            if(%vehicleId=="")
            {              
               $herc5 = newObject("Herc5",Herc,23);
               setPilotId($herc5,$skillLevel);    
            }
            else
            {
               if($skillLevel==28)
               {
                  Elite5.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc5,78);
               }     
               else if($skillLevel==29)
               {
                  Veteran5.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc5,79);
               }     
               else if($skillLevel==30)
               {
                  Professional5.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc5,80);
               }          
               else if($skillLevel==31)
               {
                  Average5.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc5,81);
               }          
               else if($skillLevel==32)
               {
                  Rookie5.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc5,82);
               }             
               else if($skillLevel==33)
               {
                  Idiot5.name = getName(%vehicleId)@"'s Clone";
                  setPilotId($herc5,83);
               }
            }
         }
      }
   }
   else
   {
      $herc5 = newObject("Herc5",$herc5type,$herc5Id);  
      setPilotId($herc5,$skillLevel);    
   }
   addToSet($AIs, $herc5);
   setTeam($herc5,*IDSTR_TEAM_RED);
   redrop($herc5);
}

function AI1::structure::onscan(%scanned,%scanner)
{
   if(isShutDown(%scanner)==true)
   {
      reverseAI1();
   }
   else
   {
      if($herc1Id==23)
      {
         $herc1Id = 27;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Platinum Guard Adjudicator");
      }
      else if($herc1Id==27)
      {
         $herc1Id = 38;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Metagen Adjudicator");
      }
      else if($herc1Id==38)
      {
         $herc1Id = 1;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Apocalypse");
      }
      else if($herc1Id==1)
      {
         $herc1Id = 10;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Knight's Apocalypse");
      }
      else if($herc1Id==10)
      {
         $herc1Id = 31;
         $herc1type = Tank;
         say(0,2,"<f0>AI #1 Selection - Avenger");
      }
      else if($herc1Id==31)
      {
         $herc1Id = 5;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Basilisk");
      }
      else if($herc1Id==5)
      {
         $herc1Id = 14;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Knight's Basilisk");
      }
      else if($herc1Id==14)
      {
         $herc1Id = 25;
         $herc1type = Tank;
         say(0,2,"<f0>AI #1 Selection - Bolo");
      }
      else if($herc1Id==25)
      {
         $herc1Id = 8;
         $herc1type = Tank;
         say(0,2,"<f0>AI #1 Selection - Disrupter");
      }
      else if($herc1Id==8)
      {
         $herc1Id = 17;
         $herc1type = Tank;
         say(0,2,"<f0>AI #1 Selection - Knight's Disrupter");
      }
      else if($herc1Id==17)
      {
         $herc1Id = 32;
         $herc1type = Tank;
         say(0,2,"<f0>AI #1 Selection - Dreadlock");
      }
      else if($herc1Id==32)
      {
         $herc1Id = 30;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Emancipator");
      }
      else if($herc1Id==30)
      {
         $herc1Id = 24;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Executioner");
      }
      else if($herc1Id==24)
      {
         $herc1Id = 28;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Platinum Guard Executioner");
      }
      else if($herc1Id==28)
      {
         $herc1Id = 39;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Metagen Executioner");
      }
      else if($herc1Id==39)
      {
         $herc1Id = 21;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Goad");
      }
      else if($herc1Id==21)
      {
         $herc1Id = 36;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Metagen Goad");
      }
      else if($herc1Id==36)
      {
         $herc1Id = 3;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Gorgon");
      }
      else if($herc1Id==3)
      {
         $herc1Id = 12;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Knight's Gorgon");
      }
      else if($herc1Id==12)
      {
         $herc1Id = 2;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Minotaur");
      }
      else if($herc1Id==2)
      {
         $herc1Id = 11;
         $herc1type = Herc;
         say(0,2,"<f0>AI #1 Selection - Knight's Minotaur");
      }   
      else
      {
         AI1cont();
      }
   }
}

function AI1cont()
{
   if($herc1Id==11)
   {
      $herc1Id = 7;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Myrmidon");
   }
   else if($herc1Id==7)
   {
      $herc1Id = 16;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Knight's Myrmidon");
   }
   else if($herc1Id==16)
   {
      $herc1Id = 133;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Nike Siege Tank");
   }
   else if($herc1Id==133)
   {
      $herc1Id = 33;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Olympian");
   }
   else if($herc1Id==33)
   {
      $herc1Id = 6;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Paladin");
   }
   else if($herc1Id==6)
   {
      $herc1Id = 15;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Knight's Paladin");
   }
   else if($herc1Id==15)
   {
      $herc1Id = 41;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Harabec's Predator");
   }
   else if($herc1Id==41)
   {
      $herc1Id = 26;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Recluse");
   }
   else if($herc1Id==26)
   {
      $herc1Id = 20;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Seeker");
   }
   else if($herc1Id==20)
   {
      $herc1Id = 35;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Seeker");
   }
   else if($herc1Id==35)
   {
      $herc1Id = 22;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Shepherd");
   }
   else if($herc1Id==22)
   {
      $herc1Id = 37;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Shepherd");
   }   
   else if($herc1Id==37)
   {
      $herc1Id = 4;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Talon");
   }   
   else if($herc1Id==4)
   {
      $herc1Id = 13;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Knight's Talon");
   }   
   else if($herc1Id==13)
   {
      $herc1Id = 40;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Harabec's Apocalypse");
   }   
   else if($herc1Id==40)
   {
      $herc1Id = 45;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Bek Storm's Predator");
   }   
   else if($herc1Id==45)
   {
      $herc1Id = 42;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Caanon's Basilisk");
   }   
   else if($herc1Id==42)
   {
      $herc1Id = 29;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Prometheus");
   }
   else if($herc1Id==29)
   {
      $herc1Id = 138;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Pouncer Assault Bike");
   }   
   else if($herc1Id==138)
   {
      $herc1Id = 150;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Starsiege Magic Bus");
   }      
   else if($herc1Id==150)
   {
      $herc1Id = "Clone";
      say(0,2,"<f0>AI #1 Selection - Clone of Player (Activator)");
   }         
   else
   {
      AI1cont2();
   }
}

function AI1cont2()
{
   if($herc1Id=="Clone")
   {
      $herc1Id = "CloneRandom";
      say(0,2,"<f0>AI #1 Selection - Clone of Random Player");
   }   
   else if($herc1Id=="CloneRandom")
   {
      $herc1Id = 23;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Adjudicator");
   }   
}

function reverseAI1()
{
   if($herc1Id==38)
   {
      $herc1Id = 27;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Platinum Guard Adjudicator");
   }
   else if($herc1Id==1)
   {
      $herc1Id = 38;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Adjudicator");
   }
   else if($herc1Id==10)
   {
      $herc1Id = 1;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Apocalypse");
   }
   else if($herc1Id==31)
   {
      $herc1Id = 10;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Knight's Apocalypse");
   }
   else if($herc1Id==5)
   {
      $herc1Id = 31;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Avenger");
   }
   else if($herc1Id==14)
   {
      $herc1Id = 5;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Basilisk");
   }
   else if($herc1Id==25)
   {
      $herc1Id = 14;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Knight's Basilisk");
   }
   else if($herc1Id==8)
   {
      $herc1Id = 25;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Bolo");
   }
   else if($herc1Id==17)
   {
      $herc1Id = 8;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Disrupter");
   }
   else if($herc1Id==32)
   {
      $herc1Id = 17;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Knight's Disrupter");
   }
   else if($herc1Id==30)
   {
      $herc1Id = 32;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Dreadlock");
   }
   else if($herc1Id==24)
   {
      $herc1Id = 30;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Emancipator");
   }
   else if($herc1Id==28)
   {
      $herc1Id = 24;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Executioner");
   }
   else if($herc1Id==39)
   {
      $herc1Id = 28;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Platinum Guard Executioner");
   }
   else if($herc1Id==21)
   {
      $herc1Id = 39;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Executioner");
   }
   else if($herc1Id==36)
   {
      $herc1Id = 21;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Goad");
   }
   else if($herc1Id==3)
   {
      $herc1Id = 36;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Goad");
   }
   else if($herc1Id==12)
   {
      $herc1Id = 3;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Gorgon");
   }
   else if($herc1Id==2)
   {
      $herc1Id = 12;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Knight's Gorgon");
   }
   else if($herc1Id==11)
   {
      $herc1Id = 2;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Minotaur");
   }
   else if($herc1Id==7)
   {
      $herc1Id = 11;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Knight's Minotaur");
   }   
   else
   {
      reverseAI1cont();
   }
}

function reverseAI1cont()
{
   if($herc1Id==16)
   {
      $herc1Id = 7;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Myrmidon");
   }
   else if($herc1Id==133)
   {
      $herc1Id = 16;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Knight's Myrmidon");
   }
   else if($herc1Id==33)
   {
      $herc1Id = 133;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Nike Siege Tank");
   }
   else if($herc1Id==6)
   {
      $herc1Id = 33;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Olympian");
   }
   else if($herc1Id==15)
   {
      $herc1Id = 6;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Paladin");
   }
   else if($herc1Id==41)
   {
      $herc1Id = 15;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Knight's Paladin");
   }
   else if($herc1Id==26)
   {
      $herc1Id = 41;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Harabec's Predator");
   }
   else if($herc1Id==20)
   {
      $herc1Id = 26;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Recluse");
   }
   else if($herc1Id==35)
   {
      $herc1Id = 20;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Seeker");
   }
   else if($herc1Id==22)
   {
      $herc1Id = 35;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Seeker");
   }
   else if($herc1Id==37)
   {
      $herc1Id = 22;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Shepherd");
   }
   else if($herc1Id==4)
   {
      $herc1Id = 37;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Metagen Shepherd");
   }   
   else if($herc1Id==13)
   {
      $herc1Id = 4;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Talon");
   }   
   else if($herc1Id==40)
   {
      $herc1Id = 13;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Knight's Talon");
   }   
   else if($herc1Id==45)
   {
      $herc1Id = 40;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Harabec's Apocalypse");
   }   
   else if($herc1Id==42)
   {
      $herc1Id = 45;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Bek Storm's Predator");
   }   
   else if($herc1Id==29)
   {
      $herc1Id = 42;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Caanon's Basilisk");
   }   
   else if($herc1Id==138)
   {
      $herc1Id = 29;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Prometheus");
   }
   else if($herc1Id==150)
   {
      $herc1Id = 138;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Pouncer Assault Bike");
   }   
   else if($herc1Id=="Clone")
   {
      $herc1Id = 150;
      $herc1type = Tank;
      say(0,2,"<f0>AI #1 Selection - Starsiege Magic Bus");
   }      
   else if($herc1Id=="CloneRandom")
   {
      $herc1Id = "Clone";
      say(0,2,"<f0>AI #1 Selection - Clone of Player (Activator)");
   }         
   else
   {
      reverseAI1cont2();
   }
}

function reverseAI1cont2()
{
   if($herc1Id==23)
   {
      $herc1Id = "CloneRandom";
      say(0,2,"<f0>AI #1 Selection - Clone of Random Player");
   }   
   else if($herc1Id==27)
   {
      $herc1Id = 23;
      $herc1type = Herc;
      say(0,2,"<f0>AI #1 Selection - Adjudicator");
   }   
}

function AI2::structure::onscan(%scanned,%scanner)
{
   if(isShutDown(%scanner)==true)
   {
      reverseAI2();
   }
   else
   {
      if($herc2Id==23)
      {
         $herc2Id = 27;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Platinum Guard Adjudicator");
      }
      else if($herc2Id==27)
      {
         $herc2Id = 38;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Metagen Adjudicator");
      }
      else if($herc2Id==38)
      {
         $herc2Id = 1;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Apocalypse");
      }
      else if($herc2Id==1)
      {
         $herc2Id = 10;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Knight's Apocalypse");
      }
      else if($herc2Id==10)
      {
         $herc2Id = 31;
         $herc2type = Tank;
         say(0,4,"<f1>AI #2 Selection - Avenger");
      }
      else if($herc2Id==31)
      {
         $herc2Id = 5;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Basilisk");
      }
      else if($herc2Id==5)
      {
         $herc2Id = 14;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Knight's Basilisk");
      }
      else if($herc2Id==14)
      {
         $herc2Id = 25;
         $herc2type = Tank;
         say(0,4,"<f1>AI #2 Selection - Bolo");
      }
      else if($herc2Id==25)
      {
         $herc2Id = 8;
         $herc2type = Tank;
         say(0,4,"<f1>AI #2 Selection - Disrupter");
      }
      else if($herc2Id==8)
      {
         $herc2Id = 17;
         $herc2type = Tank;
         say(0,4,"<f1>AI #2 Selection - Knight's Disrupter");
      }
      else if($herc2Id==17)
      {
         $herc2Id = 32;
         $herc2type = Tank;
         say(0,4,"<f1>AI #2 Selection - Dreadlock");
      }
      else if($herc2Id==32)
      {
         $herc2Id = 30;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Emancipator");
      }
      else if($herc2Id==30)
      {
         $herc2Id = 24;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Executioner");
      }
      else if($herc2Id==24)
      {
         $herc2Id = 28;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Platinum Guard Executioner");
      }
      else if($herc2Id==28)
      {
         $herc2Id = 39;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Metagen Executioner");
      }
      else if($herc2Id==39)
      {
         $herc2Id = 21;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Goad");
      }
      else if($herc2Id==21)
      {
         $herc2Id = 36;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Metagen Goad");
      }
      else if($herc2Id==36)
      {
         $herc2Id = 3;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Gorgon");
      }
      else if($herc2Id==3)
      {
         $herc2Id = 12;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Knight's Gorgon");
      }
      else if($herc2Id==12)
      {
         $herc2Id = 2;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Minotaur");
      }
      else if($herc2Id==2)
      {
         $herc2Id = 11;
         $herc2type = Herc;
         say(0,4,"<f1>AI #2 Selection - Knight's Minotaur");
      }   
      else
      {
         AI2cont();
      }
   }
}

function AI2cont()
{
   if($herc2Id==11)
   {
      $herc2Id = 7;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Myrmidon");
   }
   else if($herc2Id==7)
   {
      $herc2Id = 16;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Knight's Myrmidon");
   }
   else if($herc2Id==16)
   {
      $herc2Id = 133;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Nike Siege Tank");
   }
   else if($herc2Id==133)
   {
      $herc2Id = 33;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Olympian");
   }
   else if($herc2Id==33)
   {
      $herc2Id = 6;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Paladin");
   }
   else if($herc2Id==6)
   {
      $herc2Id = 15;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Knight's Paladin");
   }
   else if($herc2Id==15)
   {
      $herc2Id = 41;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Harabec's Predator");
   }
   else if($herc2Id==41)
   {
      $herc2Id = 26;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Recluse");
   }
   else if($herc2Id==26)
   {
      $herc2Id = 20;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Seeker");
   }
   else if($herc2Id==20)
   {
      $herc2Id = 35;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Seeker");
   }
   else if($herc2Id==35)
   {
      $herc2Id = 22;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Shepherd");
   }
   else if($herc2Id==22)
   {
      $herc2Id = 37;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Shepherd");
   }   
   else if($herc2Id==37)
   {
      $herc2Id = 4;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Talon");
   }   
   else if($herc2Id==4)
   {
      $herc2Id = 13;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Knight's Talon");
   }   
   else if($herc2Id==13)
   {
      $herc2Id = 40;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Harabec's Apocalypse");
   }   
   else if($herc2Id==40)
   {
      $herc2Id = 45;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Bek Storm's Predator");
   }   
   else if($herc2Id==45)
   {
      $herc2Id = 42;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Caanon's Basilisk");
   }   
   else if($herc2Id==42)
   {
      $herc2Id = 29;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Prometheus");
   }
   else if($herc2Id==29)
   {
      $herc2Id = 138;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Pouncer Assault Bike");
   }   
   else if($herc2Id==138)
   {
      $herc2Id = 150;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Starsiege Magic Bus");
   }      
   else if($herc2Id==150)
   {
      $herc2Id = "Clone";
      say(0,4,"<f1>AI #2 Selection - Clone of Player (Activator)");
   }         
   else
   {
      AI2cont2();
   }
}

function AI2cont2()
{
   if($herc2Id=="Clone")
   {
      $herc2Id = "CloneRandom";
      say(0,4,"<f1>AI #2 Selection - Clone of Random Player");
   }   
   else if($herc2Id=="CloneRandom")
   {
      $herc2Id = 23;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Adjudicator");
   }   
}

function reverseAI2()
{
   if($herc2Id==38)
   {
      $herc2Id = 27;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Platinum Guard Adjudicator");
   }
   else if($herc2Id==1)
   {
      $herc2Id = 38;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Adjudicator");
   }
   else if($herc2Id==10)
   {
      $herc2Id = 1;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Apocalypse");
   }
   else if($herc2Id==31)
   {
      $herc2Id = 10;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Knight's Apocalypse");
   }
   else if($herc2Id==5)
   {
      $herc2Id = 31;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Avenger");
   }
   else if($herc2Id==14)
   {
      $herc2Id = 5;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Basilisk");
   }
   else if($herc2Id==25)
   {
      $herc2Id = 14;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Knight's Basilisk");
   }
   else if($herc2Id==8)
   {
      $herc2Id = 25;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Bolo");
   }
   else if($herc2Id==17)
   {
      $herc2Id = 8;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Disrupter");
   }
   else if($herc2Id==32)
   {
      $herc2Id = 17;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Knight's Disrupter");
   }
   else if($herc2Id==30)
   {
      $herc2Id = 32;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Dreadlock");
   }
   else if($herc2Id==24)
   {
      $herc2Id = 30;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Emancipator");
   }
   else if($herc2Id==28)
   {
      $herc2Id = 24;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Executioner");
   }
   else if($herc2Id==39)
   {
      $herc2Id = 28;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Platinum Guard Executioner");
   }
   else if($herc2Id==21)
   {
      $herc2Id = 39;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Executioner");
   }
   else if($herc2Id==36)
   {
      $herc2Id = 21;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Goad");
   }
   else if($herc2Id==3)
   {
      $herc2Id = 36;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Goad");
   }
   else if($herc2Id==12)
   {
      $herc2Id = 3;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Gorgon");
   }
   else if($herc2Id==2)
   {
      $herc2Id = 12;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Knight's Gorgon");
   }
   else if($herc2Id==11)
   {
      $herc2Id = 2;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Minotaur");
   }
   else if($herc2Id==7)
   {
      $herc2Id = 11;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Knight's Minotaur");
   }   
   else
   {
      reverseAI2cont();
   }
}

function reverseAI2cont()
{
   if($herc2Id==16)
   {
      $herc2Id = 7;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Myrmidon");
   }
   else if($herc2Id==133)
   {
      $herc2Id = 16;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Knight's Myrmidon");
   }
   else if($herc2Id==33)
   {
      $herc2Id = 133;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Nike Siege Tank");
   }
   else if($herc2Id==6)
   {
      $herc2Id = 33;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Olympian");
   }
   else if($herc2Id==15)
   {
      $herc2Id = 6;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Paladin");
   }
   else if($herc2Id==41)
   {
      $herc2Id = 15;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Knight's Paladin");
   }
   else if($herc2Id==26)
   {
      $herc2Id = 41;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Harabec's Predator");
   }
   else if($herc2Id==20)
   {
      $herc2Id = 26;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Recluse");
   }
   else if($herc2Id==35)
   {
      $herc2Id = 20;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Seeker");
   }
   else if($herc2Id==22)
   {
      $herc2Id = 35;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Seeker");
   }
   else if($herc2Id==37)
   {
      $herc2Id = 22;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Shepherd");
   }
   else if($herc2Id==4)
   {
      $herc2Id = 37;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Metagen Shepherd");
   }   
   else if($herc2Id==13)
   {
      $herc2Id = 4;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Talon");
   }   
   else if($herc2Id==40)
   {
      $herc2Id = 13;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Knight's Talon");
   }   
   else if($herc2Id==45)
   {
      $herc2Id = 40;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Harabec's Apocalypse");
   }   
   else if($herc2Id==42)
   {
      $herc2Id = 45;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Bek Storm's Predator");
   }   
   else if($herc2Id==29)
   {
      $herc2Id = 42;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Caanon's Basilisk");
   }   
   else if($herc2Id==138)
   {
      $herc2Id = 29;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Prometheus");
   }
   else if($herc2Id==150)
   {
      $herc2Id = 138;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Pouncer Assault Bike");
   }   
   else if($herc2Id=="Clone")
   {
      $herc2Id = 150;
      $herc2type = Tank;
      say(0,4,"<f1>AI #2 Selection - Starsiege Magic Bus");
   }      
   else if($herc2Id=="CloneRandom")
   {
      $herc2Id = "Clone";
      say(0,4,"<f1>AI #2 Selection - Clone of Player (Activator)");
   }         
   else
   {
      reverseAI2cont2();
   }
}

function reverseAI2cont2()
{
   if($herc2Id==23)
   {
      $herc2Id = "CloneRandom";
      say(0,4,"<f1>AI #2 Selection - Clone of Random Player");
   }   
   else if($herc2Id==27)
   {
      $herc2Id = 23;
      $herc2type = Herc;
      say(0,4,"<f1>AI #2 Selection - Adjudicator");
   }   
}

function AI3::structure::onscan(%scanned,%scanner)
{
   if(isShutDown(%scanner)==true)
   {
      reverseAI3();
   }
   else
   {
      if($herc3Id==23)
      {
         $herc3Id = 27;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Platinum Guard Adjudicator");
      }
      else if($herc3Id==27)
      {
         $herc3Id = 38;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Metagen Adjudicator");
      }
      else if($herc3Id==38)
      {
         $herc3Id = 1;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Apocalypse");
      }
      else if($herc3Id==1)
      {
         $herc3Id = 10;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Knight's Apocalypse");
      }
      else if($herc3Id==10)
      {
         $herc3Id = 31;
         $herc3type = Tank;
         say(0,5,"<f2>AI #3 Selection - Avenger");
      }
      else if($herc3Id==31)
      {
         $herc3Id = 5;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Basilisk");
      }
      else if($herc3Id==5)
      {
         $herc3Id = 14;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Knight's Basilisk");
      }
      else if($herc3Id==14)
      {
         $herc3Id = 25;
         $herc3type = Tank;
         say(0,5,"<f2>AI #3 Selection - Bolo");
      }
      else if($herc3Id==25)
      {
         $herc3Id = 8;
         $herc3type = Tank;
         say(0,5,"<f2>AI #3 Selection - Disrupter");
      }
      else if($herc3Id==8)
      {
         $herc3Id = 17;
         $herc3type = Tank;
         say(0,5,"<f2>AI #3 Selection - Knight's Disrupter");
      }
      else if($herc3Id==17)
      {
         $herc3Id = 32;
         $herc3type = Tank;
         say(0,5,"<f2>AI #3 Selection - Dreadlock");
      }
      else if($herc3Id==32)
      {
         $herc3Id = 30;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Emancipator");
      }
      else if($herc3Id==30)
      {
         $herc3Id = 24;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Executioner");
      }
      else if($herc3Id==24)
      {
         $herc3Id = 28;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Platinum Guard Executioner");
      }
      else if($herc3Id==28)
      {
         $herc3Id = 39;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Metagen Executioner");
      }
      else if($herc3Id==39)
      {
         $herc3Id = 21;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Goad");
      }
      else if($herc3Id==21)
      {
         $herc3Id = 36;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Metagen Goad");
      }
      else if($herc3Id==36)
      {
         $herc3Id = 3;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Gorgon");
      }
      else if($herc3Id==3)
      {
         $herc3Id = 12;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Knight's Gorgon");
      }
      else if($herc3Id==12)
      {
         $herc3Id = 2;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Minotaur");
      }
      else if($herc3Id==2)
      {
         $herc3Id = 11;
         $herc3type = Herc;
         say(0,5,"<f2>AI #3 Selection - Knight's Minotaur");
      }   
      else
      {
         AI3cont();
      }
   }
}

function AI3cont()
{
   if($herc3Id==11)
   {
      $herc3Id = 7;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Myrmidon");
   }
   else if($herc3Id==7)
   {
      $herc3Id = 16;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Knight's Myrmidon");
   }
   else if($herc3Id==16)
   {
      $herc3Id = 133;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Nike Siege Tank");
   }
   else if($herc3Id==133)
   {
      $herc3Id = 33;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Olympian");
   }
   else if($herc3Id==33)
   {
      $herc3Id = 6;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Paladin");
   }
   else if($herc3Id==6)
   {
      $herc3Id = 15;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Knight's Paladin");
   }
   else if($herc3Id==15)
   {
      $herc3Id = 41;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Harabec's Predator");
   }
   else if($herc3Id==41)
   {
      $herc3Id = 26;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Recluse");
   }
   else if($herc3Id==26)
   {
      $herc3Id = 20;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Seeker");
   }
   else if($herc3Id==20)
   {
      $herc3Id = 35;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Seeker");
   }
   else if($herc3Id==35)
   {
      $herc3Id = 22;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Shepherd");
   }
   else if($herc3Id==22)
   {
      $herc3Id = 37;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Shepherd");
   }   
   else if($herc3Id==37)
   {
      $herc3Id = 4;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Talon");
   }   
   else if($herc3Id==4)
   {
      $herc3Id = 13;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Knight's Talon");
   }   
   else if($herc3Id==13)
   {
      $herc3Id = 40;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Harabec's Apocalypse");
   }   
   else if($herc3Id==40)
   {
      $herc3Id = 45;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Bek Storm's Predator");
   }   
   else if($herc3Id==45)
   {
      $herc3Id = 42;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Caanon's Basilisk");
   }   
   else if($herc3Id==42)
   {
      $herc3Id = 29;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Prometheus");
   }
   else if($herc3Id==29)
   {
      $herc3Id = 138;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Pouncer Assault Bike");
   }   
   else if($herc3Id==138)
   {
      $herc3Id = 150;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Starsiege Magic Bus");
   }      
   else if($herc3Id==150)
   {
      $herc3Id = "Clone";
      say(0,5,"<f2>AI #3 Selection - Clone of Player (Activator)");
   }         
   else
   {
      AI3cont2();
   }
}

function AI3cont2()
{
   if($herc3Id=="Clone")
   {
      $herc3Id = "CloneRandom";
      say(0,5,"<f2>AI #3 Selection - Clone of Random Player");
   }   
   else if($herc3Id=="CloneRandom")
   {
      $herc3Id = 23;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Adjudicator");
   }   
}

function reverseAI3()
{
   if($herc3Id==38)
   {
      $herc3Id = 27;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Platinum Guard Adjudicator");
   }
   else if($herc3Id==1)
   {
      $herc3Id = 38;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Adjudicator");
   }
   else if($herc3Id==10)
   {
      $herc3Id = 1;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Apocalypse");
   }
   else if($herc3Id==31)
   {
      $herc3Id = 10;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Knight's Apocalypse");
   }
   else if($herc3Id==5)
   {
      $herc3Id = 31;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Avenger");
   }
   else if($herc3Id==14)
   {
      $herc3Id = 5;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Basilisk");
   }
   else if($herc3Id==25)
   {
      $herc3Id = 14;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Knight's Basilisk");
   }
   else if($herc3Id==8)
   {
      $herc3Id = 25;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Bolo");
   }
   else if($herc3Id==17)
   {
      $herc3Id = 8;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Disrupter");
   }
   else if($herc3Id==32)
   {
      $herc3Id = 17;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Knight's Disrupter");
   }
   else if($herc3Id==30)
   {
      $herc3Id = 32;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Dreadlock");
   }
   else if($herc3Id==24)
   {
      $herc3Id = 30;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Emancipator");
   }
   else if($herc3Id==28)
   {
      $herc3Id = 24;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Executioner");
   }
   else if($herc3Id==39)
   {
      $herc3Id = 28;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Platinum Guard Executioner");
   }
   else if($herc3Id==21)
   {
      $herc3Id = 39;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Executioner");
   }
   else if($herc3Id==36)
   {
      $herc3Id = 21;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Goad");
   }
   else if($herc3Id==3)
   {
      $herc3Id = 36;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Goad");
   }
   else if($herc3Id==12)
   {
      $herc3Id = 3;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Gorgon");
   }
   else if($herc3Id==2)
   {
      $herc3Id = 12;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Knight's Gorgon");
   }
   else if($herc3Id==11)
   {
      $herc3Id = 2;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Minotaur");
   }
   else if($herc3Id==7)
   {
      $herc3Id = 11;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Knight's Minotaur");
   }   
   else
   {
      reverseAI3cont();
   }
}

function reverseAI3cont()
{
   if($herc3Id==16)
   {
      $herc3Id = 7;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Myrmidon");
   }
   else if($herc3Id==133)
   {
      $herc3Id = 16;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Knight's Myrmidon");
   }
   else if($herc3Id==33)
   {
      $herc3Id = 133;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Nike Siege Tank");
   }
   else if($herc3Id==6)
   {
      $herc3Id = 33;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Olympian");
   }
   else if($herc3Id==15)
   {
      $herc3Id = 6;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Paladin");
   }
   else if($herc3Id==41)
   {
      $herc3Id = 15;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Knight's Paladin");
   }
   else if($herc3Id==26)
   {
      $herc3Id = 41;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Harabec's Predator");
   }
   else if($herc3Id==20)
   {
      $herc3Id = 26;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Recluse");
   }
   else if($herc3Id==35)
   {
      $herc3Id = 20;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Seeker");
   }
   else if($herc3Id==22)
   {
      $herc3Id = 35;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Seeker");
   }
   else if($herc3Id==37)
   {
      $herc3Id = 22;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Shepherd");
   }
   else if($herc3Id==4)
   {
      $herc3Id = 37;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Metagen Shepherd");
   }   
   else if($herc3Id==13)
   {
      $herc3Id = 4;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Talon");
   }   
   else if($herc3Id==40)
   {
      $herc3Id = 13;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Knight's Talon");
   }   
   else if($herc3Id==45)
   {
      $herc3Id = 40;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Harabec's Apocalypse");
   }   
   else if($herc3Id==42)
   {
      $herc3Id = 45;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Bek Storm's Predator");
   }   
   else if($herc3Id==29)
   {
      $herc3Id = 42;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Caanon's Basilisk");
   }   
   else if($herc3Id==138)
   {
      $herc3Id = 29;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Prometheus");
   }
   else if($herc3Id==150)
   {
      $herc3Id = 138;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Pouncer Assault Bike");
   }   
   else if($herc3Id=="Clone")
   {
      $herc3Id = 150;
      $herc3type = Tank;
      say(0,5,"<f2>AI #3 Selection - Starsiege Magic Bus");
   }      
   else if($herc3Id=="CloneRandom")
   {
      $herc3Id = "Clone";
      say(0,5,"<f2>AI #3 Selection - Clone of Player (Activator)");
   }         
   else
   {
      reverseAI3cont2();
   }
}

function reverseAI3cont2()
{
   if($herc3Id==23)
   {
      $herc3Id = "CloneRandom";
      say(0,5,"<f2>AI #3 Selection - Clone of Random Player");
   }   
   else if($herc3Id==27)
   {
      $herc3Id = 23;
      $herc3type = Herc;
      say(0,5,"<f2>AI #3 Selection - Adjudicator");
   }   
}

function AI4::structure::onscan(%scanned,%scanner)
{
   if(isShutDown(%scanner)==true)
   {
      reverseAI4();
   }
   else
   {
      if($herc4Id==23)
      {
         $herc4Id = 27;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Platinum Guard Adjudicator");
      }
      else if($herc4Id==27)
      {
         $herc4Id = 38;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Metagen Adjudicator");
      }
      else if($herc4Id==38)
      {
         $herc4Id = 1;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Apocalypse");
      }
      else if($herc4Id==1)
      {
         $herc4Id = 10;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Knight's Apocalypse");
      }
      else if($herc4Id==10)
      {
         $herc4Id = 31;
         $herc4type = Tank;
         say(0,6,"<f4>AI #4 Selection - Avenger");
      }
      else if($herc4Id==31)
      {
         $herc4Id = 5;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Basilisk");
      }
      else if($herc4Id==5)
      {
         $herc4Id = 14;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Knight's Basilisk");
      }
      else if($herc4Id==14)
      {
         $herc4Id = 25;
         $herc4type = Tank;
         say(0,6,"<f4>AI #4 Selection - Bolo");
      }
      else if($herc4Id==25)
      {
         $herc4Id = 8;
         $herc4type = Tank;
         say(0,6,"<f4>AI #4 Selection - Disrupter");
      }
      else if($herc4Id==8)
      {
         $herc4Id = 17;
         $herc4type = Tank;
         say(0,6,"<f4>AI #4 Selection - Knight's Disrupter");
      }
      else if($herc4Id==17)
      {
         $herc4Id = 32;
         $herc4type = Tank;
         say(0,6,"<f4>AI #4 Selection - Dreadlock");
      }
      else if($herc4Id==32)
      {
         $herc4Id = 30;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Emancipator");
      }
      else if($herc4Id==30)
      {
         $herc4Id = 24;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Executioner");
      }
      else if($herc4Id==24)
      {
         $herc4Id = 28;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Platinum Guard Executioner");
      }
      else if($herc4Id==28)
      {
         $herc4Id = 39;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Metagen Executioner");
      }
      else if($herc4Id==39)
      {
         $herc4Id = 21;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Goad");
      }
      else if($herc4Id==21)
      {
         $herc4Id = 36;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Metagen Goad");
      }
      else if($herc4Id==36)
      {
         $herc4Id = 3;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Gorgon");
      }
      else if($herc4Id==3)
      {
         $herc4Id = 12;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Knight's Gorgon");
      }
      else if($herc4Id==12)
      {
         $herc4Id = 2;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Minotaur");
      }
      else if($herc4Id==2)
      {
         $herc4Id = 11;
         $herc4type = Herc;
         say(0,6,"<f4>AI #4 Selection - Knight's Minotaur");
      }   
      else
      {
         AI4cont();
      }
   }
}

function AI4cont()
{
   if($herc4Id==11)
   {
      $herc4Id = 7;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Myrmidon");
   }
   else if($herc4Id==7)
   {
      $herc4Id = 16;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Knight's Myrmidon");
   }
   else if($herc4Id==16)
   {
      $herc4Id = 133;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Nike Siege Tank");
   }
   else if($herc4Id==133)
   {
      $herc4Id = 33;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Olympian");
   }
   else if($herc4Id==33)
   {
      $herc4Id = 6;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Paladin");
   }
   else if($herc4Id==6)
   {
      $herc4Id = 15;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Knight's Paladin");
   }
   else if($herc4Id==15)
   {
      $herc4Id = 41;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Harabec's Predator");
   }
   else if($herc4Id==41)
   {
      $herc4Id = 26;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Recluse");
   }
   else if($herc4Id==26)
   {
      $herc4Id = 20;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Seeker");
   }
   else if($herc4Id==20)
   {
      $herc4Id = 35;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Seeker");
   }
   else if($herc4Id==35)
   {
      $herc4Id = 22;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Shepherd");
   }
   else if($herc4Id==22)
   {
      $herc4Id = 37;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Shepherd");
   }   
   else if($herc4Id==37)
   {
      $herc4Id = 4;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Talon");
   }   
   else if($herc4Id==4)
   {
      $herc4Id = 13;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Knight's Talon");
   }   
   else if($herc4Id==13)
   {
      $herc4Id = 40;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Harabec's Apocalypse");
   }   
   else if($herc4Id==40)
   {
      $herc4Id = 45;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Bek Storm's Predator");
   }   
   else if($herc4Id==45)
   {
      $herc4Id = 42;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Caanon's Basilisk");
   }   
   else if($herc4Id==42)
   {
      $herc4Id = 29;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Prometheus");
   }
   else if($herc4Id==29)
   {
      $herc4Id = 138;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Pouncer Assault Bike");
   }   
   else if($herc4Id==138)
   {
      $herc4Id = 150;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Starsiege Magic Bus");
   }      
   else if($herc4Id==150)
   {
      $herc4Id = "Clone";
      say(0,6,"<f4>AI #4 Selection - Clone of Player (Activator)");
   }         
   else
   {
      AI4cont2();
   }
}

function AI4cont2()
{
   if($herc4Id=="Clone")
   {
      $herc4Id = "CloneRandom";
      say(0,6,"<f4>AI #4 Selection - Clone of Random Player");
   }   
   else if($herc4Id=="CloneRandom")
   {
      $herc4Id = 23;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Adjudicator");
   }   
}

function reverseAI4()
{
   if($herc4Id==38)
   {
      $herc4Id = 27;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Platinum Guard Adjudicator");
   }
   else if($herc4Id==1)
   {
      $herc4Id = 38;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Adjudicator");
   }
   else if($herc4Id==10)
   {
      $herc4Id = 1;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Apocalypse");
   }
   else if($herc4Id==31)
   {
      $herc4Id = 10;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Knight's Apocalypse");
   }
   else if($herc4Id==5)
   {
      $herc4Id = 31;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Avenger");
   }
   else if($herc4Id==14)
   {
      $herc4Id = 5;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Basilisk");
   }
   else if($herc4Id==25)
   {
      $herc4Id = 14;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Knight's Basilisk");
   }
   else if($herc4Id==8)
   {
      $herc4Id = 25;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Bolo");
   }
   else if($herc4Id==17)
   {
      $herc4Id = 8;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Disrupter");
   }
   else if($herc4Id==32)
   {
      $herc4Id = 17;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Knight's Disrupter");
   }
   else if($herc4Id==30)
   {
      $herc4Id = 32;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Dreadlock");
   }
   else if($herc4Id==24)
   {
      $herc4Id = 30;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Emancipator");
   }
   else if($herc4Id==28)
   {
      $herc4Id = 24;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Executioner");
   }
   else if($herc4Id==39)
   {
      $herc4Id = 28;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Platinum Guard Executioner");
   }
   else if($herc4Id==21)
   {
      $herc4Id = 39;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Executioner");
   }
   else if($herc4Id==36)
   {
      $herc4Id = 21;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Goad");
   }
   else if($herc4Id==3)
   {
      $herc4Id = 36;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Goad");
   }
   else if($herc4Id==12)
   {
      $herc4Id = 3;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Gorgon");
   }
   else if($herc4Id==2)
   {
      $herc4Id = 12;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Knight's Gorgon");
   }
   else if($herc4Id==11)
   {
      $herc4Id = 2;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Minotaur");
   }
   else if($herc4Id==7)
   {
      $herc4Id = 11;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Knight's Minotaur");
   }   
   else
   {
      reverseAI4cont();
   }
}

function reverseAI4cont()
{
   if($herc4Id==16)
   {
      $herc4Id = 7;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Myrmidon");
   }
   else if($herc4Id==133)
   {
      $herc4Id = 16;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Knight's Myrmidon");
   }
   else if($herc4Id==33)
   {
      $herc4Id = 133;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Nike Siege Tank");
   }
   else if($herc4Id==6)
   {
      $herc4Id = 33;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Olympian");
   }
   else if($herc4Id==15)
   {
      $herc4Id = 6;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Paladin");
   }
   else if($herc4Id==41)
   {
      $herc4Id = 15;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Knight's Paladin");
   }
   else if($herc4Id==26)
   {
      $herc4Id = 41;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Harabec's Predator");
   }
   else if($herc4Id==20)
   {
      $herc4Id = 26;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Recluse");
   }
   else if($herc4Id==35)
   {
      $herc4Id = 20;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Seeker");
   }
   else if($herc4Id==22)
   {
      $herc4Id = 35;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Seeker");
   }
   else if($herc4Id==37)
   {
      $herc4Id = 22;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Shepherd");
   }
   else if($herc4Id==4)
   {
      $herc4Id = 37;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Metagen Shepherd");
   }   
   else if($herc4Id==13)
   {
      $herc4Id = 4;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Talon");
   }   
   else if($herc4Id==40)
   {
      $herc4Id = 13;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Knight's Talon");
   }   
   else if($herc4Id==45)
   {
      $herc4Id = 40;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Harabec's Apocalypse");
   }   
   else if($herc4Id==42)
   {
      $herc4Id = 45;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Bek Storm's Predator");
   }   
   else if($herc4Id==29)
   {
      $herc4Id = 42;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Caanon's Basilisk");
   }   
   else if($herc4Id==138)
   {
      $herc4Id = 29;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Prometheus");
   }
   else if($herc4Id==150)
   {
      $herc4Id = 138;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Pouncer Assault Bike");
   }   
   else if($herc4Id=="Clone")
   {
      $herc4Id = 150;
      $herc4type = Tank;
      say(0,6,"<f4>AI #4 Selection - Starsiege Magic Bus");
   }      
   else if($herc4Id=="CloneRandom")
   {
      $herc4Id = "Clone";
      say(0,6,"<f4>AI #4 Selection - Clone of Player (Activator)");
   }         
   else
   {
      reverseAI4cont2();
   }   
}

function reverseAI4cont2()
{
   if($herc4Id==23)
   {
      $herc4Id = "CloneRandom";
      say(0,6,"<f4>AI #4 Selection - Clone of Random Player");
   }   
   else if($herc4Id==27)
   {
      $herc4Id = 23;
      $herc4type = Herc;
      say(0,6,"<f4>AI #4 Selection - Adjudicator");
   }   
}

function AI5::structure::onscan(%scanned,%scanner)
{
   if(isShutDown(%scanner)==true)
   {
      reverseAI5();
   }
   else
   {
      if($herc5Id==23)
      {
         $herc5Id = 27;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Platinum Guard Adjudicator");
      }
      else if($herc5Id==27)
      {
         $herc5Id = 38;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Metagen Adjudicator");
      }
      else if($herc5Id==38)
      {
         $herc5Id = 1;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Apocalypse");
      }
      else if($herc5Id==1)
      {
         $herc5Id = 10;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Knight's Apocalypse");
      }
      else if($herc5Id==10)
      {
         $herc5Id = 31;
         $herc5type = Tank;
         say(0,7,"<f5>AI #5 Selection - Avenger");
      }
      else if($herc5Id==31)
      {
         $herc5Id = 5;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Basilisk");
      }
      else if($herc5Id==5)
      {
         $herc5Id = 14;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Knight's Basilisk");
      }
      else if($herc5Id==14)
      {
         $herc5Id = 25;
         $herc5type = Tank;
         say(0,7,"<f5>AI #5 Selection - Bolo");
      }
      else if($herc5Id==25)
      {
         $herc5Id = 8;
         $herc5type = Tank;
         say(0,7,"<f5>AI #5 Selection - Disrupter");
      }
      else if($herc5Id==8)
      {
         $herc5Id = 17;
         $herc5type = Tank;
         say(0,7,"<f5>AI #5 Selection - Knight's Disrupter");
      }
      else if($herc5Id==17)
      {
         $herc5Id = 32;
         $herc5type = Tank;
         say(0,7,"<f5>AI #5 Selection - Dreadlock");
      }
      else if($herc5Id==32)
      {
         $herc5Id = 30;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Emancipator");
      }
      else if($herc5Id==30)
      {
         $herc5Id = 24;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Executioner");
      }
      else if($herc5Id==24)
      {
         $herc5Id = 28;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Platinum Guard Executioner");
      }
      else if($herc5Id==28)
      {
         $herc5Id = 39;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Metagen Executioner");
      }
      else if($herc5Id==39)
      {
         $herc5Id = 21;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Goad");
      }
      else if($herc5Id==21)
      {
         $herc5Id = 36;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Metagen Goad");
      }
      else if($herc5Id==36)
      {
         $herc5Id = 3;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Gorgon");
      }
      else if($herc5Id==3)
      {
         $herc5Id = 12;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Knight's Gorgon");
      }
      else if($herc5Id==12)
      {
         $herc5Id = 2;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Minotaur");
      }
      else if($herc5Id==2)
      {
         $herc5Id = 11;
         $herc5type = Herc;
         say(0,7,"<f5>AI #5 Selection - Knight's Minotaur");
      }   
      else
      {
         AI5cont();
      }
   }
}

function AI5cont()
{
   if($herc5Id==11)
   {
      $herc5Id = 7;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Myrmidon");
   }
   else if($herc5Id==7)
   {
      $herc5Id = 16;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Knight's Myrmidon");
   }
   else if($herc5Id==16)
   {
      $herc5Id = 133;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Nike Siege Tank");
   }
   else if($herc5Id==133)
   {
      $herc5Id = 33;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Olympian");
   }
   else if($herc5Id==33)
   {
      $herc5Id = 6;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Paladin");
   }
   else if($herc5Id==6)
   {
      $herc5Id = 15;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Knight's Paladin");
   }
   else if($herc5Id==15)
   {
      $herc5Id = 41;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Harabec's Predator");
   }
   else if($herc5Id==41)
   {
      $herc5Id = 26;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Recluse");
   }
   else if($herc5Id==26)
   {
      $herc5Id = 20;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Seeker");
   }
   else if($herc5Id==20)
   {
      $herc5Id = 35;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Seeker");
   }
   else if($herc5Id==35)
   {
      $herc5Id = 22;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Shepherd");
   }
   else if($herc5Id==22)
   {
      $herc5Id = 37;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Shepherd");
   }   
   else if($herc5Id==37)
   {
      $herc5Id = 4;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Talon");
   }   
   else if($herc5Id==4)
   {
      $herc5Id = 13;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Knight's Talon");
   }   
   else if($herc5Id==13)
   {
      $herc5Id = 40;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Harabec's Apocalypse");
   }   
   else if($herc5Id==40)
   {
      $herc5Id = 45;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Bek Storm's Predator");
   }   
   else if($herc5Id==45)
   {
      $herc5Id = 42;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Caanon's Basilisk");
   }   
   else if($herc5Id==42)
   {
      $herc5Id = 29;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Prometheus");
   }
   else if($herc5Id==29)
   {
      $herc5Id = 138;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Pouncer Assault Bike");
   }   
   else if($herc5Id==138)
   {
      $herc5Id = 150;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Starsiege Magic Bus");
   }      
   else if($herc5Id==150)
   {
      $herc5Id = "Clone";
      say(0,7,"<f5>AI #5 Selection - Clone of Player (Activator)");
   }         
   else
   {
      AI5cont2();
   }
}

function AI5cont2()
{
   if($herc5Id=="Clone")
   {
      $herc5Id = "CloneRandom";
      say(0,7,"<f5>AI #5 Selection - Clone of Random Player");
   }   
   else if($herc5Id=="CloneRandom")
   {
      $herc5Id = 23;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Adjudicator");
   }   
}

function reverseAI5()
{
   if($herc5Id==38)
   {
      $herc5Id = 27;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Platinum Guard Adjudicator");
   }
   else if($herc5Id==1)
   {
      $herc5Id = 38;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Adjudicator");
   }
   else if($herc5Id==10)
   {
      $herc5Id = 1;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Apocalypse");
   }
   else if($herc5Id==31)
   {
      $herc5Id = 10;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Knight's Apocalypse");
   }
   else if($herc5Id==5)
   {
      $herc5Id = 31;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Avenger");
   }
   else if($herc5Id==14)
   {
      $herc5Id = 5;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Basilisk");
   }
   else if($herc5Id==25)
   {
      $herc5Id = 14;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Knight's Basilisk");
   }
   else if($herc5Id==8)
   {
      $herc5Id = 25;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Bolo");
   }
   else if($herc5Id==17)
   {
      $herc5Id = 8;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Disrupter");
   }
   else if($herc5Id==32)
   {
      $herc5Id = 17;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Knight's Disrupter");
   }
   else if($herc5Id==30)
   {
      $herc5Id = 32;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Dreadlock");
   }
   else if($herc5Id==24)
   {
      $herc5Id = 30;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Emancipator");
   }
   else if($herc5Id==28)
   {
      $herc5Id = 24;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Executioner");
   }
   else if($herc5Id==39)
   {
      $herc5Id = 28;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Platinum Guard Executioner");
   }
   else if($herc5Id==21)
   {
      $herc5Id = 39;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Executioner");
   }
   else if($herc5Id==36)
   {
      $herc5Id = 21;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Goad");
   }
   else if($herc5Id==3)
   {
      $herc5Id = 36;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Goad");
   }
   else if($herc5Id==12)
   {
      $herc5Id = 3;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Gorgon");
   }
   else if($herc5Id==2)
   {
      $herc5Id = 12;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Knight's Gorgon");
   }
   else if($herc5Id==11)
   {
      $herc5Id = 2;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Minotaur");
   }
   else if($herc5Id==7)
   {
      $herc5Id = 11;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Knight's Minotaur");
   }   
   else
   {
      reverseAI5cont();
   }
}

function reverseAI5cont()
{
   if($herc5Id==16)
   {
      $herc5Id = 7;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Myrmidon");
   }
   else if($herc5Id==133)
   {
      $herc5Id = 16;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Knight's Myrmidon");
   }
   else if($herc5Id==33)
   {
      $herc5Id = 133;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Nike Siege Tank");
   }
   else if($herc5Id==6)
   {
      $herc5Id = 33;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Olympian");
   }
   else if($herc5Id==15)
   {
      $herc5Id = 6;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Paladin");
   }
   else if($herc5Id==41)
   {
      $herc5Id = 15;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Knight's Paladin");
   }
   else if($herc5Id==26)
   {
      $herc5Id = 41;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Harabec's Predator");
   }
   else if($herc5Id==20)
   {
      $herc5Id = 26;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Recluse");
   }
   else if($herc5Id==35)
   {
      $herc5Id = 20;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Seeker");
   }
   else if($herc5Id==22)
   {
      $herc5Id = 35;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Seeker");
   }
   else if($herc5Id==37)
   {
      $herc5Id = 22;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Shepherd");
   }
   else if($herc5Id==4)
   {
      $herc5Id = 37;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Metagen Shepherd");
   }   
   else if($herc5Id==13)
   {
      $herc5Id = 4;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Talon");
   }   
   else if($herc5Id==40)
   {
      $herc5Id = 13;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Knight's Talon");
   }   
   else if($herc5Id==45)
   {
      $herc5Id = 40;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Harabec's Apocalypse");
   }   
   else if($herc5Id==42)
   {
      $herc5Id = 45;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Bek Storm's Predator");
   }   
   else if($herc5Id==29)
   {
      $herc5Id = 42;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Caanon's Basilisk");
   }   
   else if($herc5Id==138)
   {
      $herc5Id = 29;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Prometheus");
   }
   else if($herc5Id==150)
   {
      $herc5Id = 138;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Pouncer Assault Bike");
   }   
   else if($herc5Id=="Clone")
   {
      $herc5Id = 150;
      $herc5type = Tank;
      say(0,7,"<f5>AI #5 Selection - Starsiege Magic Bus");
   }      
   else if($herc5Id=="CloneRandom")
   {
      $herc5Id = "Clone";
      say(0,7,"<f5>AI #5 Selection - Clone of Player (Activator)");
   }         
   else
   {
      reverseAI5cont2();
   }
}

function reverseAI5cont2()
{
   if($herc5Id==23)
   {
      $herc5Id = "CloneRandom";
      say(0,7,"<f5>AI #5 Selection - Clone of Random Player");
   }   
   else if($herc5Id==27)
   {
      $herc5Id = 23;
      $herc5type = Herc;
      say(0,7,"<f5>AI #5 Selection - Adjudicator");
   }   
}

function AIall::structure::onscan(%scanned,%scanner)
{
   if(isShutDown(%scanner)==true)
   {
      reverseAIall();
   }
   else
   {
      if($hercallId==23)
      {
         $hercallId = 27;
         $herc1Id = 27;
         $herc2Id = 27;
         $herc3Id = 27;
         $herc4Id = 27;
         $herc5Id = 27;         
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Platinum Guard Adjudicator");
      }
      else if($hercallId==27)
      {
         $hercallId = 38;
         $herc1Id = 38;
         $herc2Id = 38;
         $herc3Id = 38;
         $herc4Id = 38;
         $herc5Id = 38;         
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Metagen Adjudicator");
      }
      else if($hercallId==38)
      {
         $hercallId = 1;
         $herc1Id = 1;
         $herc2Id = 1;
         $herc3Id = 1;
         $herc4Id = 1;
         $herc5Id = 1;
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Apocalypse");
      }
      else if($hercallId==1)
      {
         $hercallId = 10;
         $herc1Id = 10;
         $herc2Id = 10;
         $herc3Id = 10;
         $herc4Id = 10;
         $herc5Id = 10;
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Knight's Apocalypse");
      }
      else if($hercallId==10)
      {
         $hercallId = 31;
         $herc1Id = 31;
         $herc2Id = 31;
         $herc3Id = 31;
         $herc4Id = 31;
         $herc5Id = 31;    
         $herc1type = Tank;
         $herc2type = Tank;
         $herc3type = Tank;
         $herc4type = Tank;
         $herc5type = Tank;
         say(0,8,"<f6>Total AI Selection - Avenger");
      }
      else if($hercallId==31)
      {
         $hercallId = 5;
         $herc1Id = 5;
         $herc2Id = 5;
         $herc3Id = 5;
         $herc4Id = 5;
         $herc5Id = 5;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Basilisk");
      }
      else if($hercallId==5)
      {
         $hercallId = 14;
         $herc1Id = 14;
         $herc2Id = 14;
         $herc3Id = 14;
         $herc4Id = 14;
         $herc5Id = 14;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Knight's Basilisk");
      }
      else if($hercallId==14)
      {
         $hercallId = 25;
         $herc1Id = 25;
         $herc2Id = 25;
         $herc3Id = 25;
         $herc4Id = 25;
         $herc5Id = 25;    
         $herc1type = Tank;
         $herc2type = Tank;
         $herc3type = Tank;
         $herc4type = Tank;
         $herc5type = Tank;
         say(0,8,"<f6>Total AI Selection - Bolo");
      }
      else if($hercallId==25)
      {
         $hercallId = 8;
         $herc1Id = 8;
         $herc2Id = 8;
         $herc3Id = 8;
         $herc4Id = 8;
         $herc5Id = 8;    
         $herc1type = Tank;
         $herc2type = Tank;
         $herc3type = Tank;
         $herc4type = Tank;
         $herc5type = Tank;
         say(0,8,"<f6>Total AI Selection - Disrupter");
      }
      else if($hercallId==8)
      {
         $hercallId = 17;
         $herc1Id = 17;
         $herc2Id = 17;
         $herc3Id = 17;
         $herc4Id = 17;
         $herc5Id = 17;    
         $herc1type = Tank;
         $herc2type = Tank;
         $herc3type = Tank;
         $herc4type = Tank;
         $herc5type = Tank;
         say(0,8,"<f6>Total AI Selection - Knight's Disrupter");
      }
      else if($hercallId==17)
      {
         $hercallId = 32;
         $herc1Id = 32;
         $herc2Id = 32;
         $herc3Id = 32;
         $herc4Id = 32;
         $herc5Id = 32;    
         $herc1type = Tank;
         $herc2type = Tank;
         $herc3type = Tank;
         $herc4type = Tank;
         $herc5type = Tank;
         say(0,8,"<f6>Total AI Selection - Dreadlock");
      }
      else if($hercallId==32)
      {
         $hercallId = 30;
         $herc1Id = 30;
         $herc2Id = 30;
         $herc3Id = 30;
         $herc4Id = 30;
         $herc5Id = 30;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Emancipator");
      }
      else if($hercallId==30)
      {
         $hercallId = 24;
         $herc1Id = 24;
         $herc2Id = 24;
         $herc3Id = 24;
         $herc4Id = 24;
         $herc5Id = 24;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Executioner");
      }
      else if($hercallId==24)
      {
         $hercallId = 28;
         $herc1Id = 28;
         $herc2Id = 28;
         $herc3Id = 28;
         $herc4Id = 28;
         $herc5Id = 28;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Platinum Guard Executioner");
      }
      else if($hercallId==28)
      {
         $hercallId = 39;
         $herc1Id = 39;
         $herc2Id = 39;
         $herc3Id = 39;
         $herc4Id = 39;
         $herc5Id = 39;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Metagen Executioner");
      }
      else if($hercallId==39)
      {
         $hercallId = 21;
         $herc1Id = 21;
         $herc2Id = 21;
         $herc3Id = 21;
         $herc4Id = 21;
         $herc5Id = 21;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Goad");
      }
      else if($hercallId==21)
      {
         $hercallId = 36;
         $herc1Id = 36;
         $herc2Id = 36;
         $herc3Id = 36;
         $herc4Id = 36;
         $herc5Id = 36;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Metagen Goad");
      }
      else if($hercallId==36)
      {
         $hercallId = 3;
         $herc1Id = 3;
         $herc2Id = 3;
         $herc3Id = 3;
         $herc4Id = 3;
         $herc5Id = 3;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Gorgon");
      }
      else if($hercallId==3)
      {
         $hercallId = 12;
         $herc1Id = 12;
         $herc2Id = 12;
         $herc3Id = 12;
         $herc4Id = 12;
         $herc5Id = 12;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Knight's Gorgon");
      }
      else if($hercallId==12)
      {
         $hercallId = 2;
         $herc1Id = 2;
         $herc2Id = 2;
         $herc3Id = 2;
         $herc4Id = 2;
         $herc5Id = 2;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Minotaur");
      }
      else if($hercallId==2)
      {
         $hercallId = 11;
         $herc1Id = 11;
         $herc2Id = 11;
         $herc3Id = 11;
         $herc4Id = 11;
         $herc5Id = 11;    
         $herc1type = Herc;
         $herc2type = Herc;
         $herc3type = Herc;
         $herc4type = Herc;
         $herc5type = Herc;
         say(0,8,"<f6>Total AI Selection - Knight's Minotaur");
      }   
      else
      {
         AIallcont();
      }
   }
}

function AIallcont()
{
   if($hercallId==11)
   {
      $hercallId = 7;
      $herc1Id = 7;
      $herc2Id = 7;
      $herc3Id = 7;
      $herc4Id = 7;
      $herc5Id = 7;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Myrmidon");
   }
   else if($hercallId==7)
   {
      $hercallId = 16;
      $herc1Id = 16;
      $herc2Id = 16;
      $herc3Id = 16;
      $herc4Id = 16;
      $herc5Id = 16;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Knight's Myrmidon");
   }
   else if($hercallId==16)
   {
      $hercallId = 133;
      $herc1Id = 133;
      $herc2Id = 133;
      $herc3Id = 133;
      $herc4Id = 133;
      $herc5Id = 133;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Nike Siege Tank");
   }
   else if($hercallId==133)
   {
      $hercallId = 33;
      $herc1Id = 33;
      $herc2Id = 33;
      $herc3Id = 33;
      $herc4Id = 33;
      $herc5Id = 33;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Olympian");
   }
   else if($hercallId==33)
   {
      $hercallId = 6;
      $herc1Id = 6;
      $herc2Id = 6;
      $herc3Id = 6;
      $herc4Id = 6;
      $herc5Id = 6;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Paladin");
   }
   else if($hercallId==6)
   {
      $hercallId = 15;
      $herc1Id = 15;
      $herc2Id = 15;
      $herc3Id = 15;
      $herc4Id = 15;
      $herc5Id = 15;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Knight's Paladin");
   }
   else if($hercallId==15)
   {
      $hercallId = 41;
      $herc1Id = 41;
      $herc2Id = 41;
      $herc3Id = 41;
      $herc4Id = 41;
      $herc5Id = 41;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Harabec's Predator");
   }
   else if($hercallId==41)
   {
      $hercallId = 26;
      $herc1Id = 26;
      $herc2Id = 26;
      $herc3Id = 26;
      $herc4Id = 26;
      $herc5Id = 26;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Recluse");
   }
   else if($hercallId==26)
   {
      $hercallId = 20;
      $herc1Id = 20;
      $herc2Id = 20;
      $herc3Id = 20;
      $herc4Id = 20;
      $herc5Id = 20;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Seeker");
   }
   else if($hercallId==20)
   {
      $hercallId = 35;
      $herc1Id = 35;
      $herc2Id = 35;
      $herc3Id = 35;
      $herc4Id = 35;
      $herc5Id = 35;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Seeker");
   }
   else if($hercallId==35)
   {
      $hercallId = 22;
      $herc1Id = 22;
      $herc2Id = 22;
      $herc3Id = 22;
      $herc4Id = 22;
      $herc5Id = 22;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Shepherd");
   }
   else if($hercallId==22)
   {
      $hercallId = 37;
      $herc1Id = 37;
      $herc2Id = 37;
      $herc3Id = 37;
      $herc4Id = 37;
      $herc5Id = 37;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Shepherd");
   }   
   else if($hercallId==37)
   {
      $hercallId = 4;
      $herc1Id = 4;
      $herc2Id = 4;
      $herc3Id = 4;
      $herc4Id = 4;
      $herc5Id = 4;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Talon");
   }   
   else if($hercallId==4)
   {
      $hercallId = 13;
      $herc1Id = 13;
      $herc2Id = 13;
      $herc3Id = 13;
      $herc4Id = 13;
      $herc5Id = 13;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Knight's Talon");
   }   
   else if($hercallId==13)
   {
      $hercallId = 40;
      $herc1Id = 40;
      $herc2Id = 40;
      $herc3Id = 40;
      $herc4Id = 40;
      $herc5Id = 40;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Harabec's Apocalypse");
   }   
   else if($hercallId==40)
   {
      $hercallId = 45;
      $herc1Id = 45;
      $herc2Id = 45;
      $herc3Id = 45;
      $herc4Id = 45;
      $herc5Id = 45;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Bek Storm's Predator");
   }   
   else if($hercallId==45)
   {
      $hercallId = 42;
      $herc1Id = 42;
      $herc2Id = 42;
      $herc3Id = 42;
      $herc4Id = 42;
      $herc5Id = 42;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Caanon's Basilisk");
   }   
   else if($hercallId==42)
   {
      $hercallId = 29;
      $herc1Id = 29;
      $herc2Id = 29;
      $herc3Id = 29;
      $herc4Id = 29;
      $herc5Id = 29;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Prometheus");
   }
   else if($hercallId==29)
   {
      $hercallId = 138;
      $herc1Id = 138;
      $herc2Id = 138;
      $herc3Id = 138;
      $herc4Id = 138;
      $herc5Id = 138;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Pouncer Assault Bike");
   }   
   else if($hercallId==138)
   {
      $hercallId = 150;
      $herc1Id = 150;
      $herc2Id = 150;
      $herc3Id = 150;
      $herc4Id = 150;
      $herc5Id = 150;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Starsiege Magic Bus");
   }      
   else if($hercallId==150)
   {
      $hercallId = "Clone";
      $herc1Id = "Clone";
      $herc2Id = "Clone";
      $herc3Id = "Clone";
      $herc4Id = "Clone";
      $herc5Id = "Clone";
      say(0,8,"<f6>Total AI Selection - Clone of Player (Activator)");
   }         
   else
   {
      AIallcont2();
   }
}

function AIallcont2()
{
   if($hercallId=="Clone")
   {
      $hercallId = "CloneRandom";
      $herc1Id = "CloneRandom";
      $herc2Id = "CloneRandom";
      $herc3Id = "CloneRandom";
      $herc4Id = "CloneRandom";
      $herc5Id = "CloneRandom";
      say(0,8,"<f6>Total AI Selection - Clone of Random Player");
   }   
   else if($hercallId=="CloneRandom")
   {
      $hercallId = 23;
      $herc1Id = 23;
      $herc2Id = 23;
      $herc3Id = 23;
      $herc4Id = 23;
      $herc5Id = 23;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Adjudicator");
   }   
}

function reverseAIall()
{
   if($hercallId==38)
   {
      $hercallId = 27;
      $herc1Id = 27;
      $herc2Id = 27;
      $herc3Id = 27;
      $herc4Id = 27;
      $herc5Id = 27;         
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Platinum Guard Adjudicator");
   }
   else if($hercallId==1)
   {
      $hercallId = 38;
      $herc1Id = 38;
      $herc2Id = 38;
      $herc3Id = 38;
      $herc4Id = 38;
      $herc5Id = 38;         
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Adjudicator");
   }
   else if($hercallId==10)
   {
      $hercallId = 1;
      $herc1Id = 1;
      $herc2Id = 1;
      $herc3Id = 1;
      $herc4Id = 1;
      $herc5Id = 1;
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Apocalypse");
   }
   else if($hercallId==31)
   {
      $hercallId = 10;
      $herc1Id = 10;
      $herc2Id = 10;
      $herc3Id = 10;
      $herc4Id = 10;
      $herc5Id = 10;
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Knight's Apocalypse");
   }
   else if($hercallId==5)
   {
      $hercallId = 31;
      $herc1Id = 31;
      $herc2Id = 31;
      $herc3Id = 31;
      $herc4Id = 31;
      $herc5Id = 31;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Avenger");
   }
   else if($hercallId==14)
   {
      $hercallId = 5;
      $herc1Id = 5;
      $herc2Id = 5;
      $herc3Id = 5;
      $herc4Id = 5;
      $herc5Id = 5;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Basilisk");
   }
   else if($hercallId==25)
   {
      $hercallId = 14;
      $herc1Id = 14;
      $herc2Id = 14;
      $herc3Id = 14;
      $herc4Id = 14;
      $herc5Id = 14;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Knight's Basilisk");
   }
   else if($hercallId==8)
   {
      $hercallId = 25;
      $herc1Id = 25;
      $herc2Id = 25;
      $herc3Id = 25;
      $herc4Id = 25;
      $herc5Id = 25;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Bolo");
   }
   else if($hercallId==17)
   {
      $hercallId = 8;
      $herc1Id = 8;
      $herc2Id = 8;
      $herc3Id = 8;
      $herc4Id = 8;
      $herc5Id = 8;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Disrupter");
   }
   else if($hercallId==32)
   {
      $hercallId = 17;
      $herc1Id = 17;
      $herc2Id = 17;
      $herc3Id = 17;
      $herc4Id = 17;
      $herc5Id = 17;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Knight's Disrupter");
   }
   else if($hercallId==30)
   {
      $hercallId = 32;
      $herc1Id = 32;
      $herc2Id = 32;
      $herc3Id = 32;
      $herc4Id = 32;
      $herc5Id = 32;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Dreadlock");
   }
   else if($hercallId==24)
   {
      $hercallId = 30;
      $herc1Id = 30;
      $herc2Id = 30;
      $herc3Id = 30;
      $herc4Id = 30;
      $herc5Id = 30;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Emancipator");
   }
   else if($hercallId==28)
   {
      $hercallId = 24;
      $herc1Id = 24;
      $herc2Id = 24;
      $herc3Id = 24;
      $herc4Id = 24;
      $herc5Id = 24;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Executioner");
   }
   else if($hercallId==39)
   {
      $hercallId = 28;
      $herc1Id = 28;
      $herc2Id = 28;
      $herc3Id = 28;
      $herc4Id = 28;
      $herc5Id = 28;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Platinum Guard Executioner");
   }
   else if($hercallId==21)
   {
      $hercallId = 39;
      $herc1Id = 39;
      $herc2Id = 39;
      $herc3Id = 39;
      $herc4Id = 39;
      $herc5Id = 39;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Executioner");
   }
   else if($hercallId==36)
   {
      $hercallId = 21;
      $herc1Id = 21;
      $herc2Id = 21;
      $herc3Id = 21;
      $herc4Id = 21;
      $herc5Id = 21;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Goad");
   }
   else if($hercallId==3)
   {
      $hercallId = 36;
      $herc1Id = 36;
      $herc2Id = 36;
      $herc3Id = 36;
      $herc4Id = 36;
      $herc5Id = 36;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Goad");
   }
   else if($hercallId==12)
   {
      $hercallId = 3;
      $herc1Id = 3;
      $herc2Id = 3;
      $herc3Id = 3;
      $herc4Id = 3;
      $herc5Id = 3;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Gorgon");
   }
   else if($hercallId==2)
   {
      $hercallId = 12;
      $herc1Id = 12;
      $herc2Id = 12;
      $herc3Id = 12;
      $herc4Id = 12;
      $herc5Id = 12;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Knight's Gorgon");
   }
   else if($hercallId==11)
   {
      $hercallId = 2;
      $herc1Id = 2;
      $herc2Id = 2;
      $herc3Id = 2;
      $herc4Id = 2;
      $herc5Id = 2;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Minotaur");
   }
   else if($hercallId==7)
   {
      $hercallId = 11;
      $herc1Id = 11;
      $herc2Id = 11;
      $herc3Id = 11;
      $herc4Id = 11;
      $herc5Id = 11;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Knight's Minotaur");
   }   
   else
   {
      reverseAIallcont();
   }
}

function reverseAIallcont()
{
   if($hercallId==16)
   {
      $hercallId = 7;
      $herc1Id = 7;
      $herc2Id = 7;
      $herc3Id = 7;
      $herc4Id = 7;
      $herc5Id = 7;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Myrmidon");
   }
   else if($hercallId==133)
   {
      $hercallId = 16;
      $herc1Id = 16;
      $herc2Id = 16;
      $herc3Id = 16;
      $herc4Id = 16;
      $herc5Id = 16;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Knight's Myrmidon");
   }
   else if($hercallId==33)
   {
      $hercallId = 133;
      $herc1Id = 133;
      $herc2Id = 133;
      $herc3Id = 133;
      $herc4Id = 133;
      $herc5Id = 133;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Nike Siege Tank");
   }
   else if($hercallId==6)
   {
      $hercallId = 33;
      $herc1Id = 33;
      $herc2Id = 33;
      $herc3Id = 33;
      $herc4Id = 33;
      $herc5Id = 33;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Olympian");
   }
   else if($hercallId==15)
   {
      $hercallId = 6;
      $herc1Id = 6;
      $herc2Id = 6;
      $herc3Id = 6;
      $herc4Id = 6;
      $herc5Id = 6;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Paladin");
   }
   else if($hercallId==41)
   {
      $hercallId = 15;
      $herc1Id = 15;
      $herc2Id = 15;
      $herc3Id = 15;
      $herc4Id = 15;
      $herc5Id = 15;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Knight's Paladin");
   }
   else if($hercallId==26)
   {
      $hercallId = 41;
      $herc1Id = 41;
      $herc2Id = 41;
      $herc3Id = 41;
      $herc4Id = 41;
      $herc5Id = 41;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Harabec's Predator");
   }
   else if($hercallId==20)
   {
      $hercallId = 26;
      $herc1Id = 26;
      $herc2Id = 26;
      $herc3Id = 26;
      $herc4Id = 26;
      $herc5Id = 26;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Recluse");
   }
   else if($hercallId==35)
   {
      $hercallId = 20;
      $herc1Id = 20;
      $herc2Id = 20;
      $herc3Id = 20;
      $herc4Id = 20;
      $herc5Id = 20;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Seeker");
   }
   else if($hercallId==22)
   {
      $hercallId = 35;
      $herc1Id = 35;
      $herc2Id = 35;
      $herc3Id = 35;
      $herc4Id = 35;
      $herc5Id = 35;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Seeker");
   }
   else if($hercallId==37)
   {
      $hercallId = 22;
      $herc1Id = 22;
      $herc2Id = 22;
      $herc3Id = 22;
      $herc4Id = 22;
      $herc5Id = 22;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Shepherd");
   }
   else if($hercallId==4)
   {
      $hercallId = 37;
      $herc1Id = 37;
      $herc2Id = 37;
      $herc3Id = 37;
      $herc4Id = 37;
      $herc5Id = 37;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Metagen Shepherd");
   }   
   else if($hercallId==13)
   {
      $hercallId = 4;
      $herc1Id = 4;
      $herc2Id = 4;
      $herc3Id = 4;
      $herc4Id = 4;
      $herc5Id = 4;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Talon");
   }   
   else if($hercallId==40)
   {
      $hercallId = 13;
      $herc1Id = 13;
      $herc2Id = 13;
      $herc3Id = 13;
      $herc4Id = 13;
      $herc5Id = 13;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Knight's Talon");
   }   
   else if($hercallId==45)
   {
      $hercallId = 40;
      $herc1Id = 40;
      $herc2Id = 40;
      $herc3Id = 40;
      $herc4Id = 40;
      $herc5Id = 40;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Harabec's Apocalypse");
   }   
   else if($hercallId==42)
   {
      $hercallId = 45;
      $herc1Id = 45;
      $herc2Id = 45;
      $herc3Id = 45;
      $herc4Id = 45;
      $herc5Id = 45;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Bek Storm's Predator");
   }   
   else if($hercallId==29)
   {
      $hercallId = 42;
      $herc1Id = 42;
      $herc2Id = 42;
      $herc3Id = 42;
      $herc4Id = 42;
      $herc5Id = 42;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Caanon's Basilisk");
   }   
   else if($hercallId==138)
   {
      $hercallId = 29;
      $herc1Id = 29;
      $herc2Id = 29;
      $herc3Id = 29;
      $herc4Id = 29;
      $herc5Id = 29;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Prometheus");
   }
   else if($hercallId==150)
   {
      $hercallId = 138;
      $herc1Id = 138;
      $herc2Id = 138;
      $herc3Id = 138;
      $herc4Id = 138;
      $herc5Id = 138;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Pouncer Assault Bike");
   }   
   else if($hercallId=="Clone")
   {
      $hercallId = 150;
      $herc1Id = 150;
      $herc2Id = 150;
      $herc3Id = 150;
      $herc4Id = 150;
      $herc5Id = 150;    
      $herc1type = Tank;
      $herc2type = Tank;
      $herc3type = Tank;
      $herc4type = Tank;
      $herc5type = Tank;
      say(0,8,"<f6>Total AI Selection - Starsiege Magic Bus");
   }      
   else if($hercallId=="CloneRandom")
   {
      $hercallId = "Clone";
      $herc1Id = "Clone";
      $herc2Id = "Clone";
      $herc3Id = "Clone";
      $herc4Id = "Clone";
      $herc5Id = "Clone";
      say(0,8,"<f6>Total AI Selection - Clone of Player (Activator)");
   }         
   else
   {
      reverseAIallcont2();
   }
}

function reverseAIallcont2()
{
   if($hercallId==23)
   {
      $hercallId = "CloneRandom";
      $herc1Id = "CloneRandom";
      $herc2Id = "CloneRandom";
      $herc3Id = "CloneRandom";
      $herc4Id = "CloneRandom";
      $herc5Id = "CloneRandom";
      say(0,8,"<f6>Total AI Selection - Clone of Random Player");
   }   
   else if($hercallId==27)
   {
      $hercallId = 23;
      $herc1Id = 23;
      $herc2Id = 23;
      $herc3Id = 23;
      $herc4Id = 23;
      $herc5Id = 23;    
      $herc1type = Herc;
      $herc2type = Herc;
      $herc3type = Herc;
      $herc4type = Herc;
      $herc5type = Herc;
      say(0,8,"<f6>Total AI Selection - Adjudicator");
   }   
}

function ZenAll::trigger::onEnter(%this, %object)
{
   // tell user pad has been entered
   if($pads==true)
   {
      Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
   }
   else if($pads==false)
   {
      Zen::onEnter(%this, %object, "", true, true);  
   }   
}

function ZenAll::trigger::onContact(%this, %object)
{
   if($pads==true)
   {
      // one hundred points of loading
      // five percent reloading
      Zen::work(%this, %object, 100, 5, 0, true); 
   }
}

function ZenAll::trigger::onLeave(%this, %object)
{
   Zen::onLeave(%this, %object);    
}

function onMissionEnd()
{
   flushConsoleScheduler();
   deleteObject($herc1);
   deleteObject($herc2);
   deleteObject($herc3);
   deleteObject($herc4);
   deleteObject($herc5);
}