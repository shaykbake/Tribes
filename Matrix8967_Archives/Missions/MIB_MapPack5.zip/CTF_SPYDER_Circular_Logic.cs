// FILENAME:	CTF_SPYDER_Circular_Logic.cs
//
// AUTHORS:  	Com. Sentinal [M.I.B.]
//
//------------------------------------------------------------------------------
// Stealth Detection - Set to true & players with a "/" in front of their
// will be detected when they join or leave the server.

$stealthDetect = true;    //Set to false to turn off stealth detection

//------------------------------------------------------------------------------
$missionName = "CTF_SPYDER_Circular_Logic";

// CTF stuff
$maxFlagCount  = 8;           // no of flags required by a team to end the game
$flagValue     = 5;          // points your team gets for capturing
$carrierValue  = 2;          //  "      "    "    "    " killing carrier
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 420;             // 7 minute timer (due to minefield hazards)

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
   titanSounds();
   $explosivesSupply1 = "ready";
   $explosivesSupply2 = "ready";
   $explosivesSupply3 = "ready";
   $explosivesSupply4 = "ready";
   $explosivesSupply5 = "ready";
   $mines = "MissionGroup/mines";

   //CTF Stuff   
   initGlobalVars();
   $lastVehicleOnZen = "";
   $lastVehicleOnRedZen = "";
   $lastVehicleOnBlueZen = "";
   $secondsToGain = 0;
   $secondsToGainRedZen = 0;
   $secondsToGainBlueZen = 0;
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "CloudBurst", "Terror"); 
   setGameInfo("<F2>GAME TYPE:<F0>  Spyder Mine CTF\n\n<F2>MISSION:<F0>  CTF_SPYDER_Circular_Logic\n\nWelcome to Spyder Mine CTF! Your vehicle is equipped with a Spyder Mine when you spawn. Set a nav marker, then shut down to deploy the Spyder Mine. The Spyder Mine drone will then proceed to your nav marker and deploy a proximity mine field there. You can toggle your mine field's density by scanning a structure or another vehicle. To re-equip your vehicle with a Spyder Mine, merely walk into an Spyder Mine Supply Depot. You can download CTF_SPYDER_Circular_Logic & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   //reset the boomkills
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %player.boomkill = 0;
      %player.armed = false;
      %player.spyderlock = false;
      %player.deathdelay = false;
   }
}

function player::onAdd(%player)
{
   %player.boomkill = 0;
   %player.armed = false;
   %player.spyderlock = false;
   %player.deathdelay = false;
   %player.leftgame = false;
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
        say(0,0,"<f4>"@getname(%player)@" joined the game","alarm2.wav");
        messagebox(%player,"This server is equipped with an anti-stealth detection system. The slash on your name has been detected. All players have been alerted to your presence.");
   }
   say(%player, 0, "Welcome to Spyder Mine CTF! Check the game info tab for the rules. You can download CTF_SPYDER_Circular_Logic & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   deleteItAll(%player);
}

function player::onRemove(%player)
{
   if(($stealthDetect == true)&&(strAlign(1, left, getname(%player))=="/"))
   {
      say(0,0,"<f4>"@getname(%player)@" left the game","alarm2.wav");
   }
   %player.leftgame = true;
   %player.deleted = true;
   %player.armed = false;
   deleteobject(%player.spyder);
   %player.spyder = "";
   deleteobject(%player.explosion);
   %player.explosion = "";
   deleteobject(%player.mine1);
   %player.mine1 = "";
   deleteobject(%player.mine2);
   %player.mine2 = "";
   deleteobject(%player.mine3);
   %player.mine3 = "";
   deleteobject(%player.mine4);
   %player.mine4 = "";
   deleteobject(%player.mine5);
   %player.mine5 = "";
   deleteobject(%player.mine6);
   %player.mine6 = "";
   deleteobject(%player.mine7);
   %player.mine7 = "";
   deleteobject(%player.mine8);
   %player.mine8 = "";
   deleteobject(%player.mine9);
   %player.mine9 = "";
   deleteobject(%player.mine10);
   %player.mine10 = "";
   deleteobject(%player.minetrigger11);
   %player.minetrigger11 = "";
   deleteobject(%player.minetrigger21);
   %player.minetrigger21 = "";
   deleteobject(%player.minetrigger31);
   %player.minetrigger31 = "";
   deleteobject(%player.minetrigger41);
   %player.minetrigger41 = "";
   deleteobject(%player.minetrigger12);
   %player.minetrigger12 = "";
   deleteobject(%player.minetrigger22);
   %player.minetrigger22 = "";
   deleteobject(%player.minetrigger32);
   %player.minetrigger32 = "";
   deleteobject(%player.minetrigger42);
   %player.minetrigger42 = "";
   deleteobject(%player.minetrigger13);
   %player.minetrigger13 = "";
   deleteobject(%player.minetrigger23);
   %player.minetrigger23 = "";
   deleteobject(%player.minetrigger33);
   %player.minetrigger33 = "";
   deleteobject(%player.minetrigger43);
   %player.minetrigger43 = "";
   deleteobject(%player.minetrigger14);
   %player.minetrigger14 = "";
   deleteobject(%player.minetrigger24);
   %player.minetrigger24 = "";
   deleteobject(%player.minetrigger34);
   %player.minetrigger34 = "";
   deleteobject(%player.minetrigger44);
   %player.minetrigger44 = "";
   deleteobject(%player.minetrigger15);
   %player.minetrigger15 = "";
   deleteobject(%player.minetrigger25);
   %player.minetrigger25 = "";
   deleteobject(%player.minetrigger35);
   %player.minetrigger35 = "";
   deleteobject(%player.minetrigger45);
   %player.minetrigger45 = "";
   deleteobject(%player.minetrigger16);
   %player.minetrigger16 = "";
   deleteobject(%player.minetrigger26);
   %player.minetrigger26 = "";
   deleteobject(%player.minetrigger36);
   %player.minetrigger36 = "";
   deleteobject(%player.minetrigger46);
   %player.minetrigger46 = "";
   deleteobject(%player.minetrigger17);
   %player.minetrigger17 = "";
   deleteobject(%player.minetrigger27);
   %player.minetrigger27 = "";
   deleteobject(%player.minetrigger37);
   %player.minetrigger37 = "";
   deleteobject(%player.minetrigger47);
   %player.minetrigger47 = "";
   deleteobject(%player.minetrigger18);
   %player.minetrigger18 = "";
   deleteobject(%player.minetrigger28);
   %player.minetrigger28 = "";
   deleteobject(%player.minetrigger38);
   %player.minetrigger38 = "";
   deleteobject(%player.minetrigger48);
   %player.minetrigger48 = "";
   deleteobject(%player.minetrigger19);
   %player.minetrigger19 = "";
   deleteobject(%player.minetrigger29);
   %player.minetrigger29 = "";
   deleteobject(%player.minetrigger39);
   %player.minetrigger39 = "";
   deleteobject(%player.minetrigger49);
   %player.minetrigger49 = "";
   deleteobject(%player.minetrigger110);
   %player.minetrigger110 = "";
   deleteobject(%player.minetrigger210);
   %player.minetrigger210 = "";
   deleteobject(%player.minetrigger310);
   %player.minetrigger310 = "";
   deleteobject(%player.minetrigger410);
   %player.minetrigger410 = "";
}


function vehicle::onadd(%vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   %player.hasBomb = true;
   %player.InPad = false;
   %player.spawndelay = true;
   %player.minefield = "normal";
   %player.destroyer = "Nobody";
   %player.hitamine = false;
   schedule("spawndelay(" @ %player @ ");", 5);

   // CTF stuff
   %team = getTeam(playerManager::vehicleIdToPlayerNum(%vehicleId));
   %color = teamToColor(%team);
   %flagKey = strcat(%color, "FlagCount");
	
   adjTeamCount(%team, 1);
	
   //if the flag isn't at the base, but no one has it, correct situation
   if(dataRetrieve(0, %flagKey) && !dataRetrieve(0, strcat(%color, "FlagCarried")))
   {
   	setFlag(%team, true);
   }
}   

function spawndelay(%player)
{
   %player.spawndelay = false;
}

function trigger::onEnter(%trigger, %vehicleId)
{
   %player1 = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   if(getObjectName(%trigger) == "mine")
   {
      %player2 = %trigger.owner;
      if(%player2.armed == true)
      {
         %player1.hitamine = true;
         explodeMine(%player1, %player2, %trigger);
      }
   }
}

function explodeMine(%player1, %player2, %trigger)
{
   %player1.destroyer = %player2;
   %x = getPosition(%trigger.mine, x);
   %y = getPosition(%trigger.mine, y);
   %z = getTerrainHeight(%x, %y);
   setposition(%player2.explosion, %x, %y, (%z - 1));
   setShapeVisibility(%player2.explosion, true);
   playAnimSequence(%player2.explosion, 0, true);
   playSound(0, "sfx_fog.wav", IDPRF_2D); 
   damageArea(%trigger, 0, 0, 0, 150, 2500);
   schedule("setShapeVisibility(" @ %player2.explosion @ ", false);", 1.067);
   schedule("playAnimSequence(" @ %player2.explosion @ ", 0, false);", 1.1);
   schedule("deleteMine(" @ %player2 @ ", " @ %trigger @ ");", 1.067);
   schedule("victimSurvived(" @ %player1 @ ");", 2);
}

function deleteMine(%player, %trigger)
{
   for(%num = 1; %num < 11; %num++)
   {
      if(%trigger.mine == %player.mine[%num])
      {
         deleteObject(%player.mine[%num]);
         %player.mine[%num] = "";
         deleteObject(%player.minetrigger1[%num]);
         %player.minetrigger1[%num] = "";
         deleteObject(%player.minetrigger2[%num]);
         %player.minetrigger2[%num] = "";
         deleteObject(%player.minetrigger3[%num]);
         %player.minetrigger3[%num] = "";
         deleteObject(%player.minetrigger4[%num]);
         %player.minetrigger4[%num] = "";
      }
   }
}

function victimSurvived(%player)
{
   %player.destroyer = "Nobody";
   %player.hitamine = false;
}

function vehicle::ondestroyed(%destroyed, %destroyer)
{
   %player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   %player2 = playermanager::vehicleIdtoPlayerNum(%destroyed);
   
   %player2.deathdelay = true;
   schedule("deathdelay(" @ %player2 @ ");", 5);
   if(%player2.hitamine == true)
   {
      if(%player2.destroyer != %player2)
      {
         say("Everybody", 3, getHudName(%destroyed) @ " was destroyed by one of " @ getName(%player2.destroyer) @ "'s mines!");
         if($server::TeamPlay == false)
         {
            %killer = %player2.destroyer;
            %killer.boomkill = %killer.boomkill + 3;
         }
         else if(($server::TeamPlay == true)&&(getTeam(%player2.destroyer) != getTeam(%player2)))
         {
            %killer = %player2.destroyer;
            %killer.boomkill = %killer.boomkill + 3;
         }
      }
      else
      {
         say("Everybody", 4, getHudName(%destroyed) @ " accidently stepped on one of his own mines!");
      }
   }
   else if((%player == 0)&&(%player2.hitamine == false))
   {
      say("Everybody", 0, getHudName(%destroyed) @ " got blown up!");
   }
   else
   {
      vehicle::onDestroyedLog(%destroyed, %destroyer);
   
      // this is weird but %destroyer isn't necessarily a vehicle
      %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
      if(%message != "")
      {
         say( 0, 0, %message);
      }
      
      // enforce the rules
      if($server::TeamPlay == true)
      {
         if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
         {
            antiTeamKill(%destroyer);
         }
      }   
   }

   // CTF stuff
   %team = getTeam(%destroyed);
   adjTeamCount(%team, -1);
   %teamCount = getTeamPlayerCount(%team);      

   if(%teamCount < 1)
   {
	   setFlag(%team, false);					
   }

   %color = dataRetrieve(%destroyed, "hasFlag");
   %flagTeam = colorToTeam(%color);
   
   // if the destroyed vehicle has a flag, it goes back to it's base
   if (%color != "")
   {
      playerDropsFlag(%destroyed);
      
      // let everyone know this guy drops the flag
      %str =
         *IDMULT_CHAT_SURRENDER_FLAG_1 @
         getName( %destroyed )         @
         *IDMULT_CHAT_SURRENDER_FLAG_2 @ 
         %flagTeam                     @
         *IDMULT_CHAT_SURRENDER_FLAG_3;
      
      %soundFile = "";   
      if(%flagTeam == *IDSTR_TEAM_RED)
      {
         %soundFile = "red_flag_sur.wav";
      }
      else if(%flagTeam == *IDSTR_TEAM_BLUE)
      {
         %soundFile = "blue_flag_sur.wav";
      }
      else if(%flagTeam == *IDSTR_TEAM_YELLOW)
      {
         %soundFile = "yel_flag_sur.wav";
      }
      else
      {
         %soundFile = "purp_flag_sur.wav";
      }   
      
      say( 0, 0, %str, %soundFile );

            
      if($scoringFreeze == false)
      {     
         // destroyer's team gets credit for killing the carrier
         %destroyerTeam = getTeam(%destroyer);  
      
         // only give points if destroyed recovered his/her own flag
         if(%destroyerTeam == colorToTeam(%color))
         {
            %key = strcat(teamToColor(getTeam(%destroyer)), "CarriersKilled");
            dataStore(0, %key, 1 + dataRetrieve(0, %key));
            
            // player gets credit, too
            %player = playerManager::vehicleIdToPlayerNum(%destroyer);
            if(%player != 0)
            {
               %player.carriersKilled = %player.carriersKilled + 1;
            }
         }

         // echo the surrender to the console for logging
         echo(*IDSTR_CONSOLE_CTF_SURRENDER @ " " @ playerManager::vehicleIdToPlayerNum(%destroyed));                        
      }	  
   }
   else
   {
      // not a flag carrier ... is it an enemy?
      if($scoringFreeze == false)
      {
         if(getTeam(%destroyed) != getTeam(%destroyer))
         {
            %player = playerManager::vehicleIdToPlayerNum(%destroyer);
            if(%player != 0)
            {
               %player.genericKills = %player.genericKills + 1;
            }
         }
      }
   }
}

function deathdelay(%player2)
{
   %player2.deathdelay = false;
}

function vehicle::onscan(%scanned, %scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%player.minefield == "normal")
   {
      %player.minefield = "dense";
      say(%player, %player, "<f1>Mine field density: Dense");
   }
   else if(%player.minefield == "dense")
   {
      %player.minefield = "extremelydense";
      say(%player, %player, "<f1>Mine field density: Extremely Dense");
   }
   else if(%player.minefield == "extremelydense")
   {
      %player.minefield = "extremelysparse";
      say(%player, %player, "<f1>Mine field density: Extremely Sparse");
   }
   else if(%player.minefield == "extremelysparse")
   {
      %player.minefield = "sparse";
      say(%player, %player, "<f1>Mine field density: Sparse");
   }
   else if(%player.minefield == "sparse")
   {
      %player.minefield = "normal";
      say(%player, %player, "<f1>Mine field density: Normal");
   }
}

function structure::onscan(%scanned, %scanner)
{
   %player = playermanager::vehicleIdtoPlayerNum(%scanner);
   if(%player.minefield == "normal")
   {
      %player.minefield = "dense";
      say(%player, %player, "<f1>Mine field density: Dense");
   }
   else if(%player.minefield == "dense")
   {
      %player.minefield = "extremelydense";
      say(%player, %player, "<f1>Mine field density: Extremely Dense");
   }
   else if(%player.minefield == "extremelydense")
   {
      %player.minefield = "extremelysparse";
      say(%player, %player, "<f1>Mine field density: Extremely Sparse");
   }
   else if(%player.minefield == "extremelysparse")
   {
      %player.minefield = "sparse";
      say(%player, %player, "<f1>Mine field density: Sparse");
   }
   else if(%player.minefield == "sparse")
   {
      %player.minefield = "normal";
      say(%player, %player, "<f1>Mine field density: Normal");
   }
}

function explosives::trigger::onContact(%trigger, %vehicleId)
{
   %player = playermanager::vehicleIdtoPlayerNum(%vehicleId);
   if(isshutdown(%vehicleId) == false)
   {
      %player.justlaid = false;
   }
   if((%player.InPad == false)&&(isshutdown(%vehicleId) == true)&&(%player.hasbomb == true)&&(%player.justlaid == false)&&(%player.deathdelay == false))
   {  
      %player.justlaid = true;
      deploySpyder(%vehicleId);
   }  
   else if((%player.InPad == false)&&(isshutdown(%vehicleId) == true)&&(%player.hasbomb == false)&&(%player.justlaid == false)&&(%player.deathdelay == false))
   {  
      %player.justlaid = true;
      say(%player, %player, "<f1>Your vehicle is not equipped with a Spyder Mine.");
   }
}

function deploySpyder(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player.spyderlock == false)
   {
      say(%player, %player, "<f5>Spyder Mine deployed.", "C5_pbbbbbt.WAV");
      %player.spyderlock = true;
      %player.armed = false;
      deleteItAll(%player);
      %player.spyder = newObject("spyder", StaticShape, "pr_ara.DTS");
      %x = getPosition(%vehicleId, x);
      %y = getPosition(%vehicleId, y);
      %z = getTerrainHeight(%x, %y);
      setPosition(%player.spyder, %x, %y, %z);
      %player.deleted = false;
      addToSet($mines, %player.spyder);
      playAnimSequence(%player.spyder, 0, false);
      schedule("playAnimSequence(" @ %player.spyder @ ", 0, true);", 0.5);
      %player.hasbomb = false;
      %x1 = getPosition(%vehicleId, x);
      %y1 = getPosition(%vehicleId, y);
      %nav = getVehicleNavMarkerId(%vehicleId);
      %x2 = getPosition(%nav, x);
      %y2 = getPosition(%nav, y);
      %distance = getDistance(%vehicleId, %nav);
      if(%distance == 0)
      {
         %increments = 1;
         %xOffset = 7.07;
         %yOffset = 7.07;
      }
      else
      {
         %increments = %distance / 10;
         %xDist = %x2 - %x1;
         %yDist = %y2 - %y1;
         %xOffset = %xDist / %increments;
         %yOffset = %yDist / %increments;
      }
      schedule("repulse(" @ %player @ ", " @ %player.spyder @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %increments @ ");", 1);
   }
   else
   {
      say(%player, %player, "<f1>You must wait until your current mine field is armed before you can deploy another Spyder Mine.");
   }
}

function repulse(%player, %spyder, %xOffset, %yOffset, %increments)
{
   if((%increments > 1)&&(%player.deleted == false))
   {
      %increments--;
      %x = getPosition(%spyder, x) + %xOffset;
      %y = getPosition(%spyder, y) + %yOffset;
      %z = getTerrainHeight(%x, %y);
      setPosition(%spyder, %x, %y, %z);
      schedule("repulse(" @ %player @ ", " @ %spyder @ ", " @ %xOffset @ ", " @ %yOffset @ ", " @ %increments @ ");", 0.1);
   }
   else
   {
      if(%player.deleted == false)
      {
         %player.explosion = newobject("Explosion", StaticShape, "fx_exp_podT.DTS");
         addToSet($mines, %player.explosion);
         setShapeVisibility(%player.explosion, false);
         playAnimSequence(%player.explosion, 0, false);
         %x = getPosition(%spyder, x);
         %y = getPosition(%spyder, y);
         %z = getTerrainHeight(%x, %y);
         setPosition(%player.explosion, %x, %y, %z);
         layMines(%player, %spyder, %player.minefield, 1);
      }
   }
}

function layMines(%player, %spyder, %configuration, %num)
{
   if(%player.leftgame == false)
   {
      if(%num <= 10)
      {
         %player.mine[%num] = newobject("prox", StaticShape, "pr_prx.DTS");
         addToSet($mines, %player.mine[%num]);
         %x1 = getposition(%spyder, x);
         %y1 = getposition(%spyder, y);
         //Modified density settings for CTF only
         if(%configuration == "extremelysparse")
         {
            %low = -200;
            %high = 200;
         } 
         else if(%configuration == "sparse")
         {
            %low = -150;
            %high = 150;
         } 
         else if(%configuration == "normal")
         {
            %low = -100;
            %high = 100;
         } 
         else if(%configuration == "dense")
         {
            %low = -75;
            %high = 75;
         }
         else if(%configuration == "extremelydense")
         {
            %low = -50;
            %high = 50;
         }
         %x = randomInt((%x1 + %low), (%x1 + %high));
         %y = randomInt((%y1 + %low), (%y1 + %high));
         %z = getTerrainHeight(%x, %y);
         setPosition(%player.mine[%num], %x, %y, (%z + 0.5));
         %player.minetrigger1[%num] = newObject("mine", SimTrigger);
         %trigger1 = %player.minetrigger1[%num];
         %trigger1.owner = %player;
         %trigger1.mine = %player.mine[%num];
         %player.minetrigger2[%num] = newObject("mine", SimTrigger);
         %trigger2 = %player.minetrigger2[%num];
         %trigger2.owner = %player;
         %trigger2.mine = %player.mine[%num];
         %player.minetrigger3[%num] = newObject("mine", SimTrigger);
         %trigger3 = %player.minetrigger3[%num];
         %trigger3.owner = %player;
         %trigger3.mine = %player.mine[%num];
         %player.minetrigger4[%num] = newObject("mine", SimTrigger);
         %trigger4 = %player.minetrigger4[%num];
         %trigger4.owner = %player;
         %trigger4.mine = %player.mine[%num];
         addToSet($mines, %player.minetrigger1[%num]);
         addToSet($mines, %player.minetrigger2[%num]);
         addToSet($mines, %player.minetrigger3[%num]);
         addToSet($mines, %player.minetrigger4[%num]);
         setPosition(%player.minetrigger1[%num], (%x - 1), (%y - 1), (%z + 1));
         setPosition(%player.minetrigger2[%num], (%x - 1), (%y + 1), (%z + 1));
         setPosition(%player.minetrigger3[%num], (%x + 1), (%y - 1), (%z + 1));
         setPosition(%player.minetrigger4[%num], (%x + 1), (%y + 1), (%z + 1));
         %num++;
         schedule("layMines(" @ %player @ ", " @ %spyder @ ", " @ %configuration @ ", " @ %num @ ");", 1);
      }
      else
      {
         deleteObject(%player.spyder);
         %player.spyder = "";
         %player.armed = true;
         %player.spyderlock = false;
         say(%player, %player, "<F5>Mine field armed.", "C2_tattadit.WAV");
      }
   }
   else if(%player.leftgame == true)
   {
      deleteItAll(%player);
   }
}

function deleteItAll(%player)
{
   %player.deleted = true;
   %player.armed = false;
   deleteobject(%player.spyder);
   %player.spyder = "";
   deleteobject(%player.explosion);
   %player.explosion = "";
   deleteobject(%player.mine1);
   %player.mine1 = "";
   deleteobject(%player.mine2);
   %player.mine2 = "";
   deleteobject(%player.mine3);
   %player.mine3 = "";
   deleteobject(%player.mine4);
   %player.mine4 = "";
   deleteobject(%player.mine5);
   %player.mine5 = "";
   deleteobject(%player.mine6);
   %player.mine6 = "";
   deleteobject(%player.mine7);
   %player.mine7 = "";
   deleteobject(%player.mine8);
   %player.mine8 = "";
   deleteobject(%player.mine9);
   %player.mine9 = "";
   deleteobject(%player.mine10);
   %player.mine10 = "";
   deleteobject(%player.minetrigger11);
   %player.minetrigger11 = "";
   deleteobject(%player.minetrigger21);
   %player.minetrigger21 = "";
   deleteobject(%player.minetrigger31);
   %player.minetrigger31 = "";
   deleteobject(%player.minetrigger41);
   %player.minetrigger41 = "";
   deleteobject(%player.minetrigger12);
   %player.minetrigger12 = "";
   deleteobject(%player.minetrigger22);
   %player.minetrigger22 = "";
   deleteobject(%player.minetrigger32);
   %player.minetrigger32 = "";
   deleteobject(%player.minetrigger42);
   %player.minetrigger42 = "";
   deleteobject(%player.minetrigger13);
   %player.minetrigger13 = "";
   deleteobject(%player.minetrigger23);
   %player.minetrigger23 = "";
   deleteobject(%player.minetrigger33);
   %player.minetrigger33 = "";
   deleteobject(%player.minetrigger43);
   %player.minetrigger43 = "";
   deleteobject(%player.minetrigger14);
   %player.minetrigger14 = "";
   deleteobject(%player.minetrigger24);
   %player.minetrigger24 = "";
   deleteobject(%player.minetrigger34);
   %player.minetrigger34 = "";
   deleteobject(%player.minetrigger44);
   %player.minetrigger44 = "";
   deleteobject(%player.minetrigger15);
   %player.minetrigger15 = "";
   deleteobject(%player.minetrigger25);
   %player.minetrigger25 = "";
   deleteobject(%player.minetrigger35);
   %player.minetrigger35 = "";
   deleteobject(%player.minetrigger45);
   %player.minetrigger45 = "";
   deleteobject(%player.minetrigger16);
   %player.minetrigger16 = "";
   deleteobject(%player.minetrigger26);
   %player.minetrigger26 = "";
   deleteobject(%player.minetrigger36);
   %player.minetrigger36 = "";
   deleteobject(%player.minetrigger46);
   %player.minetrigger46 = "";
   deleteobject(%player.minetrigger17);
   %player.minetrigger17 = "";
   deleteobject(%player.minetrigger27);
   %player.minetrigger27 = "";
   deleteobject(%player.minetrigger37);
   %player.minetrigger37 = "";
   deleteobject(%player.minetrigger47);
   %player.minetrigger47 = "";
   deleteobject(%player.minetrigger18);
   %player.minetrigger18 = "";
   deleteobject(%player.minetrigger28);
   %player.minetrigger28 = "";
   deleteobject(%player.minetrigger38);
   %player.minetrigger38 = "";
   deleteobject(%player.minetrigger48);
   %player.minetrigger48 = "";
   deleteobject(%player.minetrigger19);
   %player.minetrigger19 = "";
   deleteobject(%player.minetrigger29);
   %player.minetrigger29 = "";
   deleteobject(%player.minetrigger39);
   %player.minetrigger39 = "";
   deleteobject(%player.minetrigger49);
   %player.minetrigger49 = "";
   deleteobject(%player.minetrigger110);
   %player.minetrigger110 = "";
   deleteobject(%player.minetrigger210);
   %player.minetrigger210 = "";
   deleteobject(%player.minetrigger310);
   %player.minetrigger310 = "";
   deleteobject(%player.minetrigger410);
   %player.minetrigger410 = "";
}

function onMissionEnd()
{
   deleteobject($mines);
}

function getPlayerScore(%player)
{
   return((getKills(%player) * $killPoints) - (getDeaths(%player) * $deathPoints)) + %player.boomkill;
}

function explosivesSupply1::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply1=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply1 = "not ready";
      schedule("$explosivesSupply1 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 001 is ready.\");",30);
   }
   else if(($explosivesSupply1=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply1!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 001 is not ready.");
   }
}

function explosivesSupply2::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply2=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply2 = "not ready";
      schedule("$explosivesSupply2 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Depot 002 is ready.\");",30);
   }
   else if(($explosivesSupply2=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply2!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 002 is not ready.");
   }
}

function explosivesSupply3::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply3=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply3 = "not ready";
      schedule("$explosivesSupply3 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 003 is ready.\");",30);
   }
   else if(($explosivesSupply3=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply3!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 003 is not ready.");
   }
}

function explosivesSupply4::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply4=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply4 = "not ready";
      schedule("$explosivesSupply4 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 004 is ready.\");",30);
   }
   else if(($explosivesSupply4=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply4!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 004 is not ready.");
   }
}

function explosivesSupply5::trigger::onenter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(($explosivesSupply5=="ready")&&(%player.hasbomb==false))
   {
      %player.hasbomb = true;
      say(%player,%player,"<f1>Your vehicle has been equipped with a Spyder Mine.");
      $explosivesSupply5 = "not ready";
      schedule("$explosivesSupply5 = \"ready\";",30);
      schedule("say(0,0,\"<f1>Spyder Mine Supply Depot 005 is ready.\");",30);
   }
   else if(($explosivesSupply5=="ready")&&(%player.hasbomb==true))
   {
      say(%player,%player,"<f1>Your vehicle is already equipped with a Spyder Mine!");
   }
   else if($explosivesSupply5!="ready")
   {
      say(%player,%player,"<f1>Spyder Mine Supply Depot 005 is not ready.");
   }
}

//  BombZen Pad Functionality
function BombZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);
      %player.InPad = true; 
}

function BombZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 40, 70, true); 
}

function BombZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombHeal Pad Functionality
function BombHeal::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);
      %player.InPad = true; 
}

function BombHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 1000, 0, 0, true); 
}

function BombHeal::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}

//  BombAmmo Pad Functionality
function BombAmmo::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);
      %player.InPad = true; 
}

function BombAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, 40, 40, true); 
}

function BombAmmo::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}


function explosives::trigger::onEnter(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.spawndelay==false)
   {
      say(%player,%player,"<f1>Re-entering mission area. Spyder Mine back online.");
   }
}

function explosives::trigger::onLeave(%this,%object)
{
   %player = playermanager::vehicleIdtoPlayerNum(%object);
   if(%player.deathdelay==false)
   {
      say(%player,%player,"<f1>Leaving mission area. Spyder Mine disabled.");
   }
}

// CTF Circular Logic stuff (slightly altered)
//--------------------------------------------------------------------------
// ZenAll Pad Functionality
//------------------------------------------------------------------------------
function ZenAll::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
      %player.InPad = true; 
}
function ZenAll::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $yellowZenHealRate, $yellowZenAmmoRate, $zenWaitTime, true);
	if(isShutDown(%object)){
		if(%object != $lastVehicleOnZen){
			$lastVehicleOnZen = %object;
			$secondsToGain = 1;
		}
		else{
			$secondsToGain = $secondsToGain + 1;
		}
		if($secondsToGain >= 4)
			giveTurretsToThisGuy(%object);
	}
}

function ZenAll::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}
// ZenAll Pad Functionality
//------------------------------------------------------------------------------
function RedZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true); 
      %player.InPad = true;  
}

function RedZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $redZenHealRate, $redZenAmmoRate, $zenWaitTime, true);
	if(isShutDown(%object)){
		if(%object != $lastVehicleOnRedZen){
			$lastVehicleOnRedZen = %object;
			$secondsToGainRedZen = 1;
		}
		else{
			$secondsToGainRedZen = $secondsToGainRedZen + 1;
		}
		if($secondsToGainRedZen >= 4)
			giveRedTurretsToThisGuy(%object);
	}
}

function RedZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}
// ZenAll Pad Functionality
//------------------------------------------------------------------------------
function BlueZen::trigger::onEnter(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_ALLPAD, true, true);  
      %player.InPad = true; 
}

function BlueZen::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $blueZenHealRate, $blueZenAmmoRate, $zenWaitTime, true);
	if(isShutDown(%object)){
		if(%object != $lastVehicleOnBlueZen){
			$lastVehicleOnBlueZen = %object;
			$secondsToGainBlueZen = 1;
		}
		else{
			$secondsToGainBlueZen = $secondsToGainBlueZen + 1;
		}
		if($secondsToGainBlueZen >= 4)
			giveBlueTurretsToThisGuy(%object);
	}
}

function BlueZen::trigger::onLeave(%this, %object)
{
      %player = playermanager::vehicleIdtoPlayerNum(%object);
      %player.InPad = false; 
}
// Turret Code
// -----------------------------------------------------------------------------------

function giveTurretsToThisGuy(%vehicleId)
{
	%team = getTeam(%vehicleId);
	setTeam("MissionGroup\\CenterStructures\\T1", %team);
	setTeam("MissionGroup\\CenterStructures\\T2", %team);
	setTeam("MissionGroup\\CenterStructures\\T3", %team);
	setTeam("MissionGroup\\CenterStructures\\T4", %team);
	setTeam("MissionGroup\\CenterStructures\\NavZen", %team);
	order("MissionGroup\\CenterStructures", Shutdown, false);	
}

function giveRedTurretsToThisGuy(%vehicleId)
{
	%team = getTeam(%vehicleId);
	setTeam("MissionGroup\\CenterStructures\\T5", %team);
	setTeam("MissionGroup\\CenterStructures\\T6", %team);
	setTeam("MissionGroup\\CenterStructures\\NavZenRed", %team);
	order("MissionGroup\\CenterStructures", Shutdown, false);	
}

function giveBlueTurretsToThisGuy(%vehicleId)
{
	%team = getTeam(%vehicleId);
	setTeam("MissionGroup\\CenterStructures\\T7", %team);
	setTeam("MissionGroup\\CenterStructures\\T8", %team);
	setTeam("MissionGroup\\CenterStructures\\NavZenBlue", %team);
	order("MissionGroup\\CenterStructures", Shutdown, false);	
}
