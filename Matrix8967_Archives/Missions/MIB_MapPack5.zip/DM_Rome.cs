// FILENAME:	DM_Rome.cs
//
// AUTHORS:  	Gen. Deathrow [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Rome";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = false;
}

function onMissionStart()
{
	marsSounds();
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to SS Rome's Death Arena! You can download this & other missions made by Gen. Deathrow [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function door1::trigger::onEnter(%this, %vehicleId){
	if($hercsAtDoor1 == 0){
		playAnimSequence(getObjectId("MissionGroup\\Stuff\\Door1"), 0, true);
	}
	$hercsAtDoor1 = $hercsAtDoor1 + 1;
}
function door1::trigger::onLeave(%this, %vehicleId){
	$hercsAtDoor1 = $hercsAtDoor1 - 1;
	if($hercsAtDoor1 == 0){
		playAnimSequence(getObjectId("MissionGroup\\Stuff\\Door1"), 0, false);
	}
}
function door2::trigger::onEnter(%this, %vehicleId){
	if($hercsAtDoor2 == 0){
		playAnimSequence(getObjectId("MissionGroup\\Stuff\\Door2"), 0, true);
	}
	$hercsAtDoor2 = $hercsAtDoor2 + 1;
}
function door2::trigger::onLeave(%this, %vehicleId){
	$hercsAtDoor2 = $hercsAtDoor2 - 1;
	if($hercsAtDoor2 == 0){
		playAnimSequence(getObjectId("MissionGroup\\Stuff\\Door2"), 0, false);
	}
}


