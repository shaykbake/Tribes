// FILENAME:    DM_The_Crowd.cs
//
// AUTHOR:      Maj. Stormtrooper [M.I.B.]
//----------------------------------------------------------------------------------------------

$missionName = "DM_The_Crowd";

exec("multiplayerStdLib.cs");
exec("dmStdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = False;
	$server::AllowDeathmatch = True;
	$server::AllowTeamPlay = True;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionLoad()
{
   cdAudioCycle("Newtech", "Mechsoul", "Terror"); 
}


//-------------------------------------------------------------
function player::onAdd(%player)
{
   say(%player, 0, "Welcome to the Crowd!! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionStart()
{
   desertSounds();
   $turn = off;
}

function vehicle::onScan(%scanned, %scanner)
{
   %dude = playerManager::vehicleIdToPlayerNum(%scanner);
   %abc = getConnection(%dude);
   if(%abc == "LOOPBACK")
   {
	%z = getPosition(%scanned, z) - 6;
	$trap = getObjectId("Missiongroup\\surge");
	%person = playerManager::vehicleIdToPlayerNum(%scanned);
	%y = getPosition(%scanned, y);
	%z1 = getPosition(%scanned, z) + 0.7;
	%x = getPosition(%scanned, x);
	setPosition(%scanned, %x, %y, %z1);
	setPosition($trap, %x, %y, %z);
	messageBox(%person, "You have been punished by the host.");
	schedule("healObject(" @ %scanned @ ", -50000);", 5 );
	schedule("setPosition($trap, %x, %y, -500);", 5.5 );
   }
}

function begin::structure::onAttacked(%d, %r)
{
   if($turn == off)
   {
	$turn = on;
	$hat = getObjectId("Missiongroup\\hat");
	%x1 = getPosition($hat, x);
	%y1 = getPosition($hat, y);
	%z1 = getPosition($hat, z);
	dropPod(%x1, %y1, %z1, %x1, %y1, 140);
	setFlybyCamera($hat , 85, 250, -220);
	schedule("setPlayerCamera();", 1);
	schedule("$turn = off;", 1.5 );
   }
}

function person1::structure::onScan(%d, %r)
{
   %x1 = getPosition(%d, x);
   %y1 = getPosition(%d, y);
   %z1 = getPosition(%d, z);
   %x2 = getPosition(%r, x);
   %y2 = getPosition(%r, y);
   %zrot = getAngle(%x1, %y1, %x2, %y2) - 90;
   setPosition(%d, %x1, %y1, %z1, %zrot, 0);
   playAnimSequence(%d, 0, true);
   schedule("randomreaction("@%r@");", 1 );
   schedule("CloseGuy("@%d@");", 2 );
}

function CloseGuy(%guy)
{
   playAnimSequence(%guy, 0, false);
}

function getAngle(%x1, %y1, %x2, %y2)
{
   //Angle is defined from point A (x1, y1) to point B (x2, y2)
   //Point A (x1, y1) is the base point (center of the protractor)
   //Be sure to enter the coordinates for the base point first (x1, y1)

   %deltaX = %x2 - %x1;
   %deltaY = %y2 - %y1;
   %angle = getVector(%deltaX, %deltaY);
   return %angle;
}

function randomreaction(%r)
{
   playSound(%r, "plasma3.wav", IDPRF_2D);
}

//from here down you don't wanna scan thru, you can see why :]// 

function getVector(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);   
   if((%tan >= -0.008728)&&(%tan < 0.008728))
   {
      if(%deltaX > 0)
      {
         %angle = 0;
      }
      else if(%deltaX < 0)
      {
         %angle = 180;
      }
      return %angle;
   }
   else if((%tan >= 0.008728)&&(%tan < 0.026188))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 1;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 181;
      }
      return %angle;
   }
   else if((%tan >= 0.026188)&&(%tan < 0.043664))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 2;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 182;
      }
      return %angle;
   }
   else if((%tan >= 0.043664)&&(%tan < 0.061167))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 3;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 183;
      }
      return %angle;
   }
   else if((%tan >= 0.061167)&&(%tan < 0.078708))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 4;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 184;
      }
      return %angle;
   }
   else if((%tan >= 0.078708)&&(%tan < 0.096296))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 5;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 185;
      }
      return %angle;
   }
   else if((%tan >= 0.096296)&&(%tan < 0.113944))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 6;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 186;
      }
      return %angle;
   }
   else if((%tan >= 0.113944)&&(%tan < 0.131663))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 7;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 187;
      }
      return %angle;
   }
   else if((%tan >= 0.131663)&&(%tan < 0.149463))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 8;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 188;
      }
      return %angle;
   }
   else if((%tan >= 0.149463)&&(%tan < 0.167356))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 9;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 189;
      }
      return %angle;
   }
   else if((%tan >= 0.167356)&&(%tan < 0.185354))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 10;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 190;
      }
      return %angle;
   }
   else if((%tan >= 0.185354)&&(%tan < 0.203468))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 11;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 191;
      }
      return %angle;
   }
   else if((%tan >= 0.203468)&&(%tan < 0.221712))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 12;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 192;
      }
      return %angle;
   }
   else if((%tan >= 0.221712)&&(%tan < 0.240098))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 13;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 193;
      }
      return %angle;
   }
   else if((%tan >= 0.240098)&&(%tan < 0.258639))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 14;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 194;
      }
      return %angle;
   }
   else if((%tan >= 0.258639)&&(%tan < 0.277347))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 15;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 195;
      }
      return %angle;
   }
   else if((%tan >= 0.277347)&&(%tan < 0.296238))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 16;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 196;
      }
      return %angle;
   }
   else if((%tan >= 0.296238)&&(%tan < 0.315325))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 17;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 197;
      }
      return %angle;
   }
   else if((%tan >= 0.315325)&&(%tan < 0.334624))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 18;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 198;
      }
      return %angle;
   }
   else if((%tan >= 0.334624)&&(%tan < 0.354149))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 19;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 199;
      }
      return %angle;
   }
   else if((%tan >= 0.354149)&&(%tan < 0.373917))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 20;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 200;
      }
      return %angle;
   }
   else
   {
      getVector2(%deltaX, %deltaY);
   }
}

function getVector2(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 0.373917)&&(%tan < 0.393945))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 21;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 201;
      }
      return %angle;
   }
   else if((%tan >= 0.393945)&&(%tan < 0.414251))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 22;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 202;
      }
      return %angle;
   }
   else if((%tan >= 0.414251)&&(%tan < 0.434852))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 23;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 203;
      }
      return %angle;
   }
   else if((%tan >= 0.434852)&&(%tan < 0.455768))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 24;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 204;
      }
      return %angle;
   }
   else if((%tan >= 0.455768)&&(%tan < 0.477020))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 25;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 205;
      }
      return %angle;
   }
   else if((%tan >= 0.477020)&&(%tan < 0.498629))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 26;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 206;
      }
      return %angle;
   }
   else if((%tan >= 0.498629)&&(%tan < 0.520617))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 27;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 207;
      }
      return %angle;
   }
   else if((%tan >= 0.520617)&&(%tan < 0.543009))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 28;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 208;
      }
      return %angle;
   }
   else if((%tan >= 0.543009)&&(%tan < 0.565830))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 29;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 209;
      }
      return %angle;
   }
   else if((%tan >= 0.565830)&&(%tan < 0.589105))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 30;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 210;
      }
      return %angle;
   }
   else if((%tan >= 0.589105)&&(%tan < 0.612865))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 31;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 211;
      }
      return %angle;
   }
   else if((%tan >= 0.612865)&&(%tan < 0.637138))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 32;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 212;
      }
      return %angle;
   }
   else if((%tan >= 0.637138)&&(%tan < 0.661958))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 33;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 213;
      }
      return %angle;
   }
   else if((%tan >= 0.661958)&&(%tan < 0.687358))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 34;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 214;
      }
      return %angle;
   }
   else if((%tan >= 0.687358)&&(%tan < 0.713375))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 35;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 215;
      }
      return %angle;
   }
   else if((%tan >= 0.713375)&&(%tan < 0.740048))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 36;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 216;
      }
      return %angle;
   }
   else if((%tan >= 0.740048)&&(%tan < 0.767420))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 37;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 217;
      }
      return %angle;
   }
   else if((%tan >= 0.767420)&&(%tan < 0.795535))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 38;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 218;
      }
      return %angle;
   }
   else if((%tan >= 0.795535)&&(%tan < 0.824442))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 39;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 219;
      }
      return %angle;
   }
   else if((%tan >= 0.824442)&&(%tan < 0.854193))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 40;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 220;
      }
      return %angle;
   }
   else
   {
      getVector3(%deltaX, %deltaY);
   }
}

function getVector3(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 0.854193)&&(%tan < 0.884845))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 41;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 221;
      }
      return %angle;
   }
   else if((%tan >= 0.884845)&&(%tan < 0.916460))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 42;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 222;
      }
      return %angle;
   }
   else if((%tan >= 0.916460)&&(%tan < 0.949102))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 43;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 223;
      }
      return %angle;
   }
   else if((%tan >= 0.949102)&&(%tan < 0.982844))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 44;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 224;
      }
      return %angle;
   }
   else if((%tan >= 0.982844)&&(%tan < 1.017765))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 45;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 225;
      }
      return %angle;
   }
   else if((%tan >= 1.017765)&&(%tan < 1.053950))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 46;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 226;
      }
      return %angle;
   }
   else if((%tan >= 1.053950)&&(%tan < 1.091491))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 47;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 227;
      }
      return %angle;
   }
   else if((%tan >= 1.091491)&&(%tan < 1.130490))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 48;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 228;
      }
      return %angle;
   }
   else if((%tan >= 1.130490)&&(%tan < 1.171061))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 49;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 229;
      }
      return %angle;
   }
   else if((%tan >= 1.171061)&&(%tan < 1.213325))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 50;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 230;
      }
      return %angle;
   }
   else if((%tan >= 1.213325)&&(%tan < 1.257419))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 51;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 231;
      }
      return %angle;
   }
   else if((%tan >= 1.257419)&&(%tan < 1.303493))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 52;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 232;
      }
      return %angle;
   }
   else if((%tan >= 1.303493)&&(%tan < 1.351713))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 53;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 233;
      }
      return %angle;
   }
   else if((%tan >= 1.351713)&&(%tan < 1.402265))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 54;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 234;
      }
      return %angle;
   }
   else if((%tan >= 1.402265)&&(%tan < 1.455354))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 55;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 235;
      }
      return %angle;
   }
   else if((%tan >= 1.455354)&&(%tan < 1.511213))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 56;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 236;
      }
      return %angle;
   }
   else if((%tan >= 1.511213)&&(%tan < 1.570100))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 57;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 237;
      }
      return %angle;
   }
   else if((%tan >= 1.570100)&&(%tan < 1.632307))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 58;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 238;
      }
      return %angle;
   }
   else if((%tan >= 1.632307)&&(%tan < 1.698165))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 59;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 239;
      }
      return %angle;
   }
   else if((%tan >= 1.698165)&&(%tan < 1.768049))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 60;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 240;
      }
      return %angle;
   }
   else
   {
      getVector4(%deltaX, %deltaY);
   }
}

function getVector4(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 1.768049)&&(%tan < 1.842387))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 61;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 241;
      }
      return %angle;
   }
   else if((%tan >= 1.842387)&&(%tan < 1.921668))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 62;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 242;
      }
      return %angle;
   }
   else if((%tan >= 1.921668)&&(%tan < 2.006457))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 63;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 243;
      }
      return %angle;
   }
   else if((%tan >= 2.006457)&&(%tan < 2.097405))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 64;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 244;
      }
      return %angle;
   }
   else if((%tan >= 2.097405)&&(%tan < 2.195272))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 65;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 245;
      }
      return %angle;
   }
   else if((%tan >= 2.195272)&&(%tan < 2.300945))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 66;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 246;
      }
      return %angle;
   }
   else if((%tan >= 2.300945)&&(%tan < 2.415470))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 67;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 247;
      }
      return %angle;
   }
   else if((%tan >= 2.415470)&&(%tan < 2.540088))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 68;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 248;
      }
      return %angle;
   }
   else if((%tan >= 2.540088)&&(%tan < 2.676283))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 69;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 249;
      }
      return %angle;
   }
   else if((%tan >= 2.676283)&&(%tan < 2.825844))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 70;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 250;
      }
      return %angle;
   }
   else if((%tan >= 2.825844)&&(%tan < 2.990947))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 71;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 251;
      }
      return %angle;
   }
   else if((%tan >= 2.990947)&&(%tan < 3.174268))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 72;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 252;
      }
      return %angle;
   }
   else if((%tan >= 3.174268)&&(%tan < 3.379134))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 73;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 253;
      }
      return %angle;
   }
   else if((%tan >= 3.379134)&&(%tan < 3.609733))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 74;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 254;
      }
      return %angle;
   }
   else if((%tan >= 3.609733)&&(%tan < 3.871416))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 75;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 255;
      }
      return %angle;
   }
   else if((%tan >= 3.871416)&&(%tan < 4.171128))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 76;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 256;
      }
      return %angle;
   }
   else if((%tan >= 4.171128)&&(%tan < 4.518053))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 77;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 257;
      }
      return %angle;
   }
   else if((%tan >= 4.518053)&&(%tan < 4.924592))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 78;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 258;
      }
      return %angle;
   }
   else if((%tan >= 4.924592)&&(%tan < 5.407918))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 79;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 259;
      }
      return %angle;
   }
   else if((%tan >= 5.407918)&&(%tan < 5.992517))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 80;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 260;
      }
      return %angle;
   }
   else
   {
      getVector5(%deltaX, %deltaY);
   }
}

function getVector5(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan >= 5.992517)&&(%tan < 6.714561))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 81;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 261;
      }
      return %angle;
   }
   else if((%tan >= 6.714561)&&(%tan < 7.629858))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 82;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 262;
      }
      return %angle;
   }
   else if((%tan >= 7.629858)&&(%tan < 8.829355))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 83;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 263;
      }
      return %angle;
   }
   else if((%tan >= 8.829355)&&(%tan < 10.472208))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 84;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 264;
      }
      return %angle;
   }
   else if((%tan >= 10.472208)&&(%tan < 12.865359))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 85;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 265;
      }
      return %angle;
   }
   else if((%tan >= 12.865359)&&(%tan < 16.690901))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 86;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 266;
      }
      return %angle;
   }
   else if((%tan >= 16.690901)&&(%tan < 23.858695))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 87;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 267;
      }
      return %angle;
   }
   else if((%tan >= 23.858695)&&(%tan < 42.963107))
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 88;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 268;
      }
      return %angle;
   }
   else if(%tan >= 42.963107)
   {
      if((%deltaX > 0)&&(%deltaY > 0))
      {
         %angle = 89;
      }
      else if((%deltaX < 0)&&(%deltaY < 0))
      {
         %angle = 269;
      }
      return %angle;
   }
   else if(%deltaX == 0)
   {
      if(%deltaY > 0)
      {
         %angle = 90;
      }
      else if(%deltaY < 0)
      {
         %angle = 270;
      }
      return %angle;
   }
   else if(%tan < -42.963107)
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 91;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 271;
      }
      return %angle;
   }
   else if((%tan < -23.858695)&&(%tan >= -42.963107))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 92;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 272;
      }
      return %angle;
   }
   else if((%tan < -16.690901)&&(%tan >= -23.858695))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 93;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 273;
      }
      return %angle;
   }
   else if((%tan < -12.865359)&&(%tan >= -16.690901))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 94;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 274;
      }
      return %angle;
   }
   else if((%tan < -10.472208)&&(%tan >= -12.865359))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 95;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 275;
      }
      return %angle;
   }
   else if((%tan < -8.829355)&&(%tan >= -10.472208))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 96;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 276;
      }
      return %angle;
   }
   else if((%tan < -7.629858)&&(%tan >= -8.829355))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 97;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 277;
      }
      return %angle;
   }
   else if((%tan < -6.714561)&&(%tan >= -7.629858))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 98;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 278;
      }
      return %angle;
   }
   else if((%tan < -5.992517)&&(%tan >= -6.714561))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 99;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 279;
      }
      return %angle;
   }
   else if((%tan < -5.407918)&&(%tan >= -5.992517))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 100;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 280;
      }
      return %angle;
   }
   else
   {
      getVector6(%deltaX, %deltaY);
   }
}

function getVector6(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -4.924592)&&(%tan >= -5.407918))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 101;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 281;
      }
      return %angle;
   }
   else if((%tan < -4.518053)&&(%tan >= -4.924592))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 102;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 282;
      }
      return %angle;
   }
   else if((%tan < -4.171128)&&(%tan >= -4.518053))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 103;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 283;
      }
      return %angle;
   }
   else if((%tan < -3.871416)&&(%tan >= -4.171128))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 104;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 284;
      }
      return %angle;
   }
   else if((%tan < -3.609733)&&(%tan >= -3.871416))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 105;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 285;
      }
      return %angle;
   }
   else if((%tan < -3.379134)&&(%tan >= -3.609733))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 106;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 286;
      }
      return %angle;
   }
   else if((%tan < -3.174268)&&(%tan >= -3.379134))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 107;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 287;
      }
      return %angle;
   }
   else if((%tan < -2.990947)&&(%tan >= -3.174268))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 108;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 288;
      }
      return %angle;
   }
   else if((%tan < -2.825844)&&(%tan >= -2.990947))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 109;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 289;
      }
      return %angle;
   }
   else if((%tan < -2.676283)&&(%tan >= -2.825844))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 110;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 290;
      }
      return %angle;
   }
   else if((%tan < -2.540088)&&(%tan >= -2.676283))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 111;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 291;
      }
      return %angle;
   }
   else if((%tan < -2.415470)&&(%tan >= -2.540088))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 112;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 292;
      }
      return %angle;
   }
   else if((%tan < -2.300945)&&(%tan >= -2.415470))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 113;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 293;
      }
      return %angle;
   }
   else if((%tan < -2.195272)&&(%tan >= -2.300945))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 114;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 294;
      }
      return %angle;
   }
   else if((%tan < -2.097405)&&(%tan >= -2.195272))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 115;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 295;
      }
      return %angle;
   }
   else if((%tan < -2.006457)&&(%tan >= -2.097405))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 116;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 296;
      }
      return %angle;
   }
   else if((%tan < -1.921668)&&(%tan >= -2.006457))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 117;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 297;
      }
      return %angle;
   }
   else if((%tan < -1.842387)&&(%tan >= -1.921668))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 118;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 298;
      }
      return %angle;
   }
   else if((%tan < -1.768049)&&(%tan >= -1.842387))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 119;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 299;
      }
      return %angle;
   }
   else if((%tan < -1.698165)&&(%tan >= -1.768049))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 120;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 300;
      }
      return %angle;
   }
   else
   {
      getVector7(%deltaX, %deltaY);
   }
}

function getVector7(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -1.632307)&&(%tan >= -1.698165))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 121;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 301;
      }
      return %angle;
   }
   else if((%tan < -1.570100)&&(%tan >= -1.632307))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 122;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 302;
      }
      return %angle;
   }
   else if((%tan < -1.511213)&&(%tan >= -1.570100))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 123;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 303;
      }
      return %angle;
   }
   else if((%tan < -1.455354)&&(%tan >= -1.511213))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 124;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 304;
      }
      return %angle;
   }
   else if((%tan < -1.402265)&&(%tan >= -1.455354))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 125;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 305;
      }
      return %angle;
   }
   else if((%tan < -1.351713)&&(%tan >= -1.402265))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 126;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 306;
      }
      return %angle;
   }
   else if((%tan < -1.303493)&&(%tan >= -1.351713))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 127;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 307;
      }
      return %angle;
   }
   else if((%tan < -1.257419)&&(%tan >= -1.303493))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 128;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 308;
      }
      return %angle;
   }
   else if((%tan < -1.213325)&&(%tan >= -1.257419))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 129;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 309;
      }
      return %angle;
   }
   else if((%tan < -1.171061)&&(%tan >= -1.213325))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 130;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 310;
      }
      return %angle;
   }
   else if((%tan < -1.130490)&&(%tan >= -1.171061))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 131;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 311;
      }
      return %angle;
   }
   else if((%tan < -1.091491)&&(%tan >= -1.130490))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 132;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 312;
      }
      return %angle;
   }
   else if((%tan < -1.053950)&&(%tan >= -1.091491))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 133;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 313;
      }
      return %angle;
   }
   else if((%tan < -1.017765)&&(%tan >= -1.053950))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 134;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 314;
      }
      return %angle;
   }
   else if((%tan < -0.982844)&&(%tan >= -1.017765))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 135;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 315;
      }
      return %angle;
   }
   else if((%tan < -0.949102)&&(%tan >= -0.982844))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 136;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 316;
      }
      return %angle;
   }
   else if((%tan < -0.916460)&&(%tan >= -0.949102))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 137;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 317;
      }
      return %angle;
   }
   else if((%tan < -0.884845)&&(%tan >= -0.916460))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 138;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 318;
      }
      return %angle;
   }
   else if((%tan < -0.854193)&&(%tan >= -0.884845))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 139;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 319;
      }
      return %angle;
   }
   else if((%tan < -0.824442)&&(%tan >= -0.854193))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 140;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 320;
      }
      return %angle;
   }
   else
   {
      getVector8(%deltaX, %deltaY);
   }
}

function getVector8(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -0.795535)&&(%tan >= -0.824442))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 141;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 321;
      }
      return %angle;
   }
   else if((%tan < -0.767420)&&(%tan >= -0.795535))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 142;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 322;
      }
      return %angle;
   }
   else if((%tan < -0.740048)&&(%tan >= -0.767420))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 143;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 323;
      }
      return %angle;
   }
   else if((%tan < -0.713375)&&(%tan >= -0.740048))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 144;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 324;
      }
      return %angle;
   }
   else if((%tan < -0.687358)&&(%tan >= -0.713375))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 145;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 325;
      }
      return %angle;
   }
   else if((%tan < -0.661958)&&(%tan >= -0.687358))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 146;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 326;
      }
      return %angle;
   }
   else if((%tan < -0.637138)&&(%tan >= -0.661958))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 147;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 327;
      }
      return %angle;
   }
   else if((%tan < -0.612865)&&(%tan >= -0.637138))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 148;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 328;
      }
      return %angle;
   }
   else if((%tan < -0.589105)&&(%tan >= -0.612865))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 149;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 329;
      }
      return %angle;
   }
   else if((%tan < -0.565830)&&(%tan >= -0.589105))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 150;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 330;
      }
      return %angle;
   }
   else if((%tan < -0.543009)&&(%tan >= -0.565830))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 151;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 331;
      }
      return %angle;
   }
   else if((%tan < -0.520617)&&(%tan >= -0.543009))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 152;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 332;
      }
      return %angle;
   }
   else if((%tan < -0.498629)&&(%tan >= -0.520617))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 153;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 333;
      }
      return %angle;
   }
   else if((%tan < -0.477020)&&(%tan >= -0.498629))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 154;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 334;
      }
      return %angle;
   }
   else if((%tan < -0.455768)&&(%tan >= -0.477020))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 155;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 335;
      }
      return %angle;
   }
   else if((%tan < -0.434852)&&(%tan >= -0.455768))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 156;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 336;
      }
      return %angle;
   }
   else if((%tan < -0.414251)&&(%tan >= -0.434852))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 157;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 337;
      }
      return %angle;
   }
   else if((%tan < -0.393945)&&(%tan >= -0.414251))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 158;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 338;
      }
      return %angle;
   }
   else if((%tan < -0.373917)&&(%tan >= -0.393945))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 159;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 339;
      }
      return %angle;
   }
   else if((%tan < -0.354149)&&(%tan >= -0.373917))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 160;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 340;
      }
      return %angle;
   }
   else
   {
      getVector9(%deltaX, %deltaY);
   }
}

function getVector9(%deltaX, %deltaY)
{
   %tan = (%deltaY / %deltaX);
   if((%tan < -0.334624)&&(%tan >= -0.354149))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 161;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 341;
      }
      return %angle;
   }
   else if((%tan < -0.315325)&&(%tan >= -0.334624))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 162;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 342;
      }
      return %angle;
   }
   else if((%tan < -0.296238)&&(%tan >= -0.315325))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 163;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 343;
      }
      return %angle;
   }
   else if((%tan < -0.277347)&&(%tan >= -0.296238))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 164;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 344;
      }
      return %angle;
   }
   else if((%tan < -0.258639)&&(%tan >= -0.277347))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 165;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 345;
      }
      return %angle;
   }
   else if((%tan < -0.240098)&&(%tan >= -0.258639))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 166;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 346;
      }
      return %angle;
   }
   else if((%tan < -0.221712)&&(%tan >= -0.240098))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 167;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 347;
      }
      return %angle;
   }
   else if((%tan < -0.203468)&&(%tan >= -0.221712))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 168;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 348;
      }
      return %angle;
   }
   else if((%tan < -0.185354)&&(%tan >= -0.203468))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 169;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 349;
      }
      return %angle;
   }
   else if((%tan < -0.167356)&&(%tan >= -0.185354))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 170;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 350;
      }
      return %angle;
   }
   else if((%tan < -0.149463)&&(%tan >= -0.167356))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 171;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 351;
      }
      return %angle;
   }
   else if((%tan < -0.131663)&&(%tan >= -0.149463))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 172;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 352;
      }
      return %angle;
   }
   else if((%tan < -0.113944)&&(%tan >= -0.131663))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 173;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 353;
      }
      return %angle;
   }
   else if((%tan < -0.096296)&&(%tan >= -0.113944))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 174;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 354;
      }
      return %angle;
   }
   else if((%tan < -0.078708)&&(%tan >= -0.096296))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 175;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 355;
      }
      return %angle;
   }
   else if((%tan < -0.061167)&&(%tan >= -0.078708))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 176;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 356;
      }
      return %angle;
   }
   else if((%tan < -0.043664)&&(%tan >= -0.061167))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 177;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 357;
      }
      return %angle;
   }
   else if((%tan < -0.026188)&&(%tan >= -0.043664))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 178;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 358;
      }
      return %angle;
   }
   else if((%tan < -0.008728)&&(%tan >= -0.026188))
   {
      if((%deltaX < 0)&&(%deltaY > 0))
      {
         %angle = 179;
      }
      else if((%deltaX > 0)&&(%deltaY < 0))
      {
         %angle = 359;
      }
      return %angle;
   }
}
