// FILENAME:	TDM_Desolate_Night.cs
//
// AUTHOR:		Gen. Raven [M.I.B.]
//
// RANDOM ADVICE: Watch The Late Show with David Letterman. It's where I get all my ideas. :) Not really, but it's still cool.
//------------------------------------------------------------------------------

$missionName = "TDM_Desolate_Night";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul");
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to TDM Desolate Night! You can download this & other missions made by Gen. Raven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%this)
{
   // see if it is a player
   %player = playerManager::vehicleIdToPlayerNum(%this);
   if(%player == 0) 
      return;

   schedule( "setEnemyNavPoint(" @ %this @ ");", 1 );
}

function setEnemyNavPoint( %this )
{
   if( getTeam(%this) == *IDSTR_TEAM_BLUE )
   {
      setNavMarker( "MissionGroup/NavPurple", true, %this );
   }
   else
   {
      setNavMarker( "MissionGroup/NavBlue", true, %this );
   }
}

function onMissionStart()
{
	initGlobalVars();
   
	marsSounds();
}

//Prometheus' Radioactive Disco Hut

function Disco::trigger::onContact(%this, %object)
{
	damageObject(%object, 1000);
}

//Teleportation

function Prom::structure::onAttacked(%this, %attacker){

	say(%this, 1, "PROMETHEUS: You dare attack my sacred statue! Now you will die!!!");

	
		setPosition(%attacker, 7390.44, 3407.62, 601);
	}
}