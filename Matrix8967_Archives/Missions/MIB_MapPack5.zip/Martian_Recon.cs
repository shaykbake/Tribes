// FILENAME:	Martian_Recon.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Martian Recon";

// Allows the missions to cycle (defaulted to true)
$cycleMissions = true;

$missionLoaded = false;
$missionStarted = false;
$currentActivePlayers = 0;
$playersBackAtBase = 0;
$datalinkEngaged = false;
$playersDownloading = 0;
$downloader = "Nobody";
$downloadTime = 0;
$downloadObjComp = false;
$downloadLock = false;
$successLock = false;
$dataProxLock = false;
$vehId = "N/A";
$vehType = "N/A";
$squad1Activated = false;
$squad2Activated = false;
$squad3Activated = false;
$squad4Activated = false;
$ambushActivated = false;

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
}

Pilot LongRange
{
   id = 28;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 1000.0;
   deactivateBuff = 1000.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

function onMissionStart()
{
   marsSounds();
   $navBravo = getObjectId("Missiongroup\\navBravo");
   $navEcho = getObjectId("Missiongroup\\navEcho");
   $AIhercs = "Missiongroup/AIhercs";
   $squad1Herc1 = getObjectId("Missiongroup\\squad1Herc1");
   $squad1Herc2 = getObjectId("Missiongroup\\squad1Herc2");
   $squad1Herc3 = getObjectId("Missiongroup\\squad1Herc3");
   $squad2Herc1 = getObjectId("Missiongroup\\squad2Herc1");
   $squad2Herc2 = getObjectId("Missiongroup\\squad2Herc2");
   $squad2Herc3 = getObjectId("Missiongroup\\squad2Herc3");
   $squad3Herc1 = getObjectId("Missiongroup\\squad3Herc1");
   $squad3Herc2 = getObjectId("Missiongroup\\squad3Herc2");
   $squad3Herc3 = getObjectId("Missiongroup\\squad3Herc3");
   $squad4Herc1 = getObjectId("Missiongroup\\squad4Herc1");
   $squad4Herc2 = getObjectId("Missiongroup\\squad4Herc2");
   $squad4Herc3 = getObjectId("Missiongroup\\squad4Herc3");
   $squad1path = "Missiongroup/squad1path";
   $squad2path = getObjectId("Missiongroup\\squad2path");
   $listeningPost = getObjectId("Missiongroup\\listeningPost");
   $squad4path = "Missiongroup/squad4path";
   $altAdjustPath = getObjectId("Missiongroup\\altSquad1path\\altAdjustPath");
   $altSquad1path = "Missiongroup/altSquad1Path";
   setVehicleRadarVisible($squad1Herc1, false);
   setVehicleRadarVisible($squad1Herc2, false);
   setVehicleRadarVisible($squad1Herc3, false);
   setVehicleRadarVisible($squad2Herc1, false);
   setVehicleRadarVisible($squad2Herc2, false);
   setVehicleRadarVisible($squad2Herc3, false);
   setVehicleRadarVisible($squad3Herc1, false);
   setVehicleRadarVisible($squad3Herc2, false);
   setVehicleRadarVisible($squad3Herc3, false);
   setVehicleRadarVisible($squad4Herc1, false);
   setVehicleRadarVisible($squad4Herc2, false);
   setVehicleRadarVisible($squad4Herc3, false);
}

function player::onAdd(%player)
{
   say(%player, 0, "Mission 1: Martian Recon. You are a part of a small rebel force on Mars. Your mission is to proceed to nav Echo and establish a direct data-link with an imperial listening post. Your squad must then download the necessary intelligence in order for the martian resistance to determine the location of a certain hidden imperial base. Good Luck.");
   %player.datalink = false;
   %player.status = "Waiting";
   %player.vehicle = "N/A";
   %player.reload = true;
   %player.late = true;
}

function onMissionLoad()
{
   cdAudioCycle("Watching", "Purge", "Cyberntx");
   setGameInfo("<F2>GAME TYPE:<F0>  MIB Multiplayer Campaign\n\n<F2>MISSION:<F0>  Mission 1: Martian Recon\n\n<F2>MISSION CREATOR:<F0>  Com. Sentinal [M.I.B.]\n\n<F2>BRIEFING:<F0>\n\nYou are a part of a small rebel force on Mars. Your mission is to proceed to nav Echo and establish a direct data-link with an imperial listening post. Your squad must then download the necessary intelligence in order for the martian resistance to determine the location of a certain hidden imperial base. Good Luck.\n\n<F3>TIP: Each player has 1 emergency reload per mission. Scan another vehicle to use it at any time during the mission.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download the entire MIB Multiplayer Campaign & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      %player.status = "Waiting";
      %player.late = true;
   }
   $currentActivePlayers = "N/A";
   if($missionLoaded == false)
   {
      $missionLoaded = true;
      say("Everybody", 0, "Mission 1: Martian Recon. You are a part of a small rebel force on Mars. Your mission is to proceed to nav Echo and establish a direct data-link with an imperial listening post. Your squad must then download the necessary intelligence in order for the martian resistance to determine the location of a certain hidden imperial base. Good Luck.");
   }
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player != 0)
   {
      %player.late = true;
      %player.reload = false;
      if((getTeam(%vehicleId)!=*IDSTR_TEAM_YELLOW)&&(%player!=0))
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      }
      if($missionStarted==true)
      {
         schedule("healObject(" @ %vehicleId @ ", -50000);", 1);
         messageBox(%player, "You cannot join a game in progress. Please wait until the mission is over to join.");
      }
      else if($missionStarted==false)
      {
         %player.late = false;
         %player.status = "Alive";
         %player.vehicle = getVehicleName(%vehicleId);
      }
      %vehicleId.backAtBase = false;
   }
}

function dropZoneWarning::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if($missionStarted==false)
      {
         say(%player, 1, "<F5>WARNING: Exiting the drop zone will start the mission.");
      }
      if($downloadObjComp==true)
      {
         if(%object.backAtBase == false)
         {
            %object.backAtBase = true;
            $playersBackAtBase++;
            if($playersBackAtBase >= $currentActivePlayers)
            {
               if($successLock == false)
               {
                  $successLock = true;
                  setFlybyCamera(%object, -50, 50, 50);
                  missionSuccessful();
               }
            }
         }
      }
   }
}

function exitDropZone::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      $missionStarted = true;
      startMessage();
   }
}

function startMessage()
{
   $playersNotLate = 0;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(%player.late==false)
      {
         $playersNotLate++;
      }
      %player.reload = false;
   }
   $currentActivePlayers = $playersNotLate;
   if($playersNotLate == 1)
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " player.");
   }
   else
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " players.");
   }
   schedule("setNavEcho();",5);
}

function setNavEcho()
{
   squad2();
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navBravo, false, %vehicleId); 
      setNavMarker($navEcho, true, %vehicleId); 
   }
   say("Everybody", 2, "<F1>TAC-COM: Your orders are to proceed to nav Echo and establish a data-link to the enemy listening post.");
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Then you must hack into the computer mainframe and download the necessary imperial intelligence.\");", 5);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Be warned, there has been several imperial patrols spotted in this area. Be on the lookout.\");", 10);
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: We must now cease all transmissions as to not be detected. Good luck.\");", 15);
}

function squad1::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad1Activated==false))
   {
      $squad1Activated = true;
      setPosition($squad1Herc1, -665, -3, 476);
      setPosition($squad1Herc2, -680, 23, 473);
      setPosition($squad1Herc3, -630, 24, 475);
      setVehicleRadarVisible($squad1Herc1, true);
      setVehicleRadarVisible($squad1Herc2, true);
      setVehicleRadarVisible($squad1Herc3, true);
      say("Everybody", 1, "<F5>WARNING: Enemy squad detected.", "enem_squad_det.wav");
      order($squad1Herc1, guard, $squad1path);
      order($squad1Herc2, guard, $squad1path);
      order($squad1Herc3, guard, $squad1path);
      order($squad1Herc1, speed, high);
      order($squad1Herc2, speed, high);
      order($squad1Herc3, speed, high);
      %x1 = -1550;
      %y1 = -391;
      %x2 = -505;
      %y2 = 597;
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 8))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 8)
      {
         %extraHercs = 8;
      }
      $currentPath = $squad1Path;
      %speed = "high";
      dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, 3, %speed);
   }
}

function altSquad1::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad1Activated==false))
   {
      $squad1Activated = true;
      %xAlt = getPosition(%object, x) + 50;
      %yAlt = getPosition(%object, y) + 500;
      %zAlt = getTerrainHeight(%xAlt, %yAlt);
      setPosition($altAdjustPath, %xAlt, %yAlt, %zAlt);
      setPosition($squad1Herc1, 1306, 533, 599);
      setPosition($squad1Herc2, 1321, 491, 598);
      setPosition($squad1Herc3, 1276, 514, 604);
      setVehicleRadarVisible($squad1Herc1, true);
      setVehicleRadarVisible($squad1Herc2, true);
      setVehicleRadarVisible($squad1Herc3, true);
      say("Everybody", 1, "<F5>WARNING: Enemy squad detected.", "enem_squad_det.wav");
      order($squad1Herc1, guard, $altSquad1path);
      order($squad1Herc2, guard, $altSquad1path);
      order($squad1Herc3, guard, $altSquad1path);
      order($squad1Herc1, speed, high);
      order($squad1Herc2, speed, high);
      order($squad1Herc3, speed, high);
      %x1 = 792;
      %y1 = -24;
      %x2 = 1526;
      %y2 = 697;
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 8))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 8)
      {
         %extraHercs = 8;
      }
      $currentPath = $altSquad1Path;
      %speed = "high";
      dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, 3, %speed);
   }
}

function squad2()
{
   setVehicleRadarVisible($squad2Herc1, true);
   setVehicleRadarVisible($squad2Herc2, true);
   setVehicleRadarVisible($squad2Herc3, true);
   order($squad2Herc1, guard, $listeningPost);
   order($squad2Herc2, guard, $listeningPost);
   order($squad2Herc3, guard, $listeningPost);
   %x1 = 1144;
   %y1 = 1095;
   %x2 = 2002;
   %y2 = 2242;
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 3))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 3)
   {
      %extraHercs = 3;
   }
   $currentPath = $squad2Path;
   %speed = "low";
   dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, 3, %speed);
}

function squad3()
{
   setVehicleRadarVisible($squad3Herc1, true);
   setVehicleRadarVisible($squad3Herc2, true);
   setVehicleRadarVisible($squad3Herc3, true);
   order($squad3Herc1, guard, $listeningPost);
   order($squad3Herc2, guard, $listeningPost);
   order($squad3Herc3, guard, $listeningPost);
   %x1 = -1557;
   %y1 = 3162;
   %x2 = 2614;
   %y2 = 3929;
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 7))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 7)
   {
      %extraHercs = 7;
   }
   $currentPath = $listeningPost;
   %speed = "low";
   dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, 3, %speed);
}

function squad4()
{
   setVehicleRadarVisible($squad4Herc1, true);
   setVehicleRadarVisible($squad4Herc2, true);
   setVehicleRadarVisible($squad4Herc3, true);
   setPilotId($squad4Herc1, 28);
   setPilotId($squad4Herc2, 28);
   setPilotId($squad4Herc3, 28);
   setPosition($squad4Herc1, 846, 2799, 625);
   setPosition($squad4Herc2, 897, 2810, 620);
   setPosition($squad4Herc3, 796, 2807, 625);
   order($squad4Herc1, guard, $squad4Path);
   order($squad4Herc2, guard, $squad4Path);
   order($squad4Herc3, guard, $squad4Path);
   order($squad4Herc1, speed, high);
   order($squad4Herc2, speed, high);
   order($squad4Herc3, speed, high);
   %x1 = -130;
   %y1 = 2785;
   %x2 = 1594;
   %y2 = 3254;
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 6)
   {
      %extraHercs = 6;
   }
   $currentPath = $squad4Path;
   %speed = "high";
   dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, 3, %speed);
}

function Ambush::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($ambushActivated==false)&&($downloadObjComp==true))
   {
      $ambushActivated = true;
      %x1 = 669;
      %y1 = -547;
      %x2 = 1612;
      %y2 = 231;
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 3))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 3)
      {
         %extraHercs = 3;
      }
      $currentPath = %object;
      %speed = "high";
      dropExtraHercsAmbush(%extraHercs, %x1, %y1, %x2, %y2, 3, %speed);
   }
}

function dropExtraHercs(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      randomTransport(%herc, %x1, %y1, %x2, %y2);
      order(%herc, guard, $currentPath);
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraHercs(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ");", %dropInterval);
   }
}

function dropExtraHercsAmbush(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      randomTransport(%herc, %x1, %y1, %x2, %y2);
      order(%herc, attack, $currentPath);
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraHercs(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ");", %dropInterval);
   }
}

function randomVeh()
{
   %type = randomInt(0,21);
   if(%type==0)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 2;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 3;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 4;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 5;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 6;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 7;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 10;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 11;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 12;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 13;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 14;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 15;
      $vehType = "tank";
   }
   else if(%type==13)
   {
      $vehId = 16;
      $vehType = "tank";
   }
   else if(%type==14)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==15)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==16)
   {
      $vehId = 1;
      $vehType = "herc";
   }
   else if(%type==17)
   {
      $vehId = 3;
      $vehType = "herc";
   }
   else if(%type==18)
   {
      $vehId = 3;
      $vehType = "herc";
   }
   else if(%type==19)
   {
      $vehId = 10;
      $vehType = "herc";
   }
   else if(%type==20)
   {
      $vehId = 12;
      $vehType = "herc";
   }
   else if(%type==21)
   {
      $vehId = 5;
      $vehType = "herc";
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   if(%player1 == 0)
   {
      schedule("deleteObject(" @ %destroyed @ ");", 5);
   }
   else
   {
      if($missionStarted == true)
      {
         %player1.datalink = false;
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            reloadObject(%vehicleId, 10000);
         }
         if(%player1.late == false)
         {
            %player1.late = true;
            %player1.status = "Dead";
            $currentActivePlayers--;
            checkForPlayersDead();
            if(($playersBackAtBase >= $currentActivePlayers)&&($playersBackAtBase > 0))
            {
               missionSuccessful();
            }
         }
      }
      else
      {
         %player1.late = true;
         %player1.status = "Waiting";
      }
   }
   if(%player2 != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function datalink::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {  
      $playersDownloading++;
      %player.datalink = true;
      if($datalinkEngaged == false)
      {
         $downloader = %object;
         $datalinkEngaged = true;
         say("Everybody", 2, "<F5>Data-link Engaged.", "dlink_engaged.wav");
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %everybody = playerManager::getPlayerNum(%i);
            setHudTimer(180, -1, "Downloading Data:", 2, %everybody);
         }
         if($dataProxLock == false)
         {
            $dataProxLock = true;
            schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: Your squad must remain within close proximity of the listening post until the download has been completed.\");", 3);
         }
      }
      if($squad3Activated == false)
      {
         $squad3Activated = true;
         squad3();
      }  
   }
}

function datalink::trigger::onLeave(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      $playersDownloading--;
      %player.datalink = false;
      if(($datalinkEngaged == true)&&($downloadObjComp == false))
      {
         if(%object == $downloader)
         {
            if($playersDownloading > 0)
            {
               pickNewDownloader();
            }
            else
            {
               $downloader = "Nobody";
               $datalinkEngaged = false;
               $downloadTime = 0;
               %count = playerManager::getPlayerCount();
               for(%i = 0; %i < %count; %i++)
               {
                  %everybody = playerManager::getPlayerNum(%i);
                  setHudTimer(0, 1, "", 2, %everybody);
               }
               say("Everybody", 2, "<F5>Data Transfer Aborted.", "dlink_abort.wav");
            }
         }
      }
   }
}

function datalink::trigger::onContact(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if(($datalinkEngaged == true)&&($playersDownloading > 0))
      {  
         if(%object == $downloader)
         {
            $downloadTime++;
            if(($downloadTime >= 174)&&($downloadLock == false))
            {
               $downloadLock = true;
               downloadComplete();
            }
         }
      }
   }
}

function pickNewDownloader()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if(%player.datalink == true)
      {
         if($downloader == "Nobody")
         {
            $downloader = %vehicleId;
         }
      }
   }
}

function downloadComplete()
{  
   $downloadObjComp = true;
   say("Everybody", 2, "<F1>Data Transfer Complete.", "dlink_complete.wav");
   schedule("say(\"Everybody\", 2, \"<F1>TAC-COM: We've detected more imperial reinforcements on the way, head back to nav Bravo immediately.\", \"mission_obj_new.wav\");", 3);
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navEcho, false, %vehicleId);
      setNavMarker($navBravo, true, %vehicleId);
   }
   squad4();
}

function checkForPlayersDead()
{
   %allDead = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%vehicleId != "") && (isGroupDestroyed(%vehicleId) == false))
      {
         %allDead = false;
      }
   }
   if(%allDead == true)
   {
      schedule("missionFailed();", 3);
   }
}

function listeningPost::structure::onDestroyed(%destroyed, %destroyer)
{
   if($downloadObjComp == false)
   {
      say("Everybody", 2, "<F5>The listening post has been destroyed!");
      schedule("missionFailed();", 3);
   }
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player.reload == false)
   {
      %player.reload = true;
      reloadObject(%scanner, 99999);
      say(%player, %player, "<F5>Emergency reload initiated.");
   }
}

function missionSuccessful()
{
   flushConsoleScheduler();
   playSound(0, "Mission_comp.wav", IDPRF_2D);
   messageBox(0, "Mission Successful");
   if($cycleMissions == true)
   {
      $MissionCycling::Stage0 = "Covert_Strike";
      $server::Mission = $MissionCycling::Stage0;
   }
   schedule("missionEndConditionMet();", 10);
}

function missionFailed()
{  
   if($successLock == false)
   {
      flushConsoleScheduler();
      playSound(0, "Mission_fail.wav", IDPRF_2D);
      messageBox(0, "Mission Failed");
      if($cycleMissions == true)
      {
         $MissionCycling::Stage0 = "Covert_Strike";
         $server::Mission = $MissionCycling::Stage0;
      }
      schedule("missionEndConditionMet();", 5);
   }
}

function onMissionEnd()
{
   deleteObject($AIhercs);
}

function getPlayerStatus(%player)
{
   return(%player.status);
}

function getActivePlayers()
{
   return($currentActivePlayers);
}

function getPlayerVehicle(%player)
{
   return(%player.vehicle);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";


	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
         $ScoreBoard::PlayerColumnFunction4 = "getPlayerVehicle";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = "Players Remaining";
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getActivePlayers";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}
