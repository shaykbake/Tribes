// FILENAME:	ATR2_CTF_Titanic_Assault.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "ATR2_CTF_Titanic_Assault";

$maxFlagCount  = 5;        
$flagValue     = 5;        
$carrierValue  = 2;        
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 0;

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

$server::HudMapViewOffsetX = -6300;
$server::HudMapViewOffsetY = 2400;

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;

      $server::MassLimit = 0;
}

function onMissionStart()
{
	initGlobalVars();

      $padWaitTime = 0;

	titanSounds();
}   

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to ATR2 CTF_Titanic_Assault! This is as close to the SS Alpha Tech Release 2 as you're gonna get! You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

// Ammo Pad Functionality
//------------------------------------------------------------------------------
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}

function setDefaultMissionItems()
{
   allowVehicle(                                          all, FALSE  );
   allowVehicle(                                            2, TRUE  );  //Minotaur
   allowVehicle(                                           30, TRUE  );  //Emancipator
   allowVehicle(                                           21, TRUE  );  //Goad
   allowVehicle(                                            7, TRUE  );  //Myrmidon
   
   allowWeapon(                                           all, FALSE  );
   allowWeapon(                                           101, TRUE  );  //Laser
   allowWeapon(                                           105, TRUE  );  //EMP
   allowWeapon(                                           107, TRUE  );  //Blaster
   allowWeapon(                                           116, TRUE  );  //ATC
   allowWeapon(                                           119, TRUE  );  //Blast Cannon
   allowWeapon(                                           126, TRUE  );  //Sparrow Missile Pack 6
   allowWeapon(                                           127, TRUE  );  //Sparrow Missile Pack 10

   allowComponent(                                        all, TRUE  );
   allowComponent(                                        800, FALSE  );  //Computers Restricted
   allowComponent(                                        802, FALSE  );  
   allowComponent(                                        805, FALSE  );  
   allowComponent(                                        806, FALSE  );  
   allowComponent(                                        807, FALSE  );  
   allowComponent(                                        809, FALSE  );  //Jammers Restricted
   allowComponent(                                        811, FALSE  );  
   allowComponent(                                        812, FALSE  );  
   allowComponent(                                        813, FALSE  );  
   allowComponent(                                        820, FALSE  );  //Thermal Diffuser
   allowComponent(                                        845, FALSE  );  //SCAP
   allowComponent(                                        850, FALSE  );  //SAMP
   allowComponent(                                        860, FALSE  );  //LTADs
   allowComponent(                                        865, FALSE  );  //Battery
   allowComponent(                                        870, FALSE  );  //CAP
   allowComponent(                                        875, FALSE  );  //Field Stabilizer
   allowComponent(                                        880, FALSE  );  //Rocket Booster
   allowComponent(                                        885, FALSE  );  //Turbine Booster
   allowComponent(                                        890, FALSE  );  //Nano-Repair Module
   allowComponent(                                        900, FALSE  );  //Angel Life Support
   allowComponent(                                        910, FALSE  );  //Anti-Gravity Gen
   allowComponent(                                        912, FALSE  );  //Electrohull
   allowComponent(                                        914, FALSE  );  //UAP
   allowComponent(                                        931, FALSE  );  //Quicksilver Nano-Armor
}


//--------------------------------------------------------------------------------
//--easter code

function vanishTrigger1::trigger::onAdd(%this)
{
	dataStore(%this, "isActive", true); // bool for trigger active
}
function vanishTrigger1::trigger::onEnter(%this, %object)
{
	triggerOnEnter(1, %object);	
}
function vanishTrigger2::trigger::onAdd(%this)
{
	dataStore(%this, "isActive", false); // bool for trigger active
}

function vanishTrigger2::trigger::onEnter(%this, %object)
{
	triggerOnEnter(2, %object);	
}
function vanishTrigger3::trigger::onAdd(%this, %object)
{
	dataStore(%this, "isActive", false); // bool for trigger active
}
function vanishTrigger3::trigger::onEnter(%this, %object)
{
	triggerOnEnter(3, %object);	
}
function teleportTrigger::trigger::onAdd(%this)
{
	dataStore(%this, "isActive", false); // bool for trigger active
}
function teleportTrigger::trigger::onEnter(%this, %object)
{
	triggerOnEnter(teleport, %object);	
}
function triggerOnEnter(%index, %object)
{
	%thisTrigger = "";
	%nextTrigger = "";
	%chatMsg = "";
	
	if(%index == 1)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger1");
		%nextTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger2");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\flag1");
		%nextFlag =    getObjectId("MissionGroup\\extra\\flag2");
		%chatMsg  = "Trigger 2 activated.";		 	 	
	}

	if(%index == 2)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger2");
		%nextTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger3");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\flag2");
		%nextFlag =    getObjectId("MissionGroup\\extra\\flag3");
		%chatMsg = "Trigger 3 activated.";	
	}

	if(%index == 3)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger3");
		%nextTrigger = getObjectId("MissionGroup\\extra\\teleportTrigger");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\flag3");
		%nextFlag =    getObjectId("MissionGroup\\extra\\teleport");
		%chatMsg = "Teleportation device online."; 
		setShapeVisibility(getObjectId("MissionGroup\\Extra\\fx_tele_t1"), true);	
	}

	if(%index == teleport)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\teleportTrigger");
		%nextTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger1");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\teleport");
		%nextFlag =    getObjectId("MissionGroup\\extra\\flag1");
		%chatMsg = "Teleportation Device is inoperable.";	
	}
	
	if(%thisTrigger == "" || %nextTrigger == "")
	{
		echo("bad triggerIds!");
		return;
	}
	
	%isActive = dataRetrieve(%thisTrigger, "isActive");

	if(%isActive != false)
	{
		dataStore(%thisTrigger, "isActive", false);
		dataStore(%nextTrigger, "isActive", true);
		
		if(%index != 3)
		{
			setShapeVisibility(%nextFlag, true);
		}
				
		if(%index == teleport)
		{
			%malfunctionChance = randomFloat(0.0,0.1);
			if(%malfunctionChance > randomFloat(0.0,1.0))
			{
				malfunction(%object);
			}
			else
			{
				teleport(%object);
				setShapeVisibility(getObjectId("MissionGroup\\Extra\\fx_tele_t1"), false);
			}
		}
		else
		{
			setShapeVisibility(%thisFlag, false);
			// chat(%object, 0, %chatMsg);	
		   Say( playerManager::vehicleIdToPlayerNum(%object), %object, %chatMsg );
      }					
	}
	else if(%index == teleport)
	{
		// chat(%object, 0, %chatMsg);
	   Say( playerManager::vehicleIdToPlayerNum(%object), %object, %chatMsg );
   }	
}
function teleport(%object)
{
	%flagNum = randomInt(1,2);
	%x = %y = 0;

	if(%flagNum == 1)
	{
		%x = -5099;
		%y = 4310;
	}

	if(%flagNum == 2)
	{
		%x = -4863;
		%y = 893;
	}
	
	%playerNum = playerManager::vehicleIdToPlayerNum(%object);
	
	Say( %object, %object, "Teleportation initiated." );
   
   	healObject(%object, 600.0);
	reloadObject(%object, 60.0);

	randomTransport(%object, %x, %y, %x, %y);
   	%str = "Say( %object, %object, \"Teleportation complete.\" );";
   	schedule( %str, 2.5 );
}
function malfunction(%object)
{
	Say( %object, %object, "Teleportation initiated." );
   
  	%playerNum = playerManager::vehicleIdToPlayerNum(%object);
	fadeEvent(%playerNum, out, 2.5, 0.5,0.0,0.0);
  	%str = "Say( %object, %object, \"Teleportation malfunction!\" );";
  	schedule( %str, 1.8 );
	
 	schedule(strcat("fadeEvent(", %playerNum, ", in, 1.5, 0.5,0.0,0.0);"), 2.5);
	schedule(strcat("damageObject(", %object, ", 10000);"), 2.5);		
}




