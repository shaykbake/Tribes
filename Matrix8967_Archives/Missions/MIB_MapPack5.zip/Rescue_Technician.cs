// FILENAME:	Rescue_Technician.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "Rescue Technician";

// Allows the missions to cycle (defaulted to true)
$cycleMissions = true;

$missionLoaded = false;
$missionStarted = false;
$currentActivePlayers = 0;
$rescue = false;
$playersBackAtBase = 0;
$successLock = false;
$vehId = "N/A";
$vehType = "N/A";
$squad1Activated = false;
$squad2Activated = false;
$squad3Activated = false;
$squad4Activated = false;
$bravo = false;
$delta = false;
$echo = false;
$foxtrot = false;
$cloak = false;
$turretDelay = false;
$reload = false;

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;

   $server::MaxPlayers = 10;
   $server::TimeLimit = 0;
}

Pilot BigRadar
{
   id = 28;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 1500.0;
   deactivateBuff = 1000.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot SmallRadar
{
   id = 29;
   skill = 0.5;
   accuracy = 0.5;
   aggressiveness = 0.5;
   activateDist = 200.0;
   deactivateBuff = 800.0;
   targetFreq = 3.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
};

Pilot Carter
{
   id = 30;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 0.0;
   activateDist = 0.0;
   deactivateBuff = 0.0;
   targetFreq = 1.0;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "LT Carter [IMP/KN/E17]";
};

Pilot Carter2
{
   id = 31;
   skill = 1.0;
   accuracy = 1.0;
   aggressiveness = 1.0;
   activateDist = 350.0;
   deactivateBuff = 0.0;
   targetFreq = 0.3;
   trackFreq = 0.1;
   fireFreq = 0.1;
   LOSFreq = 0.1;
   name = "LT Carter [IMP/KN/E17]";
};

function onMissionStart()
{
   venusSounds();
   $navAlpha = getObjectId("Missiongroup\\navAlpha");
   $navBravo = getObjectId("Missiongroup\\navBravo");
   $navDelta = getObjectId("Missiongroup\\navDelta");
   $navEcho = getObjectId("Missiongroup\\navEcho");
   $navFoxtrot = getObjectId("Missiongroup\\navFoxtrot");
   $AIhercs = "Missiongroup/AIhercs";
   $turret1 = getObjectId("Missiongroup\\base\\turret\\turret1");
   $turret2 = getObjectId("Missiongroup\\base\\turret\\turret2");
   $Technician = getObjectId("Missiongroup\\technician");
   $squad1Herc1 = getObjectId("Missiongroup\\squad1Herc1");
   $squad1Herc2 = getObjectId("Missiongroup\\squad1Herc2");
   $squad1Herc3 = getObjectId("Missiongroup\\squad1Herc3");   
   $squad2Herc1 = getObjectId("Missiongroup\\squad2Herc1");
   $squad2Herc2 = getObjectId("Missiongroup\\squad2Herc2");
   $squad2Herc3 = getObjectId("Missiongroup\\squad2Herc3");
   $squad3Herc1 = getObjectId("Missiongroup\\squad3Herc1");
   $squad3Herc2 = getObjectId("Missiongroup\\squad3Herc2");
   $squad3Herc3 = getObjectId("Missiongroup\\squad3Herc3");
   $squad4Herc1 = getObjectId("Missiongroup\\squad4Herc1");
   $squad4Herc2 = getObjectId("Missiongroup\\squad4Herc2");
   $squad4Herc3 = getObjectId("Missiongroup\\squad4Herc3");
   $squad1path = "Missiongroup/squad1path";
   $squad2path = "Missiongroup/squad2path";
   $squad3path = "Missiongroup/squad3path";
   $squad4path = "Missiongroup/squad4path";
   $TechPath = "Missiongroup/TechPath";
   $TechStop = getObjectId("Missiongroup\\TechPath\\TechStop");
   setVehicleRadarVisible($Technician, false);
   setVehicleRadarVisible($squad1Herc1, false);
   setVehicleRadarVisible($squad1Herc2, false);
   setVehicleRadarVisible($squad1Herc3, false);
   setVehicleRadarVisible($squad2Herc1, false);
   setVehicleRadarVisible($squad2Herc2, false);
   setVehicleRadarVisible($squad2Herc3, false);
   setVehicleRadarVisible($squad3Herc1, false);
   setVehicleRadarVisible($squad3Herc2, false);
   setVehicleRadarVisible($squad3Herc3, false);
   setVehicleRadarVisible($squad4Herc1, false);
   setVehicleRadarVisible($squad4Herc2, false);
   setVehicleRadarVisible($squad4Herc3, false);
}

function player::onAdd(%player)
{
   say(%player, 0, "Mission 3: Rescue Technician. During a routine patrol mission, one of our squads encountered heavy cybrid resistance. LT Carter [IMP/KN/E17], the sole survivor, is a critical herc technican. Although severely damaged, she managed to escape. She is now trapped in a heavily cybrid infested area. Recently, we recieved a distress signal from her, giving her coordinates. Your mission is to locate LT Carter and escort her safely back to base.");
   %player.status = "Waiting";
   %player.vehicle = "N/A";
   %player.reload = true;
   %player.late = true;
   %player.nav = "alpha";
}

function onMissionLoad()
{
   cdAudioCycle("Cyberntx", "CloudBurst", "Terror");
   setGameInfo("<F2>GAME TYPE:<F0>  MIB Multiplayer Campaign\n\n<F2>MISSION:<F0>  Mission 3: Rescue Technician\n\n<F2>MISSION CREATOR:<F0>  Com. Sentinal [M.I.B.]\n\n<F2>BRIEFING:<F0>\n\nDuring a routine patrol mission, one of our squads encountered heavy cybrid resistance. Only one of the pilots survived, LT Carter [IMP/KN/E17], a critical herc technican. Although her HERC was severely damaged, she managed to escape. Unfortunately, she is now trapped in a heavily cybrid infested area. Recently, we recieved a distress signal from LT Carter, giving her exact coordinates. She has remained cloaked to avoid the cybrid squads roaming the area, but she is rapidly losing power in her HERC. Your mission is to locate LT Carter and escort her safely back to base.\n\n<f3>TIP: Each player has 1 emergency reload per mission. Scan another vehicle to use it at any time during the mission.<F0>\n\n<F2>DOWNLOAD INFO:<F0>\n\nYou can download the entire MIB Multiplayer Campaign in the \"MIB Map Packs\" on the MIB Website at www.starsiegemeninblack.cjb.net.");
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      %player.status = "Waiting";
      %player.late = true;
      %player.nav = "alpha";
   }
   $currentActivePlayers = "N/A";
   if($missionLoaded == false)
   {
      $missionLoaded = true;
      say("Everybody", 0, "Mission 3: Rescue Technician. During a routine patrol mission, one of our squads encountered heavy cybrid resistance. LT Carter [IMP/KN/E17], the sole survivor, is a critical herc technican. Although severely damaged, she managed to escape. She is now trapped in a heavily cybrid infested area. Recently, we recieved a distress signal from her, giving her coordinates. Your mission is to locate LT Carter and escort her safely back to base.");
   }
}

function vehicle::onAdd(%vehicleId)
{
   %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
   if(%player != 0)
   {
      %player.late = true;
      %player.reload = false;
      if((getTeam(%vehicleId)!=*IDSTR_TEAM_YELLOW)&&(%player!=0))
      {
         setTeam(%vehicleId, *IDSTR_TEAM_YELLOW);
      }
      if($missionStarted==true)
      {
         schedule("healObject(" @ %vehicleId @ ", -50000);", 1);
         messageBox(%player, "You cannot join a game in progress. Please wait until the mission is over to join.");
      }
      else if($missionStarted==false)
      {
         %player.late = false;
         %player.status = "Alive";
         %player.vehicle = getVehicleName(%vehicleId);
      }
      %vehicleId.backAtBase = false;
   }
}

function dropZoneWarning::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if(%player != 0)
   {
      if($missionStarted == false)
      {
         say(%player, 1, "<F5>WARNING: Exiting the drop zone will start the mission.");
      }
      if($rescue == true)
      {
         if(%object.backAtBase == false)
         {
            %object.backAtBase = true;
            $playersBackAtBase++;
            if($playersBackAtBase >= $currentActivePlayers)
            {
               if($successLock == false)
               {
                  $successLock = true;
                  setFlybyCamera(%object, -50, 50, 50);
                  missionSuccessful();
               }
            }
         }
      }
   }
}

function exitDropZone::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($missionStarted==false))
   {
      $missionStarted = true;
      startMessage();
   }
}

function startMessage()
{
   $playersNotLate = 0;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      if(%player.late==false)
      {
         $playersNotLate++;
      }
      %player.reload = false;
   }
   $currentActivePlayers = $playersNotLate;
   if($playersNotLate == 1)
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " player.");
   }
   else
   {
      say("Everybody", 2, "<F5>The mission will begin with " @ $playersNotLate @ " players.");
   }
   setNavBravo();
}

function setNavBravo()
{
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      setNavMarker($navAlpha, false, %vehicleId); 
      setNavMarker($navDelta, false, %vehicleId); 
      setNavMarker($navEcho, false, %vehicleId); 
      setNavMarker($navFoxtrot, false, %vehicleId); 
      setNavMarker($navBravo, true, %vehicleId);
      %player.nav = "bravo";
   }
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: During a routine patrol mission, one of our squads encountered heavy cybrid resistance. Only one of the pilots survived, LT Carter [IMP/KN/E17], a critical herc technican.\");", 5);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: Although her herc was severely damaged, she managed to escape. Unfortunately, she is now trapped in a heavily cybrid infested area.\");", 12);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: Recently, we recieved a distress signal from LT Carter, giving her exact coordinates. She has remained cloaked to avoid the cybrid squads roaming the area, but she is rapidly losing power in her herc.\");", 19);
   schedule("say(\"Everybody\", 2, \"<F4>TAC-COM: Your mission is to locate LT Carter and escort her safely back to base.\");", 26);
}

function squad1::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad1Activated == false))
   {
      $squad1Activated = true;
      setVehicleRadarVisible($squad1Herc1, true);
      setVehicleRadarVisible($squad1Herc2, true);
      setVehicleRadarVisible($squad1Herc3, true);
      setPosition($squad1Herc1, 1208, 2085, 486);
      setPosition($squad1Herc2, 1259, 2129, 476);
      setPosition($squad1Herc3, 1302, 2158, 483);
      order($squad1Herc1, speed, high);
      order($squad1Herc2, speed, high);
      order($squad1Herc3, speed, high);
      order($squad1Herc1, guard, $squad1Path);
      order($squad1Herc2, guard, $squad1Path);
      order($squad1Herc3, guard, $squad1Path);
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 5))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 5)
      {
         %extraHercs = 5;
      }
      %x1 = 2302;
      %y1 = 2540;
      %x2 = 717;
      %y2 = 1366;
      $currentPath = $squad1Path;
      %dropInterval = 5;
      %speed = "high";
      %order = "guard";
      %radar = "big";
      dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar);
   }
}

function squad2::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad2Activated == false))
   {
      $squad2Activated = true;
      schedule("squad2Taunts();", 3);
      setVehicleRadarVisible($squad2Herc1, true);
      setVehicleRadarVisible($squad2Herc2, true);
      setVehicleRadarVisible($squad2Herc3, true);
      dropPod(868, 3702, (290 + 1000), 868, 3702, 290, $squad2Herc1);
      schedule("dropPod(922, 3698, (283 + 1000), 922, 3698, 283, $squad2Herc2);", 3);
      schedule("dropPod(1084, 3676, (274 + 1000), 1084, 3676, 274, $squad2Herc3);", 6);
      order($squad2Herc1, guard, $squad2Path);
      order($squad2Herc2, guard, $squad2Path);
      order($squad2Herc3, guard, $squad2Path);
      order($squad2Herc1, speed, high);
      order($squad2Herc2, speed, high);
      order($squad2Herc3, speed, high);
      if($currentActivePlayers == 1)
      {
         %extraHercs = 0;
      }
      else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 6))
      {
         %extraHercs = $currentActivePlayers;
      }
      else if($currentActivePlayers > 6)
      {
         %extraHercs = 6;
      }
      %x1 = 907;
      %y1 = 3433;
      %x2 = -126;
      %y2 = 3174;
      $currentPath = $squad2Path;
      %dropInterval = 5;
      %speed = "high";
      %order = "guard";
      %radar = "normal";
      dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar);
   }
}

function squad3()
{
   setVehicleRadarVisible($squad3Herc1, true);
   setVehicleRadarVisible($squad3Herc2, true);
   setVehicleRadarVisible($squad3Herc3, true);
   dropPod(-1534, 2051, (426 + 1000), -1534, 2051, 426, $squad3Herc1);
   schedule("dropPod(-1096, 934, (500 + 1000), -1096, 934, 500, $squad3Herc2);", 3);
   schedule("dropPod(50, 405, (584 + 1000), 50, 405, 584, $squad3Herc3);", 6);
   order($squad3Herc1, speed, high);
   order($squad3Herc2, speed, high);
   order($squad3Herc3, speed, high);
   order($squad3Herc1, guard, $squad3Path);
   order($squad3Herc2, guard, $squad3Path);
   order($squad3Herc3, guard, $squad3Path);
   if($currentActivePlayers == 1)
   {
      %extraHercs = 0;
   }
   else if(($currentActivePlayers > 1)&&($currentActivePlayers <= 7))
   {
      %extraHercs = $currentActivePlayers;
   }
   else if($currentActivePlayers > 7)
   {
      %extraHercs = 7;
   }
   %x1 = 602;
   %y1 = 1915;
   %x2 = -1668;
   %y2 = 1108;
   $currentPath = $squad3Path;
   %dropInterval = 5;
   %speed = "high";
   %order = "guard";
   %radar = "big";
   schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", 20);
}

function squad4::trigger::onEnter(%this, %object)
{
   %player = playerManager::vehicleIdToPlayerNum(%object);
   if((%player != 0)&&($squad4Activated == false)&&($foxtrot == true))
   {
      $squad4Activated = true;
      setVehicleRadarVisible($squad4Herc1, true);
      setVehicleRadarVisible($squad4Herc2, true);
      setVehicleRadarVisible($squad4Herc3, true);
      setPosition($squad4Herc1, 2088, 1170, 462);
      setPosition($squad4Herc2, 2138, 1199, 471);
      setPosition($squad4Herc3, 2032, 1127, 445);
      order($squad4Herc1, guard, $squad4Path);
      order($squad4Herc2, guard, $squad4Path);
      order($squad4Herc3, guard, $squad4Path);
      order($squad4Herc1, speed, high);
      order($squad4Herc2, speed, high);
      order($squad4Herc3, speed, high);
   }
}

function dropExtraCybrids(%extraHercs, %x1, %y1, %x2, %y2, %dropInterval, %speed, %order, %radar)
{
   if(%extraHercs > 0)
   {
      %extraHercs--;
      randomCybVeh();
      %herc = newObject("extraHerc", $vehType, $vehId);
      setPosition(%herc, 10000, 10000, -500);
      addToSet($AIhercs, %herc);
      setTeam(%herc, *IDSTR_TEAM_RED);
      if(%radar == "big")
      {
         setPilotId(%herc, 28);
      }
      else if(%radar == "small")
      {
         setPilotId(%herc, 29);
      }
      if(%x1 < %x2)
      {
         %x = randomInt(%x1, %x2);
      }
      else if(%x1 > %x2)
      {
         %x = randomInt(%x2, %x1);
      }
      else
      {
         %x = %x1;
      }
      if(%y1 < %y2)
      {
         %y = randomInt(%y1, %y2);
      }
      else if(%y1 > %y2)
      {
         %y = randomInt(%y2, %y1);
      }
      else
      {
         %y = %y1;
      }
      %z = getTerrainHeight(%x, %y);
      dropPod(%x, %y, (%z + 1000), %x, %y, %z, %herc);
      if(%order == "guard")
      {
         order(%herc, guard, $currentPath);
      }
      else if(%order == "attack")
      {
         order(%herc, attack, $currentPath);
      }
      if(%speed == "high")
      {
         order(%herc, speed, high);
      }
      schedule("dropExtraCybrids(" @ %extraHercs @ ", " @ %x1 @ ", " @ %y1 @ ", " @ %x2 @ ", " @ %y2 @ ", " @ %dropInterval @ ", " @ %speed @ ", " @ %order @ ", " @ %radar @ ");", %dropInterval);
   }
}

function randomCybVeh()
{
   %type = randomInt(0,13);
   if(%type==0)
   {
      $vehId = 20;
      $vehType = "herc";
   }
   else if(%type==1)
   {
      $vehId = 21;
      $vehType = "herc";
   }
   else if(%type==2)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==3)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==4)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==5)
   {
      $vehId = 25;
      $vehType = "tank";
   }
   else if(%type==6)
   {
      $vehId = 26;
      $vehType = "tank";
   }
   else if(%type==7)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==8)
   {
      $vehId = 28;
      $vehType = "herc";
   }
   else if(%type==9)
   {
      $vehId = 22;
      $vehType = "herc";
   }
   else if(%type==10)
   {
      $vehId = 23;
      $vehType = "herc";
   }
   else if(%type==11)
   {
      $vehId = 24;
      $vehType = "herc";
   }
   else if(%type==12)
   {
      $vehId = 27;
      $vehType = "herc";
   }
   else if(%type==13)
   {
      $vehId = 28;
      $vehType = "herc";
   }
}

function vehicle::onDestroyed(%destroyed, %destroyer)
{
   %player1 = playerManager::vehicleIdToPlayerNum(%destroyed);
   %player2 = playerManager::vehicleIdToPlayerNum(%destroyer);
   if(%player1 == 0)
   {
      schedule("deleteObject(" @ %destroyed @ ");", 5);
   }
   else
   {
      if($missionStarted == true)
      {
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            reloadObject(%vehicleId, 10000);
         }
         if(%player1.late == false)
         {
            %player1.late = true;
            %player1.status = "Dead";
            $currentActivePlayers--;
            checkForPlayersDead();
            if(($playersBackAtBase >= $currentActivePlayers)&&($playersBackAtBase > 0))
            {
               missionSuccessful();
            }
         }
      }
      else
      {
         %player1.late = true;
         %player1.status = "Waiting";
      }
   }
   if(%player2 != 0)
   {
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      healObject(%destroyer, 50000);
      reloadObject(%destroyer, 10000);
   }
   
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   // this is weird but %destroyer isn't necessarily a vehicle
   %message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }
   
   // enforce the rules
   if($server::TeamPlay == true)
   {
      if((getTeam(%destroyed) == getTeam(%destroyer)) && (%destroyed != %destroyer))
      {
         antiTeamKill(%destroyer);
      }
   }   
}

function technician::vehicle::onDestroyed(%destroyed, %destroyer)
{
   say("Everybody", 1, "<F5>LT Carter [IMP/KN/E17]: AAAAAAHHHHH!!!!!!", "F3_Riana_aaaargh.WAV");
   schedule("say(\"Everybody\", 1, \"<F5>The technician has been killed!\");", 3);
   schedule("missionFailed();", 6);
}

function technician::vehicle::onArrived(%vehicleId, %where)
{
   reloadObject($Technician, 99999);
   if(%where == $TechStop)
   {
      $rescue = true;
      say("Everybody", 1, "<F4>TAC-COM: The technician has safely reached the base.", "GEN_OC01.wav");
      order($Technician, clear);
      setPilotId($Technician, 31);
      order($Technican, guard, $TechStop);
   }
}

function cloak::trigger::onEnter(%this, %object)
{
   if($cloak == false)
   {
      $cloak = true;
      say("Everybody", 1, "<F4>TAC-COM: The technician is cloaked because of the heavy cybrid presence in this area. Get in there, and get out fast.");
      setTeam($Technician, *IDSTR_TEAM_YELLOW);
      healObject($Technician, -13000);
      order($Technician, cloak, true);
   }
}

function vehicle::onAttacked(%attacked, %attacker)
{
   if((%attacked == $Technician)&&($reload == false))
   {
      $reload = true;
      reloadObject($Technician, 99999);
      schedule("$reload = false;", 10);
   }
   if((%attacked == $Technician)&&(getTeam(%attacker) != *IDSTR_TEAM_YELLOW)&&($rescue == true))
   {
      if($turretDelay == false)
      {
         $turretDelay = true;
         order($turret1, attack, %attacker);
         order($turret2, attack, %attacker);
         schedule("$turretDelay = false;", 10);
      }
   }
}

function bravo::trigger::onEnter(%this, %object)
{  
   %player1 = playerManager::vehicleIdToPlayerNum(%object);
   if(%player1 != 0)
   {
      if(($bravo == false)&&($foxtrot == false))
      {
         $bravo = true;
         playSound(0, "Navpoint.wav", IDPRF_2D);
         schedule("say(\"Everybody\", 1, \"<F5>TAC-COM: Proceed to nav Delta.\");", 3);
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            setNavMarker($navAlpha, false, %vehicleId); 
            setNavMarker($navBravo, false, %vehicleId);
            setNavMarker($navEcho, false, %vehicleId); 
            setNavMarker($navFoxtrot, false, %vehicleId); 
            setNavMarker($navDelta, true, %vehicleId); 
            %player1.nav = "delta";
         }
      }
      else if($foxtrot == true)
      {
         if(%player1.nav == "bravo")
         {
            %player1.nav = "alpha";
            playSound(%player1, "Navpoint.wav", IDPRF_2D);
            //setNavMarker($navBravo, false, %object);
            //setNavMarker($navDelta, false, %object);  
            //setNavMarker($navEcho, false, %object);
            //setNavMarker($navFoxtrot, false, %object); 
            setNavMarker($navAlpha, true, %object); 
         }
      }
   }
}

function delta::trigger::onEnter(%this, %object)
{  
   %player1 = playerManager::vehicleIdToPlayerNum(%object);
   if(%player1 != 0)
   {
      if(($delta == false)&&($foxtrot == false))
      {
         $delta = true;
         playSound(0, "Navpoint.wav", IDPRF_2D);
         schedule("say(\"Everybody\", 1, \"<F5>TAC-COM: Proceed to nav Echo.\");", 3);
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            setNavMarker($navAlpha, false, %vehicleId); 
            setNavMarker($navBravo, false, %vehicleId);
            setNavMarker($navDelta, false, %vehicleId); 
            setNavMarker($navFoxtrot, false, %vehicleId); 
            setNavMarker($navEcho, true, %vehicleId);
            %player1.nav = "echo";
         }
      }
      else if($foxtrot == true)
      {
         if(%player1.nav == "delta")
         {
            %player1.nav = "bravo";
            playSound(%player1, "Navpoint.wav", IDPRF_2D);
            //setNavMarker($navAlpha, false, %object); 
            //setNavMarker($navDelta, false, %object);  
            //setNavMarker($navEcho, false, %object);
            //setNavMarker($navFoxtrot, false, %object); 
            setNavMarker($navBravo, true, %object);
         }
      }
   }
}

function echo::trigger::onEnter(%this, %object)
{  
   %player1 = playerManager::vehicleIdToPlayerNum(%object);
   if(%player1 != 0)
   {
      if(($echo == false)&&($foxtrot == false))
      {
         $echo = true;
         playSound(0, "Navpoint.wav", IDPRF_2D);
         schedule("say(\"Everybody\", 1, \"<F5>TAC-COM: Proceed to nav Foxtrot.\");", 3);
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);
            setNavMarker($navAlpha, false, %vehicleId); 
            setNavMarker($navBravo, false, %vehicleId);
            setNavMarker($navDelta, false, %vehicleId); 
            setNavMarker($navEcho, false, %vehicleId); 
            setNavMarker($navFoxtrot, true, %vehicleId); 
            %player1.nav = "foxtrot";
         }
      }
      else if($foxtrot == true)
      {
         if(%player1.nav == "echo")
         {
            %player1.nav = "delta";
            playSound(%player1, "Navpoint.wav", IDPRF_2D);
            //setNavMarker($navAlpha, false, %object); 
            //setNavMarker($navBravo, false, %object);
            //setNavMarker($navEcho, false, %object);
            //setNavMarker($navFoxtrot, false, %object); 
            setNavMarker($navDelta, true, %object);  
         }
      }
   }
}

function foxtrot::trigger::onEnter(%this, %object)
{  
   %player1 = playerManager::vehicleIdToPlayerNum(%object);
   if(%player1 != 0)
   {
      if($foxtrot == false)
      {
         $foxtrot = true;
         schedule("order($Technician, cloak, false);", 5);
         setVehicleRadarVisible($Technician, true);
         schedule("say(\"Everybody\", 1, \"<F5>LT Carter [IMP/KN/E17]: Thank God you're here. I've been stranded in this area for some time. My herc is damaged, and I have orders to head back to base under your escort.\");", 6);
         schedule("say(\"Everybody\", 1, \"<F5>LT Carter [IMP/KN/E17]: We must hurry, this place is infested with cybrids. There's no telling when they might strike.\");", 12);
         %count = playerManager::getPlayerCount();
         for(%i = 0; %i < %count; %i++)
         {
            %player = playerManager::getPlayerNum(%i);
            %vehicleId = playerManager::playerNumToVehicleId(%player);      
            //setNavMarker($navAlpha, false, %vehicleId); 
            //setNavMarker($navBravo, false, %vehicleId);
            //setNavMarker($navDelta, false, %vehicleId); 
            //setNavMarker($navFoxtrot, false, %vehicleId); 
            setNavMarker($navEcho, true, %vehicleId);
            %player1.nav = "echo";
         }
         schedule("order($Technician, guard, $TechPath);", 15);
         schedule("order($Technician, speed, high);", 16);
         schedule("squad3();", 16);
      }
   }
}

function squad2Taunts()
{
   playSound(0, "C1_hurtmaimkill.wav", IDPRF_2D);
   schedule("playSound(0, \"C4_eliminateanimals.wav\", IDPRF_2D);", 4);
}

function vehicle::onScan(%scanned, %scanner)
{
   %player = playerManager::vehicleIdToPlayerNum(%scanner);
   if(%player.reload == false)
   {
      %player.reload = true;
      reloadObject(%scanner, 99999);
      say(%player, %player, "<F5>Emergency reload initiated.");
   }
}

function checkForPlayersDead()
{
   %allDead = true;
   %count = playerManager::getPlayerCount();
   for(%i = 0; %i < %count; %i++)
   {
      %player = playerManager::getPlayerNum(%i);
      %vehicleId = playerManager::playerNumToVehicleId(%player);
      if((%vehicleId != "") && (isGroupDestroyed(%vehicleId) == false))
      {
         %allDead = false;
      }
   }
   if(%allDead == true)
   {
      schedule("missionFailed();", 3);
   }
}

function missionSuccessful()
{
   flushConsoleScheduler();
   playSound(0, "Mission_comp.wav", IDPRF_2D);
   messageBox(0, "Mission Successful");
   if($cycleMissions == true)
   {
      $MissionCycling::Stage0 = "New_Technology";
      $server::Mission = $MissionCycling::Stage0;
   }
   schedule("missionEndConditionMet();", 10);
}

function missionFailed()
{  
   if($successLock == false)
   {
      flushConsoleScheduler();
      playSound(0, "Mission_fail.wav", IDPRF_2D);
      messageBox(0, "Mission Failed");
      if($cycleMissions == true)
      {
         $MissionCycling::Stage0 = "New_Technology";
         $server::Mission = $MissionCycling::Stage0;
      }
      schedule("missionEndConditionMet();", 5);
   }
}

function onMissionEnd()
{
   deleteObject($AIhercs);
}

function getPlayerStatus(%player)
{
   return(%player.status);
}

function getActivePlayers()
{
   return($currentActivePlayers);
}

function getPlayerVehicle(%player)
{
   return(%player.vehicle);
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

   if($server::TeamPlay == "True")	
   {
	   // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
         $ScoreBoard::PlayerColumnHeader4 = "Vehicle";


	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
         $ScoreBoard::PlayerColumnFunction4 = "getPlayerVehicle";
   }
   else
   {
       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = "Current Status";
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getPlayerStatus";
	   $ScoreBoard::PlayerColumnFunction3 = "getKills";
   }

   // Team ScoreBoard column headings
   $ScoreBoard::TeamColumnHeader1 = *IDMULT_SCORE_SCORE;
   $ScoreBoard::TeamColumnHeader2 = "Players Remaining";
   $ScoreBoard::TeamColumnHeader3 = *IDMULT_SCORE_KILLS;

   // Team ScoreBoard column functions
   $ScoreBoard::TeamColumnFunction1 = "getTeamScore";
   $ScoreBoard::TeamColumnFunction2 = "getActivePlayers";
   $ScoreBoard::TeamColumnFunction3 = "getTeamKills";

   // tell server to process all the scoreboard definitions defined above
   serverInitScoreBoard();
}
