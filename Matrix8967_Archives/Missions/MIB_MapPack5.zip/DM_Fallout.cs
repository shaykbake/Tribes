// FILENAME:	DM_Fallout.cs
//
// AUTHOR:  	M@J M@X D@M@Ge [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Fallout";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
   marsSounds();
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to DeathMatch Fallout! You can download this & other missions made by M@J M@X D@M@Ge [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}