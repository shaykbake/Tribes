// FILENAME:	DM_Snow_Blind.cs
//
// AUTHOR:  	Com. Sentinal [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Snow_Blind";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	iceSounds();
      $lock = false;
      $turret1 = getObjectId("MissionGroup\\turret1");
      $turret2 = getObjectId("MissionGroup\\turret2");
      $turret3 = getObjectId("MissionGroup\\turret3");
      $turret4 = getObjectId("MissionGroup\\turret4");
      $turret5 = getObjectId("MissionGroup\\turret5");
      $turret6 = getObjectId("MissionGroup\\turret6");
      $turret7 = getObjectId("MissionGroup\\turret7");
      $turret8 = getObjectId("MissionGroup\\turret8");
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DeathMatch Snow Blind! You can download this & other missions made by Com. Sentinal [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function vehicle::onAdd(%vehicleId)
{
   if(($lock==false)&&($server::TeamPlay == false))
   {
      deActivateTurrets();
   }
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
}

function deActivateTurrets()
{  
   $lock = true;
   setTeam($turret1, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret2, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret3, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret4, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret5, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret6, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret7, *IDSTR_TEAM_NEUTRAL);
   setTeam($turret8, *IDSTR_TEAM_NEUTRAL);
   order($turret1, shutdown, true);
   order($turret2, shutdown, true);
   order($turret3, shutdown, true);
   order($turret4, shutdown, true);
   order($turret5, shutdown, true);
   order($turret6, shutdown, true);
   order($turret7, shutdown, true);
   order($turret8, shutdown, true);
}

//Explosives....handle with care
//------------------------------------------------------------------------------
function box1::structure::onDestroyed(%destroyed, %destroyer)
{
   blast(%destroyer, 200, 5000);
}

function box2::structure::onDestroyed(%destroyed, %destroyer)
{
   blast(%destroyer, 200, 5000);
}

function box3::structure::onDestroyed(%destroyed, %destroyer)
{
   blast(%destroyer, 200, 5000);
}

function box4::structure::onDestroyed(%destroyed, %destroyer)
{
   blast(%destroyer, 200, 5000);
}
