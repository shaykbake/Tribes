// FILENAME:    DM_Deathmatch.cs 
//
// AUTHOR:      Maj. Stormtrooper [M.I.B.]
//
// RANDOM COMMANDS:
// playSound( id, soundName, soundProfile, {,object or (x,y,z position) } );
// ban(playerId, minutes, < reason > );
//--------------------------------------------------------------------------------

$missionName = "DM_DeathMatch";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	meteorSounds();
      avalancheSounds();
}

function player::onAdd(%player)
{
   say(%player, 0, "Welcome to DeathMatch \"DEATHMATCH\"! You can download this & other missions made by Maj. Stormtrooper [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
   messagebox(%player, "I sez how are you doing?");
   messagebox(%player, "In this map, if u fall off, you have to use a teleporter to get back up.");
   messagebox(%player, "So be warned, and please don't stay on the ground =p");
}

function onMissionLoad()
{
   cdAudioCycle("Yougot", "Newtech", "Mechsoul");
}

function ranport::trigger::onContact(%trigger, %vehicleId)
{
    %player = playerManager::vehicleIdToPlayerNum(%vehicleId);
    fadeEvent(%player, out, 1, 1, 0, 0);
    playSound(%player, "sfx_fog.wav", IDPRF_2D);
    reDrop(%vehicleId);
    fadeEvent(%player, in, 1, 1, 0, 0); 
}
