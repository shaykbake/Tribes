// Generic Harvester Map "Harv_Desolate"
// Intended as a template should someone want to make more...
// ][)ull 2-23-1
//========================
// **Note on supply dumps**
// In addition to the things described below, you will need supply dumps for each team. The supply dump is a trigger at
// which player's drop off their ore. The scriptclass of a supply dump *must* be "supplyDump". The object name *must*
// be the first letter of the team color then dump (meaning RDump or BDump for Red team and Blue team respectivly).
// Any other characters can follow, the first 5 are the important ones. 
// For a team to be team-inspecifice it can have any other name besides RDump or BDump.
//========================

// Execute any other scripts first. I don't have any on this map.

function setHarvestVariables()
{

$Planet = "Mars"; 
 // Choices: "Mars" "Europa" "Snow" "Moon" "Mercury" "Titan" "Venus" "Pluto" 
 // -- ok, so not all of them are planets, but this **HAS** to match the planet of your map **OR SS WILL CRASH**
 // If you don't know, leave it undefined and it will use trees instead of rocks.

$orePatches = 2;  //Number of ore patches (triggers with the script class 'OrePatch')

$OreZones = 1; //Number of rectangles in which ore can be spawned (x/y min/max)
$Xlow[1] = -690; //Range in which the ore patch can be spawned (randomly moved to) -- Start with one, go up to $OreZones
$Xhigh[1] = 1000; 
$Ylow[1] = -255;
$Yhigh[1] = 770;

$BlueMarkers = 1; // Number of Blue bases
$RedMarkers = 1; // Number of Red bases

  // Need one for each base that you can build around. Start with 1, go up till the last one is the same as $(team)Markers
$BlueMarker[1] = getObjectId("MissionGroup\\BaseMarkers\\bluenav1"); 
$RedMarker[1] = getObjectId("MissionGroup\\BaseMarkers\\rednav1"); 

$BlueRadius[1] = 700; // Distance away something can be built from $BlueMarker[#]... small for a small base, 
$RedRadius[1] = 700;    // big for a big base. There must be one for each $TeamMarker[#].

$NewBaseRadius = 300; // Distance from base extenders that something can be built.

// Target Buildings that need to be destroyed to win
// Their team's can't be nutral, must match

$Targets[*IDSTR_TEAM_RED] = 5;  // Mission Objectives, building with scriptclass "target"
$Targets[*IDSTR_TEAM_BLUE] = 5;


 // These need to be defined once per ore patch, incresing [number] by one,
 // starting with 1 and going up. Last number should be the same as the number of patches.

$orePatch[1] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger1");     // The trigger
$orePatch[1].size = 100;                    // Should correspond to the size of the trigger (un-check: "[ ] is sphere" in F2 window for best results) 
$orePatch[1].maxOre = 700;                 // Value of ore that can be extracted from it
$orePatch[1].maxRocks = 7;                 // Number of rocks to put in it


$orePatch[2] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger2");
$orePatch[2].size = 100;
$orePatch[2].maxOre = 700;
$orePatch[2].maxRocks = 7;


// Nuke Variables (Nuke script from Sentinal M.I.B.'s DM_Nuclear_Fallout at his suggestion)
// More Info about variables to be added...

$SiloDTS[*IDSTR_TEAM_BLUE] = "hmoonrefinery.dts";
$SiloDTS[*IDSTR_TEAM_RED] = "hmoonrefinery.dts";

$Silo[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\BLUE\\nukeBuilder");
$Silo[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\RED\\nukeBuilder");

$SiloX[*IDSTR_TEAM_BLUE] = -307.7;
$SiloY[*IDSTR_TEAM_BLUE] = -506.2;
$SiloZ[*IDSTR_TEAM_BLUE] = 100;
$SiloZRot[*IDSTR_TEAM_BLUE] = 180;
$SiloXRot[*IDSTR_TEAM_BLUE] = 0;

$SiloX[*IDSTR_TEAM_RED] = -285.3;
$SiloY[*IDSTR_TEAM_RED] = 1029.6;
$SiloZ[*IDSTR_TEAM_RED] = 100;
$SiloZRot[*IDSTR_TEAM_RED] = 0;
$SiloXRot[*IDSTR_TEAM_RED] = 0;

 //Shrike Missile Husks for the bombs
$Bomb[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\blueBomb");
$Bomb[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\redBomb");

focusServer();
 //Waypoints (Put them where they are placed in this map in relation to the bases)
$Waypoints[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup/blueWaypoints");
$Waypoints[*IDSTR_TEAM_RED] = getObjectId("Missiongroup/redWaypoints");
$Waypoint[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup/blueWaypoints/Waypoint1");
$Waypoint[*IDSTR_TEAM_RED] = getObjectId("Missiongroup/redWaypoints/Waypoint1");
$Waypoint2[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup/blueWaypoints/Waypoint2");
$Waypoint2[*IDSTR_TEAM_RED] = getObjectId("Missiongroup/redWaypoints/Waypoint2");
unfocus();
   
 //PodExplosion Animations (Buzzbum MOD - FX Shapes)
$Explosion[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\blueExplosion");
$Explosion[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\redExplosion");
   
 //Thumper Animations (Buzzbum MOD - FX Shapes)
$Shockwave[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\blueShock");
$Shockwave[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\redShock");

// Starting Point for the dracos. Atop a launchpad or whatever.
$DracoX[*IDSTR_TEAM_BLUE] = -311.6;
$DracoY[*IDSTR_TEAM_BLUE] = -444.4;
$DracoZ[*IDSTR_TEAM_BLUE] = 125;
$DracoX[*IDSTR_TEAM_RED] = -282.3;
$DracoY[*IDSTR_TEAM_RED] = -967.2;
$DracoZ[*IDSTR_TEAM_RED] = 125;

}


// Functions available to map makers if they want to add stuff to functions already used.
// They are called at the end of the function they are named for and can be used in the same way.
// If a function is not here it is unused EXCEPT vehicle::onScan which I think already has too much in it
// and therefroe didn't include. Anything else can be defined however you want.
// NOTE: These don't need to have anything in them, it is compltely optional. Delete them if you wish.
// Another NOTE: If you do use them, they must be defined *before* calling the library


function HarvVehicleOnDestroyed(%destroyed, %destroyer)
{ }

function HarvVehicleOnAdd(%vehicle)
{ }

function HarvOnMissionLoad()
{ }

function HarvPlayerOnAdd(%player)
{ }

function HarvPlayerOnRemove(%player)
{ }

function HarvVehicleOnMessage(%a, %b, %c, %d, %e, %f, %g, %h)
{ }

function HarvTurretOnDestroyed(%turret, %veh)
{ }

function HarvOnMissionStart() // If you want to over-ride a cost for a vehicle, define the new value here
{ }



$MapVersion = "ver1.000 - 2-23-1"; // This, $MapBy, and $AdditionalRules should be defined before executing the StdLib
$MapBy = "<F4>Harv_Desolate by dull@ss-harvester.com"; // Map-Maker can put any contact info or whatever here
$AdditionalRules = ""; // Put any other stuff you want added to the rules here... limited space...

exec("Harvest_StdLib.cs");

$missionName = "Desolate-" @ $HarvStdLibVer; // Only thing you put after executing the StdLib other than your personal functions
