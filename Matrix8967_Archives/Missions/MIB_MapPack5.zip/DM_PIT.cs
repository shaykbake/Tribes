// FILENAME:	DM_Pit.cs
//
// AUTHORS:  	Gen. Deathrow [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "The Pit";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	

   // what can the client choose for a team
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

   // what can the server admin choose for available teams
   $server::disableTeamRed = false;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = true;
}

function onMissionStart()
{
	marsSounds();
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to Pit DeathMatch! Scan a vehicle to check out his specs. You can download this & other missions made by Gen. Deathrow [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.","F6_DWish_lookitthatl.WAV");
}


function vehicle::onAdd(%this)
{
say(%player, 0, " ", "M7_lookingforblood.wav");
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching"); 
}

function vehicle::onScan(%this, %object, %string)
{
  %player = playerManager::vehicleIdToPlayerNum(%object);

  %componentCount = getComponentCount(%this);
  %index = 0;
  while (%index < %componentCount) 
  {
    %id = getComponentId(%this, %index);
    %theName = nameStuff(%id);
	say(%player, 0, %theName);
	%index++;
  }

  %weaponCount = getWeaponCount(%this);
  %index = 0;
  while (%index < %weaponCount) 
  {
    %id = getWeaponId(%this, %index);
	%theName = nameGun(%id);
	say(%player, 0, %theName);
    %index++;
  }
}


function nameStuff(%thingie)
{
	if ((%thingie >= 100) && (%thingie <= 115))
	{
		return(nameEngineA(%thingie));
	}

	else if ((%thingie >= 128) && (%thingie <= 143))
	{
		return(nameEngineB(%thingie));
	}

	else if ((%thingie >= 200) && (%thingie <=230))
	{
		return(nameReactor(%thingie));
	}

	else if ((%thingie >= 300) && (%thingie <= 333))
	{
		return(nameShield(%thingie));
	}

	else if ((%thingie >= 400) && (%thingie <= 434))
	{
		return(nameSensor(%thingie));
	}

	else if ((%thingie >= 800) && (%thingie <= 807))
	{
		return(nameComputer(%thingie));
	}

	else if ((%thingie >= 926) && (%thingie <= 931))
	{
		return(nameArmor(%thingie));
	}

	else if ((%thingie >= 810) && (%thingie <= 914))
	{
		return(nameSpecial(%thingie));
	}

	else return("Unknown component");
}


function nameEngineA(%thingie)
{
	if(%thingie == 100)
	{
		return("Human Light Vehicle Engine");
	}
	else if(%thingie == 101)
	{
		return("Human High Output Light Engine");
	}
	else if(%thingie == 102)
	{
		return("Human Light Agility Engine");
	}
	else if(%thingie == 103)
	{
		return("Human Standard Medium Engine");
	}
	else if(%thingie == 104)
	{
		return("Human High Output Medium Engine");
	}
	else if(%thingie == 105)
	{
		return("Human Medium Agility Engine");
	}
	else if(%thingie == 106)
	{
		return("Human Standard Heavy Engine");
	}
	else if(%thingie == 107)
	{
		return("Human Improved Heavy Engine");
	}
	else if(%thingie == 108)
	{
		return("Human Heavy Cruise Engine");
	}
	else if(%thingie == 109)
	{
		return("Human High Output Heavy Engine");
	}
	else if(%thingie == 110)
	{
		return("Human Heavy Agility Engine");
	}
	else if(%thingie == 111)
	{
		return("Human Standard Assault Engine");
	}
	else if(%thingie == 112)
	{
		return("Human Improved Assault Engine");
	}
	else if(%thingie == 113)
	{
		return("Human Heavy Turbine Engine");
	}
	else if(%thingie == 114)
	{
		return("Human High Output Turbine Engine");
	}
	else if(%thingie == 115)
	{
		return("Human Super Heavy Engine");
	}
	else return("Unknown engine");
}

function nameEngineB(%thingie)
{
	if(%thingie == 128)
	{
		return("Cybrid Alpha Light Vehicle Engine");
	}
	else if(%thingie == 129)
	{
		return("Cybrid Beta Light Agility Engine");
	}
	else if(%thingie == 130)
	{
		return("Cybrid Gamma Standard Medium Engine");
	}
	else if(%thingie == 131)
	{
		return("Cybrid Delta Medium Cruise Engine");
	}
	else if(%thingie == 132)
	{
		return("Cybrid Epsilon Improved Medium Engine");
	}
	else if(%thingie == 133)
	{
		return("Cybrid Zeta Medium High Output Engine");
	}
	else if(%thingie == 134)
	{
		return("Cybrid Eta Medium Agility Engine");
	}
	else if(%thingie == 135)
	{
		return("Cybrid Theta Standard Heavy Engine");
	}
	else if(%thingie == 136)
	{
		return("Cybrid Iota Heavy High Output Engine");
	}
	else if(%thingie == 137)
	{
		return("Cybrid Kappa Heavy Agility Engine");
	}
	else if(%thingie == 138)
	{
		return("Cybrid Lambda Standard Assault Engine");
	}
	else if(%thingie == 139)
	{
		return("Cybrid Mu Improved Assault Engine");
	}
	else if(%thingie == 140)
	{
		return("Cybrid Nu High Output Assault Engine");
	}
	else if(%thingie == 141)
	{
		return("Cybrid Xi Heavy Assault Engine");
	}
	else if(%thingie == 142)
	{
		return("Cybrid Omicron Heavy Assault Turbine");
	}
	else if(%thingie == 143)
	{
		return("Cybrid Pi Super Heavy Turbine");
	}
	else return("Unknown engine");
}


function nameReactor(%thingie)
{
	if (%thingie == 200)
	{
		return("Human Micro Reactor");
	}
	else if(%thingie == 201)
	{
		return("Human Small Reactor");
	}
	else if(%thingie == 202)
	{
		return("Human Standard Reactor");
	}
	else if(%thingie == 203)
	{
		return("Human Medium Reactor");
	}
	else if(%thingie == 204)
	{
		return("Human Large Reactor");
	}
	else if(%thingie == 205)
	{
		return("Human Maxim Reactor");
	}
	else if(%thingie == 225)
	{
		return("Cybrid Alpha Reactor");
	}
	else if(%thingie == 226)
	{
		return("Cybrid Beta Reactor");
	}
	else if(%thingie == 227)
	{
		return("Cybrid Gamma Reactor");
	}
	else if(%thingie == 228)
	{
		return("Cybrid Delta Reactor");
	}
	else if(%thingie == 229)
	{
		return("Cybrid Epsilon Reactor");
	}
	else if(%thingie == 230)
	{
		return("Cybrid Theta Reactor");
	}
	else return("Unknown reactor");
}


function nameShield(%thingie)
{
	if(%thingie == 300)
	{
		return("Human Standard Shield");
	}
	else if(%thingie == 301)
	{
		return("Human Protector Shield");
	}
	else if(%thingie == 302)
	{
		return("Human Guardian Shield");
	}
	else if(%thingie == 303)
	{
		return("Human FastCharge Shield");
	}
	else if(%thingie == 304)
	{
		return("Human Centurion Shield");
	}
	else if(%thingie == 305)
	{
		return("Human Repulsor Shield");
	}
	else if(%thingie == 306)
	{
		return("Human Titan Shield");
	}
	else if(%thingie == 307)
	{
		return("Human Medusa Shield");
	}
	else if(%thingie == 326)
	{
		return("Cybrid Alpha Shield");
	}
	else if(%thingie == 327)
	{
		return("Cybrid Beta Shield");
	}
	else if(%thingie == 328)
	{
		return("Cybrid Gamma Shield");
	}
	else if(%thingie == 329)
	{
		return("Cybrid Delta Shield");
	}
	else if(%thingie == 330)
	{
		return("Cybrid Epsilon Shield");
	}
	else if(%thingie == 331)
	{
		return("Cybrid Zeta Shield");
	}
	else if(%thingie == 332)
	{
		return("Cybrid Eta Shield");
	}
	else if(%thingie == 333)
	{
		return("Cybrid Theta Shield");
	}
	else return("Unknown shield");
}



function nameSensor(%thingie)
{
	if(%thingie == 400)
	{
		return("Human Basic Sensor");
	}
	else if(%thingie == 401)
	{
		return("Human Ranger Sensor");
	}
	else if(%thingie == 408)
	{
		return("Human Standard Sensor");
	}
	else if(%thingie == 409)
	{
		return("Human Longbow Sensor");
	}
	else if(%thingie == 410)
	{
		return("Human Infiltrator Sensor");
	}
	else if(%thingie == 411)
	{
		return("Human Crossbow Sensor");
	}
	else if(%thingie == 412)
	{
		return("Human Ultralight Sensor");
	}
	else if(%thingie == 413)
	{
		return("Human Hound Dog Sensor");
	}
	else if(%thingie == 414)
	{
		return("Human Thermal Sensor");
	}
	else if(%thingie == 426)
	{
		return("Cybrid Alpha Sensor - Basic");
	}
	else if(%thingie == 427)
	{
		return("Cybrid Beta Sensor - Long Range");
	}
	else if(%thingie == 428)
	{
		return("Cybrid Gamma Sensor - Standard");
	}
	else if(%thingie == 429)
	{
		return("Cybrid Delta Sensor - Longbow");
	}
	else if(%thingie == 430)
	{
		return("Cybrid Epsilon Sensor - Infiltrator");
	}
	else if(%thingie == 431)
	{
		return("Cybrid Zeta Sensor - Crossbow");
	}
	else if(%thingie == 432)
	{
		return("Cybrid Eta Sensor - Ultralight");
	}
	else if(%thingie == 433)
	{
		return("Cybrid Theta Sensor - Hound");
	}
	else if(%thingie == 434)
	{
		return("Cybrid Iota Sensor - Motion Detector");
	}
	else return("Unknown sensor");
}





function nameArmor(%thingie)
{
	if(%thingie == 926)
	{
		return("Carbon Fiber Laminate Armor");
	}
	else if(%thingie == 927)
	{
		return("Quad Bonded Metaplas Armor");
	}
	else if(%thingie == 928)
	{
		return("Depleted Uranium Armor");
	}
	else if(%thingie == 929)
	{
		return("Ceramic Armor");
	}
	else if(%thingie == 930)
	{
		return("Crystaluminum Armor");
	}
	else if(%thingie == 931)
	{
		return("Quicksilver Armor");
	}
	else return("Unknown armor");
}



function nameComputer(%thingie)
{
	if(%thingie == 800)
	{
		return("Human Basic Computer - 166");
	}
	else if(%thingie == 801)
	{
		return("Human Improved Computer - 300");
	}
	else if(%thingie == 802)
	{
		return("Human Advanced Computer - 450");
	}
	else if(%thingie == 805)
	{
		return("Cybrid Basic Systems Control - Alpha");
	}
	else if(%thingie == 806)
	{
		return("Cybrid Enhanced Systems Control - Beta");
	}
	else if(%thingie == 807)
	{
		return("Cybrid Advanced Systems Control");
	}
	else return("Unknown computer");
}


function nameSpecial(%thingie)
{
	if(%thingie == 810)
	{
		return("Human Guardian ECM");
	}
	else if(%thingie == 811)
	{
		return("Human Doppleganger ECM");
	}
	else if(%thingie == 812)
	{
		return("Cybrid Alpha ECM");
	}
	else if(%thingie == 813)
	{
		return("Cybrid Beta ECM");
	}
	else if(%thingie == 820)
	{
		return("Thermal Diffuser");
	}
	else if(%thingie == 830)
	{
		return("Chameleon Cloak");
	}
	else if(%thingie == 831)
	{
		return("Cuttlefish Cloak");
	}
	else if(%thingie == 840)
	{
		return("Shield Modulator");
	}
	else if(%thingie == 845)
	{
		return("Shield Capaciotr");
	}
	else if(%thingie == 850)
	{
		return("Shield Amplifier");
	}
	else if(%thingie == 860)
	{
		return("Laser Targeting Module");
	}
	else if(%thingie == 865)
	{
		return("Auxiliary Power Storage Battery");
	}
	else if(%thingie == 870)
	{
		return("Reactor Capacitor");
	}
	else if(%thingie == 875)
	{
		return("Field Stabilizer");
	}
	else if(%thingie == 880)
	{
		return("Rocket Booster");
	}
	else if(%thingie == 885)
	{
		return("Turbine Booster");
	}
	else if(%thingie == 890)
	{
		return("Nanorepair");
	}
	else if(%thingie == 900)
	{
		return("Angel Life Support");
	}
	else if(%thingie == 910)
	{
		return("AntiGrav Generator");
	}
	else if(%thingie == 912)
	{
		return("Electrohull");
	}
	else if(%thingie == 914)
	{
		return("Universal Ammunition Pack");
	}
}

function nameGun(%thingie)
{
	if ((%thingie >= 1) && (%thingie <= 119))
	{
		return(nameGunA(%thingie));
	}

	else
	{
		return(nameGunB(%thingie));
	}
}


function nameGunA(%thingie)
{
	if(%thingie == 3)
	{
		return("Disrupter cannon");
	}
	else if(%thingie == 101)
	{
		return("Laser");
	}
	else if(%thingie == 102)
	{
		return("Heavy Laser");
	}
	else if(%thingie == 103)
	{
		return("Compression Laser");
	}
	else if(%thingie == 104)
	{
		return("Twin Laser");
	}
	else if(%thingie == 105)
	{
		return("Electromagnetic Pulse Cannon");
	}
	else if(%thingie == 106)
	{
		return("Electron Flux Whip");
	}
	else if(%thingie == 107)
	{
		return("Blaster");
	}
	else if(%thingie == 108)
	{
		return("Heavy Blaster");
	}
	else if(%thingie == 109)
	{
		return("Particle Beam Weapon");
	}
	else if(%thingie == 110)
	{
		return("Plasma Cannon");
	}
	else if(%thingie == 111)
	{
		return("Blink Gun");
	}
	else if(%thingie == 112)
	{
		return("Quantum Gun");
	}
	else if(%thingie == 113)
	{
		return("Magneto-Fusion Autocannon");
	}
	else if(%thingie == 114)
	{
		return("Nano-infuser");
	}
	else if(%thingie == 115)
	{
		return("Nanite Cannon");
	}
	else if(%thingie == 116)
	{
		return("Autocannon");
	}
	else if(%thingie == 117)
	{
		return("Heavy Autocannon");
	}
	else if(%thingie == 118)
	{
		return("Electro-magnetic Autocannon");
	}
	else if(%thingie == 119)
	{
		return("Blast Cannon");
	}
	else return("Unrecognized weaponry");
}

function nameGunB(%thingie)
{
	if(%thingie == 120)
	{
		return("Heavy Blast Cannon");
	}
	else if(%thingie == 121)
	{
		return("Rail Gun");
	}
	else if(%thingie == 124)
	{
		return("Pit Viper Missile 8");
	}
	else if(%thingie == 125)
	{
		return("Pit Viper Missile 12");
	}
	else if(%thingie == 126)
	{
		return("Sparrow Missile 6");
	}
	else if(%thingie == 127)
	{
		return("Sparrow Missile 10");
	}
	else if(%thingie == 128)
	{
		return("Swarm Missile 6");
	}
	else if(%thingie == 129)
	{
		return("Minion Missile");
	}
	else if(%thingie == 130)
	{
		return("Shirke Missile 8");
	}
	else if(%thingie == 131)
	{
		return("Arachnitron 4");
	}
	else if(%thingie == 132)
	{
		return("Arachnitron 8");
	}
	else if(%thingie == 133)
	{
		return("Arachnitron 12");
	}
	else if(%thingie == 134)
	{
		return("Proximity Mine 6");
	}
	else if(%thingie == 135)
	{
		return("Proximity Mine 10");
	}
	else if(%thingie == 136)
	{
		return("Proximity Mine 15");
	}
	else if(%thingie == 142)
	{
		return("Radiation Gun");
	}
	else if(%thingie == 147)
	{
		return("Aphid Missile");
	}
	else if(%thingie == 150)
	{
		return("Smart Gun");
	}
	else return("Unrecognized weaponry");
}