// FILENAME:	DM_Forts.cs
//
// AUTHORS:  	Gen. Deathrow [M.I.B.]
//------------------------------------------------------------------------------

$missionName = "DM_Forts";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = True;
	$server::AllowDeathmatch = False;
	$server::AllowTeamPlay = True;	
	
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Watching", "Mechsoul"); 
}

function onMissionStart()
{
	temperateSounds();	
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to DeathMatch SS Forts! You can download this & other missions made by Gen. Deathrow [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}



function Buddha::structure::onAttacked(%destroyed, %destroyer){
	%sayTo = playerManager::vehicleIdToPlayerNum(%destroyer);
	Say(%sayTo, %sayTo, *IDMULT_YOU_KILLED_BUDDHA);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
	healObject(%destroyer, -10000);
}

function Door1::trigger::onEnter(%this, %vehicleId){
	playAnimSequence(getObjectId("MissionGroup\\Triggers\\Door"), 0, true);
}
function Door1::trigger::onLeave(%this, %vehicleId){
	playAnimSequence(getObjectId("MissionGroup\\Triggers\\Door"), 0, false);
}

    
