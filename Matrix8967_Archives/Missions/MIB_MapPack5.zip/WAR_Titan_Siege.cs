////////////////////////////////////////////////////////////////////////////////////////////////// 
//We all know the value of victory, but few truly know defeat...
//////////////////////////////////////////////////////////////////////////////////////////////////
// on this map you will need strategy, i mean real strategy, without you
// teammates you will lose. bases have 2 perimeters... inner and outer. 
// outer has hercs and mfac turrets, inner has the bulk of your turret defenses
// and 3 gen are used just for the inner. the inner has a loopback defense, meaning its turres are powered by a generator
// that is outside the perimeter but is defended by turrets that are powerd by the generators inside the perimeter
// however once you lose the outer perimeter the inner will not last long, and
// cannot stop many enemies from coming in,- but they are strong, they just
// cannot withstand alot of enemies at once. a well organized attack will defeat an
// unorganized defense in a few minutes of play. those of you who are victorious, you will truly
// know what it is to win a REAL war, for those who lose... well... you are among a scarce few who..
// TRULY KNOW DEFEAT. Good hunting! - Maj. DarkRaven [M.I.B.]
///////////////////////////////////////////////////////////////////////////////////////////////////

$missionName = "WAR_Titan_Siege";

exec("multiplayerStdLib.cs");

$server::HudMapViewOffsetX = -6300;
$server::HudMapViewOffsetY = 2400;

///////////////////////////////////////////////////////////////////////////////////////////////////
// Lots O' Globals
///////////////////////////////////////////////////////////////////////////////////////////////////
$redKills = 0;
$yellowKills = 0;

$redBuildingsDestroyed = 0;
$yellowBuildingsDestroyed = 0;

$yellowHerc1RespawnTime = 0;
$yellowHerc2RespawnTime = 0;
$yellowHerc3RespawnTime = 0;
$yellowHerc4RespawnTime = 0;
$yellowHerc5Respawntime = 0;
$redHerc1RespawnTime = 0;
$redHerc2RespawnTime = 0;
$redHerc3RespawnTime = 0;
$redHerc4RespawnTime = 0;
$redHerc5RespawnTime = 0;

//HERC PATHS >> so i can find it ( =HG= )

$yellowHerc1Path = "MissionGroup/yellowHerc1Path";
$yellowHerc2Path = "MissionGroup/yellowHerc2Path";
$yellowHerc3Path = "MissionGroup/yellowHerc3Path";
$yellowHerc5Path = "MissionGroup/yellowHerc5Path";
$redHerc1Path = "MissionGroup/redHerc1Path";
$redHerc2Path = "MissionGroup/redHerc2Path";
$redHerc3Path = "MissionGroup/redHerc3Path";
$redHerc5Path = "MissionGroup/redHerc5Path";

$yellowHqDestroyed = false;
$redHqDestroyed = false;

///////////////////////////////////////////////////////////////////////////////////////////////////
// the Game Info tab uses these variables in the rules
///////////////////////////////////////////////////////////////////////////////////////////////////
$respawnDelay = 60;
$respawnDelayNoHq = 120;
$BUILDINGS_TO_DESTROY = 6;

///////////////////////////////////////////////////////////////////////////////////////////////////
// our base defender attributes
//
// The jump from 0.9 to 1.0 is a big one. At skill 1.0 and accuracy 1.0 the AI units will aim 
// first for the weapons, then the legs. A little too much for this mission.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
Pilot YellowPilot
{
   id = 28;
   
   name = *IDMULT_WAR_YELLOW_DEFENDER;
   
   skill = 0.9;
   accuracy = 0.85;
   aggressiveness = 0.9;
   activateDist = 900.0;
   deactivateBuff = 400.0;
   targetFreq = 2.5;
   trackFreq = 0.1;
   fireFreq = 0.2;
   LOSFreq = 0.2;
   orderFreq = 2.0;
};

Pilot RedPilot
{
   id = 29;
   
   name = *IDMULT_WAR_RED_DEFENDER;
   
   skill = 0.9;
   accuracy = 0.85;
   aggressiveness = 0.9;
   activateDist = 900.0;
   deactivateBuff = 400.0;
   targetFreq = 2.5;
   trackFreq = 0.1;
   fireFreq = 0.3;
   LOSFreq = 0.3;
   orderFreq = 2.0;
};

function initGlobalVars()
{
   $scoringFreeze = false;
   
   %playerCount = playerManager::getPlayerCount();
	// clear all points for the players
   for (%p = 0; %p < %playerCount; %p++)
	{
		%player = playerManager::getPlayerNum(%p);
      %player.numKills = 0;
      %player.buildingsDestroyed = 0;
   }
}

function setDefaultMissionOptions()
{
	$server::TeamPlay = True;
	$server::AllowDeathmatch = False;
	$server::AllowTeamPlay = True;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = false;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = true;

   $server::disableTeamRed = false;
   $server::disableTeamBlue = true;
   $server::disableTeamYellow = false;
   $server::disableTeamPurple = true;
}

function setDefaultMissionItems()
{
   allowComponent(                                        830, FALSE  );      //Chameleon
   allowComponent(                                        831, FALSE  );      //Cuttlefish cloak
   allowComponent(                                        840, true  );      //Shield Modulator
   allowComponent(                                        914, true  );      //UAP
}

function player::onAdd(%this)
{
   say(%this, 0, "Welcome to WAR! You can download WAR_Titan_Siege & other missions made by Maj. DarkRaven [M.I.B.] in the \"MIB Map Packs\" at www.starsiegeplayers.com or on the MIB Website at www.starsiegemeninblack.cjb.net.");
}

function onMissionLoad()
{
   cdAudioCycle("ss2", "Watching", "Mechsoul"); 

// HERC ID >> so i can find it ( =HG= )

   // get the original ID for each AI Herc ( for use later when we clone them )
   $yellowHerc1 = getObjectId( "MissionGroup/yellowHerc1/herc1" );
   $yellowHerc2 = getObjectId( "MissionGroup/yellowHerc2/herc1" );
   $yellowHerc3 = getObjectId( "MissionGroup/yellowHerc3/herc1" );
   $yellowHerc4 = getObjectId( "MissionGroup/yellowhqdefender/herc1" );
   $yellowHerc5 = getObjectId( "MissionGroup/yellowHerc5/Tank1" );

   $redHerc1 = getObjectId( "MissionGroup/redHerc1/herc1" );
   $redHerc2 = getObjectId( "MissionGroup/redHerc2/herc1" );
   $redHerc3 = getObjectId( "MissionGroup/redHerc3/herc1" );
   $redHerc4 = getObjectId( "MissionGroup/redhqdefender/herc1" );
   $redHerc5 = getobjectId( "MissionGroup/redHerc5/Tank1" );

   %rules = "<tIDMULT_WAR_GAMETYPE>"      @        
            "<tIDMULT_WAR_MAPNAME>"       @ 
            $missionName                  @  
            "<tIDMULT_WAR_OBJECTIVES_1>"  @
            timeDifference($respawnDelay, 0)       @
            "<tIDMULT_WAR_OBJECTIVES_2>"  @
            timeDifference($respawnDelayNoHq, 0)   @
            "<tIDMULT_WAR_OBJECTIVES_3>"  @
            "<tIDMULT_WAR_OBJECTIVES_4>"  @
            $BUILDINGS_TO_DESTROY         @
            "<tIDMULT_WAR_OBJECTIVES_5>"  @
            "<tIDMULT_WAR_SCORING_1>"     @
            "<tIDMULT_WAR_SCORING_2>"     @
            "<tIDMULT_STD_ITEMS>"         @
            "<tIDMULT_WAR_HQ>"            @
            "<tIDMULT_WAR_GENERATORS>"    @
            "<tIDMULT_WAR_TURRETS>"       @
            "<tIDMULT_WAR_FLAGS>"         @
            "<tIDMULT_WAR_GLOW>"          @
            "<tIDMULT_STD_HEAL>"          @
            "<tIDMULT_STD_RELOAD_1>"      @
            $PadWaitTime                  @
            "<tIDMULT_STD_RELOAD_2>";
   
   setGameInfo(%rules);
}


//-------------------------------------------------------------
function player::onAdd(%this)
{
   say(%this, 0, *IDMULT_WAR_WELCOME);
}

function vehicle::onAdd(%this)
{
   // see if it is a player
   %player = playerManager::vehicleIdToPlayerNum(%this);
   if(%player == 0) 
      return;

   schedule( "setEnemyNavPoint(" @ %this @ ");", 1 );
}

function setEnemyNavPoint( %this )
{
   if( getTeam(%this) == *IDSTR_TEAM_YELLOW )
   {
      setNavMarker( "MissionGroup/RedBase/navigationMarker1", true, %this );
   }
   else
   {
      setNavMarker( "MissionGroup/YellowBase/navigationMarker1", true, %this );
   }
}


function vehicle::onDestroyed( %this, %destroyer )
{
   if( getTeam( %this ) == *IDSTR_TEAM_RED )
   {
      $yellowKills++;
   }
   else
   {
      $redKills++;
   }

   // award the player a kill ( if the enemy is a different color )
   if( getTeam( %destroyer ) != getTeam( %this ) )
   {
      %player = playerManager::vehicleIdToPlayerNum( %destroyer );
      if(%player != 0)
      {
         %player.numKills++;      
      }
   }
   
   //----------------------------------------------------------------
   // If any of our AI hercs die, give a message and re-clone/drop them >> so i can find it ( =HG= )
   //----------------------------------------------------------------
   if( %this == $yellowHerc1 )
   {
      $yellowHercsDestroyed++;
      
      if( $yellowHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc1\", " @ %this @ ", -5971, 4396, 100);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc1\", " @ %this @ ", -5971, 4396, 76);", $respawnDelayNoHq);
      }
   }
   if( %this == $yellowHerc2 )
   {
      $yellowHercsDestroyed++;

      if( $yellowHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc2\", " @ %this @ ", -5355, 4683, 128);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc2\", " @ %this @ ", -5355, 4683, 128);", $respawnDelayNoHq);
      }
   }
   if( %this == $yellowHerc3 )
   {
      $yellowHercsDestroyed++;
      
      if( $yellowHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc3\", " @ %this @ ", -4267, 5020, 112);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc3\", " @ %this @ ", -4267, 5020, 112);", $respawnDelayNoHq);
      }
   }
   if( %this == $yellowHerc4 )
   {
      $yellowHercsDestroyed++;
      
      if( $yellowHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc4\", " @ %this @ ", -5178, 5345, 20);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc4\", " @ %this @ ", -5178, 5345, 20);", $respawnDelayNoHq);
      }
   }
   if( %this == $yellowHerc5 )
   {
      $yellowHercsDestroyed++;
      
      if( $yellowHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc4\", " @ %this @ ", -5125, 5123, 50);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$yellowHerc4\", " @ %this @ ", -5125, 5123, 50);", $respawnDelayNoHq);
      }
   }
   if( %this == $redHerc1 )
   {
      $redHercsDestroyed++;
      
      if( $redHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$redHerc1\", " @ %this @ ", -4896, 2182, 20);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$redHerc1\", " @ %this @ ", -4896, 2182, 20);", $respawnDelayNoHq);
      }
   }
   if( %this == $redHerc2 )
   {
      $redHercsDestroyed++;
      
      if( $redHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$redHerc2\", " @ %this @ ", -5095, 1768, 80);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$redHerc2\", " @ %this @ ", -5095, 1768, 80);", $respawnDelayNoHq);
      }
   }
   if( %this == $redHerc3 )
   {
      $redHercsDestroyed++;
      
      if( $redHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$redHerc3\", " @ %this @ ", -4549, 1638, 80);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$redHerc3\", " @ %this @ ", -4549, 1638, 80);", $respawnDelayNoHq);
      }

   }
   if( %this == $redHerc4 )
   {
      $redHercsDestroyed++;
      
      if( $redHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$redHerc4\", " @ %this @ ", -4900, 1488, 80);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$redHerc4\", " @ %this @ ", -4900, 1488, 80);", $respawnDelayNoHq);
      }

   }
   if( %this == $redHerc5 )
   {
      $redHercsDestroyed++;
      
      if( $redHqDestroyed == false )
      {
         schedule( "trevorsCloneVehicle(\"$redHerc5\", " @ %this @ ", -5125, 1679, 80);", $respawnDelay);
      }
      else
      {
         schedule( "trevorsCloneVehicle(\"$redHerc5\", " @ %this @ ", -5125, 1679, 80);", $respawnDelayNoHq);
      }

   }
   // left over from missionStdLib.cs
   vehicle::onDestroyedLog(%this, %destroyer);
   
   // give the death messages...
   %message = getFancyDeathMessage(getHUDName(%this), getHUDName(%destroyer));
   if(%message != "")
   {
      say( 0, 0, %message);
   }

   // rules enforcement
   if(
      (getTeam(%this) == getTeam(%destroyer)) &&
      (%this != %destroyer)
   )
   {
      antiTeamKill(%destroyer);
   }
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

	$ScoreBoard::PlayerColumnHeader1 = "Team";
	$ScoreBoard::PlayerColumnHeader2 = "Kills";
	$ScoreBoard::PlayerColumnHeader3 = "Buildings Destroyed";

	$ScoreBoard::PlayerColumnFunction1 = "getTeam2";
	$ScoreBoard::PlayerColumnFunction2 = "getKills";
	$ScoreBoard::PlayerColumnFunction3 = "getBuildingsDestroyed";

   $ScoreBoard::TeamColumnHeader1 = "Structures Remaining";
   $ScoreBoard::TeamColumnHeader2 = "Total Kills";
   $ScoreBoard::TeamColumnFunction1 = "getRemainingStructures";
   $ScoreBoard::TeamColumnFunction2 = "getTeamKills";
 
   serverInitScoreBoard();
}

function getTeam2(%player)
{
   if( getTeam( %player ) == *IDSTR_TEAM_YELLOW )
   {
      return *IDMULT_YELLOW;
   }
   else
   {
      return *IDMULT_RED;
   }
}

function getKills(%player)
{
   if( %player.numKills != "")
      return %player.numKills;
      
   return "0";
}

function getTeamKills(%team)
{
   if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_YELLOW )
   {
      return $yellowKills;
   }
   else
   {
      return $redKills;
   }   
}

function getRemainingStructures(%team)
{
   if( getTeamNameFromTeamId(%team) == *IDSTR_TEAM_YELLOW )
   {
      return $BUILDINGS_TO_DESTROY - $yellowBuildingsDestroyed;
   }
   else
   {
      return $BUILDINGS_TO_DESTROY - $redBuildingsDestroyed;
   }   
}

function getBuildingsDestroyed(%player)
{
   if( %player.buildingsDestroyed != "")
      return %player.buildingsDestroyed;
   
   return "0";
}

///////////////////////////////////////////////////////
// turrets have 2 numbers after so i can get 2 0r 3 on 1 generator... first number is the generator number and
// the second is so the game realizes there are more than 1 turrets.
///////////////////////////////////////////////////////

function redGen1::structure::onDestroyed( %this, %who )
{
  $redBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/redBase/t11", shutdown, True );
  order( "MissionGroup/redBase/t12", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_RED_BR_GEN_DESTROYED;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_RED_STRUCTURE;
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
}

function redGen2::structure::onDestroyed( %this, %who )
{
  $redBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/redBase/t21", shutdown, True );
  order( "MissionGroup/redBase/t22", shutdown, True );
  order( "MissionGroup/redBase/t23", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_RED_FR_GEN_DESTROYED;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_RED_STRUCTURE;
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
}

function redGen3::structure::onDestroyed( %this, %who )
{
  $redBuildingsDestroyed++;
  checkForWin();
 
  order( "MissionGroup/redBase/t31", shutdown, True );
  order( "MissionGroup/redBase/t32", shutdown, True );
  order( "MissionGroup/redBase/t33", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_RED_CEN_GEN_DESTROYED;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_RED_STRUCTURE;
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
}

function redGen4::structure::onDestroyed( %this, %who )
{
  $redBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/redBase/t41", shutdown, True );
  order( "MissionGroup/redBase/t42", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_RED_BL_GEN_DESTROYED;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_RED_STRUCTURE;
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
}

function redGen5::structure::onDestroyed( %this, %who )
{
  $redBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/redBase/t51", shutdown, True );
  order( "MissionGroup/redBase/t52", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_RED_FL_GEN_DESTROYED;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_RED_STRUCTURE;
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
}

function yellowGen1::structure::onDestroyed( %this, %who )
{
  $yellowBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/yellowBase/t11", shutdown, True );
  order( "MissionGroup/yellowBase/t12", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_YELLOW_BR_GEN_DESTROYED;
  say(IDSTR_TEAM_RED, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_YELLOW_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
}

function yellowGen2::structure::onDestroyed( %this, %who )
{
  $yellowBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/yellowBase/t21", shutdown, True );
  order( "MissionGroup/yellowBase/t22", shutdown, True );
  order( "MissionGroup/yellowBase/t23", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_YELLOW_FR_GEN_DESTROYED;
  say(IDSTR_TEAM_RED, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_YELLOW_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
}

function yellowGen3::structure::onDestroyed( %this, %who )
{
  $yellowBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/yellowBase/t31", shutdown, True );
  order( "MissionGroup/yellowBase/t32", shutdown, True );
  order( "MissionGroup/yellowBase/t33", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_YELLOW_CEN_GEN_DESTROYED;
  say(IDSTR_TEAM_RED, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_YELLOW_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
}

function yellowGen4::structure::onDestroyed( %this, %who )
{
  $yellowBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/yellowBase/t41", shutdown, True );
  order( "MissionGroup/yellowBase/t42", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_YELLOW_BL_GEN_DESTROYED;
  say(IDSTR_TEAM_RED, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_YELLOW_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
}

function yellowGen5::structure::onDestroyed( %this, %who )
{
  $yellowBuildingsDestroyed++;
  checkForWin();

  order( "MissionGroup/yellowBase/t51", shutdown, True );
  order( "MissionGroup/yellowBase/t52", shutdown, True );
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_YELLOW_FL_GEN_DESTROYED;
  say(IDSTR_TEAM_RED, 1234, %txt, "ene_struct_dest.wav");    


  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_YELLOW_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    
}

function redHQ::structure::onDestroyed( %this, %who )
{
  $redBuildingsDestroyed++;
  checkForWin();
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }

  $redHqDestroyed = true;

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_RED_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "ene_struct_dest.wav");    
  say(IDSTR_TEAM_RED, 1234, %txt, "friend_struct_des.wav");    
  say(0, 1234, "<F5>" @ *IDMULT_WAR_RED_HQ_DESTROYED @ timeDifference($respawnDelayNoHq, 0) @ "." );
}


function yellowHQ::structure::onDestroyed( %this, %who )
{
  $yellowBuildingsDestroyed++;
  checkForWin();
  %player = playerManager::vehicleIdToPlayerNum( %who );
  if(%player != 0)
  {
      %player.buildingsDestroyed++;     
  }
  
  $yellowHqDestroyed = true;

  %txt = "<F5>" @ getHUDName(%who) @ *IDMULT_WAR_DESTROYED_YELLOW_STRUCTURE;
  say(IDSTR_TEAM_YELLOW, 1234, %txt, "friend_struct_des.wav");    

  say(IDSTR_TEAM_RED, 1234, %txt, "ene_struct_dest.wav");    
  say(0, 1234, "<F5>" @ *IDMULT_WAR_YELLOW_HQ_DESTROYED @ timeDifference($respawnDelayNoHq, 0) @ "." );
}


function onMissionStart()
{
	$healRate = 100;   
	$ammoRate = 3;
 	$padWaitTime = 15;

   windSounds();
	marsSounds();	

   initGlobalVars();

// ORDERS SO HERCS MOVE ALONG PATHS >> so i can find it ( =HG= )
   
   order( $yellowHerc1, guard, $yellowHerc1Path );
   order( $yellowHerc2, guard, $yellowHerc2Path );
   order( $yellowHerc3, guard, $yellowHerc3Path );
   order( $yellowHerc5, guard, $yellowHerc5Path );
   order( $redHerc1, guard, $redHerc1Path );
   order( $redHerc2, guard, $redHerc2Path );
   order( $redHerc3, guard, $redHerc3Path );
   order( $redHerc5, guard, $redHerc5Path );
}

function checkForWin()
{
   if( $yellowBuildingsDestroyed >= $BUILDINGS_TO_DESTROY )
   {
      fadeEvent( 0, out, 1.5, 1.0, 0, 0 ); 
      schedule( "missionEndConditionMet();", 1.6 );
      
      %txt = "Red team is victorious!";
      messageBox(0, %txt);
   }
   else if( $redBuildingsDestroyed >= $BUILDINGS_TO_DESTROY )
   {
      fadeEvent( 0, out, 1.5, 1.0, 1.0, 0 ); 
      schedule( "missionEndConditionMet();", 1.6 );
      
      %txt = "Yellow team has won!";
      messageBox(0, %txt);
   }   
}


// Healing Pad Functionality
//------------------------------------------------------------------------------
function ZenHeal::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_HEALPAD, true, true);  
}
function ZenHeal::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, $healRate, 0, $padWaitTime, true); 
}

// Ammo Pad Functionality
//------------------------------------------------------------------------------
function ZenAmmo::trigger::onEnter(%this, %object)
{
   	Zen::onEnter(%this, %object, *IDMULT_CHAT_AMMOPAD, true, true);  
}

function ZenAmmo::trigger::onContact(%this, %object)
{
   	Zen::work(%this, %object, 0, $ammoRate, $padWaitTime, true); 
}

// Vehicles can clone
 
function trevorsCloneVehicle(%globalVarName, %old, %x, %y, %z)
{
   %clone = cloneVehicle(%old);
   setPosition(%clone, %x, %y, %z);

   schedule( "deleteObject(" @ %old @ ");", $respawnDealNoHq + 10 );

   schedule( %globalVarName @ " = " @ %clone @ ";", 0);

   addToSet( "MissionGroup", %clone );

   %path = %globalVarName @ "Path";
   schedule( "order( " @ %clone @ ", guard, " @ %path @ " );", 1 );
}

//--------------------------------------------------------------------------------
//--easter EGG code >> SHHHHH IT IS A SECRET!   same one in featherlight2 map...

function vanishTrigger1::trigger::onAdd(%this)
{
	dataStore(%this, "isActive", true); // bool for trigger active
}
function vanishTrigger1::trigger::onEnter(%this, %object)
{
	triggerOnEnter(1, %object);	
}
function vanishTrigger2::trigger::onAdd(%this)
{
	dataStore(%this, "isActive", false); // bool for trigger active
}

function vanishTrigger2::trigger::onEnter(%this, %object)
{
	triggerOnEnter(2, %object);	
}
function vanishTrigger3::trigger::onAdd(%this, %object)
{
	dataStore(%this, "isActive", false); // bool for trigger active
}
function vanishTrigger3::trigger::onEnter(%this, %object)
{
	triggerOnEnter(3, %object);	
}
function teleportTrigger::trigger::onAdd(%this)
{
	dataStore(%this, "isActive", false); // bool for trigger active
}
function teleportTrigger::trigger::onEnter(%this, %object)
{
	triggerOnEnter(teleport, %object);	
}
function triggerOnEnter(%index, %object)
{
	%thisTrigger = "";
	%nextTrigger = "";
	%chatMsg = "";
	
	if(%index == 1)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger1");
		%nextTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger2");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\flag1");
		%nextFlag =    getObjectId("MissionGroup\\extra\\flag2");
		%chatMsg  = "Trigger 2 activated.";		 	 	
	}

	if(%index == 2)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger2");
		%nextTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger3");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\flag2");
		%nextFlag =    getObjectId("MissionGroup\\extra\\flag3");
		%chatMsg = "Trigger 3 activated.";	
	}

	if(%index == 3)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger3");
		%nextTrigger = getObjectId("MissionGroup\\extra\\teleportTrigger");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\flag3");
		%nextFlag =    getObjectId("MissionGroup\\extra\\teleport");
		%chatMsg = "Teleportation device online."; 
		setShapeVisibility(getObjectId("MissionGroup\\Extra\\fx_tele_t1"), true);	
	}

	if(%index == teleport)
	{
		%thisTrigger = getObjectId("MissionGroup\\extra\\teleportTrigger");
		%nextTrigger = getObjectId("MissionGroup\\extra\\vanishTrigger1");
		%thisFlag =	   getObjectId("MissionGroup\\extra\\teleport");
		%nextFlag =    getObjectId("MissionGroup\\extra\\flag1");
		%chatMsg = "Teleportation Device is inoperable.";	
	}
	
	if(%thisTrigger == "" || %nextTrigger == "")
	{
		echo("bad triggerIds!");
		return;
	}
	
	%isActive = dataRetrieve(%thisTrigger, "isActive");

	if(%isActive != false)
	{
		dataStore(%thisTrigger, "isActive", false);
		dataStore(%nextTrigger, "isActive", true);
		
		if(%index != 3)
		{
			setShapeVisibility(%nextFlag, true);
		}
				
		if(%index == teleport)
		{
			%malfunctionChance = randomFloat(0.0,0.1);
			if(%malfunctionChance > randomFloat(0.0,1.0))
			{
				malfunction(%object);
			}
			else
			{
				teleport(%object);
				setShapeVisibility(getObjectId("MissionGroup\\Extra\\fx_tele_t1"), false);
			}
		}
		else
		{
			setShapeVisibility(%thisFlag, false);
			// chat(%object, 0, %chatMsg);	
		   Say( playerManager::vehicleIdToPlayerNum(%object), %object, %chatMsg );
      }					
	}
	else if(%index == teleport)
	{
		// chat(%object, 0, %chatMsg);
	   Say( playerManager::vehicleIdToPlayerNum(%object), %object, %chatMsg );
   }	
}
function teleport(%object)
{
	%flagNum = randomInt(1,2);
	%x = %y = 0;

	if(%flagNum == 1)
	{
		%x = -5099;
		%y = 4310;
	}

	if(%flagNum == 2)
	{
		%x = -4863;
		%y = 893;
	}
	
	%playerNum = playerManager::vehicleIdToPlayerNum(%object);
	
	Say( %object, %object, "Teleportation initiated." );
   
   	healObject(%object, 600.0);
	reloadObject(%object, 60.0);

	randomTransport(%object, %x, %y, %x, %y);
   	%str = "Say( %object, %object, \"Teleportation complete.\" );";
   	schedule( %str, 2.5 );
}
function malfunction(%object)
{
	Say( %object, %object, "Teleportation initiated." );
   
  	%playerNum = playerManager::vehicleIdToPlayerNum(%object);
	fadeEvent(%playerNum, out, 2.5, 0.5,0.0,0.0);
  	%str = "Say( %object, %object, \"Teleportation malfunction!\" );";
  	schedule( %str, 1.8 );
	
 	schedule(strcat("fadeEvent(", %playerNum, ", in, 1.5, 0.5,0.0,0.0);"), 2.5);
	schedule(strcat("damageObject(", %object, ", 10000);"), 2.5);		
}




