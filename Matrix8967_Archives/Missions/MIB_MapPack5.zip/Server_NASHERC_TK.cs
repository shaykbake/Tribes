// FILENAME: Server_NASHERC_TK.cs
//
// NASHERC Racing Server Script
// Craftsman Tank Series (TK) Restrictions


exec(serverLocation);
//-------------------------------------------------
//  RC file to start a server automatically
//-------------------------------------------------

//-------------------------------------------------
// Edit the parameters of this file to configure
// your server options. Use notepad, not a word
// processor. File must be saved as text only.
//-------------------------------------------------

//-------------------------------------------------
// Type the name for your server inside the quotes
// Must be less then 22 characters
//-------------------------------------------------
$server::Hostname = strcat("NASHERC RACING!!!");

//-------------------------------------------------
// Password Protection. Leave blank for none.
// Quotes optional.
//-------------------------------------------------
$server::Password =                                 "";

//-------------------------------------------------
// Maximum player limit. 16 is highest recommended.
//-------------------------------------------------
$server::MaxPlayers =                              10;

//-------------------------------------------------
// Number of kills before server cycles.
// If zero, kills are never reset.
//-------------------------------------------------
$server::FragLimit =                               0;

//-------------------------------------------------
// Time limit in minutes before server cycles.
// Must be a positive integer.
//-------------------------------------------------
$server::TimeLimit =                               0;

//-------------------------------------------------
// Mass limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::MassLimit =                                45;

//-------------------------------------------------
// Combat Value limit per player
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::CombatValueLimit =                         0;

//-------------------------------------------------
// Team play options. TeamPlay false =  deathmatch.
// TeamPlay true = teams
//-------------------------------------------------
$server::TeamPlay =                                FALSE;

//-------------------------------------------------
// Team Mass limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamMassLimit =                            0;

//-------------------------------------------------
// Team Combat Value Limit - valid only when teamPlay is true
// Must be a positive integer or zero for no limit.
//-------------------------------------------------
$server::TeamCombatValueLimit =                     0;

//-------------------------------------------------
// Tech Level Limit
// Must be a positive integer less then or
// equal to 128 or zero for no limit.
//-------------------------------------------------
$server::TechLevelLimit =                          0;

//-------------------------------------------------
// Drop In Progress
// Does server allow drop in progress??
//-------------------------------------------------
$server::DropInProgress =                            TRUE  ;

$server::AllowMixedTech =                           TRUE  ;
$server::FactoryVehOnly =                           FALSE  ;

//-------------------------------------------------
// Mission rotation list. This is the order the
// worlds will cycle in a game with either the frag
// or time limits set.
//-------------------------------------------------
$MissionCycling::Stage0 =                          "RACE_TK_Daytona";
$MissionCycling::Stage1 =                          "RACE_TK_Charlotte";
$MissionCycling::Stage2 =                          "RACE_TK_LA";
$MissionCycling::Stage3 =                          "RACE_TK_Bristol";
$MissionCycling::Stage4 =                          "RACE_TK_Rockingham";
$MissionCycling::Stage5 =                          "RACE_TK_Talladega";
$MissionCycling::Stage6 =                          "RACE_TK_Martinsville";
$MissionCycling::Stage7 =                          "RACE_TK_Sears_Point";
$MissionCycling::Stage8 =                          "RACE_TK_Manhattan";
$MissionCycling::Stage9 =                          "RACE_TK_Atlanta";
$MissionCycling::Stage10 =                         "RACE_TK_New_York";
$MissionCycling::Stage11 =                         "RACE_TK_RR_Spawne32";
//-------------------------------------------------
// Start mission. Defines which mission from the
// rotation list the server starts on.
//-------------------------------------------------
$server::Mission = $MissionCycling::Stage0;

// These items will be allowed by default -- your mission script can change these
// by calling allowVehicle, allowComponent, or allowWeapon
function setAllowedItems()
{
      allowVehicle(  all, FALSE  );
      allowVehicle(  17, TRUE  );
      allowVehicle(  25, TRUE  );
      allowVehicle(  41, TRUE  );
      
      allowWeapon(  all, FALSE  );
      allowWeapon(  3, FALSE  );
      allowWeapon(  101, TRUE  );
      allowWeapon(  102, TRUE  );
      allowWeapon(  103, TRUE  );
      allowWeapon(  104, TRUE  );
      allowWeapon(  105, TRUE  );
      allowWeapon(  111, TRUE  );
      allowWeapon(  114, TRUE  );
      allowWeapon(  115, TRUE  );
      allowWeapon(  116, TRUE  );
      allowWeapon(  117, TRUE  );
      allowWeapon(  118, TRUE  );
      allowWeapon(  121, TRUE  );
      allowWeapon(  111, TRUE  );
            
      allowComponent(  all, TRUE  );
      allowComponent(  809, FALSE );
      allowComponent(  810, FALSE );
      allowComponent(  811, FALSE );
      allowComponent(  812, FALSE );
      allowComponent(  813, FALSE );
      allowComponent(  820, FALSE );
      allowComponent(  840, FALSE );
      allowComponent(  845, FALSE );
      allowComponent(  850, FALSE );
      allowComponent(  860, FALSE );
      allowComponent(  875, FALSE );
      allowComponent(  880, FALSE );
      allowComponent(  900, FALSE );
      allowComponent(  910, FALSE );
}


