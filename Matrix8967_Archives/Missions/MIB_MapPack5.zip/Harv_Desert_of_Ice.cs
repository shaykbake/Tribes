// Harvester Map: Desert of Ice
//
// Two teams, two bases each, The smaller housing a teleporter base, the larger the AiBuilders.
// Both bases have turret, refinery and expansion builders. All spawnpoints area at the larger (farther away) base.
// Supply Dumps at both bases. One Zen pad in the center to fight over. Red team can only build Human AI, Blue
// can only build Cybrid AI. Designed to show off the many options in Harvester.
//
// ][)ull 2-23-1
//========================


function setHarvestVariables()
{

$Planet = "Snow"; 

$orePatches = 7;

$OreZones = 6;
$Xlow[1] = -4000;
$Xhigh[1] = -500; 
$Ylow[1] = -500;
$Yhigh[1] = 4000;

$Xlow[2] = -4000;
$Xhigh[2] = -1250; 
$Ylow[2] = -1500;
$Yhigh[2] = -500;

$Xlow[3] = -4000;
$Xhigh[3] = -500; 
$Ylow[3] = -4000;
$Yhigh[3] = -1500;

$Xlow[4] = 500;
$Xhigh[4] = 4000; 
$Ylow[4] = -4000;
$Yhigh[4] = -2000;

$Xlow[5] = 0;
$Xhigh[5] = 4000; 
$Ylow[5] = -2000;
$Yhigh[5] = 1500;

$Xlow[6] = 500;
$Xhigh[6] = 4000; 
$Ylow[6] = 1500;
$Yhigh[6] = 4000;

$BlueMarkers = 2; 
$RedMarkers = 2; 

$BlueMarker[1] = getObjectId("MissionGroup\\BLUE\\BaseNav"); 
$RedMarker[1] = getObjectId("MissionGroup\\RED\\BaseNav"); 
$BlueMarker[2] = getObjectId("MissionGroup\\BlueTPbase\\BaseNav"); 
$RedMarker[2] = getObjectId("MissionGroup\\RedTPbase\\BaseNav"); 

$BlueRadius[1] = 700;
$RedRadius[1] = 700;
$BlueRadius[2] = 400;
$RedRadius[2] = 400;

$NewBaseRadius = 500;

$Targets[*IDSTR_TEAM_RED] = 5; 
$Targets[*IDSTR_TEAM_BLUE] = 5;

$orePatch[1] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger1");
$orePatch[1].size = 100;
$orePatch[1].maxOre = 700;
$orePatch[1].maxRocks = 7;

$orePatch[2] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger2");
$orePatch[2].size = 100;
$orePatch[2].maxOre = 700;
$orePatch[2].maxRocks = 7;

$orePatch[3] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger3");
$orePatch[3].size = 100;
$orePatch[3].maxOre = 700;
$orePatch[3].maxRocks = 7;

$orePatch[4] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger4");
$orePatch[4].size = 100;
$orePatch[4].maxOre = 700;
$orePatch[4].maxRocks = 7;

$orePatch[5] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger5");
$orePatch[5].size = 100;
$orePatch[5].maxOre = 700;
$orePatch[5].maxRocks = 7;

$orePatch[6] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger6");
$orePatch[6].size = 100;
$orePatch[6].maxOre = 700;
$orePatch[6].maxRocks = 7;

$orePatch[7] = getObjectId("MissionGroup\\oreTriggers\\OreTrigger7");
$orePatch[7].size = 100;
$orePatch[7].maxOre = 700;
$orePatch[7].maxRocks = 7;



$SiloDTS[*IDSTR_TEAM_BLUE] = "hmoonrefinery.dts";
$SiloDTS[*IDSTR_TEAM_RED] = "hmoonrefinery.dts";


$Silo[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\BLUE\\nukeBuilder");
$Silo[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\RED\\nukeBuilder");

$SiloX[*IDSTR_TEAM_BLUE] = 35.7;
$SiloY[*IDSTR_TEAM_BLUE] = 3443.9;
$SiloZ[*IDSTR_TEAM_BLUE] = 155.3;
$SiloZRot[*IDSTR_TEAM_BLUE] = 105;
$SiloXRot[*IDSTR_TEAM_BLUE] = 0;

$SiloX[*IDSTR_TEAM_RED] = -363.2;
$SiloY[*IDSTR_TEAM_RED] = -2971.6;
$SiloZ[*IDSTR_TEAM_RED] = 222.9;
$SiloZRot[*IDSTR_TEAM_RED] = 0;
$SiloXRot[*IDSTR_TEAM_RED] = 0;

 //Shrike Missile Husks for the bombs
$Bomb[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\blueBomb");
$Bomb[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\redBomb");


 //Waypoints (Put them where they are placed in this map in relation to the bases)
$Waypoints[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup/blueWaypoints");
$Waypoints[*IDSTR_TEAM_RED] = getObjectId("Missiongroup/redWaypoints");
$Waypoint[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup/blueWaypoints/Waypoint1");
$Waypoint[*IDSTR_TEAM_RED] = getObjectId("Missiongroup/redWaypoints/Waypoint1");
$Waypoint2[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup/blueWaypoints/Waypoint2");
$Waypoint2[*IDSTR_TEAM_RED] = getObjectId("Missiongroup/redWaypoints/Waypoint2");

   
 //PodExplosion Animations (Buzzbum MOD - FX Shapes)
$Explosion[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\blueExplosion");
$Explosion[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\redExplosion");
   
 //Thumper Animations (Buzzbum MOD - FX Shapes)
$Shockwave[*IDSTR_TEAM_BLUE] = getObjectId("Missiongroup\\blueShock");
$Shockwave[*IDSTR_TEAM_RED] = getObjectId("Missiongroup\\redShock");

// Starting Point for the dracos. Atop a launchpad or whatever.
$DracoX[*IDSTR_TEAM_BLUE] = 29.3;
$DracoY[*IDSTR_TEAM_BLUE] = 3383.3;
$DracoZ[*IDSTR_TEAM_BLUE] = 164;
$DracoX[*IDSTR_TEAM_RED] = -383.9;
$DracoY[*IDSTR_TEAM_RED] = -2895.5;
$DracoZ[*IDSTR_TEAM_RED] = 240.1;
}

//===========Stuff copied and edited from Mike The Goad's "Move It"============================

function HarvVehicleOnDestroyed(%destroyed, %destroyer)
{
if(%destroyed == $rm)
 {
 $rm = "";
 pr();
 }
if(%destroyed == $bm)
 {
 $bm = "";
 pb();
 }
}

function HarvTurretOnDestroyed(%turret, %veh)
{
if(getFullPath(%turret) == "missionGroup\\Red Turrets\\Mobile Turret")
 setShapeVisibility(getObjectId("missionGroup\\Red Turrets\\MTGen"), false);
if(getFullPath(%turret) == "missionGroup\\Blue Turrets\\Mobile Turret")
 setShapeVisibility(getObjectId("missionGroup\\Blue Turrets\\MTGen"), false);
}


//=== Red
//== Nav Porter

function RedGen::structure::onScan(%this,%scanner)	// Red mobile nav porter
{
if($rm == "")
 {
 $rm = %scanner;					//new global 
 %p=playerManager::vehicleIdToPlayerNum(%scanner);
 say(%p,0,"Scan again to place nav-porter"); 
 mr();
 }
 else
 {
 $rm = "";
 }
}

function mr()
{
%x = (getPosition($rm,x) - 75);
%y = getPosition($rm,y);
%z = getPosition($rm,z);
if(%x == %z)					// he died or left
 {
 $rm = "";
 pr();
 }
 else
 {
 setPosition(getObjectId("missionGroup\\RedMove\\Frame"),%x,%y,%z);
 %gz = (%z + 12.7);
 setPosition(getObjectId("missionGroup\\RedMove\\redGen"),%x,%y,%gz);
 setPosition(getObjectId("missionGroup\\RedMove\\NavPorter"),%x,%y,%z);
 }
if($rm != "")
 {
 schedule("mr();",0.2);
 }
 else
 {
 pr();
 }
}

function pr()
{
%x = getPosition(getObjectId("MissionGroup\\RedMove\\Frame"),x);
%y = getPosition(getObjectId("MissionGroup\\RedMove\\Frame"),y);
%h = (getTerrainHeight(%x,%y) - 0.5);
setPosition(getObjectId("missionGroup\\RedMove\\Frame"),%x,%y,%h);
%gz = (%h + 12.7);
setPosition(getObjectId("missionGroup\\RedMove\\redGen"),%x,%y,%gz);
setPosition(getObjectId("missionGroup\\RedMove\\NavPorter"),%x,%y,%h);
}


//== Turret

function rmtGen::structure::onScan(%this,%scanner)	// Red mobile turret
{
if($rtm == "")
 {
 $rtm = %scanner;					//new global 
 %p=playerManager::vehicleIdToPlayerNum(%scanner);
 say(%p,0,"Scan again to place mobile-turret"); 
 mrt();
 }
 else
 {
 $rtm = "";
 }
}

function mrt()
{
%x = (getPosition($rtm,x) - 75);
%y = getPosition($rtm,y);
%z = getPosition($rtm,z);
if(%x == %z)					// he died or left
 {
 $rtm = "";
 prt();
 }
 else
 {
 setPosition(getObjectId("missionGroup\\Red Turrets\\Mobile Turret"),%x,%y,(%z-2));
 setPosition(getObjectId("missionGroup\\Red Turrets\\MTGen"),%x,%y,(%z-5), 180);
 }
if($rtm != "")
 {
 schedule("mrt();",0.2);
 }
 else
 {
 prt();
 }
}

function prt()
{
%x = getPosition(getObjectId("MissionGroup\\Red Turrets\\Mobile Turret"),x);
%y = getPosition(getObjectId("MissionGroup\\Red Turrets\\Mobile Turret"),y);
%h = (getTerrainHeight(%x,%y) - 2);
setPosition(getObjectId("missionGroup\\Red Turrets\\Mobile Turret"),%x,%y,%h);
setPosition(getObjectId("missionGroup\\Red Turrets\\MTGen"),%x,%y,%h-3,180);
}


//=== Blue
//== Nav Porter

function BlueGen::structure::onScan(%this,%scanner)	// Blue mobile nav porter
{
if($bm == "")
 {
 $bm = %scanner;					//new global 
 %p=playermanager::vehicleIdToPlayerNum(%scanner);
 say(%p,0,"Scan again to place nav-porter"); 
 mb();
 }
 else
 {
 $bm = "";
 }
}

function mb()
{
%x = (getPosition($bm,x) - 75);
%y = getPosition($bm,y);
%z = getPosition($bm,z);
if(%x == %z)					// he died or left
 {
 $bm = "";
 pb();
 }
 else
 {
 setPosition(getObjectId("missionGroup\\BlueMove\\Frame"),%x,%y,%z);
 %gz = (%z + 12.7);
 setPosition(getObjectId("missionGroup\\BlueMove\\BlueGen"),%x,%y,%gz);
 setPosition(getObjectId("missionGroup\\BlueMove\\NavPorter"),%x,%y,%z);
 }
if($bm != "")
 {
 schedule("mb();",0.2);
 }
 else
 {
 pb();
 }
}

function pb()
{
%x = getPosition(getObjectId("MissionGroup\\BlueMove\\Frame"),x);
%y = getPosition(getObjectId("MissionGroup\\BlueMove\\Frame"),y);
%h = (getTerrainHeight(%x,%y) - 0.5);
setPosition(getObjectId("missionGroup\\BlueMove\\Frame"),%x,%y,%h);
%gz = (%h + 12.7);
setPosition(getObjectId("missionGroup\\BlueMove\\BlueGen"),%x,%y,%gz);
setPosition(getObjectId("missionGroup\\BlueMove\\NavPorter"),%x,%y,%h);
}

//== Turret

function bmtGen::structure::onScan(%this,%scanner)	// Blue mobile turret
{
if($btm == "")
 {
 $btm = %scanner;					//new global 
 %p=playerManager::vehicleIdToPlayerNum(%scanner);
 say(%p,0,"Scan again to place mobile-turret"); 
 mbt();
 }
 else
 {
 $btm = "";
 }
}

function mbt()
{
%x = (getPosition($btm,x) - 75);
%y = getPosition($btm,y);
%z = getPosition($btm,z);
if(%x == %z)					// he died or left
 {
 $btm = "";
 pbt();
 }
 else
 {
 setPosition(getObjectId("missionGroup\\Blue Turrets\\Mobile Turret"),%x,%y,(%z-2), 180);
 setPosition(getObjectId("missionGroup\\Blue Turrets\\MTGen"),%x,%y,(%z-5));
 }
if($btm != "")
 {
 schedule("mbt();",0.2);
 }
 else
 {
 pbt();
 }
}

function pbt()
{
%x = getPosition(getObjectId("MissionGroup\\Blue Turrets\\Mobile Turret"),x);
%y = getPosition(getObjectId("MissionGroup\\Blue Turrets\\Mobile Turret"),y);
%h = (getTerrainHeight(%x,%y) - 2);
setPosition(getObjectId("missionGroup\\Blue Turrets\\Mobile Turret"),%x,%y,%h, 180);
setPosition(getObjectId("missionGroup\\Blue Turrets\\MTGen"),%x,%y,%h-3);
}



//===== Somthin' ;-)

function deck::structure::onScan(%house, %veh)
{
%player = playerManager::vehicleIdToPlayerNum(%veh);
%veh.egg++;
if(%veh.egg == 0)
 {
 healObject(%veh, 10000);
 reloadObject(%veh, 10000);
 say(%player, 0, "][)ull: Hey, long time no see, what's up?", "ee_pd09.wav");
 schedule("say("@%player@", 0, \"][)ull: Oh, shoot, my dinner's burning, drop me a line at dull@ss-harvester.com, gotta go...\");", 2);
 schedule("burn(true);", 2);
 }
else if(%veh.egg == 1)
 {
 say(%player, 0, "][)ull: What? Can't it wait?");
 return;
 }
else if(%veh.egg == 2)
 {
 say(%player, 0, "][)ull: ...okaaaay...");
 return;
 }
else if(%veh.egg == 3)
 {
 %txt = "<F";
 for(%j=0; %j<=68; %j++)
  {
  %r = randomInt(0, 5);
  %txt = %txt@%r@">*<F";
  }
 %r = randomInt(0,5);
 %txt = %txt@%r@">*";
 say(%player, 0, "][)ull: "@%txt, "C5_pbbbbbt.WAV");
 return;
 }
else if(%veh.egg <= 4)
 {
 %txt = "<F";
 for(%j=0; %j<=68; %j++)
  {
  %r = randomInt(0, 5);
  %txt = %txt@%r@">*<F";
  }
 %r = randomInt(0,5);
 %txt = %txt@%r@">*";
 say(%player, 0, "][)ull: "@%txt, "sfx_electrical_bzzt.wav");
 healObject(%veh, -10000000);
 return;
 }
}

function burn(%a)
{
setShapeVisibility(getObjectId("MissionGroup/Stuff/f1"), %a);
setShapeVisibility(getObjectId("MissionGroup/Stuff/f2"), %a);
setShapeVisibility(getObjectId("MissionGroup/Stuff/f3"), %a);
if(%a) schedule("burn(false);", 60);
}

//=======================================================================


$MapVersion = "ver01.007 - 2-23-1";
$MapBy = "<F4>Harv_Desert_of_Ice by dull@ss-harvester.com";
exec("Harvest_StdLib.cs");
$missionName = "Desert_of_Ice -" @ $HarvStdLibVer;

function HarvVehicleOnAdd(%vehicle)
{%vehicle.egg = -1;}

function HarvOnMissionStart()
{ burn(false); }

function NavPorter::trigger::onEnter(%trigger, %vehicle)
{
%player = playerManager::vehicleIdToPlayerNum(%vehicle);
%markerId = getVehicleNavMarkerId(%vehicle);
%x = getPosition(%markerId,x);
%y = getPosition(%markerId,y);
%z = getPosition(%markerId,z)+20;
if(%x == 0 && %y == 0) { say(%player, 0, "You must set a Nav-Marker to use the Nav-porter"); return; }
setPosition(%vehicle, %x, %y, %z);

for(%i=1; %i<=%vehicle.Guards; %i++)
 {
 %j = %vehicle.Guard[%i];
 %tX = (randomInt(-50, 50) + %x);
 %tY = (randomInt(-50, 50) + %y);
 %tz = %z;
 while(getTerrainHeight(%tX, %tY) > %tz) { %tz = %tz + 5; }
 setPosition( %j, %tx, %ty, %tz);
 }
}

function NPortDes::structure::onScan(%statue, %vehicle)
{
%player = playerManager::vehicleIdToPlayerNum(%vehicle);
if(%player == 0) return;
say(%player, 35, "<F4>This is a nav-porter, set a nav marker and go through the portal to be warped to your nav marker. Setting nav markers with the ovehead map is recommended.");
}


function box::structure::onDestroyed(%box, %destroyer) // Try shooting the fuel containers from up close, I dare you...
{
schedule("damageArea("@%box@", 0, 0, 0, 40, 10000);", 1.5);
}



function ZenPad::trigger::onEnter(%trigger, %vehicle)
{ Zen::onEnter(%trigger, %vehicle, *IDMULT_CHAT_ALLPAD, true, true); }

function ZenPad::trigger::onContact(%trigger, %vehicle)
{ Zen::work(%trigger, %vehicle, 100, 5, 0, true); }

function ZenPad::trigger::onLeave(%trigger, %vehicle)
{ Zen::onLeave(%trigger, %vehicle); }


// From MultiplayerStdLib, trimmed (and don't want most of that stuff, as the script is long enough as it is)

function Zen::onEnter(%trigger, %object, %message, %isReady, %countdown)
{
   if(%message != "")
   {
      %output = %message;
      %soundFile = "";
      if(%message == *IDMULT_CHAT_HEALPAD)
      {
         %soundFile = "repair_ent.wav";
      }
      else if(%message == *IDMULT_CHAT_AMMOPAD)
      {
         %soundFile = "reload_ent.wav";
      }
      
      if(%isReady == true)
      {
         %output = %output @ " ";
         if(
            %trigger.wait == false ||
            %trigger.wait == "" ||
            (%trigger.reset <= getCurrentTime())    
         )
         {
            %output = %output @ *IDMULT_READY; 
         }
         else
         {
            %output = %output @ *IDMULT_NOT_READY;
            
            if(
               %countdown == true &&   
               %trigger.reset != ""  
            )
            {
               %output = %output @ " " @ *IDMULT_READY_IN_1;
               %remaining = timeDifference(%trigger.reset, getCurrentTime());
               %output = %output @ %remaining @ *IDMULT_READY_IN_2;            
            }         
         }
      }
      %player = playerManager::vehicleIdToPlayerNum(%object);
      if(%player != 0)
      {
         say(%player, %trigger, %output, %soundFile);
      }
   }
}

function Zen::onLeave(%trigger, %object)
{
   if(%object == %trigger.special)
   {
      %trigger.special.pad = "";
      %trigger.special = "";
   }
}

function Zen::work(%trigger, %object, %healRate, %ammoRate, %reset, %shutdown)
{
   if(
      (
         isShutDown(%object) == true || 
         %shutdown == false 
      ) &&
      (
         %trigger.wait == false ||   
         %trigger.wait == "" ||
         %trigger.special == %object 
      ) &&
      (
         %trigger.depleted == "" ||  
         %trigger.depleted == false
      )
   )   
   {
      if(%healRate > 0)
      {
         healObject(%object, %healRate);
      }
      
      if(%ammoRate > 0)
      {   
         reloadObject(%object, %ammoRate);
      }

      if(
         %reset > 0 && 
         %trigger.reset == "" 
      )
      {      
         %trigger.special = %object;
         %object.pad = %trigger; 
         schedule("Zen::depleted(" @ %trigger @ ");", (%reset / 3));
         %trigger.reset = schedule("Zen::recharged(" @ %trigger @ ");", %reset);
         %trigger.wait = true;
      }
   }
   else
   {
      if(
         %object == %trigger.special && 
         %shutdown == true &&           
         isShutDown(%object) == false   
      )
      {
         %trigger.special.pad = "";
         %trigger.special = "";      
      }
   }
}

function getFullPath(%object)
{
   // recursive function to get the path of this thing
   if(%object == 0)
   {
      return "";
   }
   
   %name = getObjectName(%object);
   
   if(%name == "MissionGroup")
   {
      return %name;
   }
   else
   {
      return (getFullPath(getGroup(%object)) @ "\\" @ %name);
   }
}
