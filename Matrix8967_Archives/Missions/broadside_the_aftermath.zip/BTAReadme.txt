Broadside The Aftermath was created by:
	/AD*Myamoto
Email:
	Myamoto@myamoto.com

This is a CTF map made  on behalf of all of us that love Broadside, but are sick of it being a demolitions exercise. 

