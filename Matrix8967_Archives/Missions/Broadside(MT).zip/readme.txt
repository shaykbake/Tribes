Welcome to DeviousLand Maps!

unzip the map files into your Tribes/base/missions directory

questions/comments contact Mojica at   misterdevious@hotmail.com
			     for more Devious Stuff go to http://members.xoom.com/mrdevious


these maps are weird, and they have lots of turrets/trees/terrain features.  They may require
more processor power than regular maps.  If the game crashes or lags frequently, try limiting the
number of people who can join.


---Mojica