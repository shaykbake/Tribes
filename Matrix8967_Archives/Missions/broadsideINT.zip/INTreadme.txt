Intensity maps, by: MetalSnake{IW}
==================================

Installation
============
To install the map, simply extract the files into your Tribes/Base/Missions directory.
If Tribes is running (such as a dedicated server) you will NEED to close and restart Tribes
in order for the new map(s) to be recognized.

Only servers need this map, so unless you are planning on hosting a server, or just want
to check them out, there is no need to install the map to play, simply find a server
hosting them. One example is IronWolves Den.


Disclaimer
==========
I will not be held responsible for any damages incurred by the use of this map. Period.
If you don't know what you are doing, drop me a line at crosfadr@gwi.net,
or find someone else who knows what they are doing.


On The Web
==========
Check out the Ironwolves site at http://ironwolves.cjb.net
Check out my other maps at http://www.gwi.net/~buzz37/maps.html


Thanks for your interest in my maps... I will continue to make more. If you think you
have any cool ideas, drop me a line at crosfadr@gwi.net and let them fly.