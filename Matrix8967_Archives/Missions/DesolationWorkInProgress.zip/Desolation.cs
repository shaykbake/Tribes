// FILENAME:	Deslotaion.cs
// TERRAIN:	The one from Bloody Brunch.  I would've preferred more cliffs farther out.
// AUTHORS:  	/ {HM} Sabre -^-
//==============================================================================================================

//---------------------
//Note to self: REDO THE LIGHTING!!!!
//---------------------

$missionName = "DM_Bloody_Brunch";	//Yes, I know this is wrong.  No, I do not care.

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

//=============================================================================================================//
//=============================================================================================================//
//These presets are importaint, as they set limits on AI, Drones, Scrap, and Rocks to reduce lag and prevent crashes.
//They are preset to what my computer can handle running non-dedicated with no guests.
//Set these values high if you feel your computer can handle larger numbers of AI and objects.

$CybridLimit = 30;	//I advise at least 25
$DroneLimit = 5;	//I advise at least 5
$ArtilleryLimit = 7;	//I advise at least 5
$RockLimit = 30;	//I advise at least 25
$DebrisLimit = 40;	//I advise at least 30

//These two presets determine the behavior of certain checks thoughout the mission.
//Increasing these values will increase the 'polish' of certain script effects, but will also put a bit more strain on the server.
//Set these really high if you feel your computer can handle additional script calculations.

$LightningCheckLimit = 15;	//I advise at least 5
$CybridCycleDelay = 1;		//Lowering this value will put more stress on the server
$DroneCycleDelay = 3;		//Lowering this value will put more stress on the server
$AIRoamSpeed = medium;		//AI movement speed.
$AIActionSpeed = high;		//AI movement speed.
$DroneSpeed = high;		//Drone movement speed.
$ArtillerySpeed = low;		//Artillery movement speed.

//These presets have little to do with performance, rather they bear on base difficulty of this mission.
//They represent the starting supply levels of the two factions, and the base and maximum 
	
$HumanStartScrap = 10;
$HumanStartOre = 0;
$CybridStartOre = 0;		//Increases random AI spawn rates
$CybridStartScrap = 0;		//Increases initial Drone spawn rate, and specific AI taskgroup size/frequency

//Difficulty modifiers
//These values specifically influence Cybrid strength and skill.  Alter with care.

$DifficultyStart = 1;		//MUST be greater than 0 to prevent errors, but less than 18
$DifficultyLimit = 20;		//MUST be less than 20 to prevent errors
$AILevelStart = 1;		//MUST be 1 or greater to prevent errors and mindless AI!
$AILevelLimit = 10;		//MUST be 10 or less to prevent errors and mindless AI!
$OreGoalBase = 5;		//These are completely up to you.
$OreGoalFactor = 10;		//Keep in mind, a player going solo needs $OreGoalBase + $OreGoalFactor to win.

//These kinda fit in all and none of the above categories...
$BaseDetectRange = 1500;	//Distance at which AI detect base.  Increase for more frequent base attacks.
$DroneDetectRange = 1250;	//Distance at which AI detect drones.  Increase for heavier drone escorts.
$AIDetectRange = 1000;		//Distance at which AI detect other AI.  Increase for greater AI coordination.
$ArtilleryAttackRange = 1500;	//Distance at which Artillery attack base.
$FirstDetectFactor = 2;		//Factor increase of AI's first detection cycle.

//=============================================================================================================//
//=============================================================================================================//

Pilot Pilot	
{
	name = "Transport";
	id = 30;
	skill = 1.0;
	accuracy = 1.0;
	aggressiveness = 0.1;	
	activateDist = 0.0;	
	deactivateBuff = 100.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Pilot	
{
	name = "Convoy Leader";
	id = 31;
	skill = 1.0;
	accuracy = 1.0;
	aggressiveness = 0.1;	
	activateDist = 0.0;	
	deactivateBuff = 100.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Pilot	
{
	name = "Fuel Cargo";
	id = 32;
	skill = 1.0;
	accuracy = 1.0;
	aggressiveness = 0.1;	
	activateDist = 0.0;	
	deactivateBuff = 100.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid1	
{
	name = "Cybrid";
	id = 41;
	skill = 0.1;
	accuracy = 0.1;
	aggressiveness = 0.1;	
	activateDist = 550.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid2	
{
	name = "Cybrid";
	id = 42;
	skill = 0.2;
	accuracy = 0.2;
	aggressiveness = 0.2;	
	activateDist = 600.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid3
{
	name = "Cybrid";
	id = 43;
	skill = 0.3;
	accuracy = 0.3;
	aggressiveness = 0.3;	
	activateDist = 650.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid4	
{
	name = "Cybrid";
	id = 44;
	skill = 0.4;
	accuracy = 0.4;
	aggressiveness = 0.4;	
	activateDist = 700.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid5	
{
	name = "Cybrid";
	id = 45;
	skill = 0.5;
	accuracy = 0.5;
	aggressiveness = 0.5;	
	activateDist = 750.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid6
{
	name = "Cybrid";
	id = 46;
	skill = 0.6;
	accuracy = 0.6;
	aggressiveness = 0.6;	
	activateDist = 800.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid7
{
	name = "Cybrid";
	id = 47;
	skill = 0.7;
	accuracy = 0.7;
	aggressiveness = 0.7;	
	activateDist = 850.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid8
{
	name = "Cybrid";
	id = 48;
	skill = 0.8;
	accuracy = 0.8;
	aggressiveness = 0.8;	
	activateDist = 900.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid9
{
	name = "Cybrid";
	id = 49;
	skill = 0.9;
	accuracy = 0.9;
	aggressiveness = 0.9;	
	activateDist = 950.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot Cybrid10
{
	name = "Cybrid";
	id = 50;
	skill = 1.0;
	accuracy = 1.0;
	aggressiveness = 1.0;	
	activateDist = 1000.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot CybridGatherer
{
	name = "Cybrid Salvage Unit";
	id = 51;
	skill = 1.0;
	accuracy = 1.0;
	aggressiveness = 1.0;	
	activateDist = 500.0;	
	deactivateBuff = 200.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 0.3;
	LOSFreq = 0.1;
};

Pilot CybridArtillery
{
	name = "Cybrid Artillery";
	id = 66;
	skill = 0.5;
	accuracy = 0.5;
	aggressiveness = 1.0;	
	activateDist = 1500.0;	
	deactivateBuff = 250.0;
	targetFreq = 1.0;
	trackFreq = 0.1;
	fireFreq = 1.0;
	LOSFreq = 0.1;
};

function setDefaultMissionOptions()
{
	//dbecho("setDefaultMissionOptions()");

	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = true;
	$server::AllowTeamPurple = false;

	$server::disableTeamRed = true;
	$server::disableTeamBlue = false;
	$server::disableTeamYellow = false;
	$server::disableTeamPurple = true;
}

function copyobject(%this, %name)
{
	//dbecho("copyobject(%this, ");

	%this = getobjectid(%this);
	storeObject(%this, "copy.tmp");
	if(%name != "")
		%copy = loadObject(%name, "copy.tmp");
	else
		%copy = loadObject(getObjectName(%this), "copy.tmp");
	return %copy;
}

function onMissionLoad()
{
	//dbecho("onMissionLoad()");

	setGameInfo("Welcome to our little corner of hell.  I heard what happened down south.  Damn tragic.  Pray that we fare better...\n\nWe're the last human-held outpost in the area ...the 'brids burned the rest...  This was going to be a staging area for evacuation, but now we're cut off.  We're going to have to pull this off with what little resources we can get past Cybrid lines.\n\nDelta Sector did manage to launch their ships before they were overrun.  The ion storm should hide them from radar long enough to engage the Cybrid mothership in orbit.  We'll have enough of a window to get our ships through, if they succeed.  Pray that they do.\n\nWe've recieved word of a transport coming through with supplies.  I guess the storm is keeping those glitches grounded.  We need you to protect it while it unloads.  Make sure <F6>nothing<F0> gets through, we won't be getting another chance at this.");

	$difficulty = $difficultyStart;
	$AIlevel = $AIlevelStart;
	$missionstarted = 0;
	$missionloaded = 0;

	$ionlevel = 100;
	$ionflux = -1;

	$HumanBase = getobjectid("Missiongroup\\yellowbase");
	$HumanBase.center = getobjectid("Missiongroup\\yellowbase\\HQ");
	$HumanBase.accelerator = getobjectid("Missiongroup\\yellowbase\\Accelerator");
	$HumanBase.drill = getobjectid("Missiongroup\\yellowbase\\Drill");
	$HumanBase.refinery = getobjectid("Missiongroup\\yellowbase\\Refinery");
	$HumanBase.attacktime = getsimtime();
	$HumanBase.targettime = getsimtime();
	$HumanBase.artillerytime = getsimtime();
	
	$CybridBase = getobjectid("Missiongroup\\redbase");
	$CybridDump = getobjectid("Missiongroup\\redbase\\Entrance");
	$Cybridbase.distance = 10000;
	$ActiveAI = 0;
	$ActiveDrone = 0;

	$Outpost1 = getobjectid("Missiongroup\\Cybrids\\Outpost1");
	$Outpost1.center = getobjectid("Missiongroup\\Cybrids\\Outpost1\\Beacon1");
	$Outpost2 = getobjectid("Missiongroup\\Cybrids\\Outpost2");
	$Outpost2.center = getobjectid("Missiongroup\\Cybrids\\Outpost2\\Beacon2");

	$rock1 = getobjectid("Missiongroup\\objects\\rock1");
	$rock2 = getobjectid("Missiongroup\\objects\\rock2");
	$rock3 = getobjectid("Missiongroup\\objects\\rock3");
	$rocktrigger = getobjectid("Missiongroup\\objects\\rocktrigger");
	$debris1 = getobjectid("Missiongroup\\objects\\debris1");
	$debris2 = getobjectid("Missiongroup\\objects\\debris2");
	$debris3 = getobjectid("Missiongroup\\objects\\debris3");
	$debris4 = getobjectid("Missiongroup\\objects\\debris4");
	$debristrigger = getobjectid("Missiongroup\\objects\\debris");
	$lightning = getobjectid("Missiongroup\\objects\\lightning");

	$Drone = "Missiongroup\\Cybrids\\drones";
	$Flyer = "Missiongroup\\flyers";
	$mountaintopflyer = getobjectid("Missiongroup\\flyers\\flyer1");

	$HumanOre = $HumanStartOre;
	$HumanScrap = $HumanStartScrap;
	$CybridOre = $CybridStartOre;
	$CybridScrap = $CybridStartScrap;

	$HumanTurrets = 0;
	$CybridTurrets = 0;

	$CybridCount = 0;
	$DroneCount = 0;
	$ArtilleryCount = 0;
	$RockCount = 0;
	$DebrisCount = 0;

	cdAudioCycle("Watching", "Cloudburst", "Terror");
}

function onMissionStart()
{
	//dbecho("onMissionStart()");

	venusSounds();
	deleteobject("Missiongroup\\Debris");
	$Debris = newObject("Debris", simGroup);
	addToSet("Missiongroup", $Debris);
	deleteobject("Missiongroup\\Triggers");
	$Triggers = newObject("Triggers", simGroup);
	addToSet("Missiongroup", $Triggers);

	deleteobject("Missiongroup\\CybridAI");
	$CybridAI = newObject("CybridAI", simGroup);
	addToSet("Missiongroup", $CybridAI);
	deleteobject("Missiongroup\\DroneAI");
	$DroneAI = newObject("DroneAI", simGroup);
	addToSet("Missiongroup", $DroneAI);

	deleteobject("Missiongroup\\Turrets");
	$Turrets = newObject("Turrets", simGroup);
	addToSet("Missiongroup", $Turrets);
	deleteobject("Missiongroup\\DestroyedObjects");
	$DestroyedObjects = newObject("DestroyedObjects", simGroup);
	addToSet("Missiongroup", $DestroyedObjects);

	damagearea($mountaintopflyer, 0,0,10,10,1750);
	damagearea($mountaintopflyer, 16,40,42.5,60,1750);
	damagearea($mountaintopflyer, -16,40,42.5,60,3500);
	damagearea($mountaintopflyer, 16,-40,42.5,60,7000);
	damagearea($mountaintopflyer, -16,-40,42.5,60,3500);

	$missionloaded = true;

	checkstartbounds();
}

//Addition
//====================================

function player::onAdd(%this)
{
	//dbecho("player::onAdd(%this)");

	if(strAlign(1, left, getname(%player))=="/")
   	{
      		say(0,0,""@getname(%player)@" joined the game.");
   	}
      	say(%this,0,"This map is still in development, and so much of the mission instruction is incomplete.  Please explore the map.  Watch out for marauding AI, though.  Where there is one, there may be more, and many a nasty surprise hides under a cloak...");
}

function vehicle::onadd(%this)
{
	//dbecho("vehicle::onadd(%this)");

	if(getteam(%this)== *IDSTR_TEAM_BLUE)
	{
		setteam(%this, *IDSTR_TEAM_YELLOW);
	}

	%this.loadlimit = 0;
	for(%i=1;%i<(getVehicleAvailableMass(%this)*4);%i++)
	{
		%this.loadlimit += 0.25;
	}
	%this.scrapload = 0;
	%this.oreload = 0;
	%this.silent = 0;

	%player = playermanager::vehicleidtoplayernum(%this);
	if(%player)
	{
		if( !$missionstarted )
			schedule("say("@%player@", $humanbase.center, \"<F1>TAC-COM: <F6>Our supply transport will be landing on the mountain any moment now.  Make sure it unloads safely.\");", 2.5);
		else
			if( %player.allowed )
			{
				schedule("say("@%player@", $humanbase.center, \"<F1>TAC-COM: <F6>You're late, pilot.  Get on the bounce!\");", 2.5);
				$MissionPlayerCount++;
			}
			else
			{
				%x = getposition(%this, x);
				%y = getposition(%this, y);
				%z = getterrainheight(%x, %y) - 25;
				setposition(%this, %x, %y, %z);
				%this.silent = 1;
				messagebox(%player, "Sorry, but you cannot join the mission at this point.  You may return to the lobby or watch the mission with the orbital camera.");
				schedule("damagearea("@%this@", 0, 0, 5, 5, 50000);", 0.25);
				return;
			}

		%player.saytime = getsimtime();
		order(%this, guard, 0);
		if(%this.loadlimit)
			say(%player, 1234, "<F5>Your vehicle has room for "@%this.loadlimit@" tons of scrap.");
		else
			say(%player, 1234, "<F5>Your vehicle does not have enough room for a cargo bay!");
	}
}

function checkstartbounds(%this)
{
	//dbecho("checkstartbounds(%this)");

	%c = playerManager::getPlayerCount();
	for(%i=0;%i<%c;%i++)
	{
		%player = playerManager::getPlayerNum(%i);
		%this = playerManager::playerNumToVehicleId(%player);
		if(getdistance(%this, $humanbase.center) > 150)
			return startmission();
	}
	schedule("checkstartbounds();", 15);
}

function startmission()
{
	//dbecho("startmission()");

	$missionstarted = 1;
	%c = playermanager::getplayercount();
	$MissionPlayerCount = 0;
	for(%i=0;%i<%c;%i++)
	{
		%p = playerManager::getPlayerNum(%i);
		%v = playerManager::playernumtovehicleid(%p);
		%p.allowed = 1;
		if( isobject( %v )  &&  !isgroupdestroyed( %v ) )
		{
			$MissionPlayerCount++;
			%p.allowed = 0;
		}
	}

	$Mission::Objective1 = 0;
	$Mission::Objective2 = 0;
	$Mission::Objective2::Timer = 180;

	say(0,$mountaintopflyer, "<F2>Transport: <F6>Transport here, setting down.  Where's the welcoming party?");
	schedule("say(0, $humanbase.center, \"<F1>TAC-COM: <F6>Good to see you.  We have an escort en route.  How was your flight?\");", 5);
	schedule("playsound(0, \"sfx_quake.wav\", IDPRF_2D, "@$lightning@");", 2.5);

	schedule("say(0,$mountaintopflyer, \"<F2>Transport: <F6>I took some flak flying over 'brid territory, but I'll live.  The cargo's intact, but the bay doors got fried.  I'll need a little help prying them open.\");", 10);
	schedule("say(0,$humanbase.center, \"<F1>TAC-COM: <F6>We already have a crew out there.  Get that stuff over here as soon as possible, we need to launch ASAP.\");", 17.5);
	schedule("say(0,$mountaintopflyer, \"<F2>Transport: <F6>Hold on, I'm getting some wierd readings...\");", 25);
	schedule("playsound(0, \"sfx_quake.wav\", IDPRF_2D, "@$lightning@");", 25);
	schedule("playsound(0, \"sfx_quake.wav\", IDPRF_2D, "@$lightning@");", 26);
	schedule("playsound(0, \"sfx_quake.wav\", IDPRF_2D, "@$lightning@");", 27);
	schedule("say(0,$mountaintopflyer, \"<F2>Transport: <F6>Oh my God...!\");", 28);
	

	%x = getposition($mountaintopflyer, x) + 10;
	%y = getposition($mountaintopflyer, y) + 10;

	schedule("lightningstrike("@%x@", "@%y@");", 30);
	schedule("damagearea($mountaintopflyer, 10, 10, -10, 20, 1000);", 30);
	schedule("damagearea($mountaintopflyer, 10, 10, -10, 20, 1000);", 32.5);
	schedule("damagearea($mountaintopflyer, 10, 10, -10, 20, 1000);", 35);

	schedule("say(0,$humanbase.center, \"<F1>TAC-COM: <F6>DAMMIT!  There goes our ride...  Christ and Hunter...\");", 35);

	schedule("say(0,$humanbase.center, \"<F1>TAC-COM: <F6>Hey, look at the sky!  The 'brid ship is breaking up.  Looks like our boys came through.  Dammit, at least they died thinking we had a chance...\");", 45);
	schedule("say(0,$humanbase.center, \"<F1>TAC-COM: <F6>What...?  I don't believe this...   We have ANOTHER transport inbound!  ETA 15 minutes!  We may make it out of here!  Alright, NO 'brids get through!  NONE!\");", 60);
	schedule("say(0,$humanbase.center, \"<F1>TAC-COM: <F6>Crap... Alright, it looks like you guys are gonna be busy tonight.  The transport doesn't have enough ore to shield all our ships against the storm...\");", 60);
	schedule("say(0,$humanbase.center, \"<F1>TAC-COM: <F6>That Cybrid mothership probably had a good deal on its hull, so you might be able to extract or from the debris.  Bring it back to the \");", 75);

	droprandomdrone(2, 3, 1);

	schedule("dropBeacons();", 25);
	schedule("missionflow();", 32.5);
}

function turret::onadd(%this)
{
	//dbecho("turret::onadd(%this)");

	%this.turret = 1;
	if( !$missionloaded )
	{
		if( getteam(%this) == *IDSTR_TEAM_YELLOW )
		{
			if( getobjectname(%this) != "TempTurret" )
				schedule("createbackupturret("@%this@");", 5);
			$HumanTurrets++;
		}
		else if( getteam(%this) == *IDSTR_TEAM_RED )
			$CybridTurrets++;
	}
}

function createbackupturret(%this)
{
	//dbecho("createbackupturret(%this)");

	if( $missionloaded )
	{
		%this.copy = copyobject(%this, "Turret");
		%that = %this.copy;
		addtoset($turrets, %that);
		setposition(%that, 0, -10000, 10000);
		setteam(%that, *IDSTR_TEAM_NEUTRAL);
	}
	else
	{
		schedule("createbackupturret("@%this@");", 5);
	}
}

function dropBeacons()
{
	dropBeacon($Outpost1);
	dropBeacon($Outpost2);
}

function dropBeacon(%this)
{
	%xold = getposition(%this.center, x);
	%yold = getposition(%this.center, y);
	%x = %xold / 2 + randomint(-250, 250);
	%y = %yold / 2 + randomint(-250, 250);
	setUpOutpost(%this, 0, %xold - %x, %yold - %y);
}

function setUpOutpost(%this, %that, %xold, %yold)
{
	%that = getnextobject(%this, %that);
	if( %that )
	{
		%x = getposition(%that, x) - %xold;
		%y = getposition(%that, y) - %yold;
		%z = getterrainheight(%x, %y) - 1;
		%r = getposition(%that, rot);
		if( getobjectname(%that) != "Beam")
			schedule("droppod("@%x@", "@%y@", "@%z + 5000@", "@%x@", "@%y@", "@%z@");", randomint(1, 8) / 4);
		else
			%z -= 50;
		setposition(%that, %x, %y, %z, %r);
		setUpOutpost(%this, %that, %xold, %yold);
	}
}

  //=============================================================================//
 //Mission Flow									//
//=============================================================================//

function missionflow()
{
	//dbecho("missionflow()");

	if($missionstarted)
	{	
		//Lightning & effects

		if( $lightning )
		{
			$ionflux = randomint($ionflux, -1);
			$ionLevel -= $ionflux;
			if($ionLevel <= 0)
				$ionLevel = 0;
		}
		else
			$ionlevel= 0;
	
		%l = randomint(1, ($ionlevel + 200));
		if(%l > 200)
		{
			playsound(0, "sfx_quake.wav", IDPRF_2D, $lightning);
			schedule("lightningstrike();", randomint(1, 9) + 0.125);	//boom!
		}
		else if(%l > 175)
		{
			schedule("lavaglow();", randomint(1, 4) + 0.25);	//asthetic
		}
	
		//AI	
	
		if($Cybridcount < $CybridLimit)
		{
			%p = ( 10 * $MissionPlayerCount ) + $Cybridore + $difficulty + 1;
			%c = ( $Cybridcount * 5 ) + ( $ionlevel / 5 ) + ( $dronecount * 10 ) + %p;
			if( randomint( 1, %c ) <= %p ) 
			{
				%a = randomint(0, 15 - $MissionPlayerCount) + 0.375;
				schedule("droprandomcybrid();", %a);
				if(!%a)
					if($ArtilleryCount < $ArtilleryLimit)
						schedule("createartillery();", 0.5);
			}
		}
	
		if($CybridCount)
			if(!$ActiveAI)
				schedule("RoamAI("@getnextobject($CybridAI, 0)@");", 0.625);
		$ActiveAI = 0;
	
		//Rock Drops			
	
		%l = randomint(1, 150 + $ionlevel);	//Reroll
		if(%l <= 130)
		{
			schedule("droprock("@randomint(2000, 8000)@");", randomint(1, 10) + 0.75);
		}
		else if(%l <= 140)
		{
			%x = randomint(-%size, %size);
			%y = randomint(-%size, %size);
			%z = getterrainheight(%x, %y) + 2000;

			%r = randomint(1, 10);		

			schedule("droppod("@randomint(-8000, 8000)@", "@randomint(-8000, 8000)@", 5000, "@%x@", "@%y@", "@%z@");", %r);
			$ionlevel += $ionflux * %r - %r;
		}

		//Drones

		if( $CybridDump )
		{
			if( $DroneCount )
				if( !$ActiveDrone )
					schedule("RoamDrone(getnextobject("@$DroneAI@", 0));", 0.875);
			$ActiveDrone = 0;

			if( $DroneCount < $DroneLimit )
			{
				if( $CybridTurrets >= 4 )
				{
					if($CybridScrap >= 10)
					{
						$CybridScrap -= 10;
						%Drone = droprandomdrone(3, 1);
						schedule("createescort("@%drone@");", 2.5);
					}
				}
				else
					if(%l < 3)
						schedule("droprandomdrone("@%l@");", 1);
			}

			for(%i=0;%i<$MissionPlayerCount;%i++)
			{
				%player = playerManager::getPlayerNum(%i);
				%this = playerManager::playerNumToVehicleId(%player);
				if($Cybridbase.distance)
				{
					%d = getdistance(%this, $Cybriddump);
					if(%d)
						if( %d < $Cybridbase.distance )
							schedule("cybridbase"@$Cybridbase.distance@"("@%this@", "@$MissionPlayerCount@");", 1.5);
				}
			}
		}

		//Drill

		if(%l < 5)
			if( !isgroupdestroyed($HumanBase.drill) )
				$HumanOre += 0.25;
	
		//Difficulty

		$difficulty += 0.25;
		if($difficulty > $DifficultyLimit)
			$difficulty = $DifficultyLimit;
	
		if( $AIlevel >= $AILevelLimit )
			$AILevel = $AILevelLimit;
		else
			$AIlevel += 0.125;


		if( !$Mission::Objective1 )
		{
			if( $humanore >= ($OreGoalBase + ($OreGoalFactor * $MissionPlayerCount))  &&  !isgroupdestroyed($HumanBase.accelerator) )
			{
				$Mission::Objective1 = 1;
				say(0, $HumanBase.center, "<F1>TAC-COM: <F6>{text pending, objective 1 completed}");
			}
		}
		else
		{
			if( $Mission::Objective2 )
				victory();
		}

		if( !$Mission::Objective2 )
		{
			$Mission::Objective2::Timer--;
			if( !$Mission::Objective2::Timer )
			{
				findLandingSite();
			}
		}

		schedule("missionflow();", 5);
	}
}

  //---------------------//
 //Environmental	//
//---------------------//

function lightningstrike(%x, %y)
{
	//dbecho("lightningstrike(%x, ");

	$lightning.striking = 1;
	
	if(%x == "")
	{
		%h = 0;
		for(%i=0;%i<$LightningCheckLimit;%i++)
		{
			%d = 8000 - (8000 * %i / $LightningCheckLimit);
			%x2 = randomint(-%d, %d);
			%y2 = randomint(-%d, %d);
			%z2 = getterrainheight(%x2, %y2);
			if(%z < %z2)
			{
				%z = %z2;
				%x = %x2;
				%y = %y2;
				%t = %i + 1;
			}
		}
	}
	else
	{
		%z = getterrainheight(%x, %y);
	}
	setposition($lightning, %x, %y, %z - 50);
	echo("LIGHTNING STRIKE AT ("@%x@", "@%y@", "@%z@") ");

	playSound(0, "sfx_thunder1.wav", IDPRF_2D, 1);
	fadeevent(0, out, 0.25, 1, 1, 2);
	schedule("playSound(0, \"sfx_thunder1.wav\", IDPRF_2D, 2);", 0.1);
	schedule("playSound(0, \"sfx_thunder1.wav\", IDPRF_2D, 3);", 0.2);
	schedule("playSound(0, \"sfx_thunder2.wav\", IDPRF_2D, 4);", 0.25);
	schedule("fadeevent(0, in, 2.5, 2, 1.5, 1);", 0.3);

	schedule("damagearea("@$lightning@", 0, 0, 50, 25, 100000);", 0.25);
	schedule("damagearea("@$lightning@", 0, 0, 50, 50, 10000);", 0.5);
	schedule("damagearea("@$lightning@", 0, 0, 50, 75, 1000);", 0.75);
	schedule("damagearea("@$lightning@", 0, 0, 50, 100, 100);", 1);
	schedule("setposition("@$lightning@", 12000, 0, 5000);", 2);

	schedule("$lightning.striking = 0;", 3);

	$ionlevel -=  randomint(10, 100);
}

function lavaglow()
{
	//dbecho("lavaglow()");

	if(!$lightning.striking)
	{
		fadeevent(0, out, 0.75, 0.15, 0, 0);
		schedule("fadeevent(0, in, 1, 0.15, 0, 0);", 0.80);
		if($RockCount)
		{
			%this = pick($Debris);
			damageobject(%this, 1500);
			damagearea(%this, 0, 0, 0, 50, 500);

			playsound(0, "sfx_quake.wav", IDPRF_2D);
		}
	}
}

function droprock(%size)
{
	//dbecho("droprock(%size)");

	%r = randomint(1, 5);
	if($rockcount < $RockLimit)
	{
		if(%r <= 3)
		{
			%v = randomint(2, 4) / 2;
			%d = copyobject($rock[%r], "rock");
			addtoset($Debris, %d);
			%t = copyobject($rocktrigger, "rocktrigger");
			addtoset($Triggers, %t);		

			%x = randomint(-%size, %size);
			%y = randomint(-%size, %size);
			%z = getterrainheight(%x, %y);

			droppod(0, 0, 7500, %x, %y, %z);

			%time = sqrt((%x * %x) + (%y * %y) + ((7500 - %z) * (7500 - %z))) / 400;
			schedule("setposition("@%d@", "@%x@", "@%y@", "@%z@", "@(10 * randomint(1, 36))@", "@(10 * randomint(1, 36))@");", %time );
			schedule("setposition("@%t@", "@%x@", "@%y@", "@%z@");", %time );
			schedule("damagearea("@%d@", 0, 0, 0, "@randomint(10, 50)@", "@randomint(100, 500)@");", %time + 0.1);
			%d.trigger = %t;
			%t.object = %d;
			%d.value = %v * %r;

			$ionlevel -= %v;
			$rockcount++;
		}
		
	}
	else if(%r == 1)
	{
		echo("Too many rocks, dropping a dummy");
		%x = randomint(-%size, %size);
		%y = randomint(-%size, %size);
		%z = getterrainheight(%x, %y) - 5;

		droppod(0, 0, 7500, %x, %y, %z);
		$ionlevel += $ionflux;
	}
}

  //---------------------//
 //AI & Behavior	//
//---------------------//

function droprandomcybrid(%disablepod, %r, %p, %x, %y, %z)
{
	//dbecho("droprandomcybrid(%disablepod, ");

	if(!%r)
		%r = randomint(1, $difficulty);
	%AI = loadObject("Cybrid", "multiplayer\\Desolation\\Cybrid"@%r@".veh");
	addtoset($CybridAI, %AI);

	if(!%p)
	{
		%p = randomint(41, 40 + $AILevel);
		%p = randomint(%p, 40 + $AILevel);
	}
	setPilotId(%AI, %p);
	%AI.pilot = %p;

	if(!%disablepod)
	{
		setposition(%AI, 8000, 0, 5075);
		if(!%x)
			%x = randomint(-8000, 8000);
		if(!%y)
			%y = randomint(-8000, 8000);
		if(!%z)
			%z = getterrainheight(%x, %y);
		droppod(randomint(-6000, 6000), randomint(-6000, 6000), 4000, %x, %y, %z, %AI);

		schedule("picktarget("@%AI@", $FirstDetectFactor);", 30);
	}

	$Cybridcount++;

	return %AI;
}

function roamAI(%this)
{
	//dbecho("roamAI(%this)");

	$ActiveAI = 1;
	if( isobject(%this) )
	{
		if( !isgroupdestroyed(%this) )
		{
			order(%this, cloak, true);
			if( !isobject(%this.target)  ||  isgroupdestroyed(%this.target) )
				%this.target = 0;
			if( !%this.target )
			{
				%id = gettargetid(%this);
				if( %id )
					%this.target = %id;
				else if( !picktarget(%this, 1) )
				{
					order(%this, clear);
					%x = randomint(-6000, 6000);
					%y = randomint(-6000, 6000);
					%z = getterrainheight(%x, %y);
					order(%this, speed, $AIRoamSpeed);
					schedule("order("@%this@", guard, "@%x@", "@%y@", "@%z@");", 0.5);
				}
			}
			else 
			{
				%team = getteam(%this.target);
				if(%team == getteam(%this))
				{
					%target = gettargetid(%this.target);
					if( %target  &&  %team != getteam(%target) )
					{
						order(%this, speed, $AIActionSpeed);
						order(%this, attack, %target);
					}
				}
			}
		}
		else
		{
			$CybridCount--;
			schedule("deleteobject("@%this@");", 0.25);
		}
	}

	if($CybridCount)
	{
		%AI = getnextobject($CybridAI, %this);
		if(%AI)
			schedule("roamAI("@%AI@");", $CybridCycleDelay);
		else
			schedule("roamAI("@getnextobject($CybridAI, 0)@");", $CybridCycleDelay);
	}
}

function picktarget(%this, %factor)
{
	//dbecho("picktarget(%this, ");

	if( getdistance(%this, $HumanBase.center) < ($BaseDetectRange * %factor - $ionlevel) )
	{
		order(%this, clear);
		order(%this, speed, $AIActionSpeed);
		order(%this, attack, pick($HumanBase));
		return 1;
	}
	else
	{
		if( $DroneCount )
			if( pickdrone(%this, 0, %factor) )
				return 1;
		if( $CybridCount )
			return pickAI(%this, 0, %factor);
	}
}

function pickdrone(%this, %that, %factor)
{
	//dbecho("pickdrone(%this, ");

	%that = getnextobject($DroneAI, %that);
	if(%that)
	{
		%d = getdistance(%this, %that);
		if( %d  &&  %d < ($DroneDetectRange * %factor - $ionlevel) )
		{
			%this.target = %that;
			order(%this, clear);
			order(%this, speed, $AIActionSpeed);
			order(%this, guard, %this.target);
			return 1;
		}
		else
			return pickDrone(%this, %that, %factor);
	}
	return 0;
}

function pickAI(%this, %that, %factor)
{
	//dbecho("pickAI(%this, ");

	%that = getnextobject($CybridAI, %that);
	if(%that)
	{
		%d = getdistance(%this, %that);
		if( %d  &&  %d < ($AIDetectRange * %factor - $ionlevel) )
		{
			if(%this.pilot < %that.pilot)
			{
				%this.target = %that;
				order(%this, speed, $AIActionSpeed);
				order(%this, guard, %that);
				return 1;
			}
			else if( !%that.target )
			{
				order(%this, speed, $AIActionSpeed);
				order(%that, guard, %this);
				%that.target = %this;
			}
		}
		else
			return pickAI(%this, %that, %factor);
	}
	return 0;
}

function droprandomdrone(%r, %disablepod)
{
	//dbecho("droprandomdrone(%r, ");

	if($DroneCount < $DroneLimit)
	{
		%Drone = copyobject($Drone@"\\drone1", "Drone");
		addtoset($DroneAI, %Drone);
		setTeam(%Drone, *IDSTR_TEAM_RED);
		setPilotId(%Drone, 51);
		%Drone.pilot = 51;

		setposition(%Drone, 8000, 8000, 5075);

		%rand = 50;
		if(!%r)
		{
			%r = randomint(1, 8);
			%disablepod = true;
			%rand = 500;
		}
		if(%r > 2)
		{
			%this = $CybridDump;
		}
		else
			%this = $Outpost[%r];

		%x = getposition(%this, x) + randomint(-%rand, -(%rand / 2));
		%y = getposition(%this, y) + randomint(-%rand, %rand);
		%z = getterrainheight(%x, %y);
		if(!%disablepod)
			droppod(%x + randomint(-500, 500), %y + randomint(-500, 500), %z + randomint(2000, 4000), %x, %y, %z, %Drone);
		else
			schedule("redrop("@%Drone@");", 2.5);

		%Drone.action = 0;
		$DroneCount++;

		return %Drone;
	}
	else
		echo("Too many Drones, spawn canceled.  "@$DroneLimit@" drones are allowed, increase $DroneLimit to allow more drones");
}

function roamdrone(%this)
{
	//dbecho("roamdrone(%this)");

	//dbecho("==========Drone program initialized==========");
	if( isobject(%this) )
	{
		//dbecho("Drone existance confirmed");
		if(!isgroupdestroyed(%this))
		{
			//dbecho("Drone functionality confirmed");
			%that = %this.action;
			%distance = %this.distance;
			if( !isobject(%that)  ||  isgroupdestroyed(%that) )
				%this.action = 0;
			if( !%this.action )
				%this.distance = 65536;
			else
				%this.distance = getdistance(%this, %this.action);
			if(%this.action != $CybridDump)
			{
				//dbecho("Drone is not returning to base");
				if( !scandebris(%this, getNextObject($Debris, 0), 0) )
				{
					//dbecho("Drone has no target, setting drone to idle");
					%this.action = 0;
					order(%this, clear);
					order(%this, speed, $DroneSpeed);
					order(%this, guard, randomint(-8000, 8000), randomint(-8000, 8000));
				}
				else
				{
					//dbecho("Drone has a target");
					if(%this.action != %that)
					{
						//dbecho("Drone has aquired a new target");
						%factor = 1 - ((%this.scrapload + %this.oreload) / %this.loadlimit);

						//dbecho(%this@" is "@%this.distance@"m away from "@getobjectname(%that)@" ("@%that@") with loadlimit of "@%this.loadlimit@" tons and "@(%factor * 100)@" percent empty, "@$RockCount@" rocks and "@$DebrisCount@" debris");
										
						if(%factor < 0.1)
						{
							//dbecho("Drone is full and will return to base");
							order(%this, clear);
							order(%this, guard, $CybridDump);
							%this.action = $CybridDump;
						}
						else
						{
							//dbecho("Drone has room and is moving to harvest");
							order(%this, clear);
							order(%this, guard, %this.action);
						}
					}
					else 
					{
						//dbecho("Drone already has a target");
						if(%this.distance < 150)
						{
							//dbecho("Drone is within harvesting distance");
							if(%this.action.value > 0)
							{
								//dbecho("Drone recognizes target as harvestable");
								%empty = %this.loadlimit - (%this.scrapload + %this.oreload);
								if( %empty )
								{
									//dbecho("Drone has room to hold cargo");
									if(getobjectname(%this.action) == "debris")
									{
										//dbecho("Drone is harvesting scrap");
										%this.scrapload += %empty;
										%this.action.value -= %empty;
										if(%this.action.value <= 0)
										{
											//dbecho("Drone is overfull");
											%this.scrapload += %this.action.value;
											%this.action.value -= %this.action.value;
											$DebrisCount--;
											schedule("deleteobject("@%this.action@");", 0.75);
											schedule("deleteobject("@%this.action.trigger@");", 0.75);
											
											%this.action = 0;
										}
									}
									else
									{
										//dbecho("Drone is harvesting ore");
										%this.oreload += %empty;
										%this.action.value -= %empty;
										if(%this.action.value <= 0)
										{
											//dbecho("Drone is overfull");
											%this.oreload += %this.action.value;
											%this.action.value -= %this.action.value;
											$RockCount--;
											schedule("deleteobject("@%this.action@");", 0.75);
											schedule("deleteobject("@%this.action.trigger@");", 0.75);
											
											%this.action = 0;
										}
									}							
								}
								else
								{
									//dbecho("Drone is full");
									order(%this, clear);
									order(%this, guard, $CybridDump);
									%this.action = $CybridDump;
									%this.distance = getdistance(%this, $CybridDump);
								}
							}
						}
						else 
						{
							//dbecho("Drone is not within harvesting distance");
							if(%distance - 1 <= getdistance(%this, %this.action))
							{
								//dbecho("Drone is not moving properly");
								order(%this, clear);
								order(%this, guard, %this.action);
							}
						}
					}
				}
			}
			else
			{
				//dbecho("Drone is returning to base");
				if(%distance - 1 <= getdistance(%this, $CybridDump))
				{
					//dbecho("Drone is not moving properly");
					order(%this, clear);
					order(%this, guard, $CybridDump);
				}
			}
		}
		else
		{
			//dbecho("Drone is destroyed, deleting drone");
			$DroneCount--;
			schedule("deleteobject("@%this@");", 0.1);
		}
	}
	
	//dbecho("==========Drone program complete==========");
	if( ($DroneCount + $ArtilleryCount) )
	{
		$ActiveDrone = 1;
		%AI = getnextobject($DroneAI, %this);
		if( %AI )
			if( getobjectname(%AI) == "Drone" )
				schedule("roamDrone("@%AI@");", $DroneCycleDelay);
			else
				schedule("roamArtillery("@%AI@");", $DroneCycleDelay);
		else
			schedule("roamDrone("@getnextobject($DroneAI, 0)@");", $DroneCycleDelay);
	}
}

function scandebris(%this, %debris, %num)
{
	//dbecho("scandebris(%this, ");

	if(%debris)
	{
		if(%debris != %this.action)
		{
			%d = getdistance(%this, %debris);
			if( %d )
				if(%d < %this.distance)
				{
					%this.action = %debris;
					%this.distance = %d;
				}
		}
		return scandebris(%this, getnextobject($Debris, %debris), 1);
	}
	return %num;
}

function createescort(%this)
{
	//dbecho("createescort(%this)");

	%r = randomint(1,3);
	for(%i=0;%i<%r;%i++)
	{
		%escort = droprandomcybrid(1);
		setposition(%escort, 8000, 8000, 5075);

		if(%escort)
		{
			%x = getposition(%this, x) + randomint(-50, 50);
			%y = getposition(%this, y) + randomint(-50, 50);
			schedule("droppod(0, 0, 5000, "@%x@", "@%y@", "@getterrainheight(%x, %y)@", "@%escort@");", randomfloat(0, 3));

			order(%escort, guard, %this);
			%escort.target = %this;
		}
	}
}

function createartillery(%num, %this)
{
	//dbecho("createartillery(%num, ");

	if(!%num)
		%num = randomint(1, 3);
	if(%num != 3)
		%location = $Outpost[%num];
	else
		%location = $CybridDump;

	if( !isgroupdestroyed(%location) )
	{
		%fx = 50 * randomint( -5, 5 );
		%fy = 100 * randomint( -5, 5 );
		if( %fx  ||  %fy )
		{
			%x = getposition( %location, x ) + %fx;
			%y = getposition( %location, y ) + %fx;
			%z = getterrainheight( %x, %y );

			%Artillery = newObject( "Artillery", Tank, 90 );
			addtoset( $DroneAI, %Artillery );
			setteam(%Artillery, *IDSTR_TEAM_RED);
			setPilotId( %Artillery, 66 );
			%Artillery.pilot = 66;

			setposition( %Artillery, 8000, 8000, 5075 );

			droppod( %x, %y, %z + 4000, %x, %y, %z, %Artillery );
	
			$ArtilleryCount++;

			if( %this )
				order( %Artillery, attack, %this );

			reloadobject(%Artillery, -5000);

			return %Artillery;
		}
	}
}

function roamArtillery(%this)
{
	//dbecho("roamArtillery(%this)");

	if( !isgroupdestroyed( %this ) )
	{
		order(%this, cloak, true);
		%distance = getdistance(%this, $Humanbase.center);
		if(!gettargetid(%this))
			if(%distance < $ArtilleryAttackRange)
			{
				order(%this, clear);
				order(%this, attack, pick($Humanbase));
			}
			else
			{
				order(%this, clear);
				order(%this, speed, $ArtillerySpeed);
				order(%this, guard, $Humanbase.center);
			}
		%this.distance = %distance;
		reloadobject(%this, 1);
	}
	else
	{
		schedule("deleteobject("@%this@");", 0.5);
		$ArtilleryCount--;
	}

	if( ( $DroneCount + $ArtilleryCount ) )
	{
		$ActiveDrone = 1;
		%AI = getnextobject($DroneAI, %this);
		if( %AI )
			if( getobjectname(%AI) == "Drone" )
				schedule("roamDrone("@%AI@");", $DroneCycleDelay);
			else
				schedule("roamArtillery("@%AI@");", $DroneCycleDelay);
		else
			schedule("roamDrone("@getnextobject($DroneAI, 0)@");", $DroneCycleDelay);
	}
}

function cybridbase10000(%this, %c)
{
	//dbecho("cybridbase10000(%this)");

	$Cybridbase.distance = 6000;
	echo("PERIMETER CAUTION!  INTRUDER DETECTED WITHIN 10000 METERS OF BASE!");
	for(%i=0;%i<%c * 0.5;%i++)
	{
		createCybridDefender(randomint(1, 5), randomint(41, 42), %this);
		createArtillery(3, %this);
	}
}

function cybridbase6000(%this, %c)
{
	//dbecho("cybridbase6000(%this)");

	if( $CybridCount <= $CybridLimit )
	{
		$Cybridbase.distance = 5000;
		echo("PERIMETER WARNING!  INTRUDER DETECTED WITHIN 6000 METERS OF BASE!");
		for(%i=0;%i<%c * 0.75;%i++)
			createCybridDefender(randomint(6, 10), randomint(43, 44), %this);
	}
}

function cybridbase5000(%this, %c)
{
	//dbecho("cybridbase5000(%this)");

	if( $ArtilleryCount <= $ArtilleryLimit )
	{
		$Cybridbase.distance = 3000;
		echo("PERIMETER WARNING!  INTRUDER DETECTED WITHIN 5000 METERS OF BASE!");
		for(%i=0;%i<%c * 0.75;%i++)
			createArtillery(3, %this);
	}
}

function cybridbase3000(%this, %c)
{
	//dbecho("cybridbase3000(%this)");

	if( $CybridCount <= $CybridLimit )
	{
		$Cybridbase.distance = 2500;
		echo("PERIMETER ALERT!  INTRUDER DETECTED WITHIN 3000 METERS OF BASE!");
		for(%i=0;%i<%c * 1.0;%i++)
			createCybridDefender(randomint(11, 15), randomint(45, 46), %this);
	}
}

function cybridbase2500(%this, %c)
{
	//dbecho("cybridbase3000(%this)");

	if( $ArtilleryCount <= $ArtilleryLimit )
	{
		$Cybridbase.distance = 1000;
		echo("PERIMETER ALERT!  INTRUDER DETECTED WITHIN 2500 METERS OF BASE!");
		for(%i=0;%i<%c;%i++)
			createArtillery(3, %this);
	}
}

function cybridbase1000(%this, %c)
{
	//dbecho("cybridbase1000(%this)");

	if( $CybridCount <= $CybridLimit )
	{
		$Cybridbase.distance = 0;
		echo("PERIMETER BREACH!  INTRUDER DETECTED WITHIN 1000 METERS OF BASE!");
		for(%i=0;%i<%c * 1.25;%i++)
			createCybridDefender(randomint(16, 20), randomint(47, 48), %this);
	}
}

function createCybridDefender(%r, %p, %this)
{
	//dbecho("createCybridDefender(%r, ");

	%x = getposition($CybridDump, x) + (100 * randomint(-5, 5));
	%y = getposition($CybridDump, y) + (100 * randomint(-5, 5));
	%z = getterrainheight(%x, %y);

	%AI = loadObject("Cybrid", "multiplayer\\Desolation\\Cybrid"@%r@".veh");
	addtoset($CybridAI, %AI);
	setposition(%AI, 8000, 0, 5075);

	setPilotId(%AI, %p);
	%AI.pilot = %p;

	$Cybridcount++;

	droppod(%x, %y, %z + randomint(3600, 4400), %x, %y, %z, %AI);
	schedule("order("@%AI@", attack, "@%this@");", 12);
}

  //---------------------//
 //Mission Goals	//
//---------------------//

function findLandingSite()
{
	//dbecho("dropshipLanding()");

	$Mission::Objective2 = 1;
	say(0, $HumanBase.center, "<F1>TAC-COM: <F6>{text pending, objective 2 completed}");

	//	schedule("brindintheDrones();", 25.0);
}

function victory()
{
	//dbecho("victory()");

	if(!isgroupdestroyed($HumanBase.accelerator))
	{
		playSound(0, "Mission_comp.wav", IDPRF_2D);
		messageBox(0, "Mission Successful");

		schedule("setFlybyCamera("@$HumanBase.accelerator@", -150, 150, 250);", 2.5);
		schedule("playanimsequence("@$HumanBase.accelerator@", 0, true);", 5);
		schedule("fadeevent(0, out, 5, 0, 0, 1);", 10);

		endmission();
	}
}

function endmission()
{
	//dbecho("endmission()");

	$missionstarted = 0;

	$CybridCount = 0;
	$DroneCount = 0;
	$ArtilleryCount = 0;

	deleteobject($DroneAI);		//There may be issues with the artillery, so they have to go.
	deleteobject($Triggers);	//Just a little extra behind-the-scenes cleanup to reduce demands during the final moments.
	deleteobject($Turrets);		//These also aren't visable, and so can be removed.

	schedule("missionEndConditionMet();", 15);
}

  //=============================================================================//
 //Triggers									//
//=============================================================================//

function debris::trigger::onEnter(%this, %object)
{
	//dbecho("debris::trigger::onEnter(%this, ");

	%player = playermanager::vehicleidtoplayernum(%object);
	if(%player)
	{
		%time = getsimtime();
		if(%time - %player.saytime > 2)
		{
			%player.saytime = %time;
			if(%object.loadlimit)
			{
				%p = strcat( 100 * (%object.oreload + %object.scrapload) / %object.loadlimit);
				if(strlen(%p) > 5)
					%p = strAlign(5, L, %p);
				say(%player, 1234, "<F6>Scrap source detected, shutdown to collect.  Your cargo bay is "@%p@" percent filled.");
			}
			else
				say(%player, 1234, "<F6>Scrap source detected, but your vehicle does not have a cargo bay!");
		}
	}
}

function debris::trigger::onContact(%this, %object)
{
	//dbecho("debris::trigger::onContact(%this, ");

	if(isshutdown(%object))
	{
		%debris = %this.object;
		%load = %object.scrapload + %object.oreload;
		if( %load < %object.loadlimit  &&  %debris.value > 0 )
		{
			%object.loadsource = %this.object;
			%debris.value -= 0.25;
			%object.scrapload += 0.25;

			%player = playermanager::vehicleidtoplayernum(%object);
			if( %player )
				playsound(%player, "sfx_hitdebris.wav", IDPRF_2D);

			if( %debris.value <= 0 )
			{
				schedule("checkifharvesting("@%object@", "@%debris@");", 0.6);
				schedule("deleteobject("@%debris@");", 0.75);
				schedule("deleteobject("@%this@");", 0.75);
				$debriscount--;
			}
			if( %load + 0.25 >= %object.loadlimit )
			{
				if( %player )
				{
					say(%player, 1234, "<F5>Your vehicle cannot carry any more scrap.", "alarm2.wav");
				}
			}
		}
	}
}

function checkifharvesting(%object, %rock)
{
	//dbecho("checkifharvesting(%object, ");

	if( %object.loadsource == %rock )
	{
		%player = playermanager::vehicleidtoplayernum(%object);
		if( %player )
		{
			%p = strcat( 100 * (%object.oreload + %object.scrapload) / %object.loadlimit);
			if(strlen(%p) > 5)
				%p = strAlign(5, L, %p);
			say(%player, 1234, "<F5>This scrap source has been exhausted.  Your cargo bay is "@%p@" percent filled.");
		}
		else
		{
			order(%object, guard, $Cybriddump);
		}
	}
}

function rocktrigger::trigger::onEnter(%this, %object)
{
	//dbecho("rocktrigger::trigger::onEnter(%this, ");

	%player = playermanager::vehicleidtoplayernum(%object);
	if(%player)
	{
		%time = getsimtime();
		if(%time - %player.saytime > 2)
		{
			%player.saytime = %time;
			if(%object.loadlimit)
			{
				%p = strcat( 100 * (%object.oreload + %object.scrapload) / %object.loadlimit);
				if(strlen(%p) > 5)
					%p = strAlign(5, L, %p);
				say(%player, 1234, "<F6>Ore source detected, shutdown to collect.  Your cargo bay is "@%p@" percent filled.");
			}
			else
				say(%player, 1234, "<F6>Ore source detected, but your vehicle cannot carry any!");
		}
	}
}

function rocktrigger::trigger::onContact(%this, %object)
{
	//dbecho("rocktrigger::trigger::onContact(%this, ");

	if(isshutdown(%object))
	{
		%load = %object.scrapload + %object.oreload;
		if( %load  <  %object.loadlimit )
		{
			%object.harvesting = %this.object;
			%ore = %this.object;
			%ore.value -= 0.25;
			%object.oreload += 0.25;

			%player = playermanager::vehicleidtoplayernum(%object);
			if(%player)
				playsound(%player, "sfx_hitdebris.wav", IDPRF_2D);

			if(%ore.value <= 0)
			{
				if(%player)
				{
					%p = strcat( 100 * (%object.oreload + %object.scrapload) / %object.loadlimit);
					if(strlen(%p) > 5)
						%p = strAlign(5, L, %p);
					say(%player, 1234, "<F5>This scrap source has been exhausted.  Your cargo bay is "@%p@" percent filled.");
				}
				else
				{
					order(%object, guard, $Cybriddump);
				}
				deleteobject(%this.object);
				deleteobject(%this);
				$RockCount--;
			}
			if( %load + 0.25 >=  %object.loadlimit )
			{
				if(%player)
				{
					say(%player, 1234, "<F5>Your vehicle cannot carry any more ore.", "alarm2.wav");
				}
				else
				{
					order(%this, guard, $Cybriddump);
				}
			}
		}
	}
}

function depot::trigger::onenter(%this, %object)
{
	//dbecho("depot::trigger::onenter(%this, ");

	%player = playermanager::vehicleidtoplayernum(%object);
	if(%player)
	{
		say(%player, 1234, "<F5>Entering supply depot.  Shutdown to dump your cargo and initate repairs.\n<F1> Current ore supply: "@$humanore@" tons.\n Current scrap supply: "@$humanscrap@" tons.");
	}
}

function depot::trigger::oncontact(%this, %object)
{
	//dbecho("depot::trigger::oncontact(%this, ");

	if(isshutdown(%object))
	{
		%player = playermanager::vehicleidtoplayernum(%object);
		if(%player)
		{
			if(%object.oreload > 0)
			{
				%object.oreload -= 0.25;
				$humanore += 0.25;
				playsound(%player, "sfx_machine1.wav", IDPRF_2D);
				if( %object.oreload <= 0  &&  %object.scrapload <= 0 )
				{
					say(%player, 1234, "<F5>Supply dumping completed.\n<F1> Current ore supply: "@$humanore@" tons.\n Current scrap supply: "@$humanscrap@" tons.");
				}
			}
			else if(%object.scrapload > 0)
			{
				%object.scrapload -= 0.25;
				$Humanscrap += 0.25;
				playsound(%player, "sfx_machine3.wav", IDPRF_2D);
				if(%object.scrapload <= 0)
				{
						say(%player, 1234, "<F5>Supply dumping completed.\n<F1> Current ore supply: "@$humanore@" tons.\n Current scrap supply: "@$humanscrap@" tons.");
				}
			}
			healobject(%object, 50);
			reloadobject(%object, 5);
		}
	}
}

function vehicle::onArrived(%this, %where)
{
	//dbecho("vehicle::onArrived(%this, ");

	if( %where == $Cybriddump )
		if(%this.action == $Cybriddump)
		{
			%this.action = 0;
			$Cybridore += %this.oreload;
			%this.oreload = 0;
			$Cybridscrap += %this.scrapload;
			%this.scrapload = 0;
		}
}

  //=============================================================================//
 //Combat									//
//=============================================================================//

function vehicle::ontargeted(%this, %targeter)
{
	//dbecho("vehicle::ontargeted(%this, ");

	if( %targeter.turret )
	{
		if( getteam(%targeter) == *IDSTR_TEAM_YELLOW )
			if( !%this.detected )
			{
				%this.detected = 1;
				%time = getsimtime();
				if( %time - $Humanbase.targettime > 20 )
					say(0, $Humanbase.center, "<F1>TAC-COM: <F6>We're picking up inbound Cybrids!  Look alive!", "sfx_Siren.wav");
				$Humanbase.targettime = %time;
			}
	}
	else
	{
		%player = playermanager::vehicleidtoplayernum(%targeter);
		if(!%player)
		{
			if(!%this.adj)
			{
				postAction(%targeter, IDACTION_SHIELD_FOCUS_ADJ, 1);
				postAction(%targeter, IDACTION_SHIELD_TRACK, 1);
				%this.adj = 1;
			}
			order(%targeter, cloak, true);
		}
	}
}

function structure::onAttacked(%this, %attacker)
{
	//dbecho("structure::onAttacked(%this, ");

	if( getobjectname(%this) )
		if( getteam(%this) != getteam(%attacker) )
		{
			healobject(%this, 100);		//Makeshift armor
			if( getteam(%this) == *IDSTR_TEAM_YELLOW  &&  getteam( %attacker ) != *IDSTR_TEAM_YELLOW )
			{
				%time = getsimtime();
				if( %attacker.pilot == 66 )
				{
					if( !%attacker.detected )
						if( %time - $humanbase.artillerytime > 50 )
							say(0, $Humanbase.center, "<F1>TAC-COM: <F6>Shit, they're shelling the base!  Take that artillery out now!", "Artillery_warn.wav");
				}
				if( %time - $humanbase.attacktime  > 10 )
				{
					if( %time - $humanbase.turrettime  > 10 )
						say(0, $humanbase.center, "<F1>TAC-COM: <F6>They're attacking our base!", "alarm2.wav");
					else
						say(0, $humanbase.center, "<F1>TAC-COM: <F6>They're punching holes in the "@gethudname(%this)@"!", "alarm2.wav");
				}
				%attacker.detected = 1;
				$humanbase.attacktime = %time;
			}
		}
}

function turret::onAttacked(%this, %attacker)
{
	//dbecho("turret::onAttacked(%this, ");

	if( getteam(%this) != getteam(%attacker) )
	{
		healobject(%this, 100);		//Makeshift armor
		if( getteam(%this) == *IDSTR_TEAM_YELLOW  &&  getteam( %attacker ) != *IDSTR_TEAM_YELLOW )
		{
			%time = getsimtime();
			if( %attacker.pilot == 66 )
			{
				if( !%attacker.detected )
					if( %time - $humanbase.artillerytime > 25 )
						say(0, $Humanbase.center, "<F1>TAC-COM: <F6>They have artillery in the field!  Take them out!", "Artillery_warn.wav");
			}
			if( %time - $humanbase.turrettime  > 10 )
				say(0, $humanbase.center, "<F1>TAC-COM: <F6>Base defenses are under attack!", "alarm2.wav");
			%attacker.detected = 1;
			$humanbase.turrettime = %time;
		}
	}
}

  //=============================================================================//
 //Destruction									//
//=============================================================================//

function vehicle::ondestroyed(%this, %destroyer)
{
	//dbecho("vehicle::ondestroyed(%this, ");

	if(%destroyer > 0  &&  %this != %destroyer)
	{
		%team = getteam(%this);

		%v = randomint(0, %this.scrapload);
		%v += %this.oreload;

		if(%team == *IDSTR_TEAM_RED)
		{
			%c = getweaponcount(%this);
			%c += getcomponentcount(%this);
			%v = randomint(%v * 4, %c * 4) / 4;
		}

		$ionflux -= %c;
		
		%player = playermanager::vehicleidtoplayernum(%destroyer);
		%player2 = playermanager::vehicleidtoplayernum(%this);
		if( %player2 )
		{
			if( !%this.silent )
			{
				say(0,0, "<F5>"@getHUDName(%this)@"<F5> is down!");
				playsound(0, "sfx_siren.wav", IDPRF_2D);
			}
		}
		else
			if( %player )
				say(%player, 0, "<F6>Target destroyed");
		if(%v > 0)
		{
			createdebris(%this, %v);
		}
	}
}

function createdebris(%this, %v, %xlow, %xhigh, %ylow, %yhigh, %zlow, %zhigh)
{
	//dbecho("createdebris(%this, ");

	if($debrisCount < $DebrisLimit)
	{
		if(!%xlow)
			%xlow = 0;
		if(!%ylow)
			%ylow = 0;
		if(!%zlow)
			%zlow = 0;
		if(!%xhigh)
			%xhigh = 0;
		if(!%yhigh)
			%yhigh = 0;
		if(!%zhigh)
			%zhigh = 0;

		%x = getposition(%this, x) + randomint(%xlow, %xhigh);
		%y = getposition(%this, y) + randomint(%ylow, %yhigh);
		%z = getterrainheight(%x, %y) + randomint(%zlow, %zhigh);
		if(%z + 50 < getposition(%this, z))
			return;

		%r = randomint(1, 4);
		%d = copyobject($debris[%r], "debris");
		addToSet($debris, %d);
		%t = copyobject($debristrigger, "debris");
		addToSet($Triggers, %t);

		%x = getposition(%this, x) + randomint(%xlow, %xhigh);
		%y = getposition(%this, y) + randomint(%ylow, %yhigh);
		%z = getterrainheight(%x, %y) + randomint(%zlow, %zhigh);

		setposition(%d, %x, %y, %z, randomint(1, 360), randomint(1, 360));
		setposition(%t, %x, %y, %z);
		%d.trigger = %t;
		%t.object = %d;
		%d.value = %v;

		%f = randomint(1, $DebrisOverflow * 4) / 4;
		if($DebrisOverflow > 0)
		{
			$DebrisOverflow -= %f;
			%d.value += %f;
		}

		$DebrisCount++;
	}
	else
	{
		echo("Too much debris, debris creation canceled.  "@$DebrisLimit@" debris are allowed, increase $DebrisLimit to allow more debris.  Just to be fair, I'll try to spread some of the scrap value around.");
		$DebrisOverflow += %v;
		%debris = pick($Debris);
		damageobject(%debris, $DenrisOverflow * 100);
		damagearea(%debris, 0, 0, 0, $DebrisOverflow * 5, $DebrisOverflow * 50);
	}
}

function turret::onDestroyed(%this, %destroyer)
{
	//dbecho("turret::onDestroyed(%this, ");

	for(%i=0;%i<3;%i++)
	{
		%v = randomint(1, 5);
		schedule("createdebris("@%this@", "@%v@", -10, 10, -10, 10, 0, 2);", %i);
	}

	if(getteam(%this) == *IDSTR_TEAM_YELLOW)
	{
		$HumanTurrets--;
		if( getobjectname(%this) != "TempTurret" )
			say(0,$humanbase.center,"<F5>A Base Defense Turret has been disabled!");
		else
			return say(0,$humanbase.center,"<F5>Delta Turret has been disabled!");
	}
	else if(getteam(%this) == *IDSTR_TEAM_RED)
		$CybridTurrets--;
	schedule("scrapturret("@%this@");", 10);
}

function scrapturret(%this)
{
	//dbecho("scrapturret(%this)");

	if(getteam(%this) == *IDSTR_TEAM_YELLOW)
	{
		if($humanscrap >= 15)
		{
			respawnturret(%this);
			$humanscrap -= 15;
			return;
		}
	}
	else
	{
		if($cybridcrap >= 15)
		{
			respawnturret(%this);
			$cybridcrap -= 15;
			return;
		}
	}
	schedule("scrapturret("@%this@");", 5);
}

function respawnturret(%this)
{
	//dbecho("respawnturret(%this)");

	%team = getteam(%this);
	%x = getposition(%this, x);
	%y = getposition(%this, y);
	%z = getposition(%this, z);
	%r = getposition(%this, rot) * 180 / 3.14159265;
	setposition(%this.copy, %x, %y, %z, %r);
	setteam(%this.copy, %team);
	createbackupturret(%this.copy);

	schedule("deleteobject("@%this@");", 0.5);

	if(%team == *IDSTR_TEAM_YELLOW)
	{
		say(0,$humanbase.center,"<F1>Base Defense Turret restored.");
		$HumanTurrets++;
		addtoset($HumanBase, %this.copy);
	}
	else
	{
		$CybridTurrets++;
		addtoset($CybridBase, %this.copy);
	}
}

function structure::ondestroyed(%this, %destroyer)
{
	//dbecho("structure::ondestroyed(%this, ");

	%team = getteam(%this);

	if(%team == *IDSTR_TEAM_PURPLE)
	{
		%this.value = 0;
		deleteobject(%this.trigger);
		if(getObjectName(%this) == "debris")
			$DebrisCount--;
		else
			$RockCount--;
		schedule("deleteobject("@%this@");", 0.5);
	}
	else 
	{
		addtoset($DestroyedObjects, %this);
		if(%team == *IDSTR_TEAM_RED)
		{
			for(%i=0;%i<3;%i++)
			{
				%v = randomint(2, 10);
				createdebris(%this, %v, -15, 15, -15, 15, -1, 2);			
			}
		}
		else if(%team == *IDSTR_TEAM_YELLOW)
		{
			say(0, $Humanbase.center, "<F5>"@getHUDname(%this)@" has been destroyed!");
		}
	}
	
	if(%this)
		killchannel(%this);
}

function Entrance::structure::ondestroyed(%this, %destroyer)
{
	//dbecho("Entrance::structure::ondestroyed(%this, ");

	damageobject("Missiongroup\\redbase\\Sensor", 5000);
	damageobject("Missiongroup\\redbase\\Sensor", 5000);
}

function Bunker::structure::ondestroyed(%this, %destroyer)
{
	//dbecho("Bunker::structure::ondestroyed(%this, ");

	damageobject("Missiongroup\\redbase\\Tracking", 5000);
	damageobject("Missiongroup\\redbase\\Tracking", 5000);
	damageobject($CybridEntrance, 25000);
	damageobject($CybridEntrance, 25000);

	schedule("say(0, "@$Humanbase.center@", \"<F1>TAC-COM: <F6>"@gethudname(%destroyer)@"<F6>, we think that was the main Cybrid installation for this area!  Excellent job!\");", 2.5);

	for(%i=0;%i<($Cybridscrap+$CybridOre)/10;%i++)
	{
		%v = randomint(2, 10);
		createdebris(%this, %v, -15, 15, -15, 15, -1, 2);			
	}
	$CybridOre = 0;
	$Cybridscrap = 0;
	$CybridDump = 0;
}

function Beacon1::structure::onDestroyed(%this, %destroyer)
{
	//dbecho("Beacon1::Structure::onDestroyed(%this, ");

	playanimsequence("Missiongroup\\Cybrids\\Outpost1\\Beam", 0, true);
	schedule("say(0, "@$Humanbase.center@", \"<F1>TAC-COM: <F6>"@gethudname(%destroyer)@"<F6>, we are no longer reading Cybrid signals in your area.  You must have done something right.\");", 2.5);
}

function Beacon2::structure::onDestroyed(%this, %destroyer)
{
	//dbecho("Beacon2::Structure::onDestroyed(%this, ");

	playanimsequence("Missiongroup\\Cybrids\\Outpost2\\Beam", 0, true);
	schedule("say(0, "@$Humanbase.center@", \"<F1>TAC-COM: <F6>"@gethudname(%destroyer)@"<F6>, looks like you've knocked out Cybrid networks in the area.  Good work.\");", 2.5);
}

function Accelerator::Structure::onDestroyed(%this, %destroyer)
{
	//dbecho("Accelerator::Structure::onDestroyed(%this, ");

	endmission();

	fadeevent(0, out, 0.5, 3, 1, 1);
	schedule("fadeevent(0, in, 2, 3, 1, 1.5);", 0.5);

	playSound(0, "Mission_fail.wav", IDPRF_2D);
	messageBox(0, "Mission Failed");

	schedule("setDominantCamera("@%destroyer@", "@%this@", 0, -10, 12.5);", 2.5);
	schedule("setFlybyCamera("@%this@", -150, 150, 150);", 5);
	schedule("fadeevent(0, out, 4, 1, 0, 0);", 5);
	schedule("setPlayerCamera();", 10);
	schedule("fadeevent(0, in, 2.5, 1, 0, 0);", 9);
	schedule("fadeevent(0, out, 3, 0.25, 0, 0);", 12);

}

function onMissionEnd()
{
	//dbecho("onMissionEnd()");

	$missionloaded = 0;

	flushconsolescheduler();
}

function dbecho(%message)
{
	fileWrite("DesolationLog.txt", append, getsimtime(), " ", getDate(), " ", getTime(), " - ", %message);
}