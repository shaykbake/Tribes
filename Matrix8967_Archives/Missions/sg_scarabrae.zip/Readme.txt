----
--------
------------
[Map by Shotgun_Avenger "sgavenger@avenger.net"]

[INSTALLATION]

unzip all the files into your TRIBES\BASE\MISSIONS directory.

then your all set, it will appear in your CTF games list.


[VERY SPECIAL THANKS]

Special thanks go out to "The Obsidian Order" [OO], my brothers in Tribes.

And to everyone else who joined the server while i was editing and gave me feedback.

[DISCLAIMER]

You can e-mail me at the address provided, I cant give technical help as to why Tribes
is not working for you. You can point out gliches in my maps. I'd prefer you didnt edit my maps
you may use them as a base of comparison for your own works though.


If you want your maps to be seen by the public, the best place to do that is:

www.avenger.net