Xtreme Gaming Map Pack 5a

Unzip this pack into C:\Dynamix\Tribes\base\missions or wherever you have Tribes installed.

This pack includes 17 maps. It updates every map I have released so far so make sure "overwrite all files" is checked.

Visit http://www.xtremegaming.net daily for new maps!

Email: optimizer@xtremegaming.net with any comments or suggestions.