function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "D1"){
      %positionIn = "435.128 186.948 324.119";
      %positionOut = "381.362 184.777 908.898";
   }
      else if(%this.num == "D2"){
      %positionIn = "428.615 232.936 872.142";
      %positionOut = "79.2366 187.263 179.868";
   }
%client = Player::getClient(%object);
	if(%this.num == "B1"){
      %positionIn = "-194.244 187.007 323.698";
      %positionOut = "-140.006 189.412 908.899";
   }
      else if(%this.num == "B2"){
      %positionIn = "-186.953 230.78 872.832";
      %positionOut = "";
   }


  	if(%this.in){ 
         GameBase::setPosition(%client, %positionIn);
         //messageAll(0, "~wshieldhit.wav");
	   Client::SendMessage(%client,0,"~wshieldhit.wav");
      }
      	else if(%this.out){
         GameBase::setPosition(%client, %positionOut);
         //messageAll(0, "~wshieldhit.wav");
         Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
} 


