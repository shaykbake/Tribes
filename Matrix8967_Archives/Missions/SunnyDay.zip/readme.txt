MADE BY: XGN DF0
WHEN:    9 MAY 1999
EMAIL:   stevgagn@cgocable.ca