function GroupTrigger::onEnter(%this, %object)
{
%client = Player::getClient(%object);
	if(%this.num == "Group1"){
      %positionIn = "-1272.79 -80.4141 795.179";
      %positionOut = "-1212.9 -80.4564 260.049";
   }
      else if(%this.num == "Group2"){
      %positionIn = "-797.786 -79.7527 794.793";
      %positionOut = "-868.923 -79.2783 260.154";
   }
%client = Player::getClient(%object);
	if(%this.num == "Group3"){
      %positionIn = "-1346.97 -80.7598 375.016";
      %positionOut = "-721.791 -80.1938 374.593";
   }


  	if(%this.in){ 
         GameBase::setPosition(%client, %positionIn);
         //messageAll(0, "~wshieldhit.wav");
	   Client::SendMessage(%client,0,"~wshieldhit.wav");
      }
      	else if(%this.out){
         GameBase::setPosition(%client, %positionOut);
         //messageAll(0, "~wshieldhit.wav");
         Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
} 


