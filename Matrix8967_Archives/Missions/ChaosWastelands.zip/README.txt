Map Name: 	Chaos_Wastelands
Map Type:	Server Side
Mission Type:	CTF
Objectives/Num:	Yes/1

Author:		STRiDOR
Contact Info:	stridor__@hotmail.com
Server:		-STRiDOR-s JOiNT
Date: 		Feb 3, 1999

	First off let me just say that Tribes is an _amazing_ game!  I haven't 
been this addicted to a game since... Well, since the NES days at least.  And 
because of that fact I decided to make a Server side map.  

	I have some other cool ideas in mind for new maps (whenever I get some 
time :) and have plans to make some more.  The whole Server side map thing 
appeals to me, because you can make a totally brand new map (other than the base 
terrain and lighting) and all players can play without downloading huge maps, so 
access is the same as it always is!  This is a great feature that I hope some 
future developers take advantage of.

	This map has been out for about 2 weeks already and I've been getting very 
positive feedback from people on my server, so I hope you all enjoy it as well. 
When the new map editor comes out I�d like to fix some of the lighting and send 
a modified version of the map. As it stands right now a few objects are quite 
dark. 

	Thanks to all the players showing their support for Tribes by making MODS, 
maps, and web pages for reference.  They are most useful.

If anyone has any question/comments just write me at my e-mail address.

STRiDOR

