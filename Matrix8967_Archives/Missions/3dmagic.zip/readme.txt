-=   STARSIEGE TRIBES MAP    =-

MADE BY:  Steve Gagn� (XGN DF0)
TIME:     Made in 2 DAYS <-- DAMN --> 2 DAYS
WHEN:     10 June 1999 04h, 21min, 29sec
NOTE:     13th map hehehe
EMAIL:    stevgagn@cgocable.ca