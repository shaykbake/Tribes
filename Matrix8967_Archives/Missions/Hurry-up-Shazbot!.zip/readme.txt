-=   STARSIEGE TRIBES MAP    =-

MADE BY:  Steve Gagn� (XGN DF0)
WHEN:     23 MAY 1999
EMAIL:    stevgagn@cgocable.ca