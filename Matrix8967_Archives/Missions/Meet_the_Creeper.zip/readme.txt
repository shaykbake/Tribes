MEET_THE_CREEPER A CTF MAP
BY: ]DrC[CreepngDeth

Hey everyone, 
This is my first map so you gotta tell me if you like it. There will be many more to come so if you do like it please e-mail me so i know i'm doing something right. You can e-mail me at davejillard@geocities.com
Well here is how you install the map 

just unzip it to your Tribes/Base/Missions folder and then host a game and enjoy. Have Fun 
