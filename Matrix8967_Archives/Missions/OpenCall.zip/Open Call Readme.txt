Tribes Open Call Contest Readme
December 10th, 1999


*******************************
COMMENTS

Well, here they are - the Tribes Open Call submission finalists!

Several missions floored us with their creativity and overall artistic sense. However, it really came down to gameplay issues on who made it and who didn't. The maps that are included in the Open Call pack were the ones that we ended up wanting to play again and again. Hopefully, you all will too!

The dev team wants to thank all who submitted maps - we're firmly convinced that we've got the best audience out there!

Note that some of the missions were "tweaked" a bit to improve playability, but we tried to leave them as close to the original as possible.


*******************************
INSTALLATION

Simply unzip the maps into your Dynamix\Tribes\base\missions directory.
For example, I have Tribes installed on my C: drive so I would unzip them to:

C:\Dynamix\Tribes\base\missions

Once the maps are unzipped to the missions directory, you're ready to go!

New terrain is used in the maps, so those who don't download these maps to their own computers won't be able to play on them. For this reason, the new maps will use a new type, "OpenCall" - look for it in the join server screen in the Mission Type column (instead of "CTF", "Arena", or "Hunters").


*******************************
LIST OF MISSIONS

_Mission Name_		_Mission Type_		_Author_
CanyonCrusade		Capture the Flag	DOX
DarkAurora		Capture the Flag	DOX
Death_Row		Capture the Flag	Goldberg
Massive_Sides		Capture the Flag	Mongo
MidnightMayhem		Capture the Flag	DOX
NightSlide		Capture the Flag	Hurricane
OlympusMons		Capture the Flag	DOX
OneSmallStep		Capture and Hold	DOX
Slipstream		Defend and Destroy	Green
Spartacus'sGauntlet	Capture the Flag	DOX
Sulfurious		Capture the Flag	DOX
SuperCross_2		Capture the Flag	EEPROM
TheLongWalk		Capture the Flag	Goldberg
Turbulence		Capture the Flag	Bloodhype



Thanks again!

Scott "Captain America" Rudi
And other miscreants of the Tribes & Tribes 2 Dev teams