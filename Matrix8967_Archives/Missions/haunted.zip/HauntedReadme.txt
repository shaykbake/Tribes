Haunted was created by:
	/AD*Myamoto

Email:
	Myamoto@myamoto.com

I always loved Desert of Death, both no one would play, (Shazbot!). This map was created to allow for more a more flexible playing experience while maintaining DoDs crazy and frantic play.