Documentation for Tribes map  "Space_Station"

______________________________________________________________
Files that are required in your Tribes/base/mission folder:

Space_Station2.dsc
Space_Station2.mis

______________________________________________________________
This is a SERVER SIDE map that was designed by:
ImrtlBeast
ImrtlBeast@zcentral.com 
http://www.clanworld.dk/northwind/gamers
______________________________________________________________
ABOUT MAP:

This map incorporates a new twist in usage of flags.  Each team 
has a main flag that is at one end of this massive space station.
This map is totaly closed in but it is huge enough to get lost in.

There is also a switch stations that control that levels 
inventory stations and turrets.  This switch also control a flag
that is within that level that changes to the owner of the switch
staion.  This provides pro's and con's to owning switch.  It allows 
you to have a flag closer to the enemys so that you don't have to 
travel so far to touch it to yours.  It also gives you inventroy 
stations to recharge in and turrets that are friendly to you.  On 
the other hand it brings a flag closer to the enemy to allow them 
easier access.  It gives you another flag to have to protect 
from enemy forces.  If no one chooses to touch switch then flag is 
neutral and also all stations within that level as well.  I hope 
that you like it and I would love input so that I can make future 
maps more enjoyable.

Send email to: fxatnght@graceba.net
______________________________________________________________
