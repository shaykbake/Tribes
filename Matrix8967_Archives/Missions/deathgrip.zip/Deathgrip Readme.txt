   ***Deathgrip***
***[MI-Cpl Icepick***
     ***Map #2***

This is the second map that I have made.  This is a very
large map.

The Blood Eagle have a heavily fortified fortress on the 
OUTSIDE...

The Diamond Sword have three Dropships that have distinct
differences.

Any feedback is welcome.

[MI-Cpl] Icepick
Mobile Infantry
gravity16@email.com