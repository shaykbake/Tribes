**** This map designed for Tribes 1.3.xx****
                 04/09/99
================================================================
Title                   : DeathMonkeys (version 1.0a)
Author                  : Lucas Goodwin (RB|Hosed)
Email Address           : lucasg@gorge.net
Description             : Tribes CTF Map
================================================================

-=- Play Information -=-

This is a VERY fast playing map.  The central base can make or break your team.


Recomended # of Players : 12-24
Client Download Req.    : Yes.  Sorry folks, you've got download it to play it.

-=- Construction -=-

Base                    : DangerousCrossings .ted and .vol
Editor(s) used          : Tribes built-in editor in patch 1.3.12
Known Bugs              : At times the trees don't show on the PDA screen
Build Time              : 4 days

-=- Other Info -=-

1.0:
My very first map, ever.  I babied this one, wanted it just right.  Gameplay should be very balanced.

1.0a:
Changed the spawn points by the Sensor Arrays so that they now are by their respective bases.  Server side change and therefore you do not need to redownload on the client end.