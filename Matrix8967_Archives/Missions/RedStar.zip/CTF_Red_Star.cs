// FILENAME:	CTF_Red_Star.cs
//
// AUTHORS:	/ {HM} Sabre -^-
//------------------------------------------------------------------------------

$missionName = "CTF_Red_Star";

$maxFlagCount  = 5;           // no of flags required by a team to end the game
$flagValue     = 6;          // points your team gets for capturing
$carrierValue  = 3;          //  "      "    "    "    " killing carrier
$killPoints    = 1;
$deathPoints   = 1;
$flagTime = 180;

exec("multiplayerStdLib.cs");
exec("CTFstdLib.cs");

function setDefaultMissionOptions()
{
	$server::TeamPlay = true;
	$server::AllowDeathmatch = false;
	$server::AllowTeamPlay = true;	

	$server::AllowTeamRed = false;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = true;

   // what can the server admin choose for available teams
   $server::disableTeamRed = true;
   $server::disableTeamBlue = false;
   $server::disableTeamYellow = true;
   $server::disableTeamPurple = false;
}

function onMissionLoad()
{
   cdAudioCycle("Purge", "Terror", "Watching");
   setGameInfo("<F2>GAME TYPE:<F0> Team Capture the Flag\n\n<F2>RULES:<F0> Welcome to Starsiege Capture the Flag.  Teams score points by stealing the other team's flag and returning it to their own.  The first team to capture five flags wins!  Individual players earn six points for each flag they capture, one point for each kill, and three point for each enemy flag carrier they kill.  Players lose one point per death.  A flag carrier has three minutes to capture a stolen flag, or else it is returned to the owning team's base.\n\n<F2>MISSION:<F0>  Red Star\n\n<F2>DESCRIPTION:<F0> As their planet dissolved in the War of the Races, the Harbringers forsook the earth and took to the skies.  Centuries later, their fortress-cities endure, a testiment to their ingenuity ... and their brutality.  Below, small tribes of the Races still fight, killing each other with unwavering ferocity.  Some of the Races have recently found their way onto some of the floating relics and, as always happens when different Races meet, war ensured.");
}

function player::onAdd(%player)
{
   %vehicleId = playermanager::vehicleidtoplayernum(%player);
   %vehicleId.deathMethod = "";
   %vehicleId.Fail = false;
   %vehicleId.Cancel = true;
   %vehicleId.up = false;
   say(%player, %player, "Welcome to CTF Red Star.  Map created by / {HM} Sabre -^-.  Watch your step...");
   if(strAlign(1, left, getname(%player))=="/")
   {
      say(0,0,"<f4>"@getname(%player)@" joined the game.");
   }
}

function player::onRemove(%player)
{
   if(strAlign(1, left, getname(%player))=="/")
   {
      say(0,0,"<f4>"@getname(%player)@" left the game.");
   }
}

function onMissionStart()
{
	initGlobalVars();
	marsSounds();
   	schedule("randomDeathStorm();",1);
}


//Purple Transporters
//-----------------------------------------------------------------------

function PurpleTransport1::trigger::onContact(%this, %object)
{
	setPosition(%object, -175, 90, 2525); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported into Purple Team's guard tower.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function PurpleTransport2::trigger::onContact(%this, %object)
{
	setPosition(%object, 50, 200, 2555); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported onto Purple Team's ramparts.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function PurpleTransport3::trigger::onContact(%this, %object)
{
	setPosition(%object, -195, 265, 2520); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported off of Purple Team's ramparts.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function PurpleTransport4::trigger::onContact(%this, %object)
{
	setPosition(%object, -550, 0, 4025); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported to the Execution Site.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function PurpleTransport5::trigger::onContact(%this, %object)
{
	setPosition(%object, -175, 0, 2525); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported from the Execuiton Site into Pruple Team's guard tower.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

//Blue Transporters
//-----------------------------------------------------------------------

function BlueTransport1::trigger::onContact(%this, %object)
{
	setPosition(%object, 175, -90, 2525); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported into Blue Team's guard tower.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function BlueTransport2::trigger::onContact(%this, %object)
{
	setPosition(%object, -50, -200, 2555); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported onto Blue Team's ramparts.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function BlueTransport3::trigger::onContact(%this, %object)
{
	setPosition(%object, 195, -265, 2520); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported off of Blue Team's ramparts.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function BlueTransport4::trigger::onContact(%this, %object)
{
	setPosition(%object, 550, 0, 4025); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported to the Execution Site.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

function BlueTransport5::trigger::onContact(%this, %object)
{
	setPosition(%object, 175, 0, 2525); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f1>You are being teleported from the Execution Site to Blue Team's guard tower.");
	playSound(%player, "teleporter.wav", IDPRF_2D);
}

//High Above Scripts
//-------------------------------------------------------------------------
function ExecutionerTransport::trigger::onEnter(%this, %object)
{
	setPosition(%object, 0, 0, 4080); 
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f5>Now you will be executed.");
	playSound(%player, "sfx_thunder1.wav", IDPRF_2D);
}

function Executioner::trigger::onEnter(%this, %object)
{
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f6>AAAGH!<F0>");
	playSound(%player, "F7_G_aaagh.wav", IDPRF_2D);
}

function Executioner::trigger::onContact(%this, %object)
{
	%object.deathMethod = "Impale";
	healObject(%object, -7500);
	%player = playermanager::vehicleIdtoplayerNum(%object);
	playSound(%player, "sfx_pilot_hit.wav", IDPRF_2D);
}

function Executioner::trigger::onLeave(%this, %object)
{
	%object.deathMethod = "";
}

//Firepit Scripts
//-----------------------------------------------------------------------
function firePit::trigger::onEnter(%this, %object)
{
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f2>You have fallen through the Thermal Exhaust shaft.  Hope you don't burn up...<F0>");
	playSound(%player, "bigflyby.wav", IDPRF_2D);
}

function firePit::trigger::onContact(%this, %object)
{
	%object.deathMethod = "Exhaust";
	healObject(%object, -2000);
	%player = playermanager::vehicleIdtoplayerNum(%object);
	playSound(%player, "sfx_fire.wav", IDPRF_2D);
}

function firePit::trigger::onLeave(%this, %object)
{
	%object.deathMethod = "";
}

function firePitExit::trigger::onEnter(%this, %object)
{
	%object.deathMethod = "";
	%player = playermanager::vehicleIdToPlayerNum(%object);
	say(%player, %player, "<F2>That burned, didn't it?  Well, seeing how you're still alive, lets see if you can last long enough on the ground to get back up.");
}

//Deathmessages
//-----------------------------------------------------------------------
function vehicle::onDestroyed(%destroyed, %destroyer)
{
	%player = playermanager::vehicleIdtoPlayerNum(%destroyer);
   	%team = getTeam(%destroyed);
   	adjTeamCount(%team, -1);
   	%teamCount = getTeamPlayerCount(%team);      

   	if(%teamCount < 1)
   	{
	   	setFlag(%team, false);					
   	}

   	%color = dataRetrieve(%destroyed, "hasFlag");
   	%flagTeam = colorToTeam(%color);
   
   	// if the destroyed vehicle has a flag, it goes back to it's base
   	if (%color != "")
   	{
     	 	playerDropsFlag(%destroyed);
      
      		// let everyone know this guy drops the flag
      		%str =
         		*IDMULT_CHAT_SURRENDER_FLAG_1 @
         		getName( %destroyed )         @
         		*IDMULT_CHAT_SURRENDER_FLAG_2 @ 
         		%flagTeam                     @
         		*IDMULT_CHAT_SURRENDER_FLAG_3;
      
      		%soundFile = "";   
      		if(%flagTeam == *IDSTR_TEAM_RED)
      		{
         		%soundFile = "red_flag_sur.wav";
      		}
      		else if(%flagTeam == *IDSTR_TEAM_BLUE)
      		{
         		%soundFile = "blue_flag_sur.wav";
      		}
      		else if(%flagTeam == *IDSTR_TEAM_YELLOW)
      		{
         		%soundFile = "yel_flag_sur.wav";
      		}
      		else
      		{
         		%soundFile = "purp_flag_sur.wav";
      		}   
      
      		say( 0, 0, %str, %soundFile );

            
      		if($scoringFreeze == false)
      		{     
         		// destroyer's team gets credit for killing the carrier
         		%destroyerTeam = getTeam(%destroyer);  
      
         		// only give points if destroyed recovered his/her own flag
         		if(%destroyerTeam == colorToTeam(%color))
         		{
            			%key = strcat(teamToColor(getTeam(%destroyer)), "CarriersKilled");
            			dataStore(0, %key, 1 + dataRetrieve(0, %key));
            
            			// player gets credit, too
            			%player = playerManager::vehicleIdToPlayerNum(%destroyer);
            			if(%player != 0)
            			{
               				%player.carriersKilled = %player.carriersKilled + 1;
            			}
         		}

         		// echo the surrender to the console for logging
         		echo(*IDSTR_CONSOLE_CTF_SURRENDER @ " " @ playerManager::vehicleIdToPlayerNum(%destroyed));                        
      		}	  
   	}
   	else
   	{
      		// not a flag carrier ... is it an enemy?
      		if($scoringFreeze == false)
      		{
         		if(getTeam(%destroyed) != getTeam(%destroyer))
         		{
            			%player = playerManager::vehicleIdToPlayerNum(%destroyer);
            			if(%player != 0)
            			{
               				%player.genericKills = %player.genericKills + 1;
            			}
         		}
      		}
   	}
	if(%destroyed.deathMethod == "Exhaust")
	{
      		%die = randomInt(0,3);
      		if(%die == 0){
         		say(0, 0,getHUDName(%destroyed)@" was fried in the Thermal Exhaust Shaft.","sfx_fire.wav");
      		}
      		else if(%die == 1){
         		say(0, 0,getHUDName(%destroyed)@" couldn't take the heat in the Thermal Exhaust Shaft.","sfx_lava.wav");
      		}
      		else if(%die == 2){
         		say(0, 0,getHUDName(%destroyed)@" burst into flames in the Thermal Exhaust Shaft.","sfx_shrk.wav");
      		}
      		else 
		{
         		say(0, 0,getHUDName(%destroyed)@" combusted while falling through the Thermal Exhaust Shaft","explo3.wav");
      		}
	}
 	else if(%destroyed.deathMethod == "Impale")
   	{
      		%die = randomInt(0,2);
      		if(%die == 0){
         		say(0, 0,getHUDName(%destroyed)@" was brutally impaled.","sfx_cybrid_com.wav");
      		}
      		else if(%die == 1){
         		say(0, 0,getHUDName(%destroyed)@" was run through.","sfx_cybrid_com.wav");
      		}
      		else
		{
         		say(0, 0,getHUDName(%destroyed)@"'s body now adorns the Executioner's lance.","sfx_cybrid_com.wav");
      		}
   	}
	else if(%destroyed.deathMethod == "Pop")
   	{
      		%die = randomInt(0,1);
      		if(%die == 0){
         		say(0, 0,getHUDName(%destroyed)@" failed to rematerialize.","explo3.wav");
      		}
      		else
		{
         		say(0, 0,getHUDName(%destroyed)@" vanished in a Transporter accident.","explo3.wav");
      		}
      		
   	}
   	else
   	{
	// enforce the rules
   	if(
      		(getTeam(%destroyed) == getTeam(%destroyer)) &&
      		(%destroyed != %destroyer)
   	)
   		{
      			antiTeamKill(%destroyer);
   		}

   		vehicle::onDestroyedLog(%destroyed, %destroyer);
   
   		// give the death messages...
   		%message = getFancyDeathMessage(getHUDName(%destroyed), getHUDName(%destroyer));
   		if(%message != "")
   		{
      			say( 0, 0, %message);
   		}
		%destroyed.deathMethod = "";
	}
}


//Meteor Shower
//---------------------------------------------------------------------------

function randomDeathStorm()
{
	deleteObject($meteorite);
	$meteorite=newObject("meteorite",staticshape,"xobstacle.dts");
	addToSet("MissionGroup",$meteorite);
	setShapeVisibility($meteorite,false);
	%nextStorm=randomInt(30, 30);
	dropMeteor("default",1,5,-50,-150,50,150,-1000,-1000,1000,1000);
	%dropMeteors="dropMeteor(\"default\",1,5,-50,-50,50,50,-1000,-1000,1000,1000);";
	fadeevent(0, out, 0.75, 0.15, 0, 0);
	schedule("fadeevent(0, in, 1.0, 0.15, 0, 0);", 0.80);
	schedule(%dropMeteors,5);
	schedule(%dropMeteors,10);
	schedule(%dropMeteors,15);
	schedule(%dropMeteors,20);
	schedule(%dropMeteors,25);
	schedule("randomDeathStorm();",%nextStorm);
}

function dropMeteor(%type, %rate, %count, %xHigh1, %yHigh1, %xHigh2, %yHigh2, %xLow1, %yLow1, %xLow2, %yLow2){

	%ceiling = 2250;

	if(%xHigh2 == "") %xHigh2 = 0;
	if(%yHigh2 == "") %yHigh2 = 0;
	if(%xLow1 == "") %xLow1 = 0;
	if(%yLow1 == "") %yLow1 = 0;
	if(%xLow2 == "") %xLow2 = 0;
	if(%yLow2 == "") %yLow2 = 0;

	if(%xLow1 == 0 && %xLow2 == 0 && %yLow1 == 0 && %yLow2 == 0){
		%xLow1 = %xHigh1;
		%xLow2 = %xHigh2;
		%yLow1 = %yHigh1;
		%yLow2 = %yHigh2;
	}

	%startX = randomInt(%xHigh1, %xHigh2);
	%startY = randomInt(%yHigh1, %yHigh2);

	%endX = randomInt(%xLow1, %xLow2);
	%endY = randomInt(%yLow1, %yLow2);

	if(%type == "focus"){
		%startX = %endX = %xHigh1;
		%startY = %endY = %yHigh1;		
	}
	else if(%type == "focalStart"){
		%startX = %xLow1;
		%startY = %yLow1;
	}
	else if(%type == "focalEnd"){
		%endX = %xLow1;
		%endY = %yLow1;
	}
	else if(%type == "vertical"){
		%startX = %endX;
		%startY = %endY;
	}

	%endZ = getTerrainHeight(%endX, %endY);

	// Determine when the next meteorite will fall
	%when = %rate;
	if(%when < 0){
		%when = %when * -1;
		%when = randomFloat(0, %when);
	}

	if(count != -1)
		%count = %count - 1;

	%nextMeteorite = "dropMeteor(";
	%nextMeteorite = strcat(%nextMeteorite, %type, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %rate, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %count, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xHigh1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yHigh1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xHigh2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yHigh2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xLow1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yLow1, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %xLow2, ", ");
	%nextMeteorite = strcat(%nextMeteorite, %yLow2, ");");

	dropPod(%startX, %startY, %ceiling, %endX, %endY, %endZ, "MissionGroup\\meteorite");
	%doDamage = "damagearea(";
	%doDamage = strcat(%doDamage, "\"MissionGroup\\\\meteorite\", 0, 0, 0, 125, 12500);");

	// This next bit calculates when the meteor hits the ground and damages the herc when it does...
	%timeDrop = ((%endX - %startX) * (%endX - %startX));
	%timeDrop = %timeDrop + ((%endY - %startY) * (%endY - %startY));
	%timeDrop = %timeDrop + ((%ceiling - %endZ) * (%ceiling - %endZ));
	%timeDrop = sqrt(%timeDrop);
	%timeDrop = %timeDrop / 400;
	schedule(%doDamage, %timeDrop);

	if(%count != 0)
		schedule(%nextMeteorite, %when);
}

//Ground Teleporters.  Part of the script came from *~Milliardo Peacecraft~*, who got it from [1Cav]�BlackRainbow���.  I've changed it quite a bit to fit the circumstances, but I still would like to thank them.
//-----------------------------------------------------------------------
function groundTransport::trigger::onEnter(%this, %object)
{
	%player = playermanager::vehicleIdtoplayerNum(%object);
	say(%player, %player, "<f2>Heh, I don't get much company down here.  Life company that is.  Anyways, the Transporter will be powered up in a few seconds, if you want to go up.  Just stay there and don't move.<F0>");
	playSound(%player, "sfx_shrk.wav", IDPRF_2D);
}

function groundTransport::trigger::onContact(%this, %object)
{
	%player = playermanager::vehicleIdtoplayerNum(%object);
	if(%object != $lastVehicleOnTele){
		$lastVehicleOnTele = %object;
		$secondsToTele = 0;
	}
	else
	{
		$secondsToTele = $secondsToTele + 1;
	}
	if($secondsToTele >= 5)
	{		
		%player = playermanager::vehicleIdtoplayerNum(%object);
		playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
	
		if($secondsToTele >= 10)
		{
			setPosition(%object, -25, 0, 170);
			%player = playermanager::vehicleIdtoplayerNum(%object);
			say(%player, %player, "<f2>Transporting...<F0>");	
			playsound(%player,"teleporter.wav",IDPRF_2D);
			%object.Fail = false;
			%object.Cancel = false;
			%object.up = true;
			schedule("up(" @ %object @ ");",0.25);
			$secondsToTele = 0;
			
		}
	}
}



function groundTransport::trigger::onLeave(%this, %object)
{
	if(%object = $lastVehicleOnTele)
	{
		if(($secondsToTele  <= 4)&&($secondsToTele >= 1))
		{
			%player = playermanager::vehicleIdtoplayerNum(%object);
			playsound(%player,"alarm2.wav",IDPRF_2D);
			say(%player, %player, "<F2>Hey, what the hell do you think you're doing?  Don't jump off the damn thing while I'm working!  Now we gotta start all over...");
		}
		else if(($secondsToTele <=9)&&($secondsToTele >= 1))
		{
			setPosition(%object, -25, 0, 175);
			%player = playermanager::vehicleIdtoplayerNum(%object);
			playsound(%player,"sfx_shieldcap_backfire.wav",IDPRF_2D);
			say(%player, %player, "<F2>Are you brain damaged or something?","M11_areyoubraind.WAV");
			%object.Fail = true;
			%object.Cancel = false;
			%object.up = true;
			schedule("up(" @ %object @ ");",0.25);
			%object.deathMethod = "Pop";
		}
	}
	$lastVechicleOnTele = "";
	$secondsToTele = 0;
}

function up(%object)
{
	if(%object.cancel == true) return;
	else if(%object.up == true)
	{
		%object.upx = getposition(%object, x);
		%object.upy = getposition(%object, y);
		%object.upz = getposition(%object, z)+20;
		setposition(%object, %object.upx, %object.upy, %object.upz);
		playsound(%player,"sfx_electrical_bzzt.wav",IDPRF_2D);
		schedule("up(" @ %object @ ");",0.1);
	}
}

function groundTransportFail::trigger::onEnter(%this, %object)
{
	%object.up = false;
	%object.Cancel = true;
	if(%object.Fail == true)
	{
		healObject(%object, -10000);
		playsound(0,"explo3.wav",IDPRF_2D);
		%object.deathMethod = "";
	}
	else
	{
		setPosition(%object, 0, 0, 2525);
	}
}

function transport::structure::onScan(%this, %vehicleId)
{
	%player = playermanager::vehicleIdtoplayerNum(%vehicleId);
	say(%player, %player, "<F2>So, you want to know how this works, eh?  Just step onto the Transporter platform and I'll power the thing up.  It may take a few seconds, but it works. Just dont get off the pad while its working, or I'll have one hell of a time bringing you back. You won't enjoy it either.");        
}
