This is a variant map of Broadside. It incorprates the 'new' jump/spring boards.


============
Installation
============

Extract the Jumpside.mis and Jumpside.dsc into your tribes/base/missions folder.

Extract the two .cs files into your tribes/base folder. (These will not affect anything, they just add the jump/spring board the game and the editor.) They are needed on the server only. 


Have fun!


Questions/Comments Contact:

Lord Mycroft!OT!

mycroft@LanMinds.Net