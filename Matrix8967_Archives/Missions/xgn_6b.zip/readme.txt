XGN_6b Map Pack

Four of the XGN crew got together (Optimizer, Clippy, Ruff Rider, Pokey) and put a small map pack out this weekend for your Tribal pleasure!

Each on of the maps included in this pack are CTF maps. They were designed by expert map makers from XGN. We now have a total of 32 maps out in the Tribes community!

Unzip into your dynamix\tribes\base\mission folder and enjoy.......

Maps Included
TaptheRockies - By Ruff Rider
SkiZone - By Pokey
DeadlyEncounter - By Clippy
Vally_of_Death - By Optimizer

Send any feedback to optimizer@xtremegaming.net and as always check http://www.xtremegaming.net daily for all your shooter info and check MMC for all your Map needs!
