Just extract all the files to your Dynamix/Tribes/base/missions folder and thats all 

Hope you enjoy the map made by Riley! :D