// FILENAME:	DM_Burst_Arena.cs
//
// AUTHOR:  	/ {HM} Sabre -^-
//------------------------------------------------------------------------------

$missionName = "DM_Burst_Arena";

exec("multiplayerStdLib.cs");
exec("DMstdLib.cs");

Pilot AI
{
	id=28;
	skill=0.5;
	accuracy=0.5;
	aggressiveness=0.5;
	activateDist=800.0;
	deactivateBuff=100.0;
	targetFreq=3.0;
	trackFreq=0.1;
	fireFreq=0.1;
	LOSFreq=0.1;
};

function setDefaultMissionOptions()
{
	$server::TeamPlay = false;
	$server::AllowDeathmatch = true;
	$server::AllowTeamPlay = true;	
	
	$server::AllowTeamRed = true;
	$server::AllowTeamBlue = true;
	$server::AllowTeamYellow = false;
	$server::AllowTeamPurple = false;

	$server::disableTeamRed = false;
	$server::disableTeamBlue = false;
	$server::disableTeamYellow = true;
	$server::disableTeamPurple = true;
}

function setAllowedItems()
{
	//Vehicles
	allowVehicle( all, false);
	allowVehicle(                                           20,  TRUE  );      //Seeker
	allowWeapon(                                       all,     FALSE  );
	allowWeapon(                                           116,  TRUE  );      //Autocannon
}

function onMissionStart()
{
	$killPoints = 3;
	$deathPoints = 2;

	titanSounds();
	schedule("missionendconditionmet();", 3600);
}

function player::onAdd(%this)
{
	say(%this, 0, "Welcome to the Burst Arena!  The challenge: score points by knocking enemies out of the arena.  As this is a challenge of accuracy and agility, players are restricted to using Seekers armed with ATCs.  Read the rules tab for more detailed rules, as well as some important information about the arena.");
	%this.kills = 0;
	%this.deaths = 0;
}

function vehicle::onAdd(%this)
{
	%player = playermanager::vehicleidtoplayernum(%this);
	%this.out = false;
	%this.dead = false;
	%this.attacker = 0;
	schedule("fallcheckup("@%this@");", 1);
	if(%player > 0)
	{
		if(getVehicleName(%this) != "Seeker")
		{
			deleteobject(%this);
			messagebox(%player, "Your vehicle does not meet this server's requirements, and has been deleted.  Return to the lobby and check your vehicle before attempting to respawn");
			return;
		}
		%c = getweaponcount(%this);
		if( %c > 2 )
		{
			deleteobject(%this);
			messagebox(%player, "Your vehicle does not meet this server's requirements, and has been deleted.  Return to the lobby and check your vehicle before attempting to respawn");
			return;
		}
		for(%i=0;%i<%c;%i++)
		{
			if( 116 != getWeaponId(%this, %i) )
			{
				deleteobject(%this);
				messagebox(%player, "Your vehicle does not meet this server's requirements, and has been deleted.  Return to the lobby and check your vehicle before attempting to respawn");
				return;
			}
		}
	}
}

function onMissionLoad()
{
	cdAudioCycle("Yougot", "Newtech", "Mechsoul"); 
	setGameInfo("<F2>GAME TYPE:<F0> Burst Deathmatch\n\n<F2>RULES:<F0>Welcome to the Burst Arena!  The goal of this mission is to score as many points as possible by knocking opponents out of the arena.  As this is a challenge of wit and agility, <F5>players are restricted to using Seekers armed with ATCs!<F0>  Also take note that gravity has been lowered, so watch where you step!\n\n<F2>MISSION:<F0>  Burst Arena\n\n<F2>MISSION INFO:<F0>  Be aware that gravity has been lowered for this mission.  Also, every few minutes an ion pulse will be fired into the center of the arena, blasting anyone <f5>NOT<F0> at the edges into the air and probably out of the arena.  When you hear the warning siren, you will have mere seconds to escape the blast.  Make sure you do, as all kills and deaths will be worth double.\n\n<F2>CREATOR:<F0>  / {HM} Sabre -^-");

	%count = playerManager::getPlayerCount();
	for(%i = 0; %i < %count; %i++)
	{
		%player = playermanager::getPlayerNum(%i);
		%player.kills = 0;
		%player.deaths = 0;
	}
}

function vehicle::onattacked(%this, %object)
{
	healobject(%this, 175);
	if(%object > 0)
	{
		healobject(%this, 175);
		reloadobject(%this, 1);
		damagearea(%this, 0,0,-1,10,0);
		schedule("damagearea("@%this@", 0,0,-1,10,0);", 0.1);
		schedule("damagearea("@%this@", 0,0,-1,10,0);", 0.2);
		schedule("damagearea("@%this@", 0,0,-1,10,0);", 0.3);
		if(%this != %object)
		{
			%this.attacker = %object;
		}
	}
}


function fallcheckup(%this)
{
	if( getposition( %this, z ) < 1050 )
	{
		damageobject(%this, 50000);
		return;
	}
	if(isgroupdestroyed(%this))
		return;
	schedule("fallcheckup("@%this@");", 1);
}

function vehicle::ondestroyed(%this, %object)
{	
	%this.dead = true;
	if(%this.attacker > 0)
	{
		%object = %this.attacker;
		%r = randomint(1, 10);
		if(%r == 1)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was evicted from the arena by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 2)
			say(0,0,"<F5>"@gethudname(%object)@"<F5> shoved "@gethudname(%this)@"<F5> out of the arena.", "sfx_reactorcap_backfire.wav");
		if(%r == 3)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> got the ol' heave-ho from "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 4)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was tripped by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 5)
			say(0,0,"<F5>"@gethudname(%object)@"<F5> gave "@gethudname(%this)@"<F5> a one-way ticket out of the arena.", "sfx_reactorcap_backfire.wav");
		if(%r == 6)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was blown away by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 7)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was evicted from the arena by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 8)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was evicted from the arena by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 9)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was evicted from the arena by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		if(%r == 10)
			say(0,0,"<F5>"@gethudname(%this)@"<F5> was evicted from the arena by "@gethudname(%object)@"<F5>.", "sfx_reactorcap_backfire.wav");
		%oplayer = playermanager::vehicleidtoplayernum(%object);
		%tplayer = playermanager::vehicleidtoplayernum(%this);
		if(%oplayer != %tplayer)
		{
			%oplayer.kills++;
		}
		%tplayer.deaths++;
	}
	%player = playermanager::vehicleidtoplayernum(%this);
	if(%player > 0)
	{
	}
	else
	{
		schedule("deleteobject("@%this@");", 0.5);
	}
}

function thump::trigger::oncontact(%this, %object)
{
	for(%i=0;%i<$burst.targets;%i++)
	{
		if(%object == $burst.target[%i])
			return;
	}
	$burst.target[$burst.targets] = %object;
	$burst.targets++;
}

function getplayerScore(%a)
{
	if( %a.deaths )
		%score = ( %a.kills / ( %a.deaths ) ) * 100;
	else
		%score = %a.kills * 150;
	if(%score >= 1000)
		return strAlign(4, L, %score);
	if(%score >= 100)
		return strAlign(3, L, %score);
	if(%score >= 10)
		return strAlign(2, L, %score);
	if(%score >= 1)
		return strAlign(1, L, %score);
	return 0;
}

function getplayerKills(%player)
{
	return %player.kills;
}

function getplayerDeaths(%player)
{
	return %player.deaths;
}

function initScoreBoard()
{
   deleteVariables("$ScoreBoard::PlayerColumn*");
   deleteVariables("$ScoreBoard::TeamColumn*");

       // Player ScoreBoard column headings
	   $ScoreBoard::PlayerColumnHeader1 = *IDMULT_SCORE_SQUAD;
	   $ScoreBoard::PlayerColumnHeader2 = *IDMULT_SCORE_SCORE;
	   $ScoreBoard::PlayerColumnHeader3 = *IDMULT_SCORE_KILLS;
	   $ScoreBoard::PlayerColumnHeader4 = *IDMULT_SCORE_DEATHS;

	   // Player ScoreBoard column functions
	   $ScoreBoard::PlayerColumnFunction1 = "getSquad";
	   $ScoreBoard::PlayerColumnFunction2 = "getplayerScore";
	   $ScoreBoard::PlayerColumnFunction3 = "getplayerKills";
	   $ScoreBoard::PlayerColumnFunction4 = "getplayerDeaths";

   serverInitScoreBoard();
}	

function onmissionend()
{
	flushconsolescheduler();
}

//Easter Egg

Pilot AI
{
	id=28;
	skill=0.5;
	accuracy=0.5;
	aggressiveness=2;
	activateDist=800.0;
	deactivateBuff=100.0;
	targetFreq=3.0;
	trackFreq=0.1;
	fireFreq=0.1;
	LOSFreq=0.1;
};

function AIdrop(%player)
{
	%veh=playermanager::playernumtovehicleId(%player);
	%AI=clonevehicle(%veh);
	setPilotId(%AI,28);
	redrop(%AI);
}

function AIwar(%period)
{
	if(%period)
		$AIWar::Period = %period;
	if($AIWar::Period)
	{
		%c = playermanager::getplayercount();
		%r = randomint(0, %c-1);
		%p = playermanager::getPlayerNum(%r);
		AIdrop(%p);
		schedule("AIWar();", $AIWar::Period);
	}
}