Starsiege: Tribes Map - 'Wildside' by Gonk

**********************************
Description
**********************************

Basically just a modification of Broadside (again). I did it to get the
feel of TED. Hope you enjoy it!

**********************************
Installation Instructions
**********************************

NOTE:This map is only a required download for servers. (server-side map)
Although clients are welcome to download the map, it is not necessary.

Unzip both files to your Tribes\base\missions directory

**********************************
Author Information
**********************************

Name: Gonk (Gonk-PTT- on the servers)
Tribe: Planet-Tribes Tribe
URL: http://www.planet-tribes.com
E-Mail: ramone241@usnetway.com
Misc. Info.: This is my first Tribes map, and I hope to make more. I was
amazed at how simple it was to do this. TED really is a great tool. I
hope you server ops and your players enjoy this map! Look for more maps
by me soon! Thanks again!