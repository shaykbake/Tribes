$ObjData::Num = "0";
$ObjData::WinScore = 100;
$ObjData::MissionType = "Capture and Hold";
