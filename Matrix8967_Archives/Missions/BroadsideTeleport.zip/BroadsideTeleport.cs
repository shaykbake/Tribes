//For use with BroadsideTeleport by Stephen Limowski
//SL83@mindspring.com
//ICQ#:32109041
//-----------------------------------------
//GroupTrigger::onEnter()
//-----------------------------------------
function GroupTrigger::onEnter(%this, %object)
{
// this gets the clients id number
%client = Player::getClient(%object);
   // Diamond Sword in out positions 
	if(%this.num == "BS1"){
      %positionIn = "-71.6596 -222.257 1170.09";
      %positionOut = "-456.19 -246.069 179.952";
   }
// Diamond Sword in out positions
   else if(%this.num == "BS2"){
      %positionIn = "-72.1197 -238.183 1170.17";
      %positionOut = "-377.484 -205.882 135.629";
   }  
// Diamond Sword in out positions
   else if(%this.num == "BS3"){
      %positionIn = "-119.393 -238.489 1170.1";
      %positionOut = "-399.745 -283.608 114.423";
   }  
// Diamond Sword in out positions
   else if(%this.num == "BS4"){
      %positionIn = "-119.402 -222.363 1170.19";
      %positionOut = "-394.476 -240.055 147.154";
   }  
// Blood Eagle in out positions
   else if(%this.num == "BS5"){
      %positionIn = "-225.567 -237.967 1170.89";
      %positionOut = "-216.702 -226.885 187.022";
   }
// Blood Eagle in out positions
   else if(%this.num == "BS6"){
      %positionIn = "-225.408 -221.975 1170.92";
      %positionOut = "-246.551 -249.246 148.542";
   }        
// Blood Eagle in out positions
   else if(%this.num == "BS7"){
      %positionIn = "-179.148 -221.976 1170.89";
      %positionOut = "-265.263 -212.154 152.927";
   }  
// Blood Eagle in out positions
   else if(%this.num == "BS8"){
      %positionIn = "-179.132 -238.349 1170.87";
      %positionOut = "-259.715 -153.337 147.554";
   }  
// this sets the actual position if trigger is in = true
	if(%this.in){ 
         GameBase::setPosition(%client, %positionIn);
         //messageAll(0, "~wshieldhit.wav");
	   Client::SendMessage(%client,0,"~wshieldhit.wav");
      }
      // this sets the position if out = true
	else if(%this.out){
         GameBase::setPosition(%client, %positionOut);
         //messageAll(0, "~wshieldhit.wav");
         Client::SendMessage(%client,0,"~wshieldhit.wav");
	}
 
} 