This is the final version of Broadside with a new method of spawning.  I implemented a new spawning method using a teleporter and spawning base.  Each team owns one spawn base, and there are many inventory stations in it.  After you die once, you will respawn in the Spawning Base and then can suit up and teleport down to the ground.  You only have access to your spawn base and only if you die.  You cannot take the flag into the spawn base, and enemies cannot enter your spawn base.  There are four teleporters in each base.

There are 3 files that are needed for the map to function

BroadsideTeleport.cs---This is the Teleporter file and must go in the Tribes\base folder.  It will work even if you are running a Mod.

BroadsideTeleport.MIS---This is the Mission file and goes in the Missions folder

BroadsideTeleport.DSC---Mission Description file wich goes in the Missions folder also.

If you have any questions or comments I can be reached at SL83@mindspring.com
ICQ: 32109041

Stephen Limowski--SL83