AVALANCHE -- A New Balanced Map for TRIBES

  Avalanche is a new, balanced map intended for use in 
organized ladder matches. This map was first unveiled
at TRIBEScon '99.

  To use Avalanche, place the files into your
TRIBES\base\missions directory.  Enjoy!

Also Remeber, if you see Analog Kid and he looks confused, 
ignore him and go on. He is harmless, and is probably 
pretending to be a tree or a squrrell or something...