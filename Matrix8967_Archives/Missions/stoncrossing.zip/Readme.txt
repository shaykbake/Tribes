Well here a new map from me to you i hope you like.


the maps name is StonCrossing i bet you can't think of where i got the
name hehe.

here is my Version DangerousCrossing.



"Peace" 


for Stoned