Volcano(CTF)

Just extract to your tribes/base/missions directory and that's it!


Designed by Pokey
Feel free to email me with any questions or comments.
jiw592s@mail.smsu.edu



Special thanks to Earthworm for a fantastic tutorial! http://www.seatac.net/earthworm/
