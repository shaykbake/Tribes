MakeSkin: A skin/logo processor for StarSiege TRIBES
----------------------------------------------------

  To make a skin that will work properly in TRIBES,
you must first create an 8-bit (Indexed color in
PhotoShop) MS .BMP file, using one of the included
palettes, pal1-pal3.  All are included in PS .act
form, as well as the MS .pal format.  If it becomes
necessary, they'll be re-released in more esoteric
file formats, but this should be sufficient for
almost any bitmap editor out there.

  Once you have your bitmap mapped to the proper
color set, all you need to do is run makeskin.exe on
it once, and it should be ready to go.  For instance,
if you've created a Light Armor skin called skin.bmp,
using pal3, and your Tribes's skin prefix is DCore,
you would execute:

makeskin pal3 skin.bmp dcore.larmor.bmp

  That's all there is to it!  You'll next need to put
your Tribes's skins into a volume, and place the
volume in your base\skins directory.  Read
SkinVolumes.txt to find out how to use vt to accomplish
this.  Note that for your skin to be visible to others,
they must also have the skin volume on their computer.

WARNING: This is an UNSUPPORTED tool, with very little
error checking!  It's entirely possible that, if passed
improper arguments, makeskin could overwrite vital data.
Always back up your art, and make sure that the output
name you pass in is valid.  Dynamix cannot be responsible
for any loss of data.

FURTHER WARNING: If any palette other than pal3 is used,
your skin will not render correctly in the preview
window of the Player Setup screen in TRIBES v1.0  (though
it will show up correctly in the game).  This will be
addressed, but it is strongly recommended that you use
pal3 unless you urgently need the color set in one of the
other palettes.  (All of the baseline skins are rendered
in this palette.)
