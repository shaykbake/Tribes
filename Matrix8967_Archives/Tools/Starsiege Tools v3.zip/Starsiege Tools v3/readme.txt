----------------------------------------------------------------------
 Tools release notes:
----------------------------------------------------------------------

   This is a collection of the tools which we used in the production of 
Tribes.  We provide the tools to you as-is.  We understand that the tools
are not completely bug-free, though with some patience, and a little use, 
you should be able to use them for the purpose intended.

   Please read through all the documentation provided with this release.  
Many of the tools are somewhat tricky in their use -- the documentation
touches on some of these issues.
   
   We will continue to update the tools, and the accompaning documentation,
as we see fit.  Any changes will be posted on 'www.tribesplayers.com'.


----------------------------------------------------------------------
 Files included in this release:
----------------------------------------------------------------------
   
   cw3230.dll
   cw3230mt.dll
   cw3240mt.dll
   extract.exe
   makeskin.exe
   matilda2.exe
   MaxShapes.zip
   mfc42d.dll
   missionlighting.exe
   missionlighting.cs
   msvcrtd.dll
   picanew.exe
   textable.exe
   vmerge.exe
   vt.exe
   vtlist.exe
   zed.exe
   zedbuild.exe
   zedlight.exe
   zedshape.exe
   docs\AddingVoiceSets.txt
   docs\MakeSkin.txt
   docs\Matilda.txt
   docs\PicaNew.txt
   docs\MissionEditor\miseditor.htm
   docs\MissionEditor\Image72.gif
   docs\MissionEditor\Image73.gif
   docs\MissionEditor\Image74.gif
   docs\MissionEditor\Image75.gif
   docs\MissionEditor\Image76.gif
   docs\ZED\ZEDmanual.htm
   docs\ZED\Image(1-71).gif
   palettes\pal1MS.pal
   palettes\pal1PS.act
   palettes\pal2MS.pal
   palettes\pal2PS.act
   palettes\pal3MS.pal
   palettes\pal3PS.act
   samples\acommand.zed
   samples\BELfloatingPad.zed
   samples\bunker2.zed
   samples\COPLfloatingPad.zed
   samples\DSLfloatingPad.zed
   samples\SWLfloatingPad.zed

   ----------------------------------------------------------------------
   Note: be sure to place the following files in your tribes executable 
         directory:
      
         missionlighting.cs
         missionlighting.exe
         textable.exe
   ----------------------------------------------------------------------


----------------------------------------------------------------------
 Brief description of executables:
----------------------------------------------------------------------

zed.exe(1.96)
----------------------------------------------------------------------
   This program is used to create the interiors used in the game.  This
includes any of the bases, towers, bunkers, etc.  Please refer to the zed 
documentation on the use of this program.

   Zed has known stability issues running under Windows 95/98.  We highly
recommend that you run zed through Windows NT.  If you are unable to run
zed through Windows NT, it is advisable to avoid using the 'Texture View' 
and to save often!

   We are currently working on a Quake Level (.map file format) converter
for Tribes.  Once we are finished with it, it will be posted on our web site.
This should allow you to use your favorite Quake editor to generate Tribes
interior shapes.  

   Our current focus is on finishing the Quake map converter - so changes to
zed may not come quickly.  Please be patient.


zedbuild.exe(3.9) zedlight.exe(3.9) zedshape.exe(3.9)
----------------------------------------------------------------------
   These tools process the exported '.zvl' file from Zed to produce
a '.div' volume for use in the game.  Zedshape and Zedlight are invoked
from Zedbuild, so you will never need to run these programs directly.

   Example:
   
   zedbuild <zedfile.zvl> [-h]
      -h: to enable higher detail, at the expense of speed 
          (be sure to use when finished with shape)


vt.exe(3.0.1)
----------------------------------------------------------------------
   Tool to add files to volumes.  Run without arguments for a listing
of commands and usage.


vtlist.exe(1.00)
----------------------------------------------------------------------
   Tool to list the files within volumes.  Run without arguments for 
a listing of commands and usage.


extract.exe(1.0)
----------------------------------------------------------------------
   Tool used to get a file from a volume.  Run without arguments for a
listing of commands and usage.

vmerge.exe(1.0)
----------------------------------------------------------------------
   Used to merge two volumes together.  Run without arguments for a
listing of commands and usage.


textable.exe(2.1)
----------------------------------------------------------------------
   This program generates a material list and a terrain texture placement
lookup table for use with the terrain engine.  We will be posting information
on how to add user generated terrains soon.


missionlighting.exe (1.01)
----------------------------------------------------------------------
   This program relights the mission to generate detailed shadows.  It
can be invoked in the mission editor by pressing the 'Relight' button.  The
program requires the console script 'missionlighting.cs' to be in the same
directory as the executable.  Be sure to place it in your executable 
directory (where tribes.exe is) along with the 'missionlighting.cs' file.
You can also run the program from a command prompt.

   Example:

   missionlighting base\missions\raindance.mis 
   
   Run without arguments for more information on commands and usage.

makeskin.exe(1.0)
----------------------------------------------------------------------
   This program remaps 8-bit Windows .BMP files in Phoenix bitmaps according
to provided palette files for use in TRIBES.  For detailed usage please
read 'makeskin.txt'.

picanew.exe(1.3)
----------------------------------------------------------------------
   This utility is used to generate palette files for use in the game.
For detailed usage please read 'picanew.txt'.

matilda2.exe(3.21)
----------------------------------------------------------------------
   This utility generates material lists for use in the game.  A material
list is essentially a list of bitmaps along with extra information for
each material.  For detailed usage please read 'matilda.txt'



----------------------------------------------------------------------
 What's missing:
----------------------------------------------------------------------

   Here is a list of some items we are currently addressing:
   
   * documentation, and tutorial, on adding user generated terrain sets
   * Quake map file converter
   * information on adding user defined worlds into the new mission wizard
   * more advanced editing documentation

----------------------------------------------------------------------

      Have fun!

      Mitch Shaw
      <mitch.shaw@dynamix.com>


